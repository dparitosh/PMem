<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703185058626_983056_420332" xmi:uuid="a6fe3e30-915a-013c-7158-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703185058621_651945_420321"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_8e001ed_1498551965780_845924_14128"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703185077685_134540_421260" xmi:uuid="aa47c800-915a-013c-7158-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703185077680_306741_421249"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_8e001ed_1498551965780_845924_14128"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703185177901_192566_425657" xmi:uuid="bd985980-915a-013c-7158-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703185177896_694405_425646"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_8e001ed_1498551965780_845924_14128"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_29c0149_1617189722996_879842_14897" xmi:uuid="d1971410-8fde-0139-a9d8-78b156d8ad1a">
    <base_UMLClassDiagram xmi:idref="_18_4_1_29c0149_1617189722988_121984_14886"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_8e001ed_1498551965780_845924_14128"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446301038_60614_285910" xmi:uuid="1273e1d0-6c45-013d-d60b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446301032_895633_285899"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200446735_930490_15617"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446298898_935196_283072" xmi:uuid="1a20d270-6c46-013d-d60b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446298892_269869_283061"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200734582_937142_15801"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1620220113969_458060_66215" xmi:uuid="2f56bf80-9071-0139-a9e5-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1620220113860_255580_66203"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201320430_810393_16219"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446297951_855666_281865" xmi:uuid="3d39fe30-6c46-013d-d60b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446297944_706856_281854"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617199936020_463996_15431"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446299721_49277_284161" xmi:uuid="56e49b70-6c45-013d-d60b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446299714_911578_284150"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446301397_448864_286393" xmi:uuid="5e3dd440-6c46-013d-d60b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446301391_461768_286382"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200980407_188298_15943"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446299133_884096_283375" xmi:uuid="879a14f0-6c45-013d-d60b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446299126_987106_283364"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192893237_274389_15179"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446298371_917521_282349" xmi:uuid="bdf78c10-6c45-013d-d60b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446298365_965832_282338"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446300804_453215_285607" xmi:uuid="cb1922b0-6c45-013d-d60b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446300798_414135_285596"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201320430_810393_16219"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1617822556593_358101_75938" xmi:uuid="d1c96140-8fde-0139-a9d8-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1617822556572_971623_75927"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1617828792527_134905_79074" xmi:uuid="d253cde0-8fde-0139-a9d8-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1617828792518_436056_79063"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200446735_930490_15617"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617720169165_423927_61691" xmi:uuid="d2e4bfc0-8fde-0139-a9d8-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617720169101_631824_61679"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1617825998950_564159_77262" xmi:uuid="d361f4d0-8fde-0139-a9d8-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1617825998943_326731_77251"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192893237_274389_15179"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1617818940493_630996_69914" xmi:uuid="d3e37180-8fde-0139-a9d8-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1617818940332_230570_69903"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1617823883620_160974_76502" xmi:uuid="d3fdfc50-8fde-0139-a9d8-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1617823883572_914156_76490"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201153286_596027_16081"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1617824748114_51022_76952" xmi:uuid="d49175d0-8fde-0139-a9d8-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1617824748108_228858_76941"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200734582_937142_15801"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1617828099801_464663_78715" xmi:uuid="d523da50-8fde-0139-a9d8-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1617828099792_491480_78704"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617199936020_463996_15431"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617721642860_153854_64528" xmi:uuid="d5b1e6c0-8fde-0139-a9d8-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617721642860_252556_64517"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200980407_188298_15943"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446300283_692531_284884" xmi:uuid="e3b32460-6c44-013d-d60b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446300277_114859_284873"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446299488_751240_283858" xmi:uuid="f49c0c90-6c45-013d-d60b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446299482_473634_283847"/>
    <defaultNamespace href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201153286_596027_16081"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703185058621_651945_420321" xmi:uuid="a6fd6650-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_8e001ed_1498551965780_845924_14128"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185058673_323176_420354" xmi:uuid="a705f370-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200521903_877462_15663"/>
      <ownedElement xmi:id="a701cc50-915a-013c-7158-0a5172f4a469" xmi:uuid="a701cd70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200521903_877462_15663"/>
        <text>SchemeEntryAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="a703ae00-915a-013c-7158-0a5172f4a469" xmi:uuid="a703af10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="a7044b40-915a-013c-7158-0a5172f4a469" xmi:uuid="a7044c20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1187" height="205"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185060732_489237_420425" xmi:uuid="a73f4560-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="a70ce1c0-915a-013c-7158-0a5172f4a469" xmi:uuid="a70ce2e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="0bdbba40-6c42-013d-d60b-0800270c66d6" xmi:uuid="0bdbbb10-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185061333_998203_420485" xmi:uuid="a7533e90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityAssignment"/>
      <ownedElement xmi:id="a7418cc0-915a-013c-7158-0a5172f4a469" xmi:uuid="a7418dd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityAssignment"/>
        <text>ActivityAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="0efa2ae0-6c42-013d-d60b-0800270c66d6" xmi:uuid="0efa2b80-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="278" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185063034_930742_420579" xmi:uuid="a7927a00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
      <ownedElement xmi:id="a7558250-915a-013c-7158-0a5172f4a469" xmi:uuid="a7558370-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
        <text>ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="101f6570-6c42-013d-d60b-0800270c66d6" xmi:uuid="101f6600-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="491" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185063851_899118_420632" xmi:uuid="a84ec650-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueAssignment"/>
      <ownedElement xmi:id="a7b92e00-915a-013c-7158-0a5172f4a469" xmi:uuid="a7b92f20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueAssignment"/>
        <text>PropertyValueAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="1c035f80-6c42-013d-d60b-0800270c66d6" xmi:uuid="1c036010-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="704" y="95" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185065207_364926_420697" xmi:uuid="a88f0b40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583841957854_241881_57156"/>
      <ownedElement xmi:id="a8577bb0-915a-013c-7158-0a5172f4a469" xmi:uuid="a8577cc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583841957854_241881_57156"/>
        <text>ResourceAsRealized</text>
      </ownedElement>
      <ownedElement xmi:id="24e305d0-6c42-013d-d60b-0800270c66d6" xmi:uuid="24e30660-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="980" y="95" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185066693_474070_420759" xmi:uuid="a8c317a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832142352_199733_56200"/>
      <ownedElement xmi:id="a8923260-915a-013c-7158-0a5172f4a469" xmi:uuid="a8923370-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832142352_199733_56200"/>
        <text>ResourceEvent</text>
      </ownedElement>
      <ownedElement xmi:id="281d0880-6c42-013d-d60b-0800270c66d6" xmi:uuid="281d0910-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="145" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185068536_13489_420828" xmi:uuid="a8ebbc90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
      <ownedElement xmi:id="a8c53650-915a-013c-7158-0a5172f4a469" xmi:uuid="a8c53760-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
        <text>Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="2ad739e0-6c42-013d-d60b-0800270c66d6" xmi:uuid="2ad73a80-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="297" y="145" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185070064_432330_420895" xmi:uuid="a9121770-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
      <ownedElement xmi:id="a8edc300-915a-013c-7158-0a5172f4a469" xmi:uuid="a8edc410-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
        <text>SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="2d749110-6c42-013d-d60b-0800270c66d6" xmi:uuid="2d7491a0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="569" y="145" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185071910_783181_420980" xmi:uuid="a93a61e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
      <ownedElement xmi:id="a9142000-915a-013c-7158-0a5172f4a469" xmi:uuid="a9142110-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
        <text>SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="3008c8a0-6c42-013d-d60b-0800270c66d6" xmi:uuid="3008c930-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="841" y="145" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185073442_564001_421047" xmi:uuid="a9940410-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
      <ownedElement xmi:id="a945b9c0-915a-013c-7158-0a5172f4a469" xmi:uuid="a945bae0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
        <text>TaskElement</text>
      </ownedElement>
      <ownedElement xmi:id="350cc660-6c42-013d-d60b-0800270c66d6" xmi:uuid="350cc700-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="195" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185075564_802476_421117" xmi:uuid="a9ee97b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
      <ownedElement xmi:id="a997a270-915a-013c-7158-0a5172f4a469" xmi:uuid="a997a380-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
        <text>TaskMethod</text>
      </ownedElement>
      <ownedElement xmi:id="3a5729f0-6c42-013d-d60b-0800270c66d6" xmi:uuid="3a572a80-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="323" y="195" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185077649_108105_421208" xmi:uuid="aa4655b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
      <ownedElement xmi:id="a9f25200-915a-013c-7158-0a5172f4a469" xmi:uuid="a9f25330-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
        <text>TaskMethodVersion</text>
      </ownedElement>
      <ownedElement xmi:id="40a7d640-6c42-013d-d60b-0800270c66d6" xmi:uuid="40a7d6c0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="581" y="195" width="238" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1247" height="275"/>
    <name>SchemeEntryAssignmentSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703185077680_306741_421249" xmi:uuid="aa46fbb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_8e001ed_1498551965780_845924_14128"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185077712_294287_421281" xmi:uuid="aa4fabf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617196081526_459916_15269"/>
      <ownedElement xmi:id="aa4ba2e0-915a-013c-7158-0a5172f4a469" xmi:uuid="aa4ba3f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617196081526_459916_15269"/>
        <text>SchemeSubjectAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="aa4d9670-915a-013c-7158-0a5172f4a469" xmi:uuid="aa4d9780-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="aa4e2150-915a-013c-7158-0a5172f4a469" xmi:uuid="aa4e2210-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1243" height="755"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185079794_467506_421352" xmi:uuid="aa8520a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="aa522140-915a-013c-7158-0a5172f4a469" xmi:uuid="aa522260-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="46e3eeb0-6c42-013d-d60b-0800270c66d6" xmi:uuid="46e3ef40-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185080399_360150_421412" xmi:uuid="aa998f50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityAssignment"/>
      <ownedElement xmi:id="aa8764a0-915a-013c-7158-0a5172f4a469" xmi:uuid="aa8765b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityAssignment"/>
        <text>ActivityAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="4a04fdc0-6c42-013d-d60b-0800270c66d6" xmi:uuid="4a04fe50-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="278" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185082099_125818_421506" xmi:uuid="aad95ba0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
      <ownedElement xmi:id="aa9bdba0-915a-013c-7158-0a5172f4a469" xmi:uuid="aa9bdcc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
        <text>ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="4b211050-6c42-013d-d60b-0800270c66d6" xmi:uuid="4b2110f0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="491" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185083944_279859_421574" xmi:uuid="aaf6c470-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
      <ownedElement xmi:id="aade1780-915a-013c-7158-0a5172f4a469" xmi:uuid="aade1b60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
        <text>Analysis</text>
      </ownedElement>
      <ownedElement xmi:id="4f82a1e0-6c42-013d-d60b-0800270c66d6" xmi:uuid="4f82a280-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="704" y="95" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185085955_35960_421636" xmi:uuid="ab0bf6a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
      <ownedElement xmi:id="aaf84630-915a-013c-7158-0a5172f4a469" xmi:uuid="aaf84730-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
        <text>AnalysisDisciplineDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="5144ead0-6c42-013d-d60b-0800270c66d6" xmi:uuid="5144eb70-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="923" y="95" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185087727_17463_421721" xmi:uuid="ab204540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
      <ownedElement xmi:id="ab0d8390-915a-013c-7158-0a5172f4a469" xmi:uuid="ab0d84a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
        <text>AnalysisVersion</text>
      </ownedElement>
      <ownedElement xmi:id="528e97d0-6c42-013d-d60b-0800270c66d6" xmi:uuid="528e9840-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="145" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185089817_220972_421795" xmi:uuid="ab82d7f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_Breakdown"/>
      <ownedElement xmi:id="ab2a05c0-915a-013c-7158-0a5172f4a469" xmi:uuid="ab2a06e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_Breakdown"/>
        <text>Breakdown</text>
      </ownedElement>
      <ownedElement xmi:id="557e6f30-6c42-013d-d60b-0800270c66d6" xmi:uuid="557e6fc0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="284" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185091989_31370_421869" xmi:uuid="abdfc8d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
      <ownedElement xmi:id="ab862700-915a-013c-7158-0a5172f4a469" xmi:uuid="ab862810-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
        <text>BreakdownElement</text>
      </ownedElement>
      <ownedElement xmi:id="5a4ed050-6c42-013d-d60b-0800270c66d6" xmi:uuid="5a4ed0e0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="517" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185093875_419965_421942" xmi:uuid="ac1c4c80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersion"/>
      <ownedElement xmi:id="abe31880-915a-013c-7158-0a5172f4a469" xmi:uuid="abe31da0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersion"/>
        <text>BreakdownElementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="5f7dccf0-6c42-013d-d60b-0800270c66d6" xmi:uuid="5f7dcd90-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="750" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185096157_940248_422025" xmi:uuid="ac72b640-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
      <ownedElement xmi:id="ac1fafb0-915a-013c-7158-0a5172f4a469" xmi:uuid="ac1fb0c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
        <text>BreakdownElementView</text>
      </ownedElement>
      <ownedElement xmi:id="62d2ee50-6c42-013d-d60b-0800270c66d6" xmi:uuid="62d2eee0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="983" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185097652_388599_422096" xmi:uuid="aca98110-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersion"/>
      <ownedElement xmi:id="ac761b70-915a-013c-7158-0a5172f4a469" xmi:uuid="ac761c80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersion"/>
        <text>BreakdownVersion</text>
      </ownedElement>
      <ownedElement xmi:id="67725ed0-6c42-013d-d60b-0800270c66d6" xmi:uuid="67725f70-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="195" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185099500_481245_422165" xmi:uuid="acd84510-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581927879268_726070_55882"/>
      <ownedElement xmi:id="acaf3e20-915a-013c-7158-0a5172f4a469" xmi:uuid="acaf3f30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581927879268_726070_55882"/>
        <text>Collection</text>
      </ownedElement>
      <ownedElement xmi:id="6ae26960-6c42-013d-d60b-0800270c66d6" xmi:uuid="6ae26a00-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="298" y="195" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185101267_69665_422240" xmi:uuid="acf9d490-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
      <ownedElement xmi:id="acda73e0-915a-013c-7158-0a5172f4a469" xmi:uuid="acda74e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
        <text>CollectionVersion</text>
      </ownedElement>
      <ownedElement xmi:id="6d44b890-6c42-013d-d60b-0800270c66d6" xmi:uuid="6d44b930-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="523" y="195" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185103159_805179_422313" xmi:uuid="ad188300-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
      <ownedElement xmi:id="acfbfcd0-915a-013c-7158-0a5172f4a469" xmi:uuid="acfbfde0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
        <text>CollectionView</text>
      </ownedElement>
      <ownedElement xmi:id="6f255f10-6c42-013d-d60b-0800270c66d6" xmi:uuid="6f255fa0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="748" y="195" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185104389_380385_422377" xmi:uuid="adce9a10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Contract"/>
      <ownedElement xmi:id="ad2e5b10-915a-013c-7158-0a5172f4a469" xmi:uuid="ad2e5f50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Contract"/>
        <text>Contract</text>
      </ownedElement>
      <ownedElement xmi:id="732846d0-6c42-013d-d60b-0800270c66d6" xmi:uuid="73284bf0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="973" y="195" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185106526_899166_422451" xmi:uuid="ae15b380-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_Document"/>
      <ownedElement xmi:id="add66660-915a-013c-7158-0a5172f4a469" xmi:uuid="add667a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_Document"/>
        <text>Document</text>
      </ownedElement>
      <ownedElement xmi:id="7fd27ad0-6c42-013d-d60b-0800270c66d6" xmi:uuid="7fd27bb0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="245" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185108436_552628_422517" xmi:uuid="ae4865d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
      <ownedElement xmi:id="ae183010-915a-013c-7158-0a5172f4a469" xmi:uuid="ae183130-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
        <text>DocumentDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="84a127f0-6c42-013d-d60b-0800270c66d6" xmi:uuid="84a12940-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="356" y="245" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185110332_680036_422602" xmi:uuid="ae72d4e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
      <ownedElement xmi:id="ae4af530-915a-013c-7158-0a5172f4a469" xmi:uuid="ae4af650-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
        <text>DocumentVersion</text>
      </ownedElement>
      <ownedElement xmi:id="8950b640-6c42-013d-d60b-0800270c66d6" xmi:uuid="8950b6d0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="647" y="245" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185110601_406519_422646" xmi:uuid="aebf1b20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8f301ed_1516976459291_216644_31699"/>
      <ownedElement xmi:id="ae7f11d0-915a-013c-7158-0a5172f4a469" xmi:uuid="ae7f1400-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8f301ed_1516976459291_216644_31699"/>
        <text>EnvironmentDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="8e753b40-6c42-013d-d60b-0800270c66d6" xmi:uuid="8e753bd0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="938" y="245" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185110878_676582_422700" xmi:uuid="af054a30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517519484482_504497_34529"/>
      <ownedElement xmi:id="aeccd300-915a-013c-7158-0a5172f4a469" xmi:uuid="aeccd430-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517519484482_504497_34529"/>
        <text>EnvironmentDefinitionVersion</text>
      </ownedElement>
      <ownedElement xmi:id="92014d40-6c42-013d-d60b-0800270c66d6" xmi:uuid="92014de0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="295" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185112772_666241_422769" xmi:uuid="af457730-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
      <ownedElement xmi:id="af0d2e80-915a-013c-7158-0a5172f4a469" xmi:uuid="af0d2fa0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
        <text>IndividualPart</text>
      </ownedElement>
      <ownedElement xmi:id="9570ffb0-6c42-013d-d60b-0800270c66d6" xmi:uuid="95710050-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="295" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185114627_221711_422843" xmi:uuid="af737f00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
      <ownedElement xmi:id="af4811f0-915a-013c-7158-0a5172f4a469" xmi:uuid="af4813e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
        <text>IndividualPartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="989a0af0-6c42-013d-d60b-0800270c66d6" xmi:uuid="989a0b90-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="584" y="295" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185116564_878765_422918" xmi:uuid="afa36070-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="af761c50-915a-013c-7158-0a5172f4a469" xmi:uuid="af761d70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="9b299de0-6c42-013d-d60b-0800270c66d6" xmi:uuid="9b299e80-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="827" y="295" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185118431_44966_422986" xmi:uuid="afffa860-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133997057_424483_38872"/>
      <ownedElement xmi:id="afad88a0-915a-013c-7158-0a5172f4a469" xmi:uuid="afad89b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133997057_424483_38872"/>
        <text>InterfaceConnector</text>
      </ownedElement>
      <ownedElement xmi:id="a0ea9da0-6c42-013d-d60b-0800270c66d6" xmi:uuid="a0ea9e40-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185120230_49977_423059" xmi:uuid="b041f440-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134019779_950347_38878"/>
      <ownedElement xmi:id="b00337a0-915a-013c-7158-0a5172f4a469" xmi:uuid="b00338b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134019779_950347_38878"/>
        <text>InterfaceConnectorVersion</text>
      </ownedElement>
      <ownedElement xmi:id="a5e80e10-6c42-013d-d60b-0800270c66d6" xmi:uuid="a5e80eb0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185121985_794631_423132" xmi:uuid="b0867450-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
      <ownedElement xmi:id="b0459b40-915a-013c-7158-0a5172f4a469" xmi:uuid="b0459f00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
        <text>InterfaceConnectorView</text>
      </ownedElement>
      <ownedElement xmi:id="a9526620-6c42-013d-d60b-0800270c66d6" xmi:uuid="a95266c0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="507" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185123864_563433_423200" xmi:uuid="b0d9d7f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134059448_942822_38888"/>
      <ownedElement xmi:id="b08a4b20-915a-013c-7158-0a5172f4a469" xmi:uuid="b08a4c70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134059448_942822_38888"/>
        <text>InterfaceSpecification</text>
      </ownedElement>
      <ownedElement xmi:id="ac83c630-6c42-013d-d60b-0800270c66d6" xmi:uuid="ac83c6e0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="728" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185125644_377556_423273" xmi:uuid="b11c43b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134081745_171261_38892"/>
      <ownedElement xmi:id="b0dd9400-915a-013c-7158-0a5172f4a469" xmi:uuid="b0dd9520-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134081745_171261_38892"/>
        <text>InterfaceSpecificationVersion</text>
      </ownedElement>
      <ownedElement xmi:id="b1775bd0-6c42-013d-d60b-0800270c66d6" xmi:uuid="b1775c70-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="949" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185127379_111098_423345" xmi:uuid="b15c3b40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
      <ownedElement xmi:id="b1204140-915a-013c-7158-0a5172f4a469" xmi:uuid="b1204250-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
        <text>InterfaceSpecificationView</text>
      </ownedElement>
      <ownedElement xmi:id="b5128c20-6c42-013d-d60b-0800270c66d6" xmi:uuid="b5128cc0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="395" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185129138_284295_423413" xmi:uuid="b21566d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1506005124993_361009_24731"/>
      <ownedElement xmi:id="b1637b30-915a-013c-7158-0a5172f4a469" xmi:uuid="b16385f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1506005124993_361009_24731"/>
        <text>Location</text>
      </ownedElement>
      <ownedElement xmi:id="ba356900-6c42-013d-d60b-0800270c66d6" xmi:uuid="ba3569a0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="395" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185130509_400794_423477" xmi:uuid="b24eb250-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832794448_726739_56316"/>
      <ownedElement xmi:id="b2186a80-915a-013c-7158-0a5172f4a469" xmi:uuid="b2186ba0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832794448_726739_56316"/>
        <text>ManagedResource</text>
      </ownedElement>
      <ownedElement xmi:id="c2e069c0-6c42-013d-d60b-0800270c66d6" xmi:uuid="c2e06a50-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="581" y="395" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185130786_939386_423521" xmi:uuid="b2933d00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8f301ed_1516977221331_943050_33189"/>
      <ownedElement xmi:id="b25ad480-915a-013c-7158-0a5172f4a469" xmi:uuid="b25ad6c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8f301ed_1516977221331_943050_33189"/>
        <text>ObservedEnvironment</text>
      </ownedElement>
      <ownedElement xmi:id="c6ed03f0-6c42-013d-d60b-0800270c66d6" xmi:uuid="c6ed04a0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="813" y="395" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185131062_731603_423575" xmi:uuid="b2dcef00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517519821879_463861_34616"/>
      <ownedElement xmi:id="b2a01e10-915a-013c-7158-0a5172f4a469" xmi:uuid="b2a01f20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517519821879_463861_34616"/>
        <text>ObservedEnvironmentVersion</text>
      </ownedElement>
      <ownedElement xmi:id="ca1481d0-6c42-013d-d60b-0800270c66d6" xmi:uuid="ca148270-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="445" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185131178_398565_423627" xmi:uuid="b30e9570-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517522422087_502748_35594"/>
      <ownedElement xmi:id="b2e9e320-915a-013c-7158-0a5172f4a469" xmi:uuid="b2e9e580-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517522422087_502748_35594"/>
        <text>ObservedEnvironmentView</text>
      </ownedElement>
      <ownedElement xmi:id="cdd4ac00-6c42-013d-d60b-0800270c66d6" xmi:uuid="cdd4aca0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="445" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185132707_363645_423694" xmi:uuid="b3c4fd20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
      <ownedElement xmi:id="b3158f60-915a-013c-7158-0a5172f4a469" xmi:uuid="b3159090-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
        <text>Organization</text>
      </ownedElement>
      <ownedElement xmi:id="cfd95120-6c42-013d-d60b-0800270c66d6" xmi:uuid="cfd951d0-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="617" y="445" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185134025_744810_423759" xmi:uuid="b46bec70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505750163257_414856_24072"/>
      <ownedElement xmi:id="b3cc6270-915a-013c-7158-0a5172f4a469" xmi:uuid="b3cc6390-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505750163257_414856_24072"/>
        <text>OrganizationType</text>
      </ownedElement>
      <ownedElement xmi:id="d8749280-6c42-013d-d60b-0800270c66d6" xmi:uuid="d8749300-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="912" y="445" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185136171_169360_423834" xmi:uuid="b513b450-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
      <ownedElement xmi:id="b47b5b00-915a-013c-7158-0a5172f4a469" xmi:uuid="b47b5c10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
        <text>Part</text>
      </ownedElement>
      <ownedElement xmi:id="e6580960-6c42-013d-d60b-0800270c66d6" xmi:uuid="e6580a20-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185138247_330524_423909" xmi:uuid="b57f0420-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
      <ownedElement xmi:id="b518b3c0-915a-013c-7158-0a5172f4a469" xmi:uuid="b518b4c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
        <text>PartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="ee2ab9e0-6c42-013d-d60b-0800270c66d6" xmi:uuid="ee2aba80-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="367" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185140281_736844_423986" xmi:uuid="b5ef9410-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="b5842ce0-915a-013c-7158-0a5172f4a469" xmi:uuid="b5842df0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="f38390b0-6c42-013d-d60b-0800270c66d6" xmi:uuid="f3839140-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="669" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185141807_226889_424049" xmi:uuid="b68a2540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
      <ownedElement xmi:id="b5f679f0-915a-013c-7158-0a5172f4a469" xmi:uuid="b5f67af0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
        <text>Person</text>
      </ownedElement>
      <ownedElement xmi:id="f941cff0-6c42-013d-d60b-0800270c66d6" xmi:uuid="f941d070-6c42-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="971" y="495" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185143703_363944_424139" xmi:uuid="b7429a20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
      <ownedElement xmi:id="b6912e10-915a-013c-7158-0a5172f4a469" xmi:uuid="b6912f10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
        <text>PersonInOrganization</text>
      </ownedElement>
      <ownedElement xmi:id="0085e660-6c43-013d-d60b-0800270c66d6" xmi:uuid="0085e6f0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="545" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185145043_830043_424214" xmi:uuid="b7e502f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639072510862_608091_65724"/>
      <ownedElement xmi:id="b7486180-915a-013c-7158-0a5172f4a469" xmi:uuid="b74862a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639072510862_608091_65724"/>
        <text>ProductGroup</text>
      </ownedElement>
      <ownedElement xmi:id="0a995ba0-6c43-013d-d60b-0800270c66d6" xmi:uuid="0a995c40-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="360" y="545" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185146604_880408_424284" xmi:uuid="b8a9ddd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Project"/>
      <ownedElement xmi:id="b7ebffb0-915a-013c-7158-0a5172f4a469" xmi:uuid="b7ec00d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Project"/>
        <text>Project</text>
      </ownedElement>
      <ownedElement xmi:id="1338f990-6c43-013d-d60b-0800270c66d6" xmi:uuid="1338fa30-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="662" y="545" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185147285_821500_424335" xmi:uuid="b92fb3e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionAssignment"/>
      <ownedElement xmi:id="b8b5ade0-915a-013c-7158-0a5172f4a469" xmi:uuid="b8b5af10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionAssignment"/>
        <text>PropertyDefinitionAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="1c8fed90-6c43-013d-d60b-0800270c66d6" xmi:uuid="1c8fef80-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="957" y="545" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185148134_713387_424398" xmi:uuid="b9d1b5d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueAssignment"/>
      <ownedElement xmi:id="b93b8370-915a-013c-7158-0a5172f4a469" xmi:uuid="b93b8470-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueAssignment"/>
        <text>PropertyValueAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="2326f8b0-6c43-013d-d60b-0800270c66d6" xmi:uuid="2326f940-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185149527_838186_424463" xmi:uuid="ba0c9420-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583829364095_153317_54200"/>
      <ownedElement xmi:id="b9d4fd10-915a-013c-7158-0a5172f4a469" xmi:uuid="b9d4fe30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583829364095_153317_54200"/>
        <text>RequiredResource</text>
      </ownedElement>
      <ownedElement xmi:id="2ae39470-6c43-013d-d60b-0800270c66d6" xmi:uuid="2ae395c0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="595" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185151436_867124_424532" xmi:uuid="ba55ddb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
      <ownedElement xmi:id="ba14f460-915a-013c-7158-0a5172f4a469" xmi:uuid="ba14f580-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
        <text>Requirement</text>
      </ownedElement>
      <ownedElement xmi:id="2ebcddb0-6c43-013d-d60b-0800270c66d6" xmi:uuid="2ebcde70-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="573" y="595" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185153339_161330_424606" xmi:uuid="ba8be410-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
      <ownedElement xmi:id="ba58be00-915a-013c-7158-0a5172f4a469" xmi:uuid="ba58bf10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
        <text>RequirementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="32319500-6c43-013d-d60b-0800270c66d6" xmi:uuid="32319590-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="876" y="595" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185154726_557856_424671" xmi:uuid="bac700a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583841957854_241881_57156"/>
      <ownedElement xmi:id="ba8f0a80-915a-013c-7158-0a5172f4a469" xmi:uuid="ba8f0bf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583841957854_241881_57156"/>
        <text>ResourceAsRealized</text>
      </ownedElement>
      <ownedElement xmi:id="3492be60-6c43-013d-d60b-0800270c66d6" xmi:uuid="3492bef0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="645" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185155881_702552_424731" xmi:uuid="baf70200-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
      <ownedElement xmi:id="bac9e940-915a-013c-7158-0a5172f4a469" xmi:uuid="bac9ea40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
        <text>ResourceItem</text>
      </ownedElement>
      <ownedElement xmi:id="3732b100-6c43-013d-d60b-0800270c66d6" xmi:uuid="3732b1a0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="297" y="645" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185157733_960358_424800" xmi:uuid="bb289570-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
      <ownedElement xmi:id="bafd60e0-915a-013c-7158-0a5172f4a469" xmi:uuid="bafd6210-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
        <text>Risk</text>
      </ownedElement>
      <ownedElement xmi:id="39df96c0-6c43-013d-d60b-0800270c66d6" xmi:uuid="39df9750-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="529" y="645" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185159551_779886_424874" xmi:uuid="bb4b55b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
      <ownedElement xmi:id="bb2ad340-915a-013c-7158-0a5172f4a469" xmi:uuid="bb2ad470-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
        <text>RiskVersion</text>
      </ownedElement>
      <ownedElement xmi:id="3c233720-6c43-013d-d60b-0800270c66d6" xmi:uuid="3c2337b0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="729" y="645" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185161422_358489_424943" xmi:uuid="bb756ab0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
      <ownedElement xmi:id="bb4d6b70-915a-013c-7158-0a5172f4a469" xmi:uuid="bb4d6c80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
        <text>Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="3dfbdfa0-6c43-013d-d60b-0800270c66d6" xmi:uuid="3dfbe960-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="929" y="645" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185162989_70431_425010" xmi:uuid="bb9b8040-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
      <ownedElement xmi:id="bb7773c0-915a-013c-7158-0a5172f4a469" xmi:uuid="bb7774d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
        <text>SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="402c5680-6c43-013d-d60b-0800270c66d6" xmi:uuid="402c5710-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="695" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185164860_294252_425095" xmi:uuid="bbc47c20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
      <ownedElement xmi:id="bb9d9220-915a-013c-7158-0a5172f4a469" xmi:uuid="bb9d9340-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
        <text>SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="421d4070-6c43-013d-d60b-0800270c66d6" xmi:uuid="421d4110-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="337" y="695" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185166763_534394_425163" xmi:uuid="bbf91f90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
      <ownedElement xmi:id="bbcb1120-915a-013c-7158-0a5172f4a469" xmi:uuid="bbcb1250-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
        <text>Slot</text>
      </ownedElement>
      <ownedElement xmi:id="451c4b30-6c43-013d-d60b-0800270c66d6" xmi:uuid="451c4bd0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="609" y="695" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185169001_732986_425231" xmi:uuid="bc29d4d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
      <ownedElement xmi:id="bbfb74e0-915a-013c-7158-0a5172f4a469" xmi:uuid="bbfb75f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
        <text>SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="465afba0-6c43-013d-d60b-0800270c66d6" xmi:uuid="465afc60-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="805" y="695" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185170832_521177_425316" xmi:uuid="bc4f8170-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
      <ownedElement xmi:id="bc2c3b10-915a-013c-7158-0a5172f4a469" xmi:uuid="bc2c3c30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
        <text>SlotVersion</text>
      </ownedElement>
      <ownedElement xmi:id="48bef760-6c43-013d-d60b-0800270c66d6" xmi:uuid="48bef7e0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="1001" y="695" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185172399_38790_425383" xmi:uuid="bca573f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
      <ownedElement xmi:id="bc533b80-915a-013c-7158-0a5172f4a469" xmi:uuid="bc533c90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
        <text>TaskElement</text>
      </ownedElement>
      <ownedElement xmi:id="4b55d860-6c43-013d-d60b-0800270c66d6" xmi:uuid="4b55d900-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="745" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185174570_118911_425453" xmi:uuid="bd01b5b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
      <ownedElement xmi:id="bca98930-915a-013c-7158-0a5172f4a469" xmi:uuid="bca98a70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
        <text>TaskMethod</text>
      </ownedElement>
      <ownedElement xmi:id="50026650-6c43-013d-d60b-0800270c66d6" xmi:uuid="500266f0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="323" y="745" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185176708_880042_425544" xmi:uuid="bd593460-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
      <ownedElement xmi:id="bd054030-915a-013c-7158-0a5172f4a469" xmi:uuid="bd054140-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
        <text>TaskMethodVersion</text>
      </ownedElement>
      <ownedElement xmi:id="55040470-6c43-013d-d60b-0800270c66d6" xmi:uuid="55040520-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="581" y="745" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185177865_307310_425605" xmi:uuid="bd96cc50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642455582242_622357_69835"/>
      <ownedElement xmi:id="bd62bc70-915a-013c-7158-0a5172f4a469" xmi:uuid="bd62bd90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642455582242_622357_69835"/>
        <text>TypeOfPerson</text>
      </ownedElement>
      <ownedElement xmi:id="5b2598e0-6c43-013d-d60b-0800270c66d6" xmi:uuid="5b259980-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="839" y="745" width="246" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1303" height="825"/>
    <name>SchemeSubjectAssignmentSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703185177896_694405_425646" xmi:uuid="bd978540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_8e001ed_1498551965780_845924_14128"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185177927_704752_425678" xmi:uuid="bda15550-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200014271_584922_15477"/>
      <ownedElement xmi:id="bd9c9c50-915a-013c-7158-0a5172f4a469" xmi:uuid="bd9c9d60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200014271_584922_15477"/>
        <text>SchemeVersionAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="bd9ec650-915a-013c-7158-0a5172f4a469" xmi:uuid="bd9ec780-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="bd9f6770-915a-013c-7158-0a5172f4a469" xmi:uuid="bd9f6840-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1243" height="755"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185180030_76640_425749" xmi:uuid="bdd87930-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="bda3d4a0-915a-013c-7158-0a5172f4a469" xmi:uuid="bda3d5e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="5e46dad0-6c43-013d-d60b-0800270c66d6" xmi:uuid="5e46db60-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185180636_872382_425809" xmi:uuid="bded2e70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityAssignment"/>
      <ownedElement xmi:id="bddab8e0-915a-013c-7158-0a5172f4a469" xmi:uuid="bddab9f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityAssignment"/>
        <text>ActivityAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="60f6bff0-6c43-013d-d60b-0800270c66d6" xmi:uuid="60f6c190-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="278" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185182370_946633_425903" xmi:uuid="be2e79f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
      <ownedElement xmi:id="bdef7dc0-915a-013c-7158-0a5172f4a469" xmi:uuid="bdef7f00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
        <text>ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="61cb1390-6c43-013d-d60b-0800270c66d6" xmi:uuid="61cb1430-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="491" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185184251_26331_425971" xmi:uuid="be48b5d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
      <ownedElement xmi:id="be3024d0-915a-013c-7158-0a5172f4a469" xmi:uuid="be3025f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
        <text>Analysis</text>
      </ownedElement>
      <ownedElement xmi:id="6511a300-6c43-013d-d60b-0800270c66d6" xmi:uuid="6511a3a0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="704" y="95" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185186313_914196_426033" xmi:uuid="be5e4360-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
      <ownedElement xmi:id="be4a50e0-915a-013c-7158-0a5172f4a469" xmi:uuid="be4a51e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
        <text>AnalysisDisciplineDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="66c147f0-6c43-013d-d60b-0800270c66d6" xmi:uuid="66c148a0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="923" y="95" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185188128_361467_426118" xmi:uuid="be7372b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
      <ownedElement xmi:id="be5fe540-915a-013c-7158-0a5172f4a469" xmi:uuid="be5fe650-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
        <text>AnalysisVersion</text>
      </ownedElement>
      <ownedElement xmi:id="67bf9840-6c43-013d-d60b-0800270c66d6" xmi:uuid="67bf98c0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="145" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185190271_218830_426192" xmi:uuid="bed065c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_Breakdown"/>
      <ownedElement xmi:id="be76c560-915a-013c-7158-0a5172f4a469" xmi:uuid="be76c670-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_Breakdown"/>
        <text>Breakdown</text>
      </ownedElement>
      <ownedElement xmi:id="68e3fd20-6c43-013d-d60b-0800270c66d6" xmi:uuid="68e3fdc0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="284" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185192490_577759_426266" xmi:uuid="bf2d30b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
      <ownedElement xmi:id="bed3ab00-915a-013c-7158-0a5172f4a469" xmi:uuid="bed3ac20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
        <text>BreakdownElement</text>
      </ownedElement>
      <ownedElement xmi:id="6dc7f750-6c43-013d-d60b-0800270c66d6" xmi:uuid="6dc7f7f0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="517" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185194413_490871_426339" xmi:uuid="bf6ae4c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersion"/>
      <ownedElement xmi:id="bf306be0-915a-013c-7158-0a5172f4a469" xmi:uuid="bf306d00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersion"/>
        <text>BreakdownElementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="71a4f120-6c43-013d-d60b-0800270c66d6" xmi:uuid="71a4f1b0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="750" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185196737_430624_426422" xmi:uuid="bfbf4ba0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
      <ownedElement xmi:id="bf6e49c0-915a-013c-7158-0a5172f4a469" xmi:uuid="bf6e4af0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
        <text>BreakdownElementView</text>
      </ownedElement>
      <ownedElement xmi:id="74ee33c0-6c43-013d-d60b-0800270c66d6" xmi:uuid="74ee3470-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="983" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185198270_83485_426493" xmi:uuid="bff745b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersion"/>
      <ownedElement xmi:id="bfc29690-915a-013c-7158-0a5172f4a469" xmi:uuid="bfc297a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersion"/>
        <text>BreakdownVersion</text>
      </ownedElement>
      <ownedElement xmi:id="78e8bf20-6c43-013d-d60b-0800270c66d6" xmi:uuid="78e8c020-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="195" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185200158_51937_426562" xmi:uuid="c0212570-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581927879268_726070_55882"/>
      <ownedElement xmi:id="bff97020-915a-013c-7158-0a5172f4a469" xmi:uuid="bff97140-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581927879268_726070_55882"/>
        <text>Collection</text>
      </ownedElement>
      <ownedElement xmi:id="7b8a3d50-6c43-013d-d60b-0800270c66d6" xmi:uuid="7b8a3df0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="298" y="195" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185201946_123525_426637" xmi:uuid="c042c510-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
      <ownedElement xmi:id="c0233040-915a-013c-7158-0a5172f4a469" xmi:uuid="c0233170-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
        <text>CollectionVersion</text>
      </ownedElement>
      <ownedElement xmi:id="7d902480-6c43-013d-d60b-0800270c66d6" xmi:uuid="7d902630-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="523" y="195" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185203691_973601_426710" xmi:uuid="c06112d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
      <ownedElement xmi:id="c044db80-915a-013c-7158-0a5172f4a469" xmi:uuid="c044dcc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
        <text>CollectionView</text>
      </ownedElement>
      <ownedElement xmi:id="7f17cf90-6c43-013d-d60b-0800270c66d6" xmi:uuid="7f17d050-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="748" y="195" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185204938_631067_426774" xmi:uuid="c10137e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Contract"/>
      <ownedElement xmi:id="c0681120-915a-013c-7158-0a5172f4a469" xmi:uuid="c0681450-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Contract"/>
        <text>Contract</text>
      </ownedElement>
      <ownedElement xmi:id="812080f0-6c43-013d-d60b-0800270c66d6" xmi:uuid="81208190-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="973" y="195" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185207133_931949_426848" xmi:uuid="c1468870-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_Document"/>
      <ownedElement xmi:id="c103d840-915a-013c-7158-0a5172f4a469" xmi:uuid="c103d970-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_Document"/>
        <text>Document</text>
      </ownedElement>
      <ownedElement xmi:id="88de1060-6c43-013d-d60b-0800270c66d6" xmi:uuid="88de10f0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="245" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185209101_156139_426914" xmi:uuid="c17ac120-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
      <ownedElement xmi:id="c1492830-915a-013c-7158-0a5172f4a469" xmi:uuid="c1492950-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
        <text>DocumentDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="8c090600-6c43-013d-d60b-0800270c66d6" xmi:uuid="8c0906a0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="356" y="245" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185212626_691365_426999" xmi:uuid="c1a587f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
      <ownedElement xmi:id="c17d4ed0-915a-013c-7158-0a5172f4a469" xmi:uuid="c17d4ff0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
        <text>DocumentVersion</text>
      </ownedElement>
      <ownedElement xmi:id="8e3c8180-6c43-013d-d60b-0800270c66d6" xmi:uuid="8e3c8250-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="647" y="245" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185213071_464139_427043" xmi:uuid="c1eb4c70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8f301ed_1516976459291_216644_31699"/>
      <ownedElement xmi:id="c1b223c0-915a-013c-7158-0a5172f4a469" xmi:uuid="c1b22570-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8f301ed_1516976459291_216644_31699"/>
        <text>EnvironmentDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="90fd5b50-6c43-013d-d60b-0800270c66d6" xmi:uuid="90fd5c30-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="938" y="245" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185213534_772455_427097" xmi:uuid="c22f9cb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517519484482_504497_34529"/>
      <ownedElement xmi:id="c1f76c30-915a-013c-7158-0a5172f4a469" xmi:uuid="c1f76e40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517519484482_504497_34529"/>
        <text>EnvironmentDefinitionVersion</text>
      </ownedElement>
      <ownedElement xmi:id="97dc61e0-6c43-013d-d60b-0800270c66d6" xmi:uuid="97dc6320-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="295" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185216630_6120_427166" xmi:uuid="c26b4010-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
      <ownedElement xmi:id="c2328a50-915a-013c-7158-0a5172f4a469" xmi:uuid="c2328ee0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
        <text>IndividualPart</text>
      </ownedElement>
      <ownedElement xmi:id="9a1a4c60-6c43-013d-d60b-0800270c66d6" xmi:uuid="9a1a4d20-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="295" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185218520_368476_427240" xmi:uuid="c295ae70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
      <ownedElement xmi:id="c26dee40-915a-013c-7158-0a5172f4a469" xmi:uuid="c26def60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
        <text>IndividualPartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="9ce20580-6c43-013d-d60b-0800270c66d6" xmi:uuid="9ce20620-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="584" y="295" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185220467_918144_427315" xmi:uuid="c2c5e890-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="c2986e20-915a-013c-7158-0a5172f4a469" xmi:uuid="c2986f30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="9f0f8530-6c43-013d-d60b-0800270c66d6" xmi:uuid="9f0f85c0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="827" y="295" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185222390_838300_427383" xmi:uuid="c31c5f50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133997057_424483_38872"/>
      <ownedElement xmi:id="c2c9c110-915a-013c-7158-0a5172f4a469" xmi:uuid="c2c9c220-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133997057_424483_38872"/>
        <text>InterfaceConnector</text>
      </ownedElement>
      <ownedElement xmi:id="a17f7ba0-6c43-013d-d60b-0800270c66d6" xmi:uuid="a17f7c40-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185224253_825814_427456" xmi:uuid="c35e5830-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134019779_950347_38878"/>
      <ownedElement xmi:id="c3200c60-915a-013c-7158-0a5172f4a469" xmi:uuid="c3200d60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134019779_950347_38878"/>
        <text>InterfaceConnectorVersion</text>
      </ownedElement>
      <ownedElement xmi:id="a6109600-6c43-013d-d60b-0800270c66d6" xmi:uuid="a6109720-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185226040_691567_427529" xmi:uuid="c3a0e110-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
      <ownedElement xmi:id="c361f840-915a-013c-7158-0a5172f4a469" xmi:uuid="c361f950-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
        <text>InterfaceConnectorView</text>
      </ownedElement>
      <ownedElement xmi:id="a9dc1500-6c43-013d-d60b-0800270c66d6" xmi:uuid="a9dc1590-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="507" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185227958_216929_427597" xmi:uuid="c3f657d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134059448_942822_38888"/>
      <ownedElement xmi:id="c3a4b240-915a-013c-7158-0a5172f4a469" xmi:uuid="c3a4b350-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134059448_942822_38888"/>
        <text>InterfaceSpecification</text>
      </ownedElement>
      <ownedElement xmi:id="ad2f4700-6c43-013d-d60b-0800270c66d6" xmi:uuid="ad2f47b0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="728" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185229787_995340_427670" xmi:uuid="c4384820-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134081745_171261_38892"/>
      <ownedElement xmi:id="c3fa09c0-915a-013c-7158-0a5172f4a469" xmi:uuid="c3fa0ad0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134081745_171261_38892"/>
        <text>InterfaceSpecificationVersion</text>
      </ownedElement>
      <ownedElement xmi:id="b0f31a20-6c43-013d-d60b-0800270c66d6" xmi:uuid="b0f31af0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="949" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185231577_564931_427742" xmi:uuid="c478b010-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
      <ownedElement xmi:id="c43c1cd0-915a-013c-7158-0a5172f4a469" xmi:uuid="c43c1e00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
        <text>InterfaceSpecificationView</text>
      </ownedElement>
      <ownedElement xmi:id="b3a62430-6c43-013d-d60b-0800270c66d6" xmi:uuid="b3a62510-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="395" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185233355_145883_427810" xmi:uuid="c53291e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1506005124993_361009_24731"/>
      <ownedElement xmi:id="c47ff4f0-915a-013c-7158-0a5172f4a469" xmi:uuid="c47ff600-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1506005124993_361009_24731"/>
        <text>Location</text>
      </ownedElement>
      <ownedElement xmi:id="b6e8eb60-6c43-013d-d60b-0800270c66d6" xmi:uuid="b6e8ec40-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="395" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185234765_503106_427874" xmi:uuid="c56b0ca0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832794448_726739_56316"/>
      <ownedElement xmi:id="c5358950-915a-013c-7158-0a5172f4a469" xmi:uuid="c5358a70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832794448_726739_56316"/>
        <text>ManagedResource</text>
      </ownedElement>
      <ownedElement xmi:id="def10450-6c43-013d-d60b-0800270c66d6" xmi:uuid="df696c80-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="581" y="395" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185235045_894648_427918" xmi:uuid="c5af5c10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8f301ed_1516977221331_943050_33189"/>
      <ownedElement xmi:id="c5776d10-915a-013c-7158-0a5172f4a469" xmi:uuid="c5776e20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8f301ed_1516977221331_943050_33189"/>
        <text>ObservedEnvironment</text>
      </ownedElement>
      <ownedElement xmi:id="ef251f90-6c43-013d-d60b-0800270c66d6" xmi:uuid="ef252060-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="813" y="395" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185235321_682506_427972" xmi:uuid="c5f4b240-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517519821879_463861_34616"/>
      <ownedElement xmi:id="c5bb9620-915a-013c-7158-0a5172f4a469" xmi:uuid="c5bb9740-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517519821879_463861_34616"/>
        <text>ObservedEnvironmentVersion</text>
      </ownedElement>
      <ownedElement xmi:id="f22e9860-6c43-013d-d60b-0800270c66d6" xmi:uuid="f22e9900-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="445" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185235449_393639_428024" xmi:uuid="c6237500-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517522422087_502748_35594"/>
      <ownedElement xmi:id="c6012590-915a-013c-7158-0a5172f4a469" xmi:uuid="c6012770-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517522422087_502748_35594"/>
        <text>ObservedEnvironmentView</text>
      </ownedElement>
      <ownedElement xmi:id="f535a8b0-6c43-013d-d60b-0800270c66d6" xmi:uuid="f535a950-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="445" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185237025_96211_428091" xmi:uuid="c6d6fc20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
      <ownedElement xmi:id="c62a41e0-915a-013c-7158-0a5172f4a469" xmi:uuid="c62a42f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
        <text>Organization</text>
      </ownedElement>
      <ownedElement xmi:id="f71292f0-6c43-013d-d60b-0800270c66d6" xmi:uuid="f71293e0-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="617" y="445" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185238379_368890_428156" xmi:uuid="c77eb470-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505750163257_414856_24072"/>
      <ownedElement xmi:id="c6de6c00-915a-013c-7158-0a5172f4a469" xmi:uuid="c6de6d10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505750163257_414856_24072"/>
        <text>OrganizationType</text>
      </ownedElement>
      <ownedElement xmi:id="fe1f94b0-6c43-013d-d60b-0800270c66d6" xmi:uuid="fe1f9560-6c43-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="912" y="445" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185240775_123255_428231" xmi:uuid="c81e7390-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
      <ownedElement xmi:id="c783cc60-915a-013c-7158-0a5172f4a469" xmi:uuid="c783cd80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
        <text>Part</text>
      </ownedElement>
      <ownedElement xmi:id="05440060-6c44-013d-d60b-0800270c66d6" xmi:uuid="05440100-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185242896_87709_428306" xmi:uuid="c88be6b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
      <ownedElement xmi:id="c823a990-915a-013c-7158-0a5172f4a469" xmi:uuid="c823aa90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
        <text>PartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="0bb1cce0-6c44-013d-d60b-0800270c66d6" xmi:uuid="0bb1ce70-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="367" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185244931_829022_428383" xmi:uuid="c8fd0c00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="c8910800-915a-013c-7158-0a5172f4a469" xmi:uuid="c8910920-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="105892c0-6c44-013d-d60b-0800270c66d6" xmi:uuid="10589320-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="669" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185246494_313041_428446" xmi:uuid="c99a6130-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
      <ownedElement xmi:id="c904a950-915a-013c-7158-0a5172f4a469" xmi:uuid="c904aa90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
        <text>Person</text>
      </ownedElement>
      <ownedElement xmi:id="155d37f0-6c44-013d-d60b-0800270c66d6" xmi:uuid="155d3890-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="971" y="495" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185248461_260333_428536" xmi:uuid="ca534120-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
      <ownedElement xmi:id="c9a188a0-915a-013c-7158-0a5172f4a469" xmi:uuid="c9a189c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
        <text>PersonInOrganization</text>
      </ownedElement>
      <ownedElement xmi:id="1b988220-6c44-013d-d60b-0800270c66d6" xmi:uuid="1b9882c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="545" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185249813_249346_428611" xmi:uuid="caf41e60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639072510862_608091_65724"/>
      <ownedElement xmi:id="ca589f50-915a-013c-7158-0a5172f4a469" xmi:uuid="ca58a060-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639072510862_608091_65724"/>
        <text>ProductGroup</text>
      </ownedElement>
      <ownedElement xmi:id="23405410-6c44-013d-d60b-0800270c66d6" xmi:uuid="234054c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="360" y="545" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185251388_656737_428681" xmi:uuid="cbb6e9a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Project"/>
      <ownedElement xmi:id="cafb2760-915a-013c-7158-0a5172f4a469" xmi:uuid="cafb2880-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Project"/>
        <text>Project</text>
      </ownedElement>
      <ownedElement xmi:id="29ff18b0-6c44-013d-d60b-0800270c66d6" xmi:uuid="29ff1950-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="662" y="545" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185252085_91773_428732" xmi:uuid="cc394f10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionAssignment"/>
      <ownedElement xmi:id="cbc2fce0-915a-013c-7158-0a5172f4a469" xmi:uuid="cbc2fe00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionAssignment"/>
        <text>PropertyDefinitionAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="32b60f10-6c44-013d-d60b-0800270c66d6" xmi:uuid="32b60fd0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="957" y="545" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185252929_922853_428795" xmi:uuid="ccda29b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueAssignment"/>
      <ownedElement xmi:id="cc44dce0-915a-013c-7158-0a5172f4a469" xmi:uuid="cc44de00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueAssignment"/>
        <text>PropertyValueAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="38354690-6c44-013d-d60b-0800270c66d6" xmi:uuid="38354760-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185254336_758619_428860" xmi:uuid="cd152eb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583829364095_153317_54200"/>
      <ownedElement xmi:id="ccdd1da0-915a-013c-7158-0a5172f4a469" xmi:uuid="ccdd1eb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583829364095_153317_54200"/>
        <text>RequiredResource</text>
      </ownedElement>
      <ownedElement xmi:id="3e67ffe0-6c44-013d-d60b-0800270c66d6" xmi:uuid="3e6800b0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="595" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185256292_703434_428929" xmi:uuid="cd5a4870-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
      <ownedElement xmi:id="cd183800-915a-013c-7158-0a5172f4a469" xmi:uuid="cd183900-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
        <text>Requirement</text>
      </ownedElement>
      <ownedElement xmi:id="40beaad0-6c44-013d-d60b-0800270c66d6" xmi:uuid="40beab70-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="573" y="595" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185258228_279865_429003" xmi:uuid="cd90b4e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
      <ownedElement xmi:id="cd5d2a60-915a-013c-7158-0a5172f4a469" xmi:uuid="cd5d2b90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
        <text>RequirementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="43bd6550-6c44-013d-d60b-0800270c66d6" xmi:uuid="43bd65f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="876" y="595" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185259652_90810_429068" xmi:uuid="cdcf2c90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583841957854_241881_57156"/>
      <ownedElement xmi:id="cd93c2d0-915a-013c-7158-0a5172f4a469" xmi:uuid="cd93c3f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583841957854_241881_57156"/>
        <text>ResourceAsRealized</text>
      </ownedElement>
      <ownedElement xmi:id="45eb91a0-6c44-013d-d60b-0800270c66d6" xmi:uuid="45eb92e0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="645" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185260828_642676_429128" xmi:uuid="ce01f660-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
      <ownedElement xmi:id="cdd241c0-915a-013c-7158-0a5172f4a469" xmi:uuid="cdd242d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
        <text>ResourceItem</text>
      </ownedElement>
      <ownedElement xmi:id="48a27c50-6c44-013d-d60b-0800270c66d6" xmi:uuid="48a27d00-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="297" y="645" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185262744_983656_429197" xmi:uuid="ce348ca0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
      <ownedElement xmi:id="ce0483c0-915a-013c-7158-0a5172f4a469" xmi:uuid="ce048500-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
        <text>Risk</text>
      </ownedElement>
      <ownedElement xmi:id="4af0f370-6c44-013d-d60b-0800270c66d6" xmi:uuid="4af0f420-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="529" y="645" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185264614_186176_429271" xmi:uuid="ce5b7e60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
      <ownedElement xmi:id="ce370420-915a-013c-7158-0a5172f4a469" xmi:uuid="ce3706b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
        <text>RiskVersion</text>
      </ownedElement>
      <ownedElement xmi:id="4cdd2480-6c44-013d-d60b-0800270c66d6" xmi:uuid="4cdd25c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="729" y="645" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185266549_192315_429340" xmi:uuid="ce888750-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
      <ownedElement xmi:id="ce5e05d0-915a-013c-7158-0a5172f4a469" xmi:uuid="ce5e06f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
        <text>Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="4e5d7910-6c44-013d-d60b-0800270c66d6" xmi:uuid="4e5d79b0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="929" y="645" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185268138_371006_429407" xmi:uuid="ceb07cf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
      <ownedElement xmi:id="ce8aaa80-915a-013c-7158-0a5172f4a469" xmi:uuid="ce8aabc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
        <text>SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="51272bf0-6c44-013d-d60b-0800270c66d6" xmi:uuid="51272df0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="695" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185270044_287173_429492" xmi:uuid="ceda4d60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
      <ownedElement xmi:id="ceb307c0-915a-013c-7158-0a5172f4a469" xmi:uuid="ceb30900-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
        <text>SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="54c99800-6c44-013d-d60b-0800270c66d6" xmi:uuid="54ed2d10-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="337" y="695" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185271986_565087_429560" xmi:uuid="cf0b57c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
      <ownedElement xmi:id="cedcae90-915a-013c-7158-0a5172f4a469" xmi:uuid="cedcafd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
        <text>Slot</text>
      </ownedElement>
      <ownedElement xmi:id="57b623c0-6c44-013d-d60b-0800270c66d6" xmi:uuid="57b62510-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="609" y="695" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185274242_878325_429628" xmi:uuid="cf3b8310-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
      <ownedElement xmi:id="cf0dc370-915a-013c-7158-0a5172f4a469" xmi:uuid="cf0dc490-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
        <text>SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="5a075380-6c44-013d-d60b-0800270c66d6" xmi:uuid="5a09e170-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="805" y="695" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185276111_424489_429713" xmi:uuid="cf613250-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
      <ownedElement xmi:id="cf3dea50-915a-013c-7158-0a5172f4a469" xmi:uuid="cf3deb60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
        <text>SlotVersion</text>
      </ownedElement>
      <ownedElement xmi:id="5c5f6b70-6c44-013d-d60b-0800270c66d6" xmi:uuid="5c5f6d00-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="1001" y="695" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185277719_157525_429780" xmi:uuid="cfb2d7a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
      <ownedElement xmi:id="cf64fe90-915a-013c-7158-0a5172f4a469" xmi:uuid="cf64ffa0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
        <text>TaskElement</text>
      </ownedElement>
      <ownedElement xmi:id="61056040-6c44-013d-d60b-0800270c66d6" xmi:uuid="6105a600-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="745" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185279934_163161_429850" xmi:uuid="d00e8ac0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
      <ownedElement xmi:id="cfb66a90-915a-013c-7158-0a5172f4a469" xmi:uuid="cfb66ba0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
        <text>TaskMethod</text>
      </ownedElement>
      <ownedElement xmi:id="693ae020-6c44-013d-d60b-0800270c66d6" xmi:uuid="693ae110-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="323" y="745" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185282105_118193_429941" xmi:uuid="d067d530-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
      <ownedElement xmi:id="d0125ec0-915a-013c-7158-0a5172f4a469" xmi:uuid="d0125fc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
        <text>TaskMethodVersion</text>
      </ownedElement>
      <ownedElement xmi:id="754f1460-6c44-013d-d60b-0800270c66d6" xmi:uuid="75564ec0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="581" y="745" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185283281_677248_430002" xmi:uuid="d09ff0e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642455582242_622357_69835"/>
      <ownedElement xmi:id="d06acfc0-915a-013c-7158-0a5172f4a469" xmi:uuid="d06ad0d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642455582242_622357_69835"/>
        <text>TypeOfPerson</text>
      </ownedElement>
      <ownedElement xmi:id="82ceba20-6c44-013d-d60b-0800270c66d6" xmi:uuid="82cebbf0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="839" y="745" width="246" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1303" height="825"/>
    <name>SchemeVersionAssignmentSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_29c0149_1617189722988_121984_14886" xmi:uuid="d196ee00-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_8e001ed_1498551965780_845924_14128"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1617190686077_649882_14924" xmi:uuid="d19ed910-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
      <ownedElement xmi:id="d19a29a0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d19a2b20-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
        <text>Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="d19b1b50-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d19b1cd0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="a5b41c60-915a-013c-7158-0a5172f4a469" xmi:uuid="a5b41d90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a5b4a140-915a-013c-7158-0a5172f4a469" xmi:uuid="a5b4a200-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="a5b6c5c0-915a-013c-7158-0a5172f4a469" xmi:uuid="a5b6c6e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485893_363243_106518"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="a5b8dc40-915a-013c-7158-0a5172f4a469" xmi:uuid="a5b8dd70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485895_968901_106519"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="a5badcc0-915a-013c-7158-0a5172f4a469" xmi:uuid="a5baddd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485896_479520_106520"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="a5bce890-915a-013c-7158-0a5172f4a469" xmi:uuid="a5bce9d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485896_80239_106521"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="a5bef950-915a-013c-7158-0a5172f4a469" xmi:uuid="a5befa60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485897_749671_106522"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="336" y="56" width="179" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617190723014_822234_14970" xmi:uuid="d1a2f140-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
      <ownedElement xmi:id="d19fe7e0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d19fe930-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
        <text>SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d1a0bcc0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1a0bde0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="a5e85bb0-915a-013c-7158-0a5172f4a469" xmi:uuid="a5e85cb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a5e8f030-915a-013c-7158-0a5172f4a469" xmi:uuid="a5e8f140-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="a5eb0c50-915a-013c-7158-0a5172f4a469" xmi:uuid="a5eb0d60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689575_515007_106625"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="a5ed0de0-915a-013c-7158-0a5172f4a469" xmi:uuid="a5ed0f00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689576_459069_106626"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="a5ef13c0-915a-013c-7158-0a5172f4a469" xmi:uuid="a5ef14d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689574_583530_106624"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="a5f14c60-915a-013c-7158-0a5172f4a469" xmi:uuid="a5f14d80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689573_79052_106623"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="a5f37bb0-915a-013c-7158-0a5172f4a469" xmi:uuid="a5f37cd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689571_972735_106622"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="339" y="252" width="179" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617192496966_583975_15073" xmi:uuid="d1a47c30-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
      <ownedElement xmi:id="d1a35b70-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1a35bf0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
        <text>SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="d1a3b150-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1a3b1c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="a619ead0-915a-013c-7158-0a5172f4a469" xmi:uuid="a619ebe0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a61a7000-915a-013c-7158-0a5172f4a469" xmi:uuid="a61a70c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="a61c8c80-915a-013c-7158-0a5172f4a469" xmi:uuid="a61c8d90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598865_325239_106576"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="a61eb1c0-915a-013c-7158-0a5172f4a469" xmi:uuid="a61eb2d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598867_453218_106577"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="a620cea0-915a-013c-7158-0a5172f4a469" xmi:uuid="a620cfb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598868_473149_106578"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="a622c890-915a-013c-7158-0a5172f4a469" xmi:uuid="a622c9b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598869_996881_106579"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="a624cf00-915a-013c-7158-0a5172f4a469" xmi:uuid="a624d020-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598870_944740_106580"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="339" y="455" width="179" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617192893245_852620_15181" xmi:uuid="d1a6d1c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192893237_274389_15179"/>
      <ownedElement xmi:id="d1a50690-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1a50700-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192893237_274389_15179"/>
        <text>SchemeSubjectAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="d1a55c20-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1a55c90-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="672" y="63" width="153" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617196081533_769063_15271" xmi:uuid="d1a7d3f0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617196081526_459916_15269"/>
      <ownedElement xmi:id="d1a730c0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1a73120-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617196081526_459916_15269"/>
        <text>SchemeSubjectAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d1a77500-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1a77560-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="d1a778d0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1a77920-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="672" y="175" width="195" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617199936027_270885_15433" xmi:uuid="d1aa7ee0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617199936020_463996_15431"/>
      <ownedElement xmi:id="d1a82a70-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1a82ae0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617199936020_463996_15431"/>
        <text>SchemeVersionAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="d1a870a0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1a87100-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="672" y="266" width="153" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617200014278_135058_15479" xmi:uuid="d1acc230-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200014271_584922_15477"/>
      <ownedElement xmi:id="d1ab9ab0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1ab9db0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200014271_584922_15477"/>
        <text>SchemeVersionAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d1ac5fa0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1ac6000-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="d1ac6490-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1ac64e0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="672" y="378" width="198" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617200446742_393322_15619" xmi:uuid="d1ae8dc0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200446735_930490_15617"/>
      <ownedElement xmi:id="d1ad1770-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1ad17d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200446735_930490_15617"/>
        <text>SchemeEntryAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="d1ad5cb0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1ad5d10-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="672" y="469" width="141" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617200521911_20350_15665" xmi:uuid="d1af9820-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200521903_877462_15663"/>
      <ownedElement xmi:id="d1aee800-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1aee860-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200521903_877462_15663"/>
        <text>SchemeEntryAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d1af2c50-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1af2cb0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="d1af2f90-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1af30a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="672" y="588" width="196" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617200734590_364143_15803" xmi:uuid="d1b16380-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200734582_937142_15801"/>
      <ownedElement xmi:id="d1afee90-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1afeef0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200734582_937142_15801"/>
        <text>SchemeRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d1b032d0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1b03330-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="ff363290-9d7f-013a-5561-0d73bd894d70" xmi:uuid="ff3633c0-9d7f-013a-5561-0d73bd894d70" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ff365dd0-9d7f-013a-5561-0d73bd894d70" xmi:uuid="ff365e70-9d7f-013a-5561-0d73bd894d70" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="ff36ccf0-9d7f-013a-5561-0d73bd894d70" xmi:uuid="ff36cda0-9d7f-013a-5561-0d73bd894d70" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_6b1022a_1649834241159_338053_68094"/>
          <text>WR1</text>
        </ownedElement>
      </ownedElement>
      <bounds x="35" y="56" width="149" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617200980414_484973_15945" xmi:uuid="d1b4d9d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200980407_188298_15943"/>
      <ownedElement xmi:id="d1b1c230-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1b1c290-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200980407_188298_15943"/>
        <text>SchemeVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d1b20750-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1b207a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="ff393af0-9d7f-013a-5561-0d73bd894d70" xmi:uuid="ff393bf0-9d7f-013a-5561-0d73bd894d70" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ff396750-9d7f-013a-5561-0d73bd894d70" xmi:uuid="ff3967f0-9d7f-013a-5561-0d73bd894d70" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="ff39f1f0-9d7f-013a-5561-0d73bd894d70" xmi:uuid="ff39f310-9d7f-013a-5561-0d73bd894d70" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_6b1022a_1649834583124_475075_68099"/>
          <text>WR1</text>
        </ownedElement>
      </ownedElement>
      <bounds x="35" y="252" width="156" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617201153294_84988_16083" xmi:uuid="d1b854f0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201153286_596027_16081"/>
      <ownedElement xmi:id="d1b5dfe0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1b5e140-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201153286_596027_16081"/>
        <text>SchemeEntryRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d1b6b490-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1b6b6b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="ff3c4ce0-9d7f-013a-5561-0d73bd894d70" xmi:uuid="ff3c4e10-9d7f-013a-5561-0d73bd894d70" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ff3c8bc0-9d7f-013a-5561-0d73bd894d70" xmi:uuid="ff3c8dd0-9d7f-013a-5561-0d73bd894d70" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="ff3d0940-9d7f-013a-5561-0d73bd894d70" xmi:uuid="ff3d0a10-9d7f-013a-5561-0d73bd894d70" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_6b1022a_1649834142620_823739_68090"/>
          <text>WR1</text>
        </ownedElement>
      </ownedElement>
      <bounds x="35" y="455" width="149" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617201320437_111316_16221" xmi:uuid="d1b9fe10-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201320430_810393_16219"/>
      <ownedElement xmi:id="d1b8bac0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1b8bb30-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201320430_810393_16219"/>
        <text>SequencingRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d1b90a60-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1b90bd0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="d1b988f0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1b98990-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d1b99d30-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1b99da0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="d1b9f880-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d1b9f8e0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617202654393_357958_67497"/>
          <text>TimeLag</text>
        </ownedElement>
        <ownedElement xmi:id="15839ca0-3397-013a-17dc-45cc4a55db9f" xmi:uuid="15839da0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624458257707_348049_80251"/>
          <text>SequencingType</text>
        </ownedElement>
      </ownedElement>
      <bounds x="35" y="574" width="177" height="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617201363250_284340_16263" xmi:uuid="d1bac7f0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201364027_146766_16264"/>
      <source xmi:idref="_18_4_1_29c0149_1617201320437_111316_16221"/>
      <target xmi:idref="_18_4_1_29c0149_1617201153294_84988_16083"/>
      <waypoint x="116" y="574"/>
      <waypoint x="116" y="524"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617722954731_658119_65263" xmi:uuid="d1bbc930-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722954683_890762_65249"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636736702584_353739_64363" xmi:uuid="15875420-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722954683_368711_65250"/>
        <bounds x="194" y="311" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617722954710_351046_65255" xmi:uuid="d1bba640-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722463205_632139_64784"/>
        <bounds x="296" y="314" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617722954711_355473_65257" xmi:uuid="d1bbbba0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722463205_632139_64784"/>
        <bounds x="322" y="294" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617200980414_484973_15945"/>
      <target xmi:idref="_18_4_1_29c0149_1617190723014_822234_14970"/>
      <waypoint x="191" y="308"/>
      <waypoint x="339" y="308"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617722956963_486694_65286" xmi:uuid="d1be4c40-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722956943_122230_65273"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636736690637_550371_64357" xmi:uuid="158b0f30-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722956943_444450_65274"/>
        <bounds x="194" y="269" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617722956950_354563_65278" xmi:uuid="d1be18b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722476853_432848_64790"/>
        <bounds x="289" y="250" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617722956950_611909_65280" xmi:uuid="d1be40c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722476853_432848_64790"/>
        <bounds x="322" y="273" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617200980414_484973_15945"/>
      <target xmi:idref="_18_4_1_29c0149_1617190723014_822234_14970"/>
      <waypoint x="191" y="266"/>
      <waypoint x="339" y="266"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617792568638_427076_62000" xmi:uuid="d1c08a70-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617792569693_892634_62001"/>
      <ownedElement xmi:id="_18_4_1_29c0149_1617792569762_604991_62011" xmi:uuid="d1c06550-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617792569693_662662_62002"/>
        <bounds x="518" y="58" width="86" height="13"/>
        <text>AssignedScheme</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617796194341_524896_62108" xmi:uuid="d1c073a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617792569693_662662_62002"/>
        <bounds x="518" y="77" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617796218075_313939_62112" xmi:uuid="d1c08600-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617792569694_391191_62003"/>
        <bounds x="645" y="77" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617192893245_852620_15181"/>
      <target xmi:idref="_18_4_1_29c0149_1617190686077_649882_14924"/>
      <waypoint x="672" y="74"/>
      <waypoint x="515" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617796172916_283335_62079" xmi:uuid="d1c183f0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617796173583_897207_62080"/>
      <ownedElement xmi:id="_18_4_1_29c0149_1617796173617_683681_62092" xmi:uuid="d1c15f00-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617796173583_599596_62081"/>
        <bounds x="708" y="147" width="59" height="13"/>
        <text>AssignedTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617796400988_794175_62120" xmi:uuid="d1c16e20-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617796173583_599596_62081"/>
        <bounds x="773" y="147" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617796576763_316341_62128" xmi:uuid="d1c17de0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617796173584_788132_62082"/>
        <bounds x="773" y="101" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617192893245_852620_15181"/>
      <target xmi:idref="_18_4_1_29c0149_1617196081533_769063_15271"/>
      <waypoint x="770" y="98"/>
      <waypoint x="770" y="175"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617799864089_448926_62457" xmi:uuid="d1c273a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799864011_423720_62444"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636736675566_294885_64351" xmi:uuid="15954ef0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799864011_170556_62445"/>
        <bounds x="187" y="115" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617799864035_456838_62449" xmi:uuid="d1c25ee0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799823948_505614_62437"/>
        <bounds x="295" y="96" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617799864036_455415_62451" xmi:uuid="d1c26e20-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799823948_505614_62437"/>
        <bounds x="322" y="119" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617200734590_364143_15803"/>
      <target xmi:idref="_18_4_1_29c0149_1617190686077_649882_14924"/>
      <waypoint x="184" y="112"/>
      <waypoint x="336" y="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617799935899_665829_62485" xmi:uuid="d1c361b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799935869_565376_62472"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636736660856_866504_64345" xmi:uuid="1598f610-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799935869_335993_62473"/>
        <bounds x="187" y="73" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617799935876_624737_62477" xmi:uuid="d1c34e80-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799924555_556213_62466"/>
        <bounds x="293" y="54" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617799935877_664541_62479" xmi:uuid="d1c35c70-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799924555_556213_62466"/>
        <bounds x="322" y="77" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617200734590_364143_15803"/>
      <target xmi:idref="_18_4_1_29c0149_1617190686077_649882_14924"/>
      <waypoint x="184" y="70"/>
      <waypoint x="336" y="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617809732588_387538_68853" xmi:uuid="d1c46fe0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809732361_478196_68840"/>
      <ownedElement xmi:id="_18_4_1_29c0149_1617809779543_558311_68864" xmi:uuid="d1c43ab0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809732367_231916_68841"/>
        <bounds x="645" y="283" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617809732513_513766_68845" xmi:uuid="d1c44a40-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809683211_399922_68829"/>
        <bounds x="521" y="264" width="123" height="13"/>
        <text>AssignedSchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617809732514_968406_68847" xmi:uuid="d1c46b60-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809683211_399922_68829"/>
        <bounds x="521" y="283" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617199936027_270885_15433"/>
      <target xmi:idref="_18_4_1_29c0149_1617190723014_822234_14970"/>
      <waypoint x="672" y="280"/>
      <waypoint x="518" y="280"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617809915484_667372_68932" xmi:uuid="d1c57320-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809915348_179616_68878"/>
      <ownedElement xmi:id="_18_4_1_29c0149_1617810195746_55231_68949" xmi:uuid="d1c55220-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809915348_373648_68879"/>
        <bounds x="773" y="304" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617809915450_458056_68883" xmi:uuid="d1c56060-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809804202_981043_68868"/>
        <bounds x="708" y="350" width="59" height="13"/>
        <text>AssignedTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617809915451_607853_68885" xmi:uuid="d1c56f50-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809804202_981043_68868"/>
        <bounds x="773" y="350" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617199936027_270885_15433"/>
      <target xmi:idref="_18_4_1_29c0149_1617200014278_135058_15479"/>
      <waypoint x="770" y="301"/>
      <waypoint x="770" y="378"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617815159942_447089_69165" xmi:uuid="d1c64460-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815159864_43626_69152"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636736715368_789842_64369" xmi:uuid="15a25530-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815159864_453856_69153"/>
        <bounds x="187" y="521" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617815159872_31342_69157" xmi:uuid="d1c63340-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815130629_845371_69131"/>
        <bounds x="301" y="525" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617815159873_867502_69159" xmi:uuid="d1c640a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815130629_845371_69131"/>
        <bounds x="315" y="497" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617201153294_84988_16083"/>
      <target xmi:idref="_18_4_1_29c0149_1617192496966_583975_15073"/>
      <waypoint x="184" y="518"/>
      <waypoint x="339" y="518"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617815161674_308472_69187" xmi:uuid="d1c71890-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815161643_966892_69174"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636736724975_766777_64375" xmi:uuid="15a5c390-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815161643_561844_69175"/>
        <bounds x="187" y="469" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617815161650_314564_69179" xmi:uuid="d1c704a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815146464_732962_69141"/>
        <bounds x="287" y="448" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617815161651_398580_69181" xmi:uuid="d1c714d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815146464_732962_69141"/>
        <bounds x="315" y="476" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617201153294_84988_16083"/>
      <target xmi:idref="_18_4_1_29c0149_1617192496966_583975_15073"/>
      <waypoint x="184" y="466"/>
      <waypoint x="339" y="466"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617816153235_578495_69858" xmi:uuid="d1c817c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816153206_833025_69845"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636736737825_439958_64381" xmi:uuid="15a8abd0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816153206_318175_69846"/>
        <bounds x="645" y="490" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617816153214_814760_69850" xmi:uuid="d1c7f560-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816078934_387924_69824"/>
        <bounds x="521" y="471" width="72" height="13"/>
        <text>AssignedEntry</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617816153216_50701_69852" xmi:uuid="d1c813e0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816078934_387924_69824"/>
        <bounds x="521" y="490" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617200446742_393322_15619"/>
      <target xmi:idref="_18_4_1_29c0149_1617192496966_583975_15073"/>
      <waypoint x="672" y="487"/>
      <waypoint x="518" y="487"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617816155586_426567_69880" xmi:uuid="d1c91100-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816155569_710471_69867"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636736756879_347183_64387" xmi:uuid="15ab7400-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816155569_753592_69868"/>
        <bounds x="770" y="507" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617816155576_136498_69872" xmi:uuid="d1c8ece0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816121645_790139_69834"/>
        <bounds x="705" y="560" width="59" height="13"/>
        <text>AssignedTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617816155577_78916_69874" xmi:uuid="d1c90b80-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816121645_790139_69834"/>
        <bounds x="770" y="560" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617200446742_393322_15619"/>
      <target xmi:idref="_18_4_1_29c0149_1617200521911_20350_15665"/>
      <waypoint x="767" y="504"/>
      <waypoint x="767" y="588"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624443439718_756638_72320" xmi:uuid="d4df85d0-76ca-013a-5bfe-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618428547866_752091_71012"/>
      <ownedElement xmi:id="_18_4_1_29c0149_1624443439665_532704_72314" xmi:uuid="15ae50f0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618428440980_200780_70985"/>
        <bounds x="362" y="236" width="44" height="13"/>
        <text>Versions</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1624443439666_290169_72316" xmi:uuid="15aebff0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618428440980_200780_70985"/>
        <bounds x="412" y="236" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617190686077_649882_14924"/>
      <target xmi:idref="_18_4_1_29c0149_1617190723014_822234_14970"/>
      <waypoint x="409" y="189"/>
      <waypoint x="409" y="252"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624443461696_799056_72339" xmi:uuid="d4e0ab50-76ca-013a-5bfe-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618430117670_907942_71685"/>
      <ownedElement xmi:id="_18_4_1_29c0149_1624443461660_921809_72333" xmi:uuid="15b0e580-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618430100054_408411_71660"/>
        <bounds x="371" y="439" width="35" height="13"/>
        <text>Entries</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1624443461661_703425_72335" xmi:uuid="15b155a0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618430100054_408411_71660"/>
        <bounds x="412" y="439" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_29c0149_1617190723014_822234_14970"/>
      <target xmi:idref="_18_4_1_29c0149_1617192496966_583975_15073"/>
      <waypoint x="409" y="385"/>
      <waypoint x="409" y="455"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="885" height="671"/>
    <name>PlanningScheduling</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446301032_895633_285899" xmi:uuid="1254fb00-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200446735_930490_15617"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301055_987416_285931" xmi:uuid="134b90e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423344478_850429_69063"/>
      <ownedElement xmi:id="13176350-6c45-013d-d60b-0800270c66d6" xmi:uuid="13176430-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423344478_850429_69063"/>
        <text>assign:Scheme_entry_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="134713e0-6c45-013d-d60b-0800270c66d6" xmi:uuid="134715d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423344478_850429_69063"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="218" height="610"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301070_123544_285965" xmi:uuid="135b01a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="615" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301080_388941_285980" xmi:uuid="136ef3a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="615" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301095_381883_285995" xmi:uuid="13860440-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="615" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301105_20836_286010" xmi:uuid="13a24d30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="615" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301116_77423_286025" xmi:uuid="13b4cd80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="615" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301131_785823_286040" xmi:uuid="13cec2d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="615" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301141_422955_286055" xmi:uuid="13e18a90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="615" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301150_377814_286070" xmi:uuid="13fd4710-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1529866794283_1220_39337"/>
      <bounds x="615" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301161_307416_286085" xmi:uuid="140e9e90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="615" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301170_560876_286100" xmi:uuid="14101230-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="615" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301184_166033_286115" xmi:uuid="14429500-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="615" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301197_205300_286130" xmi:uuid="14616bb0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="615" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301211_718859_286145" xmi:uuid="146339c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="615" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301225_227345_286160" xmi:uuid="1481d700-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="615" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301233_761678_286175" xmi:uuid="1495fc90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="615" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301243_418504_286190" xmi:uuid="14be4230-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="615" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301253_353633_286205" xmi:uuid="14cfb980-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="615" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301262_482538_286220" xmi:uuid="14e3f260-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="615" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301277_722363_286235" xmi:uuid="14f64140-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="615" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301293_95241_286250" xmi:uuid="150ea690-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="615" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301308_83025_286265" xmi:uuid="151f93a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="615" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301318_350531_286280" xmi:uuid="1548a310-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="615" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301333_847127_286295" xmi:uuid="155390c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="615" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301343_991593_286310" xmi:uuid="15711f80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="615" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301353_557408_286325" xmi:uuid="157d8960-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="615" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301365_578924_286340" xmi:uuid="158717b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="615" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301375_424693_286355" xmi:uuid="159ca4d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="615" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301385_496483_286370" xmi:uuid="15b06850-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="615" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_912748_402611" xmi:uuid="15b092c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397867_161545_255746"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301070_123544_285965"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="62"/>
      <waypoint x="263" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_515469_402614" xmi:uuid="15b0a600-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397952_309711_255762"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301080_388941_285980"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="82"/>
      <waypoint x="263" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_365232_402617" xmi:uuid="15b0b410-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398032_50648_255778"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301095_381883_285995"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="102"/>
      <waypoint x="263" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_889643_402620" xmi:uuid="15b0c190-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398114_188460_255794"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301105_20836_286010"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="122"/>
      <waypoint x="263" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_43100_402623" xmi:uuid="15c4d360-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398191_356590_255810"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301116_77423_286025"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="142"/>
      <waypoint x="263" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_937441_402626" xmi:uuid="15c4dd90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398270_858432_255826"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301131_785823_286040"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="162"/>
      <waypoint x="263" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_380334_402629" xmi:uuid="15c4e450-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398355_11841_255842"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301141_422955_286055"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="182"/>
      <waypoint x="263" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_764496_402632" xmi:uuid="15c4ec10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398431_497552_255858"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301150_377814_286070"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="202"/>
      <waypoint x="263" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_688294_402635" xmi:uuid="15c4f320-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398506_211508_255874"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301161_307416_286085"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="222"/>
      <waypoint x="263" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_291529_402638" xmi:uuid="15c4f940-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398591_121089_255890"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301170_560876_286100"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="242"/>
      <waypoint x="263" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_722601_402641" xmi:uuid="15c50290-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398676_625251_255906"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301184_166033_286115"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="262"/>
      <waypoint x="263" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_852034_402644" xmi:uuid="15c50c60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398839_859196_255938"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301197_205300_286130"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="282"/>
      <waypoint x="263" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_190505_402647" xmi:uuid="15c51bf0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398917_840701_255954"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301211_718859_286145"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="302"/>
      <waypoint x="263" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_235917_402650" xmi:uuid="15c52660-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601398999_167850_255970"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301225_227345_286160"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="322"/>
      <waypoint x="263" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_243810_402653" xmi:uuid="15c52f50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601399081_436267_255986"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301233_761678_286175"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="342"/>
      <waypoint x="263" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_896244_402656" xmi:uuid="15c538d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601399158_416012_256002"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301243_418504_286190"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="362"/>
      <waypoint x="263" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_708282_402659" xmi:uuid="15c54290-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601399237_939061_256018"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301253_353633_286205"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="382"/>
      <waypoint x="263" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_665746_402662" xmi:uuid="15c54bf0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601399317_290693_256034"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301262_482538_286220"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="402"/>
      <waypoint x="263" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_401702_402665" xmi:uuid="15c581e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601399396_604787_256050"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301277_722363_286235"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="422"/>
      <waypoint x="263" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_66136_402668" xmi:uuid="15c590e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601399480_763022_256066"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301293_95241_286250"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="442"/>
      <waypoint x="263" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_120938_402671" xmi:uuid="15c599f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601399728_328925_256114"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301308_83025_286265"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="462"/>
      <waypoint x="263" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_16391_402674" xmi:uuid="15c5a120-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601399813_327252_256130"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301318_350531_286280"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="482"/>
      <waypoint x="263" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496729_574269_402677" xmi:uuid="15c5b1a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601399892_540551_256146"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301333_847127_286295"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="502"/>
      <waypoint x="263" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496730_570332_402680" xmi:uuid="15c5bbc0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601399976_439254_256162"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301343_991593_286310"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="522"/>
      <waypoint x="263" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496730_898974_402683" xmi:uuid="15c5c3b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400057_645370_256178"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301353_557408_286325"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="542"/>
      <waypoint x="263" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496730_837606_402686" xmi:uuid="15c5cb10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400136_862937_256194"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301365_578924_286340"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="562"/>
      <waypoint x="263" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496730_245484_402689" xmi:uuid="15c5d1f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400217_812376_256210"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301375_424693_286355"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="582"/>
      <waypoint x="263" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496730_798619_402692" xmi:uuid="15c5d9f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400296_668756_256226"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301385_496483_286370"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301055_987416_285931"/>
      <waypoint x="615" y="602"/>
      <waypoint x="263" y="602"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="618" height="680"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446298892_269869_283061" xmi:uuid="19fd4e80-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200734582_937142_15801"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298914_605486_283093" xmi:uuid="1acc2210-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423937148_833783_69368"/>
      <ownedElement xmi:id="1ab6c820-6c46-013d-d60b-0800270c66d6" xmi:uuid="1ab6c900-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423937148_833783_69368"/>
        <text>relate:Scheme_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="1acc0d60-6c46-013d-d60b-0800270c66d6" xmi:uuid="1acc0e30-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423937148_833783_69368"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="180" height="370"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298929_552810_283127" xmi:uuid="1adccb00-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="524" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298943_902959_283142" xmi:uuid="1ae5d580-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="524" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298957_610146_283157" xmi:uuid="1af08e80-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="524" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298968_380023_283172" xmi:uuid="1b02cf20-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="524" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298977_930918_283187" xmi:uuid="1b0413f0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="524" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298990_845322_283202" xmi:uuid="1b2140e0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="524" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299004_188058_283217" xmi:uuid="1b2c28c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="524" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299018_812788_283232" xmi:uuid="1b3a3920-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="524" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299032_394374_283247" xmi:uuid="1b46af50-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="524" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299041_803311_283262" xmi:uuid="1b540810-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="524" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299056_46139_283277" xmi:uuid="1b7bb7e0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="524" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299071_78713_283292" xmi:uuid="1b931cf0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="524" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299085_497658_283307" xmi:uuid="1b945730-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="524" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299095_658604_283322" xmi:uuid="1ba4e310-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="524" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299109_879250_283337" xmi:uuid="1bb935c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="524" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299120_578547_283352" xmi:uuid="1bba8510-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="524" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_835450_402119" xmi:uuid="1bcb2ad0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400407_134149_256305"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298929_552810_283127"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="62"/>
      <waypoint x="225" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_405752_402122" xmi:uuid="1bcb36d0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400572_523945_256337"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298943_902959_283142"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="82"/>
      <waypoint x="225" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_60801_402125" xmi:uuid="1bcb4040-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400656_804736_256353"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298957_610146_283157"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="102"/>
      <waypoint x="225" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_611002_402128" xmi:uuid="1bcb4a00-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400738_809006_256369"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298968_380023_283172"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="122"/>
      <waypoint x="225" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_971415_402131" xmi:uuid="1bcb5790-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400815_445827_256385"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298977_930918_283187"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="142"/>
      <waypoint x="225" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_474616_402134" xmi:uuid="1bcb6620-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400889_366870_256401"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298990_845322_283202"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="162"/>
      <waypoint x="225" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_150151_402137" xmi:uuid="1bcb7470-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601400973_467906_256417"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299004_188058_283217"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="182"/>
      <waypoint x="225" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_150415_402140" xmi:uuid="1bcb8370-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401056_237952_256433"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299018_812788_283232"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="202"/>
      <waypoint x="225" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_166831_402143" xmi:uuid="1bcb9240-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401141_456083_256449"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299032_394374_283247"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="222"/>
      <waypoint x="225" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_983491_402146" xmi:uuid="1bcb9e00-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401224_735893_256465"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299041_803311_283262"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="242"/>
      <waypoint x="225" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_344638_402149" xmi:uuid="1bcbb2a0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401302_417620_256481"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299056_46139_283277"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="262"/>
      <waypoint x="225" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_353776_402152" xmi:uuid="1bcbbf40-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401386_307915_256497"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299071_78713_283292"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="282"/>
      <waypoint x="225" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_423737_402155" xmi:uuid="1bcbd310-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401470_767284_256513"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299085_497658_283307"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="302"/>
      <waypoint x="225" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_859267_402158" xmi:uuid="1bcbe5c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401555_645170_256529"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299095_658604_283322"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="322"/>
      <waypoint x="225" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_818760_402161" xmi:uuid="1bcbf260-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401635_562702_256545"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299109_879250_283337"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="342"/>
      <waypoint x="225" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496634_354418_402164" xmi:uuid="1bcc0150-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401719_43093_256561"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299120_578547_283352"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298914_605486_283093"/>
      <waypoint x="524" y="362"/>
      <waypoint x="225" y="362"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="527" height="440"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1620220113860_255580_66203" xmi:uuid="2f55f830-9071-0139-a9e5-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201320430_810393_16219"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1624454004235_394377_75230" xmi:uuid="18bf08e0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624454004226_496324_75226"/>
      <bounds x="748" y="83" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624457121347_482844_80027" xmi:uuid="196661c0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624457122562_188609_80028"/>
      <source xmi:idref="_18_4_1_29c0149_1624458637573_131462_80513"/>
      <target xmi:idref="_18_4_1_29c0149_1624454563196_890236_75264"/>
      <waypoint x="217" y="126"/>
      <waypoint x="378" y="126"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624457929145_449384_80095" xmi:uuid="1966ce20-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624457931310_518582_80096"/>
      <source xmi:idref="_18_4_1_29c0149_1624457734487_922554_80061"/>
      <target xmi:idref="_18_4_1_29c0149_1624454828906_504851_75295"/>
      <waypoint x="347" y="158"/>
      <waypoint x="378" y="158"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624453821833_393341_75110" xmi:uuid="d65529f0-76ca-013a-5bfe-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624453821736_313177_75109"/>
      <ownedElement xmi:id="18da8230-3397-013a-17dc-45cc4a55db9f" xmi:uuid="18da8320-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624453821736_313177_75109"/>
        <text>seqRel:Sequencing_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="18dbbbf0-3397-013a-17dc-45cc4a55db9f" xmi:uuid="18dbbcb0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624453821736_313177_75109"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="c31d0810-6c45-013d-d60b-0800270c66d6" xmi:uuid="c31d08a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c32c1430-6c45-013d-d60b-0800270c66d6" xmi:uuid="c32c1500-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1624454563196_890236_75264" xmi:uuid="192eb080-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Sequencing_relationship-time_lag"/>
          <ownedElement xmi:id="19123240-3397-013a-17dc-45cc4a55db9f" xmi:uuid="19123310-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Sequencing_relationship-time_lag"/>
            <text>time_lag:Time_interval</text>
          </ownedElement>
          <ownedElement xmi:id="192e40b0-3397-013a-17dc-45cc4a55db9f" xmi:uuid="192e41d0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Sequencing_relationship-time_lag"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="378" y="112" width="173" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1624454828906_504851_75295" xmi:uuid="1965f290-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Sequencing_relationship-sequencing_type"/>
          <ownedElement xmi:id="194a7d90-3397-013a-17dc-45cc4a55db9f" xmi:uuid="194a7e50-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Sequencing_relationship-sequencing_type"/>
            <text>sequencing_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="196574e0-3397-013a-17dc-45cc4a55db9f" xmi:uuid="196575c0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Sequencing_relationship-sequencing_type"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="378" y="147" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="371" y="84" width="301" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624454108030_164195_75253" xmi:uuid="d65534b0-76ca-013a-5bfe-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624454109837_671211_75254"/>
      <source xmi:idref="_18_4_1_29c0149_1624453821833_393341_75110"/>
      <target xmi:idref="_18_4_1_29c0149_1624454004235_394377_75230"/>
      <waypoint x="672" y="91"/>
      <waypoint x="748" y="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624454863214_985095_75366" xmi:uuid="d6553a10-76ca-013a-5bfe-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_29c0149_1617823883572_914156_76490"/>
      <bounds x="301" y="21" width="154" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624457734487_922554_80061" xmi:uuid="d6566600-76ca-013a-5bfe-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624457734480_646631_80059"/>
      <ownedElement xmi:id="19682130-3397-013a-17dc-45cc4a55db9f" xmi:uuid="196821e0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624457734480_646631_80059"/>
        <text>type:String</text>
      </ownedElement>
      <ownedElement xmi:id="196951f0-3397-013a-17dc-45cc4a55db9f" xmi:uuid="196952b0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624457734480_646631_80059"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="147" y="147" width="200" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624458142792_664170_80145" xmi:uuid="19d5e370-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624458143420_107574_80146"/>
      <source xmi:idref="_18_4_1_29c0149_1624453821833_393341_75110"/>
      <target xmi:idref="_18_4_1_29c0149_1624458208310_841479_80183"/>
      <waypoint x="658" y="182"/>
      <waypoint x="658" y="256"/>
      <waypoint x="506" y="256"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624458101133_313747_80110" xmi:uuid="d6816bf0-76ca-013a-5bfe-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624458101128_531100_80108"/>
      <ownedElement xmi:id="1983efe0-3397-013a-17dc-45cc4a55db9f" xmi:uuid="1983f0f0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624458101128_531100_80108"/>
        <text>sequenceTypeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="19851b30-3397-013a-17dc-45cc4a55db9f" xmi:uuid="19851be0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624458101128_531100_80108"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="c6d7ab90-6c45-013d-d60b-0800270c66d6" xmi:uuid="c6d7ac60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c6e12a70-6c45-013d-d60b-0800270c66d6" xmi:uuid="c6e12c10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1624458208310_841479_80183" xmi:uuid="19d570f0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="19b88cc0-3397-013a-17dc-45cc4a55db9f" xmi:uuid="19b88d90-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="19d4ea90-3397-013a-17dc-45cc4a55db9f" xmi:uuid="19d4eb90-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="322" y="245" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="315" y="217" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624458257712_263542_80253" xmi:uuid="d69fca70-76ca-013a-5bfe-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624458257707_348049_80251"/>
      <ownedElement xmi:id="1a1ee520-3397-013a-17dc-45cc4a55db9f" xmi:uuid="1a1ee5f0-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624458257707_348049_80251"/>
        <text>SequencingType:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="1a2050a0-3397-013a-17dc-45cc4a55db9f" xmi:uuid="1a205170-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624458257707_348049_80251"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1624458316478_125337_80447" xmi:uuid="1a20cf30-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="c967c680-6c45-013d-d60b-0800270c66d6" xmi:uuid="c967c760-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="105" y="216" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="237" y="241" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="238" width="224" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624458333273_769636_80466" xmi:uuid="d69fd3e0-76ca-013a-5bfe-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624458334819_521607_80467"/>
      <source xmi:idref="_18_4_1_29c0149_1624458101133_313747_80110"/>
      <target xmi:idref="_18_4_1_29c0149_1624458316478_125337_80447"/>
      <waypoint x="315" y="249"/>
      <waypoint x="252" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1624458614114_987416_80482" xmi:uuid="d6a9c5e0-76ca-013a-5bfe-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617202654393_357958_67497"/>
      <ownedElement xmi:id="1a377280-3397-013a-17dc-45cc4a55db9f" xmi:uuid="1a377350-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617202654393_357958_67497"/>
        <text>TimeLag:TimeInterval</text>
      </ownedElement>
      <ownedElement xmi:id="1a389fc0-3397-013a-17dc-45cc4a55db9f" xmi:uuid="1a38a080-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617202654393_357958_67497"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1624458637573_131462_80513" xmi:uuid="1a393750-3397-013a-17dc-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570638347483_759313_50189"/>
        <ownedElement xmi:id="cac496f0-6c45-013d-d60b-0800270c66d6" xmi:uuid="cac497b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570638347483_759313_50189"/>
          <bounds x="220" y="107" width="146" height="13"/>
          <text>timeInterval : Time_interval [1]</text>
        </ownedElement>
        <bounds x="202" y="116" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="112" width="189" height="25"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="751" height="296"/>
    <name>SequencingRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446297944_706856_281854" xmi:uuid="3d117f30-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617199936020_463996_15431"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446297989_792705_281887" xmi:uuid="3dd15890-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618422373495_522723_68956"/>
      <ownedElement xmi:id="3db48370-6c46-013d-d60b-0800270c66d6" xmi:uuid="3db48450-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618422373495_522723_68956"/>
        <text>assign:Scheme_version_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="3dd144a0-6c46-013d-d60b-0800270c66d6" xmi:uuid="3dd14560-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618422373495_522723_68956"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="230" height="610"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298006_816791_281921" xmi:uuid="3ddd2bf0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="608" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298016_3897_281936" xmi:uuid="3dea0020-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="608" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298030_871813_281951" xmi:uuid="3debea40-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="608" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298038_200954_281966" xmi:uuid="3ded6d40-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="608" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298049_784441_281981" xmi:uuid="3e1351e0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="608" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298064_51464_281996" xmi:uuid="3e1f8a30-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="608" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298073_837150_282011" xmi:uuid="3e2eed80-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="608" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298081_670303_282026" xmi:uuid="3e3a9aa0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1529866794283_1220_39337"/>
      <bounds x="608" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298092_81688_282041" xmi:uuid="3e595c30-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="608" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298101_419121_282056" xmi:uuid="3e5aa440-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="608" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298115_385999_282071" xmi:uuid="3e6fd360-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="608" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298129_464939_282086" xmi:uuid="3e710c20-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="608" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298144_426468_282101" xmi:uuid="3e8000f0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="608" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298158_612251_282116" xmi:uuid="3e9a61e0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="608" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298167_246802_282131" xmi:uuid="3ea832b0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="608" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298176_521973_282146" xmi:uuid="3eb79d60-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="608" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298186_506114_282161" xmi:uuid="3ebf7840-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="608" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298197_794460_282176" xmi:uuid="3ec0c200-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="608" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298214_494892_282191" xmi:uuid="3ed59940-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="608" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298230_763620_282206" xmi:uuid="3edbe800-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="608" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298244_772625_282221" xmi:uuid="3edd36f0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="608" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298253_144049_282236" xmi:uuid="3efe6000-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="608" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298267_161102_282251" xmi:uuid="3f0a7810-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="608" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298318_858740_282266" xmi:uuid="3f197d20-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="608" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298328_270895_282281" xmi:uuid="3f1b2050-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="608" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298338_714082_282296" xmi:uuid="3f1c7540-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="608" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298349_624969_282311" xmi:uuid="3f437770-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="608" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298358_891114_282326" xmi:uuid="3f480720-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="608" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_448588_401903" xmi:uuid="3f481c10-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411024_333571_258635"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298006_816791_281921"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="62"/>
      <waypoint x="275" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_55749_401906" xmi:uuid="3f482490-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411146_393795_258651"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298016_3897_281936"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="82"/>
      <waypoint x="275" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_246854_401909" xmi:uuid="3f482cd0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411296_231523_258667"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298030_871813_281951"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="102"/>
      <waypoint x="275" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_354564_401912" xmi:uuid="3f4835b0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411390_798429_258683"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298038_200954_281966"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="122"/>
      <waypoint x="275" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_513408_401915" xmi:uuid="3f562c30-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411472_204033_258699"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298049_784441_281981"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="142"/>
      <waypoint x="275" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_784212_401918" xmi:uuid="3f563710-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411553_653223_258715"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298064_51464_281996"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="162"/>
      <waypoint x="275" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_256737_401921" xmi:uuid="3f563ea0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411637_543952_258731"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298073_837150_282011"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="182"/>
      <waypoint x="275" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_238618_401924" xmi:uuid="3f564630-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411718_225074_258747"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298081_670303_282026"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="202"/>
      <waypoint x="275" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_269918_401927" xmi:uuid="3f564d30-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411797_914345_258763"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298092_81688_282041"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="222"/>
      <waypoint x="275" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_589246_401930" xmi:uuid="3f565780-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411877_276581_258779"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298101_419121_282056"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="242"/>
      <waypoint x="275" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_148458_401933" xmi:uuid="3f565f80-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601411952_161965_258795"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298115_385999_282071"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="262"/>
      <waypoint x="275" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_543851_401936" xmi:uuid="3f566710-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601412115_380729_258827"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298129_464939_282086"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="282"/>
      <waypoint x="275" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_170776_401939" xmi:uuid="3f566da0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601412199_228320_258843"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298144_426468_282101"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="302"/>
      <waypoint x="275" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_799853_401942" xmi:uuid="3f5674d0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601412286_225198_258859"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298158_612251_282116"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="322"/>
      <waypoint x="275" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_97500_401945" xmi:uuid="3f567bb0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601412369_828543_258875"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298167_246802_282131"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="342"/>
      <waypoint x="275" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_709809_401948" xmi:uuid="3f5682c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601412450_474053_258891"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298176_521973_282146"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="362"/>
      <waypoint x="275" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_91438_401951" xmi:uuid="3f5689b0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601412530_435356_258907"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298186_506114_282161"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="382"/>
      <waypoint x="275" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_977225_401954" xmi:uuid="3f569210-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601412610_843568_258923"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298197_794460_282176"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="402"/>
      <waypoint x="275" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_612492_401957" xmi:uuid="3f5698e0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601412691_367011_258939"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298214_494892_282191"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="422"/>
      <waypoint x="275" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_29276_401960" xmi:uuid="3f56a050-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601412779_51090_258955"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298230_763620_282206"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="442"/>
      <waypoint x="275" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_376171_401963" xmi:uuid="3f56a6f0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413025_299131_259003"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298244_772625_282221"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="462"/>
      <waypoint x="275" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_142597_401966" xmi:uuid="3f56adc0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413108_985763_259019"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298253_144049_282236"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="482"/>
      <waypoint x="275" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_965304_401969" xmi:uuid="3f56b4a0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413187_322804_259035"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298267_161102_282251"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="502"/>
      <waypoint x="275" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_337025_401972" xmi:uuid="3f56bb20-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413271_224256_259051"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298318_858740_282266"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="522"/>
      <waypoint x="275" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_995969_401975" xmi:uuid="3f56c240-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413352_344693_259067"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298328_270895_282281"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="542"/>
      <waypoint x="275" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_692583_401978" xmi:uuid="3f56c980-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413432_200394_259083"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298338_714082_282296"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="562"/>
      <waypoint x="275" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_513892_401981" xmi:uuid="3f56d0b0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413509_950615_259099"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298349_624969_282311"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="582"/>
      <waypoint x="275" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496596_513718_401984" xmi:uuid="3f56d770-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413586_339033_259115"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298358_891114_282326"/>
      <target xmi:idref="_18_4_1_65b021e_1727446297989_792705_281887"/>
      <waypoint x="608" y="602"/>
      <waypoint x="275" y="602"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="611" height="680"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446299714_911578_284150" xmi:uuid="56cce260-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299738_130325_284182" xmi:uuid="57d62f90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618418461624_866716_67608"/>
      <ownedElement xmi:id="57af8250-6c45-013d-d60b-0800270c66d6" xmi:uuid="57af8310-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618418461624_866716_67608"/>
        <text>theSchemeVersion:Scheme_version</text>
      </ownedElement>
      <ownedElement xmi:id="57d61b90-6c45-013d-d60b-0800270c66d6" xmi:uuid="57d61d20-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618418461624_866716_67608"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="226" height="930"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299754_997289_284216" xmi:uuid="57e40690-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="615" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299764_834117_284231" xmi:uuid="57faa4a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_13110319_1585036997439_273570_58540"/>
      <bounds x="615" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299780_456615_284246" xmi:uuid="580b2e70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="615" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299789_570323_284261" xmi:uuid="581bfe90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551689215050_535893_40191"/>
      <bounds x="615" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299797_535739_284276" xmi:uuid="581dbb70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="615" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299806_960567_284291" xmi:uuid="581f77c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="615" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299822_467982_284306" xmi:uuid="584f69b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="615" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299832_597934_284321" xmi:uuid="58704ea0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="615" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299843_498594_284336" xmi:uuid="58949f50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="615" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299852_432306_284351" xmi:uuid="58a57640-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="615" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299866_608392_284366" xmi:uuid="58b698c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="615" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299874_431530_284381" xmi:uuid="58cc2bf0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642527069326_238058_76283"/>
      <bounds x="615" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299888_785453_284396" xmi:uuid="58da3a80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="615" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299901_169060_284411" xmi:uuid="58f53fd0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="615" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299910_138160_284426" xmi:uuid="5907a3f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1540915512831_719143_31709"/>
      <bounds x="615" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299923_824792_284441" xmi:uuid="5925e7f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="615" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299934_22564_284456" xmi:uuid="59338970-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="615" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299942_329227_284471" xmi:uuid="5945c430-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="615" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299954_676379_284486" xmi:uuid="5956f570-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="615" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299965_33416_284501" xmi:uuid="596ae230-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="615" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299974_592313_284516" xmi:uuid="598be9d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="615" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299990_196921_284531" xmi:uuid="599ebe90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="615" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300006_53243_284546" xmi:uuid="59d51780-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="615" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300017_773872_284561" xmi:uuid="5a00a940-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="615" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300026_216177_284576" xmi:uuid="5a1aa8c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1540916564417_774412_33192"/>
      <bounds x="615" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300041_885426_284591" xmi:uuid="5a2845c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="615" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300050_742971_284606" xmi:uuid="5a376740-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="615" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300065_109794_284621" xmi:uuid="5a4cb930-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="615" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300073_902505_284636" xmi:uuid="5a681530-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583916459359_231472_65084"/>
      <bounds x="615" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300122_334670_284651" xmi:uuid="5a8886d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="615" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300135_27096_284666" xmi:uuid="5a9c6ce0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="615" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300147_609389_284681" xmi:uuid="5abe43a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
      <bounds x="615" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300158_208208_284696" xmi:uuid="5ada7860-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
      <bounds x="615" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300167_835235_284711" xmi:uuid="5ae9b270-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828862325_997404_79169"/>
      <bounds x="615" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300177_722435_284726" xmi:uuid="5aeb8170-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="615" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300186_543943_284741" xmi:uuid="5b137a80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="615" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300198_244857_284756" xmi:uuid="5b25ed40-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="615" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300209_660059_284771" xmi:uuid="5b373c30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="615" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300219_836374_284786" xmi:uuid="5b56a820-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="615" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300230_418066_284801" xmi:uuid="5b7f02c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="615" y="835" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300242_684902_284816" xmi:uuid="5b92e9e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="615" y="855" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300251_327354_284831" xmi:uuid="5ba2c5a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570204497794_443467_105732"/>
      <bounds x="615" y="875" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300259_884183_284846" xmi:uuid="5bb68b80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577962989407_4853_51636"/>
      <bounds x="615" y="895" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300269_736543_284861" xmi:uuid="5bcc20e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="615" y="915" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_964460_402299" xmi:uuid="5bcc3b80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661762_184447_269807"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299754_997289_284216"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="62"/>
      <waypoint x="271" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_752112_402302" xmi:uuid="5bcc47c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1662739482380_60658_69326"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299764_834117_284231"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="82"/>
      <waypoint x="271" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_440588_402305" xmi:uuid="5bcc5250-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661856_353736_269838"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299780_456615_284246"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="102"/>
      <waypoint x="271" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_596590_402308" xmi:uuid="5bcc5de0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661939_419974_269854"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299789_570323_284261"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="122"/>
      <waypoint x="271" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_260252_402311" xmi:uuid="5bcc67f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662018_509408_269870"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299797_535739_284276"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="142"/>
      <waypoint x="271" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_445552_402314" xmi:uuid="5bcc7390-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662093_621199_269886"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299806_960567_284291"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="162"/>
      <waypoint x="271" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_450867_402317" xmi:uuid="5bcc7d30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662169_318355_269902"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299822_467982_284306"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="182"/>
      <waypoint x="271" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_92554_402320" xmi:uuid="5bcc8690-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662255_931495_269918"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299832_597934_284321"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="202"/>
      <waypoint x="271" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_254394_402323" xmi:uuid="5bcc8ee0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662329_125895_269934"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299843_498594_284336"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="222"/>
      <waypoint x="271" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_244245_402326" xmi:uuid="5bcc9710-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662407_331822_269950"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299852_432306_284351"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="242"/>
      <waypoint x="271" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_166730_402329" xmi:uuid="5bcc9f30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662484_538138_269966"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299866_608392_284366"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="262"/>
      <waypoint x="271" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_960313_402332" xmi:uuid="5bcca750-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662565_949191_269982"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299874_431530_284381"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="282"/>
      <waypoint x="271" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496664_250825_402335" xmi:uuid="5bccaf40-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662643_4992_269998"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299888_785453_284396"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="302"/>
      <waypoint x="271" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_896085_402338" xmi:uuid="5bccbf60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662725_264663_270014"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299901_169060_284411"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="322"/>
      <waypoint x="271" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_112228_402341" xmi:uuid="5bcccd80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662806_653175_270030"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299910_138160_284426"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="342"/>
      <waypoint x="271" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_753412_402344" xmi:uuid="5bccd7e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662883_571362_270046"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299923_824792_284441"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="362"/>
      <waypoint x="271" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_812483_402347" xmi:uuid="5bcce170-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606662966_369219_270062"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299934_22564_284456"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="382"/>
      <waypoint x="271" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_208585_402350" xmi:uuid="5bcceab0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663043_682480_270078"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299942_329227_284471"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="402"/>
      <waypoint x="271" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_461590_402353" xmi:uuid="5bccf3c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663118_132478_270094"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299954_676379_284486"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="422"/>
      <waypoint x="271" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_770924_402356" xmi:uuid="5bcd0030-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663196_889285_270110"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299965_33416_284501"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="442"/>
      <waypoint x="271" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_819509_402359" xmi:uuid="5bcd0c20-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663273_598138_270126"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299974_592313_284516"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="462"/>
      <waypoint x="271" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_724622_402362" xmi:uuid="5bcd1550-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663352_169134_270142"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299990_196921_284531"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="482"/>
      <waypoint x="271" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_601729_402365" xmi:uuid="5bcd1df0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663437_930223_270158"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300006_53243_284546"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="502"/>
      <waypoint x="271" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_946265_402368" xmi:uuid="5bcd2a30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663521_643471_270174"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300017_773872_284561"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="522"/>
      <waypoint x="271" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_338048_402371" xmi:uuid="5bcd32f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663604_884605_270190"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300026_216177_284576"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="542"/>
      <waypoint x="271" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_882240_402374" xmi:uuid="5bcd3b70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663679_285844_270206"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300041_885426_284591"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="562"/>
      <waypoint x="271" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_198799_402377" xmi:uuid="5bcd43d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663763_142009_270222"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300050_742971_284606"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="582"/>
      <waypoint x="271" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_959570_402380" xmi:uuid="5bcd6ea0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663841_879909_270238"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300065_109794_284621"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="602"/>
      <waypoint x="271" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_660447_402383" xmi:uuid="5bcd90f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663923_891021_270254"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300073_902505_284636"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="622"/>
      <waypoint x="271" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_820378_402386" xmi:uuid="5bcd9930-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606663996_227437_270270"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300122_334670_284651"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="642"/>
      <waypoint x="271" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_823478_402389" xmi:uuid="5bcda1d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664072_661100_270286"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300135_27096_284666"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="662"/>
      <waypoint x="271" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_878540_402392" xmi:uuid="5bcdaa70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664152_606322_270302"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300147_609389_284681"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="682"/>
      <waypoint x="271" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_570035_402395" xmi:uuid="5bce11d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664229_405580_270318"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300158_208208_284696"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="702"/>
      <waypoint x="271" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_145651_402398" xmi:uuid="5bce1f20-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664306_478592_270334"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300167_835235_284711"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="722"/>
      <waypoint x="271" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_116362_402401" xmi:uuid="5bce2a50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664385_834680_270350"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300177_722435_284726"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="742"/>
      <waypoint x="271" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_145334_402404" xmi:uuid="5bce3540-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664459_448412_270366"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300186_543943_284741"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="762"/>
      <waypoint x="271" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_294838_402407" xmi:uuid="5bce3e10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664536_998517_270382"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300198_244857_284756"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="782"/>
      <waypoint x="271" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_97426_402410" xmi:uuid="5bce5330-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664614_470096_270398"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300209_660059_284771"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="802"/>
      <waypoint x="271" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_620420_402413" xmi:uuid="5bce5f60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664692_120103_270414"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300219_836374_284786"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="822"/>
      <waypoint x="271" y="822"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_708572_402416" xmi:uuid="5bce6b70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664769_306112_270430"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300230_418066_284801"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="842"/>
      <waypoint x="271" y="842"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_744399_402419" xmi:uuid="5bce78c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664846_678363_270446"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300242_684902_284816"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="862"/>
      <waypoint x="271" y="862"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_639230_402422" xmi:uuid="5bce8500-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664925_235091_270462"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300251_327354_284831"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="880"/>
      <waypoint x="271" y="880"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_771680_402425" xmi:uuid="5bce9140-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606664999_741137_270478"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300259_884183_284846"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="903"/>
      <waypoint x="271" y="903"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496665_549676_402428" xmi:uuid="5bce9b60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665075_9836_270494"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300269_736543_284861"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299738_130325_284182"/>
      <waypoint x="615" y="921"/>
      <waypoint x="271" y="921"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="618" height="1000"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446301391_461768_286382" xmi:uuid="5e276400-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200980407_188298_15943"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301415_30334_286414" xmi:uuid="5eb93ba0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425411770_666808_69609"/>
      <ownedElement xmi:id="5ea54e30-6c46-013d-d60b-0800270c66d6" xmi:uuid="5ea54f00-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425411770_666808_69609"/>
        <text>relate:Scheme_version_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="5eb92850-6c46-013d-d60b-0800270c66d6" xmi:uuid="5eb92930-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425411770_666808_69609"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="225" height="370"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301430_114641_286448" xmi:uuid="5ec9d8b0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="573" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301443_438167_286463" xmi:uuid="5ed48370-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="573" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301460_498836_286478" xmi:uuid="5eddf020-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="573" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301470_432824_286493" xmi:uuid="5eedab50-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="573" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301478_937715_286508" xmi:uuid="5eef02d0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="573" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301492_212757_286523" xmi:uuid="5ef051f0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="573" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301506_433660_286538" xmi:uuid="5f0ebe20-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="573" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301520_354070_286553" xmi:uuid="5f1ab390-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="573" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301533_92920_286568" xmi:uuid="5f29e400-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="573" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301542_473545_286583" xmi:uuid="5f2b6400-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="573" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301558_310476_286598" xmi:uuid="5f455280-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="573" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301573_94260_286613" xmi:uuid="5f55eb10-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="573" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301587_904850_286628" xmi:uuid="5f5f6fe0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="573" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301596_69567_286643" xmi:uuid="5f60e5b0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="573" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301610_956796_286658" xmi:uuid="5f7906f0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="573" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301620_604458_286673" xmi:uuid="5f852760-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="573" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_897080_402695" xmi:uuid="5f8542d0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601396409_199913_255411"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301430_114641_286448"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="62"/>
      <waypoint x="270" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_630471_402698" xmi:uuid="5f855040-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601396569_290052_255443"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301443_438167_286463"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="82"/>
      <waypoint x="270" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_306546_402701" xmi:uuid="5f855d90-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601396702_152450_255459"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301460_498836_286478"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="102"/>
      <waypoint x="270" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_969201_402704" xmi:uuid="5f856ab0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601396787_424032_255475"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301470_432824_286493"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="122"/>
      <waypoint x="270" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_406070_402707" xmi:uuid="5f857810-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601396862_218427_255491"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301478_937715_286508"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="142"/>
      <waypoint x="270" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_279858_402710" xmi:uuid="5f8584b0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601396939_155998_255507"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301492_212757_286523"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="162"/>
      <waypoint x="270" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_331049_402713" xmi:uuid="5f8594c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397021_287705_255523"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301506_433660_286538"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="182"/>
      <waypoint x="270" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_960572_402716" xmi:uuid="5f85a3d0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397104_429112_255539"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301520_354070_286553"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="202"/>
      <waypoint x="270" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_898819_402719" xmi:uuid="5f85ad00-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397186_404565_255555"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301533_92920_286568"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="222"/>
      <waypoint x="270" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_724723_402722" xmi:uuid="5f85b6f0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397269_701518_255571"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301542_473545_286583"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="242"/>
      <waypoint x="270" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496739_515416_402725" xmi:uuid="5f85c1c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397347_35014_255587"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301558_310476_286598"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="262"/>
      <waypoint x="270" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496740_175876_402728" xmi:uuid="5f85cc20-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397429_322329_255603"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301573_94260_286613"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="282"/>
      <waypoint x="270" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496740_722573_402731" xmi:uuid="5f85d3e0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397513_567763_255619"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301587_904850_286628"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="302"/>
      <waypoint x="270" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496740_786857_402734" xmi:uuid="5f85dde0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397596_157597_255635"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301596_69567_286643"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="322"/>
      <waypoint x="270" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496740_27760_402737" xmi:uuid="5f939c20-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397675_65199_255651"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301610_956796_286658"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="342"/>
      <waypoint x="270" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496740_925330_402740" xmi:uuid="5f93ad20-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601397755_466291_255667"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301620_604458_286673"/>
      <target xmi:idref="_18_4_1_65b021e_1727446301415_30334_286414"/>
      <waypoint x="573" y="362"/>
      <waypoint x="270" y="362"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="576" height="440"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446299126_987106_283364" xmi:uuid="87989930-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192893237_274389_15179"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299149_865604_283396" xmi:uuid="8874a650-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618420559698_336606_68719"/>
      <ownedElement xmi:id="8856fb00-6c45-013d-d60b-0800270c66d6" xmi:uuid="8856fbe0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618420559698_336606_68719"/>
        <text>assign:Scheme_subject_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="88748db0-6c45-013d-d60b-0800270c66d6" xmi:uuid="88748ed0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618420559698_336606_68719"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="230" height="610"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299168_581302_283430" xmi:uuid="88a26cc0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="601" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299180_845434_283445" xmi:uuid="88beefb0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="601" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299195_310927_283460" xmi:uuid="88d48010-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="601" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299203_412691_283475" xmi:uuid="88ddcae0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="601" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299212_912093_283490" xmi:uuid="88e9e300-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="601" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299227_112588_283505" xmi:uuid="88fbdd60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="601" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299237_128273_283520" xmi:uuid="89108550-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="601" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299245_512876_283535" xmi:uuid="891b72a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1529866794283_1220_39337"/>
      <bounds x="601" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299255_759211_283550" xmi:uuid="893598b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="601" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299265_258780_283565" xmi:uuid="89438e00-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="601" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299279_51374_283580" xmi:uuid="8944de80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="601" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299295_117542_283595" xmi:uuid="896ac920-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="601" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299309_682132_283610" xmi:uuid="897e7290-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="601" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299323_432353_283625" xmi:uuid="89986d50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="601" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299331_962278_283640" xmi:uuid="89a70540-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="601" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299340_613984_283655" xmi:uuid="89b03420-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="601" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299349_263802_283670" xmi:uuid="89c424f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="601" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299358_306677_283685" xmi:uuid="89e32300-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="601" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299373_850419_283700" xmi:uuid="89f1f480-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="601" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299389_810304_283715" xmi:uuid="89f36430-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="601" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299405_400545_283730" xmi:uuid="89f4a660-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="601" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299414_368976_283745" xmi:uuid="8a20e6f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="601" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299428_16315_283760" xmi:uuid="8a3cf1e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="601" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299437_614502_283775" xmi:uuid="8a3edfa0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="601" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299447_405124_283790" xmi:uuid="8a64eab0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="601" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299457_20710_283805" xmi:uuid="8a696a40-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="601" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299467_995704_283820" xmi:uuid="8a7a71a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="601" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299476_842676_283835" xmi:uuid="8a7c2b10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="601" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_116893_402167" xmi:uuid="8a7c3990-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413700_917318_259194"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299168_581302_283430"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="62"/>
      <waypoint x="275" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_528906_402170" xmi:uuid="8a7c41d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413790_397735_259210"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299180_845434_283445"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="82"/>
      <waypoint x="275" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_533487_402173" xmi:uuid="8a7c4800-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413872_671107_259226"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299195_310927_283460"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="102"/>
      <waypoint x="275" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_416196_402176" xmi:uuid="8a7c4cf0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601413955_438391_259242"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299203_412691_283475"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="122"/>
      <waypoint x="275" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_744947_402179" xmi:uuid="8a7c52d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414033_319591_259258"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299212_912093_283490"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="142"/>
      <waypoint x="275" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_871411_402182" xmi:uuid="8a7c5720-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414109_473666_259274"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299227_112588_283505"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="162"/>
      <waypoint x="275" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_976452_402185" xmi:uuid="8a7c5cc0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414192_472333_259290"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299237_128273_283520"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="182"/>
      <waypoint x="275" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_799205_402188" xmi:uuid="8a7c6280-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414269_927790_259306"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299245_512876_283535"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="202"/>
      <waypoint x="275" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_415989_402191" xmi:uuid="8a7c68e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414346_374335_259322"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299255_759211_283550"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="222"/>
      <waypoint x="275" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_874788_402194" xmi:uuid="8a7c6e30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414424_903893_259338"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299265_258780_283565"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="242"/>
      <waypoint x="275" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_47281_402197" xmi:uuid="8a7c72a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414502_55455_259354"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299279_51374_283580"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="262"/>
      <waypoint x="275" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_48983_402200" xmi:uuid="8a7c7830-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414665_729820_259386"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299295_117542_283595"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="282"/>
      <waypoint x="275" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_292564_402203" xmi:uuid="8a7c7c80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414750_125522_259402"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299309_682132_283610"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="302"/>
      <waypoint x="275" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_110032_402206" xmi:uuid="8a7c8200-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414833_445240_259418"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299323_432353_283625"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="322"/>
      <waypoint x="275" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_491349_402209" xmi:uuid="8a7c8610-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414915_691521_259434"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299331_962278_283640"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="342"/>
      <waypoint x="275" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_573668_402212" xmi:uuid="8a7c8c40-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601414992_982621_259450"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299340_613984_283655"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="362"/>
      <waypoint x="275" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_132335_402215" xmi:uuid="8a7c9040-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601415072_219273_259466"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299349_263802_283670"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="382"/>
      <waypoint x="275" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_756232_402218" xmi:uuid="8a7c9600-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601415150_5381_259482"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299358_306677_283685"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="402"/>
      <waypoint x="275" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_930768_402221" xmi:uuid="8a7c9b90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601415228_322606_259498"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299373_850419_283700"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="422"/>
      <waypoint x="275" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_855018_402224" xmi:uuid="8a7ca010-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601415315_458864_259514"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299389_810304_283715"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="442"/>
      <waypoint x="275" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_690479_402227" xmi:uuid="8a7ca5c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601415567_862656_259562"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299405_400545_283730"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="462"/>
      <waypoint x="275" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_501720_402230" xmi:uuid="8a7cb0f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601415651_995480_259578"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299414_368976_283745"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="482"/>
      <waypoint x="275" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_405651_402233" xmi:uuid="8a7cba30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601415730_251598_259594"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299428_16315_283760"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="502"/>
      <waypoint x="275" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_589424_402236" xmi:uuid="8a7cbea0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601415811_473652_259610"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299437_614502_283775"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="522"/>
      <waypoint x="275" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_98548_402239" xmi:uuid="8a7cc4a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601415890_419399_259626"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299447_405124_283790"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="542"/>
      <waypoint x="275" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496640_205750_402242" xmi:uuid="8a7cc9e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601415969_721453_259642"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299457_20710_283805"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="562"/>
      <waypoint x="275" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496641_421723_402245" xmi:uuid="8a7cce80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601416048_600940_259658"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299467_995704_283820"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="582"/>
      <waypoint x="275" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496641_473954_402248" xmi:uuid="8a7cd4e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601416128_835062_259674"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299476_842676_283835"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299149_865604_283396"/>
      <waypoint x="601" y="602"/>
      <waypoint x="275" y="602"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="604" height="680"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446298365_965832_282338" xmi:uuid="bdf56cc0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298388_614398_282370" xmi:uuid="bebf2ca0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416373785_139876_67564"/>
      <ownedElement xmi:id="bea5a540-6c45-013d-d60b-0800270c66d6" xmi:uuid="bea5a670-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416373785_139876_67564"/>
        <text>theSchemeEntry:Scheme_entry</text>
      </ownedElement>
      <ownedElement xmi:id="bebefb70-6c45-013d-d60b-0800270c66d6" xmi:uuid="bebefc80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416373785_139876_67564"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="202" height="930"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298405_231809_282404" xmi:uuid="bedce7e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="559" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298414_795583_282419" xmi:uuid="befbff30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_2b2015d_1607082471860_88433_65272"/>
      <bounds x="559" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298430_399731_282434" xmi:uuid="bf1785d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="559" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298438_37094_282449" xmi:uuid="bf194740-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551689215050_535893_40191"/>
      <bounds x="559" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298448_750582_282464" xmi:uuid="bf3fb160-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="559" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298457_715663_282479" xmi:uuid="bf416680-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="559" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298472_952740_282494" xmi:uuid="bf603990-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="559" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298481_649559_282509" xmi:uuid="bf724300-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="559" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298491_535705_282524" xmi:uuid="bf87a1a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="559" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298500_221923_282539" xmi:uuid="bfacf7f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="559" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298514_862182_282554" xmi:uuid="bfae4a30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="559" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298524_170555_282569" xmi:uuid="bfc2a7d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642527069326_238058_76283"/>
      <bounds x="559" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298542_700883_282584" xmi:uuid="bfe0f6d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="559" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298556_10442_282599" xmi:uuid="bff63750-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="559" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298565_219738_282614" xmi:uuid="c0061010-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1540915512831_719143_31709"/>
      <bounds x="559" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298579_533999_282629" xmi:uuid="c01da610-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="559" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298589_244350_282644" xmi:uuid="c03e9850-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="559" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298598_329246_282659" xmi:uuid="c05471c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="559" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298611_171257_282674" xmi:uuid="c055c6f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="559" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298621_287249_282689" xmi:uuid="c0572050-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="559" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298631_190297_282704" xmi:uuid="c07f1640-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="559" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298648_954431_282719" xmi:uuid="c0812160-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="559" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298665_202046_282734" xmi:uuid="c0ad9030-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="559" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298679_312126_282749" xmi:uuid="c0c1b9b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="559" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298689_558878_282764" xmi:uuid="c0d2cd70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1540916564417_774412_33192"/>
      <bounds x="559" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298705_46133_282779" xmi:uuid="c0e21610-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="559" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298714_102588_282794" xmi:uuid="c0ee4280-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="559" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298729_685967_282809" xmi:uuid="c10520a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="559" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298738_805265_282824" xmi:uuid="c11490e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583916459359_231472_65084"/>
      <bounds x="559" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298749_652010_282839" xmi:uuid="c1254b90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="559" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298759_77926_282854" xmi:uuid="c1343340-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="559" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298768_425455_282869" xmi:uuid="c1461b00-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
      <bounds x="559" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298778_724685_282884" xmi:uuid="c1578860-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
      <bounds x="559" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298787_849532_282899" xmi:uuid="c16084c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828862325_997404_79169"/>
      <bounds x="559" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298796_867244_282914" xmi:uuid="c1773f90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="559" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298806_251518_282929" xmi:uuid="c1787f70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="559" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298817_520522_282944" xmi:uuid="c1942940-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="559" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298827_335772_282959" xmi:uuid="c1a21ea0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="559" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298837_987273_282974" xmi:uuid="c1aea300-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="559" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298847_2822_282989" xmi:uuid="c1d14a70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="559" y="835" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298859_776579_283004" xmi:uuid="c1dee330-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="559" y="855" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298868_684524_283019" xmi:uuid="c1f7d690-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570204497794_443467_105732"/>
      <bounds x="559" y="875" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298876_303965_283034" xmi:uuid="c1f995b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577962989407_4853_51636"/>
      <bounds x="559" y="895" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446298886_908393_283049" xmi:uuid="c1fb7140-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="559" y="915" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_549270_401987" xmi:uuid="c1fb83a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606658317_828443_269041"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298405_231809_282404"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="62"/>
      <waypoint x="247" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_572989_401990" xmi:uuid="c1fb8b50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1662738497304_529900_68868"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298414_795583_282419"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="82"/>
      <waypoint x="247" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_108312_401993" xmi:uuid="c1fb92a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606658415_572271_269072"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298430_399731_282434"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="102"/>
      <waypoint x="247" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_159657_401996" xmi:uuid="c1fb9a30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606658499_327021_269088"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298438_37094_282449"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="122"/>
      <waypoint x="247" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_810066_401999" xmi:uuid="c1fba1a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606658576_539266_269104"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298448_750582_282464"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="142"/>
      <waypoint x="247" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_466706_402002" xmi:uuid="c1fba9b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606658652_359531_269120"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298457_715663_282479"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="162"/>
      <waypoint x="247" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_478292_402005" xmi:uuid="c1fbb130-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606658726_513648_269136"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298472_952740_282494"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="182"/>
      <waypoint x="247" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_837031_402008" xmi:uuid="c22524a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606658806_915219_269152"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298481_649559_282509"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="202"/>
      <waypoint x="247" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_220311_402011" xmi:uuid="c2253550-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606658885_453847_269168"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298491_535705_282524"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="222"/>
      <waypoint x="247" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_904585_402014" xmi:uuid="c2254660-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606658961_459161_269184"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298500_221923_282539"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="242"/>
      <waypoint x="247" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_427532_402017" xmi:uuid="c2255690-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659037_340617_269200"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298514_862182_282554"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="262"/>
      <waypoint x="247" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_792014_402020" xmi:uuid="c22560e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659120_903078_269216"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298524_170555_282569"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="282"/>
      <waypoint x="247" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_134742_402023" xmi:uuid="c2257420-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659197_838177_269232"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298542_700883_282584"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="302"/>
      <waypoint x="247" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_330260_402026" xmi:uuid="c2257d20-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659279_891464_269248"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298556_10442_282599"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="322"/>
      <waypoint x="247" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_805408_402029" xmi:uuid="c2258480-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659363_205334_269264"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298565_219738_282614"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="342"/>
      <waypoint x="247" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_49507_402032" xmi:uuid="c2258ca0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659439_337727_269280"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298579_533999_282629"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="362"/>
      <waypoint x="247" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_756033_402035" xmi:uuid="c22594c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659522_456624_269296"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298589_244350_282644"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="382"/>
      <waypoint x="247" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496610_240717_402038" xmi:uuid="c2259b60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659600_210313_269312"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298598_329246_282659"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="402"/>
      <waypoint x="247" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_591012_402041" xmi:uuid="c225a2e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659676_773441_269328"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298611_171257_282674"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="422"/>
      <waypoint x="247" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_223501_402044" xmi:uuid="c225aaf0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659757_568846_269344"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298621_287249_282689"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="442"/>
      <waypoint x="247" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_546905_402047" xmi:uuid="c2262aa0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659834_165171_269360"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298631_190297_282704"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="462"/>
      <waypoint x="247" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_583992_402050" xmi:uuid="c2263310-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659912_850257_269376"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298648_954431_282719"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="482"/>
      <waypoint x="247" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_7457_402053" xmi:uuid="c2263a40-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606659994_380323_269392"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298665_202046_282734"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="502"/>
      <waypoint x="247" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_304998_402056" xmi:uuid="c2264100-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660087_404918_269408"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298679_312126_282749"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="522"/>
      <waypoint x="247" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_473138_402059" xmi:uuid="c22647b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660174_67664_269424"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298689_558878_282764"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="542"/>
      <waypoint x="247" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_623654_402062" xmi:uuid="c2265180-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660251_282773_269440"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298705_46133_282779"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="562"/>
      <waypoint x="247" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_386151_402065" xmi:uuid="c2265980-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660336_187350_269456"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298714_102588_282794"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="582"/>
      <waypoint x="247" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_77124_402068" xmi:uuid="c22661d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660416_269475_269472"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298729_685967_282809"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="602"/>
      <waypoint x="247" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_717609_402071" xmi:uuid="c2266780-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660502_672063_269488"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298738_805265_282824"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="622"/>
      <waypoint x="247" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_476859_402074" xmi:uuid="c2266e80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660576_172513_269504"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298749_652010_282839"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="642"/>
      <waypoint x="247" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_521240_402077" xmi:uuid="c22675a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660654_338135_269520"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298759_77926_282854"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="662"/>
      <waypoint x="247" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_663500_402080" xmi:uuid="c2267d10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660731_357352_269536"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298768_425455_282869"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="682"/>
      <waypoint x="247" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_510345_402083" xmi:uuid="c2268440-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660806_46691_269552"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298778_724685_282884"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="702"/>
      <waypoint x="247" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_498533_402086" xmi:uuid="c2268b60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660888_533557_269568"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298787_849532_282899"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="722"/>
      <waypoint x="247" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_493687_402089" xmi:uuid="c2347ec0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606660962_114776_269584"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298796_867244_282914"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="742"/>
      <waypoint x="247" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_41138_402092" xmi:uuid="c2348c90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661037_790934_269600"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298806_251518_282929"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="762"/>
      <waypoint x="247" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_443196_402095" xmi:uuid="c2349830-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661114_976488_269616"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298817_520522_282944"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="782"/>
      <waypoint x="247" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_618836_402098" xmi:uuid="c234a1a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661192_885659_269632"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298827_335772_282959"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="802"/>
      <waypoint x="247" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_402446_402101" xmi:uuid="c234a920-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661268_94111_269648"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298837_987273_282974"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="822"/>
      <waypoint x="247" y="822"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_143086_402104" xmi:uuid="c234aed0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661346_776409_269664"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298847_2822_282989"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="842"/>
      <waypoint x="247" y="842"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_80157_402107" xmi:uuid="c234b550-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661422_119252_269680"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298859_776579_283004"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="862"/>
      <waypoint x="247" y="862"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_644385_402110" xmi:uuid="c234bc10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661501_410499_269696"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298868_684524_283019"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="880"/>
      <waypoint x="247" y="880"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_116975_402113" xmi:uuid="c234c290-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661575_303968_269712"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298876_303965_283034"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="903"/>
      <waypoint x="247" y="903"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496611_438711_402116" xmi:uuid="c234c9f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606661651_760014_269728"/>
      <source xmi:idref="_18_4_1_65b021e_1727446298886_908393_283049"/>
      <target xmi:idref="_18_4_1_65b021e_1727446298388_614398_282370"/>
      <waypoint x="559" y="921"/>
      <waypoint x="247" y="921"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="562" height="1000"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446300798_414135_285596" xmi:uuid="caface80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201320430_810393_16219"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300820_442797_285628" xmi:uuid="cbbe13d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624453821736_313177_75109"/>
      <ownedElement xmi:id="cba180f0-6c45-013d-d60b-0800270c66d6" xmi:uuid="cba18200-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624453821736_313177_75109"/>
        <text>seqRel:Sequencing_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="cbbdfe30-6c45-013d-d60b-0800270c66d6" xmi:uuid="cbbdff10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1624453821736_313177_75109"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="208" height="370"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300836_789253_285662" xmi:uuid="cbcee880-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="573" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300849_940787_285677" xmi:uuid="cc33a920-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="573" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300864_913158_285692" xmi:uuid="cc480570-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="573" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300874_719892_285707" xmi:uuid="cc594730-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="573" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300882_760383_285722" xmi:uuid="cc78bf60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="573" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300895_592243_285737" xmi:uuid="cc895e70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="573" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300908_435485_285752" xmi:uuid="cc8af990-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="573" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300921_526971_285767" xmi:uuid="ccacb560-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="573" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300934_553310_285782" xmi:uuid="ccae8a20-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="573" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300944_255522_285797" xmi:uuid="ccd1ae00-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="573" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300960_567766_285812" xmi:uuid="ccd3af60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="573" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300975_857308_285827" xmi:uuid="cd068030-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="573" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300991_250092_285842" xmi:uuid="cd15cb20-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="573" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301001_449575_285857" xmi:uuid="cd270400-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="573" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301015_529573_285872" xmi:uuid="cd3804a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="573" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446301026_651127_285887" xmi:uuid="cd541dd0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="573" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_545866_402563" xmi:uuid="cd5439a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401832_132808_256640"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300836_789253_285662"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="62"/>
      <waypoint x="253" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_130097_402566" xmi:uuid="cd544d00-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601401993_592791_256672"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300849_940787_285677"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="82"/>
      <waypoint x="253" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_283441_402569" xmi:uuid="cd545a80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402079_205772_256688"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300864_913158_285692"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="102"/>
      <waypoint x="253" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_321205_402572" xmi:uuid="cd546a50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402163_637819_256704"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300874_719892_285707"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="122"/>
      <waypoint x="253" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_620856_402575" xmi:uuid="cd547c90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402240_529516_256720"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300882_760383_285722"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="142"/>
      <waypoint x="253" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_377524_402578" xmi:uuid="cd5489b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402320_387408_256736"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300895_592243_285737"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="162"/>
      <waypoint x="253" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_476794_402581" xmi:uuid="cd549760-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402403_342084_256752"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300908_435485_285752"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="182"/>
      <waypoint x="253" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_818702_402584" xmi:uuid="cd54b9d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402485_347676_256768"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300921_526971_285767"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="202"/>
      <waypoint x="253" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_825106_402587" xmi:uuid="cd54c8c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402569_322753_256784"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300934_553310_285782"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="222"/>
      <waypoint x="253" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_541044_402590" xmi:uuid="cd54d590-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402653_732631_256800"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300944_255522_285797"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="242"/>
      <waypoint x="253" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_541407_402593" xmi:uuid="cd54e130-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402734_113082_256816"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300960_567766_285812"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="262"/>
      <waypoint x="253" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_712831_402596" xmi:uuid="cd54f080-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402817_35458_256832"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300975_857308_285827"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="282"/>
      <waypoint x="253" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_537721_402599" xmi:uuid="cd54fca0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402902_13206_256848"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300991_250092_285842"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="302"/>
      <waypoint x="253" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_952155_402602" xmi:uuid="cd554340-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601402986_849811_256864"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301001_449575_285857"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="322"/>
      <waypoint x="253" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_140015_402605" xmi:uuid="cd555e60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601403059_928121_256880"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301015_529573_285872"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="342"/>
      <waypoint x="253" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496722_73608_402608" xmi:uuid="cd556ef0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601403141_941100_256896"/>
      <source xmi:idref="_18_4_1_65b021e_1727446301026_651127_285887"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300820_442797_285628"/>
      <waypoint x="573" y="362"/>
      <waypoint x="253" y="362"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="576" height="440"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1617822556572_971623_75927" xmi:uuid="d1c956a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1617822702333_220930_76304" xmi:uuid="d1e23020-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617822702322_99778_76300"/>
      <bounds x="1245" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617822793711_746351_76327" xmi:uuid="d1e282a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617822795115_156284_76328"/>
      <source xmi:idref="_18_4_1_29c0149_1617822702333_220930_76304"/>
      <target xmi:idref="_18_4_1_29c0149_1618416126219_217226_67492"/>
      <waypoint x="1245" y="81"/>
      <waypoint x="1131" y="81"/>
      <waypoint x="1131" y="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618416126219_217226_67492" xmi:uuid="d21a12a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416142585_802498_67523"/>
      <ownedElement xmi:id="d2198500-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d2198630-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416142585_802498_67523"/>
        <text>theScheme:Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="d219fd10-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d219fd90-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416142585_802498_67523"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="a566c530-6c44-013d-d60b-0800270c66d6" xmi:uuid="a566c6a0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a57dc310-6c44-013d-d60b-0800270c66d6" xmi:uuid="a57dc4c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875937661_843844_110983" xmi:uuid="d0e0e500-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-description"/>
          <ownedElement xmi:id="d0d523f0-915a-013c-7158-0a5172f4a469" xmi:uuid="d0d52510-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="d0e05170-915a-013c-7158-0a5172f4a469" xmi:uuid="d0e05280-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1064" y="140" width="150" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875937711_676437_111016" xmi:uuid="d0f79960-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
          <ownedElement xmi:id="d0ebeeb0-915a-013c-7158-0a5172f4a469" xmi:uuid="d0ebefe0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="d0f70a30-915a-013c-7158-0a5172f4a469" xmi:uuid="d0f70b50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1064" y="686" width="107" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1050" y="105" width="178" height="616"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618428196128_643413_70927" xmi:uuid="d251b3d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618428198621_394060_70928"/>
      <source xmi:idref="_18_4_1_29c0149_1618416126219_217226_67492"/>
      <target xmi:idref="_18_4_1_29c0149_1618428134288_439087_70889"/>
      <waypoint x="1131" y="721"/>
      <waypoint x="1131" y="1103"/>
      <waypoint x="923" y="1103"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618427959170_200832_70861" xmi:uuid="d251dc50-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618427959122_380831_70859"/>
      <ownedElement xmi:id="d2281960-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d2281a50-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618427959122_380831_70859"/>
        <text>schemeVersions:Scheme_version</text>
      </ownedElement>
      <ownedElement xmi:id="d2287a50-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d2287ab0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618427959122_380831_70859"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a8bf72c0-6c44-013d-d60b-0800270c66d6" xmi:uuid="a8bf7370-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a8e8a2b0-6c44-013d-d60b-0800270c66d6" xmi:uuid="a8e8a3e0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618428134288_439087_70889" xmi:uuid="d251a7d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version-of_scheme"/>
          <ownedElement xmi:id="d24398e0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d24399d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version-of_scheme"/>
            <text>of_scheme:Scheme</text>
          </ownedElement>
          <ownedElement xmi:id="d2519bf0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d2519ce0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version-of_scheme"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="777" y="1092" width="146" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="707" y="1064" width="238" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618428440985_329885_70987" xmi:uuid="d2538000-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618428440980_200780_70985"/>
      <ownedElement xmi:id="d25284c0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d2528520-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618428440980_200780_70985"/>
        <text>Versions:SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d252de70-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d252dee0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618428440980_200780_70985"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1618428973181_700627_71483" xmi:uuid="d2537910-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617720793589_182632_62953"/>
        <ownedElement xmi:id="ab205a90-6c44-013d-d60b-0800270c66d6" xmi:uuid="ab205b30-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617720793589_182632_62953"/>
          <bounds x="259" y="1077" width="143" height="13"/>
          <text>version : Scheme_version [1]</text>
        </ownedElement>
        <bounds x="237" y="1093" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="1085" width="210" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618428992215_937540_71502" xmi:uuid="d25399a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618428993666_964105_71503"/>
      <source xmi:idref="_18_4_1_29c0149_1618427959170_200832_70861"/>
      <target xmi:idref="_18_4_1_29c0149_1618428973181_700627_71483"/>
      <waypoint x="707" y="1099"/>
      <waypoint x="252" y="1099"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544082_50649_109074" xmi:uuid="d1645d60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535083_726376_108978"/>
      <ownedElement xmi:id="d13f79e0-915a-013c-7158-0a5172f4a469" xmi:uuid="d13f7b20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535083_726376_108978"/>
        <text>sameAsAsgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="d141b340-915a-013c-7158-0a5172f4a469" xmi:uuid="d141b460-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535083_726376_108978"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ac336810-6c44-013d-d60b-0800270c66d6" xmi:uuid="ac3368a0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ac37b630-6c44-013d-d60b-0800270c66d6" xmi:uuid="ac37b6f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_189122_109085" xmi:uuid="d16454a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="d1584e60-915a-013c-7158-0a5172f4a469" xmi:uuid="d1584f90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d1639f80-915a-013c-7158-0a5172f4a469" xmi:uuid="d163a090-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="1015" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="707" y="987" width="268" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876013835_654982_111068" xmi:uuid="d1961230-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876015641_116216_111069"/>
      <source xmi:idref="_18_4_1_29c0149_1618416126219_217226_67492"/>
      <target xmi:idref="_18_4_1_65b021e_1701875544088_827356_109086"/>
      <waypoint x="1050" y="116"/>
      <waypoint x="905" y="116"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544087_702529_109075" xmi:uuid="d1971d40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535085_442690_108979"/>
      <ownedElement xmi:id="d170d710-915a-013c-7158-0a5172f4a469" xmi:uuid="d170d820-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535085_442690_108979"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d172f660-915a-013c-7158-0a5172f4a469" xmi:uuid="d172f9f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535085_442690_108979"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="aeda9ba0-6c44-013d-d60b-0800270c66d6" xmi:uuid="aeda9c40-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="aef15c40-6c44-013d-d60b-0800270c66d6" xmi:uuid="aef15d10-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_827356_109086" xmi:uuid="d1957920-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="d18939f0-915a-013c-7158-0a5172f4a469" xmi:uuid="d1893b00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d194d700-915a-013c-7158-0a5172f4a469" xmi:uuid="d194d810-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="98" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="707" y="70" width="282" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876544214_293564_111638" xmi:uuid="d1c8b970-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876545546_683795_111639"/>
      <source xmi:idref="_18_4_1_29c0149_1618416126219_217226_67492"/>
      <target xmi:idref="_18_4_1_65b021e_1701875544088_910859_109087"/>
      <waypoint x="1050" y="627"/>
      <waypoint x="904" y="627"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544087_351857_109076" xmi:uuid="d1c975b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535086_459356_108980"/>
      <ownedElement xmi:id="d1a351d0-915a-013c-7158-0a5172f4a469" xmi:uuid="d1a352f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535086_459356_108980"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d1a59af0-915a-013c-7158-0a5172f4a469" xmi:uuid="d1a59c00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535086_459356_108980"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b1888b40-6c44-013d-d60b-0800270c66d6" xmi:uuid="b1888be0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b19af420-6c44-013d-d60b-0800270c66d6" xmi:uuid="b19af4e0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_910859_109087" xmi:uuid="d1c7d280-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="d1bbfe00-915a-013c-7158-0a5172f4a469" xmi:uuid="d1bbff20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d1c73800-915a-013c-7158-0a5172f4a469" xmi:uuid="d1c73920-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="616" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="707" y="588" width="226" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876534382_120190_111596" xmi:uuid="d229c030-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876535558_722250_111597"/>
      <source xmi:idref="_18_4_1_29c0149_1618416126219_217226_67492"/>
      <target xmi:idref="_18_4_1_65b021e_1701875544088_153532_109089"/>
      <waypoint x="1050" y="511"/>
      <waypoint x="904" y="511"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544087_780326_109077" xmi:uuid="d22a9f70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535088_794534_108981"/>
      <ownedElement xmi:id="d1d56530-915a-013c-7158-0a5172f4a469" xmi:uuid="d1d56640-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535088_794534_108981"/>
        <text>simpleIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d1d78e30-915a-013c-7158-0a5172f4a469" xmi:uuid="d1d78f40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535088_794534_108981"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b415e3b0-6c44-013d-d60b-0800270c66d6" xmi:uuid="b415e480-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b429a620-6c44-013d-d60b-0800270c66d6" xmi:uuid="b429a700-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_369377_109088" xmi:uuid="d1ef9d70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="d1e3e950-915a-013c-7158-0a5172f4a469" xmi:uuid="d1e3eb40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="d1eee760-915a-013c-7158-0a5172f4a469" xmi:uuid="d1eee880-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="721" y="469" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_153532_109089" xmi:uuid="d2111e10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="d2053180-915a-013c-7158-0a5172f4a469" xmi:uuid="d20532a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d2107530-915a-013c-7158-0a5172f4a469" xmi:uuid="d2107640-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="504" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_621510_109090" xmi:uuid="d2292d80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="d21d1d20-915a-013c-7158-0a5172f4a469" xmi:uuid="d21d1e40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="d2288f40-915a-013c-7158-0a5172f4a469" xmi:uuid="d2289050-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="721" y="539" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="707" y="441" width="263" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544087_507214_109078" xmi:uuid="d22efe80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535089_266748_108982"/>
      <ownedElement xmi:id="d22cc1b0-915a-013c-7158-0a5172f4a469" xmi:uuid="d22cc2c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535089_266748_108982"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="d22ee660-915a-013c-7158-0a5172f4a469" xmi:uuid="d22eea40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535089_266748_108982"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="553" y="539" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876083107_717689_111163" xmi:uuid="d2973070-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876086380_214731_111164"/>
      <source xmi:idref="_18_4_1_29c0149_1618416126219_217226_67492"/>
      <target xmi:idref="_18_4_1_65b021e_1701875544088_905494_109092"/>
      <waypoint x="1050" y="301"/>
      <waypoint x="949" y="301"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544087_480143_109079" xmi:uuid="d297f5c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535090_174267_108983"/>
      <ownedElement xmi:id="d23b3040-915a-013c-7158-0a5172f4a469" xmi:uuid="d23b3160-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535090_174267_108983"/>
        <text>descLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="d23d6850-915a-013c-7158-0a5172f4a469" xmi:uuid="d23d6970-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535090_174267_108983"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ba625e70-6c44-013d-d60b-0800270c66d6" xmi:uuid="ba625f10-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ba75f110-6c44-013d-d60b-0800270c66d6" xmi:uuid="ba75f1e0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_198242_109091" xmi:uuid="d2557870-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="d2498810-915a-013c-7158-0a5172f4a469" xmi:uuid="d2498920-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="d254d300-915a-013c-7158-0a5172f4a469" xmi:uuid="d254d410-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="721" y="357" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_905494_109092" xmi:uuid="d275ca60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="d26a3ee0-915a-013c-7158-0a5172f4a469" xmi:uuid="d26a4000-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="d2753580-915a-013c-7158-0a5172f4a469" xmi:uuid="d2753690-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="287" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_803765_109093" xmi:uuid="d296a090-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="d28af110-915a-013c-7158-0a5172f4a469" xmi:uuid="d28af230-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="d295f320-915a-013c-7158-0a5172f4a469" xmi:uuid="d295f470-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="322" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="707" y="259" width="269" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876089319_824690_111184" xmi:uuid="d2c8da90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876091396_72053_111185"/>
      <source xmi:idref="_18_4_1_29c0149_1618416126219_217226_67492"/>
      <target xmi:idref="_18_4_1_65b021e_1701875544088_428081_109094"/>
      <waypoint x="1050" y="214"/>
      <waypoint x="896" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_645872_109080" xmi:uuid="d2c9a640-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535091_519287_108984"/>
      <ownedElement xmi:id="d2a45bd0-915a-013c-7158-0a5172f4a469" xmi:uuid="d2a45cf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535091_519287_108984"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d2a69780-915a-013c-7158-0a5172f4a469" xmi:uuid="d2a69880-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535091_519287_108984"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c038be10-6c44-013d-d60b-0800270c66d6" xmi:uuid="c038bf20-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c04fb890-6c44-013d-d60b-0800270c66d6" xmi:uuid="c04fb960-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_428081_109094" xmi:uuid="d2c84060-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="d2bccef0-915a-013c-7158-0a5172f4a469" xmi:uuid="d2bcd290-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="d2c7a980-915a-013c-7158-0a5172f4a469" xmi:uuid="d2c7aa90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="203" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="707" y="175" width="293" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_832221_109081" xmi:uuid="d2cdf440-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535092_543509_108985"/>
      <ownedElement xmi:id="d2cbc200-915a-013c-7158-0a5172f4a469" xmi:uuid="d2cbc300-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535092_543509_108985"/>
        <text>descAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="d2cddf70-915a-013c-7158-0a5172f4a469" xmi:uuid="d2cde080-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535092_543509_108985"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="462" y="357" width="223" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876564396_571479_111725" xmi:uuid="d33609e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876568807_867445_111726"/>
      <source xmi:idref="_18_4_1_29c0149_1618416126219_217226_67492"/>
      <target xmi:idref="_18_4_1_65b021e_1701875544088_773536_109096"/>
      <waypoint x="1131" y="721"/>
      <waypoint x="1131" y="865"/>
      <waypoint x="949" y="865"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_721371_109082" xmi:uuid="d336cd00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535094_405021_108986"/>
      <ownedElement xmi:id="d2da0de0-915a-013c-7158-0a5172f4a469" xmi:uuid="d2da1000-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535094_405021_108986"/>
        <text>nameLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="d2dc2760-915a-013c-7158-0a5172f4a469" xmi:uuid="d2dc2860-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535094_405021_108986"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="c328cdc0-6c44-013d-d60b-0800270c66d6" xmi:uuid="c328d130-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c345a560-6c44-013d-d60b-0800270c66d6" xmi:uuid="c345a620-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_465476_109095" xmi:uuid="d2f41d20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="d2e86bd0-915a-013c-7158-0a5172f4a469" xmi:uuid="d2e86ce0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="d2f38660-915a-013c-7158-0a5172f4a469" xmi:uuid="d2f38900-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="721" y="924" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_773536_109096" xmi:uuid="d314c9d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="d3090330-915a-013c-7158-0a5172f4a469" xmi:uuid="d3090460-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="d31430c0-915a-013c-7158-0a5172f4a469" xmi:uuid="d31431d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="854" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_300573_109097" xmi:uuid="d33566c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="d3296480-915a-013c-7158-0a5172f4a469" xmi:uuid="d32965b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="d334a590-915a-013c-7158-0a5172f4a469" xmi:uuid="d334a680-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="889" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="707" y="826" width="273" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876555141_296029_111680" xmi:uuid="d36738a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876557375_411501_111681"/>
      <source xmi:idref="_18_4_1_29c0149_1618416126219_217226_67492"/>
      <target xmi:idref="_18_4_1_65b021e_1701875544088_187369_109098"/>
      <waypoint x="1131" y="721"/>
      <waypoint x="1131" y="795"/>
      <waypoint x="896" y="795"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_647688_109083" xmi:uuid="d367f1e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535094_140171_108987"/>
      <ownedElement xmi:id="d3427260-915a-013c-7158-0a5172f4a469" xmi:uuid="d3427380-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535094_140171_108987"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d3448420-915a-013c-7158-0a5172f4a469" xmi:uuid="d34485c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535094_140171_108987"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c9b0fc10-6c44-013d-d60b-0800270c66d6" xmi:uuid="c9b0fcb0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c9b22c30-6c44-013d-d60b-0800270c66d6" xmi:uuid="c9b22d00-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_187369_109098" xmi:uuid="d366a810-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="d35b0920-915a-013c-7158-0a5172f4a469" xmi:uuid="d35b0cc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="d3661110-915a-013c-7158-0a5172f4a469" xmi:uuid="d3661230-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="784" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="707" y="756" width="262" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_676223_109084" xmi:uuid="d36c3690-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535095_425469_108988"/>
      <ownedElement xmi:id="d36a1530-915a-013c-7158-0a5172f4a469" xmi:uuid="d36a1640-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535095_425469_108988"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="d36c25c0-915a-013c-7158-0a5172f4a469" xmi:uuid="d36c26d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535095_425469_108988"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="483" y="924" width="207" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_37086_109099" xmi:uuid="d36c4090-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535099_30682_109009"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544088_621510_109090"/>
      <target xmi:idref="_18_4_1_65b021e_1701875544087_507214_109078"/>
      <waypoint x="721" y="551"/>
      <waypoint x="687" y="551"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_679168_109100" xmi:uuid="d36c4840-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535100_422320_109020"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544088_198242_109091"/>
      <target xmi:idref="_18_4_1_65b021e_1701875544088_832221_109081"/>
      <waypoint x="721" y="368"/>
      <waypoint x="685" y="368"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875544088_873715_109101" xmi:uuid="d36c5e30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875535101_544274_109031"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544088_465476_109095"/>
      <target xmi:idref="_18_4_1_65b021e_1701875544088_676223_109084"/>
      <waypoint x="721" y="936"/>
      <waypoint x="690" y="936"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_678536_110508" xmi:uuid="d3af0b90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734865_924503_110447"/>
      <ownedElement xmi:id="d379fdd0-915a-013c-7158-0a5172f4a469" xmi:uuid="d379fee0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734865_924503_110447"/>
        <text>selectName:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_682394_110516" xmi:uuid="d3888dd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="cd4f5350-6c44-013d-d60b-0800270c66d6" xmi:uuid="cd4f53f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="289" y="682" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="343" y="691" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_739841_110518" xmi:uuid="d3959460-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="cdeaffc0-6c44-013d-d60b-0800270c66d6" xmi:uuid="cdeb0060-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="558" y="682" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="540" y="691" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_698310_110520" xmi:uuid="d3a27310-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="ceaa6370-6c44-013d-d60b-0800270c66d6" xmi:uuid="ceaa6420-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="495" y="731" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="485" y="713" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_301393_110522" xmi:uuid="d3af0250-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="cf44ddf0-6c44-013d-d60b-0800270c66d6" xmi:uuid="cf44de90-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="374" y="731" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="364" y="713" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="343" y="679" width="212" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_93378_110509" xmi:uuid="d3cb3a60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734867_871733_110448"/>
      <ownedElement xmi:id="d3bc68f0-915a-013c-7158-0a5172f4a469" xmi:uuid="d3bc6a10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734867_871733_110448"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="d3be8d70-915a-013c-7158-0a5172f4a469" xmi:uuid="d3be8e80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734867_871733_110448"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_758633_110524" xmi:uuid="d3cb2ef0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="d0d86940-6c44-013d-d60b-0800270c66d6" xmi:uuid="d0d869e0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="436" y="808" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="557" y="788" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="406" y="784" width="159" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_368334_110510" xmi:uuid="d3e7cb50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734868_664771_110449"/>
      <ownedElement xmi:id="d3d860b0-915a-013c-7158-0a5172f4a469" xmi:uuid="d3d86350-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734868_664771_110449"/>
        <text>nameLanguage:Language</text>
      </ownedElement>
      <ownedElement xmi:id="d3da7ce0-915a-013c-7158-0a5172f4a469" xmi:uuid="d3da7df0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734868_664771_110449"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_909965_110526" xmi:uuid="d3e7bfb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="d2574580-6c44-013d-d60b-0800270c66d6" xmi:uuid="d25745f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="550" y="886" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="532" y="895" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="336" y="889" width="204" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_270968_110511" xmi:uuid="d429d500-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734869_140619_110450"/>
      <ownedElement xmi:id="d3f535d0-915a-013c-7158-0a5172f4a469" xmi:uuid="d3f536f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734869_140619_110450"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_100403_110528" xmi:uuid="d40312a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="d3d98d60-6c44-013d-d60b-0800270c66d6" xmi:uuid="d3d98e00-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="275" y="136" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="329" y="145" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_794823_110530" xmi:uuid="d40ffe60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="d4768030-6c44-013d-d60b-0800270c66d6" xmi:uuid="d47680c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="577" y="140" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="559" y="149" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_476960_110532" xmi:uuid="d41d0a50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="d519f670-6c44-013d-d60b-0800270c66d6" xmi:uuid="d519f710-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="481" y="185" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="471" y="167" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_670225_110534" xmi:uuid="d429c7c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="d5b8f420-6c44-013d-d60b-0800270c66d6" xmi:uuid="d5b8f4c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="374" y="185" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="364" y="167" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="329" y="133" width="245" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_662692_110512" xmi:uuid="d44622c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734870_621005_110451"/>
      <ownedElement xmi:id="d4372780-915a-013c-7158-0a5172f4a469" xmi:uuid="d43728a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734870_621005_110451"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="d4394080-915a-013c-7158-0a5172f4a469" xmi:uuid="d4394190-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734870_621005_110451"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734937_503189_110536" xmi:uuid="d4461480-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="d7253880-6c44-013d-d60b-0800270c66d6" xmi:uuid="d7253960-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="472" y="228" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="580" y="208" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="406" y="203" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_751326_110513" xmi:uuid="d4627790-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734871_368397_110452"/>
      <ownedElement xmi:id="d45380c0-915a-013c-7158-0a5172f4a469" xmi:uuid="d45381c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734871_368397_110452"/>
        <text>descLanguage:Language</text>
      </ownedElement>
      <ownedElement xmi:id="d455ab10-915a-013c-7158-0a5172f4a469" xmi:uuid="d455ac40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734871_368397_110452"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734937_585462_110538" xmi:uuid="d4626d80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="d88585a0-6c44-013d-d60b-0800270c66d6" xmi:uuid="d88587a0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="542" y="319" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="524" y="328" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="329" y="322" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_309135_110514" xmi:uuid="d4930a40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734873_352475_110453"/>
      <ownedElement xmi:id="d46adb50-915a-013c-7158-0a5172f4a469" xmi:uuid="d46adc70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734873_352475_110453"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734937_729152_110540" xmi:uuid="d47944c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="d9e2e070-6c44-013d-d60b-0800270c66d6" xmi:uuid="d9e2e110-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="310" y="465" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="364" y="474" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734937_369215_110542" xmi:uuid="d4860960-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="da6e7380-6c44-013d-d60b-0800270c66d6" xmi:uuid="da6e74d0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="418" y="514" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="408" y="496" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734937_227909_110544" xmi:uuid="d49300e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="db072080-6c44-013d-d60b-0800270c66d6" xmi:uuid="db072190-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="521" y="466" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="503" y="475" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="364" y="462" width="154" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734936_331464_110515" xmi:uuid="d4aee810-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734873_600153_110454"/>
      <ownedElement xmi:id="d4a00b90-915a-013c-7158-0a5172f4a469" xmi:uuid="d4a00ca0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734873_600153_110454"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="d4a22840-915a-013c-7158-0a5172f4a469" xmi:uuid="d4a22940-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734873_600153_110454"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701875734937_612714_110546" xmi:uuid="d4aedb10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="dc474850-6c44-013d-d60b-0800270c66d6" xmi:uuid="dc4748f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="500" y="605" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="482" y="614" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="364" y="609" width="126" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734937_756435_110553" xmi:uuid="d4af2be0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734875_305785_110459"/>
      <source xmi:idref="_18_4_1_65b021e_1701875734936_698310_110520"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734936_93378_110509"/>
      <waypoint x="490" y="728"/>
      <waypoint x="490" y="784"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734938_700416_110554" xmi:uuid="d4af3750-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734875_574753_110463"/>
      <source xmi:idref="_18_4_1_65b021e_1701875734936_368334_110510"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734936_301393_110522"/>
      <waypoint x="371" y="889"/>
      <waypoint x="371" y="728"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734938_105462_110555" xmi:uuid="d4af3ff0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734875_108733_110468"/>
      <source xmi:idref="_18_4_1_65b021e_1701875734936_476960_110532"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734936_662692_110512"/>
      <waypoint x="476" y="182"/>
      <waypoint x="476" y="203"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734938_944242_110556" xmi:uuid="d4af4870-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734876_990043_110472"/>
      <source xmi:idref="_18_4_1_65b021e_1701875734936_751326_110513"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734936_670225_110534"/>
      <waypoint x="371" y="322"/>
      <waypoint x="371" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701875734938_306076_110557" xmi:uuid="d4af5000-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701875734876_235902_110477"/>
      <source xmi:idref="_18_4_1_65b021e_1701875734936_331464_110515"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734937_369215_110542"/>
      <waypoint x="412" y="609"/>
      <waypoint x="412" y="511"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876026155_423190_111089" xmi:uuid="d4af5c40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876029435_356968_111090"/>
      <source xmi:idref="_18_4_1_65b021e_1701875937661_843844_110983"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734936_794823_110530"/>
      <waypoint x="1064" y="154"/>
      <waypoint x="574" y="154"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876035571_157701_111113" xmi:uuid="d4af64f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876037235_994547_111114"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544088_428081_109094"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734937_503189_110536"/>
      <waypoint x="721" y="214"/>
      <waypoint x="595" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876073930_953583_111139" xmi:uuid="d4af6bc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876076457_43373_111140"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544088_803765_109093"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734937_585462_110538"/>
      <waypoint x="721" y="333"/>
      <waypoint x="539" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876277836_630928_111217" xmi:uuid="d4cbdb10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485893_363243_106518"/>
      <ownedElement xmi:id="d4bcd420-915a-013c-7158-0a5172f4a469" xmi:uuid="d4bcd540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485893_363243_106518"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="d4beff90-915a-013c-7158-0a5172f4a469" xmi:uuid="d4bf00a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485893_363243_106518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701876305251_26614_111378" xmi:uuid="d4cbd280-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="ddcf95c0-6c44-013d-d60b-0800270c66d6" xmi:uuid="ddcf9780-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="240" y="80" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="222" y="89" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="84" width="195" height="27"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876277848_893045_111248" xmi:uuid="d4db7670-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485895_968901_106519"/>
      <ownedElement xmi:id="d4d92d00-915a-013c-7158-0a5172f4a469" xmi:uuid="d4d92e10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485895_968901_106519"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d4db61b0-915a-013c-7158-0a5172f4a469" xmi:uuid="d4db62c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485895_968901_106519"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="140" width="200" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876277856_863961_111279" xmi:uuid="d4eb59a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485896_479520_106520"/>
      <ownedElement xmi:id="d4e91580-915a-013c-7158-0a5172f4a469" xmi:uuid="d4e916b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485896_479520_106520"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d4eb41b0-915a-013c-7158-0a5172f4a469" xmi:uuid="d4eb4300-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485896_479520_106520"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="469" width="141" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876277868_920988_111310" xmi:uuid="d4fb0050-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485896_80239_106521"/>
      <ownedElement xmi:id="d4f8c8e0-915a-013c-7158-0a5172f4a469" xmi:uuid="d4f8ca00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485896_80239_106521"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d4faebc0-915a-013c-7158-0a5172f4a469" xmi:uuid="d4faecc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485896_80239_106521"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="686" width="169" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876277880_671276_111341" xmi:uuid="d516fe90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485897_749671_106522"/>
      <ownedElement xmi:id="d507f620-915a-013c-7158-0a5172f4a469" xmi:uuid="d507f740-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485897_749671_106522"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="d50a1850-915a-013c-7158-0a5172f4a469" xmi:uuid="d50a1970-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874485897_749671_106522"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701876400308_147477_111478" xmi:uuid="d516f4e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="e1555ba0-6c44-013d-d60b-0800270c66d6" xmi:uuid="e1555c40-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="175" y="988" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="157" y="997" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="994" width="130" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876319099_319637_111403" xmi:uuid="d51707e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876323168_254327_111404"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544087_702529_109075"/>
      <target xmi:idref="_18_4_1_65b021e_1701876305251_26614_111378"/>
      <waypoint x="707" y="95"/>
      <waypoint x="237" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876350201_548101_111424" xmi:uuid="d5170ff0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876352478_773877_111425"/>
      <source xmi:idref="_18_4_1_65b021e_1701875734936_100403_110528"/>
      <target xmi:idref="_18_4_1_65b021e_1701876277848_893045_111248"/>
      <waypoint x="329" y="151"/>
      <waypoint x="235" y="151"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876367465_496191_111445" xmi:uuid="d5171ae0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876369820_890566_111446"/>
      <source xmi:idref="_18_4_1_65b021e_1701875734937_729152_110540"/>
      <target xmi:idref="_18_4_1_65b021e_1701876277856_863961_111279"/>
      <waypoint x="364" y="480"/>
      <waypoint x="176" y="480"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876382266_478156_111466" xmi:uuid="d5172340-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876384504_911241_111467"/>
      <source xmi:idref="_18_4_1_65b021e_1701875734936_682394_110516"/>
      <target xmi:idref="_18_4_1_65b021e_1701876277868_920988_111310"/>
      <waypoint x="343" y="697"/>
      <waypoint x="204" y="697"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876419738_559769_111505" xmi:uuid="d5172b80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876421788_934157_111506"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544082_50649_109074"/>
      <target xmi:idref="_18_4_1_65b021e_1701876400308_147477_111478"/>
      <waypoint x="707" y="1005"/>
      <waypoint x="172" y="1005"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876428805_231951_111524" xmi:uuid="d51733e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876431241_851655_111525"/>
      <source xmi:idref="_18_4_1_65b021e_1701876595333_858383_111755"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734936_739841_110518"/>
      <waypoint x="707" y="697"/>
      <waypoint x="555" y="697"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876531539_135110_111572" xmi:uuid="d5173c80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876532799_573520_111573"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544088_369377_109088"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734937_227909_110544"/>
      <waypoint x="721" y="483"/>
      <waypoint x="518" y="483"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876539746_650513_111617" xmi:uuid="d51748b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876541818_421383_111618"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544087_351857_109076"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734937_612714_110546"/>
      <waypoint x="707" y="620"/>
      <waypoint x="497" y="620"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876550251_108313_111659" xmi:uuid="d5175140-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876552935_333755_111660"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544088_647688_109083"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734936_758633_110524"/>
      <waypoint x="707" y="795"/>
      <waypoint x="572" y="795"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876560521_597413_111701" xmi:uuid="d51795a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876561750_27255_111702"/>
      <source xmi:idref="_18_4_1_65b021e_1701875544088_300573_109097"/>
      <target xmi:idref="_18_4_1_65b021e_1701875734936_909965_110526"/>
      <waypoint x="721" y="903"/>
      <waypoint x="547" y="903"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876595333_962079_111754" xmi:uuid="d54068f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876595328_535789_111752"/>
      <ownedElement xmi:id="d52540d0-915a-013c-7158-0a5172f4a469" xmi:uuid="d52541e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876595328_535789_111752"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701876595333_858383_111755" xmi:uuid="d53369a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="e2c21300-6c44-013d-d60b-0800270c66d6" xmi:uuid="e2c21390-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="653" y="682" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="707" y="691" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701876595333_50982_111757" xmi:uuid="d54059b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="e34a0040-6c44-013d-d60b-0800270c66d6" xmi:uuid="e34a00e0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="902" y="684" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="884" y="693" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="707" y="679" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876656962_86419_111821" xmi:uuid="d5407910-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876658821_632640_111822"/>
      <source xmi:idref="_18_4_1_65b021e_1701875937711_676437_111016"/>
      <target xmi:idref="_18_4_1_65b021e_1701876595333_50982_111757"/>
      <waypoint x="1064" y="700"/>
      <waypoint x="899" y="700"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1248" height="1142"/>
    <name>Scheme</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1617828792518_436056_79063" xmi:uuid="d253c3d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200446735_930490_15617"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1617829151406_90908_79341" xmi:uuid="d2544180-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617829151396_624189_79337"/>
      <bounds x="1174" y="577" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617828802854_613739_79095" xmi:uuid="d2560010-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816078934_387924_69824"/>
      <ownedElement xmi:id="d254f5b0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d254f620-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816078934_387924_69824"/>
        <text>AssignedEntry:SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="d25560a0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d2556100-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816078934_387924_69824"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617828839686_794250_79157" xmi:uuid="d255f880-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617821346318_436691_75294"/>
        <ownedElement xmi:id="e8b2b3d0-6c44-013d-d60b-0800270c66d6" xmi:uuid="e8b2b490-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617821346318_436691_75294"/>
          <bounds x="226" y="654" width="121" height="13"/>
          <text>entry : Scheme_entry [1]</text>
        </ownedElement>
        <bounds x="208" y="663" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="658" width="195" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617828802864_617907_79126" xmi:uuid="d257e090-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816121645_790139_69834"/>
      <ownedElement xmi:id="d256b940-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d256b9b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816121645_790139_69834"/>
        <text>AssignedTo:SchemeEntryAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d2572350-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d25723c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617816121645_790139_69834"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617829069569_831031_79278" xmi:uuid="d257d9d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828862325_997404_79169"/>
        <ownedElement xmi:id="e963abc0-6c44-013d-d60b-0800270c66d6" xmi:uuid="e963ac70-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828862325_997404_79169"/>
          <bounds x="308" y="688" width="176" height="13"/>
          <text>seis : scheme_entry_item_select [1]</text>
        </ownedElement>
        <bounds x="290" y="697" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="693" width="277" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617829083444_445802_79297" xmi:uuid="d257eed0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617829085580_481243_79298"/>
      <source xmi:idref="_18_4_1_29c0149_1618423385067_893612_69071"/>
      <target xmi:idref="_18_4_1_29c0149_1617828839686_794250_79157"/>
      <waypoint x="882" y="669"/>
      <waypoint x="223" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617829107500_466002_79317" xmi:uuid="d257fa30-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617829109030_591415_79318"/>
      <source xmi:idref="_18_4_1_29c0149_1618423385079_561109_69102"/>
      <target xmi:idref="_18_4_1_29c0149_1617829069569_831031_79278"/>
      <waypoint x="882" y="704"/>
      <waypoint x="305" y="704"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617829210776_445794_79362" xmi:uuid="d2580540-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617829212416_829032_79363"/>
      <source xmi:idref="_18_4_1_29c0149_1618423339023_910556_69032"/>
      <target xmi:idref="_18_4_1_29c0149_1617829151406_90908_79341"/>
      <waypoint x="1096" y="630"/>
      <waypoint x="1096" y="588"/>
      <waypoint x="1174" y="588"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618423339023_910556_69032" xmi:uuid="d2e478a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423344478_850429_69063"/>
      <ownedElement xmi:id="d265cb10-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d265cc10-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423344478_850429_69063"/>
        <text>assign:Scheme_entry_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d2663060-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d26630c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423344478_850429_69063"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="ea4aa770-6c44-013d-d60b-0800270c66d6" xmi:uuid="ea4aa890-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ea59cfd0-6c44-013d-d60b-0800270c66d6" xmi:uuid="ea59d0b0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618423385067_893612_69071" xmi:uuid="d29de910-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_assignment-assigned_activity_method"/>
          <ownedElement xmi:id="d28ec8e0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d28ec9e0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_assignment-assigned_activity_method"/>
            <text>assigned_activity_method:Scheme_entry</text>
          </ownedElement>
          <ownedElement xmi:id="d29dd8c0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d29dd9b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_assignment-assigned_activity_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="882" y="658" width="263" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618423385079_561109_69102" xmi:uuid="d2e44f90-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_assignment-items"/>
          <ownedElement xmi:id="d2c8e530-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d2c8e730-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_assignment-items"/>
            <text>items:scheme_entry_item_select</text>
          </ownedElement>
          <ownedElement xmi:id="d2e42aa0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d2e42c70-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="882" y="693" width="232" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702283957493_248050_118715" xmi:uuid="d5e851a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-role"/>
          <ownedElement xmi:id="d5dc91a0-915a-013c-7158-0a5172f4a469" xmi:uuid="d5dc92c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="d5e7b0d0-915a-013c-7158-0a5172f4a469" xmi:uuid="d5e7b1e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="889" y="742" width="98" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="868" y="630" width="294" height="154"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702053507011_205569_109995" xmi:uuid="d5e85ee0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509987065721_230294_25388"/>
      <bounds x="350" y="14" width="112" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702283939438_579345_118617" xmi:uuid="d61914d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
      <ownedElement xmi:id="d6000c70-915a-013c-7158-0a5172f4a469" xmi:uuid="d6000d90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702283939438_744640_118620" xmi:uuid="d6190b10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="f0bfba60-6c44-013d-d60b-0800270c66d6" xmi:uuid="f0bfbb00-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="405" y="80" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="387" y="89" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="238" y="77" width="164" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702283939438_804604_118618" xmi:uuid="d64b08d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
      <ownedElement xmi:id="d631ddc0-915a-013c-7158-0a5172f4a469" xmi:uuid="d631df20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702283939438_404206_118622" xmi:uuid="d64afa40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="f2e28c70-6c44-013d-d60b-0800270c66d6" xmi:uuid="f2e28d20-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="258" y="472" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="248" y="454" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="189" y="420" width="220" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702283939438_472193_118619" xmi:uuid="d67c77a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
      <ownedElement xmi:id="d6641db0-915a-013c-7158-0a5172f4a469" xmi:uuid="d6641ed0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
        <text>roleSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702283939438_386928_118624" xmi:uuid="d67c6d50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="f4e74240-6c44-013d-d60b-0800270c66d6" xmi:uuid="f4e742c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="399" y="760" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="383" y="747" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="210" y="735" width="188" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284427377_522244_121858" xmi:uuid="d6daa630-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284428949_9088_121859"/>
      <source xmi:idref="_18_4_1_29c0149_1618423339023_910556_69032"/>
      <target xmi:idref="_18_4_1_65b021e_1702284375799_201150_121139"/>
      <waypoint x="903" y="630"/>
      <waypoint x="903" y="126"/>
      <waypoint x="722" y="126"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_998838_121128" xmi:uuid="d6db1c10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375750_401880_121088"/>
      <ownedElement xmi:id="d6889b10-915a-013c-7158-0a5172f4a469" xmi:uuid="d6889c30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375750_401880_121088"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d68abba0-915a-013c-7158-0a5172f4a469" xmi:uuid="d68abca0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375750_401880_121088"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f5cea050-6c44-013d-d60b-0800270c66d6" xmi:uuid="f5cea100-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f5e08210-6c44-013d-d60b-0800270c66d6" xmi:uuid="f5e082c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_985632_121138" xmi:uuid="d6a2e690-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="d6974150-915a-013c-7158-0a5172f4a469" xmi:uuid="d6974260-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="d6a24e70-915a-013c-7158-0a5172f4a469" xmi:uuid="d6a24f90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="539" y="84" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_201150_121139" xmi:uuid="d6c2b060-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="d6b71f40-915a-013c-7158-0a5172f4a469" xmi:uuid="d6b72070-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d6c21af0-915a-013c-7158-0a5172f4a469" xmi:uuid="d6c21c10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="119" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_311221_121140" xmi:uuid="d6da1110-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="d6ce2190-915a-013c-7158-0a5172f4a469" xmi:uuid="d6ce22a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="d6d96560-915a-013c-7158-0a5172f4a469" xmi:uuid="d6d96660-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="539" y="154" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="56" width="254" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_809558_121129" xmi:uuid="d6df6b60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375755_333848_121089"/>
      <ownedElement xmi:id="d6dd4990-915a-013c-7158-0a5172f4a469" xmi:uuid="d6dd4ac0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375755_333848_121089"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="d6df5c80-915a-013c-7158-0a5172f4a469" xmi:uuid="d6df5d90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375755_333848_121089"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="329" y="154" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284431450_786285_121879" xmi:uuid="d7257e00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284433902_319057_121880"/>
      <source xmi:idref="_18_4_1_29c0149_1618423339023_910556_69032"/>
      <target xmi:idref="_18_4_1_65b021e_1702284375799_369576_121141"/>
      <waypoint x="903" y="630"/>
      <waypoint x="903" y="249"/>
      <waypoint x="722" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_573461_121130" xmi:uuid="d725fec0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
      <ownedElement xmi:id="d6f5f9e0-915a-013c-7158-0a5172f4a469" xmi:uuid="d6f5fb00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d7024850-915a-013c-7158-0a5172f4a469" xmi:uuid="d7024960-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="fb95ffe0-6c44-013d-d60b-0800270c66d6" xmi:uuid="fb960080-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="fbac8970-6c44-013d-d60b-0800270c66d6" xmi:uuid="fbac8a30-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_369576_121141" xmi:uuid="d724d9a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="d7191610-915a-013c-7158-0a5172f4a469" xmi:uuid="d7191730-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d7242a90-915a-013c-7158-0a5172f4a469" xmi:uuid="d7242b90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="231" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="203" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284436400_977246_121900" xmi:uuid="d76b2e90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284438771_217827_121901"/>
      <source xmi:idref="_18_4_1_29c0149_1618423339023_910556_69032"/>
      <target xmi:idref="_18_4_1_65b021e_1702284375799_29905_121142"/>
      <waypoint x="903" y="630"/>
      <waypoint x="903" y="326"/>
      <waypoint x="723" y="326"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_895694_121131" xmi:uuid="d76b9b90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
      <ownedElement xmi:id="d73c0d70-915a-013c-7158-0a5172f4a469" xmi:uuid="d73c0e90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d74855a0-915a-013c-7158-0a5172f4a469" xmi:uuid="d74856c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="febafa40-6c44-013d-d60b-0800270c66d6" xmi:uuid="febafae0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="fef31c50-6c44-013d-d60b-0800270c66d6" xmi:uuid="fef31d30-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_29905_121142" xmi:uuid="d76a9780-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="d75ed590-915a-013c-7158-0a5172f4a469" xmi:uuid="d75ed6b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d769f950-915a-013c-7158-0a5172f4a469" xmi:uuid="d769fa60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="308" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="280" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284441257_219540_121921" xmi:uuid="d7bd6f60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284442920_382904_121922"/>
      <source xmi:idref="_18_4_1_29c0149_1618423339023_910556_69032"/>
      <target xmi:idref="_18_4_1_65b021e_1702284375799_795504_121144"/>
      <waypoint x="903" y="630"/>
      <waypoint x="903" y="410"/>
      <waypoint x="714" y="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_7127_121132" xmi:uuid="d7bdf7b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375759_873388_121090"/>
      <ownedElement xmi:id="d777c020-915a-013c-7158-0a5172f4a469" xmi:uuid="d777c130-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375759_873388_121090"/>
        <text>smplDescAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d779e390-915a-013c-7158-0a5172f4a469" xmi:uuid="d779e730-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375759_873388_121090"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="015b6d70-6c45-013d-d60b-0800270c66d6" xmi:uuid="015b6e10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="015cac50-6c45-013d-d60b-0800270c66d6" xmi:uuid="015cad10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_383606_121143" xmi:uuid="d79be4b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="d7905740-915a-013c-7158-0a5172f4a469" xmi:uuid="d7905850-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="d79b4eb0-915a-013c-7158-0a5172f4a469" xmi:uuid="d79b4fe0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="434" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_795504_121144" xmi:uuid="d7bce010-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="d7b12fd0-915a-013c-7158-0a5172f4a469" xmi:uuid="d7b130e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="d7bc3ce0-915a-013c-7158-0a5172f4a469" xmi:uuid="d7bc3e10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="399" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="371" width="287" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_901659_121133" xmi:uuid="d804ad90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
      <ownedElement xmi:id="d7d58680-915a-013c-7158-0a5172f4a469" xmi:uuid="d7d587b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="d7e29a50-915a-013c-7158-0a5172f4a469" xmi:uuid="d7e29b60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="06309850-6c45-013d-d60b-0800270c66d6" xmi:uuid="06309900-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="06320d70-6c45-013d-d60b-0800270c66d6" xmi:uuid="06320e30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_961009_121145" xmi:uuid="d804a3f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="d7f8c190-915a-013c-7158-0a5172f4a469" xmi:uuid="d7f8c2c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="d8040ca0-915a-013c-7158-0a5172f4a469" xmi:uuid="d8040db0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="259" y="371" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="343" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_409612_121134" xmi:uuid="d82b9810-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375764_163211_121091"/>
      <ownedElement xmi:id="d81118b0-915a-013c-7158-0a5172f4a469" xmi:uuid="d81119c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375764_163211_121091"/>
        <text>descText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="d8133b60-915a-013c-7158-0a5172f4a469" xmi:uuid="d8133e50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375764_163211_121091"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="087b1430-6c45-013d-d60b-0800270c66d6" xmi:uuid="087b14c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="088889a0-6c45-013d-d60b-0800270c66d6" xmi:uuid="08888a60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_110792_121146" xmi:uuid="d82b8d50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="d81fde80-915a-013c-7158-0a5172f4a469" xmi:uuid="d81fdff0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="d82ad420-915a-013c-7158-0a5172f4a469" xmi:uuid="d82ad560-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="357" y="518" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="343" y="490" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284445289_534946_121942" xmi:uuid="d8712190-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284447142_128984_121943"/>
      <source xmi:idref="_18_4_1_29c0149_1618423339023_910556_69032"/>
      <target xmi:idref="_18_4_1_65b021e_1702284375799_570140_121147"/>
      <waypoint x="903" y="630"/>
      <waypoint x="903" y="609"/>
      <waypoint x="714" y="609"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_575917_121135" xmi:uuid="d87192f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
      <ownedElement xmi:id="d841d370-915a-013c-7158-0a5172f4a469" xmi:uuid="d841d480-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d84ea750-915a-013c-7158-0a5172f4a469" xmi:uuid="d84ea990-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="0ad40940-6c45-013d-d60b-0800270c66d6" xmi:uuid="0ad409e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0ae48e20-6c45-013d-d60b-0800270c66d6" xmi:uuid="0ae48ef0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_570140_121147" xmi:uuid="d8708b10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="d8650db0-915a-013c-7158-0a5172f4a469" xmi:uuid="d8650ee0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="d86ff920-915a-013c-7158-0a5172f4a469" xmi:uuid="d86ffa40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="595" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="567" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284450058_538204_121963" xmi:uuid="d8b5d840-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284451878_103223_121964"/>
      <source xmi:idref="_18_4_1_29c0149_1618423339023_910556_69032"/>
      <target xmi:idref="_18_4_1_65b021e_1702284375799_394924_121148"/>
      <waypoint x="900" y="784"/>
      <waypoint x="900" y="840"/>
      <waypoint x="723" y="840"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_450069_121136" xmi:uuid="d8b64630-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
      <ownedElement xmi:id="d8878b40-915a-013c-7158-0a5172f4a469" xmi:uuid="d8878dc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d8938bb0-915a-013c-7158-0a5172f4a469" xmi:uuid="d8938cb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="0ddb0510-6c45-013d-d60b-0800270c66d6" xmi:uuid="0ddb05b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0df028e0-6c45-013d-d60b-0800270c66d6" xmi:uuid="0df029e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_394924_121148" xmi:uuid="d8b54720-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="d8a9b8b0-915a-013c-7158-0a5172f4a469" xmi:uuid="d8a9b9c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d8b4b400-915a-013c-7158-0a5172f4a469" xmi:uuid="d8b4b510-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="826" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="798" width="246" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_137469_121137" xmi:uuid="d8decef0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375768_999385_121092"/>
      <ownedElement xmi:id="d8c3db70-915a-013c-7158-0a5172f4a469" xmi:uuid="d8c3dc90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375768_999385_121092"/>
        <text>default:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_870976_121149" xmi:uuid="d8d21900-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="117716f0-6c45-013d-d60b-0800270c66d6" xmi:uuid="117717a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="471" y="738" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="525" y="747" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702284375799_477276_121151" xmi:uuid="d8dec1a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="12288ce0-6c45-013d-d60b-0800270c66d6" xmi:uuid="12288d80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="689" y="736" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="671" y="745" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="525" y="735" width="161" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375800_946367_121153" xmi:uuid="d8ded9c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375772_727825_121096"/>
      <source xmi:idref="_18_4_1_65b021e_1702284375799_311221_121140"/>
      <target xmi:idref="_18_4_1_65b021e_1702284375799_809558_121129"/>
      <waypoint x="539" y="165"/>
      <waypoint x="463" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375800_658710_121154" xmi:uuid="d8dee3a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375772_954406_121104"/>
      <source xmi:idref="_18_4_1_65b021e_1702284375799_961009_121145"/>
      <target xmi:idref="_18_4_1_65b021e_1702284375799_409612_121134"/>
      <waypoint x="480" y="396"/>
      <waypoint x="480" y="490"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284375800_460860_121155" xmi:uuid="d8deec80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284375772_641483_121105"/>
      <source xmi:idref="_18_4_1_65b021e_1702284375799_383606_121143"/>
      <target xmi:idref="_18_4_1_65b021e_1702284375799_409612_121134"/>
      <waypoint x="595" y="459"/>
      <waypoint x="595" y="522"/>
      <waypoint x="530" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284424914_830498_121834" xmi:uuid="d8def4e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284426148_385776_121835"/>
      <source xmi:idref="_18_4_1_65b021e_1702284375799_985632_121138"/>
      <target xmi:idref="_18_4_1_65b021e_1702283939438_744640_118620"/>
      <waypoint x="539" y="95"/>
      <waypoint x="402" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284454728_241662_121984" xmi:uuid="d8df00f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284456133_872001_121985"/>
      <source xmi:idref="_18_4_1_65b021e_1702283957493_248050_118715"/>
      <target xmi:idref="_18_4_1_65b021e_1702284375799_477276_121151"/>
      <waypoint x="889" y="753"/>
      <waypoint x="686" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284457777_518826_122008" xmi:uuid="d8df0a00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284458897_199063_122009"/>
      <source xmi:idref="_18_4_1_65b021e_1702284375799_870976_121149"/>
      <target xmi:idref="_18_4_1_65b021e_1702283939438_386928_118624"/>
      <waypoint x="525" y="753"/>
      <waypoint x="398" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284462735_709067_122032" xmi:uuid="d8df1450-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284464069_494048_122033"/>
      <source xmi:idref="_18_4_1_65b021e_1702284375799_110792_121146"/>
      <target xmi:idref="_18_4_1_65b021e_1702283939438_404206_118622"/>
      <waypoint x="357" y="529"/>
      <waypoint x="256" y="529"/>
      <waypoint x="256" y="469"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1177" height="876"/>
    <name>SchemeEntryAssignment</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617720169101_631824_61679" xmi:uuid="d2e495e0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617720793604_914147_62957" xmi:uuid="d3077510-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617720793589_182632_62953"/>
      <bounds x="1300" y="43" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617721078666_248277_64497" xmi:uuid="d307d400-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617721080626_633489_64498"/>
      <source xmi:idref="_18_4_1_2b2015d_1617720793604_914147_62957"/>
      <target xmi:idref="_18_4_1_29c0149_1618407373671_211353_63521"/>
      <waypoint x="1300" y="53"/>
      <waypoint x="1162" y="53"/>
      <waypoint x="1162" y="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618407373671_211353_63521" xmi:uuid="d318a680-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618418461624_866716_67608"/>
      <ownedElement xmi:id="d31812e0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3181c90-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618418461624_866716_67608"/>
        <text>theSchemeVersion:Scheme_version</text>
      </ownedElement>
      <ownedElement xmi:id="d3187ce0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3187d40-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618418461624_866716_67608"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="16c97650-6c45-013d-d60b-0800270c66d6" xmi:uuid="16c976f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="16cac7d0-6c45-013d-d60b-0800270c66d6" xmi:uuid="16caca50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877896553_464049_116228" xmi:uuid="d92c38d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-description"/>
          <ownedElement xmi:id="d92059a0-915a-013c-7158-0a5172f4a469" xmi:uuid="d9205ab0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="d92ba540-915a-013c-7158-0a5172f4a469" xmi:uuid="d92ba660-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1057" y="126" width="150" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877896565_91618_116259" xmi:uuid="d9430030-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
          <ownedElement xmi:id="d9375fc0-915a-013c-7158-0a5172f4a469" xmi:uuid="d93760c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="d9426360-915a-013c-7158-0a5172f4a469" xmi:uuid="d9426470-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1057" y="714" width="107" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1036" y="91" width="252" height="658"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618430088671_22505_71647" xmi:uuid="d36014b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618430090364_928229_71648"/>
      <source xmi:idref="_18_4_1_29c0149_1618407373671_211353_63521"/>
      <target xmi:idref="_18_4_1_29c0149_1618430076935_441172_71609"/>
      <waypoint x="1036" y="431"/>
      <waypoint x="891" y="431"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618429631886_63913_71550" xmi:uuid="d3603ee0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618429631880_940542_71548"/>
      <ownedElement xmi:id="d32d2a60-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d32d2b50-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618429631880_940542_71548"/>
        <text>schemeDefinitions:Scheme_entry</text>
      </ownedElement>
      <ownedElement xmi:id="d32d95b0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d32d9620-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618429631880_940542_71548"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="1aebe6d0-6c45-013d-d60b-0800270c66d6" xmi:uuid="1aebe810-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="1aed6e90-6c45-013d-d60b-0800270c66d6" xmi:uuid="1aed6f80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618430076935_441172_71609" xmi:uuid="d3600880-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry-scheme"/>
          <ownedElement xmi:id="d3519960-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3519a50-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry-scheme"/>
            <text>scheme:Scheme_version</text>
          </ownedElement>
          <ownedElement xmi:id="d35f98a0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d35f9990-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry-scheme"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="714" y="420" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="385" width="233" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618430100059_611528_71662" xmi:uuid="d361b660-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618430100054_408411_71660"/>
      <ownedElement xmi:id="d360e5c0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d360e770-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618430100054_408411_71660"/>
        <text>Entries:SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="d36140b0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3614120-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618430100054_408411_71660"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1618430212207_684556_71707" xmi:uuid="d361afc0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617821346318_436691_75294"/>
        <ownedElement xmi:id="1d466e00-6c45-013d-d60b-0800270c66d6" xmi:uuid="1d467060-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617821346318_436691_75294"/>
          <bounds x="234" y="408" width="121" height="13"/>
          <text>entry : Scheme_entry [1]</text>
        </ownedElement>
        <bounds x="219" y="421" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="413" width="192" height="27"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618430186992_646871_71697" xmi:uuid="d361c130-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618430188459_170093_71698"/>
      <source xmi:idref="_18_4_1_29c0149_1618430212207_684556_71707"/>
      <target xmi:idref="_18_4_1_29c0149_1618429631886_63913_71550"/>
      <waypoint x="234" y="427"/>
      <waypoint x="693" y="427"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878063424_424784_116514" xmi:uuid="d9ad0020-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878064671_314140_116515"/>
      <source xmi:idref="_18_4_1_29c0149_1618407373671_211353_63521"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_529127_114407"/>
      <waypoint x="1036" y="189"/>
      <waypoint x="882" y="189"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_396096_114394" xmi:uuid="d9adbf70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432294_863786_114254"/>
      <ownedElement xmi:id="d988eea0-915a-013c-7158-0a5172f4a469" xmi:uuid="d988f220-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432294_863786_114254"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d98b4300-915a-013c-7158-0a5172f4a469" xmi:uuid="d98b44b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432294_863786_114254"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="1e49ff10-6c45-013d-d60b-0800270c66d6" xmi:uuid="1e49ffc0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="1e596f30-6c45-013d-d60b-0800270c66d6" xmi:uuid="1e597020-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_529127_114407" xmi:uuid="d9ac7090-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="d9a16e40-915a-013c-7158-0a5172f4a469" xmi:uuid="d9a17020-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="d9abc3d0-915a-013c-7158-0a5172f4a469" xmi:uuid="d9abc4e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="182" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="154" width="293" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878057274_209538_116496" xmi:uuid="d9dfb700-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878059325_323109_116497"/>
      <source xmi:idref="_18_4_1_29c0149_1618407373671_211353_63521"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_918861_114408"/>
      <waypoint x="1036" y="95"/>
      <waypoint x="891" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_804800_114395" xmi:uuid="d9e07c50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432295_47990_114255"/>
      <ownedElement xmi:id="d9ba1e30-915a-013c-7158-0a5172f4a469" xmi:uuid="d9ba2050-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432295_47990_114255"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d9bc6400-915a-013c-7158-0a5172f4a469" xmi:uuid="d9bc6510-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432295_47990_114255"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="21226710-6c45-013d-d60b-0800270c66d6" xmi:uuid="212267c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2135f700-6c45-013d-d60b-0800270c66d6" xmi:uuid="2135f7f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_918861_114408" xmi:uuid="d9df24a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="d9d2fa20-915a-013c-7158-0a5172f4a469" xmi:uuid="d9d2fb60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d9de9120-915a-013c-7158-0a5172f4a469" xmi:uuid="d9de9230-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="84" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="56" width="282" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878090265_501078_116643" xmi:uuid="da495ff0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878091879_297501_116644"/>
      <source xmi:idref="_18_4_1_29c0149_1618407373671_211353_63521"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_667453_114410"/>
      <waypoint x="1085" y="749"/>
      <waypoint x="1085" y="882"/>
      <waypoint x="935" y="882"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_640377_114396" xmi:uuid="da4a2570-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432296_233879_114256"/>
      <ownedElement xmi:id="d9ec7cd0-915a-013c-7158-0a5172f4a469" xmi:uuid="d9ec7df0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432296_233879_114256"/>
        <text>nameLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="d9eeb0b0-915a-013c-7158-0a5172f4a469" xmi:uuid="d9eeb1c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432296_233879_114256"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="23df8550-6c45-013d-d60b-0800270c66d6" xmi:uuid="23df8600-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="23fd1b80-6c45-013d-d60b-0800270c66d6" xmi:uuid="23fd1c60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_264066_114409" xmi:uuid="da070f20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="d9fb2230-915a-013c-7158-0a5172f4a469" xmi:uuid="d9fb2350-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="da066db0-915a-013c-7158-0a5172f4a469" xmi:uuid="da0670a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="707" y="945" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_667453_114410" xmi:uuid="da283830-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="da1c5950-915a-013c-7158-0a5172f4a469" xmi:uuid="da1c5a80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="da279d10-915a-013c-7158-0a5172f4a469" xmi:uuid="da279e20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="875" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_645390_114411" xmi:uuid="da48d450-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="da3d4e30-915a-013c-7158-0a5172f4a469" xmi:uuid="da3d4f40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="da483f70-915a-013c-7158-0a5172f4a469" xmi:uuid="da4840a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="910" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="847" width="273" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878067732_173205_116535" xmi:uuid="dab447b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878068646_550597_116536"/>
      <source xmi:idref="_18_4_1_29c0149_1618407373671_211353_63521"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_128828_114413"/>
      <waypoint x="1036" y="277"/>
      <waypoint x="935" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_357569_114397" xmi:uuid="dab4fca0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432297_56130_114257"/>
      <ownedElement xmi:id="da569430-915a-013c-7158-0a5172f4a469" xmi:uuid="da569550-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432297_56130_114257"/>
        <text>descLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="da58b240-915a-013c-7158-0a5172f4a469" xmi:uuid="da58b360-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432297_56130_114257"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="29ae5b60-6c45-013d-d60b-0800270c66d6" xmi:uuid="29ae5cf0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="29c7f120-6c45-013d-d60b-0800270c66d6" xmi:uuid="29c7f1c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_262082_114412" xmi:uuid="da714710-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="da655af0-915a-013c-7158-0a5172f4a469" xmi:uuid="da655c10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="da70a3e0-915a-013c-7158-0a5172f4a469" xmi:uuid="da70a650-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="707" y="336" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_128828_114413" xmi:uuid="da927c80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="da8693b0-915a-013c-7158-0a5172f4a469" xmi:uuid="da8695a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="da91e560-915a-013c-7158-0a5172f4a469" xmi:uuid="da91e680-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="266" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_530240_114414" xmi:uuid="dab3b1a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="daa7ea30-915a-013c-7158-0a5172f4a469" xmi:uuid="daa7eb50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="dab32130-915a-013c-7158-0a5172f4a469" xmi:uuid="dab32250-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="301" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="238" width="269" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878100263_951465_116685" xmi:uuid="dae5b9e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878102597_492988_116686"/>
      <source xmi:idref="_18_4_1_29c0149_1618407373671_211353_63521"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_647489_114415"/>
      <waypoint x="1085" y="749"/>
      <waypoint x="1085" y="1047"/>
      <waypoint x="930" y="1047"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_703211_114398" xmi:uuid="dae67950-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432298_560725_114258"/>
      <ownedElement xmi:id="dac17720-915a-013c-7158-0a5172f4a469" xmi:uuid="dac17830-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432298_560725_114258"/>
        <text>sameAsAsgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="dac388e0-915a-013c-7158-0a5172f4a469" xmi:uuid="dac389e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432298_560725_114258"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="2fe18a30-6c45-013d-d60b-0800270c66d6" xmi:uuid="2fe18bd0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2ffb48b0-6c45-013d-d60b-0800270c66d6" xmi:uuid="2ffb4a60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_647489_114415" xmi:uuid="dae52fd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="dad99ed0-915a-013c-7158-0a5172f4a469" xmi:uuid="dad99ff0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="dae49770-915a-013c-7158-0a5172f4a469" xmi:uuid="dae49890-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="1036" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="1008" width="268" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878071355_734139_116556" xmi:uuid="db4467a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878072288_287257_116557"/>
      <source xmi:idref="_18_4_1_29c0149_1618407373671_211353_63521"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_797651_114417"/>
      <waypoint x="1036" y="543"/>
      <waypoint x="890" y="543"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_493046_114399" xmi:uuid="db452280-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432299_936010_114259"/>
      <ownedElement xmi:id="daf238f0-915a-013c-7158-0a5172f4a469" xmi:uuid="daf239f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432299_936010_114259"/>
        <text>simpleIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="daf43c50-915a-013c-7158-0a5172f4a469" xmi:uuid="daf43d50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432299_936010_114259"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="32910540-6c45-013d-d60b-0800270c66d6" xmi:uuid="329105d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="32a02840-6c45-013d-d60b-0800270c66d6" xmi:uuid="32a029c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_650226_114416" xmi:uuid="db0c5660-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="db007030-915a-013c-7158-0a5172f4a469" xmi:uuid="db007140-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="db0bb9f0-915a-013c-7158-0a5172f4a469" xmi:uuid="db0bbb10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="707" y="497" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_797651_114417" xmi:uuid="db2ccd10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="db214ab0-915a-013c-7158-0a5172f4a469" xmi:uuid="db214bd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="db2c3f20-915a-013c-7158-0a5172f4a469" xmi:uuid="db2c42f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="532" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_621792_114418" xmi:uuid="db43cc20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="db37ec30-915a-013c-7158-0a5172f4a469" xmi:uuid="db37ee40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="db433240-915a-013c-7158-0a5172f4a469" xmi:uuid="db433350-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="707" y="567" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="469" width="263" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878094757_634267_116664" xmi:uuid="db7657e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878097238_941252_116665"/>
      <source xmi:idref="_18_4_1_29c0149_1618407373671_211353_63521"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_300179_114419"/>
      <waypoint x="1085" y="749"/>
      <waypoint x="1085" y="816"/>
      <waypoint x="882" y="816"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_578395_114400" xmi:uuid="db771f00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432300_258503_114260"/>
      <ownedElement xmi:id="db5117e0-915a-013c-7158-0a5172f4a469" xmi:uuid="db511910-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432300_258503_114260"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="db5333f0-915a-013c-7158-0a5172f4a469" xmi:uuid="db533640-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432300_258503_114260"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="379d19b0-6c45-013d-d60b-0800270c66d6" xmi:uuid="379d1a60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="37a98ce0-6c45-013d-d60b-0800270c66d6" xmi:uuid="37a98de0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_300179_114419" xmi:uuid="db75bf10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="db699ec0-915a-013c-7158-0a5172f4a469" xmi:uuid="db69a1d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="db751310-915a-013c-7158-0a5172f4a469" xmi:uuid="db751440-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="805" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="777" width="262" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878075005_573578_116577" xmi:uuid="dba99be0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878076135_524496_116578"/>
      <source xmi:idref="_18_4_1_29c0149_1618407373671_211353_63521"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_443806_114421"/>
      <waypoint x="1036" y="662"/>
      <waypoint x="890" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_570498_114402" xmi:uuid="dbaa5480-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432301_684155_114262"/>
      <ownedElement xmi:id="db843890-915a-013c-7158-0a5172f4a469" xmi:uuid="db8439c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432301_684155_114262"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="db8677c0-915a-013c-7158-0a5172f4a469" xmi:uuid="db8678e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432301_684155_114262"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="3ab54210-6c45-013d-d60b-0800270c66d6" xmi:uuid="3ab542b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3ab67c80-6c45-013d-d60b-0800270c66d6" xmi:uuid="3ab67d50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_443806_114421" xmi:uuid="dba90c30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="db9d5470-915a-013c-7158-0a5172f4a469" xmi:uuid="db9d56a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="dba87100-915a-013c-7158-0a5172f4a469" xmi:uuid="dba87370-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="644" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="616" width="226" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_789418_114403" xmi:uuid="dbd44a40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432302_154106_114263"/>
      <ownedElement xmi:id="dbb84b50-915a-013c-7158-0a5172f4a469" xmi:uuid="dbb84c70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432302_154106_114263"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_59397_114422" xmi:uuid="dbc6e790-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="3e42af00-6c45-013d-d60b-0800270c66d6" xmi:uuid="3e42afd0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="639" y="703" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="693" y="712" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_341808_114424" xmi:uuid="dbd43cc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="3ef29370-6c45-013d-d60b-0800270c66d6" xmi:uuid="3ef29420-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="888" y="705" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="870" y="714" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="693" y="700" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_330586_114404" xmi:uuid="dbd945e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432302_930073_114264"/>
      <ownedElement xmi:id="dbd6efb0-915a-013c-7158-0a5172f4a469" xmi:uuid="dbd6f0e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432302_930073_114264"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="dbd93140-915a-013c-7158-0a5172f4a469" xmi:uuid="dbd93270-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432302_930073_114264"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="469" y="945" width="207" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_733547_114405" xmi:uuid="dbddcb10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432303_651261_114265"/>
      <ownedElement xmi:id="dbdb5df0-915a-013c-7158-0a5172f4a469" xmi:uuid="dbdb5f20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432303_651261_114265"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="dbddb630-915a-013c-7158-0a5172f4a469" xmi:uuid="dbddb740-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432303_651261_114265"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="539" y="567" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449651_174234_114406" xmi:uuid="dbe26010-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432304_161305_114266"/>
      <ownedElement xmi:id="dbdffe30-915a-013c-7158-0a5172f4a469" xmi:uuid="dbe00080-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432304_161305_114266"/>
        <text>descAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="dbe24a10-915a-013c-7158-0a5172f4a469" xmi:uuid="dbe24b10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432304_161305_114266"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="448" y="336" width="223" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449652_265300_114426" xmi:uuid="dbe26950-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432307_520999_114308"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_264066_114409"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_330586_114404"/>
      <waypoint x="707" y="957"/>
      <waypoint x="676" y="957"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449652_793880_114427" xmi:uuid="dbe27810-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432307_476729_114313"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_621792_114418"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_733547_114405"/>
      <waypoint x="707" y="579"/>
      <waypoint x="673" y="579"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877449652_961384_114428" xmi:uuid="dbe280c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877432308_943419_114318"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_262082_114412"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_174234_114406"/>
      <waypoint x="707" y="347"/>
      <waypoint x="671" y="347"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877526051_497834_115351" xmi:uuid="dbff85a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689575_515007_106625"/>
      <ownedElement xmi:id="dbf09d30-915a-013c-7158-0a5172f4a469" xmi:uuid="dbf09e50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689575_515007_106625"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="dbf2e820-915a-013c-7158-0a5172f4a469" xmi:uuid="dbf2e960-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689575_515007_106625"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877608473_862987_115529" xmi:uuid="dbff7dd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="4196ee00-6c45-013d-d60b-0800270c66d6" xmi:uuid="4196eea0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="240" y="66" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="222" y="75" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="63" width="195" height="37"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877526193_981412_115382" xmi:uuid="dc0edb40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689576_459069_106626"/>
      <ownedElement xmi:id="dc0cae80-915a-013c-7158-0a5172f4a469" xmi:uuid="dc0cafa0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689576_459069_106626"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="dc0ec770-915a-013c-7158-0a5172f4a469" xmi:uuid="dc0ec890-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689576_459069_106626"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="119" width="200" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877526204_823576_115413" xmi:uuid="dc1fb810-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689574_583530_106624"/>
      <ownedElement xmi:id="dc1d08d0-915a-013c-7158-0a5172f4a469" xmi:uuid="dc1d0a20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689574_583530_106624"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="dc1f9da0-915a-013c-7158-0a5172f4a469" xmi:uuid="dc1f9ed0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689574_583530_106624"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="497" width="141" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877526212_290016_115444" xmi:uuid="dc300c40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689573_79052_106623"/>
      <ownedElement xmi:id="dc2de230-915a-013c-7158-0a5172f4a469" xmi:uuid="dc2de350-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689573_79052_106623"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="dc2ffb00-915a-013c-7158-0a5172f4a469" xmi:uuid="dc2ffc10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689573_79052_106623"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="707" width="169" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877526222_396046_115475" xmi:uuid="dc4be7e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689571_972735_106622"/>
      <ownedElement xmi:id="dc3d37f0-915a-013c-7158-0a5172f4a469" xmi:uuid="dc3d3910-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689571_972735_106622"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="dc3f4f80-915a-013c-7158-0a5172f4a469" xmi:uuid="dc3f5090-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874689571_972735_106622"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701878015295_948153_116428" xmi:uuid="dc4bdba0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="453863d0-6c45-013d-d60b-0800270c66d6" xmi:uuid="45386850-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="182" y="1018" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="164" y="1027" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="1015" width="130" height="37"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_491943_115612" xmi:uuid="dc8e6430-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642804_461951_115551"/>
      <ownedElement xmi:id="dc5951e0-915a-013c-7158-0a5172f4a469" xmi:uuid="dc5952f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642804_461951_115551"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_87529_115620" xmi:uuid="dc6798c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="47166ca0-6c45-013d-d60b-0800270c66d6" xmi:uuid="47166d40-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="261" y="115" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="315" y="124" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_700202_115622" xmi:uuid="dc748ee0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="47cad030-6c45-013d-d60b-0800270c66d6" xmi:uuid="47cad0d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="563" y="119" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="545" y="128" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_852616_115624" xmi:uuid="dc818c80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="487a57d0-6c45-013d-d60b-0800270c66d6" xmi:uuid="487a5890-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="467" y="164" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="457" y="146" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_534783_115626" xmi:uuid="dc8e5820-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="492c7440-6c45-013d-d60b-0800270c66d6" xmi:uuid="492c74f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="360" y="164" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="350" y="146" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="315" y="112" width="245" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_804270_115613" xmi:uuid="dcab1190-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642805_958284_115552"/>
      <ownedElement xmi:id="dc9be380-915a-013c-7158-0a5172f4a469" xmi:uuid="dc9be490-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642805_958284_115552"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="dc9e1840-915a-013c-7158-0a5172f4a469" xmi:uuid="dc9e1940-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642805_958284_115552"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_527771_115628" xmi:uuid="dcab07c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="4aab8cd0-6c45-013d-d60b-0800270c66d6" xmi:uuid="4aab8dc0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="458" y="207" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="566" y="187" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="392" y="182" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_157089_115614" xmi:uuid="dcc6a470-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642806_355312_115553"/>
      <ownedElement xmi:id="dcb80b30-915a-013c-7158-0a5172f4a469" xmi:uuid="dcb80c60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642806_355312_115553"/>
        <text>descLanguage:Language</text>
      </ownedElement>
      <ownedElement xmi:id="dcba27d0-915a-013c-7158-0a5172f4a469" xmi:uuid="dcba28e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642806_355312_115553"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_30250_115630" xmi:uuid="dcc69b50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="4c19daa0-6c45-013d-d60b-0800270c66d6" xmi:uuid="4c19db70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="528" y="298" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="510" y="307" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="315" y="301" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_90197_115615" xmi:uuid="dcfc04e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642807_840459_115554"/>
      <ownedElement xmi:id="dcd43170-915a-013c-7158-0a5172f4a469" xmi:uuid="dcd432b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642807_840459_115554"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_728767_115632" xmi:uuid="dce2afb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="4d5c8990-6c45-013d-d60b-0800270c66d6" xmi:uuid="4d5c8af0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="296" y="493" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="350" y="502" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_66241_115634" xmi:uuid="dcef76d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="4e026030-6c45-013d-d60b-0800270c66d6" xmi:uuid="4e026110-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="404" y="542" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="394" y="524" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_577848_115636" xmi:uuid="dcfbf440-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="4ebc3fd0-6c45-013d-d60b-0800270c66d6" xmi:uuid="4ebc4070-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="507" y="494" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="489" y="503" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="350" y="490" width="154" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_44007_115616" xmi:uuid="dd18ae00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642808_643043_115555"/>
      <ownedElement xmi:id="dd099290-915a-013c-7158-0a5172f4a469" xmi:uuid="dd0993c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642808_643043_115555"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="dd0bd940-915a-013c-7158-0a5172f4a469" xmi:uuid="dd0bda40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642808_643043_115555"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_489762_115638" xmi:uuid="dd189fa0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="501a7850-6c45-013d-d60b-0800270c66d6" xmi:uuid="501a7900-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="486" y="633" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="468" y="642" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="350" y="637" width="126" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_532945_115617" xmi:uuid="dd5ac200-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642809_180609_115556"/>
      <ownedElement xmi:id="dd262780-915a-013c-7158-0a5172f4a469" xmi:uuid="dd2628b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642809_180609_115556"/>
        <text>selectName:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_998885_115640" xmi:uuid="dd349ad0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="51ae3e20-6c45-013d-d60b-0800270c66d6" xmi:uuid="51ae3f00-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="282" y="703" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="336" y="712" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_158337_115642" xmi:uuid="dd412df0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="5236c750-6c45-013d-d60b-0800270c66d6" xmi:uuid="5236c910-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="551" y="703" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="533" y="712" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_424931_115644" xmi:uuid="dd4db390-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="52f79b10-6c45-013d-d60b-0800270c66d6" xmi:uuid="52f79bd0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="488" y="752" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="478" y="734" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_225088_115646" xmi:uuid="dd5ab2a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="53d57d60-6c45-013d-d60b-0800270c66d6" xmi:uuid="53d57e00-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="367" y="752" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="357" y="734" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="336" y="700" width="212" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_12589_115618" xmi:uuid="dd772270-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642810_661166_115557"/>
      <ownedElement xmi:id="dd67db70-915a-013c-7158-0a5172f4a469" xmi:uuid="dd67dc90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642810_661166_115557"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="dd6a4310-915a-013c-7158-0a5172f4a469" xmi:uuid="dd6a4710-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642810_661166_115557"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_361681_115648" xmi:uuid="dd7713c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="553fb520-6c45-013d-d60b-0800270c66d6" xmi:uuid="553fb7f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="429" y="829" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="550" y="809" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="805" width="159" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_207348_115619" xmi:uuid="dd92d260-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642811_532657_115558"/>
      <ownedElement xmi:id="dd841b10-915a-013c-7158-0a5172f4a469" xmi:uuid="dd841c30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642811_532657_115558"/>
        <text>nameLanguage:Language</text>
      </ownedElement>
      <ownedElement xmi:id="dd863bb0-915a-013c-7158-0a5172f4a469" xmi:uuid="dd863cc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642811_532657_115558"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877642875_416406_115650" xmi:uuid="dd92c950-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="56a68e60-6c45-013d-d60b-0800270c66d6" xmi:uuid="56a68f30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="543" y="907" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="525" y="916" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="329" y="910" width="204" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642876_63095_115657" xmi:uuid="dd92daf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642813_98008_115563"/>
      <source xmi:idref="_18_4_1_65b021e_1701877642875_852616_115624"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_804270_115613"/>
      <waypoint x="462" y="161"/>
      <waypoint x="462" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642876_678106_115658" xmi:uuid="dd92e9a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642813_667844_115567"/>
      <source xmi:idref="_18_4_1_65b021e_1701877642875_157089_115614"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_534783_115626"/>
      <waypoint x="357" y="301"/>
      <waypoint x="357" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642876_625335_115659" xmi:uuid="dd92f2b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642814_336057_115572"/>
      <source xmi:idref="_18_4_1_65b021e_1701877642875_44007_115616"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_66241_115634"/>
      <waypoint x="398" y="637"/>
      <waypoint x="398" y="539"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642876_359240_115660" xmi:uuid="dd92fa60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642814_461966_115577"/>
      <source xmi:idref="_18_4_1_65b021e_1701877642875_424931_115644"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_12589_115618"/>
      <waypoint x="483" y="749"/>
      <waypoint x="483" y="805"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877642876_150423_115661" xmi:uuid="dd930240-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877642814_129314_115581"/>
      <source xmi:idref="_18_4_1_65b021e_1701877642875_207348_115619"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_225088_115646"/>
      <waypoint x="364" y="910"/>
      <waypoint x="364" y="749"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877681973_197765_116065" xmi:uuid="dd930e50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877685344_171814_116066"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_804800_114395"/>
      <target xmi:idref="_18_4_1_65b021e_1701877608473_862987_115529"/>
      <waypoint x="693" y="84"/>
      <waypoint x="237" y="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877690822_435322_116086" xmi:uuid="dd9315d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877699458_964623_116087"/>
      <source xmi:idref="_18_4_1_65b021e_1701877642875_87529_115620"/>
      <target xmi:idref="_18_4_1_65b021e_1701877526193_981412_115382"/>
      <waypoint x="315" y="133"/>
      <waypoint x="235" y="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877802351_622616_116124" xmi:uuid="dd931d50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877803373_292722_116125"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_650226_114416"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_577848_115636"/>
      <waypoint x="707" y="511"/>
      <waypoint x="504" y="511"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877805721_913733_116148" xmi:uuid="dd932500-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877807208_12051_116149"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_570498_114402"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_489762_115638"/>
      <waypoint x="693" y="648"/>
      <waypoint x="483" y="648"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877814533_315650_116172" xmi:uuid="dd932d20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877815526_478179_116173"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_530240_114414"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_30250_115630"/>
      <waypoint x="707" y="312"/>
      <waypoint x="525" y="312"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877818396_830359_116196" xmi:uuid="dd933840-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877819295_425764_116197"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_529127_114407"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_527771_115628"/>
      <waypoint x="707" y="193"/>
      <waypoint x="581" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877930303_719678_116317" xmi:uuid="dd934040-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877932062_674639_116318"/>
      <source xmi:idref="_18_4_1_65b021e_1701877896553_464049_116228"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_700202_115622"/>
      <waypoint x="1057" y="137"/>
      <waypoint x="560" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877946202_125817_116353" xmi:uuid="dd9347d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877947407_123711_116354"/>
      <source xmi:idref="_18_4_1_65b021e_1701877896565_91618_116259"/>
      <target xmi:idref="_18_4_1_65b021e_1701877449651_341808_114424"/>
      <waypoint x="1057" y="721"/>
      <waypoint x="885" y="721"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877951314_55958_116375" xmi:uuid="dd934f80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877953274_824276_116376"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_59397_114422"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_158337_115642"/>
      <waypoint x="693" y="718"/>
      <waypoint x="548" y="718"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877991990_874096_116399" xmi:uuid="dd9359b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877994309_198788_116400"/>
      <source xmi:idref="_18_4_1_65b021e_1701877642875_728767_115632"/>
      <target xmi:idref="_18_4_1_65b021e_1701877526204_823576_115413"/>
      <waypoint x="350" y="508"/>
      <waypoint x="176" y="508"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878001036_994683_116418" xmi:uuid="dd9361e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878004116_553422_116419"/>
      <source xmi:idref="_18_4_1_65b021e_1701877642875_998885_115640"/>
      <target xmi:idref="_18_4_1_65b021e_1701877526212_290016_115444"/>
      <waypoint x="336" y="718"/>
      <waypoint x="204" y="718"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878027788_253174_116455" xmi:uuid="dd936990-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878030523_201531_116456"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_703211_114398"/>
      <target xmi:idref="_18_4_1_65b021e_1701878015295_948153_116428"/>
      <waypoint x="693" y="1033"/>
      <waypoint x="179" y="1033"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878080768_634980_116598" xmi:uuid="dd937120-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878083130_429404_116599"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_578395_114400"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_361681_115648"/>
      <waypoint x="693" y="816"/>
      <waypoint x="565" y="816"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701878086360_750532_116619" xmi:uuid="dd937800-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701878087544_818058_116620"/>
      <source xmi:idref="_18_4_1_65b021e_1701877449651_645390_114411"/>
      <target xmi:idref="_18_4_1_65b021e_1701877642875_416406_115650"/>
      <waypoint x="707" y="924"/>
      <waypoint x="540" y="924"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1303" height="1086"/>
    <name>SchemeVersion</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1617825998943_326731_77251" xmi:uuid="d361e9b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192893237_274389_15179"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1617826411218_279442_77787" xmi:uuid="d3624a10-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617826411209_338291_77783"/>
      <bounds x="1160" y="601" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617826514504_702259_77810" xmi:uuid="d3626070-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617826516820_744874_77811"/>
      <source xmi:idref="_18_4_1_29c0149_1617826411218_279442_77787"/>
      <target xmi:idref="_18_4_1_29c0149_1618420246577_207530_68333"/>
      <waypoint x="1160" y="609"/>
      <waypoint x="1012" y="609"/>
      <waypoint x="1012" y="644"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617826683164_936070_78548" xmi:uuid="d363d290-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617792569693_662662_62002"/>
      <ownedElement xmi:id="d3630240-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d36302a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617792569693_662662_62002"/>
        <text>AssignedScheme:Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="d3635a50-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3635ab0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617792569693_662662_62002"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617826723378_973315_78596" xmi:uuid="d363ca70-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617822702322_99778_76300"/>
        <ownedElement xmi:id="5cc24ef0-6c45-013d-d60b-0800270c66d6" xmi:uuid="5cc24fb0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617822702322_99778_76300"/>
          <bounds x="212" y="668" width="104" height="13"/>
          <text>scheme : Scheme [1]</text>
        </ownedElement>
        <bounds x="194" y="677" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="672" width="181" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617826704579_704880_78586" xmi:uuid="d363dc60-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617826705741_890246_78587"/>
      <source xmi:idref="_18_4_1_29c0149_1618420590727_819674_68726"/>
      <target xmi:idref="_18_4_1_29c0149_1617826723378_973315_78596"/>
      <waypoint x="882" y="683"/>
      <waypoint x="209" y="683"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617826745609_893630_78611" xmi:uuid="d3654e70-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617796173583_599596_62081"/>
      <ownedElement xmi:id="d3647c40-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3647ca0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617796173583_599596_62081"/>
        <text>AssignedTo:SchemeSubjectAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d364d6e0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d364d740-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617796173583_599596_62081"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617827963354_528938_78689" xmi:uuid="d36546c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
        <ownedElement xmi:id="5d7648a0-6c45-013d-d60b-0800270c66d6" xmi:uuid="5d764950-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
          <bounds x="324" y="699" width="158" height="13"/>
          <text>sss : scheme_subject_select [1]</text>
        </ownedElement>
        <bounds x="302" y="712" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="707" width="289" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617826774997_457163_78649" xmi:uuid="d3e2ee20-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617826776357_972761_78650"/>
      <source xmi:idref="_18_4_1_29c0149_1617827963354_528938_78689"/>
      <target xmi:idref="_18_4_1_29c0149_1618420590742_289855_68757"/>
      <waypoint x="317" y="718"/>
      <waypoint x="882" y="718"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618420246577_207530_68333" xmi:uuid="d3e321a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618420559698_336606_68719"/>
      <ownedElement xmi:id="d372fee0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d372ffe0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618420559698_336606_68719"/>
        <text>assign:Scheme_subject_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d37362f0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3736350-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618420559698_336606_68719"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="5e98cde0-6c45-013d-d60b-0800270c66d6" xmi:uuid="5e98cee0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5ea9da60-6c45-013d-d60b-0800270c66d6" xmi:uuid="5ea9db20-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618420590727_819674_68726" xmi:uuid="d3abf370-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_subject_assignment-assigned_activity_method"/>
          <ownedElement xmi:id="d39543e0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3954530-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_subject_assignment-assigned_activity_method"/>
            <text>assigned_activity_method:Scheme</text>
          </ownedElement>
          <ownedElement xmi:id="d3abe330-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3abe440-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_subject_assignment-assigned_activity_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="882" y="672" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618420590742_289855_68757" xmi:uuid="d3e2e230-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_subject_assignment-items"/>
          <ownedElement xmi:id="d3d20ca0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3d20e60-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_subject_assignment-items"/>
            <text>items:scheme_subject_select</text>
          </ownedElement>
          <ownedElement xmi:id="d3e2d2a0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3e2d390-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_subject_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="882" y="707" width="213" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284852149_524165_124587" xmi:uuid="de398ad0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-role"/>
          <ownedElement xmi:id="de2e1a80-915a-013c-7158-0a5172f4a469" xmi:uuid="de2e1b90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="de38eb60-915a-013c-7158-0a5172f4a469" xmi:uuid="de38ec70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="889" y="756" width="98" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="875" y="644" width="273" height="154"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702053652625_500604_110397" xmi:uuid="de3998c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509987065721_230294_25388"/>
      <bounds x="378" y="21" width="112" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284029574_344938_118994" xmi:uuid="de69cf90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
      <ownedElement xmi:id="de515990-915a-013c-7158-0a5172f4a469" xmi:uuid="de515aa0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702284029574_882212_118997" xmi:uuid="de69c4c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="655052c0-6c45-013d-d60b-0800270c66d6" xmi:uuid="65505370-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="433" y="80" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="415" y="89" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="266" y="77" width="164" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284029574_186535_118995" xmi:uuid="de9a1290-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
      <ownedElement xmi:id="de8182e0-915a-013c-7158-0a5172f4a469" xmi:uuid="de818410-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702284029574_57837_118999" xmi:uuid="de9a0780-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="675f4450-6c45-013d-d60b-0800270c66d6" xmi:uuid="675f4510-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="286" y="472" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="276" y="454" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="217" y="420" width="220" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284029574_130444_118996" xmi:uuid="dec9fb90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
      <ownedElement xmi:id="deb1bca0-915a-013c-7158-0a5172f4a469" xmi:uuid="deb1c030-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
        <text>roleSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702284029574_129912_119001" xmi:uuid="dec9f240-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="69915350-6c45-013d-d60b-0800270c66d6" xmi:uuid="699153f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="427" y="774" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="411" y="761" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="238" y="749" width="188" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284896946_720097_124667" xmi:uuid="df2837a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284898393_206571_124668"/>
      <source xmi:idref="_18_4_1_29c0149_1618420246577_207530_68333"/>
      <target xmi:idref="_18_4_1_65b021e_1702284829295_177017_123912"/>
      <waypoint x="903" y="644"/>
      <waypoint x="903" y="137"/>
      <waypoint x="750" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_388614_123901" xmi:uuid="df28b270-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829193_681808_123861"/>
      <ownedElement xmi:id="ded64490-915a-013c-7158-0a5172f4a469" xmi:uuid="ded645a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829193_681808_123861"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ded85fc0-915a-013c-7158-0a5172f4a469" xmi:uuid="ded860d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829193_681808_123861"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="6a7ed480-6c45-013d-d60b-0800270c66d6" xmi:uuid="6a7ed520-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="6a803280-6c45-013d-d60b-0800270c66d6" xmi:uuid="6a803330-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_537863_123911" xmi:uuid="def08a60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="dee4d2a0-915a-013c-7158-0a5172f4a469" xmi:uuid="dee4d3c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="deeff8c0-915a-013c-7158-0a5172f4a469" xmi:uuid="deeff9e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="567" y="91" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_177017_123912" xmi:uuid="df10c360-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="df055400-915a-013c-7158-0a5172f4a469" xmi:uuid="df055530-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="df102bd0-915a-013c-7158-0a5172f4a469" xmi:uuid="df102d00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="567" y="126" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_947529_123913" xmi:uuid="df279cf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="df1bf490-915a-013c-7158-0a5172f4a469" xmi:uuid="df1bf5c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="df2703b0-915a-013c-7158-0a5172f4a469" xmi:uuid="df2704d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="567" y="161" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="553" y="63" width="254" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_925390_123902" xmi:uuid="df2d0c40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829197_671838_123862"/>
      <ownedElement xmi:id="df2ad2e0-915a-013c-7158-0a5172f4a469" xmi:uuid="df2ad3f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829197_671838_123862"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="df2cf700-915a-013c-7158-0a5172f4a469" xmi:uuid="df2cf810-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829197_671838_123862"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="357" y="161" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284901165_300636_124688" xmi:uuid="df71a090-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284902845_165746_124689"/>
      <source xmi:idref="_18_4_1_29c0149_1618420246577_207530_68333"/>
      <target xmi:idref="_18_4_1_65b021e_1702284829295_973940_123914"/>
      <waypoint x="903" y="644"/>
      <waypoint x="903" y="256"/>
      <waypoint x="750" y="256"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_169953_123903" xmi:uuid="df7213c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
      <ownedElement xmi:id="df432dc0-915a-013c-7158-0a5172f4a469" xmi:uuid="df432fd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="df4f9840-915a-013c-7158-0a5172f4a469" xmi:uuid="df4f9970-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="70da7cc0-6c45-013d-d60b-0800270c66d6" xmi:uuid="70da7dd0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="70f710c0-6c45-013d-d60b-0800270c66d6" xmi:uuid="70f711b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_973940_123914" xmi:uuid="df710ab0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="df6588c0-915a-013c-7158-0a5172f4a469" xmi:uuid="df6589e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="df7078a0-915a-013c-7158-0a5172f4a469" xmi:uuid="df707d70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="567" y="238" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="553" y="210" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284905579_51200_124709" xmi:uuid="dfb6e500-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284907097_660790_124710"/>
      <source xmi:idref="_18_4_1_29c0149_1618420246577_207530_68333"/>
      <target xmi:idref="_18_4_1_65b021e_1702284829295_310404_123915"/>
      <waypoint x="903" y="644"/>
      <waypoint x="903" y="326"/>
      <waypoint x="751" y="326"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_364335_123904" xmi:uuid="dfb75a00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
      <ownedElement xmi:id="df883380-915a-013c-7158-0a5172f4a469" xmi:uuid="df883490-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="df945c30-915a-013c-7158-0a5172f4a469" xmi:uuid="df945d50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="74487680-6c45-013d-d60b-0800270c66d6" xmi:uuid="74487ae0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="74689b00-6c45-013d-d60b-0800270c66d6" xmi:uuid="74689bd0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_310404_123915" xmi:uuid="dfb65350-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="dfaa7ed0-915a-013c-7158-0a5172f4a469" xmi:uuid="dfaa7fe0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="dfb5b5e0-915a-013c-7158-0a5172f4a469" xmi:uuid="dfb5b6f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="567" y="315" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="553" y="287" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284909903_658255_124730" xmi:uuid="e008a9a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284911452_990933_124731"/>
      <source xmi:idref="_18_4_1_29c0149_1618420246577_207530_68333"/>
      <target xmi:idref="_18_4_1_65b021e_1702284829295_808821_123917"/>
      <waypoint x="903" y="644"/>
      <waypoint x="903" y="420"/>
      <waypoint x="742" y="420"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_958093_123905" xmi:uuid="e0091bc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829201_614361_123863"/>
      <ownedElement xmi:id="dfc386e0-915a-013c-7158-0a5172f4a469" xmi:uuid="dfc387f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829201_614361_123863"/>
        <text>smplDescAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="dfc5aa70-915a-013c-7158-0a5172f4a469" xmi:uuid="dfc5ab90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829201_614361_123863"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="771373d0-6c45-013d-d60b-0800270c66d6" xmi:uuid="77137480-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="77257110-6c45-013d-d60b-0800270c66d6" xmi:uuid="772571c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_654339_123916" xmi:uuid="dfe76d70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="dfdc1220-915a-013c-7158-0a5172f4a469" xmi:uuid="dfdc1330-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="dfe6e080-915a-013c-7158-0a5172f4a469" xmi:uuid="dfe6e480-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="567" y="441" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_808821_123917" xmi:uuid="e0081480-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="dffc09a0-915a-013c-7158-0a5172f4a469" xmi:uuid="dffc0ac0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="e0078090-915a-013c-7158-0a5172f4a469" xmi:uuid="e00781a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="567" y="406" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="553" y="378" width="287" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_733337_123906" xmi:uuid="e04d03b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
      <ownedElement xmi:id="e01f97e0-915a-013c-7158-0a5172f4a469" xmi:uuid="e01f98f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="e02b9990-915a-013c-7158-0a5172f4a469" xmi:uuid="e02b9ab0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="7becf7e0-6c45-013d-d60b-0800270c66d6" xmi:uuid="7becf890-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7bf5c2e0-6c45-013d-d60b-0800270c66d6" xmi:uuid="7bf5c3a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_615964_123918" xmi:uuid="e04cf980-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="e0416b50-915a-013c-7158-0a5172f4a469" xmi:uuid="e0416e90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="e04c6820-915a-013c-7158-0a5172f4a469" xmi:uuid="e04c6930-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="287" y="378" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="273" y="350" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_471364_123907" xmi:uuid="e073a460-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829205_289237_123864"/>
      <ownedElement xmi:id="e058ffe0-915a-013c-7158-0a5172f4a469" xmi:uuid="e0590100-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829205_289237_123864"/>
        <text>descText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="e05b34c0-915a-013c-7158-0a5172f4a469" xmi:uuid="e05b35e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829205_289237_123864"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="7e30dd90-6c45-013d-d60b-0800270c66d6" xmi:uuid="7e30de50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7e495520-6c45-013d-d60b-0800270c66d6" xmi:uuid="7e4956f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_610447_123919" xmi:uuid="e0738e50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="e067a420-915a-013c-7158-0a5172f4a469" xmi:uuid="e067a540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="e072efd0-915a-013c-7158-0a5172f4a469" xmi:uuid="e072f0e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="385" y="525" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="371" y="497" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284913889_924751_124751" xmi:uuid="e0b8bfd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284915603_746296_124752"/>
      <source xmi:idref="_18_4_1_29c0149_1618420246577_207530_68333"/>
      <target xmi:idref="_18_4_1_65b021e_1702284829295_588393_123920"/>
      <waypoint x="903" y="644"/>
      <waypoint x="903" y="620"/>
      <waypoint x="742" y="620"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_137460_123908" xmi:uuid="e0b92ad0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
      <ownedElement xmi:id="e089e190-915a-013c-7158-0a5172f4a469" xmi:uuid="e089e290-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e0961d90-915a-013c-7158-0a5172f4a469" xmi:uuid="e0961ea0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="80a276c0-6c45-013d-d60b-0800270c66d6" xmi:uuid="80a27760-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="80b45d90-6c45-013d-d60b-0800270c66d6" xmi:uuid="80b45e70-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_588393_123920" xmi:uuid="e0b82930-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="e0ac5da0-915a-013c-7158-0a5172f4a469" xmi:uuid="e0ac5ec0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="e0b75cd0-915a-013c-7158-0a5172f4a469" xmi:uuid="e0b75f00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="567" y="602" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="553" y="574" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284922958_428099_124796" xmi:uuid="e0fd24e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284924778_479329_124797"/>
      <source xmi:idref="_18_4_1_29c0149_1618420246577_207530_68333"/>
      <target xmi:idref="_18_4_1_65b021e_1702284829295_927337_123921"/>
      <waypoint x="907" y="798"/>
      <waypoint x="907" y="844"/>
      <waypoint x="751" y="844"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_603660_123909" xmi:uuid="e0fd9540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
      <ownedElement xmi:id="e0cef5f0-915a-013c-7158-0a5172f4a469" xmi:uuid="e0cef6e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e0dac860-915a-013c-7158-0a5172f4a469" xmi:uuid="e0dac970-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="83af70c0-6c45-013d-d60b-0800270c66d6" xmi:uuid="83af7290-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="83cdf290-6c45-013d-d60b-0800270c66d6" xmi:uuid="83cdf370-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_927337_123921" xmi:uuid="e0fc89a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="e0f0c230-915a-013c-7158-0a5172f4a469" xmi:uuid="e0f0c350-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e0fbf100-915a-013c-7158-0a5172f4a469" xmi:uuid="e0fbf210-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="567" y="833" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="553" y="805" width="246" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829294_436726_123910" xmi:uuid="e1268c50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829209_855032_123865"/>
      <ownedElement xmi:id="e10b5a70-915a-013c-7158-0a5172f4a469" xmi:uuid="e10b5b80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829209_855032_123865"/>
        <text>default:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_756788_123922" xmi:uuid="e1199e50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="86c9b5e0-6c45-013d-d60b-0800270c66d6" xmi:uuid="86c9b6d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="499" y="752" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="553" y="761" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_111963_123924" xmi:uuid="e1268240-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="87672430-6c45-013d-d60b-0800270c66d6" xmi:uuid="876724d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="717" y="750" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="699" y="759" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="553" y="749" width="161" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_810976_123926" xmi:uuid="e1269820-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829213_986271_123869"/>
      <source xmi:idref="_18_4_1_65b021e_1702284829295_947529_123913"/>
      <target xmi:idref="_18_4_1_65b021e_1702284829294_925390_123902"/>
      <waypoint x="567" y="172"/>
      <waypoint x="491" y="172"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_283473_123927" xmi:uuid="e126a090-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829213_688014_123877"/>
      <source xmi:idref="_18_4_1_65b021e_1702284829295_615964_123918"/>
      <target xmi:idref="_18_4_1_65b021e_1702284829294_471364_123907"/>
      <waypoint x="508" y="403"/>
      <waypoint x="508" y="497"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284829295_245679_123928" xmi:uuid="e126a9c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284829213_637305_123878"/>
      <source xmi:idref="_18_4_1_65b021e_1702284829295_654339_123916"/>
      <target xmi:idref="_18_4_1_65b021e_1702284829294_471364_123907"/>
      <waypoint x="623" y="466"/>
      <waypoint x="623" y="529"/>
      <waypoint x="558" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284894327_794679_124643" xmi:uuid="e126b2a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284895591_457619_124644"/>
      <source xmi:idref="_18_4_1_65b021e_1702284829294_537863_123911"/>
      <target xmi:idref="_18_4_1_65b021e_1702284029574_882212_118997"/>
      <waypoint x="567" y="98"/>
      <waypoint x="430" y="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284918906_430983_124772" xmi:uuid="e126be20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284920072_206566_124773"/>
      <source xmi:idref="_18_4_1_65b021e_1702284852149_524165_124587"/>
      <target xmi:idref="_18_4_1_65b021e_1702284829295_111963_123924"/>
      <waypoint x="889" y="767"/>
      <waypoint x="714" y="767"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284927529_330633_124817" xmi:uuid="e126c660-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284928811_928231_124818"/>
      <source xmi:idref="_18_4_1_65b021e_1702284829295_756788_123922"/>
      <target xmi:idref="_18_4_1_65b021e_1702284029574_129912_119001"/>
      <waypoint x="553" y="770"/>
      <waypoint x="426" y="770"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284932183_47538_124841" xmi:uuid="e126cf80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284933713_291896_124842"/>
      <source xmi:idref="_18_4_1_65b021e_1702284829295_610447_123919"/>
      <target xmi:idref="_18_4_1_65b021e_1702284029574_57837_118999"/>
      <waypoint x="385" y="536"/>
      <waypoint x="284" y="536"/>
      <waypoint x="284" y="469"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1163" height="883"/>
    <name>SchemeSubjectAssignment</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1617818940332_230570_69903" xmi:uuid="d3e353d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1617821346329_997793_75298" xmi:uuid="d3e3fa20-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617821346318_436691_75294"/>
      <bounds x="1320" y="40" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617821529707_49294_75319" xmi:uuid="d3e43df0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617821531415_662057_75320"/>
      <source xmi:idref="_18_4_1_29c0149_1618416362390_85013_67533"/>
      <target xmi:idref="_18_4_1_29c0149_1617821346329_997793_75298"/>
      <waypoint x="1274" y="91"/>
      <waypoint x="1274" y="49"/>
      <waypoint x="1320" y="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618416362390_85013_67533" xmi:uuid="d3fdc030-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416373785_139876_67564"/>
      <ownedElement xmi:id="d3fcf4d0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3fcf620-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416373785_139876_67564"/>
        <text>theSchemeEntry:Scheme_entry</text>
      </ownedElement>
      <ownedElement xmi:id="d3fd9b10-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3fd9bc0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416373785_139876_67564"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="8bb2bd80-6c45-013d-d60b-0800270c66d6" xmi:uuid="8bb2be60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="8bb50b50-6c45-013d-d60b-0800270c66d6" xmi:uuid="8bb50c80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876866287_524172_112017" xmi:uuid="e1741440-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-description"/>
          <ownedElement xmi:id="e16871d0-915a-013c-7158-0a5172f4a469" xmi:uuid="e16872c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="e1738410-915a-013c-7158-0a5172f4a469" xmi:uuid="e1738520-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1127" y="126" width="150" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876866298_1368_112048" xmi:uuid="e18b25a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
          <ownedElement xmi:id="e17f9930-915a-013c-7158-0a5172f4a469" xmi:uuid="e17f9a40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="e18a8bc0-915a-013c-7158-0a5172f4a469" xmi:uuid="e18a8cd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1127" y="665" width="107" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1106" y="91" width="202" height="609"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876794548_494124_111854" xmi:uuid="e1a7d880-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598865_325239_106576"/>
      <ownedElement xmi:id="e19869d0-915a-013c-7158-0a5172f4a469" xmi:uuid="e1986af0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598865_325239_106576"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="e19a89e0-915a-013c-7158-0a5172f4a469" xmi:uuid="e19a8b10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598865_325239_106576"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701876896746_971766_112085" xmi:uuid="e1a7c9c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="8f121480-6c45-013d-d60b-0800270c66d6" xmi:uuid="8f121560-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="240" y="59" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="222" y="68" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="56" width="195" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876794558_17914_111885" xmi:uuid="e1b74e80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598867_453218_106577"/>
      <ownedElement xmi:id="e1b4fa80-915a-013c-7158-0a5172f4a469" xmi:uuid="e1b4fb60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598867_453218_106577"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e1b73430-915a-013c-7158-0a5172f4a469" xmi:uuid="e1b737d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598867_453218_106577"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="119" width="200" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876794566_271895_111916" xmi:uuid="e1c68e30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598868_473149_106578"/>
      <ownedElement xmi:id="e1c441d0-915a-013c-7158-0a5172f4a469" xmi:uuid="e1c442e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598868_473149_106578"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e1c66ba0-915a-013c-7158-0a5172f4a469" xmi:uuid="e1c66fc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598868_473149_106578"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="448" width="141" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876794575_305636_111947" xmi:uuid="e1d67200-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598869_996881_106579"/>
      <ownedElement xmi:id="e1d42500-915a-013c-7158-0a5172f4a469" xmi:uuid="e1d42630-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598869_996881_106579"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e1d65ed0-915a-013c-7158-0a5172f4a469" xmi:uuid="e1d65fd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598869_996881_106579"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="665" width="169" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876794682_948862_111978" xmi:uuid="e1f38d00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598870_944740_106580"/>
      <ownedElement xmi:id="e1e3bf60-915a-013c-7158-0a5172f4a469" xmi:uuid="e1e3c080-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598870_944740_106580"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="e1e5f7a0-915a-013c-7158-0a5172f4a469" xmi:uuid="e1e5f8c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701874598870_944740_106580"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701876910399_890593_112101" xmi:uuid="e1f38260-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="927bb8e0-6c45-013d-d60b-0800270c66d6" xmi:uuid="927bb990-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="175" y="984" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="157" y="993" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="980" width="130" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877074856_724938_113812" xmi:uuid="e227cf20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877076812_355852_113813"/>
      <source xmi:idref="_18_4_1_29c0149_1618416362390_85013_67533"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_414707_112348"/>
      <waypoint x="1106" y="200"/>
      <waypoint x="980" y="200"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978917_926510_112335" xmi:uuid="e228c110-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957625_401431_112187"/>
      <ownedElement xmi:id="e200b540-915a-013c-7158-0a5172f4a469" xmi:uuid="e200b660-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957625_401431_112187"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e20306e0-915a-013c-7158-0a5172f4a469" xmi:uuid="e2030830-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957625_401431_112187"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="93554830-6c45-013d-d60b-0800270c66d6" xmi:uuid="93554a50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="936760b0-6c45-013d-d60b-0800270c66d6" xmi:uuid="93676360-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_414707_112348" xmi:uuid="e22743e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="e21b62b0-915a-013c-7158-0a5172f4a469" xmi:uuid="e21b63e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="e226aa90-915a-013c-7158-0a5172f4a469" xmi:uuid="e226aba0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="182" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="154" width="293" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877211566_561338_114129" xmi:uuid="e25c3d40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877215864_719439_114130"/>
      <source xmi:idref="_18_4_1_29c0149_1618416362390_85013_67533"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_996291_112349"/>
      <waypoint x="1106" y="95"/>
      <waypoint x="989" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_217357_112336" xmi:uuid="e25cf510-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957626_163373_112188"/>
      <ownedElement xmi:id="e235f5b0-915a-013c-7158-0a5172f4a469" xmi:uuid="e235fa80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957626_163373_112188"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e23832c0-915a-013c-7158-0a5172f4a469" xmi:uuid="e2383400-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957626_163373_112188"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="95827930-6c45-013d-d60b-0800270c66d6" xmi:uuid="958279d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="959492d0-6c45-013d-d60b-0800270c66d6" xmi:uuid="959493c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_996291_112349" xmi:uuid="e25b87e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="e24fb150-915a-013c-7158-0a5172f4a469" xmi:uuid="e24fb380-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e25adfc0-915a-013c-7158-0a5172f4a469" xmi:uuid="e25ae140-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="84" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="56" width="282" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877117152_464903_114019" xmi:uuid="e2c803d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877120398_900727_114020"/>
      <source xmi:idref="_18_4_1_29c0149_1618416362390_85013_67533"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_592176_112351"/>
      <waypoint x="1145" y="700"/>
      <waypoint x="1145" y="844"/>
      <waypoint x="1033" y="844"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_49913_112337" xmi:uuid="e2c8ba40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957627_144688_112189"/>
      <ownedElement xmi:id="e26a6370-915a-013c-7158-0a5172f4a469" xmi:uuid="e26a64b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957627_144688_112189"/>
        <text>nameLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="e26caa20-915a-013c-7158-0a5172f4a469" xmi:uuid="e26cac50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957627_144688_112189"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="97f096b0-6c45-013d-d60b-0800270c66d6" xmi:uuid="97f09750-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="97f236a0-6c45-013d-d60b-0800270c66d6" xmi:uuid="97f237b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_247791_112350" xmi:uuid="e2860aa0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="e27a1590-915a-013c-7158-0a5172f4a469" xmi:uuid="e27a16c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="e2857360-915a-013c-7158-0a5172f4a469" xmi:uuid="e2857470-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="805" y="903" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_592176_112351" xmi:uuid="e2a6a600-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="e29ad860-915a-013c-7158-0a5172f4a469" xmi:uuid="e29ad980-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="e2a60100-915a-013c-7158-0a5172f4a469" xmi:uuid="e2a604d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="833" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_791620_112352" xmi:uuid="e2c76bf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="e2bbab40-915a-013c-7158-0a5172f4a469" xmi:uuid="e2bbac50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="e2c6c890-915a-013c-7158-0a5172f4a469" xmi:uuid="e2c6c9b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="868" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="805" width="273" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877084453_866823_113857" xmi:uuid="e3330440-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877085988_675587_113858"/>
      <source xmi:idref="_18_4_1_29c0149_1618416362390_85013_67533"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_88043_112354"/>
      <waypoint x="1106" y="277"/>
      <waypoint x="1033" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_633131_112338" xmi:uuid="e333bed0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957628_543348_112190"/>
      <ownedElement xmi:id="e2d51c40-915a-013c-7158-0a5172f4a469" xmi:uuid="e2d52190-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957628_543348_112190"/>
        <text>descLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="e2d74170-915a-013c-7158-0a5172f4a469" xmi:uuid="e2d74280-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957628_543348_112190"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="9d1e8400-6c45-013d-d60b-0800270c66d6" xmi:uuid="9d1e84a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="9d1fb920-6c45-013d-d60b-0800270c66d6" xmi:uuid="9d1fb9f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_2416_112353" xmi:uuid="e2ef87c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="e2e39d90-915a-013c-7158-0a5172f4a469" xmi:uuid="e2e39eb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="e2eee460-915a-013c-7158-0a5172f4a469" xmi:uuid="e2eee580-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="805" y="336" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_88043_112354" xmi:uuid="e310a970-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="e304d7f0-915a-013c-7158-0a5172f4a469" xmi:uuid="e304d930-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="e31005d0-915a-013c-7158-0a5172f4a469" xmi:uuid="e31006e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="266" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_161488_112355" xmi:uuid="e3325d00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="e3265d80-915a-013c-7158-0a5172f4a469" xmi:uuid="e3265fa0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="e331b670-915a-013c-7158-0a5172f4a469" xmi:uuid="e331b7d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="301" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="238" width="269" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877130587_643672_114061" xmi:uuid="e366a5c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877133745_453332_114062"/>
      <source xmi:idref="_18_4_1_29c0149_1618416362390_85013_67533"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_780616_112356"/>
      <waypoint x="1145" y="700"/>
      <waypoint x="1145" y="1008"/>
      <waypoint x="1028" y="1008"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_776414_112339" xmi:uuid="e3675a20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957629_362522_112191"/>
      <ownedElement xmi:id="e33fd9c0-915a-013c-7158-0a5172f4a469" xmi:uuid="e33fdae0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957629_362522_112191"/>
        <text>sameAsAsgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="e3420d40-915a-013c-7158-0a5172f4a469" xmi:uuid="e3421010-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957629_362522_112191"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a2070f30-6c45-013d-d60b-0800270c66d6" xmi:uuid="a2070ff0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a217c200-6c45-013d-d60b-0800270c66d6" xmi:uuid="a217c2d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_780616_112356" xmi:uuid="e3660800-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="e359de80-915a-013c-7158-0a5172f4a469" xmi:uuid="e359dfb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e3655270-915a-013c-7158-0a5172f4a469" xmi:uuid="e3655380-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="994" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="966" width="268" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877096405_984429_113926" xmi:uuid="e3c6d2c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877098754_325610_113927"/>
      <source xmi:idref="_18_4_1_29c0149_1618416362390_85013_67533"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_654743_112358"/>
      <waypoint x="1106" y="494"/>
      <waypoint x="988" y="494"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_468630_112340" xmi:uuid="e3c78590-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957629_978045_112192"/>
      <ownedElement xmi:id="e373a5e0-915a-013c-7158-0a5172f4a469" xmi:uuid="e373a7e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957629_978045_112192"/>
        <text>simpleIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e375e3f0-915a-013c-7158-0a5172f4a469" xmi:uuid="e375e500-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957629_978045_112192"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="a4596470-6c45-013d-d60b-0800270c66d6" xmi:uuid="a4596560-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a46f1770-6c45-013d-d60b-0800270c66d6" xmi:uuid="a46f1830-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_719753_112357" xmi:uuid="e38e2930-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="e382a460-915a-013c-7158-0a5172f4a469" xmi:uuid="e382a570-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="e38d91a0-915a-013c-7158-0a5172f4a469" xmi:uuid="e38d92c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="805" y="448" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_654743_112358" xmi:uuid="e3af0170-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="e3a36960-915a-013c-7158-0a5172f4a469" xmi:uuid="e3a36a70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e3ae6e90-915a-013c-7158-0a5172f4a469" xmi:uuid="e3ae6fb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="483" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_239965_112359" xmi:uuid="e3c62e80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="e3ba58c0-915a-013c-7158-0a5172f4a469" xmi:uuid="e3ba59d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="e3c591d0-915a-013c-7158-0a5172f4a469" xmi:uuid="e3c59560-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="805" y="518" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="420" width="263" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_756010_112341" xmi:uuid="e3f8ef50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957630_209892_112193"/>
      <ownedElement xmi:id="e3d3bcd0-915a-013c-7158-0a5172f4a469" xmi:uuid="e3d3bdf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957630_209892_112193"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e3d5ed00-915a-013c-7158-0a5172f4a469" xmi:uuid="e3d5ee20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957630_209892_112193"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a8ba80f0-6c45-013d-d60b-0800270c66d6" xmi:uuid="a8ba8190-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a8cba7d0-6c45-013d-d60b-0800270c66d6" xmi:uuid="a8cba8f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_598670_112360" xmi:uuid="e3f8dcc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="e3ec3c90-915a-013c-7158-0a5172f4a469" xmi:uuid="e3ec4240-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="e3f83d50-915a-013c-7158-0a5172f4a469" xmi:uuid="e3f83e70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="763" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="735" width="262" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877123362_581743_114040" xmi:uuid="e42a2ae0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877127197_651997_114041"/>
      <source xmi:idref="_18_4_1_29c0149_1618416362390_85013_67533"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_582631_112362"/>
      <waypoint x="1106" y="602"/>
      <waypoint x="988" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_836598_112343" xmi:uuid="e42ad830-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957631_611301_112195"/>
      <ownedElement xmi:id="e4055440-915a-013c-7158-0a5172f4a469" xmi:uuid="e4055550-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957631_611301_112195"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e4078840-915a-013c-7158-0a5172f4a469" xmi:uuid="e4078950-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957631_611301_112195"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="aac03e10-6c45-013d-d60b-0800270c66d6" xmi:uuid="aac03e80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="aac17560-6c45-013d-d60b-0800270c66d6" xmi:uuid="aac17620-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_582631_112362" xmi:uuid="e42993b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="e41de390-915a-013c-7158-0a5172f4a469" xmi:uuid="e41de4b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e428f480-915a-013c-7158-0a5172f4a469" xmi:uuid="e428f5a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="595" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="567" width="226" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_734911_112344" xmi:uuid="e453c520-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957632_17804_112196"/>
      <ownedElement xmi:id="e4387da0-915a-013c-7158-0a5172f4a469" xmi:uuid="e4387eb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957632_17804_112196"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_208737_112363" xmi:uuid="e446fe00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="ada3fb40-6c45-013d-d60b-0800270c66d6" xmi:uuid="ada3fbe0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="737" y="661" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="791" y="670" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_770105_112365" xmi:uuid="e453baf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="ae32b550-6c45-013d-d60b-0800270c66d6" xmi:uuid="ae32b5f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="986" y="663" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="968" y="672" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="791" y="658" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_216233_112345" xmi:uuid="e4583620-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957633_499401_112197"/>
      <ownedElement xmi:id="e455df40-915a-013c-7158-0a5172f4a469" xmi:uuid="e455e470-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957633_499401_112197"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="e4581e10-915a-013c-7158-0a5172f4a469" xmi:uuid="e45821b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957633_499401_112197"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="567" y="903" width="207" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_809970_112346" xmi:uuid="e45ca690-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957634_206915_112198"/>
      <ownedElement xmi:id="e45a5990-915a-013c-7158-0a5172f4a469" xmi:uuid="e45a5a90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957634_206915_112198"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="e45c93c0-915a-013c-7158-0a5172f4a469" xmi:uuid="e45c94d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957634_206915_112198"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="637" y="518" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_137822_112347" xmi:uuid="e460ec90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957634_170783_112199"/>
      <ownedElement xmi:id="e45ec580-915a-013c-7158-0a5172f4a469" xmi:uuid="e45ec690-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957634_170783_112199"/>
        <text>descAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="e460d8c0-915a-013c-7158-0a5172f4a469" xmi:uuid="e460d9e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957634_170783_112199"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="546" y="336" width="223" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_851410_112367" xmi:uuid="e460f6b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957639_54224_112242"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_247791_112350"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_216233_112345"/>
      <waypoint x="805" y="915"/>
      <waypoint x="774" y="915"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978918_465828_112368" xmi:uuid="e4610210-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957639_532038_112247"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_239965_112359"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_809970_112346"/>
      <waypoint x="805" y="530"/>
      <waypoint x="771" y="530"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701876978919_196559_112369" xmi:uuid="e4610c90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701876957640_951565_112252"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_2416_112353"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_137822_112347"/>
      <waypoint x="805" y="347"/>
      <waypoint x="769" y="347"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_6654_113315" xmi:uuid="e4a3a230-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019950_771413_113254"/>
      <ownedElement xmi:id="e46ed260-915a-013c-7158-0a5172f4a469" xmi:uuid="e46ed380-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019950_771413_113254"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_331604_113323" xmi:uuid="e47d2680-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="b0337130-6c45-013d-d60b-0800270c66d6" xmi:uuid="b03371f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="366" y="115" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="420" y="124" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_699203_113325" xmi:uuid="e489f7c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b0e4ca70-6c45-013d-d60b-0800270c66d6" xmi:uuid="b0e4cb10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="668" y="119" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="650" y="128" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_341860_113327" xmi:uuid="e496b710-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="b15f1a60-6c45-013d-d60b-0800270c66d6" xmi:uuid="b15f1b10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="572" y="164" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="562" y="146" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_397682_113329" xmi:uuid="e4a398a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="b1e7daa0-6c45-013d-d60b-0800270c66d6" xmi:uuid="b1e7db40-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="465" y="164" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="455" y="146" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="420" y="112" width="245" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_870131_113316" xmi:uuid="e4c09990-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019951_696360_113255"/>
      <ownedElement xmi:id="e4b0e7e0-915a-013c-7158-0a5172f4a469" xmi:uuid="e4b0e8f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019951_696360_113255"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="e4b32450-915a-013c-7158-0a5172f4a469" xmi:uuid="e4b32560-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019951_696360_113255"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_673471_113331" xmi:uuid="e4c08bb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="b33f3720-6c45-013d-d60b-0800270c66d6" xmi:uuid="b33f37d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="563" y="207" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="671" y="187" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="182" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_518892_113317" xmi:uuid="e4de4710-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019952_787358_113256"/>
      <ownedElement xmi:id="e4cecb30-915a-013c-7158-0a5172f4a469" xmi:uuid="e4cecc50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019952_787358_113256"/>
        <text>descLanguage:Language</text>
      </ownedElement>
      <ownedElement xmi:id="e4d107e0-915a-013c-7158-0a5172f4a469" xmi:uuid="e4d10900-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019952_787358_113256"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_75678_113333" xmi:uuid="e4de3a30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="b4ac03d0-6c45-013d-d60b-0800270c66d6" xmi:uuid="b4ac04b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="633" y="298" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="615" y="307" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="420" y="301" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_539501_113318" xmi:uuid="e5148fb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019953_562407_113257"/>
      <ownedElement xmi:id="e4ec2cb0-915a-013c-7158-0a5172f4a469" xmi:uuid="e4ec2f10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019953_562407_113257"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_651293_113335" xmi:uuid="e4fa9a40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="b5c33d30-6c45-013d-d60b-0800270c66d6" xmi:uuid="b5c33de0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="401" y="444" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="455" y="453" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_894611_113337" xmi:uuid="e5079650-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="b65aa220-6c45-013d-d60b-0800270c66d6" xmi:uuid="b65aa2c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="509" y="493" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="499" y="475" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_504942_113339" xmi:uuid="e5148560-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="b6c79860-6c45-013d-d60b-0800270c66d6" xmi:uuid="b6c79920-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="612" y="445" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="594" y="454" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="455" y="441" width="154" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_933901_113319" xmi:uuid="e5310e10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019954_580521_113258"/>
      <ownedElement xmi:id="e521cec0-915a-013c-7158-0a5172f4a469" xmi:uuid="e521cfd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019954_580521_113258"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="e523f160-915a-013c-7158-0a5172f4a469" xmi:uuid="e523f390-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019954_580521_113258"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_29082_113341" xmi:uuid="e53104e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="b7f48820-6c45-013d-d60b-0800270c66d6" xmi:uuid="b7f488c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="591" y="584" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="573" y="593" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="455" y="588" width="126" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_369960_113320" xmi:uuid="e57454e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019955_480249_113259"/>
      <ownedElement xmi:id="e53f1300-915a-013c-7158-0a5172f4a469" xmi:uuid="e53f1410-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019955_480249_113259"/>
        <text>selectName:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_600142_113343" xmi:uuid="e54ddfe0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="b94313c0-6c45-013d-d60b-0800270c66d6" xmi:uuid="b9431470-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="380" y="661" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="434" y="670" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_803991_113345" xmi:uuid="e55aa710-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b9cc8b40-6c45-013d-d60b-0800270c66d6" xmi:uuid="b9cc8ea0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="649" y="661" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="631" y="670" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_31816_113347" xmi:uuid="e5678f70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="ba6a1d30-6c45-013d-d60b-0800270c66d6" xmi:uuid="ba6a1e10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="586" y="710" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="576" y="692" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_181133_113349" xmi:uuid="e5744a60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="bafa5890-6c45-013d-d60b-0800270c66d6" xmi:uuid="bafa5920-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="465" y="710" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="455" y="692" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="434" y="658" width="212" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_458778_113321" xmi:uuid="e59050e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019956_613838_113260"/>
      <ownedElement xmi:id="e5819e30-915a-013c-7158-0a5172f4a469" xmi:uuid="e5819f50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019956_613838_113260"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="e583b3d0-915a-013c-7158-0a5172f4a469" xmi:uuid="e583b630-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019956_613838_113260"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_370074_113351" xmi:uuid="e59049b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="bc77e330-6c45-013d-d60b-0800270c66d6" xmi:uuid="bc77e3d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="527" y="787" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="648" y="767" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="763" width="159" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020007_671979_113322" xmi:uuid="e5ac5630-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019957_143614_113261"/>
      <ownedElement xmi:id="e59da940-915a-013c-7158-0a5172f4a469" xmi:uuid="e59daa50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019957_143614_113261"/>
        <text>nameLanguage:Language</text>
      </ownedElement>
      <ownedElement xmi:id="e59fcf10-915a-013c-7158-0a5172f4a469" xmi:uuid="e59fd020-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019957_143614_113261"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_256075_113353" xmi:uuid="e5ac4c80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="bda70650-6c45-013d-d60b-0800270c66d6" xmi:uuid="bda70700-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="641" y="865" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="623" y="874" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="427" y="868" width="204" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_858812_113360" xmi:uuid="e5ac5f10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019958_567047_113266"/>
      <source xmi:idref="_18_4_1_65b021e_1701877020007_341860_113327"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020007_870131_113316"/>
      <waypoint x="567" y="161"/>
      <waypoint x="567" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_129368_113361" xmi:uuid="e5ac6ac0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019958_40803_113270"/>
      <source xmi:idref="_18_4_1_65b021e_1701877020007_518892_113317"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020007_397682_113329"/>
      <waypoint x="462" y="301"/>
      <waypoint x="462" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_384870_113362" xmi:uuid="e5ac7370-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019958_974441_113275"/>
      <source xmi:idref="_18_4_1_65b021e_1701877020007_933901_113319"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020008_894611_113337"/>
      <waypoint x="503" y="588"/>
      <waypoint x="503" y="490"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_919387_113363" xmi:uuid="e5ac7c00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019959_706886_113280"/>
      <source xmi:idref="_18_4_1_65b021e_1701877020008_31816_113347"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020007_458778_113321"/>
      <waypoint x="581" y="707"/>
      <waypoint x="581" y="763"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877020008_135727_113364" xmi:uuid="e5ac85b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877019959_861489_113284"/>
      <source xmi:idref="_18_4_1_65b021e_1701877020007_671979_113322"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020008_181133_113349"/>
      <waypoint x="462" y="868"/>
      <waypoint x="462" y="707"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877066008_881208_113767" xmi:uuid="e5ac9220-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877067460_24426_113768"/>
      <source xmi:idref="_18_4_1_65b021e_1701876866287_524172_112017"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020007_699203_113325"/>
      <waypoint x="1127" y="137"/>
      <waypoint x="665" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877070551_35998_113791" xmi:uuid="e5ac9a00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877072502_496144_113792"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978917_926510_112335"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020007_673471_113331"/>
      <waypoint x="791" y="196"/>
      <waypoint x="686" y="196"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877081074_170209_113833" xmi:uuid="e5aca3f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877082096_670603_113834"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_161488_112355"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020007_75678_113333"/>
      <waypoint x="805" y="315"/>
      <waypoint x="630" y="315"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877089782_867589_113878" xmi:uuid="e5acad20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877090800_437864_113879"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_719753_112357"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020008_504942_113339"/>
      <waypoint x="805" y="462"/>
      <waypoint x="609" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877092846_50332_113902" xmi:uuid="e5acb930-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877093818_737601_113903"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_836598_112343"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020008_29082_113341"/>
      <waypoint x="791" y="599"/>
      <waypoint x="588" y="599"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877102791_645408_113947" xmi:uuid="e5acc250-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877104236_204666_113948"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_208737_112363"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020008_803991_113345"/>
      <waypoint x="791" y="679"/>
      <waypoint x="646" y="679"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877108678_378859_113971" xmi:uuid="e5acca80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877110094_419054_113972"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_598670_112360"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020008_370074_113351"/>
      <waypoint x="805" y="774"/>
      <waypoint x="663" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877113359_248724_113995" xmi:uuid="e5acd360-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877114528_870337_113996"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_791620_112352"/>
      <target xmi:idref="_18_4_1_65b021e_1701877020008_256075_113353"/>
      <waypoint x="805" y="882"/>
      <waypoint x="638" y="882"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877173567_375259_114101" xmi:uuid="e5ace2c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877174531_504147_114102"/>
      <source xmi:idref="_18_4_1_65b021e_1701876866298_1368_112048"/>
      <target xmi:idref="_18_4_1_65b021e_1701876978918_770105_112365"/>
      <waypoint x="1127" y="679"/>
      <waypoint x="983" y="679"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877227821_413248_114148" xmi:uuid="e5aceac0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877229785_241812_114149"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_217357_112336"/>
      <target xmi:idref="_18_4_1_65b021e_1701876896746_971766_112085"/>
      <waypoint x="791" y="74"/>
      <waypoint x="237" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877239547_292797_114167" xmi:uuid="e5acf330-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877242429_472445_114168"/>
      <source xmi:idref="_18_4_1_65b021e_1701877020007_331604_113323"/>
      <target xmi:idref="_18_4_1_65b021e_1701876794558_17914_111885"/>
      <waypoint x="420" y="130"/>
      <waypoint x="235" y="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877256148_225727_114188" xmi:uuid="e5acfd30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877257954_670877_114189"/>
      <source xmi:idref="_18_4_1_65b021e_1701877020007_651293_113335"/>
      <target xmi:idref="_18_4_1_65b021e_1701876794566_271895_111916"/>
      <waypoint x="455" y="459"/>
      <waypoint x="176" y="459"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877270437_506787_114209" xmi:uuid="e5ad0e60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877272106_992403_114210"/>
      <source xmi:idref="_18_4_1_65b021e_1701877020008_600142_113343"/>
      <target xmi:idref="_18_4_1_65b021e_1701876794575_305636_111947"/>
      <waypoint x="434" y="676"/>
      <waypoint x="204" y="676"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1701877282476_753174_114228" xmi:uuid="e5ad1870-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1701877285132_532676_114229"/>
      <source xmi:idref="_18_4_1_65b021e_1701876978918_776414_112339"/>
      <target xmi:idref="_18_4_1_65b021e_1701876910399_890593_112101"/>
      <waypoint x="791" y="1001"/>
      <waypoint x="172" y="1001"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1323" height="1044"/>
    <name>SchemeEntry</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1617823883572_914156_76490" xmi:uuid="d3fde8e0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201153286_596027_16081"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1618414246810_729588_67273" xmi:uuid="d3fe83d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618414246795_370801_67269"/>
      <bounds x="1125" y="460" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617824339934_201445_76746" xmi:uuid="d3fe9fb0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617824341024_758362_76747"/>
      <source xmi:idref="_18_4_1_29c0149_1618425621581_101804_69681"/>
      <target xmi:idref="_18_4_1_29c0149_1618414246810_729588_67273"/>
      <waypoint x="1064" y="504"/>
      <waypoint x="1064" y="466"/>
      <waypoint x="1125" y="466"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617824462964_923381_76753" xmi:uuid="d40146d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815130629_845371_69131"/>
      <ownedElement xmi:id="d3ffc290-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d3ffc340-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815130629_845371_69131"/>
        <text>Related:SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="d4007250-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d4007340-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815130629_845371_69131"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617824496706_329940_76877" xmi:uuid="d40139c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617821346318_436691_75294"/>
        <ownedElement xmi:id="ce180a60-6c45-013d-d60b-0800270c66d6" xmi:uuid="ce180b00-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617821346318_436691_75294"/>
          <bounds x="188" y="618" width="121" height="13"/>
          <text>entry : Scheme_entry [1]</text>
        </ownedElement>
        <bounds x="170" y="627" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="623" width="157" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617824462974_178627_76784" xmi:uuid="d405a470-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815146464_732962_69141"/>
      <ownedElement xmi:id="d4031460-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d40315b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815146464_732962_69141"/>
        <text>Relating:SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="d4044080-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d40441d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617815146464_732962_69141"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617824542360_257371_76889" xmi:uuid="d4058d80-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617821346318_436691_75294"/>
        <ownedElement xmi:id="ce9dd080-6c45-013d-d60b-0800270c66d6" xmi:uuid="ce9dd120-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617821346318_436691_75294"/>
          <bounds x="196" y="671" width="121" height="13"/>
          <text>entry : Scheme_entry [1]</text>
        </ownedElement>
        <bounds x="174" y="663" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="658" width="161" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617824568383_39703_76908" xmi:uuid="d405c370-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617824569654_980195_76909"/>
      <source xmi:idref="_18_4_1_29c0149_1618425672779_356823_69719"/>
      <target xmi:idref="_18_4_1_29c0149_1617824496706_329940_76877"/>
      <waypoint x="896" y="634"/>
      <waypoint x="185" y="634"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617824587705_268152_76928" xmi:uuid="d405e5d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617824589566_542421_76929"/>
      <source xmi:idref="_18_4_1_29c0149_1618425672790_403068_69750"/>
      <target xmi:idref="_18_4_1_29c0149_1617824542360_257371_76889"/>
      <waypoint x="896" y="669"/>
      <waypoint x="189" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618425621581_101804_69681" xmi:uuid="d4913830-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425633091_431491_69712"/>
      <ownedElement xmi:id="d422afd0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d422b0e0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425633091_431491_69712"/>
        <text>relate:Scheme_entry_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d42321f0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d4232260-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425633091_431491_69712"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="cf570810-6c45-013d-d60b-0800270c66d6" xmi:uuid="cf5708c0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="cf585810-6c45-013d-d60b-0800270c66d6" xmi:uuid="cf5858f0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618425672779_356823_69719" xmi:uuid="d4527a60-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_relationship-related_method"/>
          <ownedElement xmi:id="d440ce40-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d440cf40-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_relationship-related_method"/>
            <text>related_method:Scheme_entry</text>
          </ownedElement>
          <ownedElement xmi:id="d4526c20-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d4526d10-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_relationship-related_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="896" y="623" width="207" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618425672790_403068_69750" xmi:uuid="d4911740-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_relationship-relating_method"/>
          <ownedElement xmi:id="d474a090-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d474a1a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_relationship-relating_method"/>
            <text>relating_method:Scheme_entry</text>
          </ownedElement>
          <ownedElement xmi:id="d490fbc0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d490fde0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_entry_relationship-relating_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="896" y="658" width="210" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286437486_841730_126389" xmi:uuid="e726c520-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-description"/>
          <ownedElement xmi:id="e71ae090-915a-013c-7158-0a5172f4a469" xmi:uuid="e71ae1b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="e7262940-915a-013c-7158-0a5172f4a469" xmi:uuid="e7262a60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="896" y="539" width="150" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286437497_559703_126420" xmi:uuid="e73e13e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-name"/>
          <ownedElement xmi:id="e7324ba0-915a-013c-7158-0a5172f4a469" xmi:uuid="e7324cb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="e73d7860-915a-013c-7158-0a5172f4a469" xmi:uuid="e73d7960-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="896" y="581" width="107" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="882" y="504" width="231" height="189"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702053522082_936921_110035" xmi:uuid="e73e2800-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="357" y="14" width="115" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287588027_610608_133145" xmi:uuid="e79c7740-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287589763_340861_133146"/>
      <source xmi:idref="_18_4_1_29c0149_1618425621581_101804_69681"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_474963_130260"/>
      <waypoint x="896" y="504"/>
      <waypoint x="896" y="147"/>
      <waypoint x="764" y="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941142_228235_130248" xmi:uuid="e79cf770-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941080_548153_130200"/>
      <ownedElement xmi:id="e74a9ad0-915a-013c-7158-0a5172f4a469" xmi:uuid="e74a9be0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941080_548153_130200"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e74cd9f0-915a-013c-7158-0a5172f4a469" xmi:uuid="e74cdb10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941080_548153_130200"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d55cbb30-6c45-013d-d60b-0800270c66d6" xmi:uuid="d55cbbd0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d57cf910-6c45-013d-d60b-0800270c66d6" xmi:uuid="d57cfa10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_629625_130259" xmi:uuid="e764fe00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="e7594eb0-915a-013c-7158-0a5172f4a469" xmi:uuid="e7594fd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="e7646500-915a-013c-7158-0a5172f4a469" xmi:uuid="e7646610-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="581" y="98" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_474963_130260" xmi:uuid="e78554d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="e779e7b0-915a-013c-7158-0a5172f4a469" xmi:uuid="e779e8d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e784b480-915a-013c-7158-0a5172f4a469" xmi:uuid="e784b590-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="581" y="133" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_732936_130261" xmi:uuid="e79be720-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="e79030f0-915a-013c-7158-0a5172f4a469" xmi:uuid="e7903210-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="e79b4bb0-915a-013c-7158-0a5172f4a469" xmi:uuid="e79b4de0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="581" y="168" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="567" y="70" width="254" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_346512_130249" xmi:uuid="e7a13850-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941085_12497_130201"/>
      <ownedElement xmi:id="e79f0f40-915a-013c-7158-0a5172f4a469" xmi:uuid="e79f1050-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941085_12497_130201"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="e7a12220-915a-013c-7158-0a5172f4a469" xmi:uuid="e7a12330-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941085_12497_130201"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="322" y="168" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287594700_230684_133188" xmi:uuid="e7e6b7d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287596218_499624_133189"/>
      <source xmi:idref="_18_4_1_29c0149_1618425621581_101804_69681"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_238699_130262"/>
      <waypoint x="896" y="504"/>
      <waypoint x="896" y="256"/>
      <waypoint x="764" y="256"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_967501_130250" xmi:uuid="e7e72fe0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="e7b75770-915a-013c-7158-0a5172f4a469" xmi:uuid="e7b75890-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e7c3b760-915a-013c-7158-0a5172f4a469" xmi:uuid="e7c3b860-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="da80fd10-6c45-013d-d60b-0800270c66d6" xmi:uuid="da80fdb0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="da8234f0-6c45-013d-d60b-0800270c66d6" xmi:uuid="da8235b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_238699_130262" xmi:uuid="e7e60050-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="e7da1840-915a-013c-7158-0a5172f4a469" xmi:uuid="e7da19d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e7e55d00-915a-013c-7158-0a5172f4a469" xmi:uuid="e7e55e20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="581" y="245" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="567" y="217" width="237" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287598502_516760_133209" xmi:uuid="e82e19f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287599986_124478_133210"/>
      <source xmi:idref="_18_4_1_29c0149_1618425621581_101804_69681"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_6902_130263"/>
      <waypoint x="896" y="504"/>
      <waypoint x="896" y="333"/>
      <waypoint x="765" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_855372_130251" xmi:uuid="e82e9b80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="e7fe2b80-915a-013c-7158-0a5172f4a469" xmi:uuid="e7fe2ca0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e80aead0-915a-013c-7158-0a5172f4a469" xmi:uuid="e80aebd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="dd7b6900-6c45-013d-d60b-0800270c66d6" xmi:uuid="dd7b69b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dd87a280-6c45-013d-d60b-0800270c66d6" xmi:uuid="dd87a380-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_6902_130263" xmi:uuid="e82d7fc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="e8211fb0-915a-013c-7158-0a5172f4a469" xmi:uuid="e82120d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e82c6530-915a-013c-7158-0a5172f4a469" xmi:uuid="e82c6820-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="581" y="322" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="567" y="294" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287602320_487470_133230" xmi:uuid="e8751a00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287603968_731782_133231"/>
      <source xmi:idref="_18_4_1_29c0149_1618425621581_101804_69681"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_290494_130264"/>
      <waypoint x="896" y="504"/>
      <waypoint x="896" y="413"/>
      <waypoint x="756" y="413"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_552228_130252" xmi:uuid="e875a510-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="e844b9c0-915a-013c-7158-0a5172f4a469" xmi:uuid="e844baf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e851afa0-915a-013c-7158-0a5172f4a469" xmi:uuid="e851b0d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e01f9050-6c45-013d-d60b-0800270c66d6" xmi:uuid="e01f9130-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e03a6cc0-6c45-013d-d60b-0800270c66d6" xmi:uuid="e03a6d90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_290494_130264" xmi:uuid="e8746890-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="e868a7a0-915a-013c-7158-0a5172f4a469" xmi:uuid="e868a880-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="e873cce0-915a-013c-7158-0a5172f4a469" xmi:uuid="e873cdf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="581" y="399" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="567" y="371" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287606024_656237_133251" xmi:uuid="e8ba9810-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287607757_310742_133252"/>
      <source xmi:idref="_18_4_1_29c0149_1618425621581_101804_69681"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_968053_130265"/>
      <waypoint x="896" y="504"/>
      <waypoint x="896" y="487"/>
      <waypoint x="809" y="487"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_605299_130253" xmi:uuid="e8bb18f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="e88c0a90-915a-013c-7158-0a5172f4a469" xmi:uuid="e88c0f10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="e8980ae0-915a-013c-7158-0a5172f4a469" xmi:uuid="e8980bf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="e330a3f0-6c45-013d-d60b-0800270c66d6" xmi:uuid="e330a640-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e343fa50-6c45-013d-d60b-0800270c66d6" xmi:uuid="e343fb10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_968053_130265" xmi:uuid="e8ba0830-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="e8ae4030-915a-013c-7158-0a5172f4a469" xmi:uuid="e8ae4140-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="e8b96d30-915a-013c-7158-0a5172f4a469" xmi:uuid="e8b96e50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="581" y="476" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="567" y="448" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_697239_130254" xmi:uuid="e8bf84c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941089_568886_130202"/>
      <ownedElement xmi:id="e8bd4ab0-915a-013c-7158-0a5172f4a469" xmi:uuid="e8bd4bc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941089_568886_130202"/>
        <text>theName:String</text>
      </ownedElement>
      <ownedElement xmi:id="e8bf68f0-915a-013c-7158-0a5172f4a469" xmi:uuid="e8bf6a20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941089_568886_130202"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="567" y="574" width="181" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287610411_266471_133272" xmi:uuid="e92ad1d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287612109_142545_133273"/>
      <source xmi:idref="_18_4_1_29c0149_1618425621581_101804_69681"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_633568_130267"/>
      <waypoint x="907" y="693"/>
      <waypoint x="907" y="735"/>
      <waypoint x="765" y="735"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_487264_130255" xmi:uuid="e92b5af0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941093_611835_130203"/>
      <ownedElement xmi:id="e8cbf430-915a-013c-7158-0a5172f4a469" xmi:uuid="e8cbf550-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941093_611835_130203"/>
        <text>smlpTypeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e8ce2680-915a-013c-7158-0a5172f4a469" xmi:uuid="e8ce27a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941093_611835_130203"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="e59aea90-6c45-013d-d60b-0800270c66d6" xmi:uuid="e59aeb20-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e5ada0d0-6c45-013d-d60b-0800270c66d6" xmi:uuid="e5ada1b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_55044_130266" xmi:uuid="e8f15280-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="e8e44870-915a-013c-7158-0a5172f4a469" xmi:uuid="e8e44aa0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="e8f07ec0-915a-013c-7158-0a5172f4a469" xmi:uuid="e8f08000-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="581" y="763" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_633568_130267" xmi:uuid="e912fde0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="e9071350-915a-013c-7158-0a5172f4a469" xmi:uuid="e9071460-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e9123680-915a-013c-7158-0a5172f4a469" xmi:uuid="e91237b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="581" y="728" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_941027_130268" xmi:uuid="e92a4020-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="e91e0bf0-915a-013c-7158-0a5172f4a469" xmi:uuid="e91e0cf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="e92993d0-915a-013c-7158-0a5172f4a469" xmi:uuid="e9299510-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="581" y="798" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="567" y="700" width="272" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287614626_472797_133293" xmi:uuid="e9715c70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287616363_773893_133294"/>
      <source xmi:idref="_18_4_1_29c0149_1618425621581_101804_69681"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_535464_130269"/>
      <waypoint x="907" y="693"/>
      <waypoint x="907" y="959"/>
      <waypoint x="765" y="959"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_392022_130256" xmi:uuid="e971dcb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="e941e1c0-915a-013c-7158-0a5172f4a469" xmi:uuid="e941e2e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e94e5300-915a-013c-7158-0a5172f4a469" xmi:uuid="e94e5410-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ea7d0cb0-6c45-013d-d60b-0800270c66d6" xmi:uuid="ea7d0d60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ea975ef0-6c45-013d-d60b-0800270c66d6" xmi:uuid="ea976010-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_535464_130269" xmi:uuid="e9708d00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="e964c030-915a-013c-7158-0a5172f4a469" xmi:uuid="e964c140-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e96ffdb0-915a-013c-7158-0a5172f4a469" xmi:uuid="e9700150-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="581" y="938" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="567" y="910" width="256" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_867423_130257" xmi:uuid="e9762890-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941096_848530_130204"/>
      <ownedElement xmi:id="e9740100-915a-013c-7158-0a5172f4a469" xmi:uuid="e9740210-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941096_848530_130204"/>
        <text>theType:String</text>
      </ownedElement>
      <ownedElement xmi:id="e9760a00-915a-013c-7158-0a5172f4a469" xmi:uuid="e9760b20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941096_848530_130204"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="357" y="882" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_172024_130258" xmi:uuid="e9b3b6f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941100_421949_130205"/>
      <ownedElement xmi:id="e981fc80-915a-013c-7158-0a5172f4a469" xmi:uuid="e981fd90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941100_421949_130205"/>
        <text>smplType:Class</text>
      </ownedElement>
      <ownedElement xmi:id="e9841640-915a-013c-7158-0a5172f4a469" xmi:uuid="e9841750-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941100_421949_130205"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ecf6c490-6c45-013d-d60b-0800270c66d6" xmi:uuid="ecf6c530-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ed0c0310-6c45-013d-d60b-0800270c66d6" xmi:uuid="ed0c03e0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_801683_130270" xmi:uuid="e99c6c60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="e9903490-915a-013c-7158-0a5172f4a469" xmi:uuid="e99035a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="e99bd010-915a-013c-7158-0a5172f4a469" xmi:uuid="e99bd360-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="371" y="798" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_507439_130271" xmi:uuid="e9b3a680-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="e9a76160-915a-013c-7158-0a5172f4a469" xmi:uuid="e9a76270-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="e9b2ea60-915a-013c-7158-0a5172f4a469" xmi:uuid="e9b2eb90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="371" y="833" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="357" y="770" width="133" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_780921_130272" xmi:uuid="e9b3c900-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941104_72929_130209"/>
      <source xmi:idref="_18_4_1_65b021e_1702286941143_732936_130261"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_346512_130249"/>
      <waypoint x="581" y="179"/>
      <waypoint x="456" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_886374_130273" xmi:uuid="e9b3d380-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941105_610497_130221"/>
      <source xmi:idref="_18_4_1_65b021e_1702286941143_941027_130268"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_867423_130257"/>
      <waypoint x="599" y="823"/>
      <waypoint x="599" y="893"/>
      <waypoint x="525" y="893"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286941143_907516_130274" xmi:uuid="e9b3dbe0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286941105_367813_130226"/>
      <source xmi:idref="_18_4_1_65b021e_1702286941143_55044_130266"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_172024_130258"/>
      <waypoint x="581" y="774"/>
      <waypoint x="490" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287038655_997035_132126" xmi:uuid="e9e526f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="e9cc8000-915a-013c-7158-0a5172f4a469" xmi:uuid="e9cc8110-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702287038656_355774_132129" xmi:uuid="e9e51e20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="f0e79820-6c45-013d-d60b-0800270c66d6" xmi:uuid="f0e798b0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="482" y="94" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="464" y="103" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="322" y="91" width="157" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287038656_952190_132127" xmi:uuid="ea14cb90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="e9fcc510-915a-013c-7158-0a5172f4a469" xmi:uuid="e9fcc630-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702287038656_411496_132131" xmi:uuid="ea14c220-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="f282d250-6c45-013d-d60b-0800270c66d6" xmi:uuid="f282d300-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="574" y="529" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="556" y="538" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="322" y="525" width="249" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287038656_128757_132128" xmi:uuid="ea44c280-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="ea2c3d60-915a-013c-7158-0a5172f4a469" xmi:uuid="ea2c3e80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702287038656_797758_132133" xmi:uuid="ea44a690-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="f43e88f0-6c45-013d-d60b-0800270c66d6" xmi:uuid="f43e8990-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="340" y="752" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="330" y="734" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="322" y="700" width="163" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287592515_340910_133164" xmi:uuid="ea44d0a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287593266_731724_133165"/>
      <source xmi:idref="_18_4_1_65b021e_1702286941143_629625_130259"/>
      <target xmi:idref="_18_4_1_65b021e_1702287038656_355774_132129"/>
      <waypoint x="581" y="109"/>
      <waypoint x="479" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287619601_137684_133314" xmi:uuid="ea44ded0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287621532_11343_133315"/>
      <source xmi:idref="_18_4_1_65b021e_1702286437486_841730_126389"/>
      <target xmi:idref="_18_4_1_65b021e_1702287038656_411496_132131"/>
      <waypoint x="896" y="550"/>
      <waypoint x="571" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287623117_689057_133338" xmi:uuid="ea44e6b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287624034_536873_133339"/>
      <source xmi:idref="_18_4_1_65b021e_1702286437497_559703_126420"/>
      <target xmi:idref="_18_4_1_65b021e_1702286941143_697239_130254"/>
      <waypoint x="896" y="592"/>
      <waypoint x="748" y="592"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287626852_121128_133359" xmi:uuid="ea44eed0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287628338_219524_133360"/>
      <source xmi:idref="_18_4_1_65b021e_1702286941143_801683_130270"/>
      <target xmi:idref="_18_4_1_65b021e_1702287038656_797758_132133"/>
      <waypoint x="371" y="809"/>
      <waypoint x="336" y="809"/>
      <waypoint x="336" y="749"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287631551_803620_133381" xmi:uuid="ea44f880-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287633437_289728_133382"/>
      <source xmi:idref="_18_4_1_65b021e_1702286941143_507439_130271"/>
      <target xmi:idref="_18_4_1_65b021e_1702287038656_797758_132133"/>
      <waypoint x="371" y="844"/>
      <waypoint x="336" y="844"/>
      <waypoint x="336" y="749"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1128" height="988"/>
    <name>SchemeEntryRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1617824748108_228858_76941" xmi:uuid="d4916750-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200734582_937142_15801"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1617825835275_473544_77217" xmi:uuid="d49236f0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617825835264_714643_77213"/>
      <bounds x="1034" y="471" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617824761737_320711_76973" xmi:uuid="d496cb90-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799823948_505614_62437"/>
      <ownedElement xmi:id="d4944880-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d4944a10-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799823948_505614_62437"/>
        <text>Related:Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="d4955bc0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d4955cf0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799823948_505614_62437"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617825792854_214346_77174" xmi:uuid="d496b300-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617822702322_99778_76300"/>
        <ownedElement xmi:id="f72c8bd0-6c45-013d-d60b-0800270c66d6" xmi:uuid="f72c8ec0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617822702322_99778_76300"/>
          <bounds x="178" y="633" width="104" height="13"/>
          <text>scheme : Scheme [1]</text>
        </ownedElement>
        <bounds x="160" y="642" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="637" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617824761746_765204_77004" xmi:uuid="d499a870-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799924555_556213_62466"/>
      <ownedElement xmi:id="d4988fe0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d49890d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799924555_556213_62466"/>
        <text>Relating:Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="d49915b0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d4991630-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617799924555_556213_62466"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617825739179_488309_77159" xmi:uuid="d4999ef0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617822702322_99778_76300"/>
        <ownedElement xmi:id="f7a99300-6c45-013d-d60b-0800270c66d6" xmi:uuid="f7a993a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617822702322_99778_76300"/>
          <bounds x="178" y="669" width="104" height="13"/>
          <text>scheme : Scheme [1]</text>
        </ownedElement>
        <bounds x="160" y="678" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="672" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617825804577_672391_77193" xmi:uuid="d499b5c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617825806508_465540_77194"/>
      <source xmi:idref="_18_4_1_29c0149_1618423986590_62335_69376"/>
      <target xmi:idref="_18_4_1_29c0149_1617825792854_214346_77174"/>
      <waypoint x="840" y="648"/>
      <waypoint x="175" y="648"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617825928342_242042_77240" xmi:uuid="d499c1d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617825929788_499989_77241"/>
      <source xmi:idref="_18_4_1_29c0149_1617825835275_473544_77217"/>
      <target xmi:idref="_18_4_1_29c0149_1618423925246_82061_69337"/>
      <waypoint x="1034" y="480"/>
      <waypoint x="928" y="480"/>
      <waypoint x="928" y="518"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617824882985_576505_77143" xmi:uuid="d5234ca0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617824884823_26985_77144"/>
      <source xmi:idref="_18_4_1_29c0149_1617825739179_488309_77159"/>
      <target xmi:idref="_18_4_1_29c0149_1618423986602_566349_69407"/>
      <waypoint x="175" y="686"/>
      <waypoint x="840" y="686"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618423925246_82061_69337" xmi:uuid="d52384a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423937148_833783_69368"/>
      <ownedElement xmi:id="d4b5a770-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d4b5a870-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423937148_833783_69368"/>
        <text>relate:Scheme_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d4b61120-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d4b61190-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618423937148_833783_69368"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="f8755130-6c45-013d-d60b-0800270c66d6" xmi:uuid="f8755220-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f876d380-6c45-013d-d60b-0800270c66d6" xmi:uuid="f876d460-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618423986590_62335_69376" xmi:uuid="d4e698d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_relationship-related_method"/>
          <ownedElement xmi:id="d4d89380-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d4d89470-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_relationship-related_method"/>
            <text>related_method:Scheme</text>
          </ownedElement>
          <ownedElement xmi:id="d4e68aa0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d4e68b80-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_relationship-related_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="840" y="637" width="172" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618423986602_566349_69407" xmi:uuid="d52340a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_relationship-relating_method"/>
          <ownedElement xmi:id="d5104680-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5104780-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_relationship-relating_method"/>
            <text>relating_method:Scheme</text>
          </ownedElement>
          <ownedElement xmi:id="d5233210-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5233300-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_relationship-relating_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="840" y="672" width="175" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286404939_443027_126321" xmi:uuid="eaddf910-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-description"/>
          <ownedElement xmi:id="ead2b8a0-915a-013c-7158-0a5172f4a469" xmi:uuid="ead2b9d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="eadd2b90-915a-013c-7158-0a5172f4a469" xmi:uuid="eadd2cb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="840" y="553" width="150" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286404951_890640_126352" xmi:uuid="eaf4b4a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-name"/>
          <ownedElement xmi:id="eae901a0-915a-013c-7158-0a5172f4a469" xmi:uuid="eae902b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="eaf416e0-915a-013c-7158-0a5172f4a469" xmi:uuid="eaf41800-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="840" y="595" width="107" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="826" y="518" width="196" height="189"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702053639612_826719_110361" xmi:uuid="eaf4c6a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="301" y="14" width="115" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287450266_138339_132916" xmi:uuid="eb555290-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287452199_491231_132917"/>
      <source xmi:idref="_18_4_1_29c0149_1618423925246_82061_69337"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_218711_129448"/>
      <waypoint x="840" y="518"/>
      <waypoint x="840" y="158"/>
      <waypoint x="701" y="158"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_485711_129436" xmi:uuid="eb55cb70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928510_903469_129388"/>
      <ownedElement xmi:id="eb011410-915a-013c-7158-0a5172f4a469" xmi:uuid="eb011520-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928510_903469_129388"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="eb0383e0-915a-013c-7158-0a5172f4a469" xmi:uuid="eb0384e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928510_903469_129388"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="fd6bd880-6c45-013d-d60b-0800270c66d6" xmi:uuid="fd6bd920-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="fd8a5030-6c45-013d-d60b-0800270c66d6" xmi:uuid="fd8a5110-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_821640_129447" xmi:uuid="eb1c3a80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="eb101b00-915a-013c-7158-0a5172f4a469" xmi:uuid="eb101e90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="eb1b7050-915a-013c-7158-0a5172f4a469" xmi:uuid="eb1b74a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="518" y="112" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_218711_129448" xmi:uuid="eb3d3570-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="eb316d10-915a-013c-7158-0a5172f4a469" xmi:uuid="eb316e40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="eb3c9b30-915a-013c-7158-0a5172f4a469" xmi:uuid="eb3c9c50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="518" y="147" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_691027_129449" xmi:uuid="eb54b600-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="eb488a00-915a-013c-7158-0a5172f4a469" xmi:uuid="eb488b10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="eb53a8a0-915a-013c-7158-0a5172f4a469" xmi:uuid="eb53a9f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="518" y="182" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="504" y="84" width="254" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_337575_129437" xmi:uuid="eb5a25c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928514_647838_129389"/>
      <ownedElement xmi:id="eb57f200-915a-013c-7158-0a5172f4a469" xmi:uuid="eb57f310-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928514_647838_129389"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="eb5a12b0-915a-013c-7158-0a5172f4a469" xmi:uuid="eb5a13b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928514_647838_129389"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="259" y="182" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287454885_128214_132935" xmi:uuid="eb9f4dd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287456352_495933_132936"/>
      <source xmi:idref="_18_4_1_29c0149_1618423925246_82061_69337"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_680191_129450"/>
      <waypoint x="840" y="518"/>
      <waypoint x="840" y="273"/>
      <waypoint x="701" y="273"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_412199_129438" xmi:uuid="eb9fcd40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="eb7027d0-915a-013c-7158-0a5172f4a469" xmi:uuid="eb7028f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="eb7c7ab0-915a-013c-7158-0a5172f4a469" xmi:uuid="eb7c7bc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="024aa7f0-6c46-013d-d60b-0800270c66d6" xmi:uuid="024aa8c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0256d8f0-6c46-013d-d60b-0800270c66d6" xmi:uuid="0256d9c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_680191_129450" xmi:uuid="eb9eb980-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="eb92f3e0-915a-013c-7158-0a5172f4a469" xmi:uuid="eb92f4f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="eb9e1410-915a-013c-7158-0a5172f4a469" xmi:uuid="eb9e1520-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="518" y="259" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="504" y="231" width="237" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287461650_485084_132980" xmi:uuid="ebe55cd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287463974_321886_132981"/>
      <source xmi:idref="_18_4_1_29c0149_1618423925246_82061_69337"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_21477_129451"/>
      <waypoint x="840" y="518"/>
      <waypoint x="840" y="347"/>
      <waypoint x="702" y="347"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_145796_129439" xmi:uuid="ebe5d930-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="ebb5e2e0-915a-013c-7158-0a5172f4a469" xmi:uuid="ebb5e400-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ebc22e30-915a-013c-7158-0a5172f4a469" xmi:uuid="ebc23410-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="04fd62a0-6c46-013d-d60b-0800270c66d6" xmi:uuid="04fd63b0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="04febe40-6c46-013d-d60b-0800270c66d6" xmi:uuid="04febf10-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_21477_129451" xmi:uuid="ebe4c070-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="ebd8fa20-915a-013c-7158-0a5172f4a469" xmi:uuid="ebd8fb40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ebe42b30-915a-013c-7158-0a5172f4a469" xmi:uuid="ebe42c50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="518" y="336" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="504" y="308" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287466444_177358_133001" xmi:uuid="ec2bb700-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287468093_699532_133002"/>
      <source xmi:idref="_18_4_1_29c0149_1618423925246_82061_69337"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_925930_129452"/>
      <waypoint x="840" y="518"/>
      <waypoint x="840" y="427"/>
      <waypoint x="693" y="427"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_22745_129440" xmi:uuid="ec2c3ff0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="ebfc8e20-915a-013c-7158-0a5172f4a469" xmi:uuid="ebfc8f40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ec08ef00-915a-013c-7158-0a5172f4a469" xmi:uuid="ec08f010-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="0793c7d0-6c46-013d-d60b-0800270c66d6" xmi:uuid="0793c8a0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="079507a0-6c46-013d-d60b-0800270c66d6" xmi:uuid="07950880-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_925930_129452" xmi:uuid="ec2b20c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="ec1f97d0-915a-013c-7158-0a5172f4a469" xmi:uuid="ec1f98e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="ec2a8bd0-915a-013c-7158-0a5172f4a469" xmi:uuid="ec2a8cf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="518" y="413" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="504" y="385" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287470529_542436_133022" xmi:uuid="ec724180-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287472146_765878_133023"/>
      <source xmi:idref="_18_4_1_29c0149_1618423925246_82061_69337"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_689371_129453"/>
      <waypoint x="840" y="518"/>
      <waypoint x="840" y="501"/>
      <waypoint x="746" y="501"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_332086_129441" xmi:uuid="ec72c070-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="ec428fa0-915a-013c-7158-0a5172f4a469" xmi:uuid="ec4290c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="ec4f0200-915a-013c-7158-0a5172f4a469" xmi:uuid="ec4f0310-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="0a1e49d0-6c46-013d-d60b-0800270c66d6" xmi:uuid="0a1e4a60-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0a2a33a0-6c46-013d-d60b-0800270c66d6" xmi:uuid="0a2a34d0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_689371_129453" xmi:uuid="ec719f20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="ec65b3c0-915a-013c-7158-0a5172f4a469" xmi:uuid="ec65b4f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="ec710530-915a-013c-7158-0a5172f4a469" xmi:uuid="ec710650-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="518" y="490" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="504" y="462" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_728652_129442" xmi:uuid="ec7718c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928517_745615_129390"/>
      <ownedElement xmi:id="ec74e5c0-915a-013c-7158-0a5172f4a469" xmi:uuid="ec74e780-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928517_745615_129390"/>
        <text>theName:String</text>
      </ownedElement>
      <ownedElement xmi:id="ec7706f0-915a-013c-7158-0a5172f4a469" xmi:uuid="ec770800-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928517_745615_129390"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="504" y="595" width="181" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287474547_850467_133043" xmi:uuid="ecdfe7a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287476146_755914_133044"/>
      <source xmi:idref="_18_4_1_29c0149_1618423925246_82061_69337"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_653171_129455"/>
      <waypoint x="847" y="707"/>
      <waypoint x="847" y="756"/>
      <waypoint x="702" y="756"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_355573_129443" xmi:uuid="ece06390-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928521_496633_129391"/>
      <ownedElement xmi:id="ec835460-915a-013c-7158-0a5172f4a469" xmi:uuid="ec835560-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928521_496633_129391"/>
        <text>smlpTypeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ec8596b0-915a-013c-7158-0a5172f4a469" xmi:uuid="ec8597c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928521_496633_129391"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="0c5cb330-6c46-013d-d60b-0800270c66d6" xmi:uuid="0c5cb3d0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0c6950c0-6c46-013d-d60b-0800270c66d6" xmi:uuid="0c6951a0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_50428_129454" xmi:uuid="eca7c2a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="ec9c0470-915a-013c-7158-0a5172f4a469" xmi:uuid="ec9c0580-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="eca716b0-915a-013c-7158-0a5172f4a469" xmi:uuid="eca71900-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="518" y="777" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_653171_129455" xmi:uuid="ecc81a00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="ecbc8340-915a-013c-7158-0a5172f4a469" xmi:uuid="ecbc8450-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ecc78330-915a-013c-7158-0a5172f4a469" xmi:uuid="ecc78470-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="518" y="742" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_965550_129456" xmi:uuid="ecdf48f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="ecd3d3f0-915a-013c-7158-0a5172f4a469" xmi:uuid="ecd3d500-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="ecdeb250-915a-013c-7158-0a5172f4a469" xmi:uuid="ecdeb370-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="518" y="812" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="504" y="714" width="272" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287478413_922742_133064" xmi:uuid="ed25d030-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287480431_384209_133065"/>
      <source xmi:idref="_18_4_1_29c0149_1618423925246_82061_69337"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_809008_129457"/>
      <waypoint x="847" y="707"/>
      <waypoint x="847" y="966"/>
      <waypoint x="702" y="966"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_433894_129444" xmi:uuid="ed265020-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="ecf69420-915a-013c-7158-0a5172f4a469" xmi:uuid="ecf69540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ed02b2a0-915a-013c-7158-0a5172f4a469" xmi:uuid="ed02b3c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="10b001c0-6c46-013d-d60b-0800270c66d6" xmi:uuid="10b00260-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="10b14cb0-6c46-013d-d60b-0800270c66d6" xmi:uuid="10b14e20-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_809008_129457" xmi:uuid="ed253b00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="ed1950e0-915a-013c-7158-0a5172f4a469" xmi:uuid="ed1951f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ed24a710-915a-013c-7158-0a5172f4a469" xmi:uuid="ed24a820-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="518" y="952" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="504" y="924" width="256" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_94473_129445" xmi:uuid="ed2ab510-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928524_307273_129392"/>
      <ownedElement xmi:id="ed287e00-915a-013c-7158-0a5172f4a469" xmi:uuid="ed287f20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928524_307273_129392"/>
        <text>theType:String</text>
      </ownedElement>
      <ownedElement xmi:id="ed2aa310-915a-013c-7158-0a5172f4a469" xmi:uuid="ed2aa420-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928524_307273_129392"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="294" y="896" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_160142_129446" xmi:uuid="ed66f720-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928528_466077_129393"/>
      <ownedElement xmi:id="ed36cbb0-915a-013c-7158-0a5172f4a469" xmi:uuid="ed36d0a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928528_466077_129393"/>
        <text>smplType:Class</text>
      </ownedElement>
      <ownedElement xmi:id="ed38f0d0-915a-013c-7158-0a5172f4a469" xmi:uuid="ed38f1f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928528_466077_129393"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="13212660-6c46-013d-d60b-0800270c66d6" xmi:uuid="13212700-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="133055b0-6c46-013d-d60b-0800270c66d6" xmi:uuid="13305690-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_459969_129458" xmi:uuid="ed50de60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="ed453cd0-915a-013c-7158-0a5172f4a469" xmi:uuid="ed453df0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="ed503ae0-915a-013c-7158-0a5172f4a469" xmi:uuid="ed503be0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="308" y="812" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_998712_129459" xmi:uuid="ed66e910-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="ed5bdbc0-915a-013c-7158-0a5172f4a469" xmi:uuid="ed5bdcd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="ed664a20-915a-013c-7158-0a5172f4a469" xmi:uuid="ed664b40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="308" y="847" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="294" y="784" width="133" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_742100_129460" xmi:uuid="ed66fff0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928531_415218_129397"/>
      <source xmi:idref="_18_4_1_65b021e_1702286928567_691027_129449"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_337575_129437"/>
      <waypoint x="518" y="193"/>
      <waypoint x="393" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_494607_129461" xmi:uuid="ed670d30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928532_883487_129409"/>
      <source xmi:idref="_18_4_1_65b021e_1702286928567_965550_129456"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_94473_129445"/>
      <waypoint x="536" y="837"/>
      <waypoint x="536" y="907"/>
      <waypoint x="462" y="907"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286928567_271917_129462" xmi:uuid="ed6715a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286928532_98698_129414"/>
      <source xmi:idref="_18_4_1_65b021e_1702286928567_50428_129454"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_160142_129446"/>
      <waypoint x="518" y="788"/>
      <waypoint x="427" y="788"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287026297_775867_132028" xmi:uuid="ed97adb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="ed7f2650-915a-013c-7158-0a5172f4a469" xmi:uuid="ed7f2770-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702287026297_634327_132031" xmi:uuid="ed97a360-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="16a26a90-6c46-013d-d60b-0800270c66d6" xmi:uuid="16a26bb0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="419" y="108" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="401" y="117" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="259" y="105" width="157" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287026297_83859_132029" xmi:uuid="edc76eb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="edaf2200-915a-013c-7158-0a5172f4a469" xmi:uuid="edaf23e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702287026297_824056_132033" xmi:uuid="edc765c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="186878f0-6c46-013d-d60b-0800270c66d6" xmi:uuid="186879a0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="511" y="550" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="493" y="559" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="259" y="546" width="249" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287026297_458700_132030" xmi:uuid="edf722f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="eddf0420-915a-013c-7158-0a5172f4a469" xmi:uuid="eddf0540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702287026297_597096_132035" xmi:uuid="edf71a30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="19e25a60-6c46-013d-d60b-0800270c66d6" xmi:uuid="19e25b00-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="277" y="766" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="267" y="748" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="259" y="714" width="163" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287459271_750116_132956" xmi:uuid="edf72c10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287459919_695650_132957"/>
      <source xmi:idref="_18_4_1_65b021e_1702286928567_821640_129447"/>
      <target xmi:idref="_18_4_1_65b021e_1702287026297_634327_132031"/>
      <waypoint x="518" y="123"/>
      <waypoint x="416" y="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287485165_847226_133085" xmi:uuid="edf735e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287486637_481791_133086"/>
      <source xmi:idref="_18_4_1_65b021e_1702286928567_459969_129458"/>
      <target xmi:idref="_18_4_1_65b021e_1702287026297_597096_132035"/>
      <waypoint x="308" y="823"/>
      <waypoint x="273" y="823"/>
      <waypoint x="273" y="763"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287489257_967416_133107" xmi:uuid="edf74330-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287490773_35140_133108"/>
      <source xmi:idref="_18_4_1_65b021e_1702286928567_998712_129459"/>
      <target xmi:idref="_18_4_1_65b021e_1702287026297_597096_132035"/>
      <waypoint x="308" y="858"/>
      <waypoint x="273" y="858"/>
      <waypoint x="273" y="763"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287654069_355868_133405" xmi:uuid="edf74b90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287659422_773034_133406"/>
      <source xmi:idref="_18_4_1_65b021e_1702286404939_443027_126321"/>
      <target xmi:idref="_18_4_1_65b021e_1702287026297_824056_132033"/>
      <waypoint x="840" y="567"/>
      <waypoint x="508" y="567"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287662323_256907_133427" xmi:uuid="edf754d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287663240_127030_133428"/>
      <source xmi:idref="_18_4_1_65b021e_1702286404951_890640_126352"/>
      <target xmi:idref="_18_4_1_65b021e_1702286928567_728652_129442"/>
      <waypoint x="840" y="606"/>
      <waypoint x="685" y="606"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1037" height="1002"/>
    <name>SchemeRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1617828099792_491480_78704" xmi:uuid="d523ba60-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617199936020_463996_15431"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1617828237845_651342_78918" xmi:uuid="d524c440-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828237836_885869_78914"/>
      <bounds x="1198" y="596" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617828119157_317990_78736" xmi:uuid="d5298830-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809683211_399922_68829"/>
      <ownedElement xmi:id="d526cbd0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d526d010-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809683211_399922_68829"/>
        <text>AssignedSchemeVersion:SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d527eb50-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d527ecb0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809683211_399922_68829"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617828335399_625211_78946" xmi:uuid="d5297140-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617720793589_182632_62953"/>
        <ownedElement xmi:id="1c6d4670-6c46-013d-d60b-0800270c66d6" xmi:uuid="1c6d4700-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617720793589_182632_62953"/>
          <bounds x="292" y="662" width="143" height="13"/>
          <text>version : Scheme_version [1]</text>
        </ownedElement>
        <bounds x="274" y="671" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="665" width="261" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617828119166_396920_78767" xmi:uuid="d52bdd60-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809804202_981043_68868"/>
      <ownedElement xmi:id="d52aece0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d52aed60-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809804202_981043_68868"/>
        <text>AssignedTo:SchemeVersionAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d52b52e0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d52b5360-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617809804202_981043_68868"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1617828526505_508633_78978" xmi:uuid="d52bd4c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
        <ownedElement xmi:id="1cda2d30-6c46-013d-d60b-0800270c66d6" xmi:uuid="1cda2dd0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
          <bounds x="320" y="693" width="159" height="13"/>
          <text>svs : scheme_version_select [1]</text>
        </ownedElement>
        <bounds x="302" y="702" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="700" width="289" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617828280545_417503_78939" xmi:uuid="d52be9f0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828282797_908353_78940"/>
      <source xmi:idref="_18_4_1_29c0149_1618422364232_115185_68925"/>
      <target xmi:idref="_18_4_1_29c0149_1617828237845_651342_78918"/>
      <waypoint x="1040" y="637"/>
      <waypoint x="1040" y="606"/>
      <waypoint x="1198" y="606"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617828356323_216402_78965" xmi:uuid="d52bf550-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828357769_253587_78966"/>
      <source xmi:idref="_18_4_1_29c0149_1618422404986_174462_68964"/>
      <target xmi:idref="_18_4_1_29c0149_1617828335399_625211_78946"/>
      <waypoint x="903" y="679"/>
      <waypoint x="289" y="679"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1617828549446_192875_78997" xmi:uuid="d52c0160-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828550670_988022_78998"/>
      <source xmi:idref="_18_4_1_29c0149_1618422404996_156117_68995"/>
      <target xmi:idref="_18_4_1_29c0149_1617828526505_508633_78978"/>
      <waypoint x="903" y="711"/>
      <waypoint x="317" y="711"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618422364232_115185_68925" xmi:uuid="d5b189b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618422373495_522723_68956"/>
      <ownedElement xmi:id="d53dee60-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d53def60-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618422373495_522723_68956"/>
        <text>assign:Scheme_version_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d53e5310-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d53e5380-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618422373495_522723_68956"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="1d7d7830-6c46-013d-d60b-0800270c66d6" xmi:uuid="1d7d79c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="1d9b2890-6c46-013d-d60b-0800270c66d6" xmi:uuid="1d9b2940-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618422404986_174462_68964" xmi:uuid="d57b3790-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_assignment-assigned_activity_method"/>
          <ownedElement xmi:id="d566e0e0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d566e1c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_assignment-assigned_activity_method"/>
            <text>assigned_activity_method:Scheme_version</text>
          </ownedElement>
          <ownedElement xmi:id="d57b12b0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d57b14b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_assignment-assigned_activity_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="903" y="665" width="276" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618422404996_156117_68995" xmi:uuid="d5b17ef0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_assignment-items"/>
          <ownedElement xmi:id="d5a31180-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5a31290-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_assignment-items"/>
            <text>items:scheme_version_select</text>
          </ownedElement>
          <ownedElement xmi:id="d5b17110-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5b17200-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="903" y="700" width="214" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284510879_372871_122812" xmi:uuid="ee9987b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-role"/>
          <ownedElement xmi:id="ee8cef10-915a-013c-7158-0a5172f4a469" xmi:uuid="ee8cf260-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="ee98de40-915a-013c-7158-0a5172f4a469" xmi:uuid="ee98df50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="910" y="749" width="98" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="896" y="637" width="290" height="154"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702053775260_866395_110725" xmi:uuid="ee99a140-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509987065721_230294_25388"/>
      <bounds x="399" y="21" width="112" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702283996168_8456_118798" xmi:uuid="eecc8150-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
      <ownedElement xmi:id="eeb2f150-915a-013c-7158-0a5172f4a469" xmi:uuid="eeb2f260-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702283996168_620102_118801" xmi:uuid="eecc7130-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="22da7bc0-6c46-013d-d60b-0800270c66d6" xmi:uuid="22da7ca0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="468" y="80" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="450" y="89" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="77" width="164" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702283996168_290823_118799" xmi:uuid="ef008220-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
      <ownedElement xmi:id="eee5d2f0-915a-013c-7158-0a5172f4a469" xmi:uuid="eee5d400-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702283996168_879131_118803" xmi:uuid="ef007840-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="249e1e30-6c46-013d-d60b-0800270c66d6" xmi:uuid="249e1ee0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="321" y="472" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="311" y="454" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="252" y="420" width="220" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702283996168_952275_118800" xmi:uuid="ef3359f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
      <ownedElement xmi:id="ef198510-915a-013c-7158-0a5172f4a469" xmi:uuid="ef198620-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
        <text>roleSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702283996168_628030_118805" xmi:uuid="ef3349a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="262485a0-6c46-013d-d60b-0800270c66d6" xmi:uuid="26248630-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="462" y="767" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="446" y="754" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="273" y="742" width="188" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284695555_747898_123648" xmi:uuid="ef99e3c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284697001_214081_123649"/>
      <source xmi:idref="_18_4_1_29c0149_1618422364232_115185_68925"/>
      <target xmi:idref="_18_4_1_65b021e_1702284479474_585947_122102"/>
      <waypoint x="928" y="637"/>
      <waypoint x="928" y="137"/>
      <waypoint x="771" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_817537_122091" xmi:uuid="ef9a67b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479418_56549_122051"/>
      <ownedElement xmi:id="ef401cc0-915a-013c-7158-0a5172f4a469" xmi:uuid="ef401de0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479418_56549_122051"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ef426750-915a-013c-7158-0a5172f4a469" xmi:uuid="ef426860-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479418_56549_122051"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="26c08bf0-6c46-013d-d60b-0800270c66d6" xmi:uuid="26c08ca0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="26ce4bf0-6c46-013d-d60b-0800270c66d6" xmi:uuid="26ce4cc0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_129600_122101" xmi:uuid="ef5ce980-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="ef5009b0-915a-013c-7158-0a5172f4a469" xmi:uuid="ef500ae0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="ef5c36e0-915a-013c-7158-0a5172f4a469" xmi:uuid="ef5c3820-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="588" y="91" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_585947_122102" xmi:uuid="ef80ee20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="ef73f0e0-915a-013c-7158-0a5172f4a469" xmi:uuid="ef73f210-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ef802a40-915a-013c-7158-0a5172f4a469" xmi:uuid="ef802dd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="588" y="126" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_544628_122103" xmi:uuid="ef994180-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="ef8c78d0-915a-013c-7158-0a5172f4a469" xmi:uuid="ef8c7a20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="ef989d10-915a-013c-7158-0a5172f4a469" xmi:uuid="ef989e20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="588" y="161" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="574" y="63" width="254" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_621931_122092" xmi:uuid="ef9f8b70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479423_528559_122052"/>
      <ownedElement xmi:id="ef9cb880-915a-013c-7158-0a5172f4a469" xmi:uuid="ef9cba10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479423_528559_122052"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="ef9f0fb0-915a-013c-7158-0a5172f4a469" xmi:uuid="ef9f10e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479423_528559_122052"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="378" y="161" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284699723_9991_123669" xmi:uuid="efe95ca0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284701504_184989_123670"/>
      <source xmi:idref="_18_4_1_29c0149_1618422364232_115185_68925"/>
      <target xmi:idref="_18_4_1_65b021e_1702284479474_227321_122104"/>
      <waypoint x="928" y="637"/>
      <waypoint x="928" y="249"/>
      <waypoint x="771" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_943127_122093" xmi:uuid="efe9db70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
      <ownedElement xmi:id="efb6da60-915a-013c-7158-0a5172f4a469" xmi:uuid="efb6db80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="efc3c000-915a-013c-7158-0a5172f4a469" xmi:uuid="efc3c100-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="2b90d0d0-6c46-013d-d60b-0800270c66d6" xmi:uuid="2b90d160-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2b9b9410-6c46-013d-d60b-0800270c66d6" xmi:uuid="2b9b94d0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_227321_122104" xmi:uuid="efe8b700-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="efdc0a40-915a-013c-7158-0a5172f4a469" xmi:uuid="efdc0b60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="efe80880-915a-013c-7158-0a5172f4a469" xmi:uuid="efe809d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="588" y="238" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="574" y="210" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284704171_154737_123690" xmi:uuid="f0338b40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284706123_689883_123691"/>
      <source xmi:idref="_18_4_1_29c0149_1618422364232_115185_68925"/>
      <target xmi:idref="_18_4_1_65b021e_1702284479474_156273_122105"/>
      <waypoint x="928" y="637"/>
      <waypoint x="928" y="333"/>
      <waypoint x="772" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_832939_122094" xmi:uuid="f0340a70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
      <ownedElement xmi:id="f0019420-915a-013c-7158-0a5172f4a469" xmi:uuid="f0019560-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f00e9250-915a-013c-7158-0a5172f4a469" xmi:uuid="f00e9370-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="2dfd9180-6c46-013d-d60b-0800270c66d6" xmi:uuid="2dfd9210-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2e14c3c0-6c46-013d-d60b-0800270c66d6" xmi:uuid="2e14c490-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_156273_122105" xmi:uuid="f032ec50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="f0267d60-915a-013c-7158-0a5172f4a469" xmi:uuid="f02680b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f03248f0-915a-013c-7158-0a5172f4a469" xmi:uuid="f0324a10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="588" y="315" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="574" y="287" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284708908_359922_123711" xmi:uuid="f08db9f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284711044_395774_123712"/>
      <source xmi:idref="_18_4_1_29c0149_1618422364232_115185_68925"/>
      <target xmi:idref="_18_4_1_65b021e_1702284479474_412778_122107"/>
      <waypoint x="928" y="637"/>
      <waypoint x="928" y="424"/>
      <waypoint x="763" y="424"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_868471_122095" xmi:uuid="f08e3af0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479428_277521_122053"/>
      <ownedElement xmi:id="f04181a0-915a-013c-7158-0a5172f4a469" xmi:uuid="f04182c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479428_277521_122053"/>
        <text>smplDescAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f043d3f0-915a-013c-7158-0a5172f4a469" xmi:uuid="f043d510-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479428_277521_122053"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="2ff69810-6c46-013d-d60b-0800270c66d6" xmi:uuid="2ff698f0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3002ac80-6c46-013d-d60b-0800270c66d6" xmi:uuid="3002ad40-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_501224_122106" xmi:uuid="f06a8b10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="f05e2900-915a-013c-7158-0a5172f4a469" xmi:uuid="f05e2a20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="f069d770-915a-013c-7158-0a5172f4a469" xmi:uuid="f069da40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="588" y="441" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_412778_122107" xmi:uuid="f08d1640-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="f080e9f0-915a-013c-7158-0a5172f4a469" xmi:uuid="f080eb20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="f08c6910-915a-013c-7158-0a5172f4a469" xmi:uuid="f08c6a20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="588" y="406" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="574" y="378" width="287" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_421507_122096" xmi:uuid="f0d303c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
      <ownedElement xmi:id="f0a476f0-915a-013c-7158-0a5172f4a469" xmi:uuid="f0a478a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="f0b0be60-915a-013c-7158-0a5172f4a469" xmi:uuid="f0b0bf70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="33c881a0-6c46-013d-d60b-0800270c66d6" xmi:uuid="33c88280-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="33ca1f60-6c46-013d-d60b-0800270c66d6" xmi:uuid="33ca2260-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_367186_122108" xmi:uuid="f0d2f5c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="f0c73dd0-915a-013c-7158-0a5172f4a469" xmi:uuid="f0c73ff0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="f0d25580-915a-013c-7158-0a5172f4a469" xmi:uuid="f0d256a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="308" y="378" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="294" y="350" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_470_122097" xmi:uuid="f0f9ce90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479433_894151_122054"/>
      <ownedElement xmi:id="f0df4b60-915a-013c-7158-0a5172f4a469" xmi:uuid="f0df4c80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479433_894151_122054"/>
        <text>descText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="f0e18000-915a-013c-7158-0a5172f4a469" xmi:uuid="f0e18120-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479433_894151_122054"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="35a88f90-6c46-013d-d60b-0800270c66d6" xmi:uuid="35a89060-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="35bb3740-6c46-013d-d60b-0800270c66d6" xmi:uuid="35bb3820-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_141628_122109" xmi:uuid="f0f9bf50-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="f0edfa20-915a-013c-7158-0a5172f4a469" xmi:uuid="f0edfb30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="f0f92500-915a-013c-7158-0a5172f4a469" xmi:uuid="f0f92600-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="406" y="525" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="392" y="497" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284713557_278935_123732" xmi:uuid="f13f9ea0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284715409_948338_123733"/>
      <source xmi:idref="_18_4_1_29c0149_1618422364232_115185_68925"/>
      <target xmi:idref="_18_4_1_65b021e_1702284479474_391924_122110"/>
      <waypoint x="928" y="637"/>
      <waypoint x="928" y="613"/>
      <waypoint x="763" y="613"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_348748_122098" xmi:uuid="f14016a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
      <ownedElement xmi:id="f11007e0-915a-013c-7158-0a5172f4a469" xmi:uuid="f1100900-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f11cf130-915a-013c-7158-0a5172f4a469" xmi:uuid="f11cf250-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="37b21790-6c46-013d-d60b-0800270c66d6" xmi:uuid="37b21830-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="37c896d0-6c46-013d-d60b-0800270c66d6" xmi:uuid="37c897c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_391924_122110" xmi:uuid="f13f0760-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="f1331910-915a-013c-7158-0a5172f4a469" xmi:uuid="f1331a20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="f13e70c0-915a-013c-7158-0a5172f4a469" xmi:uuid="f13e71d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="588" y="602" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="574" y="574" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284725250_189021_123801" xmi:uuid="f184ecd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284726634_48372_123802"/>
      <source xmi:idref="_18_4_1_29c0149_1618422364232_115185_68925"/>
      <target xmi:idref="_18_4_1_65b021e_1702284479474_801025_122111"/>
      <waypoint x="931" y="791"/>
      <waypoint x="931" y="847"/>
      <waypoint x="772" y="847"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_268687_122099" xmi:uuid="f1856060-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
      <ownedElement xmi:id="f15602b0-915a-013c-7158-0a5172f4a469" xmi:uuid="f15603c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f1625b10-915a-013c-7158-0a5172f4a469" xmi:uuid="f1625c20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="3a44a150-6c46-013d-d60b-0800270c66d6" xmi:uuid="3a44a200-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3a45e5d0-6c46-013d-d60b-0800270c66d6" xmi:uuid="3a45e6c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_801025_122111" xmi:uuid="f18450a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="f1788390-915a-013c-7158-0a5172f4a469" xmi:uuid="f17884a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f183b410-915a-013c-7158-0a5172f4a469" xmi:uuid="f183b5c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="588" y="833" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="574" y="805" width="246" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_524334_122100" xmi:uuid="f1ada040-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479437_871201_122055"/>
      <ownedElement xmi:id="f1931340-915a-013c-7158-0a5172f4a469" xmi:uuid="f1931440-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479437_871201_122055"/>
        <text>default:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_706054_122112" xmi:uuid="f1a14ae0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="3c88a090-6c46-013d-d60b-0800270c66d6" xmi:uuid="3c88a140-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="520" y="745" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="574" y="754" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_789500_122114" xmi:uuid="f1ad9540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="3cf5cb60-6c46-013d-d60b-0800270c66d6" xmi:uuid="3cf5cc40-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="738" y="743" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="720" y="752" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="574" y="742" width="161" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_319122_122116" xmi:uuid="f1adaa10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479444_662417_122059"/>
      <source xmi:idref="_18_4_1_65b021e_1702284479474_544628_122103"/>
      <target xmi:idref="_18_4_1_65b021e_1702284479474_621931_122092"/>
      <waypoint x="588" y="172"/>
      <waypoint x="512" y="172"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_213903_122117" xmi:uuid="f1adb660-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479444_494654_122067"/>
      <source xmi:idref="_18_4_1_65b021e_1702284479474_367186_122108"/>
      <target xmi:idref="_18_4_1_65b021e_1702284479474_470_122097"/>
      <waypoint x="529" y="403"/>
      <waypoint x="529" y="497"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284479474_537355_122118" xmi:uuid="f1adbdf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284479444_138520_122068"/>
      <source xmi:idref="_18_4_1_65b021e_1702284479474_501224_122106"/>
      <target xmi:idref="_18_4_1_65b021e_1702284479474_470_122097"/>
      <waypoint x="644" y="466"/>
      <waypoint x="644" y="529"/>
      <waypoint x="579" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284693131_596129_123624" xmi:uuid="f1adc6b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284694066_427727_123625"/>
      <source xmi:idref="_18_4_1_65b021e_1702284479474_129600_122101"/>
      <target xmi:idref="_18_4_1_65b021e_1702283996168_620102_118801"/>
      <waypoint x="588" y="102"/>
      <waypoint x="465" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284718046_513703_123753" xmi:uuid="f1adcf40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284719326_913316_123754"/>
      <source xmi:idref="_18_4_1_65b021e_1702284510879_372871_122812"/>
      <target xmi:idref="_18_4_1_65b021e_1702284479474_789500_122114"/>
      <waypoint x="910" y="763"/>
      <waypoint x="735" y="763"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284721266_160934_123777" xmi:uuid="f1add930-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284723287_545529_123778"/>
      <source xmi:idref="_18_4_1_65b021e_1702284479474_706054_122112"/>
      <target xmi:idref="_18_4_1_65b021e_1702283996168_628030_118805"/>
      <waypoint x="574" y="763"/>
      <waypoint x="461" y="763"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702284729602_614582_123822" xmi:uuid="f1ade210-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702284731532_75517_123823"/>
      <source xmi:idref="_18_4_1_65b021e_1702284479474_141628_122109"/>
      <target xmi:idref="_18_4_1_65b021e_1702283996168_879131_118803"/>
      <waypoint x="406" y="536"/>
      <waypoint x="319" y="536"/>
      <waypoint x="319" y="469"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1201" height="883"/>
    <name>SchemeVersionAssignment</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617721642860_252556_64517" xmi:uuid="d5b1c2f0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617200980407_188298_15943"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617722773892_145020_65215" xmi:uuid="d5b2cf40-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722773886_838239_65211"/>
      <bounds x="1111" y="464" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617722229702_692011_64712" xmi:uuid="d5b79600-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722463205_632139_64784"/>
      <ownedElement xmi:id="d5b4e5c0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5b4e750-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722463205_632139_64784"/>
        <text>Related:SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d5b62540-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5b626b0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722463205_632139_64784"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617722533272_849547_64858" xmi:uuid="d5b77ea0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617720793589_182632_62953"/>
        <ownedElement xmi:id="3fe9a190-6c46-013d-d60b-0800270c66d6" xmi:uuid="3fe9a290-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617720793589_182632_62953"/>
          <bounds x="200" y="626" width="143" height="13"/>
          <text>version : Scheme_version [1]</text>
        </ownedElement>
        <bounds x="182" y="635" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="630" width="169" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617722545561_149040_64877" xmi:uuid="d5b7b4c0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722547562_273887_64878"/>
      <source xmi:idref="_18_4_1_29c0149_1618425480849_302013_69616"/>
      <target xmi:idref="_18_4_1_2b2015d_1617722533272_849547_64858"/>
      <waypoint x="868" y="641"/>
      <waypoint x="197" y="641"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617722814394_315845_65238" xmi:uuid="d5b7d4d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722816463_564247_65239"/>
      <source xmi:idref="_18_4_1_2b2015d_1617722773892_145020_65215"/>
      <target xmi:idref="_18_4_1_29c0149_1618425395700_843429_69578"/>
      <waypoint x="1111" y="473"/>
      <waypoint x="1047" y="473"/>
      <waypoint x="1047" y="511"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617722229708_15117_64743" xmi:uuid="d5b9ccf0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722476853_432848_64790"/>
      <ownedElement xmi:id="d5b8dd80-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5b8de00-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722476853_432848_64790"/>
        <text>Relating:SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d5b942e0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5b94350-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722476853_432848_64790"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617722581515_342057_64890" xmi:uuid="d5b9c410-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617720793589_182632_62953"/>
        <ownedElement xmi:id="40584fa0-6c46-013d-d60b-0800270c66d6" xmi:uuid="40585040-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617720793589_182632_62953"/>
          <bounds x="204" y="668" width="143" height="13"/>
          <text>version : Scheme_version [1]</text>
        </ownedElement>
        <bounds x="186" y="677" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="672" width="173" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617722592513_641608_64909" xmi:uuid="d5b9d9a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1617722594136_934507_64910"/>
      <source xmi:idref="_18_4_1_29c0149_1618425480860_66794_69647"/>
      <target xmi:idref="_18_4_1_2b2015d_1617722581515_342057_64890"/>
      <waypoint x="868" y="683"/>
      <waypoint x="201" y="683"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1618425395700_843429_69578" xmi:uuid="d6362200-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425411770_666808_69609"/>
      <ownedElement xmi:id="d5ceab20-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5ceac40-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425411770_666808_69609"/>
        <text>relate:Scheme_version_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d5cf2220-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5cf22a0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425411770_666808_69609"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="411c1f20-6c46-013d-d60b-0800270c66d6" xmi:uuid="411c1fd0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="413c3810-6c46-013d-d60b-0800270c66d6" xmi:uuid="413c38f0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618425480849_302013_69616" xmi:uuid="d6009350-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_relationship-related_method"/>
          <ownedElement xmi:id="d5eb05f0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d5eb06e0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_relationship-related_method"/>
            <text>related_method:Scheme_version</text>
          </ownedElement>
          <ownedElement xmi:id="d6008510-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d6008600-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_relationship-related_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="868" y="630" width="220" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1618425480860_66794_69647" xmi:uuid="d6361400-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_relationship-relating_method"/>
          <ownedElement xmi:id="d622d5b0-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d622d6d0-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_relationship-relating_method"/>
            <text>relating_method:Scheme_version</text>
          </ownedElement>
          <ownedElement xmi:id="d6360710-8fde-0139-a9d8-78b156d8ad1a" xmi:uuid="d6360860-8fde-0139-a9d8-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Scheme_version_relationship-relating_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="868" y="672" width="223" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286476195_312039_126485" xmi:uuid="f252fbb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-description"/>
          <ownedElement xmi:id="f246feb0-915a-013c-7158-0a5172f4a469" xmi:uuid="f2470000-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="f25257c0-915a-013c-7158-0a5172f4a469" xmi:uuid="f25258e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="868" y="546" width="150" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286476205_980526_126516" xmi:uuid="f26a5aa0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-name"/>
          <ownedElement xmi:id="f25e76c0-915a-013c-7158-0a5172f4a469" xmi:uuid="f25e77e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="f269bcb0-915a-013c-7158-0a5172f4a469" xmi:uuid="f269bdd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method_relationship-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="868" y="588" width="107" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="854" y="511" width="245" height="203"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702053785815_16566_110759" xmi:uuid="f26a6c20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="385" y="14" width="115" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287817697_578283_133690" xmi:uuid="f2ca0600-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287820682_550718_133691"/>
      <source xmi:idref="_18_4_1_29c0149_1618425395700_843429_69578"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_530957_131074"/>
      <waypoint x="872" y="511"/>
      <waypoint x="872" y="151"/>
      <waypoint x="729" y="151"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_784589_131062" xmi:uuid="f2cafd20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968424_92873_131014"/>
      <ownedElement xmi:id="f276a160-915a-013c-7158-0a5172f4a469" xmi:uuid="f276a290-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968424_92873_131014"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f278de10-915a-013c-7158-0a5172f4a469" xmi:uuid="f278df30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968424_92873_131014"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="457b8f50-6c46-013d-d60b-0800270c66d6" xmi:uuid="457b8ff0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4587a200-6c46-013d-d60b-0800270c66d6" xmi:uuid="4587a3b0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_803647_131073" xmi:uuid="f2914cd0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="f2855b70-915a-013c-7158-0a5172f4a469" xmi:uuid="f2855c80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="f290a9a0-915a-013c-7158-0a5172f4a469" xmi:uuid="f290aab0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="546" y="105" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_530957_131074" xmi:uuid="f2b2ae00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="f2a6a0f0-915a-013c-7158-0a5172f4a469" xmi:uuid="f2a6a200-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f2b1fc00-915a-013c-7158-0a5172f4a469" xmi:uuid="f2b1fd20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="140" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_213275_131075" xmi:uuid="f2c96bc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="f2bde440-915a-013c-7158-0a5172f4a469" xmi:uuid="f2bde540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="f2c8d2c0-915a-013c-7158-0a5172f4a469" xmi:uuid="f2c8d3d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="546" y="175" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="532" y="77" width="254" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_138344_131063" xmi:uuid="f2cf58e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968428_992871_131015"/>
      <ownedElement xmi:id="f2cd27a0-915a-013c-7158-0a5172f4a469" xmi:uuid="f2cd2b70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968428_992871_131015"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="f2cf3fd0-915a-013c-7158-0a5172f4a469" xmi:uuid="f2cf40d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968428_992871_131015"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="287" y="175" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287813511_777474_133669" xmi:uuid="f3146050-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287815176_804038_133670"/>
      <source xmi:idref="_18_4_1_29c0149_1618425395700_843429_69578"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_834337_131076"/>
      <waypoint x="872" y="511"/>
      <waypoint x="872" y="263"/>
      <waypoint x="729" y="263"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_360823_131064" xmi:uuid="f314d250-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="f2e51180-915a-013c-7158-0a5172f4a469" xmi:uuid="f2e51290-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f2f15300-915a-013c-7158-0a5172f4a469" xmi:uuid="f2f15410-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="49b05f80-6c46-013d-d60b-0800270c66d6" xmi:uuid="49b06030-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="49c8f370-6c46-013d-d60b-0800270c66d6" xmi:uuid="49c8f450-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_834337_131076" xmi:uuid="f313ca40-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="f307f690-915a-013c-7158-0a5172f4a469" xmi:uuid="f307f7b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f31327e0-915a-013c-7158-0a5172f4a469" xmi:uuid="f31328f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="252" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="532" y="224" width="237" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287806562_275296_133648" xmi:uuid="f35a0730-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287810842_901713_133649"/>
      <source xmi:idref="_18_4_1_29c0149_1618425395700_843429_69578"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_446693_131077"/>
      <waypoint x="872" y="511"/>
      <waypoint x="872" y="340"/>
      <waypoint x="730" y="340"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_308256_131065" xmi:uuid="f35a73e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="f32b6150-915a-013c-7158-0a5172f4a469" xmi:uuid="f32b6260-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f3378b00-915a-013c-7158-0a5172f4a469" xmi:uuid="f3378c10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4c245bd0-6c46-013d-d60b-0800270c66d6" xmi:uuid="4c245c80-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4c3d0ae0-6c46-013d-d60b-0800270c66d6" xmi:uuid="4c3d0bb0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_446693_131077" xmi:uuid="f35977c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="f34dac90-915a-013c-7158-0a5172f4a469" xmi:uuid="f34dadc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f358e600-915a-013c-7158-0a5172f4a469" xmi:uuid="f358e710-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="329" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="532" y="301" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287803355_753113_133627" xmi:uuid="f39fceb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287804640_777545_133628"/>
      <source xmi:idref="_18_4_1_29c0149_1618425395700_843429_69578"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_670070_131078"/>
      <waypoint x="872" y="511"/>
      <waypoint x="872" y="420"/>
      <waypoint x="721" y="420"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_678133_131066" xmi:uuid="f3a04630-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="f3705780-915a-013c-7158-0a5172f4a469" xmi:uuid="f37058a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f37caa80-915a-013c-7158-0a5172f4a469" xmi:uuid="f37cabc0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4eac0c30-6c46-013d-d60b-0800270c66d6" xmi:uuid="4eac0d10-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4ead9dd0-6c46-013d-d60b-0800270c66d6" xmi:uuid="4ead9e80-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_670070_131078" xmi:uuid="f39f3b80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="f3937340-915a-013c-7158-0a5172f4a469" xmi:uuid="f3937450-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="f39e9dd0-915a-013c-7158-0a5172f4a469" xmi:uuid="f39e9f00-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="406" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="532" y="378" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287742836_823030_133505" xmi:uuid="f3e62ce0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287744354_410435_133506"/>
      <source xmi:idref="_18_4_1_29c0149_1618425395700_843429_69578"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_727035_131079"/>
      <waypoint x="872" y="511"/>
      <waypoint x="872" y="494"/>
      <waypoint x="774" y="494"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_325029_131067" xmi:uuid="f3e69f70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="f3b6b9a0-915a-013c-7158-0a5172f4a469" xmi:uuid="f3b6bac0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="f3c35c30-915a-013c-7158-0a5172f4a469" xmi:uuid="f3c35d60-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="50ebe980-6c46-013d-d60b-0800270c66d6" xmi:uuid="50ebea20-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="50f4f000-6c46-013d-d60b-0800270c66d6" xmi:uuid="50f4f0d0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_727035_131079" xmi:uuid="f3e5a1c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="f3d9dd00-915a-013c-7158-0a5172f4a469" xmi:uuid="f3d9de10-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="f3e50f20-915a-013c-7158-0a5172f4a469" xmi:uuid="f3e51030-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="483" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="532" y="455" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_407560_131068" xmi:uuid="f3eaee80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968432_140769_131016"/>
      <ownedElement xmi:id="f3e8c7a0-915a-013c-7158-0a5172f4a469" xmi:uuid="f3e8c8b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968432_140769_131016"/>
        <text>theName:String</text>
      </ownedElement>
      <ownedElement xmi:id="f3eadef0-915a-013c-7158-0a5172f4a469" xmi:uuid="f3eae000-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968432_140769_131016"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="532" y="595" width="181" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287798867_196152_133606" xmi:uuid="f45506d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287800453_285083_133607"/>
      <source xmi:idref="_18_4_1_29c0149_1618425395700_843429_69578"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_992469_131081"/>
      <waypoint x="889" y="714"/>
      <waypoint x="889" y="753"/>
      <waypoint x="730" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_193061_131069" xmi:uuid="f4557560-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968436_394593_131017"/>
      <ownedElement xmi:id="f3f7d3c0-915a-013c-7158-0a5172f4a469" xmi:uuid="f3f7d4e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968436_394593_131017"/>
        <text>smlpTypeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f3f9f540-915a-013c-7158-0a5172f4a469" xmi:uuid="f3f9f640-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968436_394593_131017"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="53054f60-6c46-013d-d60b-0800270c66d6" xmi:uuid="53054ff0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5315e310-6c46-013d-d60b-0800270c66d6" xmi:uuid="5315e3c0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_446054_131080" xmi:uuid="f41becb0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="f40fd820-915a-013c-7158-0a5172f4a469" xmi:uuid="f40fd940-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="f41b5f40-915a-013c-7158-0a5172f4a469" xmi:uuid="f41b6050-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="770" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_992469_131081" xmi:uuid="f43d5650-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="f4317120-915a-013c-7158-0a5172f4a469" xmi:uuid="f4317230-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f43cb490-915a-013c-7158-0a5172f4a469" xmi:uuid="f43cb5c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="735" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_424200_131082" xmi:uuid="f4545e70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="f4488d60-915a-013c-7158-0a5172f4a469" xmi:uuid="f4488e70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="f453c340-915a-013c-7158-0a5172f4a469" xmi:uuid="f453c450-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="546" y="805" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="532" y="707" width="272" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287793999_310941_133587" xmi:uuid="f49ad4e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287795265_476135_133588"/>
      <source xmi:idref="_18_4_1_29c0149_1618425395700_843429_69578"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_786889_131083"/>
      <waypoint x="889" y="714"/>
      <waypoint x="889" y="959"/>
      <waypoint x="730" y="959"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_505782_131070" xmi:uuid="f49b59c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="f46bb730-915a-013c-7158-0a5172f4a469" xmi:uuid="f46bb840-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f477ef40-915a-013c-7158-0a5172f4a469" xmi:uuid="f477f050-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="56c40ef0-6c46-013d-d60b-0800270c66d6" xmi:uuid="56c40f90-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="56d7b390-6c46-013d-d60b-0800270c66d6" xmi:uuid="56d7b470-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_786889_131083" xmi:uuid="f49a34c0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="f48e4430-915a-013c-7158-0a5172f4a469" xmi:uuid="f48e4540-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f49985e0-915a-013c-7158-0a5172f4a469" xmi:uuid="f49986f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="945" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="532" y="917" width="256" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_642279_131071" xmi:uuid="f49f97d0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968440_565667_131018"/>
      <ownedElement xmi:id="f49d6fb0-915a-013c-7158-0a5172f4a469" xmi:uuid="f49d70b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968440_565667_131018"/>
        <text>theType:String</text>
      </ownedElement>
      <ownedElement xmi:id="f49f8870-915a-013c-7158-0a5172f4a469" xmi:uuid="f49f8960-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968440_565667_131018"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="322" y="889" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_666138_131072" xmi:uuid="f4dc5cf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968444_190816_131019"/>
      <ownedElement xmi:id="f4ab9490-915a-013c-7158-0a5172f4a469" xmi:uuid="f4ab95a0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968444_190816_131019"/>
        <text>smplType:Class</text>
      </ownedElement>
      <ownedElement xmi:id="f4adaef0-915a-013c-7158-0a5172f4a469" xmi:uuid="f4adb010-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968444_190816_131019"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="58b15410-6c46-013d-d60b-0800270c66d6" xmi:uuid="58b154b0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="58b2df20-6c46-013d-d60b-0800270c66d6" xmi:uuid="58b2e010-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_511540_131084" xmi:uuid="f4c5b3e0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="f4b9faf0-915a-013c-7158-0a5172f4a469" xmi:uuid="f4b9fc20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="f4c51ef0-915a-013c-7158-0a5172f4a469" xmi:uuid="f4c52000-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="336" y="805" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_544591_131085" xmi:uuid="f4dc4ef0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="f4d0da70-915a-013c-7158-0a5172f4a469" xmi:uuid="f4d0db80-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="f4dbb5d0-915a-013c-7158-0a5172f4a469" xmi:uuid="f4dbb6f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="336" y="840" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="322" y="777" width="133" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_700037_131086" xmi:uuid="f4dc6480-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968448_798226_131023"/>
      <source xmi:idref="_18_4_1_65b021e_1702286968480_213275_131075"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_138344_131063"/>
      <waypoint x="546" y="186"/>
      <waypoint x="421" y="186"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_168142_131087" xmi:uuid="f4dc6cf0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968449_289278_131035"/>
      <source xmi:idref="_18_4_1_65b021e_1702286968480_424200_131082"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_642279_131071"/>
      <waypoint x="564" y="830"/>
      <waypoint x="564" y="900"/>
      <waypoint x="490" y="900"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702286968480_113882_131088" xmi:uuid="f4dc7560-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702286968449_566118_131040"/>
      <source xmi:idref="_18_4_1_65b021e_1702286968480_446054_131080"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_666138_131072"/>
      <waypoint x="546" y="781"/>
      <waypoint x="455" y="781"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287048836_899666_132224" xmi:uuid="f50cef30-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="f4f422f0-915a-013c-7158-0a5172f4a469" xmi:uuid="f4f42400-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702287048836_937572_132227" xmi:uuid="f50ce850-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="5b71aac0-6c46-013d-d60b-0800270c66d6" xmi:uuid="5b71ab70-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="447" y="101" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="429" y="110" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="287" y="98" width="157" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287048836_494702_132225" xmi:uuid="f53d2650-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="f52493e0-915a-013c-7158-0a5172f4a469" xmi:uuid="f5249520-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702287048836_51263_132229" xmi:uuid="f53d1e90-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="5cc6a3a0-6c46-013d-d60b-0800270c66d6" xmi:uuid="5cc6acc0-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="539" y="543" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="521" y="552" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="287" y="539" width="249" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287048836_647898_132226" xmi:uuid="f56d8f20-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="f554b650-915a-013c-7158-0a5172f4a469" xmi:uuid="f554b8f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1702287048836_968572_132231" xmi:uuid="f56d8850-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="5e049b90-6c46-013d-d60b-0800270c66d6" xmi:uuid="5e049c40-6c46-013d-d60b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="305" y="759" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="295" y="741" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="287" y="707" width="163" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287734099_132239_133460" xmi:uuid="f56d9ee0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287735281_852333_133461"/>
      <source xmi:idref="_18_4_1_65b021e_1702286476205_980526_126516"/>
      <target xmi:idref="_18_4_1_65b021e_1702286968480_407560_131068"/>
      <waypoint x="868" y="599"/>
      <waypoint x="713" y="599"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287737350_704326_133481" xmi:uuid="f56da4b0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287739682_73164_133482"/>
      <source xmi:idref="_18_4_1_65b021e_1702286476195_312039_126485"/>
      <target xmi:idref="_18_4_1_65b021e_1702287048836_51263_132229"/>
      <waypoint x="868" y="560"/>
      <waypoint x="536" y="560"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287782676_812021_133543" xmi:uuid="f56dac70-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287784474_850265_133544"/>
      <source xmi:idref="_18_4_1_65b021e_1702286968480_511540_131084"/>
      <target xmi:idref="_18_4_1_65b021e_1702287048836_968572_132231"/>
      <waypoint x="336" y="816"/>
      <waypoint x="301" y="816"/>
      <waypoint x="301" y="756"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287787295_56956_133565" xmi:uuid="f56db370-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287788775_509127_133566"/>
      <source xmi:idref="_18_4_1_65b021e_1702286968480_544591_131085"/>
      <target xmi:idref="_18_4_1_65b021e_1702287048836_968572_132231"/>
      <waypoint x="336" y="851"/>
      <waypoint x="301" y="851"/>
      <waypoint x="301" y="756"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1702287823983_141443_133711" xmi:uuid="f56db9f0-915a-013c-7158-0a5172f4a469" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1702287825001_215921_133712"/>
      <source xmi:idref="_18_4_1_65b021e_1702286968480_803647_131073"/>
      <target xmi:idref="_18_4_1_65b021e_1702287048836_937572_132227"/>
      <waypoint x="546" y="116"/>
      <waypoint x="444" y="116"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1114" height="995"/>
    <name>SchemeVersionRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446300277_114859_284873" xmi:uuid="e3a558d0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300300_497888_284905" xmi:uuid="e4650cc0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416142585_802498_67523"/>
      <ownedElement xmi:id="e44d18c0-6c44-013d-d60b-0800270c66d6" xmi:uuid="e44d19a0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416142585_802498_67523"/>
        <text>theScheme:Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="e464fb60-6c44-013d-d60b-0800270c66d6" xmi:uuid="e464fc20-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618416142585_802498_67523"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="141" height="930"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300316_398933_284939" xmi:uuid="e46656f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="545" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300323_666845_284954" xmi:uuid="e4978140-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_13110319_1585036997439_273570_58540"/>
      <bounds x="545" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300339_360341_284969" xmi:uuid="e498c1b0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="545" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300349_693767_284984" xmi:uuid="e499ffd0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551689215050_535893_40191"/>
      <bounds x="545" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300359_240780_284999" xmi:uuid="e49b44b0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="545" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300368_747149_285014" xmi:uuid="e4d67fc0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="545" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300382_61337_285029" xmi:uuid="e4d7c670-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="545" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300392_442271_285044" xmi:uuid="e4d90cd0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="545" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300403_908610_285059" xmi:uuid="e4da5710-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="545" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300412_681234_285074" xmi:uuid="e5203aa0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="545" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300426_842696_285089" xmi:uuid="e53c8350-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="545" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300436_567701_285104" xmi:uuid="e53e65b0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642527069326_238058_76283"/>
      <bounds x="545" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300450_290737_285119" xmi:uuid="e576a050-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="545" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300465_375319_285134" xmi:uuid="e58ed400-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="545" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300473_856110_285149" xmi:uuid="e5a800d0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1540915512831_719143_31709"/>
      <bounds x="545" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300487_738977_285164" xmi:uuid="e5ccb0a0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="545" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300497_562122_285179" xmi:uuid="e5cdf220-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="545" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300506_229851_285194" xmi:uuid="e5e45d90-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="545" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300518_990070_285209" xmi:uuid="e5e5a290-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="545" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300528_847092_285224" xmi:uuid="e5e6e320-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="545" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300538_819635_285239" xmi:uuid="e62e97f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="545" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300554_895505_285254" xmi:uuid="e640bff0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="545" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300571_861568_285269" xmi:uuid="e655d1f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="545" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300583_201162_285284" xmi:uuid="e66b3f90-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="545" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300591_637136_285299" xmi:uuid="e66c82c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1540916564417_774412_33192"/>
      <bounds x="545" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300606_673902_285314" xmi:uuid="e66dc260-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="545" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300615_926278_285329" xmi:uuid="e68db990-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="545" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300630_182238_285344" xmi:uuid="e69fb810-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="545" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300640_919376_285359" xmi:uuid="e6c12730-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583916459359_231472_65084"/>
      <bounds x="545" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300651_434484_285374" xmi:uuid="e6c28070-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="545" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300662_780055_285389" xmi:uuid="e6c3c920-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="545" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300672_728751_285404" xmi:uuid="e6f5f530-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
      <bounds x="545" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300682_594843_285419" xmi:uuid="e6f74a40-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
      <bounds x="545" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300690_759801_285434" xmi:uuid="e7197a70-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828862325_997404_79169"/>
      <bounds x="545" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300700_57608_285449" xmi:uuid="e7335a60-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="545" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300710_165157_285464" xmi:uuid="e74b76f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="545" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300721_442575_285479" xmi:uuid="e755da00-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="545" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300732_716016_285494" xmi:uuid="e75719c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="545" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300743_760956_285509" xmi:uuid="e76c8970-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="545" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300753_366783_285524" xmi:uuid="e76e03b0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="545" y="835" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300765_696573_285539" xmi:uuid="e790fda0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="545" y="855" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300773_173780_285554" xmi:uuid="e7abf520-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570204497794_443467_105732"/>
      <bounds x="545" y="875" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300782_370784_285569" xmi:uuid="e7bf9f10-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577962989407_4853_51636"/>
      <bounds x="545" y="895" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446300792_79099_285584" xmi:uuid="e7d64440-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="545" y="915" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_472572_402431" xmi:uuid="e7d65710-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665185_215281_270573"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300316_398933_284939"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="62"/>
      <waypoint x="186" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_64117_402434" xmi:uuid="e7d65fc0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_2b2015d_1662738279519_46186_68483"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300323_666845_284954"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="82"/>
      <waypoint x="186" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_122328_402437" xmi:uuid="e7d66660-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665280_846812_270604"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300339_360341_284969"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="102"/>
      <waypoint x="186" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_771721_402440" xmi:uuid="e7d66d10-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665373_14414_270620"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300349_693767_284984"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="122"/>
      <waypoint x="186" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_376505_402443" xmi:uuid="e7d674b0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665463_524845_270636"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300359_240780_284999"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="142"/>
      <waypoint x="186" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_729911_402446" xmi:uuid="e7d6cfa0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665541_197870_270652"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300368_747149_285014"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="162"/>
      <waypoint x="186" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_672177_402449" xmi:uuid="e7d6d870-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665619_805840_270668"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300382_61337_285029"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="182"/>
      <waypoint x="186" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_806694_402452" xmi:uuid="e7d6e020-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665715_157835_270684"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300392_442271_285044"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="202"/>
      <waypoint x="186" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_428165_402455" xmi:uuid="e7d6e6c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665791_734581_270700"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300403_908610_285059"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="222"/>
      <waypoint x="186" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_537352_402458" xmi:uuid="e7d6ecd0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665877_374149_270716"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300412_681234_285074"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="242"/>
      <waypoint x="186" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_204953_402461" xmi:uuid="e7d6f340-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606665962_508435_270732"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300426_842696_285089"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="262"/>
      <waypoint x="186" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_153472_402464" xmi:uuid="e7d6f9c0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606666055_450421_270748"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300436_567701_285104"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="282"/>
      <waypoint x="186" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_739640_402467" xmi:uuid="e7d6ff90-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606666139_232222_270764"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300450_290737_285119"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="302"/>
      <waypoint x="186" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_729960_402470" xmi:uuid="e7d70510-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606666235_493908_270780"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300465_375319_285134"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="322"/>
      <waypoint x="186" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_765109_402473" xmi:uuid="e7d70b60-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606666325_923109_270796"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300473_856110_285149"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="342"/>
      <waypoint x="186" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_384033_402476" xmi:uuid="e7d710f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606666402_745404_270812"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300487_738977_285164"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="362"/>
      <waypoint x="186" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_987110_402479" xmi:uuid="e7d71680-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606666536_765486_270828"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300497_562122_285179"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="382"/>
      <waypoint x="186" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_529017_402482" xmi:uuid="e7d71bd0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606666688_459115_270844"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300506_229851_285194"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="402"/>
      <waypoint x="186" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_868900_402485" xmi:uuid="e7d721f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606666780_615849_270860"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300518_990070_285209"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="422"/>
      <waypoint x="186" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_949376_402488" xmi:uuid="e7d72780-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606666871_32551_270876"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300528_847092_285224"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="442"/>
      <waypoint x="186" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_660714_402491" xmi:uuid="e7d72d50-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606666956_757687_270892"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300538_819635_285239"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="462"/>
      <waypoint x="186" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_20387_402494" xmi:uuid="e7d732f0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667041_386400_270908"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300554_895505_285254"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="482"/>
      <waypoint x="186" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_720167_402497" xmi:uuid="e7d73a10-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667126_906362_270924"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300571_861568_285269"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="502"/>
      <waypoint x="186" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_579299_402500" xmi:uuid="e7d74030-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667208_594416_270940"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300583_201162_285284"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="522"/>
      <waypoint x="186" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_768720_402503" xmi:uuid="e7d745e0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667289_463991_270956"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300591_637136_285299"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="542"/>
      <waypoint x="186" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_581956_402506" xmi:uuid="e7d74ba0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667360_763301_270972"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300606_673902_285314"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="562"/>
      <waypoint x="186" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_596850_402509" xmi:uuid="e7d75120-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667440_24330_270988"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300615_926278_285329"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="582"/>
      <waypoint x="186" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_801646_402512" xmi:uuid="e7d75830-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667514_162588_271004"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300630_182238_285344"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="602"/>
      <waypoint x="186" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_504263_402515" xmi:uuid="e7d75e60-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667596_127658_271020"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300640_919376_285359"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="622"/>
      <waypoint x="186" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_981305_402518" xmi:uuid="e7d763d0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667675_604521_271036"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300651_434484_285374"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="642"/>
      <waypoint x="186" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_688450_402521" xmi:uuid="e7d769b0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667753_265658_271052"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300662_780055_285389"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="662"/>
      <waypoint x="186" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496696_306816_402524" xmi:uuid="e7d76e70-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667828_73941_271068"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300672_728751_285404"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="682"/>
      <waypoint x="186" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_981553_402527" xmi:uuid="e7d77320-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667904_136299_271084"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300682_594843_285419"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="702"/>
      <waypoint x="186" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_82800_402530" xmi:uuid="e7d77af0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606667990_608169_271100"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300690_759801_285434"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="722"/>
      <waypoint x="186" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_997695_402533" xmi:uuid="e7ecd010-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606668071_148723_271116"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300700_57608_285449"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="742"/>
      <waypoint x="186" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_552285_402536" xmi:uuid="e7ecd610-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606668152_426886_271132"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300710_165157_285464"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="762"/>
      <waypoint x="186" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_465837_402539" xmi:uuid="e7ecdd20-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606668239_178123_271148"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300721_442575_285479"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="782"/>
      <waypoint x="186" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_881578_402542" xmi:uuid="e7ece400-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606668323_312018_271164"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300732_716016_285494"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="802"/>
      <waypoint x="186" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_471425_402545" xmi:uuid="e7ece980-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606668404_570627_271180"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300743_760956_285509"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="822"/>
      <waypoint x="186" y="822"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_139575_402548" xmi:uuid="e7eceee0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606668491_237618_271196"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300753_366783_285524"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="842"/>
      <waypoint x="186" y="842"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_557537_402551" xmi:uuid="e7ecf420-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606668579_398185_271212"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300765_696573_285539"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="862"/>
      <waypoint x="186" y="862"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_329021_402554" xmi:uuid="e7ecf920-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606668663_249750_271228"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300773_173780_285554"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="880"/>
      <waypoint x="186" y="880"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_296204_402557" xmi:uuid="e7ecfe30-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606668748_963444_271244"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300782_370784_285569"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="903"/>
      <waypoint x="186" y="903"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496697_102563_402560" xmi:uuid="e7ed03d0-6c44-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1706606668834_596369_271260"/>
      <source xmi:idref="_18_4_1_65b021e_1727446300792_79099_285584"/>
      <target xmi:idref="_18_4_1_65b021e_1727446300300_497888_284905"/>
      <waypoint x="545" y="921"/>
      <waypoint x="186" y="921"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="548" height="1000"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446299482_473634_283847" xmi:uuid="f48bfcb0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1617201153286_596027_16081"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299504_684296_283879" xmi:uuid="f53676a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425633091_431491_69712"/>
      <ownedElement xmi:id="f51acdb0-6c45-013d-d60b-0800270c66d6" xmi:uuid="f51ace40-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425633091_431491_69712"/>
        <text>relate:Scheme_entry_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="f5366100-6c45-013d-d60b-0800270c66d6" xmi:uuid="f53661d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlanningScheduling.xmi#_18_4_1_29c0149_1618425633091_431491_69712"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="213" height="370"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299519_882629_283913" xmi:uuid="f53f6670-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="573" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299533_619872_283928" xmi:uuid="f54fda30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="573" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299547_653888_283943" xmi:uuid="f5512fa0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="573" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299556_814028_283958" xmi:uuid="f5535450-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="573" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299564_602887_283973" xmi:uuid="f57fd3d0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="573" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299578_683731_283988" xmi:uuid="f5a64950-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="573" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299592_173260_284003" xmi:uuid="f5b94f60-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="573" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299606_639359_284018" xmi:uuid="f5c8be80-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="573" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299620_166030_284033" xmi:uuid="f5d56b90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="573" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299629_913888_284048" xmi:uuid="f5f76f90-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="573" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299645_134892_284063" xmi:uuid="f604d030-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="573" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299660_222416_284078" xmi:uuid="f6063ac0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="573" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299674_720963_284093" xmi:uuid="f6155440-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="573" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299683_94148_284108" xmi:uuid="f624c040-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="573" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299696_315784_284123" xmi:uuid="f6370e10-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="573" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446299707_180680_284138" xmi:uuid="f65c1b20-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="573" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_401873_402251" xmi:uuid="f65c2ab0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601394987_431079_255076"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299519_882629_283913"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="62"/>
      <waypoint x="258" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_733528_402254" xmi:uuid="f65c3340-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395150_112660_255108"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299533_619872_283928"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="82"/>
      <waypoint x="258" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_802100_402257" xmi:uuid="f65c3aa0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395233_113455_255124"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299547_653888_283943"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="102"/>
      <waypoint x="258" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_240191_402260" xmi:uuid="f65c4180-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395317_508170_255140"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299556_814028_283958"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="122"/>
      <waypoint x="258" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_223745_402263" xmi:uuid="f65c4820-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395397_520225_255156"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299564_602887_283973"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="142"/>
      <waypoint x="258" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_874462_402266" xmi:uuid="f65c4f30-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395474_412956_255172"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299578_683731_283988"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="162"/>
      <waypoint x="258" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_161558_402269" xmi:uuid="f65c5620-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395556_678369_255188"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299592_173260_284003"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="182"/>
      <waypoint x="258" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_895068_402272" xmi:uuid="f65c5cb0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395640_792294_255204"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299606_639359_284018"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="202"/>
      <waypoint x="258" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_29508_402275" xmi:uuid="f65c6460-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395724_35952_255220"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299620_166030_284033"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="222"/>
      <waypoint x="258" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_719345_402278" xmi:uuid="f65c6cf0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395807_883922_255236"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299629_913888_284048"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="242"/>
      <waypoint x="258" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_560888_402281" xmi:uuid="f65c7540-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395887_458522_255252"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299645_134892_284063"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="262"/>
      <waypoint x="258" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_953073_402284" xmi:uuid="f65c7ce0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601395969_550584_255268"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299660_222416_284078"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="282"/>
      <waypoint x="258" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_687281_402287" xmi:uuid="f65c83a0-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601396054_706650_255284"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299674_720963_284093"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="302"/>
      <waypoint x="258" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_306730_402290" xmi:uuid="f65c8b50-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601396137_882564_255300"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299683_94148_284108"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="322"/>
      <waypoint x="258" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_856920_402293" xmi:uuid="f65c9120-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601396215_163472_255316"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299696_315784_284123"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="342"/>
      <waypoint x="258" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496655_738191_402296" xmi:uuid="f65c9840-6c45-013d-d60b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="PlanningScheduling.xmi#_18_4_1_65b021e_1696601396299_50231_255332"/>
      <source xmi:idref="_18_4_1_65b021e_1727446299707_180680_284138"/>
      <target xmi:idref="_18_4_1_65b021e_1727446299504_684296_283879"/>
      <waypoint x="573" y="362"/>
      <waypoint x="258" y="362"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="576" height="440"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
