<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703186087385_621610_465841" xmi:uuid="2ee25ee0-915e-013c-7161-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703186087380_819484_465830"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_8e001ed_1498551957523_330847_14120"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703186167554_666304_469313" xmi:uuid="41b29ec0-915e-013c-7161-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703186167549_940744_469302"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_8e001ed_1498551957523_330847_14120"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_2b2015d_1617887902981_193828_13989" xmi:uuid="7b5c1160-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLClassDiagram xmi:idref="_18_4_1_2b2015d_1617887902934_945942_13977"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_8e001ed_1498551957523_330847_14120"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617888884138_556703_63693" xmi:uuid="08733f20-6af0-013a-da2b-3770a1b6a6fd">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617888883553_906058_62862"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617888879632_912952_62430"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446393139_138526_337700" xmi:uuid="0f200cc0-6c46-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446393132_573085_337689"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1618414083897_902466_68707"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446398572_158691_341253" xmi:uuid="1d8d38a0-6c46-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446398564_612003_341242"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1618414876147_13677_70498"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446393386_973800_337977" xmi:uuid="45be2700-6c45-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446393379_177201_337966"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617888879632_807376_62431"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446393627_27643_338265" xmi:uuid="5323aa10-6c45-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446393620_918978_338254"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617896577119_372619_73340"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446398106_670306_340590" xmi:uuid="589dd2d0-6c45-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446398099_818352_340579"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617896633035_973986_73395"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617888884023_349217_63125" xmi:uuid="7ca57bc0-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617888880650_165708_62445"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446396103_221147_339759" xmi:uuid="7cf15680-6c45-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446396096_883569_339748"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617898760198_472667_73458"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617888884085_495634_63445" xmi:uuid="841732d0-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617888881983_347092_62649"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617888884123_462689_63692" xmi:uuid="883b2ef0-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617888883152_272616_62831"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617888879632_912952_62430"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617888884185_803599_63956" xmi:uuid="8cc10210-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617888883838_335885_63029"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617888879632_807376_62431"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617982275776_258030_67860" xmi:uuid="90d59690-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617982275772_481953_67849"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617896577119_372619_73340"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617980032235_597820_65097" xmi:uuid="91d43dc0-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617980032228_284321_65086"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617896633035_973986_73395"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617980842387_481886_66441" xmi:uuid="91e588d0-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617980842382_981971_66430"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617898760198_472667_73458"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617985064093_687380_69854" xmi:uuid="95745d80-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617985064068_959656_69816"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617985064068_761734_69815"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1617985594501_548448_71142" xmi:uuid="98bd1340-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1617985594467_349690_71104"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617985594452_714034_71103"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446399078_605108_341797" xmi:uuid="9bc81ef0-6c45-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446399070_38803_341786"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617985064068_761734_69815"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1618412233353_847651_64036" xmi:uuid="9c1aaef0-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1618412233353_612916_64025"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1618411141068_701578_62793"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1618414083929_952749_68762" xmi:uuid="a121bfe0-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1618414083897_197346_68708"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1618414083897_902466_68707"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1618414979177_544199_70565" xmi:uuid="a6256380-8fe0-0139-a9e0-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1618414979161_306015_70554"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1618414876147_13677_70498"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446400734_20284_341980" xmi:uuid="ba5172b0-6c45-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446400725_16204_341969"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617985594452_714034_71103"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446394094_694541_338928" xmi:uuid="bfbf28c0-6c44-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446394087_632249_338917"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446395912_51660_339531" xmi:uuid="e6cbfdc0-6c45-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446395905_761328_339520"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1618411141068_701578_62793"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446396254_887794_339942" xmi:uuid="ed8ece30-6c44-013d-d609-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446396247_981792_339931"/>
    <defaultNamespace href="Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703186087380_819484_465830" xmi:uuid="2ee0b120-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Risk.xmi#_18_4_1_8e001ed_1498551957523_330847_14120"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186087438_367553_465863" xmi:uuid="2eee0eb0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414214099_999308_70263"/>
      <ownedElement xmi:id="2ee80b60-915e-013c-7161-0a5172f4a469" xmi:uuid="2ee80c80-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414214099_999308_70263"/>
        <text>RiskImpactAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="2eeaec30-915e-013c-7161-0a5172f4a469" xmi:uuid="2eeaed70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="2eec4210-915e-013c-7161-0a5172f4a469" xmi:uuid="2eec4450-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1248" height="655"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186089900_992043_465934" xmi:uuid="2f2b2610-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="2ef7bc40-915e-013c-7161-0a5172f4a469" xmi:uuid="2ef7bd70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="0833e5c0-6c42-013d-d609-0800270c66d6" xmi:uuid="0833e680-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186090621_769027_465994" xmi:uuid="2f419d70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityAssignment"/>
      <ownedElement xmi:id="2f2e2c40-915e-013c-7161-0a5172f4a469" xmi:uuid="2f2e2d70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityAssignment"/>
        <text>ActivityAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="0b13f180-6c42-013d-d609-0800270c66d6" xmi:uuid="0b13f210-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="278" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186092666_305692_466088" xmi:uuid="2f83acb0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
      <ownedElement xmi:id="2f44a6a0-915e-013c-7161-0a5172f4a469" xmi:uuid="2f44a7e0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
        <text>ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="0c5598e0-6c42-013d-d609-0800270c66d6" xmi:uuid="0c559980-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="491" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186093847_361233_466160" xmi:uuid="2f9bb090-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityRelationship"/>
      <ownedElement xmi:id="2f86ce90-915e-013c-7161-0a5172f4a469" xmi:uuid="2f86cfc0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityRelationship"/>
        <text>ActivityRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="101aace0-6c42-013d-d609-0800270c66d6" xmi:uuid="101ab0c0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="704" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186095338_658790_466225" xmi:uuid="30548350-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Approval"/>
      <ownedElement xmi:id="2fb36800-915e-013c-7161-0a5172f4a469" xmi:uuid="2fb36940-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Approval"/>
        <text>Approval</text>
      </ownedElement>
      <ownedElement xmi:id="18fae520-6c42-013d-d609-0800270c66d6" xmi:uuid="18fae5b0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="917" y="95" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186097616_659587_466303" xmi:uuid="321b6350-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Condition"/>
      <ownedElement xmi:id="307c87c0-915e-013c-7161-0a5172f4a469" xmi:uuid="307c8910-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Condition"/>
        <text>Condition</text>
      </ownedElement>
      <ownedElement xmi:id="27de8b00-6c42-013d-d609-0800270c66d6" xmi:uuid="27de8b90-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="145" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186099860_739129_466372" xmi:uuid="325fbc00-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
      <ownedElement xmi:id="3224c040-915e-013c-7161-0a5172f4a469" xmi:uuid="3224c190-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
        <text>IndividualPart</text>
      </ownedElement>
      <ownedElement xmi:id="3f935c40-6c42-013d-d609-0800270c66d6" xmi:uuid="3f935ce0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="145" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186102042_753287_466446" xmi:uuid="328f45d0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
      <ownedElement xmi:id="32632ef0-915e-013c-7161-0a5172f4a469" xmi:uuid="32633040-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
        <text>IndividualPartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="427058e0-6c42-013d-d609-0800270c66d6" xmi:uuid="42705940-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="584" y="145" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186103027_612369_466514" xmi:uuid="32a36880-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersionRelationship"/>
      <ownedElement xmi:id="3292b3a0-915e-013c-7161-0a5172f4a469" xmi:uuid="3292b4d0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersionRelationship"/>
        <text>IndividualPartVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="44b0bef0-6c42-013d-d609-0800270c66d6" xmi:uuid="44b0bf90-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="827" y="145" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186105405_131225_466589" xmi:uuid="32d3ea80-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="32a6d820-915e-013c-7161-0a5172f4a469" xmi:uuid="32a6d960-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="4586af50-6c42-013d-d609-0800270c66d6" xmi:uuid="4586aff0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="195" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186106300_860027_466655" xmi:uuid="32e48de0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartViewRelationship"/>
      <ownedElement xmi:id="32d750c0-915e-013c-7161-0a5172f4a469" xmi:uuid="32d75400-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartViewRelationship"/>
        <text>IndividualPartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="4842e940-6c42-013d-d609-0800270c66d6" xmi:uuid="4842e9e0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="308" y="195" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186108254_100115_466722" xmi:uuid="339a02f0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
      <ownedElement xmi:id="32ec7430-915e-013c-7161-0a5172f4a469" xmi:uuid="32ec7580-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
        <text>Organization</text>
      </ownedElement>
      <ownedElement xmi:id="49af8170-6c42-013d-d609-0800270c66d6" xmi:uuid="49af8200-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="551" y="195" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186110881_263725_466797" xmi:uuid="34466e70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
      <ownedElement xmi:id="33ab5520-915e-013c-7161-0a5172f4a469" xmi:uuid="33ab5660-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
        <text>Part</text>
      </ownedElement>
      <ownedElement xmi:id="54de1060-6c42-013d-d609-0800270c66d6" xmi:uuid="54de1100-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="846" y="195" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186113399_355941_466872" xmi:uuid="34b547f0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
      <ownedElement xmi:id="344c5f70-915e-013c-7161-0a5172f4a469" xmi:uuid="344c60a0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
        <text>PartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="5d1e8dd0-6c42-013d-d609-0800270c66d6" xmi:uuid="5d1e8e70-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="245" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186114445_512014_466940" xmi:uuid="34df6cb0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersionRelationship"/>
      <ownedElement xmi:id="34bb3f40-915e-013c-7161-0a5172f4a469" xmi:uuid="34bb4080-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersionRelationship"/>
        <text>PartVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="62ddec00-6c42-013d-d609-0800270c66d6" xmi:uuid="62ddeca0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="367" y="245" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186116901_643691_467017" xmi:uuid="35527a90-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="34e53bb0-915e-013c-7161-0a5172f4a469" xmi:uuid="34e53ce0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="6551d350-6c42-013d-d609-0800270c66d6" xmi:uuid="6551d3e0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="669" y="245" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186117778_725658_467083" xmi:uuid="35741090-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
      <ownedElement xmi:id="35585050-915e-013c-7161-0a5172f4a469" xmi:uuid="35585180-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
        <text>PartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="6b212f80-6c42-013d-d609-0800270c66d6" xmi:uuid="6b213020-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="971" y="245" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186119629_461616_467146" xmi:uuid="360f77c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
      <ownedElement xmi:id="357c4160-915e-013c-7161-0a5172f4a469" xmi:uuid="357c42a0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
        <text>Person</text>
      </ownedElement>
      <ownedElement xmi:id="6d0964a0-6c42-013d-d609-0800270c66d6" xmi:uuid="6d096540-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="295" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186121905_154753_467236" xmi:uuid="36c95be0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
      <ownedElement xmi:id="36175ec0-915e-013c-7161-0a5172f4a469" xmi:uuid="36176000-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
        <text>PersonInOrganization</text>
      </ownedElement>
      <ownedElement xmi:id="7547d580-6c42-013d-d609-0800270c66d6" xmi:uuid="7547d620-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="360" y="295" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186122215_679947_467285" xmi:uuid="37116500-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_OrganizationOrPersonInOrganizationAssignment"/>
      <ownedElement xmi:id="36d15180-915e-013c-7161-0a5172f4a469" xmi:uuid="36d152c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_OrganizationOrPersonInOrganizationAssignment"/>
        <text>PersonOrganizationAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="80151800-6c42-013d-d609-0800270c66d6" xmi:uuid="801518d0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="655" y="295" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186124879_313876_467375" xmi:uuid="3917be80-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinition"/>
      <ownedElement xmi:id="371defe0-915e-013c-7161-0a5172f4a469" xmi:uuid="371df110-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinition"/>
        <text>PropertyDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="86161fe0-6c42-013d-d609-0800270c66d6" xmi:uuid="86162300-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="950" y="295" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186126062_527349_467444" xmi:uuid="39868b70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionRelationship"/>
      <ownedElement xmi:id="392442d0-915e-013c-7161-0a5172f4a469" xmi:uuid="39244400-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionRelationship"/>
        <text>PropertyDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="a1544890-6c42-013d-d609-0800270c66d6" xmi:uuid="a1544930-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="345" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186127562_451393_467509" xmi:uuid="3a53e4b0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValue"/>
      <ownedElement xmi:id="39935430-915e-013c-7161-0a5172f4a469" xmi:uuid="39935560-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValue"/>
        <text>PropertyValue</text>
      </ownedElement>
      <ownedElement xmi:id="a78b2db0-6c42-013d-d609-0800270c66d6" xmi:uuid="a78b2e50-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="345" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186129891_603545_467578" xmi:uuid="3aa48f40-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
      <ownedElement xmi:id="3a5f4fe0-915e-013c-7161-0a5172f4a469" xmi:uuid="3a5f5120-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
        <text>Requirement</text>
      </ownedElement>
      <ownedElement xmi:id="b4212210-6c42-013d-d609-0800270c66d6" xmi:uuid="b42122b0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="617" y="345" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186132159_953696_467652" xmi:uuid="3adc8820-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
      <ownedElement xmi:id="3aa871c0-915e-013c-7161-0a5172f4a469" xmi:uuid="3aa87300-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
        <text>RequirementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="b7918730-6c42-013d-d609-0800270c66d6" xmi:uuid="b79187d0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="920" y="345" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186133175_213022_467720" xmi:uuid="3af42a10-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersionRelationship"/>
      <ownedElement xmi:id="3ae030f0-915e-013c-7161-0a5172f4a469" xmi:uuid="3ae03210-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersionRelationship"/>
        <text>RequirementVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="bacb4320-6c42-013d-d609-0800270c66d6" xmi:uuid="bacb43b0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="395" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186135798_726688_467809" xmi:uuid="3b376810-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
      <ownedElement xmi:id="3af7df20-915e-013c-7161-0a5172f4a469" xmi:uuid="3af7e060-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
        <text>RequirementView</text>
      </ownedElement>
      <ownedElement xmi:id="bc6f1890-6c42-013d-d609-0800270c66d6" xmi:uuid="bc6f1b70-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="368" y="395" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186136749_414360_467875" xmi:uuid="3b4a8990-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementViewRelationship"/>
      <ownedElement xmi:id="3b3b3a60-915e-013c-7161-0a5172f4a469" xmi:uuid="3b3b3b90-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementViewRelationship"/>
        <text>RequirementViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="bfd64b60-6c42-013d-d609-0800270c66d6" xmi:uuid="bfd64bf0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="671" y="395" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186138134_847049_467935" xmi:uuid="3b82a1c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
      <ownedElement xmi:id="3b53a620-915e-013c-7161-0a5172f4a469" xmi:uuid="3b53a770-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
        <text>ResourceItem</text>
      </ownedElement>
      <ownedElement xmi:id="c1adbe80-6c42-013d-d609-0800270c66d6" xmi:uuid="c1adbf00-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="974" y="395" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186138869_790431_467995" xmi:uuid="3ba0d620-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583845680674_838993_58228"/>
      <ownedElement xmi:id="3b866af0-915e-013c-7161-0a5172f4a469" xmi:uuid="3b866d60-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583845680674_838993_58228"/>
        <text>ResourceItemAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="c4175050-6c42-013d-d609-0800270c66d6" xmi:uuid="c41750e0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="445" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186139821_367371_468065" xmi:uuid="3bbbdd70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583844896220_320249_57955"/>
      <ownedElement xmi:id="3ba4ada0-915e-013c-7161-0a5172f4a469" xmi:uuid="3ba4aed0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583844896220_320249_57955"/>
        <text>ResourceItemRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c571bc80-6c42-013d-d609-0800270c66d6" xmi:uuid="c571bd20-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="297" y="445" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186142070_581837_468134" xmi:uuid="3beac4d0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
      <ownedElement xmi:id="3bc2bca0-915e-013c-7161-0a5172f4a469" xmi:uuid="3bc2bdd0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
        <text>Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="c73ad560-6c42-013d-d609-0800270c66d6" xmi:uuid="c73ad600-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="529" y="445" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186143951_413097_468201" xmi:uuid="3c134a60-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
      <ownedElement xmi:id="3bedb990-915e-013c-7161-0a5172f4a469" xmi:uuid="3bedbac0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
        <text>SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="c9863bc0-6c42-013d-d609-0800270c66d6" xmi:uuid="c9863c60-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="801" y="445" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186146215_26845_468286" xmi:uuid="3c3d3950-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
      <ownedElement xmi:id="3c160c30-915e-013c-7161-0a5172f4a469" xmi:uuid="3c160d70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
        <text>SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="cbda66f0-6c42-013d-d609-0800270c66d6" xmi:uuid="cbda6840-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="495" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186147607_624004_468346" xmi:uuid="3d2a2940-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878022123_684236_27287"/>
      <ownedElement xmi:id="3c49f2f0-915e-013c-7161-0a5172f4a469" xmi:uuid="3c49f430-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878022123_684236_27287"/>
        <text>State</text>
      </ownedElement>
      <ownedElement xmi:id="cfc69f70-6c42-013d-d609-0800270c66d6" xmi:uuid="cfc6a010-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="337" y="495" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186148187_282662_468406" xmi:uuid="3dad9b20-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878933294_877087_27407"/>
      <ownedElement xmi:id="3d372150-915e-013c-7161-0a5172f4a469" xmi:uuid="3d372550-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878933294_877087_27407"/>
        <text>StateAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="db817c60-6c42-013d-d609-0800270c66d6" xmi:uuid="db817cf0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="613" y="495" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186148317_864493_468449" xmi:uuid="3de889c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1505210026947_440087_29451"/>
      <ownedElement xmi:id="3dba8d70-915e-013c-7161-0a5172f4a469" xmi:uuid="3dba8ff0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1505210026947_440087_29451"/>
        <text>StateDefinitionConfirmedAssociation</text>
      </ownedElement>
      <ownedElement xmi:id="e1c72760-6c42-013d-d609-0800270c66d6" xmi:uuid="e1c72800-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="889" y="495" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186148453_40641_468492" xmi:uuid="3e256720-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1505210216386_870734_29534"/>
      <ownedElement xmi:id="3df56210-915e-013c-7161-0a5172f4a469" xmi:uuid="3df56340-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1505210216386_870734_29534"/>
        <text>StateDefinitionHypothesisAssociation</text>
      </ownedElement>
      <ownedElement xmi:id="e53262e0-6c42-013d-d609-0800270c66d6" xmi:uuid="e5326420-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="545" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186149847_653411_468551" xmi:uuid="3efe1300-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504882542402_777959_28691"/>
      <ownedElement xmi:id="3e32e4a0-915e-013c-7161-0a5172f4a469" xmi:uuid="3e32e5f0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504882542402_777959_28691"/>
        <text>StateDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="e870c3b0-6c42-013d-d609-0800270c66d6" xmi:uuid="e870c460-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="545" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186150796_272614_468608" xmi:uuid="3fb6f7d0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1506676164331_112338_25714"/>
      <ownedElement xmi:id="3f0a9d10-915e-013c-7161-0a5172f4a469" xmi:uuid="3f0a9e40-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1506676164331_112338_25714"/>
        <text>StateDefinitionStateAssociationRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="f329fdd0-6c42-013d-d609-0800270c66d6" xmi:uuid="f329fe60-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="617" y="545" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186151672_929343_468679" xmi:uuid="403aef00-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504879295028_873077_28061"/>
      <ownedElement xmi:id="3fc3b190-915e-013c-7161-0a5172f4a469" xmi:uuid="3fc3b2d0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504879295028_873077_28061"/>
        <text>StateRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="fcc6f700-6c42-013d-d609-0800270c66d6" xmi:uuid="fcc6f7b0-6c42-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="893" y="545" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186153939_196922_468747" xmi:uuid="405787a0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_392073_63003"/>
      <ownedElement xmi:id="403fdc90-915e-013c-7161-0a5172f4a469" xmi:uuid="403fddd0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_392073_63003"/>
        <text>System</text>
      </ownedElement>
      <ownedElement xmi:id="034b2950-6c43-013d-d609-0800270c66d6" xmi:uuid="034b29e0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="595" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186156087_600652_468820" xmi:uuid="406c2d50-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_348435_63004"/>
      <ownedElement xmi:id="4059c1d0-915e-013c-7161-0a5172f4a469" xmi:uuid="4059c300-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_348435_63004"/>
        <text>SystemVersion</text>
      </ownedElement>
      <ownedElement xmi:id="04a8b5c0-6c43-013d-d609-0800270c66d6" xmi:uuid="04a8b650-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="280" y="595" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186157048_754710_468887" xmi:uuid="40755e70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199045_316367_63007"/>
      <ownedElement xmi:id="406e7cc0-915e-013c-7161-0a5172f4a469" xmi:uuid="406e7e00-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199045_316367_63007"/>
        <text>SystemVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="05dd7e30-6c43-013d-d609-0800270c66d6" xmi:uuid="05dd7ec0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="495" y="595" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186159699_736097_468968" xmi:uuid="408f70c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199044_378163_63005"/>
      <ownedElement xmi:id="4077a470-915e-013c-7161-0a5172f4a469" xmi:uuid="4077a590-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199044_378163_63005"/>
        <text>SystemView</text>
      </ownedElement>
      <ownedElement xmi:id="06728e30-6c43-013d-d609-0800270c66d6" xmi:uuid="06728ec0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="710" y="595" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186160483_37293_469033" xmi:uuid="409779a0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_6b1022a_1639047670600_911347_65028"/>
      <ownedElement xmi:id="4091d260-915e-013c-7161-0a5172f4a469" xmi:uuid="4091d3c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_6b1022a_1639047670600_911347_65028"/>
        <text>SystemViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="08229b90-6c43-013d-d609-0800270c66d6" xmi:uuid="08229c40-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="925" y="595" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186162355_9395_469100" xmi:uuid="40f5c480-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
      <ownedElement xmi:id="40a475c0-915e-013c-7161-0a5172f4a469" xmi:uuid="40a479a0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
        <text>TaskElement</text>
      </ownedElement>
      <ownedElement xmi:id="0c6ca020-6c43-013d-d609-0800270c66d6" xmi:uuid="0c6ca0f0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="645" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186164948_241648_469170" xmi:uuid="415329d0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
      <ownedElement xmi:id="40fa87f0-915e-013c-7161-0a5172f4a469" xmi:uuid="40fa8940-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
        <text>TaskMethod</text>
      </ownedElement>
      <ownedElement xmi:id="1137f400-6c43-013d-d609-0800270c66d6" xmi:uuid="1137f4a0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="323" y="645" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186167513_432567_469261" xmi:uuid="41af8d50-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
      <ownedElement xmi:id="4157deb0-915e-013c-7161-0a5172f4a469" xmi:uuid="4157dfe0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
        <text>TaskMethodVersion</text>
      </ownedElement>
      <ownedElement xmi:id="167d8730-6c43-013d-d609-0800270c66d6" xmi:uuid="167d87c0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="581" y="645" width="238" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1308" height="725"/>
    <name>RiskImpactAssignmentSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703186167549_940744_469302" xmi:uuid="41b0fab0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Risk.xmi#_18_4_1_8e001ed_1498551957523_330847_14120"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186167586_318382_469334" xmi:uuid="41bd0d70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618411191798_449206_62839"/>
      <ownedElement xmi:id="41b71790-915e-013c-7161-0a5172f4a469" xmi:uuid="41b718b0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618411191798_449206_62839"/>
        <text>RiskPerceptionSourceAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="41b9fa70-915e-013c-7161-0a5172f4a469" xmi:uuid="41b9fbb0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="41bb33a0-915e-013c-7161-0a5172f4a469" xmi:uuid="41bb34c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1250" height="755"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186170173_239324_469405" xmi:uuid="41f39d80-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="41c04240-915e-013c-7161-0a5172f4a469" xmi:uuid="41c04380-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="1c1bb700-6c43-013d-d609-0800270c66d6" xmi:uuid="1c1bb7d0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186172286_329965_469499" xmi:uuid="42346e90-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
      <ownedElement xmi:id="41f6b480-915e-013c-7161-0a5172f4a469" xmi:uuid="41f6b5c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
        <text>ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="1e841200-6c43-013d-d609-0800270c66d6" xmi:uuid="1e8412a0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="278" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186173498_979933_469571" xmi:uuid="424bd020-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityRelationship"/>
      <ownedElement xmi:id="423778f0-915e-013c-7161-0a5172f4a469" xmi:uuid="42377a30-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityRelationship"/>
        <text>ActivityRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="218a7080-6c43-013d-d609-0800270c66d6" xmi:uuid="218a7110-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="491" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186175017_379311_469636" xmi:uuid="42f31120-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Approval"/>
      <ownedElement xmi:id="4253e2c0-915e-013c-7161-0a5172f4a469" xmi:uuid="4253e3f0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Approval"/>
        <text>Approval</text>
      </ownedElement>
      <ownedElement xmi:id="23694ce0-6c43-013d-d609-0800270c66d6" xmi:uuid="23694d80-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="704" y="95" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186177429_660837_469714" xmi:uuid="449e5040-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Condition"/>
      <ownedElement xmi:id="42ff6590-915e-013c-7161-0a5172f4a469" xmi:uuid="42ff66c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Condition"/>
        <text>Condition</text>
      </ownedElement>
      <ownedElement xmi:id="2c90b110-6c43-013d-d609-0800270c66d6" xmi:uuid="2c90b1d0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="999" y="95" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186177733_10966_469764" xmi:uuid="44bbb170-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentAssignment"/>
      <ownedElement xmi:id="44a68a80-915e-013c-7161-0a5172f4a469" xmi:uuid="44a68bb0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentAssignment"/>
        <text>DocumentAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="3faac220-6c43-013d-d609-0800270c66d6" xmi:uuid="3faac2c0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="145" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186179458_707689_469829" xmi:uuid="44ed8ff0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_File"/>
      <ownedElement xmi:id="44bedae0-915e-013c-7161-0a5172f4a469" xmi:uuid="44bedc10-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_File"/>
        <text>File</text>
      </ownedElement>
      <ownedElement xmi:id="4111bce0-6c43-013d-d609-0800270c66d6" xmi:uuid="4111bd70-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="356" y="145" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186181822_996020_469898" xmi:uuid="45297db0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
      <ownedElement xmi:id="44f10dd0-915e-013c-7161-0a5172f4a469" xmi:uuid="44f10f10-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
        <text>IndividualPart</text>
      </ownedElement>
      <ownedElement xmi:id="43858160-6c43-013d-d609-0800270c66d6" xmi:uuid="438581f0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="647" y="145" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186184371_409928_469972" xmi:uuid="4558bfb0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
      <ownedElement xmi:id="452d0870-915e-013c-7161-0a5172f4a469" xmi:uuid="452d09b0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
        <text>IndividualPartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="4692fc00-6c43-013d-d609-0800270c66d6" xmi:uuid="4692fcd0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="890" y="145" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186185387_401128_470040" xmi:uuid="456cdd70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersionRelationship"/>
      <ownedElement xmi:id="455c24d0-915e-013c-7161-0a5172f4a469" xmi:uuid="455c2600-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersionRelationship"/>
        <text>IndividualPartVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="48e89440-6c43-013d-d609-0800270c66d6" xmi:uuid="48e894e0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="195" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186187739_290741_470115" xmi:uuid="459e0670-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="45704cd0-915e-013c-7161-0a5172f4a469" xmi:uuid="45704e00-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="4a070440-6c43-013d-d609-0800270c66d6" xmi:uuid="4a070530-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="308" y="195" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186188595_537028_470181" xmi:uuid="45ae6760-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartViewRelationship"/>
      <ownedElement xmi:id="45a16480-915e-013c-7161-0a5172f4a469" xmi:uuid="45a165c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartViewRelationship"/>
        <text>IndividualPartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="4bf16170-6c43-013d-d609-0800270c66d6" xmi:uuid="4bf16250-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="551" y="195" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186190025_874157_470246" xmi:uuid="4655e2d0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582535779826_461173_55822"/>
      <ownedElement xmi:id="45b68450-915e-013c-7161-0a5172f4a469" xmi:uuid="45b68590-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582535779826_461173_55822"/>
        <text>Justification</text>
      </ownedElement>
      <ownedElement xmi:id="4cec3630-6c43-013d-d609-0800270c66d6" xmi:uuid="4cec37a0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="794" y="195" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186190418_655136_470301" xmi:uuid="468629b0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582536702366_85101_56725"/>
      <ownedElement xmi:id="465e2830-915e-013c-7161-0a5172f4a469" xmi:uuid="465e2970-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582536702366_85101_56725"/>
        <text>JustificationAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="54b8a8c0-6c43-013d-d609-0800270c66d6" xmi:uuid="54b8a920-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="245" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186191332_199413_470372" xmi:uuid="46d49070-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582536097332_187147_55922"/>
      <ownedElement xmi:id="468e68d0-915e-013c-7161-0a5172f4a469" xmi:uuid="468e6a10-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582536097332_187147_55922"/>
        <text>JustificationRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="56b043a0-6c43-013d-d609-0800270c66d6" xmi:uuid="56b04430-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="360" y="245" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186191805_191387_470429" xmi:uuid="47112350-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582536297147_346665_56115"/>
      <ownedElement xmi:id="46dc68d0-915e-013c-7161-0a5172f4a469" xmi:uuid="46dc6c90-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582536297147_346665_56115"/>
        <text>JustificationSupportAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="5a1d4d30-6c43-013d-d609-0800270c66d6" xmi:uuid="5a1d4dd0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="655" y="245" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186193942_329699_470499" xmi:uuid="472ab7a0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625040869976_263353_69561"/>
      <ownedElement xmi:id="4715d360-915e-013c-7161-0a5172f4a469" xmi:uuid="4715d630-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625040869976_263353_69561"/>
        <text>Observation</text>
      </ownedElement>
      <ownedElement xmi:id="5d417ea0-6c43-013d-d609-0800270c66d6" xmi:uuid="5d417f40-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="950" y="245" width="218" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186194563_500932_470558" xmi:uuid="47353340-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625041013271_622061_69733"/>
      <ownedElement xmi:id="472cfbd0-915e-013c-7161-0a5172f4a469" xmi:uuid="472cfd10-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625041013271_622061_69733"/>
        <text>ObservationAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="5e6d3cd0-6c43-013d-d609-0800270c66d6" xmi:uuid="5e6d3d70-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="295" width="218" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186196518_362862_470625" xmi:uuid="47e8a080-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
      <ownedElement xmi:id="473d3370-915e-013c-7161-0a5172f4a469" xmi:uuid="473d3740-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
        <text>Organization</text>
      </ownedElement>
      <ownedElement xmi:id="5f62b7e0-6c43-013d-d609-0800270c66d6" xmi:uuid="5f62b870-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="303" y="295" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186199237_730905_470700" xmi:uuid="4888a010-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
      <ownedElement xmi:id="47eeb3a0-915e-013c-7161-0a5172f4a469" xmi:uuid="47eeb4f0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
        <text>Part</text>
      </ownedElement>
      <ownedElement xmi:id="675ceb20-6c43-013d-d609-0800270c66d6" xmi:uuid="675cebc0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="598" y="295" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186201730_584011_470775" xmi:uuid="48f6ba10-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
      <ownedElement xmi:id="488e6750-915e-013c-7161-0a5172f4a469" xmi:uuid="488e6890-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
        <text>PartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="6f1eb4f0-6c43-013d-d609-0800270c66d6" xmi:uuid="6f1eb630-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="900" y="295" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186202751_929114_470843" xmi:uuid="49207b80-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersionRelationship"/>
      <ownedElement xmi:id="48fca220-915e-013c-7161-0a5172f4a469" xmi:uuid="48fca350-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersionRelationship"/>
        <text>PartVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="74c21aa0-6c43-013d-d609-0800270c66d6" xmi:uuid="74c21b50-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="345" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186205118_836540_470920" xmi:uuid="4992bb30-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="492661e0-915e-013c-7161-0a5172f4a469" xmi:uuid="49266320-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="769826f0-6c43-013d-d609-0800270c66d6" xmi:uuid="76982780-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="367" y="345" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186205977_166501_470986" xmi:uuid="49b50160-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
      <ownedElement xmi:id="4998b3c0-915e-013c-7161-0a5172f4a469" xmi:uuid="4998b510-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
        <text>PartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="7bccc770-6c43-013d-d609-0800270c66d6" xmi:uuid="7bccc820-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="669" y="345" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186207821_421687_471049" xmi:uuid="4a512cc0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
      <ownedElement xmi:id="49bce6e0-915e-013c-7161-0a5172f4a469" xmi:uuid="49bce810-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
        <text>Person</text>
      </ownedElement>
      <ownedElement xmi:id="7d8618f0-6c43-013d-d609-0800270c66d6" xmi:uuid="7d861990-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="971" y="345" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186210079_405707_471139" xmi:uuid="4b0f24c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
      <ownedElement xmi:id="4a58d1c0-915e-013c-7161-0a5172f4a469" xmi:uuid="4a58d300-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
        <text>PersonInOrganization</text>
      </ownedElement>
      <ownedElement xmi:id="84f3efc0-6c43-013d-d609-0800270c66d6" xmi:uuid="84f3f050-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="395" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186210376_324669_471188" xmi:uuid="4b55d500-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_OrganizationOrPersonInOrganizationAssignment"/>
      <ownedElement xmi:id="4b16ce70-915e-013c-7161-0a5172f4a469" xmi:uuid="4b16cfc0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_OrganizationOrPersonInOrganizationAssignment"/>
        <text>PersonOrganizationAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="8ce1b6f0-6c43-013d-d609-0800270c66d6" xmi:uuid="8ce1b7c0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="360" y="395" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186212978_402437_471278" xmi:uuid="4d5cbe80-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinition"/>
      <ownedElement xmi:id="4b623210-915e-013c-7161-0a5172f4a469" xmi:uuid="4b623340-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinition"/>
        <text>PropertyDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="90b32500-6c43-013d-d609-0800270c66d6" xmi:uuid="90b325b0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="655" y="395" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186214130_322744_471347" xmi:uuid="4dcc5e70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionRelationship"/>
      <ownedElement xmi:id="4d6957a0-915e-013c-7161-0a5172f4a469" xmi:uuid="4d6958d0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionRelationship"/>
        <text>PropertyDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="ac8d4f70-6c43-013d-d609-0800270c66d6" xmi:uuid="ac8d5030-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="931" y="395" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186215609_735737_471412" xmi:uuid="4e989db0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValue"/>
      <ownedElement xmi:id="4dd97100-915e-013c-7161-0a5172f4a469" xmi:uuid="4dd97240-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValue"/>
        <text>PropertyValue</text>
      </ownedElement>
      <ownedElement xmi:id="b14e7fd0-6c43-013d-d609-0800270c66d6" xmi:uuid="b14e8070-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="445" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186217887_14402_471481" xmi:uuid="4ee01570-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
      <ownedElement xmi:id="4e9c92d0-915e-013c-7161-0a5172f4a469" xmi:uuid="4e9c9400-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
        <text>Requirement</text>
      </ownedElement>
      <ownedElement xmi:id="b9b49d20-6c43-013d-d609-0800270c66d6" xmi:uuid="b9b49e00-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="445" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186220143_74892_471555" xmi:uuid="4f198880-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
      <ownedElement xmi:id="4ee3dda0-915e-013c-7161-0a5172f4a469" xmi:uuid="4ee3dee0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
        <text>RequirementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="de7b6420-6c43-013d-d609-0800270c66d6" xmi:uuid="dea186d0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="644" y="445" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186221134_803676_471623" xmi:uuid="4f314bf0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersionRelationship"/>
      <ownedElement xmi:id="4f1d6580-915e-013c-7161-0a5172f4a469" xmi:uuid="4f1d66b0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersionRelationship"/>
        <text>RequirementVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="ed9dc4b0-6c43-013d-d609-0800270c66d6" xmi:uuid="ed9dc5d0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="947" y="445" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186223717_311062_471712" xmi:uuid="4f755dd0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
      <ownedElement xmi:id="4f34fe60-915e-013c-7161-0a5172f4a469" xmi:uuid="4f350230-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
        <text>RequirementView</text>
      </ownedElement>
      <ownedElement xmi:id="ef15e260-6c43-013d-d609-0800270c66d6" xmi:uuid="ef15e310-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="495" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186224646_421433_471778" xmi:uuid="4f88f9a0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementViewRelationship"/>
      <ownedElement xmi:id="4f7958d0-915e-013c-7161-0a5172f4a469" xmi:uuid="4f795a00-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementViewRelationship"/>
        <text>RequirementViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="f1fbb730-6c43-013d-d609-0800270c66d6" xmi:uuid="f1fbb7d0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="368" y="495" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186226028_392351_471838" xmi:uuid="4fbb2e50-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
      <ownedElement xmi:id="4f8caa10-915e-013c-7161-0a5172f4a469" xmi:uuid="4f8cab40-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
        <text>ResourceItem</text>
      </ownedElement>
      <ownedElement xmi:id="f2c893a0-6c43-013d-d609-0800270c66d6" xmi:uuid="f2c89440-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="671" y="495" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186226757_471982_471898" xmi:uuid="4fd80b20-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583845680674_838993_58228"/>
      <ownedElement xmi:id="4fbed890-915e-013c-7161-0a5172f4a469" xmi:uuid="4fbed9d0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583845680674_838993_58228"/>
        <text>ResourceItemAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="f4eb8730-6c43-013d-d609-0800270c66d6" xmi:uuid="f4eb87c0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="903" y="495" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186227314_806906_471956" xmi:uuid="4ff0cc80-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583844469230_71213_57753"/>
      <ownedElement xmi:id="4fdbc920-915e-013c-7161-0a5172f4a469" xmi:uuid="4fdbca50-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583844469230_71213_57753"/>
        <text>ResourceItemRealization</text>
      </ownedElement>
      <ownedElement xmi:id="f61bbec0-6c43-013d-d609-0800270c66d6" xmi:uuid="f61bc050-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="545" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186228248_947235_472026" xmi:uuid="500b45b0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583844896220_320249_57955"/>
      <ownedElement xmi:id="4ff48c80-915e-013c-7161-0a5172f4a469" xmi:uuid="4ff48db0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583844896220_320249_57955"/>
        <text>ResourceItemRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="f75fd8e0-6c43-013d-d609-0800270c66d6" xmi:uuid="f75fd9d0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="297" y="545" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186230453_278118_472095" xmi:uuid="50348680-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
      <ownedElement xmi:id="500e1c50-915e-013c-7161-0a5172f4a469" xmi:uuid="500e1d80-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
        <text>Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="f8691500-6c43-013d-d609-0800270c66d6" xmi:uuid="f86915a0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="529" y="545" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186232293_322484_472162" xmi:uuid="505c3070-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
      <ownedElement xmi:id="50375ae0-915e-013c-7161-0a5172f4a469" xmi:uuid="50375c10-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
        <text>SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="fad5fe30-6c43-013d-d609-0800270c66d6" xmi:uuid="fad5fee0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="801" y="545" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186234514_800488_472247" xmi:uuid="508622e0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
      <ownedElement xmi:id="505f0bc0-915e-013c-7161-0a5172f4a469" xmi:uuid="505f0cf0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
        <text>SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="fc9ebb00-6c43-013d-d609-0800270c66d6" xmi:uuid="fc9ebba0-6c43-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="595" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186235862_979686_472307" xmi:uuid="51719c80-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878022123_684236_27287"/>
      <ownedElement xmi:id="5092f2e0-915e-013c-7161-0a5172f4a469" xmi:uuid="5092f420-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878022123_684236_27287"/>
        <text>State</text>
      </ownedElement>
      <ownedElement xmi:id="000064b0-6c44-013d-d609-0800270c66d6" xmi:uuid="00006580-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="337" y="595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186236424_389280_472367" xmi:uuid="51efbc00-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878933294_877087_27407"/>
      <ownedElement xmi:id="517e65b0-915e-013c-7161-0a5172f4a469" xmi:uuid="517e66e0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878933294_877087_27407"/>
        <text>StateAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="0a72bc20-6c44-013d-d609-0800270c66d6" xmi:uuid="0a72bcd0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="613" y="595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186237994_37178_472431" xmi:uuid="53085720-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504881104148_230182_28614"/>
      <ownedElement xmi:id="51fc5240-915e-013c-7161-0a5172f4a469" xmi:uuid="51fc5380-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504881104148_230182_28614"/>
        <text>StateDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="106898c0-6c44-013d-d609-0800270c66d6" xmi:uuid="106899a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="889" y="595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186238118_304100_472474" xmi:uuid="534478c0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1505210026947_440087_29451"/>
      <ownedElement xmi:id="5314f260-915e-013c-7161-0a5172f4a469" xmi:uuid="5314f3a0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1505210026947_440087_29451"/>
        <text>StateDefinitionConfirmedAssociation</text>
      </ownedElement>
      <ownedElement xmi:id="1beca480-6c44-013d-d609-0800270c66d6" xmi:uuid="1beca530-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="645" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186238234_566263_472517" xmi:uuid="537f1560-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1505210216386_870734_29534"/>
      <ownedElement xmi:id="535149e0-915e-013c-7161-0a5172f4a469" xmi:uuid="53514b10-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1505210216386_870734_29534"/>
        <text>StateDefinitionHypothesisAssociation</text>
      </ownedElement>
      <ownedElement xmi:id="1e8d02c0-6c44-013d-d609-0800270c66d6" xmi:uuid="1e8d0370-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="645" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186239594_540379_472596" xmi:uuid="5455b780-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504882542402_777959_28691"/>
      <ownedElement xmi:id="538bf990-915e-013c-7161-0a5172f4a469" xmi:uuid="538bfad0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504882542402_777959_28691"/>
        <text>StateDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="21033910-6c44-013d-d609-0800270c66d6" xmi:uuid="210339a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="617" y="645" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186240536_594177_472653" xmi:uuid="55177ae0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1506676164331_112338_25714"/>
      <ownedElement xmi:id="54628230-915e-013c-7161-0a5172f4a469" xmi:uuid="54628360-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1506676164331_112338_25714"/>
        <text>StateDefinitionStateAssociationRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="29de2e40-6c44-013d-d609-0800270c66d6" xmi:uuid="29de2ef0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="893" y="645" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186241411_236846_472724" xmi:uuid="559bb720-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504879295028_873077_28061"/>
      <ownedElement xmi:id="55241790-915e-013c-7161-0a5172f4a469" xmi:uuid="552418b0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504879295028_873077_28061"/>
        <text>StateRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="32d883f0-6c44-013d-d609-0800270c66d6" xmi:uuid="32d884c0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="695" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186243637_262698_472792" xmi:uuid="55b5e930-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_392073_63003"/>
      <ownedElement xmi:id="559e4330-915e-013c-7161-0a5172f4a469" xmi:uuid="559e4480-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_392073_63003"/>
        <text>System</text>
      </ownedElement>
      <ownedElement xmi:id="3796e790-6c44-013d-d609-0800270c66d6" xmi:uuid="3796e9d0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="341" y="695" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186245786_437404_472865" xmi:uuid="55ca6490-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_348435_63004"/>
      <ownedElement xmi:id="55b82920-915e-013c-7161-0a5172f4a469" xmi:uuid="55b82a70-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_348435_63004"/>
        <text>SystemVersion</text>
      </ownedElement>
      <ownedElement xmi:id="38bab3d0-6c44-013d-d609-0800270c66d6" xmi:uuid="38bab4b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="556" y="695" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186246734_647143_472932" xmi:uuid="55d391f0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199045_316367_63007"/>
      <ownedElement xmi:id="55cc9bf0-915e-013c-7161-0a5172f4a469" xmi:uuid="55cc9d30-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199045_316367_63007"/>
        <text>SystemVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="39a381c0-6c44-013d-d609-0800270c66d6" xmi:uuid="39a38230-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="771" y="695" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186249354_587250_473013" xmi:uuid="55f06f20-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199044_378163_63005"/>
      <ownedElement xmi:id="55d5d740-915e-013c-7161-0a5172f4a469" xmi:uuid="55d5db10-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199044_378163_63005"/>
        <text>SystemView</text>
      </ownedElement>
      <ownedElement xmi:id="39fd71c0-6c44-013d-d609-0800270c66d6" xmi:uuid="39fd7410-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="986" y="695" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186250126_202304_473078" xmi:uuid="55f81810-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_6b1022a_1639047670600_911347_65028"/>
      <ownedElement xmi:id="55f2a6b0-915e-013c-7161-0a5172f4a469" xmi:uuid="55f2a7f0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_6b1022a_1639047670600_911347_65028"/>
        <text>SystemViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="3b3671f0-6c44-013d-d609-0800270c66d6" xmi:uuid="3b367290-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="745" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186251972_912843_473145" xmi:uuid="564cefd0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
      <ownedElement xmi:id="55fc8fe0-915e-013c-7161-0a5172f4a469" xmi:uuid="55fc9110-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
        <text>TaskElement</text>
      </ownedElement>
      <ownedElement xmi:id="3bd4a5f0-6c44-013d-d609-0800270c66d6" xmi:uuid="3bd4a6a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="280" y="745" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186254546_509266_473215" xmi:uuid="56ab5480-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
      <ownedElement xmi:id="56515eb0-915e-013c-7161-0a5172f4a469" xmi:uuid="56516000-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
        <text>TaskMethod</text>
      </ownedElement>
      <ownedElement xmi:id="3fbd6550-6c44-013d-d609-0800270c66d6" xmi:uuid="3fbd6620-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="538" y="745" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186257088_615077_473306" xmi:uuid="57097ba0-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
      <ownedElement xmi:id="56b03f30-915e-013c-7161-0a5172f4a469" xmi:uuid="56b04060-915e-013c-7161-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
        <text>TaskMethodVersion</text>
      </ownedElement>
      <ownedElement xmi:id="4411ced0-6c44-013d-d609-0800270c66d6" xmi:uuid="4411cf70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="796" y="745" width="238" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1310" height="825"/>
    <name>RiskPerceptionSourceAssignmentSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_2b2015d_1617887902934_945942_13977" xmi:uuid="7b5bf650-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Risk.xmi#_18_4_1_8e001ed_1498551957523_330847_14120"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617889718652_340801_72676" xmi:uuid="7b9bc810-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
      <ownedElement xmi:id="7b615be0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b615d10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
        <text>Risk</text>
      </ownedElement>
      <ownedElement xmi:id="7b62c580-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b62c620-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="7b944dc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b944ec0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7b945240-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b9452a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="7b95cd80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b95cdf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_440785_62571"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="7b975430-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b9754b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_931716_62572"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="7b98c820-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b98c8a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_231015_62573"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="7b9a4d00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b9a4d80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_259273_62574"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="7b9bc010-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b9bc080-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_549997_62576"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="308" y="42" width="179" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617889987964_125043_72736" xmi:uuid="7bac68d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_807376_62431"/>
      <ownedElement xmi:id="7b9d55d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b9d5640-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_807376_62431"/>
        <text>RiskRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="7b9ea0a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7b9ea110-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="7ba944b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7ba945b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7ba94820-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7ba94870-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="7baabed0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7baabf50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883600_647536_63008"/>
          <text>WR1</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="7baae700-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7baae760-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7baae9a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7baaea00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="7bac6250-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bac62e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_645799_63108"/>
          <text>RelationType</text>
        </ownedElement>
      </ownedElement>
      <bounds x="567" y="42" width="273" height="115"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617890001553_834824_72791" xmi:uuid="7baf9e50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_893704_62433"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890001337_358130_72777" xmi:uuid="7baf7b40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_972460_63109"/>
        <bounds x="494" y="50" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890001337_13513_72779" xmi:uuid="7baf8ac0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_972460_63109"/>
        <bounds x="492" y="70" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890001337_85919_72783" xmi:uuid="7baf99f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_430783_63123"/>
        <bounds x="540" y="70" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1617889987964_125043_72736"/>
      <target xmi:idref="_18_4_1_2b2015d_1617889718652_340801_72676"/>
      <waypoint x="567" y="67"/>
      <waypoint x="487" y="67"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617890004075_857478_72817" xmi:uuid="7bb2e940-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_979924_62434"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890004044_337251_72803" xmi:uuid="7bb2c4b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_895212_63110"/>
        <bounds x="492" y="95" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890004044_6916_72805" xmi:uuid="7bb2d300-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_895212_63110"/>
        <bounds x="492" y="115" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890004044_253992_72809" xmi:uuid="7bb2e4d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_897750_63124"/>
        <bounds x="540" y="115" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1617889987964_125043_72736"/>
      <target xmi:idref="_18_4_1_2b2015d_1617889718652_340801_72676"/>
      <waypoint x="567" y="112"/>
      <waypoint x="487" y="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617890143228_772091_73136" xmi:uuid="7bd8cde0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
      <ownedElement xmi:id="7bb46970-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bb469f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
        <text>RiskVersion</text>
      </ownedElement>
      <ownedElement xmi:id="7bb5b180-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bb5b1f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="7bd2c2a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bd2c390-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7bd2c780-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bd2c7e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="7bd44820-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bd448b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_26730_62761"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="7bd5ce80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bd5cef0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_599264_62762"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="7bd74af0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bd74b90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_494348_62763"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="7bd8c590-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bd8c600-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_495365_62764"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="308" y="224" width="179" height="120"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617890143259_27267_73179" xmi:uuid="7bdc3b00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_22421_62432"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890143228_864708_73124" xmi:uuid="7bdc0d50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_765824_62577"/>
        <bounds x="345" y="208" width="44" height="13"/>
        <text>Versions</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890143228_760064_73126" xmi:uuid="7bdc1c10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_765824_62577"/>
        <bounds x="395" y="208" width="24" height="13"/>
        <text>1..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890143228_925202_73130" xmi:uuid="7bdc2a50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_731652_62767"/>
        <bounds x="339" y="183" width="50" height="13"/>
        <text>VersionOf</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890143228_825354_73132" xmi:uuid="7bdc3710-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_731652_62767"/>
        <bounds x="395" y="183" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1617889718652_340801_72676"/>
      <target xmi:idref="_18_4_1_2b2015d_1617890143228_772091_73136"/>
      <waypoint x="392" y="175"/>
      <waypoint x="392" y="224"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617890342638_710068_73234" xmi:uuid="7c071280-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_912952_62430"/>
      <ownedElement xmi:id="7bddcb70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bddcbf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_912952_62430"/>
        <text>RiskView</text>
      </ownedElement>
      <ownedElement xmi:id="7bdf6f50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bdf7010-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="7bfd3d60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bfd3e70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7bfd40a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bfd4100-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="7bfed7f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7bfed860-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_517663_62946"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="7c0060d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c006160-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_946808_62947"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="7c01d7e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c01d840-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_781449_62948"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="7c0373b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c037430-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_458668_62953"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="7c039d00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c039d60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7c039f80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c039fd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="7c051770-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c0517f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_918618_62949"/>
          <text>AdditionalContexts</text>
        </ownedElement>
        <ownedElement xmi:id="7c070500-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c070600-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_109694_62952"/>
          <text>InitialContext</text>
        </ownedElement>
      </ownedElement>
      <bounds x="308" y="399" width="194" height="167"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617890342666_966313_73277" xmi:uuid="7c0ba800-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881520_650631_62638"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890342629_204289_73222" xmi:uuid="7c0b7b40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_523324_62765"/>
        <bounds x="359" y="383" width="30" height="13"/>
        <text>Views</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890342630_675687_73224" xmi:uuid="7c0b89a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_523324_62765"/>
        <bounds x="395" y="383" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890342631_309569_73228" xmi:uuid="7c0b9600-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_552517_62954"/>
        <bounds x="353" y="352" width="36" height="13"/>
        <text>ViewOf</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617890342632_320761_73230" xmi:uuid="7c0ba330-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_552517_62954"/>
        <bounds x="395" y="352" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1617890143228_772091_73136"/>
      <target xmi:idref="_18_4_1_2b2015d_1617890342638_710068_73234"/>
      <waypoint x="392" y="344"/>
      <waypoint x="392" y="399"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617896577119_902892_73342" xmi:uuid="7c17f580-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617896577119_372619_73340"/>
      <ownedElement xmi:id="7c0d3c50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c0d3cd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617896577119_372619_73340"/>
        <text>RiskPerception</text>
      </ownedElement>
      <ownedElement xmi:id="7c0e7f70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c0e7fd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="7c167100-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c1671e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7c167420-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c167550-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="7c17ee90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c17ef00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617897731985_428010_73443"/>
          <text>RiskLevel</text>
        </ownedElement>
      </ownedElement>
      <bounds x="273" y="609" width="175" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617896606192_882662_73389" xmi:uuid="7c1c2960-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617896607437_933472_73390"/>
      <source xmi:idref="_18_4_1_2b2015d_1617896577119_902892_73342"/>
      <target xmi:idref="_18_4_1_2b2015d_1617890342638_710068_73234"/>
      <waypoint x="351" y="609"/>
      <waypoint x="351" y="585"/>
      <waypoint x="405" y="585"/>
      <waypoint x="405" y="566"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617896633035_635616_73397" xmi:uuid="7c236c10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617896633035_973986_73395"/>
      <ownedElement xmi:id="7c1dad90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c1dae10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617896633035_973986_73395"/>
        <text>RiskConsequence</text>
      </ownedElement>
      <ownedElement xmi:id="7c1f5180-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c1f5260-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="490" y="609" width="108" height="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617896650239_905210_73439" xmi:uuid="7c26a7a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617896651082_501855_73440"/>
      <source xmi:idref="_18_4_1_2b2015d_1617896633035_635616_73397"/>
      <target xmi:idref="_18_4_1_2b2015d_1617890342638_710068_73234"/>
      <waypoint x="539" y="609"/>
      <waypoint x="539" y="585"/>
      <waypoint x="405" y="585"/>
      <waypoint x="405" y="566"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617898760214_694142_73460" xmi:uuid="7c30b2d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898760198_472667_73458"/>
      <ownedElement xmi:id="7c2879e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c287aa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898760198_472667_73458"/>
        <text>RelatedConsequence</text>
      </ownedElement>
      <ownedElement xmi:id="7c2b23a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c2b2450-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="392" y="728" width="125" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617898798017_892195_73504" xmi:uuid="7c33f620-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898799855_273695_73505"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617898800080_462251_73517" xmi:uuid="7c33ce90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898799855_611878_73506"/>
        <bounds x="391" y="693" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617898814665_169283_73535" xmi:uuid="7c33dcf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898799855_611878_73506"/>
        <bounds x="441" y="693" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617898945774_736970_73605" xmi:uuid="7c33f0e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898799855_504741_73507"/>
        <bounds x="441" y="713" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1617898760214_694142_73460"/>
      <target xmi:idref="_18_4_1_2b2015d_1617896577119_902892_73342"/>
      <waypoint x="438" y="728"/>
      <waypoint x="438" y="690"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617898834168_428478_73542" xmi:uuid="7c377ba0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898835843_538779_73543"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617898835943_170943_73553" xmi:uuid="7c373ee0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898835843_57455_73544"/>
        <bounds x="460" y="689" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617898916742_297716_73590" xmi:uuid="7c375bc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898835843_57455_73544"/>
        <bounds x="504" y="689" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617898955549_907068_73611" xmi:uuid="7c377790-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898835843_883746_73545"/>
        <bounds x="504" y="713" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1617898760214_694142_73460"/>
      <target xmi:idref="_18_4_1_2b2015d_1617896633035_635616_73397"/>
      <waypoint x="501" y="728"/>
      <waypoint x="501" y="686"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985345008_304089_70877" xmi:uuid="7c3fefa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064068_761734_69815"/>
      <ownedElement xmi:id="7c392850-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c3928d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064068_761734_69815"/>
        <text>CausalConsequence</text>
      </ownedElement>
      <ownedElement xmi:id="7c3a6ba0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c3a6c10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="d836abd0-9d81-013a-5569-0d73bd894d70" xmi:uuid="d836ad00-9d81-013a-5569-0d73bd894d70" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d8378d00-9d81-013a-5569-0d73bd894d70" xmi:uuid="d8378f30-9d81-013a-5569-0d73bd894d70" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="d839bd80-9d81-013a-5569-0d73bd894d70" xmi:uuid="d839be90-9d81-013a-5569-0d73bd894d70" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_6b1022a_1649845195362_162964_68184"/>
          <text>WR1</text>
        </ownedElement>
      </ownedElement>
      <bounds x="686" y="609" width="149" height="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985349373_403316_70932" xmi:uuid="7c44dc20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985150713_863506_70737"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985522221_665068_71067" xmi:uuid="7c448b70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985150713_981175_70738"/>
        <bounds x="663" y="679" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985349358_241120_70922" xmi:uuid="7c44a3c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_831757_69848"/>
        <bounds x="606" y="657" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985349358_969584_70924" xmi:uuid="7c44d410-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_831757_69848"/>
        <bounds x="613" y="679" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1617985345008_304089_70877"/>
      <target xmi:idref="_18_4_1_2b2015d_1617896633035_635616_73397"/>
      <waypoint x="686" y="676"/>
      <waypoint x="598" y="676"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985351029_523257_70962" xmi:uuid="7c48bc50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985351007_230071_70947"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985504351_633766_71051" xmi:uuid="7c4859a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985351014_232963_70948"/>
        <bounds x="663" y="644" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985351014_897594_70952" xmi:uuid="7c48a930-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_691301_69849"/>
        <bounds x="605" y="621" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985351014_677416_70954" xmi:uuid="7c48b730-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_691301_69849"/>
        <bounds x="601" y="640" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1617985345008_304089_70877"/>
      <target xmi:idref="_18_4_1_2b2015d_1617896633035_635616_73397"/>
      <waypoint x="686" y="637"/>
      <waypoint x="598" y="637"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985932212_860709_72197" xmi:uuid="7c5222c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594452_714034_71103"/>
      <ownedElement xmi:id="7c4a47b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c4a4820-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594452_714034_71103"/>
        <text>RiskPerceptionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="7c4b9860-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c4b98f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="d676b840-96ea-013a-b7b8-77b52bc67f62" xmi:uuid="d676b970-96ea-013a-b7b8-77b52bc67f62" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d677a980-96ea-013a-b7b8-77b52bc67f62" xmi:uuid="d677aa80-96ea-013a-b7b8-77b52bc67f62" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="d679fef0-96ea-013a-b7b8-77b52bc67f62" xmi:uuid="d67a0020-96ea-013a-b7b8-77b52bc67f62" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_65b021e_1648719775826_479380_68007"/>
          <text>WR1</text>
        </ownedElement>
      </ownedElement>
      <bounds x="28" y="609" width="159" height="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985935248_971203_72255" xmi:uuid="7c555c60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985935233_584058_72240"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985996513_622958_72323" xmi:uuid="7c553af0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985935233_361584_72241"/>
        <bounds x="190" y="672" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985935248_767239_72245" xmi:uuid="7c5548a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_206695_71136"/>
        <bounds x="226" y="653" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985935248_39500_72247" xmi:uuid="7c555710-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_206695_71136"/>
        <bounds x="256" y="672" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1617985932212_860709_72197"/>
      <target xmi:idref="_18_4_1_2b2015d_1617896577119_902892_73342"/>
      <waypoint x="187" y="669"/>
      <waypoint x="273" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985936952_594489_72286" xmi:uuid="7c58ba30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985936921_983653_72271"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617986009794_909021_72335" xmi:uuid="7c589870-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985936921_493504_72272"/>
        <bounds x="190" y="633" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985936936_993586_72276" xmi:uuid="7c58a6f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_266050_71137"/>
        <bounds x="229" y="615" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985936936_61513_72278" xmi:uuid="7c58b470-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_266050_71137"/>
        <bounds x="259" y="634" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1617985932212_860709_72197"/>
      <target xmi:idref="_18_4_1_2b2015d_1617896577119_902892_73342"/>
      <waypoint x="187" y="630"/>
      <waypoint x="273" y="630"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618411141068_520267_62795" xmi:uuid="7c6afe60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618411141068_701578_62793"/>
      <ownedElement xmi:id="7c5a8450-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c5a84e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618411141068_701578_62793"/>
        <text>RiskPerceptionSourceAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="7c5bf160-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c5bf1c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="98" y="728" width="219" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618411191798_468194_62841" xmi:uuid="7c6f3de0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618411191798_449206_62839"/>
      <ownedElement xmi:id="7c6c7dd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c6c7e50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618411191798_449206_62839"/>
        <text>RiskPerceptionSourceAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="7c6dc2b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c6dc320-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="7c6dc700-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c6dc750-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="84" y="798" width="232" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413586666_850283_68667" xmi:uuid="7c7272f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413586635_208616_68652"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636646988482_477753_64230" xmi:uuid="50200e80-339b-013a-17e3-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413586635_372120_68653"/>
        <bounds x="220" y="766" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618413586650_405209_68657" xmi:uuid="7c7260b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_309295_64588"/>
        <bounds x="111" y="782" width="103" height="13"/>
        <text>AssignedRiskSource</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618413586650_577990_68659" xmi:uuid="7c726dc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_309295_64588"/>
        <bounds x="220" y="782" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1618411141068_520267_62795"/>
      <target xmi:idref="_18_4_1_2b2015d_1618411191798_468194_62841"/>
      <waypoint x="217" y="763"/>
      <waypoint x="217" y="798"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413588555_875063_68693" xmi:uuid="7c75bae0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413588540_16809_68678"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636646888764_841653_64218" xmi:uuid="50453ac0-339b-013a-17e3-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413588540_256367_68679"/>
        <bounds x="283" y="712" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618413588540_496185_68683" xmi:uuid="7c759800-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412874567_526165_66168"/>
        <bounds x="218" y="693" width="59" height="13"/>
        <text>AssignedTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618413588540_126252_68685" xmi:uuid="7c75b6e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412874567_526165_66168"/>
        <bounds x="283" y="693" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1618411141068_520267_62795"/>
      <target xmi:idref="_18_4_1_2b2015d_1617896577119_902892_73342"/>
      <waypoint x="280" y="728"/>
      <waypoint x="280" y="690"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414116748_153052_70222" xmi:uuid="7c87e4c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083897_902466_68707"/>
      <ownedElement xmi:id="7c774cf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c774d60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083897_902466_68707"/>
        <text>RiskImpactAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="7c789120-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c789190-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="567" y="728" width="136" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414535170_62554_70413" xmi:uuid="7c8c30c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414214099_999308_70263"/>
      <ownedElement xmi:id="7c896990-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c896a20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414214099_999308_70263"/>
        <text>RiskImpactAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="7c8aafa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c8ab010-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="7c8ab310-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c8ab360-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="539" y="798" width="168" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414535170_865087_70458" xmi:uuid="7c8ffff0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414535133_839363_70402"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636646975726_139879_64224" xmi:uuid="516a2770-339b-013a-17e3-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414535133_223602_70403"/>
        <bounds x="654" y="766" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618414535170_599230_70407" xmi:uuid="7c8fddc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_4701_68749"/>
        <bounds x="547" y="782" width="101" height="13"/>
        <text>AssignedRiskImpact</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618414535170_97887_70409" xmi:uuid="7c8ff6b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_4701_68749"/>
        <bounds x="654" y="782" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1618414116748_153052_70222"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414535170_62554_70413"/>
      <waypoint x="651" y="763"/>
      <waypoint x="651" y="798"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414536622_735156_70484" xmi:uuid="7c938250-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414536607_555804_70469"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636646875466_146854_64212" xmi:uuid="51979110-339b-013a-17e3-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414536607_354561_70470"/>
        <bounds x="591" y="712" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618414536607_115893_70474" xmi:uuid="7c936f60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_908005_68755"/>
        <bounds x="526" y="688" width="59" height="13"/>
        <text>AssignedTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618414536607_755392_70476" xmi:uuid="7c937c60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_908005_68755"/>
        <bounds x="591" y="701" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1618414116748_153052_70222"/>
      <target xmi:idref="_18_4_1_2b2015d_1617896633035_635616_73397"/>
      <waypoint x="588" y="728"/>
      <waypoint x="588" y="686"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414876147_432072_70500" xmi:uuid="7ca17bc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414876147_13677_70498"/>
      <ownedElement xmi:id="7c9506d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c950740-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414876147_13677_70498"/>
        <text>RiskEvent</text>
      </ownedElement>
      <ownedElement xmi:id="7c9666f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7c966770-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="abf28850-3ed4-013c-a159-4b23c1d46efd" xmi:uuid="abf28970-3ed4-013c-a159-4b23c1d46efd" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="abf3b5a0-3ed4-013c-a159-4b23c1d46efd" xmi:uuid="abf3b6c0-3ed4-013c-a159-4b23c1d46efd" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="abf63fe0-3ed4-013c-a159-4b23c1d46efd" xmi:uuid="abf64110-3ed4-013c-a159-4b23c1d46efd" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_29c0149_1623839320122_134678_69647"/>
          <text>Probability</text>
        </ownedElement>
      </ownedElement>
      <bounds x="336" y="798" width="171" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618562853683_867111_62781" xmi:uuid="7ca51380-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618562853319_242988_62767"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636647394690_410785_64236" xmi:uuid="52118460-339b-013a-17e3-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618562853321_688746_62768"/>
        <bounds x="360" y="782" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618562853392_517640_62773" xmi:uuid="7ca4ef20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415057756_509501_70717"/>
        <bounds x="295" y="693" width="59" height="13"/>
        <text>AssignedTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618562853393_142544_62775" xmi:uuid="7ca509d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415057756_509501_70717"/>
        <bounds x="360" y="693" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1618414876147_432072_70500"/>
      <target xmi:idref="_18_4_1_2b2015d_1617896577119_902892_73342"/>
      <waypoint x="357" y="798"/>
      <waypoint x="357" y="690"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="855" height="882"/>
    <name>Risk</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617888883553_906058_62862" xmi:uuid="0871a060-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_912952_62430"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_397792_64973" xmi:uuid="8cbdbb40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_740241_62955"/>
      <ownedElement xmi:id="088486b0-6af0-013a-da2b-3770a1b6a6fd" xmi:uuid="08848970-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_740241_62955"/>
        <text>risk_view:Product_view_definition</text>
      </ownedElement>
      <ownedElement xmi:id="08881800-6af0-013a-da2b-3770a1b6a6fd" xmi:uuid="08881940-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_740241_62955"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="56" width="226" height="819"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_381409_65408" xmi:uuid="8cbdc700-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_722761_62939"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_836496_65034"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="784"/>
      <waypoint x="261" y="784"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_339773_65409" xmi:uuid="8cbdd260-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_682137_62940"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_791531_65036"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="806"/>
      <waypoint x="261" y="806"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_147852_65410" xmi:uuid="8cbddda0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_102172_62919"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_889935_64986"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="216"/>
      <waypoint x="261" y="216"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_67642_65411" xmi:uuid="8cbde8c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_218398_62923"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_365752_65028"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="723"/>
      <waypoint x="261" y="723"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_655895_65412" xmi:uuid="8cbdf420-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_544678_62932"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_685293_65004"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="410"/>
      <waypoint x="261" y="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_298957_65413" xmi:uuid="8cbdfee0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_23914_62937"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_920634_65030"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="746"/>
      <waypoint x="261" y="746"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_467869_65414" xmi:uuid="8cbe0a40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_840394_62915"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_998155_65022"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="656"/>
      <waypoint x="261" y="656"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_35688_65416" xmi:uuid="8cbe1fb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_284867_62938"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_878361_65032"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="763"/>
      <waypoint x="261" y="763"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_517327_65417" xmi:uuid="8cbe2ba0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_545540_62935"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_433825_65014"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="569"/>
      <waypoint x="261" y="569"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_215434_65418" xmi:uuid="8cbe3670-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_390941_62912"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_631438_64978"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="129"/>
      <waypoint x="261" y="129"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_497223_65419" xmi:uuid="8cbe4150-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_152246_62916"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_239538_65024"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="678"/>
      <waypoint x="261" y="678"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_519887_65420" xmi:uuid="8cbe4c70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_711591_62930"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_4764_65000"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="368"/>
      <waypoint x="261" y="368"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_587055_65421" xmi:uuid="8cbe5670-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_237955_62934"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_513923_65016"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="592"/>
      <waypoint x="261" y="592"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_799205_65422" xmi:uuid="8cbe60f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_308252_62928"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_119279_64998"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="347"/>
      <waypoint x="261" y="347"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_24551_65423" xmi:uuid="8cbe6c20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_974224_62936"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_524722_65010"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="524"/>
      <waypoint x="261" y="524"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_285015_65424" xmi:uuid="8cbe77a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_632825_62933"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_147750_65006"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="434"/>
      <waypoint x="261" y="434"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_929060_65425" xmi:uuid="8cbe82a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_194009_62926"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_429506_65020"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="637"/>
      <waypoint x="261" y="637"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_214847_65426" xmi:uuid="8cbe8d90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_104154_62921"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_972753_64994"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="325"/>
      <waypoint x="261" y="325"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_17911_65427" xmi:uuid="8cbe9820-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_748466_62917"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_176876_64988"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="238"/>
      <waypoint x="261" y="238"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_268569_65428" xmi:uuid="8cbea2f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_589007_62925"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_605956_65018"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="614"/>
      <waypoint x="261" y="614"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_129838_65429" xmi:uuid="8cbeae40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_99602_62914"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_270633_64982"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="171"/>
      <waypoint x="261" y="171"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_383023_65430" xmi:uuid="8cbef280-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_33632_62918"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_40436_64984"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="193"/>
      <waypoint x="261" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_995005_65431" xmi:uuid="8cbefe00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_351877_62910"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_379935_64974"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="84"/>
      <waypoint x="261" y="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_893056_65432" xmi:uuid="8cbf0880-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_417176_62929"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_309309_64990"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="261"/>
      <waypoint x="261" y="261"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_700811_65433" xmi:uuid="8cbf1290-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_287655_62913"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_670684_64980"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="148"/>
      <waypoint x="261" y="148"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_494728_65434" xmi:uuid="8cbf1de0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_837451_62911"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_901535_64976"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="107"/>
      <waypoint x="261" y="107"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_605233_65435" xmi:uuid="8cbf27d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_673561_62920"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_223156_65012"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="547"/>
      <waypoint x="261" y="547"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_998439_65436" xmi:uuid="8cbf32c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_913048_62931"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_151310_65002"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="389"/>
      <waypoint x="261" y="389"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_217979_65437" xmi:uuid="8cbf3cc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_735039_62922"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_481279_64992"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="830"/>
      <waypoint x="261" y="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_885455_65438" xmi:uuid="8cbf46b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_651186_62924"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_781576_65026"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="701"/>
      <waypoint x="261" y="701"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_492568_65439" xmi:uuid="8cbf5000-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_448027_62941"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_422557_65038"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="279"/>
      <waypoint x="261" y="279"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_90908_65440" xmi:uuid="8cbf5920-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_949543_62942"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_949484_65040"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="301"/>
      <waypoint x="261" y="301"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_503787_65441" xmi:uuid="8cbf6240-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_166756_62943"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_865899_65008"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="476"/>
      <waypoint x="261" y="476"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1663083846634_869391_72160" xmi:uuid="48527900-8498-013b-7376-29e527a7a3ad" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083847635_304189_72161"/>
      <source xmi:idref="_18_4_1_2b2015d_1663083826184_999237_72139"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="501"/>
      <waypoint x="261" y="501"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1663083861695_809192_72174" xmi:uuid="485280d0-8498-013b-7376-29e527a7a3ad" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083862911_258675_72175"/>
      <source xmi:idref="_18_4_1_2b2015d_1663083826094_803090_72129"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_397792_64973"/>
      <waypoint x="622" y="455"/>
      <waypoint x="261" y="455"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_379935_64974" xmi:uuid="088c42c0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="622" y="73" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_901535_64976" xmi:uuid="088d8c80-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="622" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_631438_64978" xmi:uuid="088f3270-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="622" y="117" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_670684_64980" xmi:uuid="0890ba50-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551433642363_802478_36217"/>
      <bounds x="622" y="139" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_270633_64982" xmi:uuid="0892a3c0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="622" y="161" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_40436_64984" xmi:uuid="08945ab0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="622" y="183" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_889935_64986" xmi:uuid="0895cca0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="622" y="205" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_176876_64988" xmi:uuid="08974d00-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="622" y="227" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_309309_64990" xmi:uuid="08990210-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="622" y="249" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_481279_64992" xmi:uuid="089a8ae0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="622" y="822" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_972753_64994" xmi:uuid="089c4760-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="622" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_119279_64998" xmi:uuid="089f5010-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578048114027_922117_59250"/>
      <bounds x="622" y="338" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_4764_65000" xmi:uuid="08a0e3c0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="622" y="360" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_151310_65002" xmi:uuid="08a233c0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="622" y="382" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_685293_65004" xmi:uuid="08a3a000-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="622" y="404" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_147750_65006" xmi:uuid="08a54660-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="622" y="426" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_865899_65008" xmi:uuid="08a68bf0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="622" y="470" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_524722_65010" xmi:uuid="08a806f0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="622" y="514" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_223156_65012" xmi:uuid="08a98100-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="622" y="536" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_433825_65014" xmi:uuid="08aaf5e0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="622" y="558" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_513923_65016" xmi:uuid="08ac52e0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="622" y="580" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_605956_65018" xmi:uuid="08adb360-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="622" y="602" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_429506_65020" xmi:uuid="08af20f0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510325553618_189011_33055"/>
      <bounds x="622" y="624" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_998155_65022" xmi:uuid="08b13530-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973058873_539759_54381"/>
      <bounds x="622" y="646" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_239538_65024" xmi:uuid="08b2a5b0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973091565_761824_54391"/>
      <bounds x="622" y="668" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_781576_65026" xmi:uuid="08b41e50-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973215473_235782_54417"/>
      <bounds x="622" y="690" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_365752_65028" xmi:uuid="08b58490-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973151145_247037_54405"/>
      <bounds x="622" y="712" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_920634_65030" xmi:uuid="08b6d230-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551689215050_535893_40191"/>
      <bounds x="622" y="734" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_878361_65032" xmi:uuid="08b839f0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="622" y="756" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_836496_65034" xmi:uuid="08b9d770-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="622" y="778" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_791531_65036" xmi:uuid="08bb7b10-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="622" y="800" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_422557_65038" xmi:uuid="08bcf3d0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="622" y="271" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_949484_65040" xmi:uuid="08be6e40-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="622" y="293" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1663083826094_803090_72129" xmi:uuid="d7abeb20-18de-013b-25a6-316dbea2a0c2" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="622" y="448" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1663083826184_999237_72139" xmi:uuid="d7ace3b0-18de-013b-25a6-316dbea2a0c2" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="622" y="492" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="625" height="890"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446393132_573085_337689" xmi:uuid="0f1e0920-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083897_902466_68707"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393181_89362_337722" xmi:uuid="0fc31430-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_170959_68750"/>
      <ownedElement xmi:id="0fa05830-6c46-013d-d609-0800270c66d6" xmi:uuid="0fa05940-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_170959_68750"/>
        <text>impactAssignment:Risk_impact_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="0fc2f940-6c46-013d-d609-0800270c66d6" xmi:uuid="0fc2fa20-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_170959_68750"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="273" height="330"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393311_715255_337891" xmi:uuid="0fc31f00-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1677145235646_481246_68483"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393311_479676_337894"/>
      <waypoint x="318" y="242"/>
      <waypoint x="685" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393199_357648_337756" xmi:uuid="0fd89a00-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="685" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393213_851051_337771" xmi:uuid="0fe3ee50-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="685" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393221_972832_337786" xmi:uuid="10007220-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="685" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393234_100293_337801" xmi:uuid="100dd7b0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="685" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393249_266686_337816" xmi:uuid="101fe8c0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="685" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393262_332315_337831" xmi:uuid="10295e60-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="685" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393275_229113_337846" xmi:uuid="103913c0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="685" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393289_555083_337861" xmi:uuid="1058ec70-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="685" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393301_300715_337876" xmi:uuid="1061fe40-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="685" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393311_479676_337894" xmi:uuid="106e6d40-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="685" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393327_706342_337909" xmi:uuid="107e4e70-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="685" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393342_366858_337924" xmi:uuid="1099d9b0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="685" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393358_570150_337939" xmi:uuid="10b6d8e0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="685" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393373_345225_337954" xmi:uuid="10c283f0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="685" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_627846_414437" xmi:uuid="10c2a180-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082654143_226595_70390"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393199_357648_337756"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="62"/>
      <waypoint x="318" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_555804_414440" xmi:uuid="10c2ad60-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082662112_342878_70418"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393213_851051_337771"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="82"/>
      <waypoint x="318" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_678939_414443" xmi:uuid="10c2bc40-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082891799_489629_70567"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393221_972832_337786"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="102"/>
      <waypoint x="318" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_411377_414446" xmi:uuid="10c2c800-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082910693_235946_70601"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393234_100293_337801"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="122"/>
      <waypoint x="318" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_164311_414449" xmi:uuid="10c2d320-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082651040_199085_70376"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393249_266686_337816"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="142"/>
      <waypoint x="318" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_153621_414452" xmi:uuid="10c2df10-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082914641_962471_70615"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393262_332315_337831"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="162"/>
      <waypoint x="318" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_913905_414455" xmi:uuid="10c2e800-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082665267_857372_70432"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393275_229113_337846"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="182"/>
      <waypoint x="318" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_534898_414458" xmi:uuid="10c2efb0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082658874_715596_70404"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393289_555083_337861"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="202"/>
      <waypoint x="318" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_870516_414461" xmi:uuid="10c2f7b0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082918389_621326_70629"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393301_300715_337876"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="222"/>
      <waypoint x="318" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_832728_414464" xmi:uuid="10c2ff80-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082668654_40860_70446"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393327_706342_337909"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="262"/>
      <waypoint x="318" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_148920_414467" xmi:uuid="10c309c0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082672006_564775_70460"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393342_366858_337924"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="282"/>
      <waypoint x="318" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_306560_414470" xmi:uuid="10c31500-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082647856_293750_70362"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393358_570150_337939"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="302"/>
      <waypoint x="318" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511388_333696_414473" xmi:uuid="10c31f30-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082925698_742820_70657"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393373_345225_337954"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393181_89362_337722"/>
      <waypoint x="685" y="322"/>
      <waypoint x="318" y="322"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="688" height="400"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446398564_612003_341242" xmi:uuid="1d7aa890-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414876147_13677_70498"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398591_825915_341274" xmi:uuid="1e475430-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415099089_958755_70727"/>
      <ownedElement xmi:id="1e2b97e0-6c46-013d-d609-0800270c66d6" xmi:uuid="1e2b9de0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415099089_958755_70727"/>
        <text>activityMethodAsgn:Risk_event</text>
      </ownedElement>
      <ownedElement xmi:id="1e474160-6c46-013d-d609-0800270c66d6" xmi:uuid="1e474250-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415099089_958755_70727"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="204" height="690"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398609_503735_341308" xmi:uuid="1e5503a0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="671" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398621_309803_341323" xmi:uuid="1e610f50-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="671" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398636_686484_341338" xmi:uuid="1e6ec6f0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="671" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398646_490098_341353" xmi:uuid="1e6fff50-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="671" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398657_292518_341368" xmi:uuid="1e8081b0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="671" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398676_621312_341383" xmi:uuid="1e9828c0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="671" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398686_194455_341398" xmi:uuid="1ea5f420-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="671" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398695_40111_341413" xmi:uuid="1eb3cd40-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1529866794283_1220_39337"/>
      <bounds x="671" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398707_336289_341428" xmi:uuid="1ec2ad20-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="671" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398717_972777_341443" xmi:uuid="1ed35c70-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="671" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398736_67813_341458" xmi:uuid="1ed4de80-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="671" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398749_614471_341473" xmi:uuid="1eeaed70-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="671" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398765_660388_341488" xmi:uuid="1eecf4c0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="671" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398781_221368_341503" xmi:uuid="1f09e590-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="671" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398794_272790_341518" xmi:uuid="1f146f40-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="671" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398803_269177_341533" xmi:uuid="1f235630-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="671" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398812_82560_341548" xmi:uuid="1f2485c0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="671" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398824_376955_341563" xmi:uuid="1f25bb70-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="671" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398834_831089_341578" xmi:uuid="1f26d880-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="671" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398854_286514_341593" xmi:uuid="1f57ee40-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="671" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398871_787327_341608" xmi:uuid="1f6ae6f0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="671" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398884_479976_341623" xmi:uuid="1f7d4040-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="671" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398898_800051_341638" xmi:uuid="1f915950-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="671" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398914_437925_341653" xmi:uuid="1fa45d60-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="671" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398924_163435_341668" xmi:uuid="1fa5be80-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="671" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398940_436710_341683" xmi:uuid="1fc3a060-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="671" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398951_993732_341698" xmi:uuid="1fd428f0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="671" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398962_676393_341713" xmi:uuid="1fe4c0b0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="671" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398974_531203_341728" xmi:uuid="1ff39f50-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="671" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398983_362854_341743" xmi:uuid="1ff4d850-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="671" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398994_613205_341758" xmi:uuid="201867f0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="671" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446399063_731794_341774" xmi:uuid="2019adc0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="671" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_828746_415043" xmi:uuid="2019c0f0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546261_750320_314244"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398609_503735_341308"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="62"/>
      <waypoint x="249" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_396577_415046" xmi:uuid="2019cd50-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546347_580833_314260"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398621_309803_341323"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="82"/>
      <waypoint x="249" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_412573_415049" xmi:uuid="2019d690-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546422_305517_314276"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398636_686484_341338"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="102"/>
      <waypoint x="249" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_14446_415052" xmi:uuid="2019df10-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546501_279776_314292"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398646_490098_341353"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="122"/>
      <waypoint x="249" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_439250_415055" xmi:uuid="2019e7a0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546577_304693_314308"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398657_292518_341368"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="142"/>
      <waypoint x="249" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_660348_415058" xmi:uuid="2019f070-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546652_253281_314324"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398676_621312_341383"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="162"/>
      <waypoint x="249" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_775880_415061" xmi:uuid="2019f920-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546734_263140_314340"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398686_194455_341398"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="182"/>
      <waypoint x="249" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_983921_415064" xmi:uuid="201a0250-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546808_995524_314356"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398695_40111_341413"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="202"/>
      <waypoint x="249" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_267964_415067" xmi:uuid="201a0b60-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546881_460804_314372"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398707_336289_341428"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="222"/>
      <waypoint x="249" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_160344_415070" xmi:uuid="201a13c0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546959_910353_314388"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398717_972777_341443"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="242"/>
      <waypoint x="249" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_215018_415073" xmi:uuid="201a1c40-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547032_294820_314404"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398736_67813_341458"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="262"/>
      <waypoint x="249" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_485083_415076" xmi:uuid="201a2450-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547110_788827_314420"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398749_614471_341473"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="282"/>
      <waypoint x="249" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_891424_415079" xmi:uuid="201a2cb0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547187_882056_314436"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398765_660388_341488"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="302"/>
      <waypoint x="249" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_872674_415082" xmi:uuid="201a3500-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547265_536755_314452"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398781_221368_341503"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="322"/>
      <waypoint x="249" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_506458_415085" xmi:uuid="201a3ef0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547348_911645_314468"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398794_272790_341518"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="342"/>
      <waypoint x="249" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_722257_415088" xmi:uuid="201a46a0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547427_152234_314484"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398803_269177_341533"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="362"/>
      <waypoint x="249" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_822866_415091" xmi:uuid="201a51f0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547499_747534_314500"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398812_82560_341548"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="382"/>
      <waypoint x="249" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_404710_415094" xmi:uuid="201a5b90-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547574_953191_314516"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398824_376955_341563"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="402"/>
      <waypoint x="249" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_116484_415097" xmi:uuid="201a63b0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547651_781015_314532"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398834_831089_341578"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="422"/>
      <waypoint x="249" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_329858_415100" xmi:uuid="201a6c00-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547726_54918_314548"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398854_286514_341593"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="442"/>
      <waypoint x="249" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_616527_415103" xmi:uuid="201a8050-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547810_33265_314564"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398871_787327_341608"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="462"/>
      <waypoint x="249" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_672383_415106" xmi:uuid="201a9640-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547892_97615_314580"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398884_479976_341623"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="482"/>
      <waypoint x="249" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_483293_415109" xmi:uuid="201aa640-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601547967_7889_314596"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398898_800051_341638"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="502"/>
      <waypoint x="249" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_110817_415112" xmi:uuid="201ab800-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601548043_223925_314612"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398914_437925_341653"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="522"/>
      <waypoint x="249" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_582158_415115" xmi:uuid="201ac2e0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601548124_793456_314628"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398924_163435_341668"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="542"/>
      <waypoint x="249" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_589194_415118" xmi:uuid="201acb20-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601548200_306478_314644"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398940_436710_341683"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="562"/>
      <waypoint x="249" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_234593_415121" xmi:uuid="201ad320-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601548284_416039_314660"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398951_993732_341698"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="582"/>
      <waypoint x="249" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_103362_415124" xmi:uuid="201adb10-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601548366_425425_314676"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398962_676393_341713"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="602"/>
      <waypoint x="249" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_62360_415127" xmi:uuid="201ae550-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601548442_441754_314692"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398974_531203_341728"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="622"/>
      <waypoint x="249" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_786213_415130" xmi:uuid="201aef30-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601548518_595981_314708"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398983_362854_341743"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="642"/>
      <waypoint x="249" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_393437_415133" xmi:uuid="201af790-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601548605_829299_314724"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398994_613205_341758"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="662"/>
      <waypoint x="249" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511484_294735_415136" xmi:uuid="201b0170-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1727446398995_667768_341770"/>
      <source xmi:idref="_18_4_1_65b021e_1727446399063_731794_341774"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398591_825915_341274"/>
      <waypoint x="671" y="682"/>
      <waypoint x="249" y="682"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="674" height="760"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446393379_177201_337966" xmi:uuid="45a6d780-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_807376_62431"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393406_369452_337998" xmi:uuid="46a0cdd0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_66649_63111"/>
      <ownedElement xmi:id="46710040-6c45-013d-d609-0800270c66d6" xmi:uuid="46710160-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_66649_63111"/>
        <text>risk_relationship:Risk_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="46a0b170-6c45-013d-d609-0800270c66d6" xmi:uuid="46a0b330-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_66649_63111"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="220" height="350"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393422_555196_338032" xmi:uuid="46bc3110-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="580" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393430_173678_338047" xmi:uuid="46cd54c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_6b1022a_1570727524445_1920_44551"/>
      <bounds x="580" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393445_596767_338062" xmi:uuid="46e0e650-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="580" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393455_33479_338077" xmi:uuid="46f57da0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="580" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393468_53300_338092" xmi:uuid="470aea40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="580" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393483_65502_338107" xmi:uuid="471d6170-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="580" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393499_544617_338122" xmi:uuid="472e0550-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="580" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393512_840266_338137" xmi:uuid="47300da0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="580" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393526_348991_338152" xmi:uuid="475ead20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="580" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393538_777320_338167" xmi:uuid="4776eef0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="580" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393555_188897_338182" xmi:uuid="47887010-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="580" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393573_647972_338197" xmi:uuid="47a30e20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="580" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393589_355132_338212" xmi:uuid="47b52f50-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="580" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393603_806645_338227" xmi:uuid="47c8efe0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="580" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393613_228153_338242" xmi:uuid="47d98d30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="580" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511393_517358_414476" xmi:uuid="47d9a090-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_792925_63104"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393422_555196_338032"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="62"/>
      <waypoint x="265" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511393_313827_414479" xmi:uuid="47d9a8c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083741734_771513_71676"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393430_173678_338047"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="82"/>
      <waypoint x="265" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511393_667184_414482" xmi:uuid="47d9afb0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_459669_63095"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393445_596767_338062"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="102"/>
      <waypoint x="265" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511393_848208_414485" xmi:uuid="47d9b760-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_48151_63096"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393455_33479_338077"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="122"/>
      <waypoint x="265" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511393_538736_414488" xmi:uuid="47d9bf20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_384652_63106"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393468_53300_338092"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="142"/>
      <waypoint x="265" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511393_229562_414491" xmi:uuid="47d9c780-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_574189_63097"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393483_65502_338107"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="162"/>
      <waypoint x="265" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511393_471608_414494" xmi:uuid="47d9cec0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_476166_63098"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393499_544617_338122"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="182"/>
      <waypoint x="265" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511394_924494_414497" xmi:uuid="47d9d680-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_591778_63099"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393512_840266_338137"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="202"/>
      <waypoint x="265" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511394_685870_414500" xmi:uuid="47d9dc50-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_752436_63105"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393526_348991_338152"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="222"/>
      <waypoint x="265" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511394_833386_414503" xmi:uuid="47d9e380-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_538247_63100"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393538_777320_338167"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="242"/>
      <waypoint x="265" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511394_721792_414506" xmi:uuid="47d9ebe0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083618210_355841_71622"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393555_188897_338182"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="262"/>
      <waypoint x="265" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511394_864007_414509" xmi:uuid="47da55e0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083621810_768427_71636"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393573_647972_338197"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="282"/>
      <waypoint x="265" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511394_608959_414512" xmi:uuid="47da64f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_546683_63101"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393589_355132_338212"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="302"/>
      <waypoint x="265" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511394_234610_414515" xmi:uuid="47da79c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_47214_63102"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393603_806645_338227"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="322"/>
      <waypoint x="265" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511394_894732_414518" xmi:uuid="47da8800-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083745232_177636_71690"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393613_228153_338242"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393406_369452_337998"/>
      <waypoint x="580" y="342"/>
      <waypoint x="265" y="342"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="583" height="420"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446393620_918978_338254" xmi:uuid="52fc70c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617896577119_372619_73340"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393648_594187_338286" xmi:uuid="5415f880-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982435654_168936_68050"/>
      <ownedElement xmi:id="53d41c20-6c45-013d-d609-0800270c66d6" xmi:uuid="53d41d00-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982435654_168936_68050"/>
        <text>risk_view:Risk_perception</text>
      </ownedElement>
      <ownedElement xmi:id="5415e790-6c45-013d-d609-0800270c66d6" xmi:uuid="5415e850-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982435654_168936_68050"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="175" height="850"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393665_755472_338320" xmi:uuid="542820b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="867" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393676_147219_338335" xmi:uuid="54467a30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="867" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393691_681170_338350" xmi:uuid="54589170-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="867" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393699_172359_338365" xmi:uuid="5459c4b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="867" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393707_998976_338380" xmi:uuid="546ca660-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551689215050_535893_40191"/>
      <bounds x="867" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393716_837957_338395" xmi:uuid="548e0570-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551433642363_802478_36217"/>
      <bounds x="867" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393725_168854_338410" xmi:uuid="548f2e90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="867" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393738_187148_338425" xmi:uuid="54b2b770-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="867" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393749_394050_338440" xmi:uuid="54b3e700-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="867" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393757_214971_338455" xmi:uuid="54dd8240-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973058873_539759_54381"/>
      <bounds x="867" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393764_853176_338470" xmi:uuid="54ed4390-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973091565_761824_54391"/>
      <bounds x="867" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393772_800801_338485" xmi:uuid="54fd1ba0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564143467_618360_192628"/>
      <bounds x="867" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393787_604992_338500" xmi:uuid="550dd690-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="867" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393801_420513_338515" xmi:uuid="552791a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="867" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393815_686855_338530" xmi:uuid="55373d20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="867" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393829_99232_338545" xmi:uuid="5538a380-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="867" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393838_551382_338560" xmi:uuid="555f4e70-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="867" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393847_140727_338575" xmi:uuid="5574f860-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="867" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393860_959252_338590" xmi:uuid="55936f20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="867" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393868_657514_338605" xmi:uuid="55955370-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973151145_247037_54405"/>
      <bounds x="867" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393877_188193_338620" xmi:uuid="55b23bb0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973215473_235782_54417"/>
      <bounds x="867" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393886_612623_338635" xmi:uuid="55c4afb0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="867" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393895_394878_338650" xmi:uuid="55c6f030-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510325553618_189011_33055"/>
      <bounds x="867" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393911_927845_338665" xmi:uuid="55c818b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="867" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393928_940358_338680" xmi:uuid="55fbe6b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="867" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393936_593867_338695" xmi:uuid="55fd2480-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564135540_870467_190875"/>
      <bounds x="867" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393944_770438_338710" xmi:uuid="561a1d50-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317852_610905_217937"/>
      <bounds x="867" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393952_686942_338725" xmi:uuid="561b9270-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564141926_556119_192266"/>
      <bounds x="867" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393960_636403_338740" xmi:uuid="561cdfc0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564137313_718057_191236"/>
      <bounds x="867" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393968_728103_338755" xmi:uuid="56543f20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578048114027_922117_59250"/>
      <bounds x="867" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393983_202113_338770" xmi:uuid="5663ea90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="867" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446393998_60032_338785" xmi:uuid="5688f5f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="867" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394008_360892_338800" xmi:uuid="569d27f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="867" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394018_430889_338815" xmi:uuid="569eaa10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="867" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394029_376856_338830" xmi:uuid="56bf1230-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="867" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394039_2891_338845" xmi:uuid="56d4a9a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="867" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394049_564412_338860" xmi:uuid="56f441f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="867" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394058_707485_338875" xmi:uuid="570598a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="867" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394070_967292_338890" xmi:uuid="5725e1f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="867" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394079_581374_338905" xmi:uuid="57270d10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="867" y="835" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511401_313172_414521" xmi:uuid="57272060-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601537965_797641_310900"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393665_755472_338320"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="62"/>
      <waypoint x="220" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511401_871532_414524" xmi:uuid="57272840-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538049_152382_310916"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393676_147219_338335"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="82"/>
      <waypoint x="220" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511401_715517_414527" xmi:uuid="57272e90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538124_6831_310932"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393691_681170_338350"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="102"/>
      <waypoint x="220" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511401_249642_414530" xmi:uuid="57273700-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538206_929875_310948"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393699_172359_338365"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="122"/>
      <waypoint x="220" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511401_792446_414533" xmi:uuid="57274080-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538279_334729_310964"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393707_998976_338380"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="142"/>
      <waypoint x="220" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_366379_414536" xmi:uuid="57274a20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538352_226283_310980"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393716_837957_338395"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="162"/>
      <waypoint x="220" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_859586_414539" xmi:uuid="57275260-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538422_14854_310996"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393725_168854_338410"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="182"/>
      <waypoint x="220" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_527246_414542" xmi:uuid="57275990-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538495_896344_311012"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393738_187148_338425"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="202"/>
      <waypoint x="220" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_498284_414545" xmi:uuid="57276250-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538573_298800_311028"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393749_394050_338440"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="222"/>
      <waypoint x="220" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_698020_414548" xmi:uuid="572769a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538647_895388_311044"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393757_214971_338455"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="242"/>
      <waypoint x="220" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_775255_414551" xmi:uuid="573b6970-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538719_683768_311060"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393764_853176_338470"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="262"/>
      <waypoint x="220" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_951029_414554" xmi:uuid="573bb0e0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538791_631874_311076"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393772_800801_338485"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="282"/>
      <waypoint x="220" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_196361_414557" xmi:uuid="573bbcc0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538864_390107_311092"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393787_604992_338500"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="302"/>
      <waypoint x="220" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_490923_414560" xmi:uuid="573bce70-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601538942_569927_311108"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393801_420513_338515"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="322"/>
      <waypoint x="220" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_888320_414563" xmi:uuid="573bd950-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539023_88855_311124"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393815_686855_338530"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="342"/>
      <waypoint x="220" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_906183_414566" xmi:uuid="573be5b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539102_81880_311140"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393829_99232_338545"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="362"/>
      <waypoint x="220" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_763621_414569" xmi:uuid="573bf0b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539180_879274_311156"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393838_551382_338560"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="382"/>
      <waypoint x="220" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_407843_414572" xmi:uuid="573bff80-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539254_550812_311172"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393847_140727_338575"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="402"/>
      <waypoint x="220" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_999736_414575" xmi:uuid="573c3160-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539326_516395_311188"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393860_959252_338590"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="422"/>
      <waypoint x="220" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_106494_414578" xmi:uuid="573c3f90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539402_723087_311204"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393868_657514_338605"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="442"/>
      <waypoint x="220" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_894743_414581" xmi:uuid="573cc780-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539531_888551_311220"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393877_188193_338620"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="462"/>
      <waypoint x="220" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_956647_414584" xmi:uuid="573ccf80-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539604_310894_311236"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393886_612623_338635"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="482"/>
      <waypoint x="220" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_247935_414587" xmi:uuid="5756acd0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539676_744919_311252"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393895_394878_338650"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="502"/>
      <waypoint x="220" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_462770_414590" xmi:uuid="5756bd30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539748_844783_311268"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393911_927845_338665"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="522"/>
      <waypoint x="220" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_665404_414593" xmi:uuid="5756ccc0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539832_673060_311284"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393928_940358_338680"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="542"/>
      <waypoint x="220" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_926630_414596" xmi:uuid="5756d6c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539913_776209_311300"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393936_593867_338695"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="562"/>
      <waypoint x="220" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_275937_414599" xmi:uuid="5756e560-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601539987_326454_311316"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393944_770438_338710"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="582"/>
      <waypoint x="220" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_238482_414602" xmi:uuid="5756efe0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540059_830065_311332"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393952_686942_338725"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="602"/>
      <waypoint x="220" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_40160_414605" xmi:uuid="5756f9d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540133_902046_311348"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393960_636403_338740"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="622"/>
      <waypoint x="220" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_526832_414608" xmi:uuid="57570650-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540206_607228_311364"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393968_728103_338755"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="642"/>
      <waypoint x="220" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_283378_414611" xmi:uuid="57571070-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540279_867777_311380"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393983_202113_338770"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="662"/>
      <waypoint x="220" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_419090_414614" xmi:uuid="57571ae0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540358_437092_311396"/>
      <source xmi:idref="_18_4_1_65b021e_1727446393998_60032_338785"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="682"/>
      <waypoint x="220" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_27101_414617" xmi:uuid="57575990-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540436_940129_311412"/>
      <source xmi:idref="_18_4_1_65b021e_1727446394008_360892_338800"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="702"/>
      <waypoint x="220" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_999004_414620" xmi:uuid="57576aa0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540538_480111_311428"/>
      <source xmi:idref="_18_4_1_65b021e_1727446394018_430889_338815"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="722"/>
      <waypoint x="220" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_742263_414623" xmi:uuid="57577a10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540662_311661_311444"/>
      <source xmi:idref="_18_4_1_65b021e_1727446394029_376856_338830"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="742"/>
      <waypoint x="220" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_531107_414626" xmi:uuid="575786d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540752_80334_311460"/>
      <source xmi:idref="_18_4_1_65b021e_1727446394039_2891_338845"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="762"/>
      <waypoint x="220" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_14371_414629" xmi:uuid="57579740-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540829_128551_311476"/>
      <source xmi:idref="_18_4_1_65b021e_1727446394049_564412_338860"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="782"/>
      <waypoint x="220" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_646856_414632" xmi:uuid="5757bc80-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540905_367950_311492"/>
      <source xmi:idref="_18_4_1_65b021e_1727446394058_707485_338875"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="802"/>
      <waypoint x="220" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_372579_414635" xmi:uuid="5757c920-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601540983_218132_311508"/>
      <source xmi:idref="_18_4_1_65b021e_1727446394070_967292_338890"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="822"/>
      <waypoint x="220" y="822"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511402_425290_414638" xmi:uuid="5757d200-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601541064_111821_311524"/>
      <source xmi:idref="_18_4_1_65b021e_1727446394079_581374_338905"/>
      <target xmi:idref="_18_4_1_65b021e_1727446393648_594187_338286"/>
      <waypoint x="867" y="842"/>
      <waypoint x="220" y="842"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="870" height="920"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446398099_818352_340579" xmi:uuid="587d92a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617896633035_973986_73395"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398125_811379_340611" xmi:uuid="598ecb50-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980088303_53626_65223"/>
      <ownedElement xmi:id="59515b20-6c45-013d-d609-0800270c66d6" xmi:uuid="59515c90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980088303_53626_65223"/>
        <text>risk_view:Risk_consequence</text>
      </ownedElement>
      <ownedElement xmi:id="598eb7c0-6c45-013d-d609-0800270c66d6" xmi:uuid="598eb900-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980088303_53626_65223"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="189" height="850"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398141_672777_340645" xmi:uuid="59901120-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="902" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398151_144737_340660" xmi:uuid="59afcf90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="902" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398166_937629_340675" xmi:uuid="59bec030-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="902" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398177_69643_340690" xmi:uuid="59ddc150-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="902" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398185_968714_340705" xmi:uuid="5a0fb7b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551689215050_535893_40191"/>
      <bounds x="902" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398194_60316_340720" xmi:uuid="5a205390-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551433642363_802478_36217"/>
      <bounds x="902" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398203_78086_340735" xmi:uuid="5a347a90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="902" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398217_582399_340750" xmi:uuid="5a487fa0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="902" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398227_863735_340765" xmi:uuid="5a6e78d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="902" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398235_855736_340780" xmi:uuid="5a86eb00-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973058873_539759_54381"/>
      <bounds x="902" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398243_554491_340795" xmi:uuid="5a884c10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973091565_761824_54391"/>
      <bounds x="902" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398250_303663_340810" xmi:uuid="5ab5dd10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564143467_618360_192628"/>
      <bounds x="902" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398264_944983_340825" xmi:uuid="5ac3a740-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="902" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398279_909238_340840" xmi:uuid="5ade7cc0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="902" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398292_475367_340855" xmi:uuid="5adfab40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="902" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398306_921275_340870" xmi:uuid="5ae10340-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="902" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398316_500750_340885" xmi:uuid="5b06cde0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="902" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398324_665720_340900" xmi:uuid="5b1aaf80-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="902" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398336_636664_340915" xmi:uuid="5b332800-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="902" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398344_323729_340930" xmi:uuid="5b46d140-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973151145_247037_54405"/>
      <bounds x="902" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398351_780184_340945" xmi:uuid="5b56a280-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973215473_235782_54417"/>
      <bounds x="902" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398361_261970_340960" xmi:uuid="5b6bd700-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="902" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398369_933625_340975" xmi:uuid="5b7e5830-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510325553618_189011_33055"/>
      <bounds x="902" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398387_215281_340990" xmi:uuid="5b96b060-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="902" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398404_913539_341005" xmi:uuid="5baaaef0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="902" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398413_495738_341020" xmi:uuid="5bca29b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564135540_870467_190875"/>
      <bounds x="902" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398422_948025_341035" xmi:uuid="5bcb9210-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317852_610905_217937"/>
      <bounds x="902" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398429_651349_341050" xmi:uuid="5bf2f8b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564141926_556119_192266"/>
      <bounds x="902" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398438_758227_341065" xmi:uuid="5c1f4ad0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564137313_718057_191236"/>
      <bounds x="902" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398446_134584_341080" xmi:uuid="5c210d70-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578048114027_922117_59250"/>
      <bounds x="902" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398460_115182_341095" xmi:uuid="5c476ad0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="902" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398475_625415_341110" xmi:uuid="5c5516c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="902" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398485_862632_341125" xmi:uuid="5c6ec500-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="902" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398495_541902_341140" xmi:uuid="5c7d16a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="902" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398506_723736_341155" xmi:uuid="5c925970-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="902" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398516_866933_341170" xmi:uuid="5c939f60-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="902" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398526_760190_341185" xmi:uuid="5cb977a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="902" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398537_922681_341200" xmi:uuid="5cbabe80-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="902" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398548_443634_341215" xmi:uuid="5cce6050-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="902" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398558_881840_341230" xmi:uuid="5cf9c2e0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="902" y="835" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_182296_414923" xmi:uuid="5cf9d8f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543056_564233_313541"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398141_672777_340645"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="62"/>
      <waypoint x="234" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_272697_414926" xmi:uuid="5cf9e540-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543141_535026_313557"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398151_144737_340660"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="82"/>
      <waypoint x="234" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_641363_414929" xmi:uuid="5cf9eec0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543215_301543_313573"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398166_937629_340675"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="102"/>
      <waypoint x="234" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_633711_414932" xmi:uuid="5cf9fa60-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543295_105934_313589"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398177_69643_340690"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="122"/>
      <waypoint x="234" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_926801_414935" xmi:uuid="5cfa0260-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543370_136301_313605"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398185_968714_340705"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="142"/>
      <waypoint x="234" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_481935_414938" xmi:uuid="5cfa0be0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543440_689319_313621"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398194_60316_340720"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="162"/>
      <waypoint x="234" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_476792_414941" xmi:uuid="5cfa14c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543514_805525_313637"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398203_78086_340735"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="182"/>
      <waypoint x="234" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_39479_414944" xmi:uuid="5cfa1ef0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543588_877257_313653"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398217_582399_340750"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="202"/>
      <waypoint x="234" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_818011_414947" xmi:uuid="5cfa2660-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543668_729252_313669"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398227_863735_340765"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="222"/>
      <waypoint x="234" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_143106_414950" xmi:uuid="5cfa2cc0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543745_671896_313685"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398235_855736_340780"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="242"/>
      <waypoint x="234" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_867233_414953" xmi:uuid="5cfa3c30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543822_27138_313701"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398243_554491_340795"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="262"/>
      <waypoint x="234" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_231181_414956" xmi:uuid="5cfa47f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543895_627051_313717"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398250_303663_340810"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="282"/>
      <waypoint x="234" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_237409_414959" xmi:uuid="5cfa5330-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601543973_785058_313733"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398264_944983_340825"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="302"/>
      <waypoint x="234" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_381463_414962" xmi:uuid="5cfa5f60-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544055_239808_313749"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398279_909238_340840"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="322"/>
      <waypoint x="234" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_925992_414965" xmi:uuid="5cfa6b10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544143_571712_313765"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398292_475367_340855"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="342"/>
      <waypoint x="234" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_319092_414968" xmi:uuid="5cfa7480-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544220_592130_313781"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398306_921275_340870"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="362"/>
      <waypoint x="234" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_2121_414971" xmi:uuid="5cfa8100-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544298_205223_313797"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398316_500750_340885"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="382"/>
      <waypoint x="234" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_712974_414974" xmi:uuid="5cfa8c40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544375_242452_313813"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398324_665720_340900"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="402"/>
      <waypoint x="234" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_625492_414977" xmi:uuid="5cfa9870-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544447_769739_313829"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398336_636664_340915"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="422"/>
      <waypoint x="234" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_510150_414980" xmi:uuid="5cfaa310-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544525_367284_313845"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398344_323729_340930"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="442"/>
      <waypoint x="234" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_592480_414983" xmi:uuid="5cfaafb0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544597_882035_313861"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398351_780184_340945"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="462"/>
      <waypoint x="234" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_839278_414986" xmi:uuid="5cfabc40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544672_152818_313877"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398361_261970_340960"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="482"/>
      <waypoint x="234" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_392476_414989" xmi:uuid="5cfac3d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544748_208117_313893"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398369_933625_340975"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="502"/>
      <waypoint x="234" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_697590_414992" xmi:uuid="5cfb0620-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544821_436521_313909"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398387_215281_340990"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="522"/>
      <waypoint x="234" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_607292_414995" xmi:uuid="5cfb1240-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544904_229817_313925"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398404_913539_341005"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="542"/>
      <waypoint x="234" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_256908_414998" xmi:uuid="5cfb2360-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601544986_598745_313941"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398413_495738_341020"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="562"/>
      <waypoint x="234" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_145865_415001" xmi:uuid="5cfb2e40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545060_261403_313957"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398422_948025_341035"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="582"/>
      <waypoint x="234" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_953949_415004" xmi:uuid="5cfb3ec0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545133_704321_313973"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398429_651349_341050"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="602"/>
      <waypoint x="234" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_881830_415007" xmi:uuid="5cfb43f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545209_716174_313989"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398438_758227_341065"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="622"/>
      <waypoint x="234" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_323090_415010" xmi:uuid="5cfb4a80-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545281_894167_314005"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398446_134584_341080"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="642"/>
      <waypoint x="234" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_468637_415013" xmi:uuid="5cfb50a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545428_623065_314021"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398460_115182_341095"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="662"/>
      <waypoint x="234" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_775310_415016" xmi:uuid="5cfb5540-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545519_26886_314037"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398475_625415_341110"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="682"/>
      <waypoint x="234" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_520976_415019" xmi:uuid="5cfb5ae0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545601_393246_314053"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398485_862632_341125"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="702"/>
      <waypoint x="234" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_698756_415022" xmi:uuid="5cfb5f20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545684_570366_314069"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398495_541902_341140"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="722"/>
      <waypoint x="234" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_656886_415025" xmi:uuid="5cfb6500-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545763_836727_314085"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398506_723736_341155"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="742"/>
      <waypoint x="234" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_562355_415028" xmi:uuid="5cfb69c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545842_743387_314101"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398516_866933_341170"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="762"/>
      <waypoint x="234" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_636050_415031" xmi:uuid="5cfb6ed0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545918_428956_314117"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398526_760190_341185"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="782"/>
      <waypoint x="234" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_336436_415034" xmi:uuid="5cfb73b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601545989_907218_314133"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398537_922681_341200"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="802"/>
      <waypoint x="234" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_659669_415037" xmi:uuid="5cfb7ab0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546065_827422_314149"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398548_443634_341215"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="822"/>
      <waypoint x="234" y="822"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511465_930233_415040" xmi:uuid="5cfb7f60-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_65b021e_1696601546143_207219_314165"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398558_881840_341230"/>
      <target xmi:idref="_18_4_1_65b021e_1727446398125_811379_340611"/>
      <waypoint x="902" y="842"/>
      <waypoint x="234" y="842"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="905" height="920"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617888880650_165708_62445" xmi:uuid="7ca56070-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_191688_64563" xmi:uuid="7ce7e540-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_259273_62574"/>
      <ownedElement xmi:id="7cd70500-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7cd70600-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_259273_62574"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="7cd91240-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7cd91340-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_259273_62574"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_200959_64564" xmi:uuid="7ce7dd40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="497eb7f0-6c44-013d-d609-0800270c66d6" xmi:uuid="497eb8a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="262" y="65" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="244" y="74" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="70" width="217" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_82309_64566" xmi:uuid="7cfec390-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_231015_62573"/>
      <ownedElement xmi:id="7cfcee20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7cfcef20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_231015_62573"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="7cfeb210-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7cfeb2c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_231015_62573"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="196" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_299767_64567" xmi:uuid="7d0cfe50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_440785_62571"/>
      <ownedElement xmi:id="7d0b5d30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d0b5e10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_440785_62571"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="7d0cee40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d0ceeb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_440785_62571"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="546" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_496020_64568" xmi:uuid="7d1b6490-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_931716_62572"/>
      <ownedElement xmi:id="7d19ba10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d19bae0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_931716_62572"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="7d1b5380-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d1b5400-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_931716_62572"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="735" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_998622_64570" xmi:uuid="7d3c2220-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_549997_62576"/>
      <ownedElement xmi:id="7d2e6360-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d2e6450-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_549997_62576"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="7d300270-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d3002e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_549997_62576"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_849751_64571" xmi:uuid="7d3c1b10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="4d444c20-6c44-013d-d609-0800270c66d6" xmi:uuid="4d444cc0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="185" y="1018" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="167" y="1027" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="1022" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_434582_64573" xmi:uuid="7d4232a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_765824_62577"/>
      <ownedElement xmi:id="7d3f1c40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d3f1cf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_765824_62577"/>
        <text>Versions:RiskVersion</text>
      </ownedElement>
      <ownedElement xmi:id="7d409cd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d409dd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_765824_62577"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_673650_64574" xmi:uuid="7d422c10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_105139_62782"/>
        <ownedElement xmi:id="4db8b580-6c44-013d-d609-0800270c66d6" xmi:uuid="4db8b790-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_105139_62782"/>
          <bounds x="227" y="1094" width="144" height="13"/>
          <text>riskVersion : Risk_version [1]</text>
        </ownedElement>
        <bounds x="209" y="1103" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="1099" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_826761_65250" xmi:uuid="7da395a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881488_175543_62499"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_603309_64658"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_161743_64577"/>
      <waypoint x="1225" y="119"/>
      <waypoint x="1225" y="95"/>
      <waypoint x="1045" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_79386_64576" xmi:uuid="7da5b020-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_491795_62579"/>
      <ownedElement xmi:id="7d681390-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d6815a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_491795_62579"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="7d6ace80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d6acf30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_491795_62579"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="5161d7a0-6c44-013d-d609-0800270c66d6" xmi:uuid="5161d900-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="51630d80-6c44-013d-d609-0800270c66d6" xmi:uuid="51630e60-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_161743_64577" xmi:uuid="7da38560-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="7d8d6150-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7d8d6250-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="7da371c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7da372e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="84" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="847" y="56" width="212" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_858581_64578" xmi:uuid="7df886f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881508_961968_62580"/>
      <ownedElement xmi:id="7db8c6b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7db8c7c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881508_961968_62580"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_662297_64579" xmi:uuid="7dcc8020-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="57469980-6c44-013d-d609-0800270c66d6" xmi:uuid="574b1040-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="254" y="189" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="308" y="198" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_279025_64581" xmi:uuid="7dda7810-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="58058a70-6c44-013d-d609-0800270c66d6" xmi:uuid="58058ba0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="555" y="148" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="537" y="157" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_198718_64583" xmi:uuid="7deb1f00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="58ae3130-6c44-013d-d609-0800270c66d6" xmi:uuid="58ae31f0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="555" y="192" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="537" y="201" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_637300_64585" xmi:uuid="7df87f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="593886f0-6c44-013d-d609-0800270c66d6" xmi:uuid="593887f0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="555" y="353" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="537" y="362" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="308" y="133" width="244" height="259"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_403521_64587" xmi:uuid="7e1a8ac0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881508_295515_62581"/>
      <ownedElement xmi:id="7e06efc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e06f0b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881508_295515_62581"/>
        <text>lang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="7e08e6b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e08e7d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881508_295515_62581"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_735703_64588" xmi:uuid="7e1a81f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="5a95ac20-6c44-013d-d609-0800270c66d6" xmi:uuid="5ab4a250-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="678" y="391" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="668" y="373" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="350" width="133" height="31"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_891123_64590" xmi:uuid="7e1eb4f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881508_231551_62582"/>
      <ownedElement xmi:id="7e1ce350-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e1ce410-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881508_231551_62582"/>
        <text>descrAttr:String</text>
      </ownedElement>
      <ownedElement xmi:id="7e1e9680-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e1e9770-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881508_231551_62582"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="525" y="441" width="200" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_947590_64591" xmi:uuid="7e3b6920-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_866413_62583"/>
      <ownedElement xmi:id="7e2cc9f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e2ccae0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_866413_62583"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="7e2ec3c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e2ec490-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_866413_62583"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_455442_64592" xmi:uuid="7e3b5180-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="5ca514c0-6c44-013d-d609-0800270c66d6" xmi:uuid="5ca51610-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="815" y="197" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="797" y="206" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="623" y="203" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_249968_65252" xmi:uuid="7e759200-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_189794_62506"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_603309_64658"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_981891_64595"/>
      <waypoint x="1190" y="284"/>
      <waypoint x="1057" y="284"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_326509_64594" xmi:uuid="7e76fb70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_836058_62584"/>
      <ownedElement xmi:id="7e4a5150-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e4a5240-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_836058_62584"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="7e4c1390-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e4c1460-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_836058_62584"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="5f806070-6c44-013d-d609-0800270c66d6" xmi:uuid="5f806140-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5f81c5e0-6c44-013d-d609-0800270c66d6" xmi:uuid="5f81c6d0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_981891_64595" xmi:uuid="7e7579d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="7e67a810-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e67a900-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="7e756da0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e756e90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="882" y="273" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="763" y="245" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_490027_65253" xmi:uuid="7f162b90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_968648_62505"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_603309_64658"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_916272_64598"/>
      <waypoint x="1190" y="375"/>
      <waypoint x="1061" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_625148_64596" xmi:uuid="7f1888c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_916027_62585"/>
      <ownedElement xmi:id="7e865e20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e865f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_916027_62585"/>
        <text>descrLang:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="7e8822c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e882390-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_916027_62585"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="63de2870-6c44-013d-d609-0800270c66d6" xmi:uuid="63de2980-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="63f4e040-6c44-013d-d609-0800270c66d6" xmi:uuid="63f4e120-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_475526_64597" xmi:uuid="7ea3fdb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="7e966e90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7e966f70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="7ea3dfd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7ea3e190-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="833" y="434" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_916272_64598" xmi:uuid="7ede8db0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="7ec73440-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7ec73620-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="7ede6380-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7ede6570-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="364" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_760283_64599" xmi:uuid="7f161ac0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="7efe4780-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7efe4860-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="7f160460-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7f1605b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="399" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="819" y="336" width="246" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_800592_64600" xmi:uuid="7f674320-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_573786_62586"/>
      <ownedElement xmi:id="7f2cb600-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7f2cb700-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_573786_62586"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_618320_64601" xmi:uuid="7f442020-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="7401a6e0-6c44-013d-d609-0800270c66d6" xmi:uuid="7401a7c0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="254" y="541" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="308" y="550" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_145543_64603" xmi:uuid="7f5a30d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="7574fc60-6c44-013d-d609-0800270c66d6" xmi:uuid="75822e90-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="463" y="516" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="445" y="525" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_147357_64605" xmi:uuid="7f6739f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="783e1700-6c44-013d-d609-0800270c66d6" xmi:uuid="7873e3c0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="464" y="581" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="445" y="591" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="308" y="504" width="152" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_382691_64607" xmi:uuid="7f851fd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_683826_62587"/>
      <ownedElement xmi:id="7f74b360-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7f74b450-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_683826_62587"/>
        <text>identifiers:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="7f765820-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7f765890-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_683826_62587"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_74957_64608" xmi:uuid="7f8516d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="7cd88d10-6c44-013d-d609-0800270c66d6" xmi:uuid="7cd88de0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="721" y="577" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="706" y="593" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="539" y="588" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_61883_65259" xmi:uuid="7fc51b50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_997853_62511"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_603309_64658"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_743393_64611"/>
      <waypoint x="1190" y="613"/>
      <waypoint x="1128" y="613"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_411319_64610" xmi:uuid="7fc67840-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_115227_62588"/>
      <ownedElement xmi:id="7f9400d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7f9401d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_115227_62588"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="7f95a750-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7f95a7c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_115227_62588"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="7fc29a50-6c44-013d-d609-0800270c66d6" xmi:uuid="7fc29b40-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7fc3c6d0-6c44-013d-d609-0800270c66d6" xmi:uuid="7fc3c7d0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_743393_64611" xmi:uuid="7fc511c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="7fb38d40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7fb38e60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="7fc50420-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7fc50500-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="602" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="903" y="574" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_158767_64612" xmi:uuid="7fef9b20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_396502_62589"/>
      <ownedElement xmi:id="7fd49a40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="7fd49b40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_396502_62589"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_58228_64613" xmi:uuid="7fe2e8e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="8d5d2e40-6c44-013d-d609-0800270c66d6" xmi:uuid="8d73a9e0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="630" y="536" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="693" y="523" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_646200_64615" xmi:uuid="7fef93c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="92a468f0-6c44-013d-d609-0800270c66d6" xmi:uuid="93889e50-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="867" y="514" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="849" y="523" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="693" y="511" width="171" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_173676_64617" xmi:uuid="80225460-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_792582_62590"/>
      <ownedElement xmi:id="80014dc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="80014ec0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_792582_62590"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_380933_64618" xmi:uuid="800fa9c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="a3701550-6c44-013d-d609-0800270c66d6" xmi:uuid="a3701650-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="721" y="727" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="777" y="712" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_679715_64620" xmi:uuid="80224680-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="a42d1280-6c44-013d-d609-0800270c66d6" xmi:uuid="a42d1330-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="972" y="702" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="954" y="711" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="777" y="700" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_9895_64622" xmi:uuid="804ea5e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_973388_62591"/>
      <ownedElement xmi:id="803104b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="803105b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_973388_62591"/>
        <text>defaultDescription:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_198620_64623" xmi:uuid="803f6b50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="a5a69870-6c44-013d-d609-0800270c66d6" xmi:uuid="a5a69920-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="637" y="174" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="693" y="159" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_153780_64625" xmi:uuid="804e9d70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="a64add60-6c44-013d-d609-0800270c66d6" xmi:uuid="a64ade20-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="920" y="149" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="902" y="158" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="693" y="147" width="224" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_629309_64627" xmi:uuid="809ceb50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_427112_62592"/>
      <ownedElement xmi:id="805d0560-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="805d0650-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_427112_62592"/>
        <text>selectName:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_890286_64628" xmi:uuid="806b4530-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="a78b5a90-6c44-013d-d609-0800270c66d6" xmi:uuid="a78b5b40-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="254" y="731" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="308" y="740" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_133759_64630" xmi:uuid="80836070-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="a82ba1e0-6c44-013d-d609-0800270c66d6" xmi:uuid="a82ba290-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="523" y="703" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="505" y="712" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_608864_64632" xmi:uuid="809035a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="a8d23cb0-6c44-013d-d609-0800270c66d6" xmi:uuid="a8d23d70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="523" y="755" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="505" y="764" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_283333_64634" xmi:uuid="809ce2d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="a96a6990-6c44-013d-d609-0800270c66d6" xmi:uuid="a96a6a40-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="525" y="909" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="505" y="917" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="308" y="693" width="212" height="280"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_506353_64636" xmi:uuid="80c0a680-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_410398_62593"/>
      <ownedElement xmi:id="80aa64f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="80aa66c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_410398_62593"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="80ac0950-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="80ac09b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_410398_62593"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_21090_64637" xmi:uuid="80c09e60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="aacca810-6c44-013d-d609-0800270c66d6" xmi:uuid="aacca8b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="756" y="752" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="739" y="767" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="763" width="152" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_832141_64639" xmi:uuid="80e19b10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_999630_62594"/>
      <ownedElement xmi:id="80cdf7a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="80cdf890-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_999630_62594"/>
        <text>nameLanguage:Language</text>
      </ownedElement>
      <ownedElement xmi:id="80cfb370-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="80cfb3e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_999630_62594"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_29890_64640" xmi:uuid="80e193a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="ac275a00-6c44-013d-d609-0800270c66d6" xmi:uuid="ac275ab0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="811" y="902" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="797" y="916" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="602" y="910" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_872997_64642" xmi:uuid="80e61330-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_477142_62595"/>
      <ownedElement xmi:id="80e34310-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="80e34380-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_477142_62595"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="80e5d950-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="80e5dae0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881510_477142_62595"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="539" y="945" width="207" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_899275_65263" xmi:uuid="81835400-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_230413_62520"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_603309_64658"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_3353_64645"/>
      <waypoint x="1264" y="742"/>
      <waypoint x="1264" y="886"/>
      <waypoint x="1152" y="886"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_254778_64643" xmi:uuid="8184b440-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881518_30512_62596"/>
      <ownedElement xmi:id="80fcc360-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="80fcc480-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881518_30512_62596"/>
        <text>nameLanguageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="80fecce0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="80fecd60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881518_30512_62596"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ad371a80-6c44-013d-d609-0800270c66d6" xmi:uuid="ad371b30-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ad386ab0-6c44-013d-d609-0800270c66d6" xmi:uuid="ad386b90-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_334207_64644" xmi:uuid="81282640-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="8114bf20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8114c010-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="81281800-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="81281900-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="924" y="945" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_3353_64645" xmi:uuid="8154fa00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="81435b00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="81435bf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="8154e920-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8154ea30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="924" y="875" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_236226_64646" xmi:uuid="81834850-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="81752f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="81753000-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="81833ab0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="81833ba0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="924" y="910" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="910" y="847" width="299" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_165738_65264" xmi:uuid="81c2ba80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_674831_62518"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_603309_64658"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_417810_64648"/>
      <waypoint x="1264" y="742"/>
      <waypoint x="1264" y="802"/>
      <waypoint x="1169" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_215966_64647" xmi:uuid="81c41890-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881518_112061_62597"/>
      <ownedElement xmi:id="8193ca80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8193cb80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881518_112061_62597"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="81957220-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="81957290-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881518_112061_62597"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b2e08530-6c44-013d-d609-0800270c66d6" xmi:uuid="b2e085d0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b2e1a770-6c44-013d-d609-0800270c66d6" xmi:uuid="b2e1a840-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_417810_64648" xmi:uuid="81c2af40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="81b3d7e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="81b3d910-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="81c2a1b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="81c2a290-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="994" y="791" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="980" y="763" width="262" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_728040_65272" xmi:uuid="82113f70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_858077_62522"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_603309_64658"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_403252_64650"/>
      <waypoint x="1264" y="742"/>
      <waypoint x="1264" y="1040"/>
      <waypoint x="1147" y="1040"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_84313_64649" xmi:uuid="82136800-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881518_783728_62598"/>
      <ownedElement xmi:id="81dad200-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="81dad2f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881518_783728_62598"/>
        <text>sameAsAsgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="81dc7c40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="81dc7cc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881518_783728_62598"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b619ce60-6c44-013d-d609-0800270c66d6" xmi:uuid="b619cf10-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b62d3ef0-6c44-013d-d609-0800270c66d6" xmi:uuid="b62d40c0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_403252_64650" xmi:uuid="821120e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="81fb5d40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="81fb5e20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="8210f650-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8210fa60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="924" y="1029" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="910" y="1001" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_536286_64656" xmi:uuid="82edd900-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881520_27291_62601"/>
      <ownedElement xmi:id="82bcaa40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="82bcac50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881520_27291_62601"/>
        <text>partVersion:Risk_version</text>
      </ownedElement>
      <ownedElement xmi:id="82c04c40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="82c04d50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881520_27291_62601"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b91bf630-6c44-013d-d609-0800270c66d6" xmi:uuid="b91bf6e0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b91d1fd0-6c44-013d-d609-0800270c66d6" xmi:uuid="b91d20a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617975640169_145161_63851" xmi:uuid="82edcce0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_version-of_product"/>
          <ownedElement xmi:id="82dfed80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="82dfee70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_version-of_product"/>
            <text>of_product:Risk</text>
          </ownedElement>
          <ownedElement xmi:id="82edbeb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="82edbfa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_version-of_product"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="924" y="1106" width="123" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="910" y="1078" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_603309_64658" xmi:uuid="835ceb60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881520_262126_62602"/>
      <ownedElement xmi:id="82fc90d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="82fc9420-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881520_262126_62602"/>
        <text>risk_:Risk</text>
      </ownedElement>
      <ownedElement xmi:id="83006930-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="83006a20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881520_262126_62602"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="bbcf1e50-6c44-013d-d609-0800270c66d6" xmi:uuid="bbcf1f00-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bbe75650-6c44-013d-d609-0800270c66d6" xmi:uuid="bbe75740-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_327027_64659" xmi:uuid="8325a280-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-description"/>
          <ownedElement xmi:id="8317b160-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8317b240-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="83259610-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="83259700-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1204" y="154" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_916967_64660" xmi:uuid="83416a90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-id"/>
          <ownedElement xmi:id="83339610-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="833396f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="83415c30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="83415d10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1204" y="518" width="88" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_739619_64661" xmi:uuid="835cdf70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-name"/>
          <ownedElement xmi:id="834f2870-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="834f2b70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="835cd150-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="835cd240-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1204" y="707" width="109" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1190" y="119" width="174" height="623"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_77482_65249" xmi:uuid="840071c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881480_913133_62497"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_692423_64561"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_603309_64658"/>
      <waypoint x="1376" y="88"/>
      <waypoint x="1309" y="88"/>
      <waypoint x="1309" y="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_507025_65251" xmi:uuid="84007c40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881488_13521_62498"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_79386_64576"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_200959_64564"/>
      <waypoint x="847" y="84"/>
      <waypoint x="259" y="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_861663_65254" xmi:uuid="840086e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881488_228028_62500"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_403521_64587"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_637300_64585"/>
      <waypoint x="644" y="371"/>
      <waypoint x="552" y="371"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_535974_65255" xmi:uuid="840092c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881488_333433_62501"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_475526_64597"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_891123_64590"/>
      <waypoint x="833" y="452"/>
      <waypoint x="725" y="452"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_252015_65256" xmi:uuid="84009d10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881488_260805_62502"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_198718_64583"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_947590_64591"/>
      <waypoint x="552" y="214"/>
      <waypoint x="623" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_117454_65257" xmi:uuid="8400a700-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_641387_62504"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_662297_64579"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_82309_64566"/>
      <waypoint x="308" y="207"/>
      <waypoint x="241" y="207"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_124976_65258" xmi:uuid="8400b1e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_787138_62507"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_326509_64594"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_455442_64592"/>
      <waypoint x="924" y="245"/>
      <waypoint x="924" y="217"/>
      <waypoint x="812" y="217"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_678614_65260" xmi:uuid="8400bcf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_675603_62508"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_382691_64607"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_147357_64605"/>
      <waypoint x="539" y="599"/>
      <waypoint x="460" y="599"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_685288_65261" xmi:uuid="8400c8d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_134734_62509"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_411319_64610"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_74957_64608"/>
      <waypoint x="903" y="595"/>
      <waypoint x="721" y="595"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_180427_65262" xmi:uuid="8400d300-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_834255_62510"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_618320_64601"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_299767_64567"/>
      <waypoint x="308" y="560"/>
      <waypoint x="168" y="560"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_684955_65265" xmi:uuid="8400de40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_161536_62512"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_608864_64632"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_506353_64636"/>
      <waypoint x="520" y="774"/>
      <waypoint x="595" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_182868_65266" xmi:uuid="8400e880-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_916668_62513"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_832141_64639"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_283333_64634"/>
      <waypoint x="602" y="928"/>
      <waypoint x="520" y="928"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_45030_65267" xmi:uuid="8400f390-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_131190_62514"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_334207_64644"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_872997_64642"/>
      <waypoint x="924" y="956"/>
      <waypoint x="746" y="956"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_909169_65268" xmi:uuid="8400fea0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_23479_62515"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_21090_64637"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_215966_64647"/>
      <waypoint x="754" y="774"/>
      <waypoint x="980" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_177728_65269" xmi:uuid="840109a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_265875_62516"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_890286_64628"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_496020_64568"/>
      <waypoint x="308" y="746"/>
      <waypoint x="209" y="746"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_104234_65270" xmi:uuid="840114c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_58897_62517"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_380933_64618"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_133759_64630"/>
      <waypoint x="777" y="718"/>
      <waypoint x="520" y="718"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_39883_65271" xmi:uuid="84011fd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_540569_62519"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_236226_64646"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_29890_64640"/>
      <waypoint x="924" y="924"/>
      <waypoint x="812" y="924"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_322721_65273" xmi:uuid="84014f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_328363_62521"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_84313_64649"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_849751_64571"/>
      <waypoint x="910" y="1033"/>
      <waypoint x="182" y="1033"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_47629_65277" xmi:uuid="840164c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_96948_62525"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_536286_64656"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_673650_64574"/>
      <waypoint x="910" y="1110"/>
      <waypoint x="224" y="1110"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_741453_65278" xmi:uuid="84017080-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_77111_62527"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_58228_64613"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_145543_64603"/>
      <waypoint x="693" y="532"/>
      <waypoint x="460" y="532"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_662210_65279" xmi:uuid="84017b00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_609357_62528"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_198620_64623"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_279025_64581"/>
      <waypoint x="693" y="165"/>
      <waypoint x="552" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_432648_65280" xmi:uuid="84018600-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_844300_62529"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_760283_64599"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_735703_64588"/>
      <waypoint x="833" y="410"/>
      <waypoint x="676" y="410"/>
      <waypoint x="676" y="388"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_124080_65284" xmi:uuid="8401b040-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_517344_62533"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_327027_64659"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_153780_64625"/>
      <waypoint x="1204" y="165"/>
      <waypoint x="917" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_532729_65285" xmi:uuid="8401bad0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_61810_62534"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_916967_64660"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_646200_64615"/>
      <waypoint x="1204" y="529"/>
      <waypoint x="864" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885434_411098_65286" xmi:uuid="8401c5a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_285607_62535"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885393_739619_64661"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_679715_64620"/>
      <waypoint x="1204" y="718"/>
      <waypoint x="969" y="718"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885393_692423_64561" xmi:uuid="8401d5c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_880128_62578"/>
      <bounds x="1376" y="80" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617975740395_890761_63903" xmi:uuid="8401e550-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617975746888_283416_63906"/>
      <source xmi:idref="_18_4_1_2b2015d_1617975640169_145161_63851"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885393_603309_64658"/>
      <waypoint x="1047" y="1117"/>
      <waypoint x="1264" y="1117"/>
      <waypoint x="1264" y="742"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1379" height="1162"/>
    <name>Risk</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446396096_883569_339748" xmi:uuid="7cc79f90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898760198_472667_73458"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396122_185779_339780" xmi:uuid="7dbd0e50-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856722_211527_66472"/>
      <ownedElement xmi:id="7d8cf620-6c45-013d-d609-0800270c66d6" xmi:uuid="7d8cf730-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856722_211527_66472"/>
        <text>related_consequence_:Related_consequence</text>
      </ownedElement>
      <ownedElement xmi:id="7dbcf500-6c45-013d-d609-0800270c66d6" xmi:uuid="7dbcf620-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856722_211527_66472"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="276" height="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396138_489511_339814" xmi:uuid="7dbe4d30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="636" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396153_649032_339829" xmi:uuid="7dd03200-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="636" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396168_983725_339844" xmi:uuid="7de0a5a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="636" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396181_887659_339859" xmi:uuid="7df60a40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="636" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396194_912767_339874" xmi:uuid="7e085070-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="636" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396210_8445_339889" xmi:uuid="7e1a65f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="636" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396226_27599_339904" xmi:uuid="7e27dab0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="636" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396240_648319_339919" xmi:uuid="7e2909f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="636" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511440_965778_414782" xmi:uuid="7e292410-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082464018_256812_69907"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396138_489511_339814"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396122_185779_339780"/>
      <waypoint x="636" y="62"/>
      <waypoint x="321" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511440_182494_414785" xmi:uuid="7e292c40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082466914_508741_69921"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396153_649032_339829"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396122_185779_339780"/>
      <waypoint x="636" y="82"/>
      <waypoint x="321" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511440_894735_414788" xmi:uuid="7e2932d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082460968_973529_69893"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396168_983725_339844"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396122_185779_339780"/>
      <waypoint x="636" y="102"/>
      <waypoint x="321" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511440_663267_414791" xmi:uuid="7e293a20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082457245_68030_69879"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396181_887659_339859"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396122_185779_339780"/>
      <waypoint x="636" y="122"/>
      <waypoint x="321" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511440_598850_414794" xmi:uuid="7e2940e0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082469823_772784_69935"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396194_912767_339874"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396122_185779_339780"/>
      <waypoint x="636" y="142"/>
      <waypoint x="321" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511440_298845_414797" xmi:uuid="7e294700-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082473589_770192_69949"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396210_8445_339889"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396122_185779_339780"/>
      <waypoint x="636" y="162"/>
      <waypoint x="321" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511440_496356_414800" xmi:uuid="7e294bb0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082476911_958587_69963"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396226_27599_339904"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396122_185779_339780"/>
      <waypoint x="636" y="182"/>
      <waypoint x="321" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511440_677292_414803" xmi:uuid="7e2951c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082454171_568217_69865"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396240_648319_339919"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396122_185779_339780"/>
      <waypoint x="636" y="202"/>
      <waypoint x="321" y="202"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="639" height="280"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617888881983_347092_62649" xmi:uuid="84170cb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_718159_64745" xmi:uuid="84353920-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_494348_62763"/>
      <ownedElement xmi:id="8426b7d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8426b8d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_494348_62763"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="84286670-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="842866e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_494348_62763"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_583060_64746" xmi:uuid="84352d60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="c5b01050-6c44-013d-d609-0800270c66d6" xmi:uuid="c5b010f0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="245" y="47" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="237" y="68" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="63" width="210" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_154749_64748" xmi:uuid="8447b620-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_599264_62762"/>
      <ownedElement xmi:id="84443f50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="84444150-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_599264_62762"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="84477570-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="844784d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_599264_62762"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="210" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_425305_64749" xmi:uuid="845b3c40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_26730_62761"/>
      <ownedElement xmi:id="845810d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="84581240-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_26730_62761"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="845affd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="845b0110-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_26730_62761"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="567" width="145" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_373898_64750" xmi:uuid="84778ec0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_495365_62764"/>
      <ownedElement xmi:id="846907f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="846908e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_495365_62764"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="846abf30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="846abfb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_495365_62764"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_959215_64751" xmi:uuid="847786e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="c8ae9e30-6c44-013d-d609-0800270c66d6" xmi:uuid="c8ae9f00-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="185" y="688" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="167" y="697" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="693" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_141517_64753" xmi:uuid="8481cf40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_523324_62765"/>
      <ownedElement xmi:id="847d73e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="847d74a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_523324_62765"/>
        <text>Views:RiskView</text>
      </ownedElement>
      <ownedElement xmi:id="847fe800-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="847fe8b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_523324_62765"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_734155_64754" xmi:uuid="8481c820-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_146274_62958"/>
        <ownedElement xmi:id="c94c48e0-6c44-013d-d609-0800270c66d6" xmi:uuid="c94c4990-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_146274_62958"/>
          <bounds x="192" y="758" width="180" height="13"/>
          <text>riskView : Product_view_definition [1]</text>
        </ownedElement>
        <bounds x="174" y="767" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="763" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_330250_64756" xmi:uuid="84d6e500-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_299549_62768"/>
      <ownedElement xmi:id="8498aa70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8498ab70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_299549_62768"/>
        <text>risk_version:Risk_version</text>
      </ownedElement>
      <ownedElement xmi:id="849a5af0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="849a5b60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_299549_62768"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="ca4174f0-6c44-013d-d609-0800270c66d6" xmi:uuid="ca4175a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ca5cdfa0-6c44-013d-d609-0800270c66d6" xmi:uuid="ca5ce080-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_568999_64757" xmi:uuid="84b73320-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-description"/>
          <ownedElement xmi:id="84a916c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="84a917a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="84b724f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="84b725d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1204" y="182" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_954199_64758" xmi:uuid="84d6d9a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-id"/>
          <ownedElement xmi:id="84c52780-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="84c52860-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="84d6cbf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="84d6cd00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1204" y="539" width="88" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1183" y="56" width="189" height="756"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_907483_65321" xmi:uuid="8517a7a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_422730_62702"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_330250_64756"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_740116_64761"/>
      <waypoint x="1183" y="81"/>
      <waypoint x="688" y="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_256298_64760" xmi:uuid="85188f90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_407705_62769"/>
      <ownedElement xmi:id="84ec5d40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="84ec5e50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_407705_62769"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="84ee3400-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="84ee3470-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_407705_62769"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="cdae3e80-6c44-013d-d609-0800270c66d6" xmi:uuid="cdae3f20-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="cdc4f570-6c44-013d-d609-0800270c66d6" xmi:uuid="cdc4f670-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_740116_64761" xmi:uuid="85179c90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="85097350-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="85097440-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="85178f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="85178ff0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="504" y="70" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="490" y="42" width="212" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_58848_64762" xmi:uuid="8563eaf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_872088_62770"/>
      <ownedElement xmi:id="852c1bf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="852c1e00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_872088_62770"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="8530f880-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8530fa10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_872088_62770"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="d085c0e0-6c44-013d-d609-0800270c66d6" xmi:uuid="d085c190-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d0997020-6c44-013d-d609-0800270c66d6" xmi:uuid="d09970e0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_701853_64763" xmi:uuid="8563e0f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="85559dc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="85559ea0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="8563d340-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8563d430-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="301" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="273" width="293" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_338924_64764" xmi:uuid="85ab20d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_257543_62771"/>
      <ownedElement xmi:id="8576a880-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8576a970-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_257543_62771"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_490753_64765" xmi:uuid="858518d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="d35de7c0-6c44-013d-d609-0800270c66d6" xmi:uuid="d35de870-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="268" y="203" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="322" y="212" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_493032_64767" xmi:uuid="8591c300-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="d40043a0-6c44-013d-d609-0800270c66d6" xmi:uuid="d4004450-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="569" y="176" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="551" y="185" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_164122_64769" xmi:uuid="859e7670-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="d48fa890-6c44-013d-d609-0800270c66d6" xmi:uuid="d48fa930-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="569" y="220" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="551" y="229" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_115188_64771" xmi:uuid="85ab1720-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="d553f980-6c44-013d-d609-0800270c66d6" xmi:uuid="d553fa40-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="569" y="381" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="551" y="390" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="322" y="161" width="244" height="259"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_28172_64773" xmi:uuid="8639ddf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_608346_62772"/>
      <ownedElement xmi:id="85ba0a60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="85ba0b50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_608346_62772"/>
        <text>descrLang:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="85bbb230-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="85bbb2a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_608346_62772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d6370a30-6c44-013d-d609-0800270c66d6" xmi:uuid="d6370e70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d64f3330-6c44-013d-d609-0800270c66d6" xmi:uuid="d64f3400-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_470875_64774" xmi:uuid="85dbd760-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="85c9d120-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="85c9d200-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="85dbc840-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="85dbc950-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="875" y="462" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_136264_64775" xmi:uuid="8608c120-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="85f98d60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="85f98eb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="86088a80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="86088bd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="875" y="392" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_771771_64776" xmi:uuid="8639d1d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="862bd2a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="862bd390-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="8639c420-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8639c510-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="875" y="427" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="861" y="364" width="246" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_906435_64777" xmi:uuid="86676550-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_406194_62773"/>
      <ownedElement xmi:id="864c3b30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="864c3c20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_406194_62773"/>
        <text>defaultDescription:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_294345_64778" xmi:uuid="865a90e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="dc1c0790-6c44-013d-d609-0800270c66d6" xmi:uuid="dc1c0910-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="651" y="202" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="707" y="187" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_28000_64780" xmi:uuid="86675c20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="dcdbf1f0-6c44-013d-d609-0800270c66d6" xmi:uuid="dcdbf2b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="948" y="179" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="930" y="188" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="707" y="175" width="238" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_688182_64782" xmi:uuid="866a9d30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_263300_62774"/>
      <ownedElement xmi:id="86690bb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="86690c10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_263300_62774"/>
        <text>descrAttr:String</text>
      </ownedElement>
      <ownedElement xmi:id="866a8a60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="866a8ad0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_263300_62774"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="539" y="469" width="200" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_116470_64783" xmi:uuid="868eea80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_300775_62775"/>
      <ownedElement xmi:id="867bc8b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="867bc9a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_300775_62775"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="867d7ee0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="867d7f50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_300775_62775"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_426923_64784" xmi:uuid="868edf60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="de85b450-6c44-013d-d609-0800270c66d6" xmi:uuid="de85b4f0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="850" y="228" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="832" y="237" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="658" y="231" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_182733_64786" xmi:uuid="86acda30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_660179_62776"/>
      <ownedElement xmi:id="869e7d80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="869e7e90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_660179_62776"/>
        <text>lang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="86a02890-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="86a02900-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_660179_62776"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_485957_64787" xmi:uuid="86acd180-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="dfce8d70-6c44-013d-d609-0800270c66d6" xmi:uuid="dfce8e20-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="699" y="419" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="689" y="401" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="665" y="378" width="133" height="31"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_626541_64789" xmi:uuid="86d622d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_677814_62777"/>
      <ownedElement xmi:id="86bb0150-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="86bb0240-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_677814_62777"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_634067_64790" xmi:uuid="86c96d90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="e10812c0-6c44-013d-d609-0800270c66d6" xmi:uuid="e1081360-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="623" y="557" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="686" y="544" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_334578_64792" xmi:uuid="86d61a90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="e1a54800-6c44-013d-d609-0800270c66d6" xmi:uuid="e1a548b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="871" y="535" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="853" y="544" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="686" y="532" width="182" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_799863_64794" xmi:uuid="8720e870-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_702987_62778"/>
      <ownedElement xmi:id="86e7c470-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="86e7c570-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_702987_62778"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_575183_64795" xmi:uuid="87030660-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="e3314c00-6c44-013d-d609-0800270c66d6" xmi:uuid="e3314da0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="205" y="562" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="259" y="571" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_766950_64797" xmi:uuid="87140100-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="e3b4ebb0-6c44-013d-d609-0800270c66d6" xmi:uuid="e3b4ec60-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="414" y="537" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="396" y="546" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_431993_64799" xmi:uuid="8720d000-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="e44a0940-6c44-013d-d609-0800270c66d6" xmi:uuid="e44a09f0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="415" y="602" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="396" y="612" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="259" y="525" width="152" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_419738_64801" xmi:uuid="874d2390-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_392743_62779"/>
      <ownedElement xmi:id="8736ed40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8736ee50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_392743_62779"/>
        <text>identifiers:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="8738b520-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8738b590-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_392743_62779"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_248235_64802" xmi:uuid="874d1950-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="e57f8650-6c44-013d-d609-0800270c66d6" xmi:uuid="e57f86e0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="672" y="596" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="657" y="612" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="490" y="609" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_707087_65331" xmi:uuid="8796b880-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_267620_62714"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_330250_64756"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_79880_64805"/>
      <waypoint x="1183" y="641"/>
      <waypoint x="1058" y="641"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_601647_64804" xmi:uuid="8798dd80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_170264_62780"/>
      <ownedElement xmi:id="875cb190-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="875cb280-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_170264_62780"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="875e67b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="875e6820-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_170264_62780"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e655baa0-6c44-013d-d609-0800270c66d6" xmi:uuid="e655bb50-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e66ad170-6c44-013d-d609-0800270c66d6" xmi:uuid="e66ad240-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_79880_64805" xmi:uuid="879696d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="87812680-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="878127b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="879671a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="879673a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="875" y="630" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="861" y="602" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_990579_65336" xmi:uuid="87e0dd40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_530800_62717"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_330250_64756"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_8018_64807"/>
      <waypoint x="1183" y="718"/>
      <waypoint x="650" y="718"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_841446_64806" xmi:uuid="87e1b340-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_89171_62781"/>
      <ownedElement xmi:id="87ab90c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="87ab93e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_89171_62781"/>
        <text>sameAsAsgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="87ada410-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="87ada4a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_89171_62781"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e8c8a8a0-6c44-013d-d609-0800270c66d6" xmi:uuid="e8c8a960-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e8c9cbc0-6c44-013d-d609-0800270c66d6" xmi:uuid="e8c9cc90-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_8018_64807" xmi:uuid="87e0d180-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="87d2d0b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="87d2d1a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="87e0c240-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="87e0c4c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="427" y="707" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="413" y="679" width="268" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_37693_64809" xmi:uuid="881ba010-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_347643_62783"/>
      <ownedElement xmi:id="87f0a2c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="87f0a3c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_347643_62783"/>
        <text>pvd:Product_view_definition</text>
      </ownedElement>
      <ownedElement xmi:id="87f24860-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="87f248d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_347643_62783"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="eb9cca30-6c44-013d-d609-0800270c66d6" xmi:uuid="eb9ccad0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ebabe7f0-6c44-013d-d609-0800270c66d6" xmi:uuid="ebabe8d0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617979866678_864966_64984" xmi:uuid="881b9480-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-defined_version"/>
          <ownedElement xmi:id="880d8840-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="880d8920-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-defined_version"/>
            <text>defined_version:Product_version</text>
          </ownedElement>
          <ownedElement xmi:id="881b8740-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="881b8820-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-defined_version"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="875" y="777" width="220" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="861" y="749" width="241" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_784883_65322" xmi:uuid="881bab90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_539342_62701"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_256298_64760"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_583060_64746"/>
      <waypoint x="490" y="74"/>
      <waypoint x="252" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_729097_65323" xmi:uuid="881bb620-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_364083_62703"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_182733_64786"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_115188_64771"/>
      <waypoint x="665" y="399"/>
      <waypoint x="566" y="399"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_565211_65324" xmi:uuid="881bc0e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_212139_62704"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_164122_64769"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_116470_64783"/>
      <waypoint x="566" y="242"/>
      <waypoint x="658" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_360125_65325" xmi:uuid="881bcbc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_968021_62705"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_58848_64762"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_426923_64784"/>
      <waypoint x="886" y="273"/>
      <waypoint x="886" y="244"/>
      <waypoint x="847" y="244"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_440410_65326" xmi:uuid="881bd5e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_550711_62706"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_470875_64774"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_688182_64782"/>
      <waypoint x="875" y="480"/>
      <waypoint x="739" y="480"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_646543_65327" xmi:uuid="881be000-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_217375_62707"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_294345_64778"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_493032_64767"/>
      <waypoint x="707" y="193"/>
      <waypoint x="566" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_771206_65328" xmi:uuid="881beb00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_163743_62708"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_771771_64776"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_485957_64787"/>
      <waypoint x="875" y="438"/>
      <waypoint x="697" y="438"/>
      <waypoint x="697" y="416"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_964042_65329" xmi:uuid="881bf5d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_109189_62709"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_568999_64757"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_28000_64780"/>
      <waypoint x="1204" y="196"/>
      <waypoint x="945" y="196"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_74964_65330" xmi:uuid="881c0030-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_942463_62710"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_490753_64765"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_154749_64748"/>
      <waypoint x="322" y="221"/>
      <waypoint x="241" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_183665_65332" xmi:uuid="881c0b00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_941669_62711"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_419738_64801"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_431993_64799"/>
      <waypoint x="490" y="620"/>
      <waypoint x="411" y="620"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_230977_65333" xmi:uuid="881c1670-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_383998_62712"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_601647_64804"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_248235_64802"/>
      <waypoint x="861" y="623"/>
      <waypoint x="672" y="623"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_247847_65334" xmi:uuid="881c20b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_938415_62713"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_575183_64795"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_425305_64749"/>
      <waypoint x="259" y="578"/>
      <waypoint x="180" y="578"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_626237_65335" xmi:uuid="881c2b70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_908580_62715"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_954199_64758"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_334578_64792"/>
      <waypoint x="1204" y="550"/>
      <waypoint x="868" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_672254_65337" xmi:uuid="881c35e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_181197_62716"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_841446_64806"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_959215_64751"/>
      <waypoint x="413" y="704"/>
      <waypoint x="182" y="704"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_655835_65339" xmi:uuid="881c4090-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_974492_62718"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_599662_64743"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_330250_64756"/>
      <waypoint x="1392" y="46"/>
      <waypoint x="1278" y="46"/>
      <waypoint x="1278" y="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_646367_65340" xmi:uuid="881c4b00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_55753_62719"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_634067_64790"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_766950_64797"/>
      <waypoint x="686" y="553"/>
      <waypoint x="411" y="553"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_892087_65342" xmi:uuid="881c5680-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_964436_62720"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_37693_64809"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_734155_64754"/>
      <waypoint x="861" y="774"/>
      <waypoint x="189" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885442_498418_65343" xmi:uuid="881c60d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_842925_62753"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_136264_64775"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_330250_64756"/>
      <waypoint x="1103" y="403"/>
      <waypoint x="1183" y="403"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_343586_65344" xmi:uuid="881c6be0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_940994_62754"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_701853_64763"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_330250_64756"/>
      <waypoint x="882" y="315"/>
      <waypoint x="1183" y="315"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_599662_64743" xmi:uuid="881c72d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_105139_62782"/>
      <bounds x="1392" y="43" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617979892833_294230_65030" xmi:uuid="881c82e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617979894558_695125_65033"/>
      <source xmi:idref="_18_4_1_2b2015d_1617979866678_864966_64984"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_330250_64756"/>
      <waypoint x="1095" y="788"/>
      <waypoint x="1183" y="788"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1395" height="827"/>
    <name>RiskVersion</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617888883152_272616_62831" xmi:uuid="883b0ad0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_912952_62430"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_858259_64884" xmi:uuid="884f6fc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_918618_62949"/>
      <ownedElement xmi:id="88494e30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="88494f30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_918618_62949"/>
        <text>AdditionalContexts:ViewContext</text>
      </ownedElement>
      <ownedElement xmi:id="884af450-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="884af4c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_918618_62949"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_848121_64885" xmi:uuid="884f6730-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516290047903_693170_38626"/>
        <ownedElement xmi:id="f277d2c0-6c44-013d-d609-0800270c66d6" xmi:uuid="f277d370-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516290047903_693170_38626"/>
          <bounds x="273" y="76" width="269" height="13"/>
          <text>additionalView : Additional_view_definition_context [0..1]</text>
        </ownedElement>
        <bounds x="251" y="88" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="84" width="238" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_668388_64890" xmi:uuid="886b5640-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_781449_62948"/>
      <ownedElement xmi:id="885cfe70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="885cff60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_781449_62948"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="885ea670-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="885ea6e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_781449_62948"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_865499_64891" xmi:uuid="886b4e40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="f3a38f20-6c44-013d-d609-0800270c66d6" xmi:uuid="f3a38fd0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="241" y="128" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="223" y="137" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="133" width="210" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_187265_64896" xmi:uuid="887a7ca0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_946808_62947"/>
      <ownedElement xmi:id="8878c050-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8878c140-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_946808_62947"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="887a6980-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="887a69f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_946808_62947"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="252" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_950013_64897" xmi:uuid="888b3410-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_517663_62946"/>
      <ownedElement xmi:id="8887d6e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8887d7e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_517663_62946"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="888afb50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="888afcb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_517663_62946"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="476" width="145" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_161377_64898" xmi:uuid="889e8310-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_109694_62952"/>
      <ownedElement xmi:id="889447f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="88944950-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_109694_62952"/>
        <text>InitialContext:ViewContext</text>
      </ownedElement>
      <ownedElement xmi:id="88978720-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="889788d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_109694_62952"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_766030_64899" xmi:uuid="889e7ac0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516289943404_493045_38585"/>
        <ownedElement xmi:id="f5ea9750-6c44-013d-d609-0800270c66d6" xmi:uuid="f5ea9a40-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516289943404_493045_38585"/>
          <bounds x="234" y="584" width="225" height="13"/>
          <text>initialView : Initial_view_definition_context [0..1]</text>
        </ownedElement>
        <bounds x="216" y="593" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="588" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_264867_64901" xmi:uuid="89512c30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_740241_62955"/>
      <ownedElement xmi:id="88adab40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="88adac30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_740241_62955"/>
        <text>risk_view:Product_view_definition</text>
      </ownedElement>
      <ownedElement xmi:id="88af5290-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="88af5300-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_740241_62955"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="f6bbd990-6c44-013d-d609-0800270c66d6" xmi:uuid="f6bbda30-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f6d248b0-6c44-013d-d609-0800270c66d6" xmi:uuid="f6d24980-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_824645_64907" xmi:uuid="88d7b080-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-id"/>
          <ownedElement xmi:id="88c5e250-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="88c5e340-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="88d7a3f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="88d7a4d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1092" y="469" width="100" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_145635_64908" xmi:uuid="88f44360-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-name"/>
          <ownedElement xmi:id="88e5ef20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="88e5eff0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="88f435c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="88f436b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-name"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1092" y="266" width="121" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617978628740_416372_64711" xmi:uuid="89278f80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_contexts"/>
          <ownedElement xmi:id="891985f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="891986d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_contexts"/>
            <text>additional_contexts:Additional_view_definition_context</text>
          </ownedElement>
          <ownedElement xmi:id="89278350-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="89278440-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_contexts"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1092" y="84" width="348" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617978628756_666742_64742" xmi:uuid="89511ed0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
          <ownedElement xmi:id="89430320-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="89430400-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
            <text>initial_context:Initial_view_definition_context</text>
          </ownedElement>
          <ownedElement xmi:id="895111e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="895112d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1092" y="588" width="281" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1078" y="49" width="369" height="644"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_617972_64922" xmi:uuid="89a51b60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_836943_62959"/>
      <ownedElement xmi:id="895f4e50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="895f4f40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_836943_62959"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_196759_64923" xmi:uuid="896d7940-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="fd27da10-6c44-013d-d609-0800270c66d6" xmi:uuid="fd27dac0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="275" y="247" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="329" y="256" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_323605_64925" xmi:uuid="8983bf20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="fdcdc840-6c44-013d-d609-0800270c66d6" xmi:uuid="fdcdc8f0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="576" y="260" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="558" y="269" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_211315_64927" xmi:uuid="89952fe0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="fe4eaee0-6c44-013d-d609-0800270c66d6" xmi:uuid="fe4eaf70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="376" y="229" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="366" y="245" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_959949_64929" xmi:uuid="89a50c20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="fedf3ae0-6c44-013d-d609-0800270c66d6" xmi:uuid="fedf3b70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="380" y="311" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="370" y="293" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="329" y="245" width="244" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_632687_64931" xmi:uuid="89d0f140-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_434166_62960"/>
      <ownedElement xmi:id="89b3e8b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="89b3e9b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_434166_62960"/>
        <text>defaultDescription:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_885901_64932" xmi:uuid="89c44b50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="000db390-6c45-013d-d609-0800270c66d6" xmi:uuid="000db4c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="686" y="286" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="742" y="271" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_614570_64934" xmi:uuid="89d0e880-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="00addf50-6c45-013d-d609-0800270c66d6" xmi:uuid="00addff0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="969" y="263" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="951" y="272" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="742" y="259" width="224" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_847855_64936" xmi:uuid="89ecdb00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_421560_62961"/>
      <ownedElement xmi:id="89de7810-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="89de7900-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_421560_62961"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="89e01f60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="89e01fc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_421560_62961"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_612269_64937" xmi:uuid="89ecd200-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="01df6460-6c45-013d-d609-0800270c66d6" xmi:uuid="01df6520-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="507" y="192" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="489" y="201" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="315" y="196" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_159801_65386" xmi:uuid="8a2c5c90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_503868_62899"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_264867_64901"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_722719_64940"/>
      <waypoint x="1078" y="221"/>
      <waypoint x="931" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_167682_64939" xmi:uuid="8a2d2d30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_125046_62962"/>
      <ownedElement xmi:id="8a011dd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a011f40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_125046_62962"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="8a02fda0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a02fe30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_125046_62962"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="02d4e780-6c45-013d-d609-0800270c66d6" xmi:uuid="02d4e840-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="02d60da0-6c45-013d-d609-0800270c66d6" xmi:uuid="02d60e60-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_722719_64940" xmi:uuid="8a2c4ff0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="8a1e2760-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a1e2850-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="8a2c4260-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a2c4350-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="756" y="210" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="742" y="182" width="293" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_999857_64941" xmi:uuid="8a491aa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_157358_62963"/>
      <ownedElement xmi:id="8a3aa660-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a3aa750-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_157358_62963"/>
        <text>lang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="8a3c4ef0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a3c4f50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_157358_62963"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_157681_64942" xmi:uuid="8a491190-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="060d79d0-6c45-013d-d609-0800270c66d6" xmi:uuid="060d7a90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="493" y="373" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="475" y="382" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="343" y="378" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_149740_65387" xmi:uuid="8ada4a10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_634499_62898"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_264867_64901"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_220560_64946"/>
      <waypoint x="1078" y="354"/>
      <waypoint x="984" y="354"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_711260_64944" xmi:uuid="8adb19f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_331204_62964"/>
      <ownedElement xmi:id="8a5834d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a5835c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_331204_62964"/>
        <text>descrLang:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="8a59e9b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a59ea20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_331204_62964"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="06e98b00-6c45-013d-d609-0800270c66d6" xmi:uuid="06e98ba0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="06fa4ce0-6c45-013d-d609-0800270c66d6" xmi:uuid="06fa4dd0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_670817_64945" xmi:uuid="8a7636c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="8a6808b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a680990-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="8a762950-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a762a40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="756" y="413" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_220560_64946" xmi:uuid="8a9fbf70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="8a91a970-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a91aa50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="8a9fb110-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8a9fb200-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="756" y="343" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_738358_64947" xmi:uuid="8ada3d10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="8ac867e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8ac868e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="8ada2e60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8ada2f60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="756" y="378" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="742" y="315" width="294" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_225621_64948" xmi:uuid="8ade5040-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_679843_62965"/>
      <ownedElement xmi:id="8adcbff0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8adcc110-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_679843_62965"/>
        <text>descrAttr:String</text>
      </ownedElement>
      <ownedElement xmi:id="8ade3d60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8ade3dc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_679843_62965"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="434" y="413" width="200" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_178164_65396" xmi:uuid="8b2d0840-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_871359_62900"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_264867_64901"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_858153_64950"/>
      <waypoint x="1078" y="151"/>
      <waypoint x="723" y="151"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_573794_64949" xmi:uuid="8b2f4750-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_605575_62966"/>
      <ownedElement xmi:id="8af48ed0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8af48fe0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_605575_62966"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="8af63a30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8af63aa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_605575_62966"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="0be13010-6c45-013d-d609-0800270c66d6" xmi:uuid="0be130b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0bf65d40-6c45-013d-d609-0800270c66d6" xmi:uuid="0bf65e00-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_858153_64950" xmi:uuid="8b2cfc90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="8b1efc40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8b1efd50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="8b2ceeb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8b2cef90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="140" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="112" width="207" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_520594_64951" xmi:uuid="8b4e6180-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_458668_62953"/>
      <ownedElement xmi:id="8b3f8a10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8b3f8b10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_458668_62953"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="8b413000-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8b4130b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_458668_62953"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_59604_64952" xmi:uuid="8b4e5850-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="0e81d340-6c45-013d-d609-0800270c66d6" xmi:uuid="0e81d3e0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="171" y="647" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="153" y="656" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="651" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_965642_65398" xmi:uuid="8b88c350-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_111_62903"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_264867_64901"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_818276_64955"/>
      <waypoint x="1078" y="669"/>
      <waypoint x="979" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_14047_64954" xmi:uuid="8b8992a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_782432_62967"/>
      <ownedElement xmi:id="8b5d7670-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8b5d7770-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_782432_62967"/>
        <text>sameAsAsgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="8b5f1ef0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8b5f1f50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_782432_62967"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="0f70ac90-6c45-013d-d609-0800270c66d6" xmi:uuid="0f70ad80-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0f7cad50-6c45-013d-d609-0800270c66d6" xmi:uuid="0f7cae70-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_818276_64955" xmi:uuid="8b88b7f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="8b7a8640-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8b7a8730-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="8b88a8c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8b88ab70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="756" y="658" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="742" y="630" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_123059_64956" xmi:uuid="8bbf5750-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_110069_62968"/>
      <ownedElement xmi:id="8b97cfc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8b97d0b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_110069_62968"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_119896_64957" xmi:uuid="8ba60f90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="130fec60-6c45-013d-d609-0800270c66d6" xmi:uuid="130fecf0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="275" y="471" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="329" y="480" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_967757_64959" xmi:uuid="8bb2bc60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="13b00570-6c45-013d-d609-0800270c66d6" xmi:uuid="13b00610-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="500" y="467" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="482" y="476" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_557313_64961" xmi:uuid="8bbf4fa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="144d2cd0-6c45-013d-d609-0800270c66d6" xmi:uuid="144d2dc0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="374" y="507" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="364" y="489" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="329" y="455" width="168" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_310646_64963" xmi:uuid="8bdb4c60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_133271_62969"/>
      <ownedElement xmi:id="8bccd960-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8bccda50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_133271_62969"/>
        <text>identifiers:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="8bce7eb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8bce7f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_133271_62969"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_260429_64964" xmi:uuid="8bdb4380-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="15bc4910-6c45-013d-d609-0800270c66d6" xmi:uuid="15bc4b60-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="504" y="519" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="503" y="542" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="343" y="539" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_25924_65400" xmi:uuid="8c1ec570-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_632540_62908"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_264867_64901"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_602128_64972"/>
      <waypoint x="1078" y="553"/>
      <waypoint x="939" y="553"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_891297_64971" xmi:uuid="8c200ec0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_481368_62971"/>
      <ownedElement xmi:id="8bea64c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8bea65c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_481368_62971"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="8bec0b80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8bec0d00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_481368_62971"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="16b83dd0-6c45-013d-d609-0800270c66d6" xmi:uuid="16b83eb0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="16cddb70-6c45-013d-d609-0800270c66d6" xmi:uuid="16cddcd0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885411_602128_64972" xmi:uuid="8c1eb360-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="8c0798c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8c0799b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="8c1e9e40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8c1e9f70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="756" y="539" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="742" y="511" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_275900_65380" xmi:uuid="8c2020b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_548809_62883"/>
      <source xmi:idref="_18_4_1_2b2015d_1617978628756_666742_64742"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_766030_64899"/>
      <waypoint x="1092" y="602"/>
      <waypoint x="231" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_397423_65384" xmi:uuid="8c2031a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_485338_62889"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_340107_64882"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_264867_64901"/>
      <waypoint x="1459" y="42"/>
      <waypoint x="1264" y="42"/>
      <waypoint x="1264" y="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_85391_65388" xmi:uuid="8c2042b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_169425_62890"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_211315_64927"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_847855_64936"/>
      <waypoint x="375" y="245"/>
      <waypoint x="375" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_370409_65389" xmi:uuid="8c2053f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_694830_62891"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_167682_64939"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_612269_64937"/>
      <waypoint x="742" y="210"/>
      <waypoint x="504" y="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_936077_65390" xmi:uuid="8c2065a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_794094_62892"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_999857_64941"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_959949_64929"/>
      <waypoint x="378" y="378"/>
      <waypoint x="378" y="308"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_287143_65391" xmi:uuid="8c207780-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_998706_62893"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_670817_64945"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_225621_64948"/>
      <waypoint x="756" y="424"/>
      <waypoint x="634" y="424"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_270813_65392" xmi:uuid="8c2088c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_590754_62894"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_885901_64932"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_323605_64925"/>
      <waypoint x="742" y="277"/>
      <waypoint x="573" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_253036_65393" xmi:uuid="8c209a60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_627416_62895"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_738358_64947"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_157681_64942"/>
      <waypoint x="756" y="389"/>
      <waypoint x="490" y="389"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_806393_65394" xmi:uuid="8c20ac50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_783300_62896"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_196759_64923"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_187265_64896"/>
      <waypoint x="329" y="263"/>
      <waypoint x="227" y="263"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_32420_65395" xmi:uuid="8c20fff0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_730618_62897"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_145635_64908"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_614570_64934"/>
      <waypoint x="1092" y="280"/>
      <waypoint x="966" y="280"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_19109_65397" xmi:uuid="8c2111c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_730777_62901"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_573794_64949"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_865499_64891"/>
      <waypoint x="525" y="147"/>
      <waypoint x="238" y="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_796554_65399" xmi:uuid="8c212230-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_962033_62902"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_14047_64954"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_59604_64952"/>
      <waypoint x="742" y="665"/>
      <waypoint x="168" y="665"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_772712_65401" xmi:uuid="8c213260-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_186655_62904"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_310646_64963"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_557313_64961"/>
      <waypoint x="371" y="539"/>
      <waypoint x="371" y="504"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_505584_65402" xmi:uuid="8c214800-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_594401_62905"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_891297_64971"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_260429_64964"/>
      <waypoint x="742" y="550"/>
      <waypoint x="518" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_353722_65403" xmi:uuid="8c2158c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_883685_62906"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885403_824645_64907"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885411_967757_64959"/>
      <waypoint x="1092" y="483"/>
      <waypoint x="497" y="483"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_427094_65405" xmi:uuid="8c2169b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_255209_62909"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885411_119896_64957"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_950013_64897"/>
      <waypoint x="329" y="487"/>
      <waypoint x="166" y="487"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_245422_65407" xmi:uuid="8c217c50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883568_607881_62885"/>
      <source xmi:idref="_18_4_1_2b2015d_1617978628740_416372_64711"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885403_848121_64885"/>
      <waypoint x="1092" y="95"/>
      <waypoint x="266" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885403_340107_64882" xmi:uuid="8c218610-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_146274_62958"/>
      <bounds x="1459" y="34" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1462" height="708"/>
    <name>RiskView</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617888883838_335885_63029" xmi:uuid="8cc0af30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_807376_62431"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_241056_65044" xmi:uuid="8cd0f5f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_895212_63110"/>
      <ownedElement xmi:id="8ccd0ca0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8ccd0db0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_895212_63110"/>
        <text>Related:Risk</text>
      </ownedElement>
      <ownedElement xmi:id="8ccf09b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8ccf0a70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_895212_63110"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_181412_65045" xmi:uuid="8cd0ecf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_880128_62578"/>
        <ownedElement xmi:id="1dfbb310-6c45-013d-d609-0800270c66d6" xmi:uuid="1dfbb3f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_880128_62578"/>
          <bounds x="164" y="597" width="65" height="13"/>
          <text>risk : Risk [1]</text>
        </ownedElement>
        <bounds x="146" y="606" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="602" width="119" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_181967_65047" xmi:uuid="8cd70660-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_972460_63109"/>
      <ownedElement xmi:id="8cd3e6d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8cd3e740-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_972460_63109"/>
        <text>Relating:Risk</text>
      </ownedElement>
      <ownedElement xmi:id="8cd565e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8cd56660-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_972460_63109"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_858070_65048" xmi:uuid="8cd6feb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_880128_62578"/>
        <ownedElement xmi:id="1e982c50-6c45-013d-d609-0800270c66d6" xmi:uuid="1e982cf0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881500_880128_62578"/>
          <bounds x="164" y="634" width="65" height="13"/>
          <text>risk : Risk [1]</text>
        </ownedElement>
        <bounds x="146" y="643" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="637" width="119" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_100409_65050" xmi:uuid="8d11d3a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="8cf01fe0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8cf020d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_493768_65051" xmi:uuid="8d11c860-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="20f6e410-6c45-013d-d609-0800270c66d6" xmi:uuid="20f6e510-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="402" y="550" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="384" y="559" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="147" y="546" width="252" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_522496_65053" xmi:uuid="8d493090-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="8d2b1300-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8d2b13f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_62271_65054" xmi:uuid="8d4927d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="233240e0-6c45-013d-d609-0800270c66d6" xmi:uuid="23324180-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="297" y="121" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="279" y="130" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="119" y="119" width="175" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_40876_65056" xmi:uuid="8d896ce0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="8d6ba3a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8d6ba490-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_496507_65057" xmi:uuid="8d896410-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="258c5500-6c45-013d-d609-0800270c66d6" xmi:uuid="258c5590-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="447" y="681" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="429" y="690" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="252" y="679" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_77941_65059" xmi:uuid="8d8973b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="399" y="28" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_238611_65060" xmi:uuid="8e46d910-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_66649_63111"/>
      <ownedElement xmi:id="8d9b69f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8d9b6af0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_66649_63111"/>
        <text>risk_relationship:Risk_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="8d9d0ef0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8d9d0f60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_66649_63111"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="26527e10-6c45-013d-d609-0800270c66d6" xmi:uuid="26527eb0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="26618030-6c45-013d-d609-0800270c66d6" xmi:uuid="26618100-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_441289_65061" xmi:uuid="8dc09800-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_relationship-description"/>
          <ownedElement xmi:id="8dab1d20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8dab1e10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="8dc089b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8dc08a90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="819" y="553" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_183612_65064" xmi:uuid="8ddffd50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_relationship-relation_type"/>
          <ownedElement xmi:id="8dce82a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8dce8380-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="8ddfeda0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8ddfeea0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_relationship-relation_type"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="819" y="686" width="150" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617980592674_914271_65904" xmi:uuid="8e19c010-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_relationship-relating_product"/>
          <ownedElement xmi:id="8e0426b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8e0427b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_relationship-relating_product"/>
            <text>relating_product:Risk</text>
          </ownedElement>
          <ownedElement xmi:id="8e197040-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8e197150-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_relationship-relating_product"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="819" y="644" width="154" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617980592660_747816_65873" xmi:uuid="8e46cb40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_relationship-related_product"/>
          <ownedElement xmi:id="8e38aeb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8e38afb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_relationship-related_product"/>
            <text>related_product:Risk</text>
          </ownedElement>
          <ownedElement xmi:id="8e46bad0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8e46bbc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_relationship-related_product"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="819" y="602" width="151" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="798" y="98" width="245" height="692"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_94449_65443" xmi:uuid="8eb993d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_354312_63082"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_238611_65060"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_126216_65067"/>
      <waypoint x="798" y="179"/>
      <waypoint x="631" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_312971_65065" xmi:uuid="8eba4520-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_810978_63113"/>
      <ownedElement xmi:id="8e55e600-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8e55e6f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_810978_63113"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="8e578f70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8e578fe0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_810978_63113"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="2d2f8c10-6c45-013d-d609-0800270c66d6" xmi:uuid="2d2f8dc0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2d44f9c0-6c45-013d-d609-0800270c66d6" xmi:uuid="2d44fa90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_554668_65066" xmi:uuid="8e73d690-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="8e65c440-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8e65c530-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="8e73c6d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8e73c7b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="448" y="126" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_126216_65067" xmi:uuid="8e9d3a90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="8e8f2100-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8e8f21f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="8e9d2af0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8e9d2be0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="448" y="161" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_799639_65068" xmi:uuid="8eb97400-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="8eab43c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8eab45e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="8eb94b00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8eb94c70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="448" y="196" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="434" y="98" width="308" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_836453_65448" xmi:uuid="8f120f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_673511_63087"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_238611_65060"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_793202_65070"/>
      <waypoint x="798" y="291"/>
      <waypoint x="638" y="291"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_28993_65069" xmi:uuid="8f12bc20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="8ed41580-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8ed41670-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="8ee0bde0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8ee0bed0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="334225f0-6c45-013d-d609-0800270c66d6" xmi:uuid="334226a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="335bd0e0-6c45-013d-d609-0800270c66d6" xmi:uuid="335bd250-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_793202_65070" xmi:uuid="8f11e8d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="8f03a330-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8f03a420-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="8f11d2d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8f11d3c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="455" y="273" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="434" y="245" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_734539_65449" xmi:uuid="8f743f70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_405247_63088"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_238611_65060"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_889054_65072"/>
      <waypoint x="798" y="368"/>
      <waypoint x="639" y="368"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_532909_65071" xmi:uuid="8f7510d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="8f2fb980-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8f2fba70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="8f44bd80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8f44bf90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="36b0e320-6c45-013d-d609-0800270c66d6" xmi:uuid="36b0e3d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="36bfed00-6c45-013d-d609-0800270c66d6" xmi:uuid="36bfede0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_889054_65072" xmi:uuid="8f743150-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="8f62af50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8f62b040-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="8f73e1e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8f73e2f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="455" y="350" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="434" y="322" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_886569_65450" xmi:uuid="8fccfe80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_509587_63089"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_238611_65060"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_340186_65074"/>
      <waypoint x="798" y="445"/>
      <waypoint x="623" y="445"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_482101_65073" xmi:uuid="8fcd9a00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="8f96de10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8f96df10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="8fa372d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8fa373b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="3a5d7a20-6c45-013d-d609-0800270c66d6" xmi:uuid="3a5d7ad0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3a6cf740-6c45-013d-d609-0800270c66d6" xmi:uuid="3a6d0040-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_340186_65074" xmi:uuid="8fccf390-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="8fbed9e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8fbedac0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="8fccc9b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8fcccaa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="448" y="427" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="434" y="399" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_249833_65451" xmi:uuid="9032d0c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_799887_63090"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_238611_65060"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_403850_65076"/>
      <waypoint x="798" y="522"/>
      <waypoint x="676" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_169288_65075" xmi:uuid="90336aa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="8fefdf50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="8fefe040-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="9005ac30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9005ad40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="3dc94ee0-6c45-013d-d609-0800270c66d6" xmi:uuid="3dc94f90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3dec0950-6c45-013d-d609-0800270c66d6" xmi:uuid="3dec0a30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_403850_65076" xmi:uuid="9032c5d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="9024be30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9024bf20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="9032b7d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9032b8c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="448" y="504" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="434" y="476" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_834432_65452" xmi:uuid="908b6d90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_325423_63091"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_238611_65060"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_718245_65078"/>
      <waypoint x="798" y="774"/>
      <waypoint x="639" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_3677_65077" xmi:uuid="908c06a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="904dcfd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="904dd1d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9060c8c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9060c9f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="416bc400-6c45-013d-d609-0800270c66d6" xmi:uuid="416bc5e0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="417c0920-6c45-013d-d609-0800270c66d6" xmi:uuid="417c0ad0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_718245_65078" xmi:uuid="908b6290-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="907d5b40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="907d5c20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="908b5370-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="908b54f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="455" y="763" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="735" width="291" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_636894_65079" xmi:uuid="908f3c60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_442548_63114"/>
      <ownedElement xmi:id="908dad90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="908dae00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_442548_63114"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="908f2960-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="908f29c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_442548_63114"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="217" y="196" width="136" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_424796_65080" xmi:uuid="90bd3010-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_884482_63115"/>
      <ownedElement xmi:id="909d3770-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="909d3860-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_884482_63115"/>
        <text>defaultType:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_975417_65081" xmi:uuid="90abb430-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="44b01510-6c45-013d-d609-0800270c66d6" xmi:uuid="44b015c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="462" y="706" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="518" y="691" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_276397_65083" xmi:uuid="90bd2250-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="45399dd0-6c45-013d-d609-0800270c66d6" xmi:uuid="45399e70-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="709" y="680" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="691" y="689" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="518" y="679" width="188" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_390402_65442" xmi:uuid="90bd4140-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_421745_63081"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_985139_65042"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_238611_65060"/>
      <waypoint x="1070" y="81"/>
      <waypoint x="928" y="81"/>
      <waypoint x="928" y="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_87236_65444" xmi:uuid="90bd5400-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_980535_63083"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_554668_65066"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_62271_65054"/>
      <waypoint x="448" y="137"/>
      <waypoint x="294" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_498443_65445" xmi:uuid="90bd6470-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_422411_63084"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_441289_65061"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_493768_65051"/>
      <waypoint x="819" y="567"/>
      <waypoint x="399" y="567"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_876677_65453" xmi:uuid="90bd75a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_803360_63092"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_975417_65081"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_496507_65057"/>
      <waypoint x="518" y="697"/>
      <waypoint x="444" y="697"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_243145_65454" xmi:uuid="90bd8630-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_57929_63094"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_799639_65068"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_636894_65079"/>
      <waypoint x="448" y="207"/>
      <waypoint x="353" y="207"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_854582_65455" xmi:uuid="90bd98b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_298998_63103"/>
      <source xmi:idref="_18_4_1_2b2015d_1617888885413_183612_65064"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_276397_65083"/>
      <waypoint x="819" y="697"/>
      <waypoint x="706" y="697"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885413_985139_65042" xmi:uuid="90bda2b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884023_752700_63112"/>
      <bounds x="1070" y="72" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_434593_65447" xmi:uuid="90bdbbe0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_375338_63086"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980592674_914271_65904"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_858070_65048"/>
      <waypoint x="819" y="651"/>
      <waypoint x="161" y="651"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617888885444_94792_65446" xmi:uuid="90bdcd70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888884007_382916_63085"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980592660_747816_65873"/>
      <target xmi:idref="_18_4_1_2b2015d_1617888885413_181412_65045"/>
      <waypoint x="819" y="613"/>
      <waypoint x="161" y="613"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1073" height="813"/>
    <name>RiskRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617982275772_481953_67849" xmi:uuid="90d57a20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617896577119_372619_73340"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617982570776_329344_68118" xmi:uuid="90d63890-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982570770_946067_68114"/>
      <bounds x="788" y="85" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617982295783_966486_67885" xmi:uuid="90e6bc30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982435654_168936_68050"/>
      <ownedElement xmi:id="90e504e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="90e506d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982435654_168936_68050"/>
        <text>risk_view:Risk_perception</text>
      </ownedElement>
      <ownedElement xmi:id="90e6aa60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="90e6aac0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982435654_168936_68050"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="427" y="84" width="183" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617982320244_788970_67989" xmi:uuid="90e6c2f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1617888883152_272616_62831"/>
      <bounds x="336" y="21" width="65" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617982497810_438494_68066" xmi:uuid="910291c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617897731985_428010_73443"/>
      <ownedElement xmi:id="90f43620-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="90f43720-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617897731985_428010_73443"/>
        <text>RiskLevel:PropertyValue</text>
      </ownedElement>
      <ownedElement xmi:id="90f5dab0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="90f5db10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617897731985_428010_73443"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617984190889_663575_69037" xmi:uuid="91028920-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1549636534195_666651_36050"/>
        <ownedElement xmi:id="4a548770-6c45-013d-d609-0800270c66d6" xmi:uuid="4a548810-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1549636534195_666651_36050"/>
          <bounds x="241" y="317" width="169" height="13"/>
          <text>representation : Representation [1]</text>
        </ownedElement>
        <bounds x="223" y="326" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="322" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617982672871_715646_68163" xmi:uuid="91029d40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982674357_86440_68166"/>
      <source xmi:idref="_18_4_1_2b2015d_1617982570776_329344_68118"/>
      <target xmi:idref="_18_4_1_2b2015d_1617982295783_966486_67885"/>
      <waypoint x="788" y="95"/>
      <waypoint x="610" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617983381365_65988_68191" xmi:uuid="9162a100-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617983381359_13106_68189"/>
      <ownedElement xmi:id="911b6040-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="911b61a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617983381359_13106_68189"/>
        <text>level:Risk_level</text>
      </ownedElement>
      <ownedElement xmi:id="911d0f70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="911d0ff0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617983381359_13106_68189"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="4b5f0990-6c45-013d-d609-0800270c66d6" xmi:uuid="4b5f0a30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4b6e3850-6c45-013d-d609-0800270c66d6" xmi:uuid="4b6e3930-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617983451037_801215_68220" xmi:uuid="91465c00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_level-described_element"/>
          <ownedElement xmi:id="91387080-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91387170-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_level-described_element"/>
            <text>described_element:Risk_perception</text>
          </ownedElement>
          <ownedElement xmi:id="91464e00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91464fd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_level-described_element"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="441" y="168" width="237" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617983491978_31811_68255" xmi:uuid="91629550-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_property-name"/>
          <ownedElement xmi:id="91546560-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91546640-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_property-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="91628770-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91628850-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_property-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="441" y="203" width="109" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="427" y="140" width="258" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617983499156_119266_68299" xmi:uuid="9162ac70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617983500249_372553_68302"/>
      <source xmi:idref="_18_4_1_2b2015d_1617983451037_801215_68220"/>
      <target xmi:idref="_18_4_1_2b2015d_1617982295783_966486_67885"/>
      <waypoint x="476" y="168"/>
      <waypoint x="476" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617983611150_338308_68326" xmi:uuid="91d0afc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617983611150_965976_68324"/>
      <ownedElement xmi:id="91718000-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="917180f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617983611150_965976_68324"/>
        <text>attitude:Risk_attitude</text>
      </ownedElement>
      <ownedElement xmi:id="91732450-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="917324b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617983611150_965976_68324"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4f2d7f30-6c45-013d-d609-0800270c66d6" xmi:uuid="4f2d7fc0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4f4d51e0-6c45-013d-d609-0800270c66d6" xmi:uuid="4f4d52d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617983655705_858135_68357" xmi:uuid="91a669d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_attitude-definition"/>
          <ownedElement xmi:id="918e5080-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="918e5170-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_attitude-definition"/>
            <text>definition:Risk_level</text>
          </ownedElement>
          <ownedElement xmi:id="91a65910-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91a65a10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_attitude-definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="441" y="287" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617983655745_962370_68388" xmi:uuid="91d062f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_attitude-used_representation"/>
          <ownedElement xmi:id="91c24cf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91c24e60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_attitude-used_representation"/>
            <text>used_representation:Property_value_representation</text>
          </ownedElement>
          <ownedElement xmi:id="91d05490-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91d05570-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_attitude-used_representation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="441" y="322" width="328" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="427" y="259" width="349" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617984251865_499844_69072" xmi:uuid="91d0ba30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617984254763_320690_69075"/>
      <source xmi:idref="_18_4_1_2b2015d_1617983655705_858135_68357"/>
      <target xmi:idref="_18_4_1_2b2015d_1617983381365_65988_68191"/>
      <waypoint x="480" y="287"/>
      <waypoint x="480" y="238"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617984263200_118491_69095" xmi:uuid="91d0c830-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617984267641_674497_69096"/>
      <source xmi:idref="_18_4_1_2b2015d_1617983655745_962370_68388"/>
      <target xmi:idref="_18_4_1_2b2015d_1617984190889_663575_69037"/>
      <waypoint x="441" y="336"/>
      <waypoint x="238" y="336"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617984539232_743462_69559" xmi:uuid="91d40230-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617984539232_40781_69557"/>
      <ownedElement xmi:id="91d26e00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91d26e70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617984539232_40781_69557"/>
        <text>default:String</text>
      </ownedElement>
      <ownedElement xmi:id="91d3ef20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91d3ef90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617984539232_40781_69557"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="147" y="203" width="183" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617984641629_624286_69601" xmi:uuid="91d40c60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617984643032_672158_69604"/>
      <source xmi:idref="_18_4_1_2b2015d_1617983491978_31811_68255"/>
      <target xmi:idref="_18_4_1_2b2015d_1617984539232_743462_69559"/>
      <waypoint x="441" y="214"/>
      <waypoint x="330" y="214"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="791" height="372"/>
    <name>RiskPerception</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617980032228_284321_65086" xmi:uuid="91d42630-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617896633035_973986_73395"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980135372_797928_65262" xmi:uuid="91d46e80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980135365_173888_65258"/>
      <bounds x="468" y="88" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980067310_466169_65120" xmi:uuid="91e54600-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980088303_53626_65223"/>
      <ownedElement xmi:id="91e389c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91e38ac0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980088303_53626_65223"/>
        <text>risk_view:Risk_consequence</text>
      </ownedElement>
      <ownedElement xmi:id="91e53200-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="91e53270-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980088303_53626_65223"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="91" y="84" width="232" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980077526_42704_65205" xmi:uuid="91e54cb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1617888883152_272616_62831"/>
      <bounds x="294" y="14" width="65" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980228661_533577_65295" xmi:uuid="91e557b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980230892_659590_65298"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980135372_797928_65262"/>
      <target xmi:idref="_18_4_1_2b2015d_1617980067310_466169_65120"/>
      <waypoint x="468" y="95"/>
      <waypoint x="323" y="95"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="471" height="124"/>
    <name>RiskConsequence</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617980842382_981971_66430" xmi:uuid="91e57110-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898760198_472667_73458"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617982134232_188322_67792" xmi:uuid="91e66630-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982134227_514970_67788"/>
      <bounds x="824" y="39" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862755_867277_66565" xmi:uuid="9241f7c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856725_556391_66474"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980862754_563253_66533"/>
      <target xmi:idref="_18_4_1_2b2015d_1617980862754_573202_66539"/>
      <waypoint x="525" y="252"/>
      <waypoint x="373" y="252"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_87430_66525" xmi:uuid="924271b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="92005000-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="920050f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9214c5e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9214c6e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="5f2ac190-6c45-013d-d609-0800270c66d6" xmi:uuid="5f2ac200-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5f3ff680-6c45-013d-d609-0800270c66d6" xmi:uuid="5f3ff740-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_573202_66539" xmi:uuid="9241eb10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="9233f1f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9233f3b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9241dc20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9241dd10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="189" y="245" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="175" y="217" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862755_588735_66566" xmi:uuid="92ab7990-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856726_433991_66475"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980862754_563253_66533"/>
      <target xmi:idref="_18_4_1_2b2015d_1617980862754_18286_66540"/>
      <waypoint x="525" y="329"/>
      <waypoint x="364" y="329"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_48268_66526" xmi:uuid="92abf4f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="92683d90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="92683f80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9281b6b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9281b7a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="627ff020-6c45-013d-d609-0800270c66d6" xmi:uuid="627ff0e0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="6295a670-6c45-013d-d609-0800270c66d6" xmi:uuid="6295a770-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_18286_66540" xmi:uuid="92ab6ef0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="929d44e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="929d45c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="92ab6060-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="92ab6150-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="189" y="322" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="175" y="294" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862755_409415_66567" xmi:uuid="93106a70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856726_892951_66476"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980862754_563253_66533"/>
      <target xmi:idref="_18_4_1_2b2015d_1617980862754_685471_66541"/>
      <waypoint x="525" y="175"/>
      <waypoint x="372" y="175"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_58194_66527" xmi:uuid="9311d540-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="92c5b0c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="92c5b1c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="92d81e10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="92d820f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="66012a40-6c45-013d-d609-0800270c66d6" xmi:uuid="66012ae0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="662a6060-6c45-013d-d609-0800270c66d6" xmi:uuid="662a6180-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_685471_66541" xmi:uuid="93104860-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="92fa6ae0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="92fa6bd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="93102060-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="93102260-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="189" y="168" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="175" y="140" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862755_47162_66568" xmi:uuid="936c0ed0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856727_652051_66477"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980862754_563253_66533"/>
      <target xmi:idref="_18_4_1_2b2015d_1617980862754_605177_66542"/>
      <waypoint x="525" y="413"/>
      <waypoint x="417" y="413"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_14445_66528" xmi:uuid="936c8990-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="93336f00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="933370f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="9341ee00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9341eef0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="69552280-6c45-013d-d609-0800270c66d6" xmi:uuid="69552330-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="695656f0-6c45-013d-d609-0800270c66d6" xmi:uuid="69565790-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_605177_66542" xmi:uuid="936c0300-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="935ded60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="935dee50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="936bf400-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="936bf4f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="189" y="406" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="175" y="371" width="308" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_555174_66529" xmi:uuid="93a213f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="93857db0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="93857e90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_830516_66543" xmi:uuid="93a20a80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="6ca82bf0-6c45-013d-d609-0800270c66d6" xmi:uuid="6ca82c90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="430" y="458" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="412" y="467" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="140" y="455" width="287" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_119434_66530" xmi:uuid="93e38a20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="93c70fc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="93c71170-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_6732_66545" xmi:uuid="93e371e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="6e93aa80-6c45-013d-d609-0800270c66d6" xmi:uuid="6e93ab10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="332" y="90" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="314" y="99" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="161" y="84" width="168" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862755_159859_66569" xmi:uuid="94484b10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856727_955707_66478"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980862754_563253_66533"/>
      <target xmi:idref="_18_4_1_2b2015d_1617980862754_636843_66547"/>
      <waypoint x="525" y="697"/>
      <waypoint x="373" y="697"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_698890_66531" xmi:uuid="9449b5c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="94031640-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="94031730-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="940f9cc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="940f9da0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="704b5b90-6c45-013d-d609-0800270c66d6" xmi:uuid="704b5c30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7060bed0-6c45-013d-d609-0800270c66d6" xmi:uuid="7060bfb0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_636843_66547" xmi:uuid="94482850-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="94302610-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="94302700-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="94480060-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="94480260-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="189" y="686" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="175" y="658" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_22848_66532" xmi:uuid="94886080-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="9463e330-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9463e420-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_181410_66548" xmi:uuid="94885790-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="73dcffc0-6c45-013d-d609-0800270c66d6" xmi:uuid="73dd0070-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="367" y="602" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="349" y="611" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="147" y="602" width="217" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_563253_66533" xmi:uuid="956638e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856722_211527_66472"/>
      <ownedElement xmi:id="949748c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="949749b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856722_211527_66472"/>
        <text>related_consequence_:Related_consequence</text>
      </ownedElement>
      <ownedElement xmi:id="949901d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="94990240-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980856722_211527_66472"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="74ecb1f0-6c45-013d-d609-0800270c66d6" xmi:uuid="74ecb4e0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="74ee35f0-6c45-013d-d609-0800270c66d6" xmi:uuid="74ee36b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_630743_66551" xmi:uuid="94b50320-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
          <ownedElement xmi:id="94a70170-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="94a70250-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="94b4f4f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="94b4f5d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="546" y="462" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_31117_66552" xmi:uuid="94d8c0d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
          <ownedElement xmi:id="94caa650-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="94caa740-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="94d8b260-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="94d8b350-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="539" y="91" width="100" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_891712_66556" xmi:uuid="95028140-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
          <ownedElement xmi:id="94eacf90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="94ead080-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="95026a10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="95026b50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="546" y="609" width="162" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617981119491_71892_67414" xmi:uuid="953759b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Related_consequence-related_view"/>
          <ownedElement xmi:id="9525cf70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9525d0a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Related_consequence-related_view"/>
            <text>related_view:Risk_consequence</text>
          </ownedElement>
          <ownedElement xmi:id="953747f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="95374b30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Related_consequence-related_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="518" width="215" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617981119504_848678_67445" xmi:uuid="95662920-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Related_consequence-relating_view"/>
          <ownedElement xmi:id="95582ed0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="95582fd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Related_consequence-relating_view"/>
            <text>relating_view:Risk_perception</text>
          </ownedElement>
          <ownedElement xmi:id="95661a90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="95661b70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Related_consequence-relating_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="560" width="203" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="56" width="287" height="672"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617980862754_955685_66534" xmi:uuid="95664080-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="371" y="21" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617981132014_243645_67480" xmi:uuid="956c98c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898835843_57455_73544"/>
      <ownedElement xmi:id="95696640-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="956968a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898835843_57455_73544"/>
        <text>Related:RiskConsequence</text>
      </ownedElement>
      <ownedElement xmi:id="956ae9b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="956aea20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898835843_57455_73544"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617981849704_565992_67561" xmi:uuid="956c8d80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980135365_173888_65258"/>
        <ownedElement xmi:id="7c1396b0-6c45-013d-d609-0800270c66d6" xmi:uuid="7c139760-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980135365_173888_65258"/>
          <bounds x="248" y="513" width="160" height="13"/>
          <text>riskView : Risk_consequence [1]</text>
        </ownedElement>
        <bounds x="230" y="522" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="518" width="196" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617981132019_295810_67511" xmi:uuid="95730340-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898799855_611878_73506"/>
      <ownedElement xmi:id="956f8550-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="956f8710-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898799855_611878_73506"/>
        <text>Relating:RiskPerception</text>
      </ownedElement>
      <ownedElement xmi:id="95710940-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="957109c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617898799855_611878_73506"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617981951942_763449_67629" xmi:uuid="9572fc00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_146274_62958"/>
        <ownedElement xmi:id="7c936d50-6c45-013d-d609-0800270c66d6" xmi:uuid="7c936e20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888883584_146274_62958"/>
          <bounds x="248" y="555" width="185" height="13"/>
          <text>^riskView : Product_view_definition [1]</text>
        </ownedElement>
        <bounds x="230" y="564" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="560" width="196" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617981963632_293929_67656" xmi:uuid="95732b00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617981965534_2785_67657"/>
      <source xmi:idref="_18_4_1_2b2015d_1617981119504_848678_67445"/>
      <target xmi:idref="_18_4_1_2b2015d_1617981951942_763449_67629"/>
      <waypoint x="546" y="571"/>
      <waypoint x="245" y="571"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617981969267_710495_67678" xmi:uuid="95734670-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617981973233_855556_67679"/>
      <source xmi:idref="_18_4_1_2b2015d_1617981119491_71892_67414"/>
      <target xmi:idref="_18_4_1_2b2015d_1617981849704_565992_67561"/>
      <waypoint x="546" y="529"/>
      <waypoint x="245" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617981997929_63237_67704" xmi:uuid="95735000-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982000440_673002_67707"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980862754_31117_66552"/>
      <target xmi:idref="_18_4_1_2b2015d_1617980862754_6732_66545"/>
      <waypoint x="539" y="105"/>
      <waypoint x="329" y="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617982005968_448293_67726" xmi:uuid="95737220-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982007743_978855_67729"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980862754_630743_66551"/>
      <target xmi:idref="_18_4_1_2b2015d_1617980862754_830516_66543"/>
      <waypoint x="546" y="473"/>
      <waypoint x="427" y="473"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617982013586_773993_67750" xmi:uuid="95739420-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982014996_611041_67753"/>
      <source xmi:idref="_18_4_1_2b2015d_1617980862754_891712_66556"/>
      <target xmi:idref="_18_4_1_2b2015d_1617980862754_181410_66548"/>
      <waypoint x="546" y="620"/>
      <waypoint x="364" y="620"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617982181313_105871_67821" xmi:uuid="95739db0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982183383_877790_67824"/>
      <source xmi:idref="_18_4_1_2b2015d_1617982134232_188322_67792"/>
      <target xmi:idref="_18_4_1_2b2015d_1617980862754_563253_66533"/>
      <waypoint x="824" y="46"/>
      <waypoint x="669" y="46"/>
      <waypoint x="669" y="56"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="827" height="743"/>
    <name>RelatedConsequence</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617985064068_959656_69816" xmi:uuid="957402e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064068_761734_69815"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_846460_69991" xmi:uuid="95cdb490-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_216840_69837"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985064137_67907_69978"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_731875_69960"/>
      <waypoint x="553" y="252"/>
      <waypoint x="387" y="252"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_877652_69959" xmi:uuid="95ce3740-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="95977860-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="95977960-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="95a46220-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="95a46300-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="7fb8d9e0-6c45-013d-d609-0800270c66d6" xmi:uuid="7fb8da80-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7fbaa0f0-6c45-013d-d609-0800270c66d6" xmi:uuid="7fbaa1c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_731875_69960" xmi:uuid="95cdaab0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="95bf9680-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="95bf9770-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="95cd9d20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="95cd9e10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="203" y="245" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="189" y="217" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_137089_69992" xmi:uuid="962a3fa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_845530_69838"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985064137_67907_69978"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_480748_69962"/>
      <waypoint x="553" y="329"/>
      <waypoint x="378" y="329"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_990976_69961" xmi:uuid="962ab8a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="95e7fb70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="95e7fc60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="95fc52d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="95fc53c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="82a56430-6c45-013d-d609-0800270c66d6" xmi:uuid="82a56510-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="82c473e0-6c45-013d-d609-0800270c66d6" xmi:uuid="82c47510-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_480748_69962" xmi:uuid="962a3470-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="961c01c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="961c02b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="962a2850-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="962a2940-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="203" y="322" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="189" y="294" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_774494_69993" xmi:uuid="967e3000-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_327603_69839"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985064137_67907_69978"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_891813_69964"/>
      <waypoint x="553" y="175"/>
      <waypoint x="386" y="175"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_770756_69963" xmi:uuid="967ea7d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="96448470-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="96448560-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="96513420-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="96513510-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="85ef7e90-6c45-013d-d609-0800270c66d6" xmi:uuid="85ef7f50-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="86136890-6c45-013d-d609-0800270c66d6" xmi:uuid="86136980-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_891813_69964" xmi:uuid="967e25b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="96702870-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="96702960-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="967e19c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="967e1aa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="203" y="168" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="189" y="140" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_965974_69994" xmi:uuid="96d21b00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_743335_69840"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985064137_67907_69978"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_910130_69966"/>
      <waypoint x="553" y="413"/>
      <waypoint x="431" y="413"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_100113_69965" xmi:uuid="96d29370-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="969c3550-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="969c3640-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="96a8d2f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="96a8d3e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="8922f940-6c45-013d-d609-0800270c66d6" xmi:uuid="8922fa10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="892f5010-6c45-013d-d609-0800270c66d6" xmi:uuid="892f50d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_910130_69966" xmi:uuid="96d21140-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="96c42e00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="96c42ef0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="96d20470-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="96d20560-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="203" y="406" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="189" y="371" width="308" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_113729_69967" xmi:uuid="9704a770-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="96eb7e20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="96eb7f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_470293_69968" xmi:uuid="97049ec0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="8c6b8070-6c45-013d-d609-0800270c66d6" xmi:uuid="8c6b81a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="437" y="458" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="419" y="467" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="175" y="455" width="259" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_828836_69970" xmi:uuid="973f4330-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="971ded70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="971def70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_570242_69971" xmi:uuid="973f3ba0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="8e42db30-6c45-013d-d609-0800270c66d6" xmi:uuid="8e42dc10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="353" y="90" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="335" y="99" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="175" y="84" width="175" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_789932_69995" xmi:uuid="9793fc50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_124425_69841"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985064137_67907_69978"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_10927_69974"/>
      <waypoint x="553" y="690"/>
      <waypoint x="380" y="690"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_706768_69973" xmi:uuid="97952690-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="975926d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="975927c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="976962e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="976963e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="8fe17d40-6c45-013d-d609-0800270c66d6" xmi:uuid="8fe17df0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="8ff36120-6c45-013d-d609-0800270c66d6" xmi:uuid="8ff36200-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_10927_69974" xmi:uuid="9793e2c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="9784cb70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9784cc60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9793c4e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9793c6a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="196" y="679" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="182" y="651" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_793949_69975" xmi:uuid="97d320c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="97b9d750-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="97b9d8f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_378798_69976" xmi:uuid="97d31980-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="93572fc0-6c45-013d-d609-0800270c66d6" xmi:uuid="93573060-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="374" y="595" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="356" y="604" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="168" y="595" width="203" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_67907_69978" xmi:uuid="98ace410-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_807377_69850"/>
      <ownedElement xmi:id="97e1e790-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="97e1e950-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_807377_69850"/>
        <text>causal_consequence_:Causal_consequence</text>
      </ownedElement>
      <ownedElement xmi:id="97e39140-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="97e391b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_807377_69850"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="94026e50-6c45-013d-d609-0800270c66d6" xmi:uuid="94026f20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="9424c860-6c45-013d-d609-0800270c66d6" xmi:uuid="9424c940-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_378649_69979" xmi:uuid="98117130-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
          <ownedElement xmi:id="97f7e330-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="97f7e540-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="981162d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="981163c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="574" y="462" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_819775_69980" xmi:uuid="9830dc30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
          <ownedElement xmi:id="9822f1a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9822f290-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="9830cfc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9830d0b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="567" y="91" width="100" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_333122_69981" xmi:uuid="984d5520-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
          <ownedElement xmi:id="983f4c20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="983f4d10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="984d4920-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="984d4a10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="574" y="602" width="162" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985239986_887808_70746" xmi:uuid="987965d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Causal_consequence-related_view"/>
          <ownedElement xmi:id="98689f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9868a000-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Causal_consequence-related_view"/>
            <text>related_view:Risk_consequence</text>
          </ownedElement>
          <ownedElement xmi:id="98795810-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="98795900-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Causal_consequence-related_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="518" width="215" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985239993_82323_70777" xmi:uuid="98acd6a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Causal_consequence-relating_view"/>
          <ownedElement xmi:id="98962250-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="98962340-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Causal_consequence-relating_view"/>
            <text>relating_view:Risk_consequence</text>
          </ownedElement>
          <ownedElement xmi:id="98acc790-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="98acc890-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Causal_consequence-relating_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="560" width="218" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="553" y="56" width="280" height="665"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_464234_69984" xmi:uuid="98acead0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="378" y="21" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_584512_69985" xmi:uuid="98b504a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_691301_69849"/>
      <ownedElement xmi:id="98b0ba90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="98b0bb30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_691301_69849"/>
        <text>Related:RiskConsequence</text>
      </ownedElement>
      <ownedElement xmi:id="98b29890-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="98b29900-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_691301_69849"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_345145_69986" xmi:uuid="98b4f950-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980135365_173888_65258"/>
        <ownedElement xmi:id="9abc4650-6c45-013d-d609-0800270c66d6" xmi:uuid="9abc46f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980135365_173888_65258"/>
          <bounds x="248" y="513" width="160" height="13"/>
          <text>riskView : Risk_consequence [1]</text>
        </ownedElement>
        <bounds x="230" y="522" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="518" width="196" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_848296_69988" xmi:uuid="98bc4940-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_831757_69848"/>
      <ownedElement xmi:id="98b86ac0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="98b86b20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_831757_69848"/>
        <text>Relating:RiskConsequence</text>
      </ownedElement>
      <ownedElement xmi:id="98ba4840-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="98ba48c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_831757_69848"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_567030_69989" xmi:uuid="98bc3f80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980135365_173888_65258"/>
        <ownedElement xmi:id="9b70df40-6c45-013d-d609-0800270c66d6" xmi:uuid="9b70dfe0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980135365_173888_65258"/>
          <bounds x="248" y="555" width="160" height="13"/>
          <text>riskView : Risk_consequence [1]</text>
        </ownedElement>
        <bounds x="230" y="564" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="560" width="196" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_795572_69998" xmi:uuid="98bc5530-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_381353_69844"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985064137_819775_69980"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_570242_69971"/>
      <waypoint x="567" y="105"/>
      <waypoint x="350" y="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_571804_69999" xmi:uuid="98bc6060-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_224000_69845"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985064137_378649_69979"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_470293_69968"/>
      <waypoint x="574" y="473"/>
      <waypoint x="434" y="473"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_102892_70000" xmi:uuid="98bc6d60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_89874_69846"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985064137_333122_69981"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_378798_69976"/>
      <waypoint x="574" y="613"/>
      <waypoint x="371" y="613"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_708524_70001" xmi:uuid="98bc76e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_665038_69847"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985064137_657139_69957"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_67907_69978"/>
      <waypoint x="860" y="42"/>
      <waypoint x="693" y="42"/>
      <waypoint x="693" y="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985064137_657139_69957" xmi:uuid="98bc7f00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_603087_69851"/>
      <bounds x="860" y="35" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985264595_164399_70821" xmi:uuid="98bc8eb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985266645_58388_70822"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985239986_887808_70746"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_345145_69986"/>
      <waypoint x="574" y="529"/>
      <waypoint x="245" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985270287_672091_70843" xmi:uuid="98bc9a40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985274064_904621_70844"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985239993_82323_70777"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985064137_567030_69989"/>
      <waypoint x="574" y="571"/>
      <waypoint x="245" y="571"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="863" height="736"/>
    <name>CausalConsequence</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1617985594467_349690_71104" xmi:uuid="98bcc2e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594452_714034_71103"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_406059_71279" xmi:uuid="99225bc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_786498_71125"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985594583_840668_71266"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985594583_280047_71248"/>
      <waypoint x="553" y="252"/>
      <waypoint x="380" y="252"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_846332_71247" xmi:uuid="9922d680-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="98e16e70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="98e16f80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="98f54b10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="98f54c00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="9ebce030-6c45-013d-d609-0800270c66d6" xmi:uuid="9ebce0d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="9ecf22b0-6c45-013d-d609-0800270c66d6" xmi:uuid="9ecf23d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_280047_71248" xmi:uuid="99224fc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="99145640-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="99145720-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="992241c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="992242b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="196" y="245" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="182" y="217" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_876247_71280" xmi:uuid="99844920-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_998675_71126"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985594583_840668_71266"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985594583_743414_71250"/>
      <waypoint x="553" y="329"/>
      <waypoint x="371" y="329"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_76460_71249" xmi:uuid="9984d830-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="993ca300-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="993ca3f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="99494c40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="99494d30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a19ef020-6c45-013d-d609-0800270c66d6" xmi:uuid="a19ef0d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a1b104d0-6c45-013d-d609-0800270c66d6" xmi:uuid="a1b10590-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_743414_71250" xmi:uuid="99843bd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="996dd6a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="996dd790-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="99842c10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="99842d20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="196" y="322" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="182" y="294" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_964315_71281" xmi:uuid="99d9d500-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_584396_71127"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985594583_840668_71266"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985594583_267842_71252"/>
      <waypoint x="553" y="175"/>
      <waypoint x="379" y="175"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_535018_71251" xmi:uuid="99da4f80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="999f6d70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="999f6e60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="99abedb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="99abee90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a4a32e20-6c45-013d-d609-0800270c66d6" xmi:uuid="a4a32ec0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a4b98180-6c45-013d-d609-0800270c66d6" xmi:uuid="a4b98260-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_267842_71252" xmi:uuid="99d9c870-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="99c810d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="99c812c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="99d9baa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="99d9bb80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="196" y="168" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="182" y="140" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_335733_71282" xmi:uuid="9a30a4c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_59587_71128"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985594583_840668_71266"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985594583_494132_71254"/>
      <waypoint x="553" y="413"/>
      <waypoint x="424" y="413"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_788240_71253" xmi:uuid="9a312330-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="99f3edb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="99f3eea0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="9a0075d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9a0076b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="a79cd020-6c45-013d-d609-0800270c66d6" xmi:uuid="a79cd0d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a7ad7700-6c45-013d-d609-0800270c66d6" xmi:uuid="a7ad77b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_494132_71254" xmi:uuid="9a309850-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="9a2296d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9a2297c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="9a308a10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9a308b00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="196" y="406" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="182" y="371" width="308" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_781315_71255" xmi:uuid="9a6389a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="9a4a2110-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9a4a2200-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_787037_71256" xmi:uuid="9a638120-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="aaffa260-6c45-013d-d609-0800270c66d6" xmi:uuid="aaffa330-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="430" y="458" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="412" y="467" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="182" y="455" width="245" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_65654_71258" xmi:uuid="9a957e20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="9a7c7c30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9a7c7d20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_963297_71259" xmi:uuid="9a957540-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="ad1acf00-6c45-013d-d609-0800270c66d6" xmi:uuid="ad1ad050-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="413" y="83" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="387" y="99" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="224" y="84" width="178" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_915551_71283" xmi:uuid="9af817c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_864480_71129"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985594583_840668_71266"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985594583_861139_71262"/>
      <waypoint x="553" y="697"/>
      <waypoint x="380" y="697"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_396950_71261" xmi:uuid="9af8b0f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="9ab16e10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9ab16f00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9abdfec0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9abdffa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="aebada40-6c45-013d-d609-0800270c66d6" xmi:uuid="aebadb20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="aec880a0-6c45-013d-d609-0800270c66d6" xmi:uuid="aec881a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_861139_71262" xmi:uuid="9af80880-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="9ae5c110-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9ae5c2d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9af7f6a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9af7f830-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="196" y="686" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="182" y="658" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_549045_71263" xmi:uuid="9b3922c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="9b1daa90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9b1dac90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_406993_71264" xmi:uuid="9b391910-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="b24c9cc0-6c45-013d-d609-0800270c66d6" xmi:uuid="b24c9e50-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="374" y="602" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="356" y="611" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="182" y="602" width="189" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_840668_71266" xmi:uuid="9c0dafc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_597558_71138"/>
      <ownedElement xmi:id="9b491ae0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9b492250-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_597558_71138"/>
        <text>relate:Risk_perception_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="9b4d5150-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9b4d51d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_597558_71138"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="b30a9ac0-6c45-013d-d609-0800270c66d6" xmi:uuid="b30a9b70-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b31cd9b0-6c45-013d-d609-0800270c66d6" xmi:uuid="b31cdad0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_637375_71267" xmi:uuid="9b6a1f90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
          <ownedElement xmi:id="9b5c1aa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9b5c1b80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="9b6a1240-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9b6a1320-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="574" y="462" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_452093_71268" xmi:uuid="9b8d44b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
          <ownedElement xmi:id="9b7b5bb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9b7b5c90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="9b8d3450-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9b8d3560-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="567" y="91" width="100" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_787367_71269" xmi:uuid="9bb253d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
          <ownedElement xmi:id="9b9bc270-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9b9bc350-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="9bb24540-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9bb24620-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="574" y="609" width="162" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985832853_804371_72068" xmi:uuid="9be223a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_relationship-related_view"/>
          <ownedElement xmi:id="9bd30ad0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9bd30c60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_relationship-related_view"/>
            <text>related_view:Risk_perception</text>
          </ownedElement>
          <ownedElement xmi:id="9be20160-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9be20350-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_relationship-related_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="518" width="200" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1617985832869_235773_72099" xmi:uuid="9c0da2d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_relationship-relating_view"/>
          <ownedElement xmi:id="9bffa600-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9bffa6e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_relationship-relating_view"/>
            <text>relating_view:Risk_perception</text>
          </ownedElement>
          <ownedElement xmi:id="9c0d94e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c0d95c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_relationship-relating_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="560" width="203" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="553" y="56" width="280" height="665"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_827054_71272" xmi:uuid="9c0db540-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="371" y="21" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_205465_71273" xmi:uuid="9c1415d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_266050_71137"/>
      <ownedElement xmi:id="9c10d610-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c10d680-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_266050_71137"/>
        <text>Related:RiskPerception</text>
      </ownedElement>
      <ownedElement xmi:id="9c125b30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c125c00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_266050_71137"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985774895_322765_72024" xmi:uuid="9c140ef0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982570770_946067_68114"/>
        <ownedElement xmi:id="b98ead70-6c45-013d-d609-0800270c66d6" xmi:uuid="b98eae20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982570770_946067_68114"/>
          <bounds x="234" y="515" width="145" height="13"/>
          <text>riskView : Risk_perception [1]</text>
        </ownedElement>
        <bounds x="216" y="524" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="518" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_385095_71276" xmi:uuid="9c1a2a50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_206695_71136"/>
      <ownedElement xmi:id="9c170fa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c171030-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_206695_71136"/>
        <text>Relating:RiskPerception</text>
      </ownedElement>
      <ownedElement xmi:id="9c188d70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c188dd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_206695_71136"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1617985800381_781193_72042" xmi:uuid="9c1a2380-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982570770_946067_68114"/>
        <ownedElement xmi:id="ba0da980-6c45-013d-d609-0800270c66d6" xmi:uuid="ba0daa30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982570770_946067_68114"/>
          <bounds x="234" y="555" width="145" height="13"/>
          <text>riskView : Risk_perception [1]</text>
        </ownedElement>
        <bounds x="216" y="564" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="560" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_598793_71286" xmi:uuid="9c1a35d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_701413_71132"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985594583_452093_71268"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985594583_963297_71259"/>
      <waypoint x="567" y="105"/>
      <waypoint x="402" y="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_62129_71287" xmi:uuid="9c1a40d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_285259_71133"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985594583_637375_71267"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985594583_787037_71256"/>
      <waypoint x="574" y="473"/>
      <waypoint x="427" y="473"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_85025_71288" xmi:uuid="9c1a4b60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_619625_71134"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985594583_787367_71269"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985594583_406993_71264"/>
      <waypoint x="574" y="620"/>
      <waypoint x="371" y="620"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_842750_71289" xmi:uuid="9c1a5600-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_229571_71135"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985594583_851523_71245"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985594583_840668_71266"/>
      <waypoint x="860" y="46"/>
      <waypoint x="693" y="46"/>
      <waypoint x="693" y="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985594583_851523_71245" xmi:uuid="9c1a5ba0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594501_85658_71139"/>
      <bounds x="860" y="39" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985841005_565507_72141" xmi:uuid="9c1a6ac0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985844373_544867_72142"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985832853_804371_72068"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985774895_322765_72024"/>
      <waypoint x="574" y="532"/>
      <waypoint x="231" y="532"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1617985848681_968226_72163" xmi:uuid="9c1a75c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985850733_289427_72164"/>
      <source xmi:idref="_18_4_1_2b2015d_1617985832869_235773_72099"/>
      <target xmi:idref="_18_4_1_2b2015d_1617985800381_781193_72042"/>
      <waypoint x="574" y="571"/>
      <waypoint x="231" y="571"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="863" height="736"/>
    <name>RiskPerceptionRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446399070_38803_341786" xmi:uuid="9bb73460-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064068_761734_69815"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446399102_295206_341818" xmi:uuid="9c9eb350-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_807377_69850"/>
      <ownedElement xmi:id="9c4f8dd0-6c45-013d-d609-0800270c66d6" xmi:uuid="9c4f8e90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_807377_69850"/>
        <text>causal_consequence_:Causal_consequence</text>
      </ownedElement>
      <ownedElement xmi:id="9c893a90-6c45-013d-d609-0800270c66d6" xmi:uuid="9c893c30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985064093_807377_69850"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="270" height="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400608_651468_341852" xmi:uuid="9cb174d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="608" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400623_410245_341867" xmi:uuid="9cc6d820-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="608" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400638_861099_341882" xmi:uuid="9cdade70-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="608" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400653_373172_341897" xmi:uuid="9cee9f20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="608" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400668_63040_341912" xmi:uuid="9cf659d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="608" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400685_22899_341927" xmi:uuid="9d043080-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="608" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400702_648580_341942" xmi:uuid="9d11d8c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="608" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400718_626910_341957" xmi:uuid="9d25dbd0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="608" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511498_230217_415139" xmi:uuid="9d25ee40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082294004_620994_69636"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400608_651468_341852"/>
      <target xmi:idref="_18_4_1_65b021e_1727446399102_295206_341818"/>
      <waypoint x="608" y="62"/>
      <waypoint x="315" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511499_348126_415142" xmi:uuid="9d2604b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082298135_692445_69650"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400623_410245_341867"/>
      <target xmi:idref="_18_4_1_65b021e_1727446399102_295206_341818"/>
      <waypoint x="608" y="82"/>
      <waypoint x="315" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511499_864214_415145" xmi:uuid="9d260cc0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082289127_426672_69622"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400638_861099_341882"/>
      <target xmi:idref="_18_4_1_65b021e_1727446399102_295206_341818"/>
      <waypoint x="608" y="102"/>
      <waypoint x="315" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511499_625603_415148" xmi:uuid="9d261220-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082285656_335815_69608"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400653_373172_341897"/>
      <target xmi:idref="_18_4_1_65b021e_1727446399102_295206_341818"/>
      <waypoint x="608" y="122"/>
      <waypoint x="315" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511499_88365_415151" xmi:uuid="9d261700-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082301927_897511_69664"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400668_63040_341912"/>
      <target xmi:idref="_18_4_1_65b021e_1727446399102_295206_341818"/>
      <waypoint x="608" y="142"/>
      <waypoint x="315" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511499_484996_415154" xmi:uuid="9d261c30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082305604_191792_69678"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400685_22899_341927"/>
      <target xmi:idref="_18_4_1_65b021e_1727446399102_295206_341818"/>
      <waypoint x="608" y="162"/>
      <waypoint x="315" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511499_948810_415157" xmi:uuid="9d2621c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082309553_975667_69692"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400702_648580_341942"/>
      <target xmi:idref="_18_4_1_65b021e_1727446399102_295206_341818"/>
      <waypoint x="608" y="182"/>
      <waypoint x="315" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511499_722890_415160" xmi:uuid="9d262730-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663082282051_915273_69594"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400718_626910_341957"/>
      <target xmi:idref="_18_4_1_65b021e_1727446399102_295206_341818"/>
      <waypoint x="608" y="202"/>
      <waypoint x="315" y="202"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="611" height="280"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1618412233353_612916_64025" xmi:uuid="9c1a9780-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618411141068_701578_62793"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413485222_860103_68619" xmi:uuid="9c1c1ca0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413485207_337361_68615"/>
      <bounds x="1056" y="674" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_820813_64688" xmi:uuid="9c227050-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_309295_64588"/>
      <ownedElement xmi:id="9c1f3c30-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c1f3cd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_309295_64588"/>
        <text>AssignedRiskSource:RiskPerceptionSourceAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="9c20bbc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c20bc30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_309295_64588"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618413131267_353577_66276" xmi:uuid="9c226750-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
        <ownedElement xmi:id="bcabc1d0-6c45-013d-d609-0800270c66d6" xmi:uuid="bcabc280-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
          <bounds x="437" y="757" width="184" height="13"/>
          <text>rpsi : risk_perception_source_item [1]</text>
        </ownedElement>
        <bounds x="419" y="766" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="763" width="392" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_627229_64689" xmi:uuid="9c7b9170-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
      <ownedElement xmi:id="9c415e40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c416030-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="9c5090f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c5091d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="be1fd530-6c45-013d-d609-0800270c66d6" xmi:uuid="be1fd5f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="be3e7a60-6c45-013d-d609-0800270c66d6" xmi:uuid="be3e7b70-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_824698_64708" xmi:uuid="9c7b84f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="9c6d97b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c6d9a60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="9c7b7680-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c7b7760-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="133" y="420" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="119" y="392" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_492487_64690" xmi:uuid="9cd2f0e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
      <ownedElement xmi:id="9c957ca0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9c957d90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9ca21b20-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9ca21c00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c12a3000-6c45-013d-d609-0800270c66d6" xmi:uuid="c12a3110-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c13828f0-6c45-013d-d609-0800270c66d6" xmi:uuid="c1382d20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_760292_64709" xmi:uuid="9cd2e490-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="9cc20620-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9cc20790-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="9cd2d080-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9cd2d200-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="644" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="616" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_329217_64691" xmi:uuid="9d114550-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
      <ownedElement xmi:id="9cf284e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9cf285e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
        <text>roleSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_989854_64710" xmi:uuid="9d113b60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="c4738d30-6c45-013d-d609-0800270c66d6" xmi:uuid="c4738dd0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="142" y="850" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="132" y="832" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="105" y="798" width="161" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_678989_64692" xmi:uuid="9d691580-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
      <ownedElement xmi:id="9d32efd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9d32f0c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9d3f7f70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9d3f8060-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="c5dc5f10-6c45-013d-d609-0800270c66d6" xmi:uuid="c5dc5ff0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c5f63790-6c45-013d-d609-0800270c66d6" xmi:uuid="c5f63980-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_924181_64712" xmi:uuid="9d690980-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="9d5b1080-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9d5b1190-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9d68fbd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9d68fcc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="1057" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="1029" width="287" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_187896_64693" xmi:uuid="9dc14300-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
      <ownedElement xmi:id="9d82fd90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9d82fe70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9d8fd0d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9d8fd1c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c8c2d5d0-6c45-013d-d609-0800270c66d6" xmi:uuid="c8c2d7e0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c8d4c360-6c45-013d-d609-0800270c66d6" xmi:uuid="c8d4c430-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_341593_64713" xmi:uuid="9dc13690-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="9db2ef10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9db2f000-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9dc12830-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9dc12920-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="280" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="252" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_941220_64694" xmi:uuid="9e2b4530-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
      <ownedElement xmi:id="9deee080-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9deee190-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9dfcd010-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9dfcd170-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="cbc32870-6c45-013d-d609-0800270c66d6" xmi:uuid="cbc32910-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="cbc45d70-6c45-013d-d609-0800270c66d6" xmi:uuid="cbc45e40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_839799_64714" xmi:uuid="9e2b2960-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="9e1d1a50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9e1d1b40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9e2b1da0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9e2b1e90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="357" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="329" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_129824_64695" xmi:uuid="9e931330-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_133924_64589"/>
      <ownedElement xmi:id="9e3a5eb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9e3a5fb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_133924_64589"/>
        <text>sourceAssignment:Risk_perception_source_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9e3e2a40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9e3e2b90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_133924_64589"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="ce10a630-6c45-013d-d609-0800270c66d6" xmi:uuid="ce10a6f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ce1f96d0-6c45-013d-d609-0800270c66d6" xmi:uuid="ce1f97b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412377875_238008_65748" xmi:uuid="9e698790-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_source_assignment-assigned_risk"/>
          <ownedElement xmi:id="9e5b7310-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9e5b7400-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_source_assignment-assigned_risk"/>
            <text>assigned_risk:Risk_perception</text>
          </ownedElement>
          <ownedElement xmi:id="9e697a40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9e697b20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_source_assignment-assigned_risk"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="658" y="728" width="208" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412377886_720438_65779" xmi:uuid="9e9307c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_source_assignment-items"/>
          <ownedElement xmi:id="9e84e660-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9e84e750-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_source_assignment-items"/>
            <text>items:risk_perception_source_item</text>
          </ownedElement>
          <ownedElement xmi:id="9e92f9d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9e92fab0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_perception_source_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="658" y="763" width="245" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="700" width="336" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_807646_64697" xmi:uuid="9e9318a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509987065721_230294_25388"/>
      <bounds x="427" y="28" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_920594_64698" xmi:uuid="9ed6ea20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
      <ownedElement xmi:id="9eba4840-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9eba4930-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_836602_64722" xmi:uuid="9ed6e2e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="d2d9d4b0-6c45-013d-d609-0800270c66d6" xmi:uuid="d2d9d550-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="335" y="124" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="317" y="133" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="140" y="119" width="192" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265023_906954_64748" xmi:uuid="9f671910-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_57501_64604"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_129824_64695"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_467171_64725"/>
      <waypoint x="784" y="700"/>
      <waypoint x="784" y="179"/>
      <waypoint x="596" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_206247_64699" xmi:uuid="9f67f7c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_711485_64591"/>
      <ownedElement xmi:id="9ee8dce0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9ee8dde0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_711485_64591"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9eec1040-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9eec1220-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_711485_64591"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d3a59df0-6c45-013d-d609-0800270c66d6" xmi:uuid="d3a59ee0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d3a6d9a0-6c45-013d-d609-0800270c66d6" xmi:uuid="d3a6da70-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_554004_64724" xmi:uuid="9f0d98b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="9efbb860-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9efbb940-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="9f0d8c10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9f0d8cf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="413" y="133" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_467171_64725" xmi:uuid="9f429ff0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="9f349f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9f34a000-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9f429310-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9f4293f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="168" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_935144_64726" xmi:uuid="9f670c20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="9f5640b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9f5641a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="9f66fee0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9f66ffd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="413" y="203" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="105" width="294" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_334659_64700" xmi:uuid="9f6d7200-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_622133_64592"/>
      <ownedElement xmi:id="9f69f9c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9f69fa20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_622133_64592"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="9f6d37c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9f6d3c40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_622133_64592"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="203" y="203" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_254885_64701" xmi:uuid="9fd33a50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_306950_64593"/>
      <ownedElement xmi:id="9f7e6270-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9f7e6360-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_306950_64593"/>
        <text>smplDescAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9f8009c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9f800b10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_306950_64593"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d8373f30-6c45-013d-d609-0800270c66d6" xmi:uuid="d8373fe0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d8465e40-6c45-013d-d609-0800270c66d6" xmi:uuid="d8465f20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_728613_64727" xmi:uuid="9fa9c100-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="9f9bbd70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9f9bbe60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="9fa9b2b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9fa9b390-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="483" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_681992_64728" xmi:uuid="9fd32e70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="9fc51cc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9fc51db0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="9fd320e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9fd321c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="448" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="420" width="287" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_691261_64702" xmi:uuid="a0056110-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
      <ownedElement xmi:id="9fec2e80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="9fec2f70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_824158_64729" xmi:uuid="a00557c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="dce520e0-6c45-013d-d609-0800270c66d6" xmi:uuid="dce52170-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="192" y="521" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="182" y="503" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="119" y="469" width="220" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_377691_64703" xmi:uuid="a0326570-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_500360_64594"/>
      <ownedElement xmi:id="a0143740-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0143840-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_500360_64594"/>
        <text>descText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="a015ed60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a015edd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_500360_64594"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="dd9e5aa0-6c45-013d-d609-0800270c66d6" xmi:uuid="dd9e5b40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dda64430-6c45-013d-d609-0800270c66d6" xmi:uuid="dda64540-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618412265008_809126_64731" xmi:uuid="a03259a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="a023ff50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0240060-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="a0324b60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0324c40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="231" y="567" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="217" y="539" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265023_573980_64734" xmi:uuid="a03270f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_296411_64595"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_760292_64709"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_129824_64695"/>
      <waypoint x="588" y="655"/>
      <waypoint x="784" y="655"/>
      <waypoint x="784" y="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265023_105007_64735" xmi:uuid="a0327c60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_909202_64596"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_924181_64712"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_129824_64695"/>
      <waypoint x="597" y="1075"/>
      <waypoint x="784" y="1075"/>
      <waypoint x="784" y="798"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265023_211503_64736" xmi:uuid="a03287a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_321796_64597"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_341593_64713"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_129824_64695"/>
      <waypoint x="596" y="291"/>
      <waypoint x="784" y="291"/>
      <waypoint x="784" y="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265023_925081_64737" xmi:uuid="a0329340-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_730607_64598"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_839799_64714"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_129824_64695"/>
      <waypoint x="597" y="368"/>
      <waypoint x="784" y="368"/>
      <waypoint x="784" y="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265023_407454_64742" xmi:uuid="a0329c50-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_734768_64600"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_935144_64726"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_334659_64700"/>
      <waypoint x="413" y="214"/>
      <waypoint x="337" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265023_961710_64745" xmi:uuid="a032a6e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_530460_64601"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_824698_64708"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_377691_64703"/>
      <waypoint x="354" y="445"/>
      <waypoint x="354" y="539"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265023_367962_64746" xmi:uuid="a032b180-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_861703_64602"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_728613_64727"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_377691_64703"/>
      <waypoint x="469" y="508"/>
      <waypoint x="469" y="574"/>
      <waypoint x="404" y="574"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412265023_71527_64747" xmi:uuid="a032bca0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_550508_64603"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_681992_64728"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_129824_64695"/>
      <waypoint x="588" y="459"/>
      <waypoint x="784" y="459"/>
      <waypoint x="784" y="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412874567_738689_66170" xmi:uuid="a038f650-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412874567_526165_66168"/>
      <ownedElement xmi:id="a035db10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a035dba0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412874567_526165_66168"/>
        <text>AssignedTo:RiskPerception</text>
      </ownedElement>
      <ownedElement xmi:id="a0375770-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a03757d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412874567_526165_66168"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618412942393_306530_66196" xmi:uuid="a038ee00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982570770_946067_68114"/>
        <ownedElement xmi:id="df0ded80-6c45-013d-d609-0800270c66d6" xmi:uuid="df0dee80-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982570770_946067_68114"/>
          <bounds x="248" y="723" width="145" height="13"/>
          <text>riskView : Risk_perception [1]</text>
        </ownedElement>
        <bounds x="230" y="732" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="728" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412969188_879073_66215" xmi:uuid="a038ffa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412971512_843445_66216"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412377875_238008_65748"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412942393_306530_66196"/>
      <waypoint x="658" y="739"/>
      <waypoint x="245" y="739"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412985516_942006_66235" xmi:uuid="a0390ae0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412987383_540096_66236"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_809126_64731"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_824158_64729"/>
      <waypoint x="231" y="578"/>
      <waypoint x="189" y="578"/>
      <waypoint x="189" y="518"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618412993148_358150_66255" xmi:uuid="a03915a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412994991_926185_66256"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412265008_554004_64724"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_836602_64722"/>
      <waypoint x="413" y="140"/>
      <waypoint x="332" y="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413143599_897907_66295" xmi:uuid="a03920f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413145231_614591_66296"/>
      <source xmi:idref="_18_4_1_2b2015d_1618412377886_720438_65779"/>
      <target xmi:idref="_18_4_1_2b2015d_1618413131267_353577_66276"/>
      <waypoint x="658" y="774"/>
      <waypoint x="434" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413285067_821673_68288" xmi:uuid="a0c24c90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277435_599043_68261"/>
      <ownedElement xmi:id="a047f6f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a047f7f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277435_599043_68261"/>
        <text>simpleRoleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a0499f60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0499fd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277435_599043_68261"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="dff850f0-6c45-013d-d609-0800270c66d6" xmi:uuid="dff851a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e0078940-6c45-013d-d609-0800270c66d6" xmi:uuid="e0078a20-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618413285067_345820_68291" xmi:uuid="a072db00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="a064ba50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a064bb40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="a072cd00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a072cde0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="903" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618413285067_978312_68292" xmi:uuid="a0a676b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="a094c610-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a094c720-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="a0a668c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0a669b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="938" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618413285067_886340_68293" xmi:uuid="a0c24010-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="a0b46230-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0b46310-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="a0c231d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0c23510-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="413" y="973" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="875" width="288" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413285067_407866_68289" xmi:uuid="a0c583b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277436_635396_68262"/>
      <ownedElement xmi:id="a0c3f460-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0c3f6d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277436_635396_68262"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="a0c572d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0c57330-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277436_635396_68262"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="182" y="973" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413285067_192352_68290" xmi:uuid="a120e7b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277436_617062_68263"/>
      <ownedElement xmi:id="a0d85c10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0d85d30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277436_617062_68263"/>
        <text>simpleRole:Class</text>
      </ownedElement>
      <ownedElement xmi:id="a0da6d80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0da6f00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277436_617062_68263"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="e49b6a20-6c45-013d-d609-0800270c66d6" xmi:uuid="e49b6ae0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e4bf3b20-6c45-013d-d609-0800270c66d6" xmi:uuid="e4bf3c40-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618413285067_241338_68294" xmi:uuid="a0fe1860-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="a0ed3b70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0ed3c60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="a0fe01d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a0fe0310-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="245" y="896" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618413285067_810596_68295" xmi:uuid="a120d990-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="a10fd2b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a10fd390-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="a120cab0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a120cb90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="223" y="931" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="182" y="868" width="156" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413285067_544138_68296" xmi:uuid="a120f400-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277436_4831_68264"/>
      <source xmi:idref="_18_4_1_2b2015d_1618413285067_886340_68293"/>
      <target xmi:idref="_18_4_1_2b2015d_1618413285067_407866_68289"/>
      <waypoint x="413" y="984"/>
      <waypoint x="344" y="984"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413285083_548464_68297" xmi:uuid="a120ff60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413277436_909551_68265"/>
      <source xmi:idref="_18_4_1_2b2015d_1618413285067_345820_68291"/>
      <target xmi:idref="_18_4_1_2b2015d_1618413285067_192352_68290"/>
      <waypoint x="413" y="914"/>
      <waypoint x="338" y="914"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413408991_409094_68558" xmi:uuid="a1210ba0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413411245_346198_68559"/>
      <source xmi:idref="_18_4_1_2b2015d_1618413285067_241338_68294"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_989854_64710"/>
      <waypoint x="245" y="907"/>
      <waypoint x="140" y="907"/>
      <waypoint x="140" y="847"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413415401_318564_68578" xmi:uuid="a1211720-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413417910_708443_68579"/>
      <source xmi:idref="_18_4_1_2b2015d_1618413285067_810596_68295"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_989854_64710"/>
      <waypoint x="223" y="942"/>
      <waypoint x="140" y="942"/>
      <waypoint x="140" y="847"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413442741_279353_68598" xmi:uuid="a1212300-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413444449_646996_68599"/>
      <source xmi:idref="_18_4_1_2b2015d_1618413285067_978312_68292"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_129824_64695"/>
      <waypoint x="597" y="949"/>
      <waypoint x="784" y="949"/>
      <waypoint x="784" y="798"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618413527638_447178_68642" xmi:uuid="a1212f10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618413529301_850205_68643"/>
      <source xmi:idref="_18_4_1_2b2015d_1618413485222_860103_68619"/>
      <target xmi:idref="_18_4_1_2b2015d_1618412265008_129824_64695"/>
      <waypoint x="1056" y="683"/>
      <waypoint x="893" y="683"/>
      <waypoint x="893" y="700"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1059" height="1107"/>
    <name>RiskPerceptionSourceAssignment</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1618414083897_197346_68708" xmi:uuid="a1217230-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083897_902466_68707"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_883974_68943" xmi:uuid="a12c4490-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_4701_68749"/>
      <ownedElement xmi:id="a128cb10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a128cc20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_4701_68749"/>
        <text>AssignedRiskImpact:RiskImpactAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="a12a8be0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a12a8d00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_4701_68749"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618414461269_536694_70367" xmi:uuid="a12c3b90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
        <ownedElement xmi:id="e8b4afc0-6c45-013d-d609-0800270c66d6" xmi:uuid="e8b4b070-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
          <bounds x="374" y="758" width="115" height="13"/>
          <text>rii : risk_impact_item [1]</text>
        </ownedElement>
        <bounds x="356" y="767" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="763" width="329" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_907522_68946" xmi:uuid="a1815f60-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
      <ownedElement xmi:id="a14b1df0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a14b1ee0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="a157b420-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a157b510-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="e9e21970-6c45-013d-d609-0800270c66d6" xmi:uuid="e9e21a10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e9f29510-6c45-013d-d609-0800270c66d6" xmi:uuid="e9f295f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_100573_68947" xmi:uuid="a18152a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="a172eb90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a172ecf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="a180e7f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a180e900-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="133" y="420" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="119" y="392" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_723530_68948" xmi:uuid="a1db7710-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
      <ownedElement xmi:id="a19d66e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a19d67c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a1ade240-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a1ade330-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="eca76000-6c45-013d-d609-0800270c66d6" xmi:uuid="eca76140-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ecad6370-6c45-013d-d609-0800270c66d6" xmi:uuid="ecad6490-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_138833_68949" xmi:uuid="a1db6cf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="a1cd7090-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a1cd7170-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="a1db5e80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a1db5f70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="644" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="616" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_525928_68950" xmi:uuid="a20fb640-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
      <ownedElement xmi:id="a1f459e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a1f45ad0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
        <text>roleSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_523877_68951" xmi:uuid="a20fada0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="efd8abc0-6c45-013d-d609-0800270c66d6" xmi:uuid="efd8ace0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="128" y="850" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="118" y="832" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="91" y="798" width="175" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_174470_68953" xmi:uuid="a2729a20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
      <ownedElement xmi:id="a22972a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a2297390-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a235fd50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a235fe40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f139abe0-6c45-013d-d609-0800270c66d6" xmi:uuid="f139ac90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f13ad070-6c45-013d-d609-0800270c66d6" xmi:uuid="f13ad140-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_178313_68954" xmi:uuid="a27278a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="a2594200-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a25942f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="a27251b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a27253a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="1057" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="1029" width="287" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_953865_68955" xmi:uuid="a2c78630-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
      <ownedElement xmi:id="a2916560-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a2916650-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a29decf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a29dede0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="f3fe00f0-6c45-013d-d609-0800270c66d6" xmi:uuid="f3fe01a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f40e8650-6c45-013d-d609-0800270c66d6" xmi:uuid="f40e8710-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_732644_68956" xmi:uuid="a2c77ae0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="a2b94ed0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a2b94fc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="a2c76c90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a2c76d80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="280" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="252" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_698638_68957" xmi:uuid="a3299af0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
      <ownedElement xmi:id="a2e791d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a2e792c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a2fc15e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a2fc16e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="f6ac2dc0-6c45-013d-d609-0800270c66d6" xmi:uuid="f6ac2e70-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f6b679c0-6c45-013d-d609-0800270c66d6" xmi:uuid="f6b67a90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_374474_68958" xmi:uuid="a3298f30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="a317c0d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a317c1b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="a32980f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a32981e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="357" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="329" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_392092_68959" xmi:uuid="a39f2c40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_170959_68750"/>
      <ownedElement xmi:id="a33d96d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a33d98c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_170959_68750"/>
        <text>impactAssignment:Risk_impact_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a33fca60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a33fcae0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_170959_68750"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="f8c57b60-6c45-013d-d609-0800270c66d6" xmi:uuid="f8c57c10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f8d448b0-6c45-013d-d609-0800270c66d6" xmi:uuid="f8d449a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414356242_12473_70273" xmi:uuid="a3725370-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_impact_assignment-assigned_risk_consequence"/>
          <ownedElement xmi:id="a35e7dd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a35e7ec0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_impact_assignment-assigned_risk_consequence"/>
            <text>assigned_risk_consequence:Risk_consequence</text>
          </ownedElement>
          <ownedElement xmi:id="a3724300-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a3724520-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_impact_assignment-assigned_risk_consequence"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="658" y="728" width="304" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414356257_960583_70304" xmi:uuid="a39f2170-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_impact_assignment-items"/>
          <ownedElement xmi:id="a3910dd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a3910eb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_impact_assignment-items"/>
            <text>items:risk_impact_item</text>
          </ownedElement>
          <ownedElement xmi:id="a39f1370-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a39f1520-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_impact_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="658" y="763" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="700" width="322" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_622932_68962" xmi:uuid="a39f3330-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509987065721_230294_25388"/>
      <bounds x="392" y="35" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_743951_68963" xmi:uuid="a3dcc050-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
      <ownedElement xmi:id="a3bec660-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a3bec780-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_57759_68964" xmi:uuid="a3dcb820-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="fd2da010-6c45-013d-d609-0800270c66d6" xmi:uuid="fd2da0d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="335" y="124" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="317" y="133" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="147" y="119" width="185" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_964023_68990" xmi:uuid="a4612f20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_251679_68737"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_392092_68959"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_310600_68968"/>
      <waypoint x="784" y="700"/>
      <waypoint x="784" y="179"/>
      <waypoint x="596" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_749249_68966" xmi:uuid="a461e740-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_446250_68751"/>
      <ownedElement xmi:id="a3eda600-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a3eda6f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_446250_68751"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a3ef4880-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a3ef48e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_446250_68751"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="fdfa4d10-6c45-013d-d609-0800270c66d6" xmi:uuid="fdfa4e10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="fe088ea0-6c45-013d-d609-0800270c66d6" xmi:uuid="fe0892d0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_319625_68967" xmi:uuid="a411f250-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="a403f890-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a403f980-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="a411e530-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a411e620-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="413" y="133" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_310600_68968" xmi:uuid="a444d360-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="a434c400-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a434c4f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="a444c4a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a444c590-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="168" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_912325_68969" xmi:uuid="a46122e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="a4530280-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a4530430-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="a4611480-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a4611570-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="413" y="203" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="105" width="294" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_664625_68970" xmi:uuid="a46523c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_255124_68752"/>
      <ownedElement xmi:id="a4638fe0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a4639050-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_255124_68752"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="a4650f60-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a4650fe0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_255124_68752"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="203" y="203" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_331728_68971" xmi:uuid="a4c8c6e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_136186_68753"/>
      <ownedElement xmi:id="a47482e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a47483e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_136186_68753"/>
        <text>smplDescAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a4763730-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a47637a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_136186_68753"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="021294b0-6c46-013d-d609-0800270c66d6" xmi:uuid="02129560-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0213ae70-6c46-013d-d609-0800270c66d6" xmi:uuid="0213af40-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_48228_68972" xmi:uuid="a49f9020-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="a4917fd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a49180c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="a49f8200-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a49f82e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="483" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_695883_68973" xmi:uuid="a4c8bc90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="a4baadc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a4baaeb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="a4c8aee0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a4c8afd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="448" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="420" width="287" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_11075_68974" xmi:uuid="a50a6510-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
      <ownedElement xmi:id="a4f143e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a4f144d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_479296_68975" xmi:uuid="a50a5c30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="061bd1c0-6c46-013d-d609-0800270c66d6" xmi:uuid="061bd2b0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="178" y="521" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="168" y="503" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="105" y="469" width="234" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_908567_68977" xmi:uuid="a53a30c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_447295_68754"/>
      <ownedElement xmi:id="a51c1670-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a51c1780-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_447295_68754"/>
        <text>descText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="a51e03b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a51e0420-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_447295_68754"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="06c3dd80-6c46-013d-d609-0800270c66d6" xmi:uuid="06c3dff0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="06e066b0-6c46-013d-d609-0800270c66d6" xmi:uuid="06e067a0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_868275_68978" xmi:uuid="a53a2540-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="a52c0450-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a52c0530-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="a53a16e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a53a1a30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="231" y="567" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="217" y="539" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_880587_68979" xmi:uuid="a54106a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_908005_68755"/>
      <ownedElement xmi:id="a53d6350-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a53d6420-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_908005_68755"/>
        <text>AssignedTo:RiskConsequence</text>
      </ownedElement>
      <ownedElement xmi:id="a53f55d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a53f56c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_908005_68755"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618414396255_83163_70335" xmi:uuid="a540fda0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980135365_173888_65258"/>
        <ownedElement xmi:id="082ef8d0-6c46-013d-d609-0800270c66d6" xmi:uuid="082ef980-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617980135365_173888_65258"/>
          <bounds x="269" y="723" width="160" height="13"/>
          <text>riskView : Risk_consequence [1]</text>
        </ownedElement>
        <bounds x="251" y="732" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="728" width="224" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_497205_68982" xmi:uuid="a5cf9d00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_186304_68756"/>
      <ownedElement xmi:id="a54fe5a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a54fe690-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_186304_68756"/>
        <text>simpleRoleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a5518e50-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5518eb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_186304_68756"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="08c333e0-6c46-013d-d609-0800270c66d6" xmi:uuid="08c334c0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="08d5a000-6c46-013d-d609-0800270c66d6" xmi:uuid="08d5a520-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_71280_68983" xmi:uuid="a58a65c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="a5763b00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5763d10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="a58a55a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a58a5840-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="903" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_24024_68984" xmi:uuid="a5b39990-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="a5a5af80-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5a5b080-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="a5b38c00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5b38ce0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="938" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_80561_68985" xmi:uuid="a5cf90c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="a5c196e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5c197c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="a5cf82c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5cf83b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="413" y="973" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="875" width="288" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_917009_68986" xmi:uuid="a5d2d990-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_189509_68757"/>
      <ownedElement xmi:id="a5d14480-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5d144f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_189509_68757"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="a5d2c620-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5d2c6a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_189509_68757"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="182" y="973" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_520016_68987" xmi:uuid="a623d9e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_434161_68758"/>
      <ownedElement xmi:id="a5e8d060-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5e8d160-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_434161_68758"/>
        <text>simpleRole:Class</text>
      </ownedElement>
      <ownedElement xmi:id="a5ea7660-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5ea76c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_434161_68758"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="0d231e40-6c46-013d-d609-0800270c66d6" xmi:uuid="0d231ee0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0d244ff0-6c46-013d-d609-0800270c66d6" xmi:uuid="0d2450d0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_642200_68988" xmi:uuid="a60615b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="a5f85070-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a5f85150-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="a60607e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a60608d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="252" y="896" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_919202_68989" xmi:uuid="a623cd80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="a613f640-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a613f720-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="a623bfa0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a623c080-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="230" y="931" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="189" y="868" width="149" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_129802_68991" xmi:uuid="a623e5c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083913_549906_68729"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_138833_68949"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_392092_68959"/>
      <waypoint x="588" y="655"/>
      <waypoint x="784" y="655"/>
      <waypoint x="784" y="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_26184_68992" xmi:uuid="a623f1c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083913_462812_68730"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_178313_68954"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_392092_68959"/>
      <waypoint x="597" y="1075"/>
      <waypoint x="784" y="1075"/>
      <waypoint x="784" y="798"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_120025_68993" xmi:uuid="a623fd70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083913_718142_68731"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_732644_68956"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_392092_68959"/>
      <waypoint x="596" y="291"/>
      <waypoint x="784" y="291"/>
      <waypoint x="784" y="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_365724_68994" xmi:uuid="a62408e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083913_670930_68732"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_374474_68958"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_392092_68959"/>
      <waypoint x="597" y="368"/>
      <waypoint x="784" y="368"/>
      <waypoint x="784" y="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_491678_68995" xmi:uuid="a6241410-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083913_858271_68733"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_912325_68969"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_664625_68970"/>
      <waypoint x="413" y="214"/>
      <waypoint x="337" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_447431_68996" xmi:uuid="a6241fe0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083913_48174_68734"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_100573_68947"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_908567_68977"/>
      <waypoint x="354" y="445"/>
      <waypoint x="354" y="539"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_73407_68997" xmi:uuid="a6242b20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083913_925487_68735"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_48228_68972"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_908567_68977"/>
      <waypoint x="469" y="508"/>
      <waypoint x="469" y="574"/>
      <waypoint x="404" y="574"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_277373_68998" xmi:uuid="a62436d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_923582_68736"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_695883_68973"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_392092_68959"/>
      <waypoint x="588" y="459"/>
      <waypoint x="784" y="459"/>
      <waypoint x="784" y="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_287619_69000" xmi:uuid="a62441d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_439349_68739"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_868275_68978"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_479296_68975"/>
      <waypoint x="231" y="578"/>
      <waypoint x="175" y="578"/>
      <waypoint x="175" y="518"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_252187_69001" xmi:uuid="a6244c80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_277199_68740"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_319625_68967"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_57759_68964"/>
      <waypoint x="413" y="140"/>
      <waypoint x="332" y="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_688130_69003" xmi:uuid="a62457c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_29990_68742"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_80561_68985"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_917009_68986"/>
      <waypoint x="413" y="984"/>
      <waypoint x="344" y="984"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_316405_69004" xmi:uuid="a6246360-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_140952_68743"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_71280_68983"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_520016_68987"/>
      <waypoint x="413" y="914"/>
      <waypoint x="338" y="914"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_609385_69005" xmi:uuid="a6246fb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_940206_68744"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_642200_68988"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_523877_68951"/>
      <waypoint x="252" y="907"/>
      <waypoint x="126" y="907"/>
      <waypoint x="126" y="847"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_979404_69006" xmi:uuid="a6247be0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_629171_68745"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_919202_68989"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_523877_68951"/>
      <waypoint x="230" y="942"/>
      <waypoint x="126" y="942"/>
      <waypoint x="126" y="847"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_173097_69007" xmi:uuid="a62487a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_712749_68746"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_24024_68984"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_392092_68959"/>
      <waypoint x="597" y="949"/>
      <waypoint x="784" y="949"/>
      <waypoint x="784" y="798"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_970647_69008" xmi:uuid="a624f040-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_294955_68747"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414084029_496973_68941"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414084029_392092_68959"/>
      <waypoint x="1000" y="683"/>
      <waypoint x="875" y="683"/>
      <waypoint x="875" y="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414084029_496973_68941" xmi:uuid="a624f7a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414083929_252857_68759"/>
      <bounds x="1000" y="677" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414407770_356561_70354" xmi:uuid="a62506f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414410467_577340_70355"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414356242_12473_70273"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414396255_83163_70335"/>
      <waypoint x="658" y="739"/>
      <waypoint x="266" y="739"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618414471230_32996_70386" xmi:uuid="a6251140-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414472966_898131_70387"/>
      <source xmi:idref="_18_4_1_2b2015d_1618414356257_960583_70304"/>
      <target xmi:idref="_18_4_1_2b2015d_1618414461269_536694_70367"/>
      <waypoint x="658" y="774"/>
      <waypoint x="371" y="774"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1003" height="1108"/>
    <name>RiskImpactAssignment</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1618414979161_306015_70554" xmi:uuid="a62539f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618414876147_13677_70498"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618415261576_840848_70812" xmi:uuid="a62609c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415261576_419616_70808"/>
      <bounds x="1041" y="98" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618415015541_529700_70586" xmi:uuid="a62c6df0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415057756_509501_70717"/>
      <ownedElement xmi:id="a62949b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a6294a40-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415057756_509501_70717"/>
        <text>AssignedTo:RiskPerception</text>
      </ownedElement>
      <ownedElement xmi:id="a62ac710-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a62ac770-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415057756_509501_70717"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1618415222670_335395_70766" xmi:uuid="a62c6550-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982570770_946067_68114"/>
        <ownedElement xmi:id="1156b840-6c46-013d-d609-0800270c66d6" xmi:uuid="1156b900-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617982570770_946067_68114"/>
          <bounds x="248" y="121" width="145" height="13"/>
          <text>riskView : Risk_perception [1]</text>
        </ownedElement>
        <bounds x="230" y="130" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="126" width="210" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618415015542_764267_70617" xmi:uuid="a6aa0890-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415099089_958755_70727"/>
      <ownedElement xmi:id="a63e7200-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a63e7410-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415099089_958755_70727"/>
        <text>activityMethodAsgn:Risk_event</text>
      </ownedElement>
      <ownedElement xmi:id="a64331c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a6433320-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415099089_958755_70727"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="11ff2ab0-6c46-013d-d609-0800270c66d6" xmi:uuid="11ff2b60-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="121ab3a0-6c46-013d-d609-0800270c66d6" xmi:uuid="121ab480-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1618415200984_82769_70735" xmi:uuid="a67820d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_event-items"/>
          <ownedElement xmi:id="a66526a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a66527a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_event-items"/>
            <text>items:Risk_perception</text>
          </ownedElement>
          <ownedElement xmi:id="a67811c0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a67812b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_event-items"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="511" y="126" width="161" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1620122808603_610083_66468" xmi:uuid="a6a9fcc0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-assigned_activity_method"/>
          <ownedElement xmi:id="a69bddd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a69bdec0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-assigned_activity_method"/>
            <text>assigned_activity_method:Activity_method</text>
          </ownedElement>
          <ownedElement xmi:id="a6a9edf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a6a9eee0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_method_assignment-assigned_activity_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="511" y="161" width="278" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="98" width="299" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618415035203_54775_70705" xmi:uuid="a6aa0fe0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1517600115205_566409_41449"/>
      <bounds x="294" y="28" width="163" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618415237055_368924_70788" xmi:uuid="a6aa1b70-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415238515_12729_70789"/>
      <source xmi:idref="_18_4_1_2b2015d_1618415200984_82769_70735"/>
      <target xmi:idref="_18_4_1_2b2015d_1618415222670_335395_70766"/>
      <waypoint x="511" y="137"/>
      <waypoint x="245" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618415326001_395339_70835" xmi:uuid="a6aa2690-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618415327004_683421_70836"/>
      <source xmi:idref="_18_4_1_2b2015d_1618415261576_840848_70812"/>
      <target xmi:idref="_18_4_1_2b2015d_1618415015542_764267_70617"/>
      <waypoint x="1041" y="105"/>
      <waypoint x="796" y="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1618563274736_647555_62791" xmi:uuid="a6b309b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../Activity/Activity.xmi#_2_attr_ActivityMethodAssignment-AssignedActivityMethod"/>
      <ownedElement xmi:id="a6afec00-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a6afecd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../Activity/Activity.xmi#_2_attr_ActivityMethodAssignment-AssignedActivityMethod"/>
        <text>AssignedActivityMethod:ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="a6b160d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a6b16140-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../Activity/Activity.xmi#_2_attr_ActivityMethodAssignment-AssignedActivityMethod"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1620122834718_47535_66504" xmi:uuid="a6b30060-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLShape">
        <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1502208068868_300862_23993"/>
        <ownedElement xmi:id="14f4d540-6c46-013d-d609-0800270c66d6" xmi:uuid="14f4d610-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1502208068868_300862_23993"/>
          <bounds x="318" y="155" width="138" height="13"/>
          <text>method : Activity_method [1]</text>
        </ownedElement>
        <bounds x="300" y="164" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="161" width="280" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620122834717_506266_66501" xmi:uuid="a6bbf530-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600577248_426940_42617"/>
      <source xmi:idref="_18_4_1_2b2015d_1620122808603_610083_66468"/>
      <target xmi:idref="_18_4_1_2b2015d_1620122834718_47535_66504"/>
      <waypoint x="511" y="172"/>
      <waypoint x="315" y="172"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620122917787_44185_66521" xmi:uuid="a7507970-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620122917782_721646_66519"/>
      <ownedElement xmi:id="a6d3c730-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a6d3c830-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620122917782_721646_66519"/>
        <text>probabilityRep:Probability_representation</text>
      </ownedElement>
      <ownedElement xmi:id="a6d7d980-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a6d7db30-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620122917782_721646_66519"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="15a1fb20-6c46-013d-d609-0800270c66d6" xmi:uuid="15a1fc60-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="15ae5a80-6c46-013d-d609-0800270c66d6" xmi:uuid="15ae5b60-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1620122976273_722881_66548" xmi:uuid="a706a990-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_representation-property"/>
          <ownedElement xmi:id="a6f7ed70-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a6f7eec0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_representation-property"/>
            <text>property:Risk_event_probability</text>
          </ownedElement>
          <ownedElement xmi:id="a7069bf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a7069cd0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_representation-property"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="763" y="315" width="212" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1620122976281_48846_66579" xmi:uuid="a733b470-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_representation-rep"/>
          <ownedElement xmi:id="a725a2d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a725a3b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_representation-rep"/>
            <text>rep:Probability</text>
          </ownedElement>
          <ownedElement xmi:id="a733a660-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a733a750-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_representation-rep"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="763" y="385" width="116" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1620122976297_635458_66610" xmi:uuid="a7506f00-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_property_representation-role"/>
          <ownedElement xmi:id="a741db10-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a741dbf0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_property_representation-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="a74ffd90-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a74ffeb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_property_representation-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="763" y="350" width="100" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="749" y="287" width="275" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620123047670_889514_66646" xmi:uuid="a7edc010-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123047667_221254_66644"/>
      <ownedElement xmi:id="a7657860-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a7657950-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123047667_221254_66644"/>
        <text>eventProbability:Risk_event_probability</text>
      </ownedElement>
      <ownedElement xmi:id="a7671f40-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a7671fb0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123047667_221254_66644"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="199e7ab0-6c46-013d-d609-0800270c66d6" xmi:uuid="199e7ba0-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="19b0fb50-6c46-013d-d609-0800270c66d6" xmi:uuid="19b0fc20-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1620123100877_691907_66673" xmi:uuid="a7a17210-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_event_probability-described_element"/>
          <ownedElement xmi:id="a78cf0d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a78cf1e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_event_probability-described_element"/>
            <text>described_element:Activity_method</text>
          </ownedElement>
          <ownedElement xmi:id="a7a16590-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a7a16670-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Risk_event_probability-described_element"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="448" y="238" width="236" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1620123100889_902505_66704" xmi:uuid="a7c50e80-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_property-description"/>
          <ownedElement xmi:id="a7b1e4b0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a7b1e590-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_property-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="a7c500a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a7c501a0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_property-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="448" y="273" width="141" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1620123100901_988490_66735" xmi:uuid="a7edb230-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_property-name"/>
          <ownedElement xmi:id="a7d71080-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a7d71170-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_property-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="a7eda340-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a7eda440-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_property-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="448" y="308" width="109" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="434" y="210" width="265" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620123179660_861236_66777" xmi:uuid="a7edcd20-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123182761_504108_66778"/>
      <source xmi:idref="_18_4_1_2b2015d_1620122976273_722881_66548"/>
      <target xmi:idref="_18_4_1_2b2015d_1620123047670_889514_66646"/>
      <waypoint x="763" y="326"/>
      <waypoint x="699" y="326"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620123209108_72300_66794" xmi:uuid="a7edd9f0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123212985_965893_66795"/>
      <source xmi:idref="_18_4_1_2b2015d_1620122976281_48846_66579"/>
      <target xmi:idref="_18_4_1_2b2015d_1643106560582_640300_66938"/>
      <waypoint x="763" y="396"/>
      <waypoint x="245" y="396"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620123226552_565351_66814" xmi:uuid="a7ede6d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123230226_28046_66815"/>
      <source xmi:idref="_18_4_1_2b2015d_1620123100877_691907_66673"/>
      <target xmi:idref="_18_4_1_2b2015d_1620122834718_47535_66504"/>
      <waypoint x="448" y="249"/>
      <waypoint x="350" y="249"/>
      <waypoint x="350" y="172"/>
      <waypoint x="315" y="172"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620123315600_994815_66832" xmi:uuid="a7f1a460-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123315597_678593_66830"/>
      <ownedElement xmi:id="a7efd040-8fe0-0139-a9e0-78b156d8ad1a" xmi:uuid="a7efd0d0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123315597_678593_66830"/>
        <text>default:String</text>
      </ownedElement>
      <ownedElement xmi:id="1da09810-339c-013a-17e3-45cc4a55db9f" xmi:uuid="1da099d0-339c-013a-17e3-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123315597_678593_66830"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="175" y="266" width="171" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620123384549_25059_66864" xmi:uuid="a7f1af90-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123385501_553584_66865"/>
      <source xmi:idref="_18_4_1_2b2015d_1620123100889_902505_66704"/>
      <target xmi:idref="_18_4_1_2b2015d_1620123315600_994815_66832"/>
      <waypoint x="448" y="277"/>
      <waypoint x="346" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620123388411_384034_66881" xmi:uuid="a7f1bb10-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123390778_125367_66882"/>
      <source xmi:idref="_18_4_1_2b2015d_1620123100901_988490_66735"/>
      <target xmi:idref="_18_4_1_2b2015d_1620123315600_994815_66832"/>
      <waypoint x="448" y="319"/>
      <waypoint x="385" y="319"/>
      <waypoint x="385" y="277"/>
      <waypoint x="346" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620123422968_25423_66898" xmi:uuid="a7f1c6e0-8fe0-0139-a9e0-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1620123425584_362556_66899"/>
      <source xmi:idref="_18_4_1_2b2015d_1620122976297_635458_66610"/>
      <target xmi:idref="_18_4_1_2b2015d_1620123315600_994815_66832"/>
      <waypoint x="763" y="361"/>
      <waypoint x="385" y="361"/>
      <waypoint x="385" y="277"/>
      <waypoint x="346" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1623839320226_294217_69648" xmi:uuid="a38ec5f0-b6f5-0139-1751-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_29c0149_1623839320122_134678_69647"/>
      <ownedElement xmi:id="a35dd060-b6f5-0139-1751-45cc4a55db9f" xmi:uuid="a35dd2c0-b6f5-0139-1751-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_29c0149_1623839320122_134678_69647"/>
        <text>Probability:ProbabilitySelect</text>
      </ownedElement>
      <ownedElement xmi:id="a38e6960-b6f5-0139-1751-45cc4a55db9f" xmi:uuid="a38e6b50-b6f5-0139-1751-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_29c0149_1623839320122_134678_69647"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1643106560582_640300_66938" xmi:uuid="21caa1f0-6af0-013a-da2b-3770a1b6a6fd" xmi:type="umldi:UMLShape">
        <modelElement href="../Probability/Probability.xmi#_18_4_1_2b2015d_1643105767136_904518_66552"/>
        <ownedElement xmi:id="1d53ef80-6c46-013d-d609-0800270c66d6" xmi:uuid="1d53f030-6c46-013d-d609-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Probability/Probability.xmi#_18_4_1_2b2015d_1643105767136_904518_66552"/>
          <bounds x="248" y="381" width="124" height="13"/>
          <text>probability : Probability [1]</text>
        </ownedElement>
        <bounds x="230" y="390" width="15" height="15"/>
      </ownedElement>
      <bounds x="28" y="385" width="210" height="25"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1044" height="437"/>
    <name>RiskEvent</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446400725_16204_341969" xmi:uuid="ba409910-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594452_714034_71103"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400758_895135_342001" xmi:uuid="baf51640-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_597558_71138"/>
      <ownedElement xmi:id="bad60200-6c45-013d-d609-0800270c66d6" xmi:uuid="bad60310-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_597558_71138"/>
        <text>relate:Risk_perception_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="baf4fcb0-6c45-013d-d609-0800270c66d6" xmi:uuid="baf4fdc0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617985594486_597558_71138"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="224" height="350"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400776_963134_342035" xmi:uuid="baf66bf0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="594" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400790_596389_342050" xmi:uuid="baf7a360-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_6b1022a_1570727524445_1920_44551"/>
      <bounds x="594" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400807_691496_342065" xmi:uuid="bb2b4d30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="594" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400817_149403_342080" xmi:uuid="bb2c7db0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="594" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400834_576835_342095" xmi:uuid="bb4b0870-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="594" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400851_682826_342110" xmi:uuid="bb601880-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="594" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400868_745850_342125" xmi:uuid="bb6151a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="594" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400884_363895_342140" xmi:uuid="bb74e2f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="594" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400897_160777_342155" xmi:uuid="bb82cc90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="594" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400908_115464_342170" xmi:uuid="bb903580-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="594" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400918_977768_342185" xmi:uuid="bb9f4ba0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="594" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400937_387222_342200" xmi:uuid="bbacf980-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="594" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400954_274929_342215" xmi:uuid="bbc52be0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="594" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400968_91371_342230" xmi:uuid="bbcf08b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="594" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446400982_156826_342245" xmi:uuid="bbd68aa0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="594" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_792993_415163" xmi:uuid="bbd6a4f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083041893_496292_70872"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400776_963134_342035"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="62"/>
      <waypoint x="269" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_962688_415166" xmi:uuid="bbd6ae90-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083302522_84933_71033"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400790_596389_342050"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="82"/>
      <waypoint x="269" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_319629_415169" xmi:uuid="bbd6b7f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083045068_407144_70886"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400807_691496_342065"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="102"/>
      <waypoint x="269" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_61427_415172" xmi:uuid="bbd6c630-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083309623_493911_71061"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400817_149403_342080"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="122"/>
      <waypoint x="269" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_587411_415175" xmi:uuid="bbd6d2a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083038982_331454_70858"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400834_576835_342095"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="142"/>
      <waypoint x="269" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_987008_415178" xmi:uuid="bbd6e350-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083306300_617924_71047"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400851_682826_342110"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="162"/>
      <waypoint x="269" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_771733_415181" xmi:uuid="bbd6ed30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083035552_927278_70844"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400868_745850_342125"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="182"/>
      <waypoint x="269" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_986274_415184" xmi:uuid="bbd6f390-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083048575_408491_70900"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400884_363895_342140"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="202"/>
      <waypoint x="269" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_509709_415187" xmi:uuid="bbd6fac0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083312858_805712_71075"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400897_160777_342155"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="222"/>
      <waypoint x="269" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_77408_415190" xmi:uuid="bbd70170-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083316335_831681_71089"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400908_115464_342170"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="242"/>
      <waypoint x="269" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_190585_415193" xmi:uuid="bbd709b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083320345_566894_71103"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400918_977768_342185"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="262"/>
      <waypoint x="269" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_227784_415196" xmi:uuid="bbe666a0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083052189_112816_70914"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400937_387222_342200"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="282"/>
      <waypoint x="269" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_637668_415199" xmi:uuid="bbe67060-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083056189_786489_70928"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400954_274929_342215"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="302"/>
      <waypoint x="269" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_275687_415202" xmi:uuid="bbe68750-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083032320_192765_70830"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400968_91371_342230"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="322"/>
      <waypoint x="269" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511503_504892_415205" xmi:uuid="bbe69e50-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083324015_645673_71117"/>
      <source xmi:idref="_18_4_1_65b021e_1727446400982_156826_342245"/>
      <target xmi:idref="_18_4_1_65b021e_1727446400758_895135_342001"/>
      <waypoint x="594" y="342"/>
      <waypoint x="269" y="342"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="597" height="420"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446394087_632249_338917" xmi:uuid="bfbdb0b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394117_593054_338949" xmi:uuid="c0cbe3c0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881520_262126_62602"/>
      <ownedElement xmi:id="c09e6e90-6c44-013d-d609-0800270c66d6" xmi:uuid="c09e6f60-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881520_262126_62602"/>
        <text>risk_:Risk</text>
      </ownedElement>
      <ownedElement xmi:id="c0cbcc10-6c44-013d-d609-0800270c66d6" xmi:uuid="c0cbcce0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881520_262126_62602"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="88" height="770"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394136_617374_338983" xmi:uuid="c0e32f70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="510" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446394146_237720_338998" xmi:uuid="c0e47a70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="510" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395524_723983_339013" xmi:uuid="c0e5b650-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="510" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395534_732658_339028" xmi:uuid="c12444b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="510" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395542_894326_339043" xmi:uuid="c126a8a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="510" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395551_23037_339058" xmi:uuid="c1525470-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="510" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395560_995509_339073" xmi:uuid="c1539b90-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="510" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395575_209031_339088" xmi:uuid="c154df90-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="510" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395586_94618_339103" xmi:uuid="c197ec90-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="510" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395596_632710_339118" xmi:uuid="c1a9f2b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="510" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395610_545493_339133" xmi:uuid="c1ab4a30-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="510" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395625_123526_339148" xmi:uuid="c1c98530-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="510" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395639_976355_339163" xmi:uuid="c1cab920-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="510" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395647_697256_339178" xmi:uuid="c1f299c0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1540915512831_719143_31709"/>
      <bounds x="510" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395661_607206_339193" xmi:uuid="c1f43530-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="510" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395671_955889_339208" xmi:uuid="c21b87a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="510" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395683_728510_339223" xmi:uuid="c23a56d0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="510" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395693_422283_339238" xmi:uuid="c246bda0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="510" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395702_687292_339253" xmi:uuid="c25c1310-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="510" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395711_28939_339268" xmi:uuid="c25d9bf0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="510" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395728_952010_339283" xmi:uuid="c28c9060-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="510" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395743_743274_339298" xmi:uuid="c28dbd50-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="510" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395752_533951_339313" xmi:uuid="c28f0150-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1540916564417_774412_33192"/>
      <bounds x="510" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395767_927559_339328" xmi:uuid="c29024f0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="510" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395776_422790_339343" xmi:uuid="c2d61f70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="510" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395791_122264_339358" xmi:uuid="c2e3db90-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="510" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395803_611638_339373" xmi:uuid="c2f5c720-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="510" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395816_925822_339388" xmi:uuid="c2f70690-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="510" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395826_528516_339403" xmi:uuid="c31fffd0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="510" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395835_987718_339418" xmi:uuid="c3212c50-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="510" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395846_214675_339433" xmi:uuid="c334d350-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="510" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395856_597906_339448" xmi:uuid="c34cf560-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="510" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395868_775547_339463" xmi:uuid="c35f80f0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="510" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395878_253491_339478" xmi:uuid="c391a080-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="510" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395890_528961_339493" xmi:uuid="c3ca52b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="510" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395900_19842_339508" xmi:uuid="c3eedfa0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="510" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_875470_414641" xmi:uuid="c3ef0700-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_927977_62540"/>
      <source xmi:idref="_18_4_1_65b021e_1727446394136_617374_338983"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="62"/>
      <waypoint x="133" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_860903_414644" xmi:uuid="c3ef2360-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_377287_62539"/>
      <source xmi:idref="_18_4_1_65b021e_1727446394146_237720_338998"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="82"/>
      <waypoint x="133" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_510068_414647" xmi:uuid="c3ef3eb0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_977968_62538"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395524_723983_339013"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="102"/>
      <waypoint x="133" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_785380_414650" xmi:uuid="c3ef51b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_518590_62564"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395534_732658_339028"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="122"/>
      <waypoint x="133" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_700697_414653" xmi:uuid="c4005e00-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_542998_62568"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395542_894326_339043"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="142"/>
      <waypoint x="133" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_824666_414656" xmi:uuid="c40072e0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_339683_62541"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395551_23037_339058"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="162"/>
      <waypoint x="133" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_253352_414659" xmi:uuid="c4008970-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_366389_62560"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395560_995509_339073"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="182"/>
      <waypoint x="133" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_339672_414662" xmi:uuid="c400c260-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_621352_62561"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395575_209031_339088"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="202"/>
      <waypoint x="133" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_501415_414665" xmi:uuid="c400f320-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_859664_62542"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395586_94618_339103"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="222"/>
      <waypoint x="133" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_163179_414668" xmi:uuid="c4011990-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_932307_62543"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395596_632710_339118"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="242"/>
      <waypoint x="133" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_751194_414671" xmi:uuid="c4014340-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_956379_62546"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395610_545493_339133"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="262"/>
      <waypoint x="133" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_937246_414674" xmi:uuid="c4015fe0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_423063_62544"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395625_123526_339148"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="282"/>
      <waypoint x="133" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_941763_414677" xmi:uuid="c4017170-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_872973_62545"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395639_976355_339163"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="302"/>
      <waypoint x="133" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_838713_414680" xmi:uuid="c4019dc0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_66517_62567"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395647_697256_339178"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="322"/>
      <waypoint x="133" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_683111_414683" xmi:uuid="c41bca50-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_380490_62548"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395661_607206_339193"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="342"/>
      <waypoint x="133" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_804006_414686" xmi:uuid="c41be430-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_776832_62558"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395671_955889_339208"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="362"/>
      <waypoint x="133" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_79258_414689" xmi:uuid="c41bf770-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_194939_62550"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395683_728510_339223"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="382"/>
      <waypoint x="133" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_111314_414692" xmi:uuid="c41c1b20-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_421632_62562"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395693_422283_339238"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="402"/>
      <waypoint x="133" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_397645_414695" xmi:uuid="c41c4d60-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_434900_62563"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395702_687292_339253"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="422"/>
      <waypoint x="133" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_415768_414698" xmi:uuid="c41c5cd0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_279734_62565"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395711_28939_339268"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="442"/>
      <waypoint x="133" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_241194_414701" xmi:uuid="c41c6ee0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1662135456140_412527_67927"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395728_952010_339283"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="462"/>
      <waypoint x="133" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_363178_414704" xmi:uuid="c41c80f0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1662135459320_132099_67941"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395743_743274_339298"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="482"/>
      <waypoint x="133" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511420_302514_414707" xmi:uuid="c41c9190-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_430768_62569"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395752_533951_339313"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="502"/>
      <waypoint x="133" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_516422_414710" xmi:uuid="c41cad00-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_273378_62547"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395767_927559_339328"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="522"/>
      <waypoint x="133" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_528014_414713" xmi:uuid="c41cc620-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_366981_62551"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395776_422790_339343"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="542"/>
      <waypoint x="133" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_36125_414716" xmi:uuid="c41cea70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_496642_62552"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395791_122264_339358"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="562"/>
      <waypoint x="133" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_949470_414719" xmi:uuid="c41d0890-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_398914_62553"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395803_611638_339373"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="582"/>
      <waypoint x="133" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_868804_414722" xmi:uuid="c41d19d0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_964706_62554"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395816_925822_339388"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="602"/>
      <waypoint x="133" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_17865_414725" xmi:uuid="c41d4750-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1662135463736_520014_67955"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395826_528516_339403"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="622"/>
      <waypoint x="133" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_850339_414728" xmi:uuid="c42cb680-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1662135469826_740845_67969"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395835_987718_339418"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="642"/>
      <waypoint x="133" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_824108_414731" xmi:uuid="c42cc9f0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_547656_62555"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395846_214675_339433"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="662"/>
      <waypoint x="133" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_354205_414734" xmi:uuid="c42cdce0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_710036_62566"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395856_597906_339448"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="682"/>
      <waypoint x="133" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_548257_414737" xmi:uuid="c42cf0c0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881498_618965_62559"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395868_775547_339463"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="702"/>
      <waypoint x="133" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_860258_414740" xmi:uuid="c42d0320-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_795115_62556"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395878_253491_339478"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="722"/>
      <waypoint x="133" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_136952_414743" xmi:uuid="c42d17a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_919815_62549"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395890_528961_339493"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="742"/>
      <waypoint x="133" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511421_33517_414746" xmi:uuid="c42d2c30-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888881490_806494_62557"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395900_19842_339508"/>
      <target xmi:idref="_18_4_1_65b021e_1727446394117_593054_338949"/>
      <waypoint x="510" y="762"/>
      <waypoint x="133" y="762"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="513" height="840"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446395905_761328_339520" xmi:uuid="e6ca8930-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618411141068_701578_62793"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395932_208452_339552" xmi:uuid="e769ac80-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_133924_64589"/>
      <ownedElement xmi:id="e748b660-6c45-013d-d609-0800270c66d6" xmi:uuid="e748b780-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_133924_64589"/>
        <text>sourceAssignment:Risk_perception_source_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e7699b00-6c45-013d-d609-0800270c66d6" xmi:uuid="e7699be0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1618412260211_133924_64589"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="336" height="270"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395948_592170_339586" xmi:uuid="e77289c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="699" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395963_99293_339601" xmi:uuid="e773e230-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="699" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395978_340460_339616" xmi:uuid="e77582c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="699" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446395991_54684_339631" xmi:uuid="e7a81be0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="699" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396005_184300_339646" xmi:uuid="e7af68b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="699" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396020_930917_339661" xmi:uuid="e7ba2a30-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="699" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396033_467299_339676" xmi:uuid="e7d2dd10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="699" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396049_319651_339691" xmi:uuid="e7ec8900-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="699" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396064_657181_339706" xmi:uuid="e7edb650-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="699" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396077_897611_339721" xmi:uuid="e8018550-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="699" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396090_57483_339736" xmi:uuid="e802b160-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="699" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_971295_414749" xmi:uuid="e802c180-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083433621_133733_71330"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395948_592170_339586"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="62"/>
      <waypoint x="381" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_759929_414752" xmi:uuid="e802c850-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083439028_653801_71358"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395963_99293_339601"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="82"/>
      <waypoint x="381" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_917090_414755" xmi:uuid="e802cf00-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083558204_401659_71467"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395978_340460_339616"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="102"/>
      <waypoint x="381" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_748861_414758" xmi:uuid="e802d5f0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083430893_298801_71316"/>
      <source xmi:idref="_18_4_1_65b021e_1727446395991_54684_339631"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="122"/>
      <waypoint x="381" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_18191_414761" xmi:uuid="e802dd10-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083561806_901173_71481"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396005_184300_339646"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="142"/>
      <waypoint x="381" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_175360_414764" xmi:uuid="e802e390-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083441738_816612_71372"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396020_930917_339661"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="162"/>
      <waypoint x="381" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_433205_414767" xmi:uuid="e802ebd0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083436412_625605_71344"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396033_467299_339676"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="182"/>
      <waypoint x="381" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_779072_414770" xmi:uuid="e802f2b0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083444928_131874_71386"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396049_319651_339691"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="202"/>
      <waypoint x="381" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_366777_414773" xmi:uuid="e802f9c0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083448135_631711_71400"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396064_657181_339706"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="222"/>
      <waypoint x="381" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_475315_414776" xmi:uuid="e80300e0-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083427951_141809_71302"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396077_897611_339721"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="242"/>
      <waypoint x="381" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511436_409265_414779" xmi:uuid="e8030720-6c45-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1663083565266_29714_71495"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396090_57483_339736"/>
      <target xmi:idref="_18_4_1_65b021e_1727446395932_208452_339552"/>
      <waypoint x="699" y="262"/>
      <waypoint x="381" y="262"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="702" height="340"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446396247_981792_339931" xmi:uuid="ed794f50-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396273_359507_339963" xmi:uuid="ee84a560-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_299549_62768"/>
      <ownedElement xmi:id="ee55a0a0-6c44-013d-d609-0800270c66d6" xmi:uuid="ee55a240-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_299549_62768"/>
        <text>risk_version:Risk_version</text>
      </ownedElement>
      <ownedElement xmi:id="ee8490d0-6c44-013d-d609-0800270c66d6" xmi:uuid="ee8491a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882535_299549_62768"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="172" height="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396289_307551_339997" xmi:uuid="ee970db0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="538" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396301_132087_340012" xmi:uuid="eeaa7b80-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="538" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396316_844152_340027" xmi:uuid="eeabd710-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="538" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396325_911192_340042" xmi:uuid="eede7f30-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="538" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396333_423464_340057" xmi:uuid="eedfac10-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="538" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396342_392431_340072" xmi:uuid="eee0df40-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="538" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396353_77024_340087" xmi:uuid="ef0e06e0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="538" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396369_412812_340102" xmi:uuid="ef0f2e40-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="538" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396380_788169_340117" xmi:uuid="ef1066a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="538" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396389_105370_340132" xmi:uuid="ef3fd570-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="538" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396405_397401_340147" xmi:uuid="ef474cd0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="538" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396420_121601_340162" xmi:uuid="ef5f9e20-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="538" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396434_340895_340177" xmi:uuid="ef74f980-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="538" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396444_345620_340192" xmi:uuid="ef88ab70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1540915512831_719143_31709"/>
      <bounds x="538" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396459_852508_340207" xmi:uuid="ef8a63b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="538" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396469_454345_340222" xmi:uuid="efa8b140-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="538" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396483_785729_340237" xmi:uuid="efc54ce0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="538" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396493_309796_340252" xmi:uuid="efd7cea0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="538" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396503_577644_340267" xmi:uuid="eff14040-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="538" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396512_51528_340282" xmi:uuid="eff26bf0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="538" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396528_790135_340297" xmi:uuid="f002e950-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="538" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396544_402062_340312" xmi:uuid="f016b2d0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="538" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446396553_254138_340327" xmi:uuid="f02f02c0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1540916564417_774412_33192"/>
      <bounds x="538" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446397930_165432_340342" xmi:uuid="f03fac10-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578048041772_118444_59236"/>
      <bounds x="538" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446397944_912578_340357" xmi:uuid="f05013a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="538" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446397954_45143_340372" xmi:uuid="f0652ef0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="538" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446397969_730169_340387" xmi:uuid="f0665ff0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="538" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446397979_636215_340402" xmi:uuid="f067c780-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="538" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446397989_409241_340417" xmi:uuid="f08f0c80-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="538" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446397998_956791_340432" xmi:uuid="f0a40430-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583854949897_4176_62663"/>
      <bounds x="538" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398008_437352_340447" xmi:uuid="f0babab0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="538" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398017_925030_340462" xmi:uuid="f0d47260-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="538" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398029_184089_340477" xmi:uuid="f0e9d0a0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="538" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398040_300736_340492" xmi:uuid="f0eb2680-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="538" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398051_272133_340507" xmi:uuid="f102fe60-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="538" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398062_389102_340522" xmi:uuid="f116ccf0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="538" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398074_354536_340537" xmi:uuid="f131b9d0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="538" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398082_133824_340552" xmi:uuid="f13300c0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570204497794_443467_105732"/>
      <bounds x="538" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446398092_240893_340567" xmi:uuid="f1345a90-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="538" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_190832_414806" xmi:uuid="f1347c00-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_682276_62722"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396289_307551_339997"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="62"/>
      <waypoint x="217" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_317551_414809" xmi:uuid="f1348950-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_317921_62723"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396301_132087_340012"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="82"/>
      <waypoint x="217" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_696359_414812" xmi:uuid="f1349aa0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_705020_62724"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396316_844152_340027"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="102"/>
      <waypoint x="217" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_205781_414815" xmi:uuid="f134ad70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_260194_62751"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396325_911192_340042"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="122"/>
      <waypoint x="217" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_79534_414818" xmi:uuid="f134ba20-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_902288_62749"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396333_423464_340057"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="142"/>
      <waypoint x="217" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_241665_414821" xmi:uuid="f134ce80-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_517815_62725"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396342_392431_340072"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="162"/>
      <waypoint x="217" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_748770_414824" xmi:uuid="f134e180-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_515008_62752"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396353_77024_340087"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="182"/>
      <waypoint x="217" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_346323_414827" xmi:uuid="f134f9b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_888734_62755"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396369_412812_340102"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="202"/>
      <waypoint x="217" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_576284_414830" xmi:uuid="f1350380-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_115603_62726"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396380_788169_340117"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="222"/>
      <waypoint x="217" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_806652_414833" xmi:uuid="f13513e0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_384646_62727"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396389_105370_340132"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="242"/>
      <waypoint x="217" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_721068_414836" xmi:uuid="f1352000-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_990400_62728"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396405_397401_340147"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="262"/>
      <waypoint x="217" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_533360_414839" xmi:uuid="f1352960-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_887669_62729"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396420_121601_340162"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="282"/>
      <waypoint x="217" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_124406_414842" xmi:uuid="f13539b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_12119_62730"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396434_340895_340177"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="302"/>
      <waypoint x="217" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_444945_414845" xmi:uuid="f13550e0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_585781_62731"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396444_345620_340192"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="322"/>
      <waypoint x="217" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_99870_414848" xmi:uuid="f1356040-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_898912_62757"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396459_852508_340207"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="342"/>
      <waypoint x="217" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_670124_414851" xmi:uuid="f1357360-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_484621_62732"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396469_454345_340222"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="362"/>
      <waypoint x="217" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_648316_414854" xmi:uuid="f13584c0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_180366_62733"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396483_785729_340237"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="382"/>
      <waypoint x="217" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_808764_414857" xmi:uuid="f1358f30-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_824060_62748"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396493_309796_340252"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="402"/>
      <waypoint x="217" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_240791_414860" xmi:uuid="f1359ad0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_376611_62747"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396503_577644_340267"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="422"/>
      <waypoint x="217" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_87732_414863" xmi:uuid="f16383e0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_208199_62734"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396512_51528_340282"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="442"/>
      <waypoint x="217" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_958197_414866" xmi:uuid="f1639610-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1662135855933_693122_68268"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396528_790135_340297"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="462"/>
      <waypoint x="217" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_983962_414869" xmi:uuid="f163acb0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1662135859878_381293_68282"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396544_402062_340312"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="482"/>
      <waypoint x="217" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_420492_414872" xmi:uuid="f163bbe0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_519206_62735"/>
      <source xmi:idref="_18_4_1_65b021e_1727446396553_254138_340327"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="502"/>
      <waypoint x="217" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_212763_414875" xmi:uuid="f163cb30-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_524326_62736"/>
      <source xmi:idref="_18_4_1_65b021e_1727446397930_165432_340342"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="522"/>
      <waypoint x="217" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_728532_414878" xmi:uuid="f163e370-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_98120_62737"/>
      <source xmi:idref="_18_4_1_65b021e_1727446397944_912578_340357"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="542"/>
      <waypoint x="217" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_954458_414881" xmi:uuid="f163edd0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_413586_62738"/>
      <source xmi:idref="_18_4_1_65b021e_1727446397954_45143_340372"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="562"/>
      <waypoint x="217" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_261647_414884" xmi:uuid="f163f510-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_630087_62739"/>
      <source xmi:idref="_18_4_1_65b021e_1727446397969_730169_340387"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="582"/>
      <waypoint x="217" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_735757_414887" xmi:uuid="f163fca0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_525638_62740"/>
      <source xmi:idref="_18_4_1_65b021e_1727446397979_636215_340402"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="602"/>
      <waypoint x="217" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_190838_414890" xmi:uuid="f1640600-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_330398_62741"/>
      <source xmi:idref="_18_4_1_65b021e_1727446397989_409241_340417"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="622"/>
      <waypoint x="217" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_522291_414893" xmi:uuid="f1640db0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_201686_62750"/>
      <source xmi:idref="_18_4_1_65b021e_1727446397998_956791_340432"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="642"/>
      <waypoint x="217" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_782984_414896" xmi:uuid="f1641a10-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1662135852153_73136_68254"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398008_437352_340447"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="662"/>
      <waypoint x="217" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_702978_414899" xmi:uuid="f16422b0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1662135848447_289826_68240"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398017_925030_340462"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="682"/>
      <waypoint x="217" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_271790_414902" xmi:uuid="f1642c30-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_22612_62742"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398029_184089_340477"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="702"/>
      <waypoint x="217" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_752597_414905" xmi:uuid="f1643580-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_326888_62743"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398040_300736_340492"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="722"/>
      <waypoint x="217" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_276775_414908" xmi:uuid="f1643d30-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_854775_62744"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398051_272133_340507"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="742"/>
      <waypoint x="217" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_302406_414911" xmi:uuid="f1644450-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_534030_62758"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398062_389102_340522"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="762"/>
      <waypoint x="217" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_467452_414914" xmi:uuid="f1644d70-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_201475_62756"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398074_354536_340537"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="782"/>
      <waypoint x="217" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_95843_414917" xmi:uuid="f1645630-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_938107_62745"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398082_133824_340552"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="802"/>
      <waypoint x="217" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511444_635074_414920" xmi:uuid="f1645de0-6c44-013d-d609-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Risk.xmi#_18_4_1_2b2015d_1617888882519_677887_62746"/>
      <source xmi:idref="_18_4_1_65b021e_1727446398092_240893_340567"/>
      <target xmi:idref="_18_4_1_65b021e_1727446396273_359507_339963"/>
      <waypoint x="538" y="822"/>
      <waypoint x="217" y="822"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="541" height="900"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
