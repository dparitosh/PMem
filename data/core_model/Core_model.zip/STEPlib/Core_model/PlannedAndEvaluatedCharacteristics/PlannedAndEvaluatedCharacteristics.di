<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1688564401006_896341_227157" xmi:uuid="5e307e10-0d30-013c-5e2b-5b8e392dc4e5">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1688564029410_212362_179108"/>
    <defaultNamespace href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1690210107917_71188_84470"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703185055031_767329_420126" xmi:uuid="983a05b0-915a-013c-7157-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703185055026_104605_420115"/>
    <defaultNamespace href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1690210107917_71188_84470"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564550763_4769_289435" xmi:uuid="5f52e310-0d30-013c-5e2b-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564399235_349824_226950"/>
    <defaultNamespace href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028950_47876_179002"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564550394_997265_289210" xmi:uuid="6183a230-0d30-013c-5e2b-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564398095_933457_226845"/>
    <defaultNamespace href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028930_826784_179001"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564550934_542595_289562" xmi:uuid="671a3a70-0d30-013c-5e2b-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564400201_889510_227030"/>
    <defaultNamespace href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028971_278852_179014"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1688564029410_212362_179108" xmi:uuid="5e300920-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1690210107917_71188_84470"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_371758_371426" xmi:uuid="5e455e40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028971_278852_179014"/>
      <ownedElement xmi:id="5e330d30-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e330eb0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028971_278852_179014"/>
        <text>EvaluatedCharacteristic</text>
      </ownedElement>
      <ownedElement xmi:id="5e340b70-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e340ca0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="5e3fd8c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e3fd9e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5e403530-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e4035e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="5e414110-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e414230-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399717_974372_227008"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="5e427c30-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e427d70-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399760_345928_227014"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="5e438230-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e438410-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400430_438502_227082"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="0e8f03c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="0e8f04f0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400449_513307_227083"/>
          <text>ClassifiedAs</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="252" y="112" width="196" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_208936_371427" xmi:uuid="5e5dad90-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028930_826784_179001"/>
      <ownedElement xmi:id="5e465ba0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e465f20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028930_826784_179001"/>
        <text>MeasuredCharacteristic</text>
      </ownedElement>
      <ownedElement xmi:id="5e475030-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e475160-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="5e56fd90-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e56fec0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5e576390-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e576470-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="5e5861d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e586300-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398349_297601_226905"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="5e594e60-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e594ff0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398369_340107_226906"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="5e5a61e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e5a64d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398389_9460_226907"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="0ea3e130-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="0ea3e240-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398408_838881_226908"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="5e5b86a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e5b88f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398447_317462_226910"/>
          <text>MeasuredCharacteristics</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="665" y="119" width="186" height="113"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_945587_371428" xmi:uuid="5e6158d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028988_238435_179016"/>
      <ownedElement xmi:id="5e5ede00-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e5edf20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028988_238435_179016"/>
        <text>MeasureActivitySelect</text>
      </ownedElement>
      <ownedElement xmi:id="da108ec0-6c41-013d-d600-0800270c66d6" xmi:uuid="da108f90-6c41-013d-d600-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="da1d7370-6c41-013d-d600-0800270c66d6" xmi:uuid="da1d7410-6c41-013d-d600-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="659" y="336" width="103" height="45"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_143363_371435" xmi:uuid="5e66a9e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028961_287099_179004"/>
      <ownedElement xmi:id="5e627b80-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e627ca0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028961_287099_179004"/>
        <text>EvaluationResultEnum</text>
      </ownedElement>
      <ownedElement xmi:id="397a49d0-7e6d-013d-f5d5-0800270c66d6" xmi:uuid="397a4b70-7e6d-013d-f5d5-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="398972c0-7e6d-013d-f5d5-0800270c66d6" xmi:uuid="39897450-7e6d-013d-f5d5-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399641_586767_227001"/>
          <text>fail</text>
        </ownedElement>
        <ownedElement xmi:id="39a62c40-7e6d-013d-f5d5-0800270c66d6" xmi:uuid="39a62d40-7e6d-013d-f5d5-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399659_852130_227002"/>
          <text>pass</text>
        </ownedElement>
        <ownedElement xmi:id="39a6e030-7e6d-013d-f5d5-0800270c66d6" xmi:uuid="39a6e0f0-7e6d-013d-f5d5-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399678_467473_227003"/>
          <text>undefined</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="203" blue="255"/>
      </localStyle>
      <bounds x="35" y="91" width="109" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_452739_371436" xmi:uuid="5e6c68f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028992_288202_179019"/>
      <ownedElement xmi:id="5e67c0f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e67c210-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028992_288202_179019"/>
        <text>EvaluationStatusEnum</text>
      </ownedElement>
      <ownedElement xmi:id="39a92390-7e6d-013d-f5d5-0800270c66d6" xmi:uuid="39a92460-7e6d-013d-f5d5-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="39a9ca10-7e6d-013d-f5d5-0800270c66d6" xmi:uuid="39a9cb70-7e6d-013d-f5d5-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400900_821659_227112"/>
          <text>invalid</text>
        </ownedElement>
        <ownedElement xmi:id="39d0b430-7e6d-013d-f5d5-0800270c66d6" xmi:uuid="39d0b570-7e6d-013d-f5d5-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400919_349856_227113"/>
          <text>not_evaluatable</text>
        </ownedElement>
        <ownedElement xmi:id="39d1d500-7e6d-013d-f5d5-0800270c66d6" xmi:uuid="39d1d610-7e6d-013d-f5d5-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400937_327319_227114"/>
          <text>to_be_evaluated</text>
        </ownedElement>
        <ownedElement xmi:id="39de1b40-7e6d-013d-f5d5-0800270c66d6" xmi:uuid="39df3310-7e6d-013d-f5d5-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400957_532923_227115"/>
          <text>valid</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="203" blue="255"/>
      </localStyle>
      <bounds x="35" y="189" width="109" height="94"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_10122_371441" xmi:uuid="5e996240-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="5e71c6d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e71c7f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="5e734cf0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5e734df0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="511" y="420" width="170" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_498638_371443" xmi:uuid="5ec658d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
      <ownedElement xmi:id="5ea15160-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5ea15370-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
        <text>ProcessOperationOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="5ea34ec0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5ea350f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="721" y="420" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_243607_371446" xmi:uuid="5ef681a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementAssignment"/>
      <ownedElement xmi:id="5ecfeb90-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5ecfec90-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementAssignment"/>
        <text>RequirementAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="5ed24d40-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5ed24e40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="217" y="420" width="239" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_62579_371454" xmi:uuid="5f025910-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028950_47876_179002"/>
      <ownedElement xmi:id="5ef7eee0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5ef7f020-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028950_47876_179002"/>
        <text>PlannedCharacteristic</text>
      </ownedElement>
      <ownedElement xmi:id="5ef8fd80-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5ef90260-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="5effef20-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5efff020-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5f004ca0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f004e20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="5f014d80-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f014ec0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399389_642281_226986"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="5f025090-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f0251b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399427_606012_226988"/>
          <text>PlannedCharacteristics</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="245" y="280" width="210" height="60"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_295865_371455" xmi:uuid="5f371cf0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="5f09b7f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f09b910-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="5f0bd200-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f0bd310-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="945" y="420" width="194" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_353884_402295" xmi:uuid="5f39ef00-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028967_26450_179007"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_840227_371429" xmi:uuid="5f38e380-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398427_960206_226909"/>
        <bounds x="642" y="311" width="67" height="12"/>
        <text>MeasureActivity</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_812874_371430" xmi:uuid="5f398000-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398427_960206_226909"/>
        <bounds x="715" y="311" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_723007_371431" xmi:uuid="5f39e360-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399756_908024_227011"/>
        <bounds x="715" y="235" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025945_208936_371427"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025945_945587_371428"/>
      <waypoint x="712" y="232"/>
      <waypoint x="712" y="336"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_212128_402296" xmi:uuid="5f3c5d30-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028991_195940_179017"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_693390_371432" xmi:uuid="5f3b80a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400510_263796_227086"/>
        <bounds x="274" y="265" width="87" height="12"/>
        <text>PlannedCharacteristic</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_779792_371433" xmi:uuid="5f3bf450-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400510_263796_227086"/>
        <bounds x="367" y="265" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_812219_371434" xmi:uuid="5f3c5950-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400896_386096_227110"/>
        <bounds x="367" y="234" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025944_371758_371426"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025945_62579_371454"/>
      <waypoint x="364" y="231"/>
      <waypoint x="364" y="280"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_131753_402297" xmi:uuid="5f3e8ad0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564029008_996408_179037"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_386886_371437" xmi:uuid="5f3df540-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400470_65525_227084"/>
        <bounds x="147" y="118" width="70" height="12"/>
        <text>EvaluationResult</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_435295_371438" xmi:uuid="5f3e8500-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400470_65525_227084"/>
        <bounds x="147" y="136" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025944_371758_371426"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025945_143363_371435"/>
      <waypoint x="252" y="133"/>
      <waypoint x="144" y="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_638293_402298" xmi:uuid="5f40e420-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564029008_198531_179038"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_957936_371439" xmi:uuid="5f406780-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400490_108398_227085"/>
        <bounds x="147" y="199" width="69" height="12"/>
        <text>EvaluationStatus</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_991627_371440" xmi:uuid="5f40dfc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400490_108398_227085"/>
        <bounds x="147" y="217" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025944_371758_371426"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025945_452739_371436"/>
      <waypoint x="252" y="214"/>
      <waypoint x="144" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_266246_402299" xmi:uuid="b5901a70-3ed1-013c-a14f-4b23c1d46efd" xmi:type="umldi:UMLEdge">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_65b021e_1688564400875_857056_227107"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025945_945587_371428"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025945_10122_371441"/>
      <waypoint x="602" y="409"/>
      <waypoint x="602" y="420"/>
      <waypoint x="710" y="381"/>
      <waypoint x="710" y="409"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_922910_402300" xmi:uuid="5f44ff60-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688564036279_393881_180518"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025945_945587_371428"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025945_498638_371443"/>
      <waypoint x="809" y="409"/>
      <waypoint x="809" y="420"/>
      <waypoint x="710" y="381"/>
      <waypoint x="710" y="409"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_535664_402301" xmi:uuid="5f4a6400-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028967_600626_179008"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_422842_371448" xmi:uuid="5f48ea60-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399408_782829_226987"/>
        <bounds x="315" y="395" width="46" height="12"/>
        <text>DefinedFor</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_218557_371449" xmi:uuid="5f49a620-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399408_782829_226987"/>
        <bounds x="367" y="395" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_961897_371450" xmi:uuid="5f4a4b60-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399758_751942_227012"/>
        <bounds x="367" y="343" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025945_62579_371454"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025945_243607_371446"/>
      <waypoint x="364" y="340"/>
      <waypoint x="364" y="420"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_635039_402302" xmi:uuid="5f4d1020-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028966_332842_179006"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_782296_371451" xmi:uuid="5f4bf250-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399738_647405_227010"/>
        <bounds x="581" y="153" width="81" height="12"/>
        <text>ActualCharacteristic</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_671565_371452" xmi:uuid="5f4c5940-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399738_647405_227010"/>
        <bounds x="640" y="171" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_501024_371453" xmi:uuid="5f4cfab0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399737_182786_227009"/>
        <bounds x="461" y="171" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025944_371758_371426"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025945_208936_371427"/>
      <waypoint x="448" y="168"/>
      <waypoint x="665" y="168"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_671623_402303" xmi:uuid="5f4fa060-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564029023_935790_179056"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_400155_371457" xmi:uuid="5f4ef010-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398508_699003_226913"/>
        <bounds x="962" y="405" width="43" height="12"/>
        <text>TestedPart</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_704441_371458" xmi:uuid="5f4f99b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398508_699003_226913"/>
        <bounds x="1011" y="405" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025945_208936_371427"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025945_295865_371455"/>
      <waypoint x="851" y="168"/>
      <waypoint x="1008" y="168"/>
      <waypoint x="1008" y="420"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_263454_402304" xmi:uuid="5f51c4a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564029023_719138_179057"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_319020_371459" xmi:uuid="5f513580-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398486_365405_226912"/>
        <bounds x="458" y="293" width="87" height="12"/>
        <text>PlannedCharacteristic</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025945_280104_371460" xmi:uuid="5f51bd20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398486_365405_226912"/>
        <bounds x="458" y="311" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025945_208936_371427"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025945_62579_371454"/>
      <waypoint x="665" y="214"/>
      <waypoint x="564" y="214"/>
      <waypoint x="564" y="308"/>
      <waypoint x="455" y="308"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1154" height="468"/>
    <name>PlannedAndEvaluatedCharacteristics</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703185055026_104605_420115" xmi:uuid="9839a320-915a-013c-7157-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1690210107917_71188_84470"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185055080_353868_420148" xmi:uuid="983cf7c0-915a-013c-7157-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028988_238435_179016"/>
      <ownedElement xmi:id="983b8050-915a-013c-7157-0a5172f4a469" xmi:uuid="983b8150-915a-013c-7157-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028988_238435_179016"/>
        <text>MeasureActivitySelect</text>
      </ownedElement>
      <ownedElement xmi:id="983c3a30-915a-013c-7157-0a5172f4a469" xmi:uuid="983c3b00-915a-013c-7157-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="983c8ac0-915a-013c-7157-0a5172f4a469" xmi:uuid="983c8b60-915a-013c-7157-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="435" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185057150_23424_420219" xmi:uuid="9870fd10-915a-013c-7157-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="983f36b0-915a-013c-7157-0a5172f4a469" xmi:uuid="983f37b0-915a-013c-7157-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="f7a43490-6c41-013d-d600-0800270c66d6" xmi:uuid="f7a43530-6c41-013d-d600-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="170" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185058587_19317_420280" xmi:uuid="98951840-915a-013c-7157-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
      <ownedElement xmi:id="987330b0-915a-013c-7157-0a5172f4a469" xmi:uuid="987331b0-915a-013c-7157-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
        <text>ProcessOperationOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="fac8d2e0-6c41-013d-d600-0800270c66d6" xmi:uuid="fac8d380-6c41-013d-d600-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="255" y="95" width="185" height="33"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="495" height="175"/>
    <name>MeasureActivitySelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564399235_349824_226950" xmi:uuid="5f524010-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028950_47876_179002"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_204362_394535" xmi:uuid="5f5b7d20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399408_782829_226987"/>
      <ownedElement xmi:id="5f5745d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f5746f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399408_782829_226987"/>
        <text>DefinedFor:RequirementAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="5f582950-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f582a40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399408_782829_226987"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_661643_394536" xmi:uuid="5f5b6f00-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570005313258_301838_56026"/>
        <ownedElement xmi:id="fd4aa930-6c41-013d-d600-0800270c66d6" xmi:uuid="fd4aa9d0-6c41-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570005313258_301838_56026"/>
          <bounds x="281" y="62" width="205" height="13"/>
          <text>assignment : Requirement_assignment [1]</text>
        </ownedElement>
        <bounds x="266" y="81" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="77" width="246" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_813031_394538" xmi:uuid="5f828fc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399389_642281_226986"/>
      <ownedElement xmi:id="5f819750-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f819860-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399389_642281_226986"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="5f827070-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f827150-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399389_642281_226986"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="273" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_186904_394539" xmi:uuid="5f9ad5e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399427_606012_226988"/>
      <ownedElement xmi:id="5f8de960-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f8dea60-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399427_606012_226988"/>
        <text>PlannedCharacteristics:PropertyValue</text>
      </ownedElement>
      <ownedElement xmi:id="5f8ec2d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5f8ec3d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399427_606012_226988"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1690210294765_300953_85901" xmi:uuid="5f9acc40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1549643568938_643883_37017"/>
        <ownedElement xmi:id="1094e240-6c42-013d-d600-0800270c66d6" xmi:uuid="1094e2e0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1549643568938_643883_37017"/>
          <bounds x="298" y="456" width="323" height="13"/>
          <text>propertyDefRepresentation : Property_definition_representation [1]</text>
        </ownedElement>
        <bounds x="280" y="465" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="455" width="253" height="37"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_651504_394542" xmi:uuid="60065a50-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399446_306937_226989"/>
      <ownedElement xmi:id="5fbec3d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5fbec500-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399446_306937_226989"/>
        <text>planned_characteristic:Planned_characteristic</text>
      </ownedElement>
      <ownedElement xmi:id="5fbff6f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5fbff820-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399446_306937_226989"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="1a259910-6c42-013d-d600-0800270c66d6" xmi:uuid="1a2599b0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="1a25d440-6c42-013d-d600-0800270c66d6" xmi:uuid="1a25d490-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_49834_394543" xmi:uuid="5fe4e3c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Planned_characteristic-planned_coordinated_characteristic"/>
          <ownedElement xmi:id="5fd8ba10-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5fd8bb10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Planned_characteristic-planned_coordinated_characteristic"/>
            <text>planned_coordinated_characteristic:Property_representation</text>
          </ownedElement>
          <ownedElement xmi:id="5fe48680-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5fe48790-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Planned_characteristic-planned_coordinated_characteristic"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1323" y="462" width="373" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_273338_394544" xmi:uuid="60064ce0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Planned_characteristic-reference_requirement"/>
          <ownedElement xmi:id="5ffb0c60-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="5ffb0d60-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Planned_characteristic-reference_requirement"/>
            <text>reference_requirement:Requirement_assignment</text>
          </ownedElement>
          <ownedElement xmi:id="6005dfa0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6005e0a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Planned_characteristic-reference_requirement"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1323" y="78" width="314" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1302" y="42" width="401" height="463"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_868384_394545" xmi:uuid="604232a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399487_367570_226991"/>
      <ownedElement xmi:id="6011dc60-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6011dd60-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399487_367570_226991"/>
        <text>selectName:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_426013_394546" xmi:uuid="601dd920-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="1f2add30-6c42-013d-d600-0800270c66d6" xmi:uuid="1f2adde0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="605" y="249" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="587" y="258" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_543261_394548" xmi:uuid="60295d70-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="1fad8a70-6c42-013d-d600-0800270c66d6" xmi:uuid="1fad8b00-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="324" y="271" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="378" y="280" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_784980_394550" xmi:uuid="6035af90-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="205ab5b0-6c42-013d-d600-0800270c66d6" xmi:uuid="205ab640-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="605" y="347" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="587" y="356" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_411490_394552" xmi:uuid="604227d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="20f199e0-6c42-013d-d600-0800270c66d6" xmi:uuid="20f19a80-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="396" y="236" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="386" y="252" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="378" y="252" width="224" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_815176_394554" xmi:uuid="605bb4a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399505_28045_226992"/>
      <ownedElement xmi:id="604e2620-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="604e2740-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399505_28045_226992"/>
        <text>name:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="604f3a90-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="604f3bb0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399505_28045_226992"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_511486_394555" xmi:uuid="605bac00-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="222fb210-6c42-013d-d600-0800270c66d6" xmi:uuid="222fb2a0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="721" y="336" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="826" y="358" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="693" y="350" width="141" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_200528_394557" xmi:uuid="6073a490-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399524_597515_226993"/>
      <ownedElement xmi:id="6066f1c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6066f530-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399524_597515_226993"/>
        <text>language1:Language</text>
      </ownedElement>
      <ownedElement xmi:id="606806b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="60680950-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399524_597515_226993"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_878913_394558" xmi:uuid="60739280-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="23d18880-6c42-013d-d600-0800270c66d6" xmi:uuid="23d18910-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="497" y="217" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="475" y="201" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="315" y="196" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_723123_394560" xmi:uuid="60764aa0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399542_175212_226994"/>
      <ownedElement xmi:id="60755cc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="60755da0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399542_175212_226994"/>
        <text>theAttribute1:String</text>
      </ownedElement>
      <ownedElement xmi:id="60763c50-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="60763d50-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399542_175212_226994"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="371" y="162" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_566096_410900" xmi:uuid="60dd5250-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399372_972288_226978"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_569213_394570"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_944203_394563"/>
      <waypoint x="952" y="144"/>
      <waypoint x="844" y="144"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_370462_394561" xmi:uuid="60dda5a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399564_103732_226995"/>
      <ownedElement xmi:id="608103c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="608104d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399564_103732_226995"/>
        <text>li1:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="6081db70-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6081dc80-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399564_103732_226995"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="24c31300-6c42-013d-d600-0800270c66d6" xmi:uuid="24c31390-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="24c35aa0-6c42-013d-d600-0800270c66d6" xmi:uuid="24c35b30-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_146458_394562" xmi:uuid="609a9bc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="608dcd00-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="608dce10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="6099b460-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6099b5b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="616" y="161" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_944203_394563" xmi:uuid="60bc9fd0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="60b15120-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="60b15220-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="60bc3780-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="60bc3890-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="616" y="132" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_919500_394564" xmi:uuid="60dcf2a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="60d1e870-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="60d1ec00-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="60dc9440-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="60dc9540-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="616" y="195" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="602" y="105" width="249" height="125"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_134048_394565" xmi:uuid="610b2d30-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399582_410797_226996"/>
      <ownedElement xmi:id="60e868d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="60e869e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399582_410797_226996"/>
        <text>dta1:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="60e93bd0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="60e93cc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399582_410797_226996"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="29ee0c50-6c42-013d-d600-0800270c66d6" xmi:uuid="29ee0cf0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="29ee4400-6c42-013d-d600-0800270c66d6" xmi:uuid="29ee4440-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_290128_394566" xmi:uuid="610b2570-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="60ffdbd0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="60ffdcf0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="610ac520-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="610ac630-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="966" y="364" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="952" y="336" width="329" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_205085_394567" xmi:uuid="615ac840-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399601_762219_226997"/>
      <ownedElement xmi:id="611681a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="611682b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399601_762219_226997"/>
        <text>dta2:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="611788d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="611789c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399601_762219_226997"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="2c927410-6c42-013d-d600-0800270c66d6" xmi:uuid="2c9274b0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2cb17e90-6c42-013d-d600-0800270c66d6" xmi:uuid="2cb17f40-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_772530_394568" xmi:uuid="6138fe00-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="612dd8c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="612dd9d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="61389f10-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6138a020-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="966" y="293" width="175" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_751322_394569" xmi:uuid="615aaf90-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="614e7300-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="614e7410-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="615a27d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="615a28d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="966" y="259" width="192" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="952" y="231" width="329" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_569213_394570" xmi:uuid="618161a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399621_305196_226998"/>
      <ownedElement xmi:id="6166bd30-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6166be40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399621_305196_226998"/>
        <text>dt:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="6167bdb0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6167bec0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399621_305196_226998"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="30f2a820-6c42-013d-d600-0800270c66d6" xmi:uuid="30f2a8d0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="30f2e5e0-6c42-013d-d600-0800270c66d6" xmi:uuid="30f2f6b0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_698174_394571" xmi:uuid="61815790-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="6174df30-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6174e2d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="6180e440-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6180e580-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="973" y="162" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="952" y="126" width="163" height="71"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_699948_410897" xmi:uuid="61816ff0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399357_470931_226971"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_438154_394572"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_651504_394542"/>
      <waypoint x="1715" y="63"/>
      <waypoint x="1703" y="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_387260_410898" xmi:uuid="61817780-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399359_892055_226972"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_273338_394544"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_661643_394536"/>
      <waypoint x="1323" y="88"/>
      <waypoint x="281" y="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_624136_410899" xmi:uuid="618180e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399361_213032_226973"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_543261_394548"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_813031_394538"/>
      <waypoint x="378" y="284"/>
      <waypoint x="209" y="284"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_966109_410901" xmi:uuid="618188d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399363_76081_226974"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_919500_394564"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_878913_394558"/>
      <waypoint x="616" y="210"/>
      <waypoint x="490" y="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_618204_410902" xmi:uuid="61819370-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399365_361711_226975"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_146458_394562"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_723123_394560"/>
      <waypoint x="616" y="175"/>
      <waypoint x="585" y="175"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_351877_410903" xmi:uuid="618199d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399367_162599_226976"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_134048_394565"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_511486_394555"/>
      <waypoint x="952" y="364"/>
      <waypoint x="841" y="364"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_9085_410904" xmi:uuid="6181a120-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399370_162760_226977"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_815176_394554"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_784980_394550"/>
      <waypoint x="693" y="364"/>
      <waypoint x="602" y="364"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_456514_410905" xmi:uuid="6181a870-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399374_394943_226979"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_698174_394571"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_426013_394546"/>
      <waypoint x="973" y="175"/>
      <waypoint x="886" y="175"/>
      <waypoint x="886" y="266"/>
      <waypoint x="602" y="266"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_740518_410906" xmi:uuid="6181af80-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399376_534390_226980"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_751322_394569"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_569213_394570"/>
      <waypoint x="1078" y="259"/>
      <waypoint x="1078" y="197"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_648055_410907" xmi:uuid="6181bc40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399379_864775_226981"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_772530_394568"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_651504_394542"/>
      <waypoint x="1141" y="305"/>
      <waypoint x="1302" y="305"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_330432_410908" xmi:uuid="6181cce0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399381_861091_226982"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_290128_394566"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_651504_394542"/>
      <waypoint x="1141" y="375"/>
      <waypoint x="1302" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_117430_410909" xmi:uuid="6181dd20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399384_909194_226983"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_200528_394557"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_411490_394552"/>
      <waypoint x="392" y="221"/>
      <waypoint x="392" y="252"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_559887_410910" xmi:uuid="61820110-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399386_779936_226984"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_49834_394543"/>
      <target xmi:idref="_18_4_1_65b021e_1690210294765_300953_85901"/>
      <waypoint x="1323" y="473"/>
      <waypoint x="295" y="473"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_438154_394572" xmi:uuid="618280d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399467_532755_226990"/>
      <bounds x="1715" y="54" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1718" height="520"/>
    <name>PlannedCharacteristic</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564398095_933457_226845" xmi:uuid="61830a40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028930_826784_179001"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_345259_394433" xmi:uuid="619e95a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398408_838881_226908"/>
      <ownedElement xmi:id="619162d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="619163e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398408_838881_226908"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="61926de0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61926ef0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398408_838881_226908"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_934739_394434" xmi:uuid="619e8f30-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="338e6850-6c42-013d-d600-0800270c66d6" xmi:uuid="338e6940-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="245" y="66" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="227" y="75" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="70" width="200" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_508184_394436" xmi:uuid="61aa5940-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398389_9460_226907"/>
      <ownedElement xmi:id="61a96060-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61a96180-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398389_9460_226907"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="61aa3650-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61aa3730-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398389_9460_226907"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="168" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_94754_394437" xmi:uuid="61b69200-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398349_297601_226905"/>
      <ownedElement xmi:id="61b5a290-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61b5a3b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398349_297601_226905"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="61b67c70-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61b67fc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398349_297601_226905"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="413" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_750645_394438" xmi:uuid="61ba5200-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398427_960206_226909"/>
      <ownedElement xmi:id="61b7d280-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61b7d620-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398427_960206_226909"/>
        <text>MeasureActivity:MeasureActivitySelect</text>
      </ownedElement>
      <ownedElement xmi:id="61b8be50-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61b8bf30-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398427_960206_226909"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_101643_394439" xmi:uuid="61ba3eb0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400875_767745_227108"/>
        <ownedElement xmi:id="35414f60-6c42-013d-d600-0800270c66d6" xmi:uuid="35415030-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400875_767745_227108"/>
          <bounds x="319" y="511" width="257" height="13"/>
          <text>measureActivitySelect : evaluation_activity_select [1]</text>
        </ownedElement>
        <bounds x="297" y="523" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="518" width="270" height="27"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_52484_394441" xmi:uuid="61c5e310-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398447_317462_226910"/>
      <ownedElement xmi:id="61c4f5f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61c4f700-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398447_317462_226910"/>
        <text>MeasuredCharacteristics:PropertyValue</text>
      </ownedElement>
      <ownedElement xmi:id="61c5d130-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61c5d220-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398447_317462_226910"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="581" width="266" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_511266_394444" xmi:uuid="61d167c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398369_340107_226906"/>
      <ownedElement xmi:id="61d084b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61d085c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398369_340107_226906"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="61d154f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61d15680-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398369_340107_226906"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="763" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_664582_394445" xmi:uuid="61ff4da0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398526_377336_226914"/>
      <ownedElement xmi:id="61dc6ed0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="61dc6fd0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398526_377336_226914"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_10549_394446" xmi:uuid="61e84480-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="382a5e80-6c42-013d-d600-0800270c66d6" xmi:uuid="382a5f20-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="514" y="374" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="496" y="383" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_106861_394448" xmi:uuid="61f3c1d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="38cbb8a0-6c42-013d-d600-0800270c66d6" xmi:uuid="38cbb940-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="303" y="405" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="357" y="414" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_714010_394450" xmi:uuid="61ff40c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="39862520-6c42-013d-d600-0800270c66d6" xmi:uuid="398626e0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="514" y="419" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="496" y="428" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="357" y="371" width="154" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_609584_394452" xmi:uuid="6215eb20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398543_426165_226915"/>
      <ownedElement xmi:id="620a0fa0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="620a10b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398543_426165_226915"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="620ae640-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="620ae700-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398543_426165_226915"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_617999_394453" xmi:uuid="6215e310-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="3ad48270-6c42-013d-d600-0800270c66d6" xmi:uuid="3ad48300-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="748" y="406" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="777" y="429" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="665" y="427" width="120" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_968931_410860" xmi:uuid="62426f20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398314_3111_226887"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_396725_394505"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_255312_394456"/>
      <waypoint x="1330" y="455"/>
      <waypoint x="1142" y="455"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_939714_394455" xmi:uuid="62435bb0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398563_852246_226916"/>
      <ownedElement xmi:id="6220a340-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6220a440-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398563_852246_226916"/>
        <text>ia:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="62216f80-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62217050-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398563_852246_226916"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="3b9e4880-6c42-013d-d600-0800270c66d6" xmi:uuid="3b9e4900-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3b9e7ec0-6c42-013d-d600-0800270c66d6" xmi:uuid="3b9e7ef0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_255312_394456" xmi:uuid="62421300-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="6236b640-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6236b760-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="6241b520-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6241b620-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="442" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="413" width="336" height="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_933008_394457" xmi:uuid="627ae940-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398586_266782_226917"/>
      <ownedElement xmi:id="624e6a60-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="624e6b70-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398586_266782_226917"/>
        <text>selectNae:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_123767_394458" xmi:uuid="6259f100-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="3fddf290-6c42-013d-d600-0800270c66d6" xmi:uuid="3fddf330-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="546" y="716" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="528" y="725" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_104786_394460" xmi:uuid="6264e3a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="40717ee0-6c42-013d-d600-0800270c66d6" xmi:uuid="40717f80-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="303" y="759" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="357" y="768" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_180056_394462" xmi:uuid="626fc1d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="410b9600-6c42-013d-d600-0800270c66d6" xmi:uuid="410b9690-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="546" y="768" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="528" y="777" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_524489_394464" xmi:uuid="627abe90-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="419f4d60-6c42-013d-d600-0800270c66d6" xmi:uuid="419f4de0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="546" y="801" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="528" y="810" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="357" y="721" width="186" height="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_757307_394466" xmi:uuid="62918810-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398607_326988_226918"/>
      <ownedElement xmi:id="62855080-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62855180-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398607_326988_226918"/>
        <text>name:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="62863090-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62863170-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398607_326988_226918"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_227921_394467" xmi:uuid="62918040-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="42c01bf0-6c42-013d-d600-0800270c66d6" xmi:uuid="42c01c80-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="693" y="763" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="798" y="785" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="665" y="777" width="141" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_742805_394469" xmi:uuid="62a84320-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398632_171357_226919"/>
      <ownedElement xmi:id="629c2a60-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="629c2b60-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398632_171357_226919"/>
        <text>language1:Language</text>
      </ownedElement>
      <ownedElement xmi:id="629d1670-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="629d1780-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398632_171357_226919"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_699191_394470" xmi:uuid="62a83b30-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="43f0a6e0-6c42-013d-d600-0800270c66d6" xmi:uuid="43f0a780-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="806" y="882" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="825" y="903" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="665" y="896" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_645521_394472" xmi:uuid="62aa3960-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398652_560629_226920"/>
      <ownedElement xmi:id="62a94920-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62a94a30-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398652_560629_226920"/>
        <text>theAttribute1:String</text>
      </ownedElement>
      <ownedElement xmi:id="62aa2110-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62aa2240-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398652_560629_226920"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="665" y="931" width="188" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_18928_410864" xmi:uuid="63186db0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398329_632058_226895"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_396725_394505"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_132634_394475"/>
      <waypoint x="1495" y="623"/>
      <waypoint x="1495" y="886"/>
      <waypoint x="1187" y="886"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_955025_394473" xmi:uuid="63197ba0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398675_824657_226921"/>
      <ownedElement xmi:id="62b52320-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62b52440-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398675_824657_226921"/>
        <text>li1:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="62b63f80-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62b640a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398675_824657_226921"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="44c997f0-6c42-013d-d600-0800270c66d6" xmi:uuid="44c99880-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="44c9dd60-6c42-013d-d600-0800270c66d6" xmi:uuid="44c9ddd0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_606408_394474" xmi:uuid="62d14750-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="62c3a5d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62c3a9b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="62d0bdc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62d0bf00-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="959" y="931" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_132634_394475" xmi:uuid="62f3b450-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="62e80990-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62e80aa0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="62f352c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="62f353d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="875" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_128690_394476" xmi:uuid="63179c10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="630abfd0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="630ac0e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="6316e100-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6316e250-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="903" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="847" width="336" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_975617_410865" xmi:uuid="634995e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398327_918789_226894"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_396725_394505"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_769334_394478"/>
      <waypoint x="1495" y="623"/>
      <waypoint x="1495" y="802"/>
      <waypoint x="1134" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_67718_394477" xmi:uuid="634a78f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398696_570271_226922"/>
      <ownedElement xmi:id="63262e70-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63262fe0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398696_570271_226922"/>
        <text>dta1:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="63273840-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63273980-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398696_570271_226922"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4a430a30-6c42-013d-d600-0800270c66d6" xmi:uuid="4a430ac0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4a5e3f20-6c42-013d-d600-0800270c66d6" xmi:uuid="4a5e4120-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_769334_394478" xmi:uuid="63493bd0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="633e28f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="633e29f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="6348d6b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6348d7c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="791" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="763" width="336" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_903338_394479" xmi:uuid="6385e9c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398716_795405_226923"/>
      <ownedElement xmi:id="635689a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63568ad0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398716_795405_226923"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_572655_394480" xmi:uuid="63635900-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="4d5c2610-6c42-013d-d600-0800270c66d6" xmi:uuid="4d5c26a0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="589" y="126" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="571" y="135" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_7682_394482" xmi:uuid="636ea0f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="4dfc9820-6c42-013d-d600-0800270c66d6" xmi:uuid="4dfc98c0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="303" y="163" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="357" y="172" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_249713_394484" xmi:uuid="637a2610-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="4e981e50-6c42-013d-d600-0800270c66d6" xmi:uuid="4e981ed0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="589" y="162" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="571" y="171" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_442223_394486" xmi:uuid="6385d340-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="4f484be0-6c42-013d-d600-0800270c66d6" xmi:uuid="4f484c80-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="589" y="209" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="571" y="218" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="357" y="126" width="229" height="121"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_36184_394488" xmi:uuid="63a03480-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398734_176891_226924"/>
      <ownedElement xmi:id="6392c2c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6392c3e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398734_176891_226924"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="6393be50-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6393bf80-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398734_176891_226924"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_514284_394489" xmi:uuid="63a022d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="50934060-6c42-013d-d600-0800270c66d6" xmi:uuid="509340e0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="723" y="154" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="831" y="176" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="667" y="168" width="172" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_422298_394491" xmi:uuid="63b94320-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398755_627641_226925"/>
      <ownedElement xmi:id="63abd0b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63abd1b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398755_627641_226925"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="63aceec0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63acefe0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398755_627641_226925"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_578614_394492" xmi:uuid="63b93ae0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="51c72690-6c42-013d-d600-0800270c66d6" xmi:uuid="51c72720-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="820" y="280" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="819" y="299" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="665" y="294" width="162" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_139040_394494" xmi:uuid="63bb1dc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398775_583231_226926"/>
      <ownedElement xmi:id="63ba27f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63ba28e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398775_583231_226926"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="63bb0bd0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63bb0cc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398775_583231_226926"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="665" y="329" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_556748_394495" xmi:uuid="642ac270-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398795_561145_226927"/>
      <ownedElement xmi:id="63c5efc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63c5f0c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398795_561145_226927"/>
        <text>li:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="63c6c390-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63c6c460-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398795_561145_226927"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="52a17ec0-6c42-013d-d600-0800270c66d6" xmi:uuid="52a17f50-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="52a1b670-6c42-013d-d600-0800270c66d6" xmi:uuid="52a1b6c0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_828580_394496" xmi:uuid="63df7570-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="63d26660-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63d26770-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="63ded450-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63ded590-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="329" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_744288_394497" xmi:uuid="64064e70-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="63f86a90-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="63f86e40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="6405aae0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6405ac20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="266" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_111476_394498" xmi:uuid="642aad10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="641e1d40-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="641e1e60-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="642a35f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="642a3970-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="294" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="238" width="336" height="126"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_931246_394499" xmi:uuid="645d04c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398815_359270_226928"/>
      <ownedElement xmi:id="6436af90-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6436b0a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398815_359270_226928"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="6437c820-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6437c930-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398815_359270_226928"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="580d1110-6c42-013d-d600-0800270c66d6" xmi:uuid="580d11a0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="582a9d80-6c42-013d-d600-0800270c66d6" xmi:uuid="582a9e50-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_449184_394500" xmi:uuid="645ce3e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="6450bad0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6450bbe0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="645c8580-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="645c8690-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="189" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="161" width="336" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_675545_410881" xmi:uuid="648edf10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398312_525754_226886"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_396725_394505"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_425067_394502"/>
      <waypoint x="1330" y="81"/>
      <waypoint x="1143" y="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_103507_394501" xmi:uuid="64900b50-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398834_156943_226929"/>
      <ownedElement xmi:id="64691350-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="64691460-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398834_156943_226929"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="6469fef0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="646a0090-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398834_156943_226929"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="5aba4510-6c42-013d-d600-0800270c66d6" xmi:uuid="5aba47c0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5abaa040-6c42-013d-d600-0800270c66d6" xmi:uuid="5abaa0f0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_425067_394502" xmi:uuid="648e6490-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="6481b280-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6481b380-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="648dd9b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="648ddac0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="70" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="42" width="336" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_396725_394505" xmi:uuid="651db8a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398852_942036_226930"/>
      <ownedElement xmi:id="649c0da0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="649c0ed0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398852_942036_226930"/>
        <text>measured_characteristic:Measured_characteristic</text>
      </ownedElement>
      <ownedElement xmi:id="649cf7b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="649cf8b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398852_942036_226930"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="5d50cb60-6c42-013d-d600-0800270c66d6" xmi:uuid="5d50cbf0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5d510980-6c42-013d-d600-0800270c66d6" xmi:uuid="5d5109d0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_132496_394506" xmi:uuid="64b68ca0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-description"/>
          <ownedElement xmi:id="64aa58a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="64aa59a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="64b62c20-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="64b62d20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1351" y="133" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_820104_394507" xmi:uuid="64cd8d10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-id"/>
          <ownedElement xmi:id="64c16f90-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="64c17080-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="64ccf790-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="64ccf8d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1351" y="377" width="95" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_270122_394508" xmi:uuid="64f63da0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-measured_coordinated_characteristic"/>
          <ownedElement xmi:id="64e7ac00-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="64e7ad40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-measured_coordinated_characteristic"/>
            <text>measured_coordinated_characteristic:Property_representation</text>
          </ownedElement>
          <ownedElement xmi:id="64f5d370-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="64f5d4a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-measured_coordinated_characteristic"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1351" y="588" width="386" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_571870_394509" xmi:uuid="651dacc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-measurement_activity"/>
          <ownedElement xmi:id="650faee0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="650fb010-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-measurement_activity"/>
            <text>measurement_activity:evaluation_activity_select</text>
          </ownedElement>
          <ownedElement xmi:id="651d38f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="651d3c40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Measured_characteristic-measurement_activity"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1351" y="519" width="314" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1330" y="42" width="414" height="581"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_549149_410885" xmi:uuid="657039d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398325_739695_226893"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_396725_394505"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_498733_394511"/>
      <waypoint x="1495" y="623"/>
      <waypoint x="1495" y="725"/>
      <waypoint x="1134" y="725"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_231407_394510" xmi:uuid="65717e20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398875_887203_226931"/>
      <ownedElement xmi:id="652a1120-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="652a1240-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398875_887203_226931"/>
        <text>dta2:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="652b2b70-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="652b2c80-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398875_887203_226931"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="64053570-6c42-013d-d600-0800270c66d6" xmi:uuid="64053610-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="64181850-6c42-013d-d600-0800270c66d6" xmi:uuid="64181920-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_498733_394511" xmi:uuid="654f4ca0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="6543bac0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6543bbd0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="654ee460-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="654ee9c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="714" width="175" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_636351_394512" xmi:uuid="656fcd40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="6563d900-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6563da10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="656f3190-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="656f32e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="672" width="192" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="637" width="336" height="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_84675_394513" xmi:uuid="659a87c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398893_206372_226932"/>
      <ownedElement xmi:id="657e7a70-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="657e7c20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398893_206372_226932"/>
        <text>dt:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="657fcb50-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="657fcc70-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398893_206372_226932"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="683a55f0-6c42-013d-d600-0800270c66d6" xmi:uuid="683a5690-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="683a8d30-6c42-013d-d600-0800270c66d6" xmi:uuid="683a8d80-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_916030_394514" xmi:uuid="659a6dd0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="658d7010-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="658d7140-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="6599c9c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6599cad0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="672" y="700" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="658" y="672" width="153" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_851011_394515" xmi:uuid="65a30100-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398508_699003_226913"/>
      <ownedElement xmi:id="659ea420-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="659ea520-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398508_699003_226913"/>
        <text>TestedPart:IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="659fb720-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="659fb880-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398508_699003_226913"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_581220_394516" xmi:uuid="65a2f740-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578045887816_8904_56634"/>
        <ownedElement xmi:id="69d75690-6c42-013d-d600-0800270c66d6" xmi:uuid="69d75730-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578045887816_8904_56634"/>
          <bounds x="266" y="1210" width="246" height="13"/>
          <text>individualPartView : Product_as_individual_view [1]</text>
        </ownedElement>
        <bounds x="248" y="1220" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="1211" width="221" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_779206_410889" xmi:uuid="663bc060-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398336_110335_226898"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_15685_394523"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_518133_394521"/>
      <waypoint x="1348" y="1156"/>
      <waypoint x="1348" y="1274"/>
      <waypoint x="1310" y="1274"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_43338_394518" xmi:uuid="663cf4e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398913_512887_226933"/>
      <ownedElement xmi:id="65adb720-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="65adb830-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398913_512887_226933"/>
        <text>paitr:Product_as_individual_test_result</text>
      </ownedElement>
      <ownedElement xmi:id="65ae8fe0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="65ae90b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398913_512887_226933"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="6a85b2e0-6c42-013d-d600-0800270c66d6" xmi:uuid="6a85b370-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="6a860980-6c42-013d-d600-0800270c66d6" xmi:uuid="6a860a50-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_82972_394519" xmi:uuid="65d37010-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-defined_version"/>
          <ownedElement xmi:id="65c691a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="65c692e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-defined_version"/>
            <text>defined_version:Product_version</text>
          </ownedElement>
          <ownedElement xmi:id="65d302f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="65d30410-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-defined_version"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="1303" width="226" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_778454_394520" xmi:uuid="65f7e860-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_as_individual_test_result-evaluated_product_definition"/>
          <ownedElement xmi:id="65eb17d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="65eb1900-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_as_individual_test_result-evaluated_product_definition"/>
            <text>evaluated_product_definition:Product_as_individual_view</text>
          </ownedElement>
          <ownedElement xmi:id="65f75a80-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="65f75e10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_as_individual_test_result-evaluated_product_definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="1219" width="351" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_518133_394521" xmi:uuid="66197d90-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_as_individual_test_result-evaluation_data"/>
          <ownedElement xmi:id="660e1560-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="660e1670-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_as_individual_test_result-evaluation_data"/>
            <text>evaluation_data:Evaluated_characteristic_of_product_as_individual_test_result</text>
          </ownedElement>
          <ownedElement xmi:id="66190350-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="66190460-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_as_individual_test_result-evaluation_data"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="1261" width="477" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_203059_394522" xmi:uuid="663b28c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
          <ownedElement xmi:id="662f36d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="662f37e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
            <text>initial_context:Initial_view_definition_context</text>
          </ownedElement>
          <ownedElement xmi:id="663aaf70-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="663ab0d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="1345" width="287" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="812" y="1183" width="505" height="197"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_613461_410891" xmi:uuid="66e0d930-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398334_153157_226897"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_396725_394505"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_745435_394525"/>
      <waypoint x="1495" y="623"/>
      <waypoint x="1495" y="1061"/>
      <waypoint x="1283" y="1061"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_15685_394523" xmi:uuid="66e20110-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398930_875565_226934"/>
      <ownedElement xmi:id="6649f6b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6649f7d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398930_875565_226934"/>
        <text>ecopaitr:Evaluated_characteristic_of_product_as_individual_test_result</text>
      </ownedElement>
      <ownedElement xmi:id="664b27e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="664b2920-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398930_875565_226934"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="7233c7d0-6c42-013d-d600-0800270c66d6" xmi:uuid="7233c880-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="72341780-6c42-013d-d600-0800270c66d6" xmi:uuid="72341850-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_723627_394524" xmi:uuid="667a2e80-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-evaluation_result"/>
          <ownedElement xmi:id="666ad6e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="666ad8a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-evaluation_result"/>
            <text>evaluation_result:evaluation_result_value</text>
          </ownedElement>
          <ownedElement xmi:id="6679ae00-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6679af60-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-evaluation_result"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="966" y="1086" width="270" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_745435_394525" xmi:uuid="669e7fa0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-measured_product_data"/>
          <ownedElement xmi:id="66903d00-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="66903e30-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-measured_product_data"/>
            <text>measured_product_data:Measured_characteristic</text>
          </ownedElement>
          <ownedElement xmi:id="669da630-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="669da950-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-measured_product_data"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="966" y="1051" width="317" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_824792_394526" xmi:uuid="66c05140-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-planned_product_data"/>
          <ownedElement xmi:id="66b4ea80-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="66b4eb80-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-planned_product_data"/>
            <text>planned_product_data:Planned_characteristic</text>
          </ownedElement>
          <ownedElement xmi:id="66bfd990-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="66bfdd80-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-planned_product_data"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="966" y="1015" width="292" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_484074_394527" xmi:uuid="66e07030-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-product_data_status"/>
          <ownedElement xmi:id="66d51a70-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="66d51b70-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-product_data_status"/>
            <text>product_data_status:evaluation_type</text>
          </ownedElement>
          <ownedElement xmi:id="66dfefd0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="66dff0d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-product_data_status"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="966" y="1121" width="244" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="987" width="439" height="169"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_20163_394528" xmi:uuid="66ed95f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398948_931612_226935"/>
      <ownedElement xmi:id="66ecaab0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="66ecad00-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398948_931612_226935"/>
        <text>erv:evaluation_result_value</text>
      </ownedElement>
      <ownedElement xmi:id="66ed8490-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="66ed8560-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398948_931612_226935"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="651" y="1085" width="267" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_268913_394529" xmi:uuid="66f91c10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398969_12690_226936"/>
      <ownedElement xmi:id="66f83630-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="66f83730-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398969_12690_226936"/>
        <text>et:evaluation_type</text>
      </ownedElement>
      <ownedElement xmi:id="66f90520-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="66f907b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398969_12690_226936"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="735" y="1120" width="185" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_955676_394530" xmi:uuid="67057700-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398989_824688_226937"/>
      <ownedElement xmi:id="670465b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="670466b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398989_824688_226937"/>
        <text>iwdc:Initial_view_definition_context</text>
      </ownedElement>
      <ownedElement xmi:id="67055470-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="67055570-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398989_824688_226937"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="1344" width="523" height="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_777824_394531" xmi:uuid="6712ca90-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399008_765169_226938"/>
      <ownedElement xmi:id="6711a480-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6711a970-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399008_765169_226938"/>
        <text>pv:Product_version</text>
      </ownedElement>
      <ownedElement xmi:id="6712a680-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="6712a7b0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399008_765169_226938"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="427" y="1260" width="343" height="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_831217_394532" xmi:uuid="6716f7c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398486_365405_226912"/>
      <ownedElement xmi:id="67144160-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="67144280-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398486_365405_226912"/>
        <text>PlannedCharacteristic:PlannedCharacteristic</text>
      </ownedElement>
      <ownedElement xmi:id="67155750-0d30-013c-5e2b-5b8e392dc4e5" xmi:uuid="67155880-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398486_365405_226912"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_633165_394533" xmi:uuid="6716f070-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399467_532755_226990"/>
        <ownedElement xmi:id="7c65b3d0-6c42-013d-d600-0800270c66d6" xmi:uuid="7c65b4b0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399467_532755_226990"/>
          <bounds x="345" y="1006" width="242" height="13"/>
          <text>plannedCharacteristic : Planned_characteristic [1]</text>
        </ownedElement>
        <bounds x="327" y="1015" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="1001" width="300" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_646295_410859" xmi:uuid="67170480-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398271_387784_226866"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_714173_394503"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_396725_394505"/>
      <waypoint x="1756" y="56"/>
      <waypoint x="1744" y="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_891682_410861" xmi:uuid="67171520-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398273_123425_226867"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_609584_394452"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_714010_394450"/>
      <waypoint x="665" y="438"/>
      <waypoint x="511" y="438"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_97265_410862" xmi:uuid="67172c00-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398275_995835_226868"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_939714_394455"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_617999_394453"/>
      <waypoint x="945" y="438"/>
      <waypoint x="792" y="438"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_792276_410863" xmi:uuid="67173a40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398277_152873_226869"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_106861_394448"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_94754_394437"/>
      <waypoint x="357" y="424"/>
      <waypoint x="168" y="424"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_170532_410866" xmi:uuid="67174740-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398279_634092_226870"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_180056_394462"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_757307_394466"/>
      <waypoint x="543" y="788"/>
      <waypoint x="665" y="788"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_219288_410867" xmi:uuid="67175b50-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398281_276526_226871"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_742805_394469"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_524489_394464"/>
      <waypoint x="665" y="910"/>
      <waypoint x="620" y="910"/>
      <waypoint x="620" y="816"/>
      <waypoint x="543" y="816"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_720637_410868" xmi:uuid="67176500-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398284_740555_226872"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_606408_394474"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_645521_394472"/>
      <waypoint x="959" y="942"/>
      <waypoint x="853" y="942"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_892162_410869" xmi:uuid="67177410-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398286_303204_226873"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_67718_394477"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_227921_394467"/>
      <waypoint x="945" y="791"/>
      <waypoint x="813" y="791"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_607647_410870" xmi:uuid="67177e70-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398288_132682_226874"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_128690_394476"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_699191_394470"/>
      <waypoint x="959" y="914"/>
      <waypoint x="840" y="914"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_601619_410871" xmi:uuid="67178640-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398290_65526_226875"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_104786_394460"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_511266_394444"/>
      <waypoint x="357" y="774"/>
      <waypoint x="209" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_414906_410872" xmi:uuid="67179030-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398292_530972_226876"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_916030_394514"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_123767_394458"/>
      <waypoint x="672" y="711"/>
      <waypoint x="616" y="711"/>
      <waypoint x="616" y="732"/>
      <waypoint x="543" y="732"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_680032_410873" xmi:uuid="67179910-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398294_947075_226877"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_422298_394491"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_442223_394486"/>
      <waypoint x="665" y="308"/>
      <waypoint x="655" y="308"/>
      <waypoint x="655" y="228"/>
      <waypoint x="586" y="228"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_393749_410874" xmi:uuid="6717b6a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398296_318521_226878"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_828580_394496"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_139040_394494"/>
      <waypoint x="959" y="340"/>
      <waypoint x="879" y="340"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_175190_410875" xmi:uuid="6717c220-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398298_486409_226879"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_514284_394489"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_931246_394499"/>
      <waypoint x="846" y="182"/>
      <waypoint x="945" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_439981_410876" xmi:uuid="6717ca80-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398300_18061_226880"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_111476_394498"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_578614_394492"/>
      <waypoint x="959" y="305"/>
      <waypoint x="834" y="305"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_490166_410877" xmi:uuid="6717d230-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398302_790730_226881"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_132496_394506"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_572655_394480"/>
      <waypoint x="1351" y="144"/>
      <waypoint x="586" y="144"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_305320_410878" xmi:uuid="6717d9e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398304_12231_226882"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_449184_394500"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_396725_394505"/>
      <waypoint x="1134" y="200"/>
      <waypoint x="1330" y="200"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_362773_410879" xmi:uuid="6717e160-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398306_389127_226883"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_744288_394497"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_396725_394505"/>
      <waypoint x="1187" y="277"/>
      <waypoint x="1330" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_779593_410880" xmi:uuid="6717ec70-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398308_678459_226884"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_7682_394482"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_508184_394436"/>
      <waypoint x="357" y="179"/>
      <waypoint x="241" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_712416_410882" xmi:uuid="6717f440-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398310_728418_226885"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_103507_394501"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_934739_394434"/>
      <waypoint x="945" y="84"/>
      <waypoint x="242" y="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_664687_410883" xmi:uuid="6717fbf0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398316_729083_226888"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_36184_394488"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_249713_394484"/>
      <waypoint x="667" y="179"/>
      <waypoint x="586" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_977641_410886" xmi:uuid="67180390-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398320_982884_226890"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_636351_394512"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_84675_394513"/>
      <waypoint x="959" y="683"/>
      <waypoint x="811" y="683"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_855902_410887" xmi:uuid="67180b10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398321_95070_226891"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_820104_394507"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_10549_394446"/>
      <waypoint x="1351" y="389"/>
      <waypoint x="511" y="389"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_992763_410888" xmi:uuid="67181580-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398323_117167_226892"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_571870_394509"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_101643_394439"/>
      <waypoint x="1351" y="529"/>
      <waypoint x="312" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_227884_410890" xmi:uuid="67181d30-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398331_11657_226896"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_778454_394520"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_581220_394516"/>
      <waypoint x="833" y="1232"/>
      <waypoint x="263" y="1232"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_439338_410892" xmi:uuid="67182480-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398340_62709_226900"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_723627_394524"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_20163_394528"/>
      <waypoint x="966" y="1096"/>
      <waypoint x="918" y="1096"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_552006_410893" xmi:uuid="67182bc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398341_350155_226901"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_484074_394527"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_268913_394529"/>
      <waypoint x="966" y="1131"/>
      <waypoint x="920" y="1131"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_693808_410894" xmi:uuid="67183700-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398343_632966_226902"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_82972_394519"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_777824_394531"/>
      <waypoint x="833" y="1316"/>
      <waypoint x="770" y="1316"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_187444_410895" xmi:uuid="67183eb0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398345_188142_226903"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_203059_394522"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_955676_394530"/>
      <waypoint x="833" y="1358"/>
      <waypoint x="768" y="1358"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_418683_410896" xmi:uuid="67184a50-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398338_530747_226899"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_824792_394526"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_633165_394533"/>
      <waypoint x="966" y="1026"/>
      <waypoint x="342" y="1026"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_714173_394503" xmi:uuid="6718e1d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398466_75669_226911"/>
      <bounds x="1756" y="48" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1759" height="1433"/>
    <name>MeasuredCharacteristic</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564400201_889510_227030" xmi:uuid="671981f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564028971_278852_179014"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_453843_394574" xmi:uuid="671cb350-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399738_647405_227010"/>
      <ownedElement xmi:id="17c86270-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="17c863a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399738_647405_227010"/>
        <text>ActualCharacteristic:MeasuredCharacteristic</text>
      </ownedElement>
      <ownedElement xmi:id="17c96ed0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="17c97010-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399738_647405_227010"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_569575_394575" xmi:uuid="17cac620-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398466_75669_226911"/>
        <ownedElement xmi:id="7e5d8c80-6c42-013d-d600-0800270c66d6" xmi:uuid="7e5d8d30-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564398466_75669_226911"/>
          <bounds x="339" y="90" width="263" height="13"/>
          <text>measuredCharacteristic : Measured_characteristic [1]</text>
        </ownedElement>
        <bounds x="321" y="99" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="91" width="294" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_330280_394577" xmi:uuid="671cb6a0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400449_513307_227083"/>
      <ownedElement xmi:id="17d70640-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="17d70750-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400449_513307_227083"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="17d7ef20-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="17d7f430-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400449_513307_227083"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_11089_394578" xmi:uuid="17e503a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="805f5c40-6c42-013d-d600-0800270c66d6" xmi:uuid="805f5ce0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="245" y="150" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="227" y="159" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="147" width="200" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_20295_394580" xmi:uuid="671cb960-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400430_438502_227082"/>
      <ownedElement xmi:id="17f1c820-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="17f1c940-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400430_438502_227082"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="17f2d060-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="17f2d1c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400430_438502_227082"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="292" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_619952_410911" xmi:uuid="1804e430-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400389_325909_227063"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_645936_394591"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_508039_394582"/>
      <waypoint x="1449" y="482"/>
      <waypoint x="302" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_727505_394581" xmi:uuid="671cbe50-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400470_65525_227084"/>
      <ownedElement xmi:id="17f46ca0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="17f46da0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400470_65525_227084"/>
        <text>EvaluationResult:EvaluationResultEnum</text>
      </ownedElement>
      <ownedElement xmi:id="17f56610-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="17f56730-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400470_65525_227084"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="81480f90-6c42-013d-d600-0800270c66d6" xmi:uuid="81481010-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="81485b30-6c42-013d-d600-0800270c66d6" xmi:uuid="81485c00-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_508039_394582" xmi:uuid="18048740-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399697_370619_227005"/>
          <ownedElement xmi:id="18030630-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="18030760-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399697_370619_227005"/>
            <text>arm_mapping:evaluation_result_value</text>
          </ownedElement>
          <ownedElement xmi:id="180400c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="18040340-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399697_370619_227005"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="57" y="470" width="245" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="441" width="274" height="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_154508_394583" xmi:uuid="671cc110-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399760_345928_227014"/>
      <ownedElement xmi:id="1812da70-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1812db80-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399760_345928_227014"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="1813c220-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1813c340-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399760_345928_227014"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="616" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_843772_394584" xmi:uuid="671cc3c0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399717_974372_227008"/>
      <ownedElement xmi:id="1820f330-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1820f430-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399717_974372_227008"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="1821f610-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1821f720-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399717_974372_227008"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="793" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_65029_394585" xmi:uuid="671cc670-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400510_263796_227086"/>
      <ownedElement xmi:id="18235b60-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="18235c80-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400510_263796_227086"/>
        <text>PlannedCharacteristic:PlannedCharacteristic</text>
      </ownedElement>
      <ownedElement xmi:id="18240bb0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="18240cb0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400510_263796_227086"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_74291_394586" xmi:uuid="18256270-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399467_532755_226990"/>
        <ownedElement xmi:id="847f0330-6c42-013d-d600-0800270c66d6" xmi:uuid="847f0500-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564399467_532755_226990"/>
          <bounds x="336" y="978" width="242" height="13"/>
          <text>plannedCharacteristic : Planned_characteristic [1]</text>
        </ownedElement>
        <bounds x="325" y="991" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="987" width="298" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_56645_394588" xmi:uuid="671cce20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400529_979264_227087"/>
      <ownedElement xmi:id="1830c640-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1830c770-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400529_979264_227087"/>
        <text>evaluated_characteristic:Evaluated_characteristic</text>
      </ownedElement>
      <ownedElement xmi:id="18318d90-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="18318ea0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400529_979264_227087"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="8616a8a0-6c42-013d-d600-0800270c66d6" xmi:uuid="8616a960-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="8616fc40-6c42-013d-d600-0800270c66d6" xmi:uuid="8616fd30-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_209688_394589" xmi:uuid="184a5f40-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-description"/>
          <ownedElement xmi:id="183dfc10-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="183dfd10-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="184a1270-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="184a14c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1449" y="224" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_645936_394591" xmi:uuid="186fb100-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-evaluation_result"/>
          <ownedElement xmi:id="1862d790-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1862d8b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-evaluation_result"/>
            <text>evaluation_result:evaluation_result_value</text>
          </ownedElement>
          <ownedElement xmi:id="186f4df0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="186f4f20-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-evaluation_result"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1449" y="462" width="264" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_510429_394592" xmi:uuid="188922c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-id"/>
          <ownedElement xmi:id="187c40d0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="187c4200-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="1888c7b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1888c8d0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1449" y="602" width="94" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026348_979524_394593" xmi:uuid="18a29330-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-name"/>
          <ownedElement xmi:id="1895d710-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1895d860-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="18a23f20-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="18a24040-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-name"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1449" y="728" width="115" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_427752_394594" xmi:uuid="18c77f90-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-planned_product_data"/>
          <ownedElement xmi:id="18ba9400-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="18ba9530-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-planned_product_data"/>
            <text>planned_product_data:Planned_characteristic</text>
          </ownedElement>
          <ownedElement xmi:id="18c73980-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="18c73a80-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-planned_product_data"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1449" y="987" width="286" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_471143_394595" xmi:uuid="18ec7f80-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-product_data_status"/>
          <ownedElement xmi:id="18dfb0f0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="18dfb200-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-product_data_status"/>
            <text>product_data_status:evaluation_type</text>
          </ownedElement>
          <ownedElement xmi:id="18ec1ed0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="18ec1ff0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-product_data_status"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1449" y="553" width="238" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_565159_394596" xmi:uuid="1913e1a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-measured_product_data"/>
          <ownedElement xmi:id="19068750-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="190688d0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-measured_product_data"/>
            <text>measured_product_data:Measured_characteristic</text>
          </ownedElement>
          <ownedElement xmi:id="191383b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="191384c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Evaluated_characteristic-measured_product_data"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1449" y="91" width="311" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1428" y="49" width="370" height="973"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_967473_410912" xmi:uuid="1925f160-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400391_813334_227064"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026349_471143_394595"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_366218_394598"/>
      <waypoint x="1449" y="566"/>
      <waypoint x="258" y="566"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_829591_394597" xmi:uuid="671cd110-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400490_108398_227085"/>
      <ownedElement xmi:id="19156cc0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="19156dd0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400490_108398_227085"/>
        <text>EvaluationStatus:EvaluationStatusEnum</text>
      </ownedElement>
      <ownedElement xmi:id="19167e80-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="19167f90-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400490_108398_227085"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="9186caa0-6c42-013d-d600-0800270c66d6" xmi:uuid="9186cb40-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="91872760-6c42-013d-d600-0800270c66d6" xmi:uuid="91872840-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_366218_394598" xmi:uuid="1925a510-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400977_438659_227117"/>
          <ownedElement xmi:id="19245120-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="19245250-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400977_438659_227117"/>
            <text>arm_mapping:evaluation_type</text>
          </ownedElement>
          <ownedElement xmi:id="19253f10-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="19254040-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400977_438659_227117"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="57" y="554" width="201" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="525" width="251" height="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_514097_394599" xmi:uuid="671cd3f0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400571_615512_227089"/>
      <ownedElement xmi:id="19355680-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="193557a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400571_615512_227089"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_720443_394600" xmi:uuid="1944eab0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="93827fc0-6c42-013d-d600-0800270c66d6" xmi:uuid="93828050-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="547" y="285" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="529" y="294" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_339747_394602" xmi:uuid="19520d70-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="94163cd0-6c42-013d-d600-0800270c66d6" xmi:uuid="94163d60-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="547" y="223" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="529" y="232" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_138756_394604" xmi:uuid="195edc20-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="94c4ca00-6c42-013d-d600-0800270c66d6" xmi:uuid="94c4caa0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="551" y="348" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="529" y="354" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_440135_394606" xmi:uuid="196be6e0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="95da4b30-6c42-013d-d600-0800270c66d6" xmi:uuid="95da4bc0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="261" y="288" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="315" y="297" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="315" y="224" width="229" height="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_16228_394608" xmi:uuid="671cd870-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400588_656129_227090"/>
      <ownedElement xmi:id="19786390-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="197864b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400588_656129_227090"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_792260_394609" xmi:uuid="1985d4a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="974eb9f0-6c42-013d-d600-0800270c66d6" xmi:uuid="974eba90-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="479" y="656" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="461" y="665" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_523669_394611" xmi:uuid="1992e6a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="97e64290-6c42-013d-d600-0800270c66d6" xmi:uuid="97e64320-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="479" y="605" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="461" y="614" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_384269_394613" xmi:uuid="199fddc0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="987028b0-6c42-013d-d600-0800270c66d6" xmi:uuid="98702930-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="261" y="612" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="315" y="621" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="315" y="602" width="161" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_743469_394615" xmi:uuid="671cdb50-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400606_632804_227091"/>
      <ownedElement xmi:id="19ac26a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="19ac27b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400606_632804_227091"/>
        <text>selectDescription1:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_61530_394616" xmi:uuid="19b99880-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="99decff0-6c42-013d-d600-0800270c66d6" xmi:uuid="99ded090-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="553" y="782" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="535" y="791" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_494146_394618" xmi:uuid="19c61110-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="9a4a14e0-6c42-013d-d600-0800270c66d6" xmi:uuid="9a4a1570-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="553" y="727" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="535" y="736" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_861022_394620" xmi:uuid="19d38f40-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="9affc4a0-6c42-013d-d600-0800270c66d6" xmi:uuid="9affc530-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="557" y="846" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="535" y="852" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_827861_394622" xmi:uuid="19e03130-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="9b7f1b10-6c42-013d-d600-0800270c66d6" xmi:uuid="9b7f1bb0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="261" y="789" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="315" y="798" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="315" y="728" width="235" height="154"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_815266_394624" xmi:uuid="671cddf0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400625_349858_227092"/>
      <ownedElement xmi:id="19ecb080-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="19ecb180-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400625_349858_227092"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="19eda6b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="19eda7b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400625_349858_227092"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_507790_394625" xmi:uuid="19fac670-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="9cd79f80-6c42-013d-d600-0800270c66d6" xmi:uuid="9cd7a0c0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="707" y="273" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="801" y="293" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="637" y="287" width="172" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_885695_394627" xmi:uuid="671ce1e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400644_199243_227093"/>
      <ownedElement xmi:id="1a069010-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a069120-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400644_199243_227093"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="1a07a660-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a07a7a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400644_199243_227093"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_571948_394628" xmi:uuid="1a141fc0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="9e2f27f0-6c42-013d-d600-0800270c66d6" xmi:uuid="9e2f28a0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="809" y="379" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="791" y="388" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="637" y="385" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_134458_394630" xmi:uuid="671ce480-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400662_783873_227094"/>
      <ownedElement xmi:id="1a20f0f0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a20f210-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400662_783873_227094"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="1a220a60-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a220b90-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400662_783873_227094"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_18587_394631" xmi:uuid="1a2f5090-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="9f9128f0-6c42-013d-d600-0800270c66d6" xmi:uuid="9f912990-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="702" y="644" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="752" y="668" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="637" y="665" width="123" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_269949_394633" xmi:uuid="671ce710-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400682_678496_227095"/>
      <ownedElement xmi:id="1a3bac60-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a3bad80-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400682_678496_227095"/>
        <text>descriptors1:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="1a3c98b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a3c99b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400682_678496_227095"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_132601_394634" xmi:uuid="1a497a70-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="a10128d0-6c42-013d-d600-0800270c66d6" xmi:uuid="a1012960-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="714" y="770" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="807" y="790" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="637" y="784" width="178" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_721133_394636" xmi:uuid="671ceb20-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400701_581885_227096"/>
      <ownedElement xmi:id="1a55e1c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a55e2d0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400701_581885_227096"/>
        <text>language1:Language</text>
      </ownedElement>
      <ownedElement xmi:id="1a56f470-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a56f590-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400701_581885_227096"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_470609_394637" xmi:uuid="1a63a610-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="a2604190-6c42-013d-d600-0800270c66d6" xmi:uuid="a2604230-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="815" y="893" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="797" y="902" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="637" y="896" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_767354_410913" xmi:uuid="1a97aa80-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400364_835200_227054"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_56645_394588"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_28787_394640"/>
      <waypoint x="1428" y="189"/>
      <waypoint x="1296" y="189"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_225075_394639" xmi:uuid="671cee40-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400720_246412_227097"/>
      <ownedElement xmi:id="1a705640-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a705750-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400720_246412_227097"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="1a713d20-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a713e40-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400720_246412_227097"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a3038560-6c42-013d-d600-0800270c66d6" xmi:uuid="a3038610-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a303c2c0-6c42-013d-d600-0800270c66d6" xmi:uuid="a303c320-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_28787_394640" xmi:uuid="1a975a50-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="1a8a4cc0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a8a4df0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="1a96fbb0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1a96fce0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1112" y="175" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1098" y="147" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_37256_410914" xmi:uuid="1accfa30-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400380_781798_227059"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_56645_394588"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_668396_394642"/>
      <waypoint x="1428" y="301"/>
      <waypoint x="1287" y="301"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_110542_394641" xmi:uuid="671cf410-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400741_474314_227098"/>
      <ownedElement xmi:id="1aa4fbc0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1aa4fce0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400741_474314_227098"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="1aa5e2a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1aa5e3c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400741_474314_227098"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a6018fa0-6c42-013d-d600-0800270c66d6" xmi:uuid="a6019030-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a601c690-6c42-013d-d600-0800270c66d6" xmi:uuid="a601c6c0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_668396_394642" xmi:uuid="1acca660-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="1abf9290-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1abf93a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="1acc4f20-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1acc5020-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1112" y="294" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1098" y="266" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_852682_410915" xmi:uuid="1b409da0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400357_830704_227051"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026350_371313_394647"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_187979_394644"/>
      <waypoint x="1075" y="438"/>
      <waypoint x="1112" y="438"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_402261_410916" xmi:uuid="1b421830-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400386_928126_227062"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_56645_394588"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026350_132429_394645"/>
      <waypoint x="1428" y="375"/>
      <waypoint x="1340" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_592161_394643" xmi:uuid="671cf8e0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400759_21405_227099"/>
      <ownedElement xmi:id="1ada3580-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1ada37f0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400759_21405_227099"/>
        <text>li:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="1adb2850-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1adb2970-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400759_21405_227099"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="a88fe2e0-6c42-013d-d600-0800270c66d6" xmi:uuid="a88fe390-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a8902b60-6c42-013d-d600-0800270c66d6" xmi:uuid="a8902c20-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026349_187979_394644" xmi:uuid="1af5ba00-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="1ae8b8a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1ae8b9d0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="1af565e0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1af56700-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1112" y="420" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_132429_394645" xmi:uuid="1b1aa7e0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="1b0d4910-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b0d4af0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="1b19d0e0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b19d4f0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1112" y="364" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_593991_394646" xmi:uuid="1b405160-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="1b332600-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b332730-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="1b3fee10-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b3fef10-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1112" y="392" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1098" y="336" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_371313_394647" xmi:uuid="671cfbc0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400778_642841_227100"/>
      <ownedElement xmi:id="1b441db0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b441ed0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400778_642841_227100"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="1b450f90-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b4510c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400778_642841_227100"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="861" y="427" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_812049_410917" xmi:uuid="1b799a90-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400401_119065_227069"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_56645_394588"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026350_907623_394649"/>
      <waypoint x="1428" y="679"/>
      <waypoint x="1295" y="679"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_477375_394648" xmi:uuid="671cfe80-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400798_954592_227101"/>
      <ownedElement xmi:id="1b520fd0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b521110-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400798_954592_227101"/>
        <text>ia:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="1b52deb0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b52df90-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400798_954592_227101"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ae439b10-6c42-013d-d600-0800270c66d6" xmi:uuid="ae439ba0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ae43f9e0-6c42-013d-d600-0800270c66d6" xmi:uuid="ae43faa0-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_907623_394649" xmi:uuid="1b793c90-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="1b6c14c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b6c15e0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="1b78bc90-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b78be10-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1112" y="665" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1098" y="630" width="249" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_277753_410918" xmi:uuid="1bae9260-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400410_442212_227074"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_56645_394588"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026350_568028_394651"/>
      <waypoint x="1428" y="802"/>
      <waypoint x="1294" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_402375_394650" xmi:uuid="671d02d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400816_287691_227102"/>
      <ownedElement xmi:id="1b8738d0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b8739e0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400816_287691_227102"/>
        <text>dta1:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="1b883750-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1b883870-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400816_287691_227102"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b10d50f0-6c42-013d-d600-0800270c66d6" xmi:uuid="b10d5190-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b10d9ec0-6c42-013d-d600-0800270c66d6" xmi:uuid="b10da160-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_568028_394651" xmi:uuid="1bae5000-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="1ba112a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1ba113c0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="1bae06e0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1bae07f0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1119" y="791" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1098" y="763" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_804203_410919" xmi:uuid="1c2296a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400359_82771_227052"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026350_92173_394656"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026350_813189_394653"/>
      <waypoint x="1084" y="872"/>
      <waypoint x="1113" y="872"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_306813_410920" xmi:uuid="1c23cf80-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400419_109769_227077"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_56645_394588"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026350_924109_394654"/>
      <waypoint x="1428" y="945"/>
      <waypoint x="1341" y="945"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_829096_394652" xmi:uuid="671d05d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400835_530325_227103"/>
      <ownedElement xmi:id="1bbc3ba0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1bbc3de0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400835_530325_227103"/>
        <text>li1:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="1bbd3310-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1bbd3440-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400835_530325_227103"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b3e72860-6c42-013d-d600-0800270c66d6" xmi:uuid="b3e72910-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b3e7bc40-6c42-013d-d600-0800270c66d6" xmi:uuid="b3e7bd00-6c42-013d-d600-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_813189_394653" xmi:uuid="1bd83160-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="1bcabdb0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1bcabee0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="1bd7ca00-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1bd7cb20-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1113" y="861" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_924109_394654" xmi:uuid="1bfc9f00-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="1bef7b00-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1bef7c10-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="1bfc1dd0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1bfc1f00-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1113" y="931" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_22974_394655" xmi:uuid="1c224e10-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="1c14f470-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1c14f750-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="1c21b5a0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1c21b790-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1113" y="896" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1099" y="833" width="249" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_92173_394656" xmi:uuid="671d0870-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400854_856380_227104"/>
      <ownedElement xmi:id="1c25d8b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1c25d9b0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400854_856380_227104"/>
        <text>theAttribute1:String</text>
      </ownedElement>
      <ownedElement xmi:id="1c26af90-24a2-013c-5bfd-2bb9f4d923a9" xmi:uuid="1c26b0d0-24a2-013c-5bfd-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400854_856380_227104"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="896" y="861" width="188" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_275806_410921" xmi:uuid="671d1130-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400361_898865_227053"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026349_225075_394639"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_11089_394578"/>
      <waypoint x="1098" y="168"/>
      <waypoint x="242" y="168"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_307647_410922" xmi:uuid="671d1d00-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400368_97889_227055"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_20295_394580"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_440135_394606"/>
      <waypoint x="241" y="304"/>
      <waypoint x="315" y="304"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_360398_410923" xmi:uuid="671d26d0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400372_180367_227056"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_209688_394589"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_339747_394602"/>
      <waypoint x="1449" y="242"/>
      <waypoint x="544" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_273493_410924" xmi:uuid="671d3000-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400375_382130_227057"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026349_815266_394624"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_720443_394600"/>
      <waypoint x="637" y="301"/>
      <waypoint x="544" y="301"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_193310_410925" xmi:uuid="671d3850-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400378_581967_227058"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026349_110542_394641"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_507790_394625"/>
      <waypoint x="1098" y="301"/>
      <waypoint x="816" y="301"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_810913_410926" xmi:uuid="671d4680-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400382_775927_227060"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026349_885695_394627"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_138756_394604"/>
      <waypoint x="637" y="399"/>
      <waypoint x="620" y="399"/>
      <waypoint x="620" y="361"/>
      <waypoint x="544" y="361"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_702481_410927" xmi:uuid="671d4ee0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400384_213910_227061"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026350_593991_394646"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_571948_394628"/>
      <waypoint x="1112" y="396"/>
      <waypoint x="806" y="396"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_882614_410928" xmi:uuid="671d5720-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400392_586891_227065"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_154508_394583"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_384269_394613"/>
      <waypoint x="168" y="627"/>
      <waypoint x="315" y="627"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_723803_410929" xmi:uuid="671d5f80-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400394_341443_227066"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_510429_394592"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_523669_394611"/>
      <waypoint x="1449" y="620"/>
      <waypoint x="476" y="620"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_822115_410930" xmi:uuid="671d7150-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400397_159095_227067"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026349_134458_394630"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_792260_394609"/>
      <waypoint x="637" y="676"/>
      <waypoint x="476" y="676"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_784479_410931" xmi:uuid="671d7b30-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400399_446420_227068"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026350_477375_394648"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_18587_394631"/>
      <waypoint x="1098" y="676"/>
      <waypoint x="767" y="676"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_637708_410932" xmi:uuid="671d8330-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400403_324742_227070"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_979524_394593"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_494146_394618"/>
      <waypoint x="1449" y="742"/>
      <waypoint x="550" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_572920_410933" xmi:uuid="671d8b50-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400405_280472_227071"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_843772_394584"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_827861_394622"/>
      <waypoint x="209" y="804"/>
      <waypoint x="315" y="804"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_353800_410934" xmi:uuid="671d9690-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400406_73074_227072"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026349_269949_394633"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_61530_394616"/>
      <waypoint x="637" y="798"/>
      <waypoint x="550" y="798"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_270318_410935" xmi:uuid="671d9e30-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400408_703861_227073"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026350_402375_394650"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_132601_394634"/>
      <waypoint x="1098" y="798"/>
      <waypoint x="822" y="798"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_733446_410936" xmi:uuid="671da760-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400414_295558_227075"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026349_721133_394636"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_861022_394620"/>
      <waypoint x="637" y="907"/>
      <waypoint x="623" y="907"/>
      <waypoint x="623" y="861"/>
      <waypoint x="550" y="861"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_437430_410937" xmi:uuid="671db090-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400417_161761_227076"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026350_22974_394655"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026349_470609_394637"/>
      <waypoint x="1113" y="910"/>
      <waypoint x="812" y="910"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_74270_410938" xmi:uuid="671dbc10-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400421_766477_227078"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026349_427752_394594"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_74291_394586"/>
      <waypoint x="1449" y="998"/>
      <waypoint x="340" y="998"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026943_738032_410939" xmi:uuid="671dc380-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400424_813841_227079"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026348_56645_394588"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026350_266991_394657"/>
      <waypoint x="1798" y="70"/>
      <waypoint x="1815" y="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026944_712029_410940" xmi:uuid="671dcaf0-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400426_192853_227080"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026349_565159_394596"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026348_569575_394575"/>
      <waypoint x="1449" y="105"/>
      <waypoint x="336" y="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026350_266991_394657" xmi:uuid="671e3100-0d30-013c-5e2b-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400551_5510_227088"/>
      <bounds x="1815" y="63" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1818" height="1037"/>
    <name>EvaluatedCharacteristic</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
