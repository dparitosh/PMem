<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1688564042627_809624_182513" xmi:uuid="39ee9550-0d33-013c-5e3a-5b8e392dc4e5">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1688563978893_923988_164779"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1690206121550_793802_84291"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703186394138_473680_480605" xmi:uuid="8d6c4dc0-915f-013c-7166-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703186394131_22671_480594"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1690206121550_793802_84291"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446460985_293060_371093" xmi:uuid="0363be20-6c42-013d-931e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446460977_929152_371082"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978646_681818_164724"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446458802_660153_370071" xmi:uuid="0665a480-6c42-013d-931e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446458794_351751_370060"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978643_218886_164720"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446458973_936606_370270" xmi:uuid="0c096dd0-6c42-013d-931e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446458964_69327_370259"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978647_712427_164727"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446460482_21043_370468" xmi:uuid="0fdf66c0-6c42-013d-931e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446460475_158514_370457"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978634_182132_164713"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446460627_355068_370666" xmi:uuid="13b07cd0-6c42-013d-931e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446460620_248670_370655"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978649_661250_164728"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446460829_626670_370880" xmi:uuid="1c0fa4e0-6c42-013d-931e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446460821_501243_370869"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978638_556285_164715"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432568_441185_233031" xmi:uuid="3a4a1bb0-0d33-013c-5e3a-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564041725_91562_182144"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978635_428470_164714"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432681_432809_233161" xmi:uuid="3a4c7220-0d33-013c-5e3a-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564042344_896532_182393"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978646_681818_164724"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432647_407121_233123" xmi:uuid="3a8e4b70-0d33-013c-5e3a-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564042205_726246_182342"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978643_218886_164720"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432701_429899_233182" xmi:uuid="3a98e440-0d33-013c-5e3a-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564042468_319443_182437"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978647_712427_164727"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432549_822496_233014" xmi:uuid="3a9a25c0-0d33-013c-5e3a-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564041619_834759_182104"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978634_182132_164713"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432725_375658_233201" xmi:uuid="3a9ae750-0d33-013c-5e3a-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564042575_393765_182476"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978649_661250_164728"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432636_96394_233104" xmi:uuid="3a9bb010-0d33-013c-5e3a-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564042116_660101_182301"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978642_323259_164718"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432595_272190_233055" xmi:uuid="3aa653c0-0d33-013c-5e3a-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564041929_110566_182218"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978638_556285_164715"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446462622_179457_371426" xmi:uuid="fd141330-6c41-013d-931e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446462615_643744_371415"/>
    <defaultNamespace href="Topology.xmi#_18_4_1_65b021e_1688563978635_428470_164714"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1688563978893_923988_164779" xmi:uuid="39ee8ae0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1690206121550_793802_84291"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025809_510078_365180" xmi:uuid="39f03bd0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978642_323259_164718"/>
      <ownedElement xmi:id="39efb560-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="39efb650-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978642_323259_164718"/>
        <text>TopologicalRepresentationItem</text>
      </ownedElement>
      <ownedElement xmi:id="39efdd60-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="39efde00-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="455" y="265" width="143" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_274620_365181" xmi:uuid="3a01d640-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_RepresentationItem"/>
      <ownedElement xmi:id="39f515c0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="39f517c0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_RepresentationItem"/>
        <text>RepresentationItem</text>
      </ownedElement>
      <ownedElement xmi:id="39f623c0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="39f624c0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="406" y="140" width="252" height="45"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_806071_365183" xmi:uuid="3a02e250-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978647_712427_164727"/>
      <ownedElement xmi:id="3a021280-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a021320-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978647_712427_164727"/>
        <text>Edge</text>
      </ownedElement>
      <ownedElement xmi:id="3a023920-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a0239b0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="483" y="357" width="119" height="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_926954_365184" xmi:uuid="3a039bc0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978643_218886_164720"/>
      <ownedElement xmi:id="3a0318b0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a031950-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978643_218886_164720"/>
        <text>Vertex</text>
      </ownedElement>
      <ownedElement xmi:id="3a033ed0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a033f70-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="686" y="364" width="98" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_238094_365185" xmi:uuid="3a048870-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978635_428470_164714"/>
      <ownedElement xmi:id="3a03d5e0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a03d920-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978635_428470_164714"/>
        <text>ConnectedEdgeSet</text>
      </ownedElement>
      <ownedElement xmi:id="3a03fff0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a040090-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="357" y="462" width="119" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_550448_365186" xmi:uuid="3a05f1f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978638_556285_164715"/>
      <ownedElement xmi:id="3a04bb40-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a04bbe0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978638_556285_164715"/>
        <text>Path</text>
      </ownedElement>
      <ownedElement xmi:id="3a04e1d0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a04e270-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="3a05bcf0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a05bd80-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3a05bef0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a05bf40-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>values</text>
        </ownedElement>
        <ownedElement xmi:id="3a05ef30-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a05efd0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042050_62160_182278"/>
          <text>OrientationList</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="203" y="357" width="166" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_536010_365187" xmi:uuid="3a06a0c0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978645_512578_164723"/>
      <ownedElement xmi:id="3a062d50-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a062df0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978645_512578_164723"/>
        <text>EdgeBasedWeightedGraphRepresentationItemsSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e1bf5330-6c41-013d-931e-0800270c66d6" xmi:uuid="e1bf5460-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e1e86e70-6c41-013d-931e-0800270c66d6" xmi:uuid="e1e86f00-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="56" y="287" width="292" height="24"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_621119_365194" xmi:uuid="3a079c40-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978649_661250_164728"/>
      <ownedElement xmi:id="3a06d310-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a06d3c0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978649_661250_164728"/>
        <text>SubEdge</text>
      </ownedElement>
      <ownedElement xmi:id="3a070690-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a070750-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="574" y="483" width="98" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_223219_365206" xmi:uuid="3a088d50-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978646_681818_164724"/>
      <ownedElement xmi:id="3a07d5e0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a07d680-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978646_681818_164724"/>
        <text>EdgeBasedTopologicalRepresentationWithLengthConstraint</text>
      </ownedElement>
      <ownedElement xmi:id="3a07fb60-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a07fc00-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="42" y="189" width="269" height="50"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_146184_365215" xmi:uuid="3a2d87c0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978634_182132_164713"/>
      <ownedElement xmi:id="3a2cc430-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a2cc500-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978634_182132_164713"/>
        <text>ConnectedEdgeSubSet</text>
      </ownedElement>
      <ownedElement xmi:id="3a2cfa50-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a2cfaf0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="357" y="559" width="119" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025811_614887_365219" xmi:uuid="3a355940-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_VertexPoint"/>
      <ownedElement xmi:id="3a2eca70-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a2ecb50-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_VertexPoint"/>
        <text>VertexPoint</text>
      </ownedElement>
      <ownedElement xmi:id="e2d6ca70-6c41-013d-931e-0800270c66d6" xmi:uuid="e2d6cb00-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="616" y="557" width="203" height="97"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025811_48987_365221" xmi:uuid="3a3da4d0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_GeometricRepresentation"/>
      <ownedElement xmi:id="3a3683e0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a3684b0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_GeometricRepresentation"/>
        <text>GeometricRepresentation</text>
      </ownedElement>
      <ownedElement xmi:id="e3738ca0-6c41-013d-931e-0800270c66d6" xmi:uuid="e3738d40-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="49" y="91" width="252" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_827965_400604" xmi:uuid="3a3e35f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042079_3752_182290"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_926954_365184"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025809_510078_365180"/>
      <waypoint x="727" y="364"/>
      <waypoint x="727" y="328"/>
      <waypoint x="526" y="328"/>
      <waypoint x="526" y="298"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_895273_400605" xmi:uuid="3a3e9fb0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041848_576775_182206"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_550448_365186"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025809_510078_365180"/>
      <waypoint x="263" y="357"/>
      <waypoint x="263" y="328"/>
      <waypoint x="526" y="328"/>
      <waypoint x="526" y="298"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_109821_400606" xmi:uuid="3a401b10-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042079_747046_182287"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_274620_365181"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025809_510078_365180"/>
      <waypoint x="525" y="185"/>
      <waypoint x="525" y="265"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_214499_400607" xmi:uuid="3a408ad0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042079_706621_182288"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_806071_365183"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025809_510078_365180"/>
      <waypoint x="529" y="357"/>
      <waypoint x="529" y="328"/>
      <waypoint x="526" y="328"/>
      <waypoint x="526" y="298"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_106086_400608" xmi:uuid="3a40f670-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041669_443808_182132"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_238094_365185"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025809_510078_365180"/>
      <waypoint x="419" y="462"/>
      <waypoint x="419" y="328"/>
      <waypoint x="526" y="328"/>
      <waypoint x="526" y="298"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_650299_400609" xmi:uuid="3a4173e0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978643_113192_164719"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_76703_365188" xmi:uuid="3a4160a0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042163_320724_182329"/>
        <bounds x="643" y="388" width="40" height="12"/>
        <text>EdgeStart</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_703446_365189" xmi:uuid="3a416810-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042163_320724_182329"/>
        <bounds x="658" y="406" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_848798_365190" xmi:uuid="3a4170a0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042162_689703_182328"/>
        <bounds x="605" y="406" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_806071_365183"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_926954_365184"/>
      <waypoint x="602" y="403"/>
      <waypoint x="686" y="403"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_241278_400610" xmi:uuid="3a41f4d0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978641_731913_164716"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_882696_365191" xmi:uuid="3a41df90-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042070_199737_182284"/>
        <bounds x="646" y="356" width="37" height="12"/>
        <text>EdgeEnd</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_783939_365192" xmi:uuid="3a41e600-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042070_199737_182284"/>
        <bounds x="658" y="373" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_566724_365193" xmi:uuid="3a41eef0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042069_605708_182283"/>
        <bounds x="605" y="374" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_806071_365183"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_926954_365184"/>
      <waypoint x="602" y="371"/>
      <waypoint x="686" y="371"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_433175_400611" xmi:uuid="3a4271b0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978641_630454_164717"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_958195_365195" xmi:uuid="3a4258c0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042075_460161_182286"/>
        <bounds x="605" y="416" width="46" height="12"/>
        <text>ParentEdge</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_948_365196" xmi:uuid="3a4260f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042075_460161_182286"/>
        <bounds x="605" y="434" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_759890_365197" xmi:uuid="3a426e00-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042075_429215_182285"/>
        <bounds x="675" y="504" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_621119_365194"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_806071_365183"/>
      <waypoint x="672" y="501"/>
      <waypoint x="683" y="501"/>
      <waypoint x="683" y="431"/>
      <waypoint x="602" y="431"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_508472_400612" xmi:uuid="3a42f090-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978647_242237_164726"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_626341_365198" xmi:uuid="3a42d8e0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042046_302159_182277"/>
        <bounds x="440" y="349" width="37" height="12"/>
        <text>EdgeList</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_657584_365199" xmi:uuid="3a42e510-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042046_302159_182277"/>
        <bounds x="454" y="371" width="22" height="12"/>
        <text>1..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_278495_365201" xmi:uuid="3a42ecd0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042395_584457_182423"/>
        <bounds x="372" y="367" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_550448_365186"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_806071_365183"/>
      <waypoint x="369" y="364"/>
      <waypoint x="483" y="364"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_721392_400613" xmi:uuid="3a434f90-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042395_829210_182424"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_621119_365194"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_806071_365183"/>
      <waypoint x="588" y="483"/>
      <waypoint x="588" y="441"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_750665_400614" xmi:uuid="3a43d2f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978644_268226_164721"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_121105_365203" xmi:uuid="3a43b970-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041834_588692_182200"/>
        <bounds x="489" y="444" width="67" height="12"/>
        <text>ConnectedEdges</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_613992_365204" xmi:uuid="3a43c520-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041834_588692_182200"/>
        <bounds x="559" y="444" width="22" height="12"/>
        <text>1..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_579272_365205" xmi:uuid="3a43cdc0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042255_79592_182369"/>
        <bounds x="479" y="493" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_238094_365185"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_806071_365183"/>
      <waypoint x="476" y="490"/>
      <waypoint x="557" y="490"/>
      <waypoint x="557" y="441"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_337037_400615" xmi:uuid="3a443760-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041847_280303_182204"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_550448_365186"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_536010_365187"/>
      <waypoint x="203" y="396"/>
      <waypoint x="172" y="396"/>
      <waypoint x="172" y="627"/>
      <waypoint x="172" y="627"/>
      <waypoint x="172" y="311"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_567055_400616" xmi:uuid="3a44a0e0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041669_48110_182133"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_238094_365185"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_536010_365187"/>
      <waypoint x="357" y="487"/>
      <waypoint x="172" y="487"/>
      <waypoint x="172" y="627"/>
      <waypoint x="172" y="627"/>
      <waypoint x="172" y="311"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_589011_400617" xmi:uuid="3a452cd0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978647_499992_164725"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_776768_365207" xmi:uuid="3a451100-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042380_962046_182417"/>
        <bounds x="149" y="272" width="23" height="12"/>
        <text>Items</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_914836_365208" xmi:uuid="3a451990-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042380_962046_182417"/>
        <bounds x="178" y="272" width="22" height="12"/>
        <text>1..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_983848_365210" xmi:uuid="3a452220-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042394_75386_182422"/>
        <bounds x="178" y="242" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_223219_365206"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_536010_365187"/>
      <waypoint x="175" y="239"/>
      <waypoint x="175" y="287"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_370147_400618" xmi:uuid="3a468de0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042262_357360_182376"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025811_48987_365221"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_223219_365206"/>
      <waypoint x="165" y="147"/>
      <waypoint x="165" y="189"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_300830_400619" xmi:uuid="3a4727b0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978645_475016_164722"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_503079_365216" xmi:uuid="3a470da0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041655_152411_182128"/>
        <bounds x="397" y="514" width="59" height="12"/>
        <text>ParentEdgeSet</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_65951_365217" xmi:uuid="3a4714f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041655_152411_182128"/>
        <bounds x="462" y="514" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025810_102484_365218" xmi:uuid="3a471f00-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042256_563659_182370"/>
        <bounds x="462" y="544" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_146184_365215"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_238094_365185"/>
      <waypoint x="459" y="559"/>
      <waypoint x="459" y="511"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_221311_400620" xmi:uuid="3a478a30-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041564_571855_182093"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_146184_365215"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025810_238094_365185"/>
      <waypoint x="375" y="559"/>
      <waypoint x="375" y="511"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_119987_400621" xmi:uuid="a0ea9760-3ed5-013c-a15e-4b23c1d46efd" xmi:type="umldi:UMLEdge">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_65b021e_1688564042167_964081_182330"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_926954_365184"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025811_614887_365219"/>
      <waypoint x="725" y="420"/>
      <waypoint x="725" y="557"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026806_491275_400622" xmi:uuid="a0ec7690-3ed5-013c-a15e-4b23c1d46efd" xmi:type="umldi:UMLEdge">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_65b021e_1688564042257_787655_182371"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025810_536010_365187"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025811_614887_365219"/>
      <waypoint x="616" y="557"/>
      <waypoint x="616" y="627"/>
      <waypoint x="172" y="311"/>
      <waypoint x="172" y="627"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="834" height="669"/>
    <name>Topology</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703186394131_22671_480594" xmi:uuid="8d6bf8f0-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1690206121550_793802_84291"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186394191_597778_480627" xmi:uuid="8d6ea660-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978645_512578_164723"/>
      <ownedElement xmi:id="8d6d8b30-915f-013c-7166-0a5172f4a469" xmi:uuid="8d6d8cd0-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978645_512578_164723"/>
        <text>EdgeBasedWeightedGraphRepresentationItemsSelect</text>
      </ownedElement>
      <ownedElement xmi:id="8d6e0bd0-915f-013c-7166-0a5172f4a469" xmi:uuid="8d6e0c80-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="8d6e4690-915f-013c-7166-0a5172f4a469" xmi:uuid="8d6e4730-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="769" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186394340_783047_480670" xmi:uuid="8d70a960-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978635_428470_164714"/>
      <ownedElement xmi:id="8d6f3470-915f-013c-7166-0a5172f4a469" xmi:uuid="8d6f3520-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978635_428470_164714"/>
        <text>ConnectedEdgeSet</text>
      </ownedElement>
      <ownedElement xmi:id="e64b6780-6c41-013d-931e-0800270c66d6" xmi:uuid="e64b6820-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="176" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186394549_482858_480716" xmi:uuid="8d733bb0-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978638_556285_164715"/>
      <ownedElement xmi:id="8d714390-915f-013c-7166-0a5172f4a469" xmi:uuid="8d714450-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978638_556285_164715"/>
        <text>Path</text>
      </ownedElement>
      <ownedElement xmi:id="e68ac4a0-6c41-013d-931e-0800270c66d6" xmi:uuid="e68ac5f0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="261" y="95" width="176" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186394964_566881_480761" xmi:uuid="8d816220-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_VertexPoint"/>
      <ownedElement xmi:id="8d7590c0-915f-013c-7166-0a5172f4a469" xmi:uuid="8d759240-915f-013c-7166-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_VertexPoint"/>
        <text>VertexPoint</text>
      </ownedElement>
      <ownedElement xmi:id="e6b26d30-6c41-013d-931e-0800270c66d6" xmi:uuid="e6b26df0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="457" y="95" width="317" height="33"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="829" height="175"/>
    <name>EdgeBasedWeightedGraphRepresentationItemsSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446460977_929152_371082" xmi:uuid="034f2240-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978646_681818_164724"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461006_905190_371114" xmi:uuid="05295c80-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042390_347222_182419"/>
      <ownedElement xmi:id="05280380-6c42-013d-931e-0800270c66d6" xmi:uuid="05280440-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042390_347222_182419"/>
        <text>representation_:Edge_based_topological_representation_with_length_constraint</text>
      </ownedElement>
      <ownedElement xmi:id="052940a0-6c42-013d-931e-0800270c66d6" xmi:uuid="05294210-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042390_347222_182419"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="466" height="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461021_662776_371148" xmi:uuid="0529b770-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="895" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461036_241526_371163" xmi:uuid="0529f1a0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="895" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461050_384375_371178" xmi:uuid="054f6560-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="895" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461063_4512_371193" xmi:uuid="054fdcd0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="895" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461073_602871_371208" xmi:uuid="05502150-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="895" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461087_820863_371223" xmi:uuid="055060b0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="895" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461108_962478_371238" xmi:uuid="05676ea0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="895" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461121_235578_371253" xmi:uuid="0567b030-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="895" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461138_719812_371268" xmi:uuid="0567e730-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="895" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461155_302947_371283" xmi:uuid="056818d0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="895" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461166_403620_371298" xmi:uuid="05684ec0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="895" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461178_618168_371313" xmi:uuid="056881e0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="895" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461192_394751_371328" xmi:uuid="0568bf90-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="895" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461208_926374_371343" xmi:uuid="0568f8d0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="895" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446461220_231803_371358" xmi:uuid="05692df0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="895" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462588_520653_371373" xmi:uuid="05696440-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../AnnotatedModelPresentation/AnnotatedModelPresentation.xmi#_18_4_1_65b021e_1674590225853_510192_72440"/>
      <bounds x="895" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462598_189982_371388" xmi:uuid="05699a50-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="895" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462609_327528_371403" xmi:uuid="0569cee0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="895" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_388339_420176" xmi:uuid="0569dc60-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663334_375240_347605"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461021_662776_371148"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="62"/>
      <waypoint x="511" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_15967_420179" xmi:uuid="0569e4c0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663416_76342_347621"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461036_241526_371163"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="82"/>
      <waypoint x="511" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_200592_420182" xmi:uuid="0569ef40-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663494_940251_347637"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461050_384375_371178"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="102"/>
      <waypoint x="511" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_955292_420185" xmi:uuid="056a0570-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663571_609951_347653"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461063_4512_371193"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="122"/>
      <waypoint x="511" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_656676_420188" xmi:uuid="056a1520-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663647_316004_347669"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461073_602871_371208"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="142"/>
      <waypoint x="511" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_271497_420191" xmi:uuid="056a2740-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663719_324339_347685"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461087_820863_371223"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="162"/>
      <waypoint x="511" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_490833_420194" xmi:uuid="056a2f60-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663796_356690_347701"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461108_962478_371238"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="182"/>
      <waypoint x="511" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_633598_420197" xmi:uuid="056a34b0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663874_483692_347717"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461121_235578_371253"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="202"/>
      <waypoint x="511" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_969896_420200" xmi:uuid="056a4400-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663949_990634_347733"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461138_719812_371268"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="222"/>
      <waypoint x="511" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_841211_420203" xmi:uuid="056a5030-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601664027_715872_347749"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461155_302947_371283"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="242"/>
      <waypoint x="511" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_448312_420206" xmi:uuid="056a5a40-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601664104_361892_347765"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461166_403620_371298"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="262"/>
      <waypoint x="511" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_477490_420209" xmi:uuid="056a6720-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601664176_279030_347781"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461178_618168_371313"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="282"/>
      <waypoint x="511" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_652007_420212" xmi:uuid="056a7060-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601664317_578197_347813"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461192_394751_371328"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="302"/>
      <waypoint x="511" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_593222_420215" xmi:uuid="05a8f860-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601664396_570846_347829"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461208_926374_371343"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="322"/>
      <waypoint x="511" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_625070_420218" xmi:uuid="05a903b0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601664473_931893_347845"/>
      <source xmi:idref="_18_4_1_65b021e_1727446461220_231803_371358"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="342"/>
      <waypoint x="511" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_897514_420221" xmi:uuid="05a90ab0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601664545_549733_347861"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462588_520653_371373"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="362"/>
      <waypoint x="511" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_918888_420224" xmi:uuid="05a914f0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601664614_588727_347877"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462598_189982_371388"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="382"/>
      <waypoint x="511" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515435_43571_420227" xmi:uuid="05a91c80-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601664684_581516_347893"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462609_327528_371403"/>
      <target xmi:idref="_18_4_1_65b021e_1727446461006_905190_371114"/>
      <waypoint x="895" y="402"/>
      <waypoint x="511" y="402"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="898" height="480"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446458794_351751_370060" xmi:uuid="06653800-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978643_218886_164720"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458843_240302_370093" xmi:uuid="06f71b30-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042250_995707_182367"/>
      <ownedElement xmi:id="06f68550-6c42-013d-931e-0800270c66d6" xmi:uuid="06f685e0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042250_995707_182367"/>
        <text>representationItem:Vertex</text>
      </ownedElement>
      <ownedElement xmi:id="06f70790-6c42-013d-931e-0800270c66d6" xmi:uuid="06f70830-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042250_995707_182367"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="173" height="230"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458860_281064_370127" xmi:uuid="06f754e0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="622" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458873_377773_370142" xmi:uuid="06f79d80-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="622" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458888_898366_370157" xmi:uuid="06f7e260-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="622" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458905_355201_370172" xmi:uuid="06f81a40-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="622" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458917_985304_370187" xmi:uuid="06f85360-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="622" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458928_464892_370202" xmi:uuid="06f889c0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="622" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458942_736475_370217" xmi:uuid="06f8be80-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="622" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458950_412899_370232" xmi:uuid="07424db0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564322825_80703_218786"/>
      <bounds x="622" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458957_546059_370247" xmi:uuid="07428920-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_65b021e_1695136989165_579059_104536"/>
      <bounds x="622" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515421_949552_420035" xmi:uuid="07429150-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661975_720169_347192"/>
      <source xmi:idref="_18_4_1_65b021e_1727446458860_281064_370127"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458843_240302_370093"/>
      <waypoint x="622" y="62"/>
      <waypoint x="218" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515421_845127_420038" xmi:uuid="07429b50-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662055_991731_347208"/>
      <source xmi:idref="_18_4_1_65b021e_1727446458873_377773_370142"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458843_240302_370093"/>
      <waypoint x="622" y="82"/>
      <waypoint x="218" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515421_781269_420041" xmi:uuid="07429fd0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662130_303017_347224"/>
      <source xmi:idref="_18_4_1_65b021e_1727446458888_898366_370157"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458843_240302_370093"/>
      <waypoint x="622" y="102"/>
      <waypoint x="218" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515421_140754_420044" xmi:uuid="0742a840-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662208_450774_347240"/>
      <source xmi:idref="_18_4_1_65b021e_1727446458905_355201_370172"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458843_240302_370093"/>
      <waypoint x="622" y="122"/>
      <waypoint x="218" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515421_40445_420047" xmi:uuid="0742aca0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662284_78838_347256"/>
      <source xmi:idref="_18_4_1_65b021e_1727446458917_985304_370187"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458843_240302_370093"/>
      <waypoint x="622" y="142"/>
      <waypoint x="218" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515421_872392_420050" xmi:uuid="0742b5f0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662359_379571_347272"/>
      <source xmi:idref="_18_4_1_65b021e_1727446458928_464892_370202"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458843_240302_370093"/>
      <waypoint x="622" y="162"/>
      <waypoint x="218" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515421_553413_420053" xmi:uuid="0742ba70-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662433_986722_347288"/>
      <source xmi:idref="_18_4_1_65b021e_1727446458942_736475_370217"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458843_240302_370093"/>
      <waypoint x="622" y="182"/>
      <waypoint x="218" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515421_767407_420056" xmi:uuid="0742c2e0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662509_559681_347304"/>
      <source xmi:idref="_18_4_1_65b021e_1727446458950_412899_370232"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458843_240302_370093"/>
      <waypoint x="622" y="202"/>
      <waypoint x="218" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515421_340873_420059" xmi:uuid="0742c740-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662577_559145_347320"/>
      <source xmi:idref="_18_4_1_65b021e_1727446458957_546059_370247"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458843_240302_370093"/>
      <waypoint x="622" y="222"/>
      <waypoint x="218" y="222"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="625" height="300"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446458964_69327_370259" xmi:uuid="0c091680-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978647_712427_164727"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446458994_59281_370291" xmi:uuid="0c8c0d10-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042515_441748_182464"/>
      <ownedElement xmi:id="0c8b74d0-6c42-013d-931e-0800270c66d6" xmi:uuid="0c8b7580-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042515_441748_182464"/>
        <text>edge_:Edge</text>
      </ownedElement>
      <ownedElement xmi:id="0c8bfa90-6c42-013d-931e-0800270c66d6" xmi:uuid="0c8bfb20-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042515_441748_182464"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="99" height="230"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446459011_885365_370325" xmi:uuid="0c8c4dd0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="587" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446459027_238637_370340" xmi:uuid="0c8c8540-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="587" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446459043_958640_370355" xmi:uuid="0c8cc8a0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="587" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460418_667934_370370" xmi:uuid="0c8d1700-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="587" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460429_715962_370385" xmi:uuid="0c8d5910-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="587" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460442_992609_370400" xmi:uuid="0ccc4970-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="587" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460455_804305_370415" xmi:uuid="0ccc9f30-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="587" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460462_70024_370430" xmi:uuid="0cccdea0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564322825_80703_218786"/>
      <bounds x="587" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460469_541673_370445" xmi:uuid="0ccd12d0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_65b021e_1695136989165_579059_104536"/>
      <bounds x="587" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515423_880267_420062" xmi:uuid="0ccd1da0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601659213_980192_346351"/>
      <source xmi:idref="_18_4_1_65b021e_1727446459011_885365_370325"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458994_59281_370291"/>
      <waypoint x="587" y="62"/>
      <waypoint x="144" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515424_823096_420065" xmi:uuid="0ccd23b0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601659295_790458_346367"/>
      <source xmi:idref="_18_4_1_65b021e_1727446459027_238637_370340"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458994_59281_370291"/>
      <waypoint x="587" y="82"/>
      <waypoint x="144" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515424_621220_420068" xmi:uuid="0ccd2980-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601659367_527105_346383"/>
      <source xmi:idref="_18_4_1_65b021e_1727446459043_958640_370355"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458994_59281_370291"/>
      <waypoint x="587" y="102"/>
      <waypoint x="144" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515424_516203_420071" xmi:uuid="0ccd2f60-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601659445_26394_346399"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460418_667934_370370"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458994_59281_370291"/>
      <waypoint x="587" y="122"/>
      <waypoint x="144" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515424_536818_420074" xmi:uuid="0ccd3570-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601659543_585112_346415"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460429_715962_370385"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458994_59281_370291"/>
      <waypoint x="587" y="142"/>
      <waypoint x="144" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515424_451608_420077" xmi:uuid="0ccd3b40-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601659617_867823_346431"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460442_992609_370400"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458994_59281_370291"/>
      <waypoint x="587" y="162"/>
      <waypoint x="144" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515424_938082_420080" xmi:uuid="0ccd3fd0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601659693_99291_346447"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460455_804305_370415"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458994_59281_370291"/>
      <waypoint x="587" y="182"/>
      <waypoint x="144" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515424_606592_420083" xmi:uuid="0ccd4570-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601659769_42040_346463"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460462_70024_370430"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458994_59281_370291"/>
      <waypoint x="587" y="202"/>
      <waypoint x="144" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515424_650916_420086" xmi:uuid="0ccd4b50-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042509_603592_182461"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460469_541673_370445"/>
      <target xmi:idref="_18_4_1_65b021e_1727446458994_59281_370291"/>
      <waypoint x="587" y="222"/>
      <waypoint x="144" y="222"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="590" height="300"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446460475_158514_370457" xmi:uuid="0fdf1c50-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978634_182132_164713"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460503_375636_370489" xmi:uuid="10a75680-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041665_852204_182130"/>
      <ownedElement xmi:id="10a6c0c0-6c42-013d-931e-0800270c66d6" xmi:uuid="10a6c180-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041665_852204_182130"/>
        <text>connected_edge_sub_set:Connected_edge_sub_set</text>
      </ownedElement>
      <ownedElement xmi:id="10a74420-6c42-013d-931e-0800270c66d6" xmi:uuid="10a744c0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041665_852204_182130"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="314" height="230"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460518_994997_370523" xmi:uuid="10a797e0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="986" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460533_852393_370538" xmi:uuid="10c51000-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="986" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460540_398689_370553" xmi:uuid="10c58eb0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042257_232118_182373"/>
      <bounds x="986" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460555_605911_370568" xmi:uuid="10c601a0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="986" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460570_147571_370583" xmi:uuid="10ded540-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="986" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460582_354976_370598" xmi:uuid="10df18c0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="986" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460592_85472_370613" xmi:uuid="10df54f0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="986" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460607_883915_370628" xmi:uuid="10df9130-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="986" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460615_35393_370643" xmi:uuid="10dfcf70-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564322825_80703_218786"/>
      <bounds x="986" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515426_390075_420089" xmi:uuid="10dfdcd0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661262_629846_346985"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460518_994997_370523"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460503_375636_370489"/>
      <waypoint x="986" y="62"/>
      <waypoint x="359" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515426_816255_420092" xmi:uuid="10dfe410-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661342_424190_347001"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460533_852393_370538"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460503_375636_370489"/>
      <waypoint x="986" y="82"/>
      <waypoint x="359" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515426_40258_420095" xmi:uuid="10dfeb20-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661418_322723_347017"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460540_398689_370553"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460503_375636_370489"/>
      <waypoint x="986" y="102"/>
      <waypoint x="359" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515426_299266_420098" xmi:uuid="10dff200-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661487_591845_347033"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460555_605911_370568"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460503_375636_370489"/>
      <waypoint x="986" y="122"/>
      <waypoint x="359" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515426_125889_420101" xmi:uuid="10dff850-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661565_249149_347049"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460570_147571_370583"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460503_375636_370489"/>
      <waypoint x="986" y="142"/>
      <waypoint x="359" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515426_616941_420104" xmi:uuid="10dffee0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661644_648900_347065"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460582_354976_370598"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460503_375636_370489"/>
      <waypoint x="986" y="162"/>
      <waypoint x="359" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515426_25506_420107" xmi:uuid="10e004c0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661717_665172_347081"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460592_85472_370613"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460503_375636_370489"/>
      <waypoint x="986" y="182"/>
      <waypoint x="359" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515426_585277_420110" xmi:uuid="10e00b10-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661790_972637_347097"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460607_883915_370628"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460503_375636_370489"/>
      <waypoint x="986" y="202"/>
      <waypoint x="359" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515426_723831_420113" xmi:uuid="10e010f0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661865_925017_347113"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460615_35393_370643"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460503_375636_370489"/>
      <waypoint x="986" y="222"/>
      <waypoint x="359" y="222"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="989" height="300"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446460620_248670_370655" xmi:uuid="13b02f10-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978649_661250_164728"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460650_934387_370687" xmi:uuid="1461e2b0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042615_536276_182501"/>
      <ownedElement xmi:id="14612810-6c42-013d-931e-0800270c66d6" xmi:uuid="146128c0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042615_536276_182501"/>
        <text>representationItem:Subedge</text>
      </ownedElement>
      <ownedElement xmi:id="1461cc60-6c42-013d-931e-0800270c66d6" xmi:uuid="1461cd10-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042615_536276_182501"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="187" height="250"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460665_691939_370721" xmi:uuid="1475fee0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="874" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460681_870247_370736" xmi:uuid="14763e60-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="874" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460734_669895_370752" xmi:uuid="147670f0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042257_232118_182373"/>
      <bounds x="874" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460749_844310_370767" xmi:uuid="1476a690-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="874" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460763_772606_370782" xmi:uuid="1476dad0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="874" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460774_70388_370797" xmi:uuid="14770f70-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="874" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460787_399391_370812" xmi:uuid="14774eb0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="874" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460802_900122_370827" xmi:uuid="1494a050-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="874" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460809_977557_370842" xmi:uuid="1494e640-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564322825_80703_218786"/>
      <bounds x="874" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460816_27865_370857" xmi:uuid="14951bd0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_65b021e_1695136989165_579059_104536"/>
      <bounds x="874" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515429_78947_420116" xmi:uuid="149527a0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660551_358560_346778"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460665_691939_370721"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460650_934387_370687"/>
      <waypoint x="874" y="62"/>
      <waypoint x="232" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515429_805396_420119" xmi:uuid="14952f40-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660631_953151_346794"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460681_870247_370736"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460650_934387_370687"/>
      <waypoint x="874" y="82"/>
      <waypoint x="232" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515429_330278_420122" xmi:uuid="14956220-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1727446460681_51405_370748"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460734_669895_370752"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460650_934387_370687"/>
      <waypoint x="874" y="102"/>
      <waypoint x="232" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515429_545841_420125" xmi:uuid="14956ac0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660707_109795_346810"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460749_844310_370767"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460650_934387_370687"/>
      <waypoint x="874" y="122"/>
      <waypoint x="232" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515429_247272_420128" xmi:uuid="14957200-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660782_580183_346826"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460763_772606_370782"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460650_934387_370687"/>
      <waypoint x="874" y="142"/>
      <waypoint x="232" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515429_263754_420131" xmi:uuid="149579e0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660859_703576_346842"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460774_70388_370797"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460650_934387_370687"/>
      <waypoint x="874" y="162"/>
      <waypoint x="232" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515429_963410_420134" xmi:uuid="14958110-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660935_409513_346858"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460787_399391_370812"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460650_934387_370687"/>
      <waypoint x="874" y="182"/>
      <waypoint x="232" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515429_972648_420137" xmi:uuid="149586a0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661010_474443_346874"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460802_900122_370827"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460650_934387_370687"/>
      <waypoint x="874" y="202"/>
      <waypoint x="232" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515429_640641_420140" xmi:uuid="14958d60-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661088_532245_346890"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460809_977557_370842"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460650_934387_370687"/>
      <waypoint x="874" y="222"/>
      <waypoint x="232" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515429_94924_420143" xmi:uuid="1495a5e0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601661156_338669_346906"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460816_27865_370857"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460650_934387_370687"/>
      <waypoint x="874" y="242"/>
      <waypoint x="232" y="242"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="877" height="320"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446460821_501243_370869" xmi:uuid="1c0f5ed0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978638_556285_164715"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460849_519926_370901" xmi:uuid="1cc94010-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042065_465232_182281"/>
      <ownedElement xmi:id="1cab99b0-6c42-013d-931e-0800270c66d6" xmi:uuid="1cab9a70-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042065_465232_182281"/>
        <text>path_:Path</text>
      </ownedElement>
      <ownedElement xmi:id="1cc928c0-6c42-013d-931e-0800270c66d6" xmi:uuid="1cc92960-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042065_465232_182281"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="94" height="250"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460864_871650_370935" xmi:uuid="1cc97960-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="741" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460880_482331_370950" xmi:uuid="1cc9af60-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="741" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460887_364106_370965" xmi:uuid="1cc9e8a0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042257_232118_182373"/>
      <bounds x="741" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460903_586768_370980" xmi:uuid="1cca1db0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="741" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460920_517797_370995" xmi:uuid="1cca5070-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="741" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460932_959916_371010" xmi:uuid="1cca8400-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="741" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460943_536134_371025" xmi:uuid="1ce04da0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="741" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460957_878730_371040" xmi:uuid="1ce09580-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="741" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460965_910017_371055" xmi:uuid="1ce0d800-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564322825_80703_218786"/>
      <bounds x="741" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446460972_382807_371070" xmi:uuid="1ce12af0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_65b021e_1695136989165_579059_104536"/>
      <bounds x="741" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515432_811088_420146" xmi:uuid="1ce13940-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601659888_874701_346557"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460864_871650_370935"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460849_519926_370901"/>
      <waypoint x="741" y="62"/>
      <waypoint x="139" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515432_908475_420149" xmi:uuid="1ce13f40-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601659967_936770_346573"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460880_482331_370950"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460849_519926_370901"/>
      <waypoint x="741" y="82"/>
      <waypoint x="139" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515432_876938_420152" xmi:uuid="1ce14940-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042045_851928_182274"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460887_364106_370965"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460849_519926_370901"/>
      <waypoint x="741" y="102"/>
      <waypoint x="139" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515432_192009_420155" xmi:uuid="1ce15190-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660053_994748_346604"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460903_586768_370980"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460849_519926_370901"/>
      <waypoint x="741" y="122"/>
      <waypoint x="139" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515432_890254_420158" xmi:uuid="1ce15880-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660130_412918_346620"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460920_517797_370995"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460849_519926_370901"/>
      <waypoint x="741" y="142"/>
      <waypoint x="139" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515432_526806_420161" xmi:uuid="1ce15f80-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660209_801086_346636"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460932_959916_371010"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460849_519926_370901"/>
      <waypoint x="741" y="162"/>
      <waypoint x="139" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515432_238211_420164" xmi:uuid="1ce167f0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660281_240325_346652"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460943_536134_371025"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460849_519926_370901"/>
      <waypoint x="741" y="182"/>
      <waypoint x="139" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515432_69488_420167" xmi:uuid="1ce17280-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660355_881240_346668"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460957_878730_371040"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460849_519926_370901"/>
      <waypoint x="741" y="202"/>
      <waypoint x="139" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515432_181701_420170" xmi:uuid="1ce18310-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601660432_564364_346684"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460965_910017_371055"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460849_519926_370901"/>
      <waypoint x="741" y="222"/>
      <waypoint x="139" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515432_610681_420173" xmi:uuid="1d0337e0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042046_851900_182275"/>
      <source xmi:idref="_18_4_1_65b021e_1727446460972_382807_371070"/>
      <target xmi:idref="_18_4_1_65b021e_1727446460849_519926_370901"/>
      <waypoint x="741" y="242"/>
      <waypoint x="139" y="242"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="744" height="320"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564041725_91562_182144" xmi:uuid="3a4a1260-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978635_428470_164714"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_895230_372937" xmi:uuid="3a4ab620-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041834_588692_182200"/>
      <ownedElement xmi:id="80846ef0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="80846ff0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041834_588692_182200"/>
        <text>ConnectedEdges:Edge</text>
      </ownedElement>
      <ownedElement xmi:id="8084ba20-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="8084c380-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041834_588692_182200"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_130296_372938" xmi:uuid="80854350-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042509_507393_182463"/>
        <ownedElement xmi:id="e75c5790-6c41-013d-931e-0800270c66d6" xmi:uuid="e75c5820-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042509_507393_182463"/>
          <bounds x="220" y="94" width="74" height="13"/>
          <text>edge : Edge [1]</text>
        </ownedElement>
        <bounds x="202" y="103" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="98" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_951747_372940" xmi:uuid="3a4abcc0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041843_556276_182202"/>
      <ownedElement xmi:id="80a80ff0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="80a81100-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041843_556276_182202"/>
        <text>connected_edge_set:Connected_edge_set</text>
      </ownedElement>
      <ownedElement xmi:id="80a86800-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="80a868d0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041843_556276_182202"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="fafe7bd0-6c41-013d-931e-0800270c66d6" xmi:uuid="fafe7d70-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="fafeac90-6c41-013d-931e-0800270c66d6" xmi:uuid="fafeacc0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_293680_372941" xmi:uuid="80c9adc0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Connected_edge_set-connected_edges"/>
          <ownedElement xmi:id="80be9a70-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="80be9b80-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Connected_edge_set-connected_edges"/>
            <text>connected_edges:Edge</text>
          </ownedElement>
          <ownedElement xmi:id="80c98b40-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="80c98c50-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Connected_edge_set-connected_edges"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="406" y="99" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="385" y="63" width="273" height="71"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_267367_402757" xmi:uuid="3a4ad6f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041832_16863_182196"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_303019_372942"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_951747_372940"/>
      <waypoint x="678" y="70"/>
      <waypoint x="658" y="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_979320_402758" xmi:uuid="3a4ae6b0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041833_489538_182197"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_293680_372941"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_130296_372938"/>
      <waypoint x="406" y="112"/>
      <waypoint x="217" y="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_604341_402759" xmi:uuid="3a4af9b0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026955_72299_411723"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_951747_372940"/>
      <waypoint x="359" y="72"/>
      <waypoint x="385" y="76"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026955_72299_411723" xmi:uuid="3a4b2cc0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="3a4b2600-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a4b26a0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>inherited from TopologicalRepresentationItem</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="203" y="35" width="156" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_303019_372942" xmi:uuid="3a4b3280-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041839_548674_182201"/>
      <bounds x="678" y="62" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="681" height="149"/>
    <name>ConnectedEdgeSet</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564042344_896532_182393" xmi:uuid="3a4c65a0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978646_681818_164724"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_822570_372969" xmi:uuid="3a4db940-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042380_962046_182417"/>
      <ownedElement xmi:id="3a4d34a0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a4d3570-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042380_962046_182417"/>
        <text>Items:EdgeBasedWeightedGraphRepresentationItemsSelect</text>
      </ownedElement>
      <ownedElement xmi:id="3a4d6570-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a4d6650-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042380_962046_182417"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_503761_372970" xmi:uuid="3a4db280-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042257_232118_182373"/>
        <ownedElement xmi:id="fedbe100-6c41-013d-931e-0800270c66d6" xmi:uuid="fedbe190-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042257_232118_182373"/>
          <bounds x="112" y="90" width="538" height="13"/>
          <text>edgeBasedWeightedGraphRepresentationItemsSelect : edge_based_weighted_graph_representation_items [1]</text>
        </ownedElement>
        <bounds x="405" y="116" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="112" width="385" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_870935_372974" xmi:uuid="3a8e0b20-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042390_347222_182419"/>
      <ownedElement xmi:id="3a6e6d00-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a6e6df0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042390_347222_182419"/>
        <text>representation_:Edge_based_topological_representation_with_length_constraint</text>
      </ownedElement>
      <ownedElement xmi:id="3a6eb090-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a6eb130-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042390_347222_182419"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="00310ee0-6c42-013d-931e-0800270c66d6" xmi:uuid="00310f70-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="003147c0-6c42-013d-931e-0800270c66d6" xmi:uuid="00314850-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_106364_372975" xmi:uuid="3a8e02f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Edge_based_topological_representation_with_length_constraint-items"/>
          <ownedElement xmi:id="3a832ab0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a832bb0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Edge_based_topological_representation_with_length_constraint-items"/>
            <text>items:edge_based_weighted_graph_representation_items</text>
          </ownedElement>
          <ownedElement xmi:id="3a8df610-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a8df730-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Edge_based_topological_representation_with_length_constraint-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="763" y="113" width="372" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="742" y="77" width="483" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_37704_402772" xmi:uuid="3a8e1250-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042379_661398_182414"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025973_106364_372975"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_503761_372970"/>
      <waypoint x="763" y="126"/>
      <waypoint x="420" y="126"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_622432_402773" xmi:uuid="3a8e1ff0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026955_949516_411727"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_870935_372974"/>
      <waypoint x="541" y="68"/>
      <waypoint x="742" y="90"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_868308_402774" xmi:uuid="3a8e25d0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042380_730367_182415"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025973_583761_372972"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_870935_372974"/>
      <waypoint x="1280" y="88"/>
      <waypoint x="1225" y="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026955_949516_411727" xmi:uuid="3a8e2fc0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="3a8e2c20-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a8e2cb0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from GeometricRepresentation</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="364" y="35" width="177" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_583761_372972" xmi:uuid="3a8e3330-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042385_433927_182418"/>
      <bounds x="1280" y="81" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1283" height="177"/>
    <name>EdgeBasedTopologicalRepresentationWithLengthConstraint</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564042205_726246_182342" xmi:uuid="3a8e4040-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978643_218886_164720"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_210558_372966" xmi:uuid="3a98bc50-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042250_995707_182367"/>
      <ownedElement xmi:id="3a987ac0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a987bc0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042250_995707_182367"/>
        <text>representationItem:Vertex</text>
      </ownedElement>
      <ownedElement xmi:id="3a98aff0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a98b090-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042250_995707_182367"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="364" y="63" width="173" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_461090_402770" xmi:uuid="3a98c2a0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042243_381834_182363"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025973_668373_372967"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_210558_372966"/>
      <waypoint x="549" y="74"/>
      <waypoint x="537" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_927382_402771" xmi:uuid="3a98cb20-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026955_467514_411726"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_210558_372966"/>
      <waypoint x="294" y="73"/>
      <waypoint x="364" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026955_467514_411726" xmi:uuid="3a98d2e0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="3a98cf30-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a98cfd0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>inherited from TopologicalRepresentationItem</text>
      </ownedElement>
      <bounds x="98" y="49" width="196" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_668373_372967" xmi:uuid="3a98d650-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042244_923697_182366"/>
      <bounds x="549" y="63" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="552" height="111"/>
    <name>Vertex</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564042468_319443_182437" xmi:uuid="3a98de10-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978647_712427_164727"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_824515_372976" xmi:uuid="3a99cf50-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042070_199737_182284"/>
      <ownedElement xmi:id="8107e550-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="8107ecc0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042070_199737_182284"/>
        <text>EdgeEnd:Vertex</text>
      </ownedElement>
      <ownedElement xmi:id="81083860-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81083910-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042070_199737_182284"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_73705_372977" xmi:uuid="8108b6b0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042244_923697_182366"/>
        <ownedElement xmi:id="077ec310-6c42-013d-931e-0800270c66d6" xmi:uuid="077ec3a0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042244_923697_182366"/>
          <bounds x="175" y="100" width="73" height="13"/>
          <text>ver : Vertex [1]</text>
        </ownedElement>
        <bounds x="157" y="109" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="105" width="130" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_245645_372979" xmi:uuid="3a99d320-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042163_320724_182329"/>
      <ownedElement xmi:id="81092770-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81092810-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042163_320724_182329"/>
        <text>EdgeStart:Vertex</text>
      </ownedElement>
      <ownedElement xmi:id="810973e0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81097490-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042163_320724_182329"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_290092_372980" xmi:uuid="810a0330-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042244_923697_182366"/>
        <ownedElement xmi:id="07bac290-6c42-013d-931e-0800270c66d6" xmi:uuid="07bac320-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042244_923697_182366"/>
          <bounds x="181" y="150" width="73" height="13"/>
          <text>ver : Vertex [1]</text>
        </ownedElement>
        <bounds x="163" y="159" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="154" width="136" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_265318_372982" xmi:uuid="3a99d5f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042515_441748_182464"/>
      <ownedElement xmi:id="8114f6c0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="8114f7c0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042515_441748_182464"/>
        <text>edge_:Edge</text>
      </ownedElement>
      <ownedElement xmi:id="81155330-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="811553e0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042515_441748_182464"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="087c07d0-6c42-013d-931e-0800270c66d6" xmi:uuid="087c0860-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="087c3ec0-6c42-013d-931e-0800270c66d6" xmi:uuid="087c3f10-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_542878_372983" xmi:uuid="81375170-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Edge-edge_end"/>
          <ownedElement xmi:id="812baca0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="812badb0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Edge-edge_end"/>
            <text>edge_end:Vertex</text>
          </ownedElement>
          <ownedElement xmi:id="81372e10-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81372ed0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Edge-edge_end"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="399" y="112" width="131" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_212941_372984" xmi:uuid="81591b10-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Edge-edge_start"/>
          <ownedElement xmi:id="814cf870-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="814d0110-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Edge-edge_start"/>
            <text>edge_start:Vertex</text>
          </ownedElement>
          <ownedElement xmi:id="8158ee30-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="8158f060-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Edge-edge_start"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="399" y="154" width="136" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="385" y="84" width="157" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_306938_402776" xmi:uuid="3a99e660-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042506_170217_182458"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025973_542878_372983"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_73705_372977"/>
      <waypoint x="399" y="123"/>
      <waypoint x="172" y="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_495133_402777" xmi:uuid="3a99ef40-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042508_272607_182460"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025973_365403_372985"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_265318_372982"/>
      <waypoint x="554" y="70"/>
      <waypoint x="462" y="70"/>
      <waypoint x="462" y="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_614545_402778" xmi:uuid="3a99fa60-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042507_483914_182459"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025973_212941_372984"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_290092_372980"/>
      <waypoint x="399" y="165"/>
      <waypoint x="178" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_365403_372985" xmi:uuid="3a9a0e50-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042509_507393_182463"/>
      <bounds x="554" y="63" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1695982395077_840088_94462" xmi:uuid="a769f860-40ed-013c-1d77-21143cc57b19" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_65b021e_1688564042116_660101_182301"/>
      <bounds x="203" y="21" width="180" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="557" height="204"/>
    <name>Edge</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564041619_834759_182104" xmi:uuid="3a9a1a30-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978634_182132_164713"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_391188_372930" xmi:uuid="3a9a9110-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041655_152411_182128"/>
      <ownedElement xmi:id="815b0190-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="815b0280-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041655_152411_182128"/>
        <text>ParentEdgeSet:ConnectedEdgeSet</text>
      </ownedElement>
      <ownedElement xmi:id="815b4d40-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="815b4de0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041655_152411_182128"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_22682_372931" xmi:uuid="815bc450-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041839_548674_182201"/>
        <ownedElement xmi:id="0d139780-6c42-013d-931e-0800270c66d6" xmi:uuid="0d139820-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041839_548674_182201"/>
          <bounds x="189" y="77" width="221" height="13"/>
          <text>connectedEdgeSet : Connected_edge_set [1]</text>
        </ownedElement>
        <bounds x="247" y="96" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="91" width="227" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_414874_372933" xmi:uuid="3a9a99f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041665_852204_182130"/>
      <ownedElement xmi:id="81668e30-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81668f40-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041665_852204_182130"/>
        <text>connected_edge_sub_set:Connected_edge_sub_set</text>
      </ownedElement>
      <ownedElement xmi:id="8166e540-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="8166e600-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041665_852204_182130"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="0df47880-6c42-013d-931e-0800270c66d6" xmi:uuid="0df47920-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0df4b290-6c42-013d-931e-0800270c66d6" xmi:uuid="0df4b2d0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_441748_372934" xmi:uuid="818860d0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Connected_edge_sub_set-parent_edge_set"/>
          <ownedElement xmi:id="817cc3f0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="817cc5f0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Connected_edge_sub_set-parent_edge_set"/>
            <text>parent_edge_set:Connected_edge_set</text>
          </ownedElement>
          <ownedElement xmi:id="81883f10-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81884020-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Connected_edge_sub_set-parent_edge_set"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="448" y="92" width="251" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="63" width="327" height="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_126018_402754" xmi:uuid="3a9a9f50-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026955_452535_411722"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_414874_372933"/>
      <waypoint x="422" y="50"/>
      <waypoint x="476" y="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_521825_402755" xmi:uuid="3a9aaae0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041653_906339_182125"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_906617_372935"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_414874_372933"/>
      <waypoint x="780" y="74"/>
      <waypoint x="768" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_291072_402756" xmi:uuid="3a9ab990-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041654_428345_182126"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_441748_372934"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_22682_372931"/>
      <waypoint x="448" y="98"/>
      <waypoint x="262" y="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026955_452535_411722" xmi:uuid="3a9ac520-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="3a9ac0b0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a9ac150-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>inherited from ConnectedEdgeSet</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="322" y="14" width="100" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_906617_372935" xmi:uuid="3a9acf50-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041660_92154_182129"/>
      <bounds x="780" y="66" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="783" height="142"/>
    <name>ConnectedEdgeSubSet</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564042575_393765_182476" xmi:uuid="3a9ad620-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978649_661250_164728"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_841892_372987" xmi:uuid="3a9b5cb0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042075_460161_182286"/>
      <ownedElement xmi:id="818a6610-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="818a6720-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042075_460161_182286"/>
        <text>ParentEdge:Edge</text>
      </ownedElement>
      <ownedElement xmi:id="818ab800-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="818ab8b0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042075_460161_182286"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_516320_372988" xmi:uuid="818b3930-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042509_507393_182463"/>
        <ownedElement xmi:id="11261350-6c42-013d-931e-0800270c66d6" xmi:uuid="112613e0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042509_507393_182463"/>
          <bounds x="180" y="80" width="74" height="13"/>
          <text>edge : Edge [1]</text>
        </ownedElement>
        <bounds x="162" y="89" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="84" width="135" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_631936_372990" xmi:uuid="3a9b5fe0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042615_536276_182501"/>
      <ownedElement xmi:id="8198af10-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="8198b000-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042615_536276_182501"/>
        <text>representationItem:Subedge</text>
      </ownedElement>
      <ownedElement xmi:id="819916f0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81991800-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042615_536276_182501"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="11ea7c70-6c42-013d-931e-0800270c66d6" xmi:uuid="11ea7d00-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="11eaaf20-6c42-013d-931e-0800270c66d6" xmi:uuid="11eaaf80-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_116358_372991" xmi:uuid="81c1f8e0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Subedge-parent_edge"/>
          <ownedElement xmi:id="81b4aa10-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81b4abd0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Subedge-parent_edge"/>
            <text>parent_edge:Edge</text>
          </ownedElement>
          <ownedElement xmi:id="81c1c690-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81c1c790-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Subedge-parent_edge"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="364" y="84" width="136" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="350" y="56" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_906011_402779" xmi:uuid="3a9b6570-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026955_37957_411729"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_631936_372990"/>
      <waypoint x="331" y="60"/>
      <waypoint x="350" y="65"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_963305_402780" xmi:uuid="3a9b7320-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042609_227152_182497"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025973_116358_372991"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_516320_372988"/>
      <waypoint x="364" y="98"/>
      <waypoint x="177" y="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_14600_402781" xmi:uuid="3a9b8230-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042610_466652_182498"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025973_825427_372992"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_631936_372990"/>
      <waypoint x="549" y="70"/>
      <waypoint x="537" y="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026955_37957_411729" xmi:uuid="3a9b8c30-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="3a9b87d0-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3a9b8860-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>inherited from Edge</text>
      </ownedElement>
      <bounds x="231" y="28" width="100" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_825427_372992" xmi:uuid="3a9b9060-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042611_29605_182500"/>
      <bounds x="549" y="64" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="552" height="134"/>
    <name>SubEdge</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564042116_660101_182301" xmi:uuid="3a9ba1a0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978642_323259_164718"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_879067_372963" xmi:uuid="3aa61d70-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042152_816793_182325"/>
      <ownedElement xmi:id="3aa5d220-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3aa5d310-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042152_816793_182325"/>
        <text>topological_representation_item:Detailed_topological_model_element</text>
      </ownedElement>
      <ownedElement xmi:id="3aa60690-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3aa60740-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042152_816793_182325"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="308" y="91" width="408" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_239050_402768" xmi:uuid="3aa623a0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042150_364106_182322"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025973_347512_372964"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025973_879067_372963"/>
      <waypoint x="728" y="63"/>
      <waypoint x="588" y="63"/>
      <waypoint x="588" y="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025973_347512_372964" xmi:uuid="3aa63e90-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042157_215227_182326"/>
      <bounds x="728" y="53" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1695982470177_243580_94550" xmi:uuid="a7defb40-40ed-013c-1d77-21143cc57b19" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_271a0567_1571674569431_927724_56905"/>
      <bounds x="245" y="35" width="117" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="731" height="131"/>
    <name>TopologicalRepresentationItem</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564041929_110566_182218" xmi:uuid="3aa64d10-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978638_556285_164715"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_686828_372947" xmi:uuid="3aa7ab60-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042046_302159_182277"/>
      <ownedElement xmi:id="81d22a20-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81d22b00-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042046_302159_182277"/>
        <text>EdgeList:Edge</text>
      </ownedElement>
      <ownedElement xmi:id="81d28090-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81d28130-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042046_302159_182277"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_894238_372948" xmi:uuid="81d2f640-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042509_507393_182463"/>
        <ownedElement xmi:id="15b613f0-6c42-013d-931e-0800270c66d6" xmi:uuid="15b61490-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042509_507393_182463"/>
          <bounds x="169" y="108" width="74" height="13"/>
          <text>edge : Edge [1]</text>
        </ownedElement>
        <bounds x="151" y="117" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="112" width="131" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_526131_372950" xmi:uuid="3aa7b200-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042050_62160_182278"/>
      <ownedElement xmi:id="81d41b90-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81d41ca0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042050_62160_182278"/>
        <text>OrientationList:Boolean</text>
      </ownedElement>
      <ownedElement xmi:id="81d47f10-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81d48040-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042050_62160_182278"/>
        <text>[1..*]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="28" y="168" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_290626_372951" xmi:uuid="3aa7b500-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042060_174241_182280"/>
      <ownedElement xmi:id="81e309a0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81e30cd0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042060_174241_182280"/>
        <text>orientedEdge:Oriented_edge</text>
      </ownedElement>
      <ownedElement xmi:id="81e39b30-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="81e39d60-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042060_174241_182280"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="16ae8770-6c42-013d-931e-0800270c66d6" xmi:uuid="16ae87f0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="16aeb970-6c42-013d-931e-0800270c66d6" xmi:uuid="16aeb9b0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_47142_372952" xmi:uuid="82181d70-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Oriented_edge-edge_definition"/>
          <ownedElement xmi:id="8206db90-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="8206dd30-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Oriented_edge-edge_definition"/>
            <text>edge_definition:Edge</text>
          </ownedElement>
          <ownedElement xmi:id="8217c0b0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="8217c260-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Oriented_edge-edge_definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="336" y="120" width="152" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_528836_372953" xmi:uuid="8235c8c0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Oriented_edge-orientation"/>
          <ownedElement xmi:id="82287420-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="82287530-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Oriented_edge-orientation"/>
            <text>orientation:Boolean</text>
          </ownedElement>
          <ownedElement xmi:id="82357ec0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="82357fc0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Oriented_edge-orientation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="336" y="168" width="143" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="315" y="84" width="205" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_668328_402763" xmi:uuid="826763d0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042042_826801_182271"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_290626_372951"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_824599_372955"/>
      <waypoint x="520" y="133"/>
      <waypoint x="609" y="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_667226_372954" xmi:uuid="3aa7b7e0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042065_465232_182281"/>
      <ownedElement xmi:id="8242d550-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="8242d690-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042065_465232_182281"/>
        <text>path_:Path</text>
      </ownedElement>
      <ownedElement xmi:id="82434310-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="82434470-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042065_465232_182281"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="1a3dcd30-6c42-013d-931e-0800270c66d6" xmi:uuid="1a3dcdc0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="1a3e0150-6c42-013d-931e-0800270c66d6" xmi:uuid="1a3e01a0-6c42-013d-931e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_824599_372955" xmi:uuid="82674710-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Path-edge_list"/>
          <ownedElement xmi:id="825b54a0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="825b55d0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Path-edge_list"/>
            <text>edge_list:Oriented_edge</text>
          </ownedElement>
          <ownedElement xmi:id="826725f0-24a5-013c-5c0c-2bb9f4d923a9" xmi:uuid="826726f0-24a5-013c-5c0c-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Path-edge_list"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="609" y="120" width="182" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="588" y="84" width="273" height="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_452681_402761" xmi:uuid="3aa7c6f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042042_326865_182270"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_307846_372956"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_667226_372954"/>
      <waypoint x="873" y="95"/>
      <waypoint x="861" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_521836_402762" xmi:uuid="3aa7cde0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042043_429875_182272"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_47142_372952"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_894238_372948"/>
      <waypoint x="336" y="130"/>
      <waypoint x="166" y="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_773766_402764" xmi:uuid="3aa7df20-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042044_316311_182273"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_528836_372953"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_526131_372950"/>
      <waypoint x="336" y="179"/>
      <waypoint x="203" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_652073_402765" xmi:uuid="3aa7e3f0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026955_962932_411724"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_667226_372954"/>
      <waypoint x="582" y="61"/>
      <waypoint x="635" y="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026955_962932_411724" xmi:uuid="3aa7f560-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="3aa7f130-0d33-013c-5e3a-5b8e392dc4e5" xmi:uuid="3aa7f1d0-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from TopologicalRepresentationItem</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="441" y="14" width="170" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_307846_372956" xmi:uuid="3aa7f890-0d33-013c-5e3a-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042056_239145_182279"/>
      <bounds x="873" y="87" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="876" height="218"/>
    <name>Path</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446462615_643744_371415" xmi:uuid="fd13d070-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Topology.xmi#_18_4_1_65b021e_1688563978635_428470_164714"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462644_583024_371447" xmi:uuid="fe101350-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041843_556276_182202"/>
      <ownedElement xmi:id="fdc872a0-6c41-013d-931e-0800270c66d6" xmi:uuid="fdc87350-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041843_556276_182202"/>
        <text>connected_edge_set:Connected_edge_set</text>
      </ownedElement>
      <ownedElement xmi:id="fe0fd200-6c41-013d-931e-0800270c66d6" xmi:uuid="fe0fd2f0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041843_556276_182202"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="262" height="230"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462660_637201_371481" xmi:uuid="fe1089e0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="881" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462674_374598_371496" xmi:uuid="fe296eb0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="881" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462681_360004_371511" xmi:uuid="fe29ab40-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564042257_232118_182373"/>
      <bounds x="881" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462696_151074_371526" xmi:uuid="fe2a2370-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="881" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462712_756531_371541" xmi:uuid="fe2a8f70-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="881" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462723_729656_371556" xmi:uuid="fe47e640-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="881" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462734_759599_371571" xmi:uuid="fe4880a0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="881" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462748_552410_371586" xmi:uuid="fe48db60-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="881" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462757_607358_371601" xmi:uuid="fe6039c0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564322825_80703_218786"/>
      <bounds x="881" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515441_382292_420230" xmi:uuid="fe6055d0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662687_747617_347399"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462660_637201_371481"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462644_583024_371447"/>
      <waypoint x="881" y="62"/>
      <waypoint x="307" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515441_153429_420233" xmi:uuid="fe606840-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662763_999503_347415"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462674_374598_371496"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462644_583024_371447"/>
      <waypoint x="881" y="82"/>
      <waypoint x="307" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515441_968960_420236" xmi:uuid="fe607c10-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1688564041834_760216_182198"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462681_360004_371511"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462644_583024_371447"/>
      <waypoint x="881" y="102"/>
      <waypoint x="307" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515441_704671_420239" xmi:uuid="fe608d40-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662848_631814_347446"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462696_151074_371526"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462644_583024_371447"/>
      <waypoint x="881" y="122"/>
      <waypoint x="307" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515441_444578_420242" xmi:uuid="fe60a0f0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601662924_387734_347462"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462712_756531_371541"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462644_583024_371447"/>
      <waypoint x="881" y="142"/>
      <waypoint x="307" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515441_395874_420245" xmi:uuid="fe60b370-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663003_652922_347478"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462723_729656_371556"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462644_583024_371447"/>
      <waypoint x="881" y="162"/>
      <waypoint x="307" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515441_115495_420248" xmi:uuid="fe60c750-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663075_2378_347494"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462734_759599_371571"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462644_583024_371447"/>
      <waypoint x="881" y="182"/>
      <waypoint x="307" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515441_66047_420251" xmi:uuid="fe60d9a0-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663149_46658_347510"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462748_552410_371586"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462644_583024_371447"/>
      <waypoint x="881" y="202"/>
      <waypoint x="307" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515441_561273_420254" xmi:uuid="fe60ef70-6c41-013d-931e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Topology.xmi#_18_4_1_65b021e_1696601663225_988303_347526"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462757_607358_371601"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462644_583024_371447"/>
      <waypoint x="881" y="222"/>
      <waypoint x="307" y="222"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="884" height="300"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
