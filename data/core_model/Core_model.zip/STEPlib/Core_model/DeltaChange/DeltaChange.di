<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1688564041524_764343_182086" xmi:uuid="3945d6b0-0d2d-013c-5e1d-5b8e392dc4e5">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1688563977805_747035_164625"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1690217571302_913930_87146"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703182726466_518162_257602" xmi:uuid="b1d624f0-9153-013c-7148-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703182726461_464501_257591"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1690217571302_913930_87146"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703182781560_62143_263828" xmi:uuid="cebfdba0-9153-013c-7148-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703182781554_25613_263817"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1690217571302_913930_87146"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446236353_203024_208626" xmi:uuid="0b206030-6c44-013d-931b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446236347_161630_208615"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1688563977621_186432_164575"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432450_950024_232969" xmi:uuid="39758d20-0d2d-013c-5e1d-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564041464_641231_182010"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1688563977638_900768_164588"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432093_759276_232560" xmi:uuid="39773aa0-0d2d-013c-5e1d-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564040129_196482_181531"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1688563977614_529768_164569"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432402_242395_232895" xmi:uuid="39781fc0-0d2d-013c-5e1d-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564041199_290435_181808"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1688563977627_584741_164579"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432134_14814_232610" xmi:uuid="39790740-0d2d-013c-5e1d-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564040349_437361_181613"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1688563977618_99552_164572"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432118_779997_232593" xmi:uuid="3979ee60-0d2d-013c-5e1d-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564040249_584349_181575"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1688563977616_967610_164571"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432155_907243_232639" xmi:uuid="397adb50-0d2d-013c-5e1d-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564040690_73091_181657"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1688563977621_186432_164575"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432319_215046_232804" xmi:uuid="397e1f10-0d2d-013c-5e1d-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564041030_309528_181746"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1688563977624_114863_164577"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564432422_566257_232918" xmi:uuid="39802990-0d2d-013c-5e1d-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564041301_687843_181862"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_219927_164584"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446236080_939352_208307" xmi:uuid="4a962cb0-6c44-013d-931b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446236074_662036_208296"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_219927_164584"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727167459497_22861_126509" xmi:uuid="4b966ff0-6c44-013d-931b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727167459402_205312_126384"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1727167458204_442443_126382"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446236408_95540_208719" xmi:uuid="bedf78e0-6c44-013d-931b-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446236399_906825_208708"/>
    <defaultNamespace href="DeltaChange.xmi#_18_4_1_65b021e_1727167458204_442443_126382"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1688563977805_747035_164625" xmi:uuid="3945b940-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1690217571302_913930_87146"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_350840_365011" xmi:uuid="3951aa90-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977621_186432_164575"/>
      <ownedElement xmi:id="3947b0e0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3947b1f0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977621_186432_164575"/>
        <text>DeltaChange</text>
      </ownedElement>
      <ownedElement xmi:id="39481bd0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39481ca0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="39507130-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39507240-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="39507ff0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39508090-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="3950e0b0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3950e160-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040048_917187_181514"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="39514a30-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39514b10-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040190_295069_181564"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="3ebb8a80-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3ebb8ba0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040401_200071_181642"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="3951a440-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3951a4e0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040406_178214_181644"/>
          <text>Id</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="182" y="112" width="144" height="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_908421_365012" xmi:uuid="39538c10-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_219927_164584"/>
      <ownedElement xmi:id="395227e0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395228c0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_219927_164584"/>
        <text>FrozenAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="39528c70-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39528d40-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="119" y="448" width="86" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_167208_365013" xmi:uuid="3954db30-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977630_247997_164586"/>
      <ownedElement xmi:id="39540110-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395401d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977630_247997_164586"/>
        <text>DeltaChangeManagementObjectSelect</text>
      </ownedElement>
      <ownedElement xmi:id="395461c0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39546270-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="39546ed0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39546f70-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="329" y="419" width="581" height="80"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_443051_365014" xmi:uuid="39569d80-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977616_967610_164571"/>
      <ownedElement xmi:id="39554210-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395542b0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977616_967610_164571"/>
        <text>DeleteElement</text>
      </ownedElement>
      <ownedElement xmi:id="39559380-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39559420-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="504" y="273" width="67" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_947889_365015" xmi:uuid="39587c80-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977627_584741_164579"/>
      <ownedElement xmi:id="395705a0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39570650-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977627_584741_164579"/>
        <text>ModifyElement</text>
      </ownedElement>
      <ownedElement xmi:id="39576870-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39576940-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="350" y="273" width="74" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_736864_365016" xmi:uuid="395a7f30-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977618_99552_164572"/>
      <ownedElement xmi:id="3958fbe0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3958fcc0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977618_99552_164572"/>
        <text>AddElement</text>
      </ownedElement>
      <ownedElement xmi:id="39596160-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39596230-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="637" y="273" width="61" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_113052_365017" xmi:uuid="395e0ec0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977614_529768_164569"/>
      <ownedElement xmi:id="395affa0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395b0090-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977614_529768_164569"/>
        <text>DeltaChangeActivity</text>
      </ownedElement>
      <ownedElement xmi:id="395b5850-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395b5bc0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="395d2210-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395d2310-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="395d3640-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395d36e0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>values</text>
        </ownedElement>
        <ownedElement xmi:id="395d9e60-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395d9f30-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040167_82714_181557"/>
          <text>AttributeName</text>
        </ownedElement>
        <ownedElement xmi:id="395e0780-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395e0880-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040172_316734_181558"/>
          <text>ChangeLocationInAggregateAttribute</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="462" y="112" width="292" height="75"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_987117_365018" xmi:uuid="39606bd0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977638_900768_164588"/>
      <ownedElement xmi:id="395e9110-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395e92e0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977638_900768_164588"/>
        <text>ModifySingleElement</text>
      </ownedElement>
      <ownedElement xmi:id="395eff20-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="395f0010-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="784" y="273" width="101" height="50"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_526544_365019" xmi:uuid="3965f130-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977624_114863_164577"/>
      <ownedElement xmi:id="3960e120-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3960e1d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977624_114863_164577"/>
        <text>ChangeElementSequence</text>
      </ownedElement>
      <ownedElement xmi:id="39613f30-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39613ff0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="39656490-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39656590-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="39657450-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="396574f0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="3965d2c0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3965d370-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041085_79312_181782"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="3edabbd0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3edabce0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041090_950060_181783"/>
          <text>ClassifiedAs</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="875" y="112" width="146" height="86"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_955231_365050" xmi:uuid="39677010-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977639_949146_164592"/>
      <ownedElement xmi:id="39668730-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="396687f0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977639_949146_164592"/>
        <text>DeltaChangeRelationshipSelect</text>
      </ownedElement>
      <ownedElement xmi:id="3966de50-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3966def0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="396708e0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39670990-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="182" y="35" width="140" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_913126_400590" xmi:uuid="396898f0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_802540_164583"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_886591_365020" xmi:uuid="39683d10-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040775_783352_181711"/>
        <bounds x="389" y="115" width="70" height="12"/>
        <text>ChangeActivities</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_731767_365021" xmi:uuid="396856f0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040775_783352_181711"/>
        <bounds x="437" y="133" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_693969_365022" xmi:uuid="39687f60-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040176_962767_181559"/>
        <bounds x="339" y="115" width="44" height="12"/>
        <text>ChangeSet</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_518633_365023" xmi:uuid="39689390-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040176_962767_181559"/>
        <bounds x="339" y="133" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_350840_365011"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_113052_365017"/>
      <waypoint x="326" y="130"/>
      <waypoint x="462" y="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_859472_400591" xmi:uuid="3969a0a0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977630_390478_164585"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_384516_365025" xmi:uuid="39696c80-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041097_68188_181785"/>
        <bounds x="757" y="125" width="31" height="12"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_134910_365026" xmi:uuid="39697e80-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041097_68188_181785"/>
        <bounds x="757" y="143" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_759064_365027" xmi:uuid="39699ba0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041357_518782_181898"/>
        <bounds x="850" y="143" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_526544_365019"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_113052_365017"/>
      <waypoint x="875" y="140"/>
      <waypoint x="754" y="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_160877_400592" xmi:uuid="396aaa80-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_192523_164581"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_15247_365028" xmi:uuid="396a7b70-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041094_958887_181784"/>
        <bounds x="767" y="157" width="35" height="12"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_466880_365029" xmi:uuid="396a8e90-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041094_958887_181784"/>
        <bounds x="767" y="175" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_692219_365030" xmi:uuid="396aa650-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041247_406032_181836"/>
        <bounds x="850" y="175" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_526544_365019"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_113052_365017"/>
      <waypoint x="875" y="172"/>
      <waypoint x="754" y="172"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_309105_400593" xmi:uuid="396b7cf0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040058_130533_181518"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_736864_365016"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_113052_365017"/>
      <waypoint x="667" y="273"/>
      <waypoint x="667" y="210"/>
      <waypoint x="608" y="210"/>
      <waypoint x="608" y="187"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_501418_400594" xmi:uuid="396c5730-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040058_224475_181520"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_443051_365014"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_113052_365017"/>
      <waypoint x="537" y="273"/>
      <waypoint x="537" y="210"/>
      <waypoint x="608" y="210"/>
      <waypoint x="608" y="187"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_633132_400595" xmi:uuid="396d0570-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040058_368214_181517"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_947889_365015"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_113052_365017"/>
      <waypoint x="387" y="273"/>
      <waypoint x="387" y="210"/>
      <waypoint x="608" y="210"/>
      <waypoint x="608" y="187"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_93489_400596" xmi:uuid="396dfd40-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040058_119027_181519"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_987117_365018"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_113052_365017"/>
      <waypoint x="844" y="273"/>
      <waypoint x="844" y="210"/>
      <waypoint x="608" y="210"/>
      <waypoint x="608" y="187"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_195668_400597" xmi:uuid="396f0110-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_793893_164582"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_980192_365031" xmi:uuid="396ed2b0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041248_325159_181838"/>
        <bounds x="707" y="397" width="85" height="12"/>
        <text>CurrentDesignObject</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_933236_365032" xmi:uuid="396ee8c0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041248_325159_181838"/>
        <bounds x="794" y="404" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_320484_365033" xmi:uuid="396efd60-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041247_85085_181837"/>
        <bounds x="794" y="336" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_987117_365018"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_167208_365013"/>
      <waypoint x="791" y="323"/>
      <waypoint x="791" y="419"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_799096_400598" xmi:uuid="39700a10-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977624_690518_164576"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_484424_365034" xmi:uuid="396fd8b0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040866_237198_181735"/>
        <bounds x="301" y="404" width="85" height="12"/>
        <text>CurrentDesignObject</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_586853_365035" xmi:uuid="396feed0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040866_237198_181735"/>
        <bounds x="392" y="404" width="22" height="12"/>
        <text>1..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_875198_365036" xmi:uuid="39700640-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040865_740820_181734"/>
        <bounds x="392" y="319" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_947889_365015"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_167208_365013"/>
      <waypoint x="389" y="306"/>
      <waypoint x="389" y="419"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_188176_400599" xmi:uuid="39711990-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977613_370328_164568"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_680501_365037" xmi:uuid="3970e180-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040053_182122_181516"/>
        <bounds x="882" y="390" width="90" height="12"/>
        <text>PreviousDesignObject</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_406919_365038" xmi:uuid="3970f780-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040053_182122_181516"/>
        <bounds x="882" y="404" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_848705_365039" xmi:uuid="39711420-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040053_28813_181515"/>
        <bounds x="882" y="336" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_987117_365018"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_167208_365013"/>
      <waypoint x="879" y="323"/>
      <waypoint x="879" y="419"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_679153_400600" xmi:uuid="397214d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977639_873896_164589"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_31539_365040" xmi:uuid="3971e320-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040287_957487_181599"/>
        <bounds x="446" y="404" width="90" height="12"/>
        <text>PreviousDesignObject</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_755138_365041" xmi:uuid="3971fca0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040287_957487_181599"/>
        <bounds x="542" y="404" width="22" height="12"/>
        <text>1..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_394048_365042" xmi:uuid="39721110-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041512_534529_182038"/>
        <bounds x="542" y="319" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_443051_365014"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_167208_365013"/>
      <waypoint x="539" y="306"/>
      <waypoint x="539" y="419"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_384030_400601" xmi:uuid="39731ad0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_42284_164580"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_292002_365043" xmi:uuid="3972e990-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040388_904940_181637"/>
        <bounds x="581" y="404" width="85" height="12"/>
        <text>CurrentDesignObject</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_798231_365044" xmi:uuid="397301c0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040388_904940_181637"/>
        <bounds x="672" y="404" width="22" height="12"/>
        <text>1..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_756833_365045" xmi:uuid="397316e0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041246_787221_181835"/>
        <bounds x="672" y="319" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_736864_365016"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_167208_365013"/>
      <waypoint x="669" y="306"/>
      <waypoint x="669" y="419"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_925574_400602" xmi:uuid="39743270-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977626_107209_164578"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_490211_365046" xmi:uuid="39740390-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041141_569965_181797"/>
        <bounds x="272" y="451" width="54" height="12"/>
        <text>FrozenObject</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_124702_365047" xmi:uuid="39741ac0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041141_569965_181797"/>
        <bounds x="304" y="469" width="22" height="12"/>
        <text>1..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_122962_365048" xmi:uuid="39742ed0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041141_226346_181796"/>
        <bounds x="218" y="469" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_908421_365012"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_167208_365013"/>
      <waypoint x="205" y="466"/>
      <waypoint x="329" y="466"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_233809_400603" xmi:uuid="39753c70-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977639_955587_164590"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025805_986806_365051" xmi:uuid="39750bd0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040778_936305_181712"/>
        <bounds x="179" y="71" width="70" height="12"/>
        <text>DescribedChange</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025806_590840_365052" xmi:uuid="39751fd0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040778_936305_181712"/>
        <bounds x="255" y="71" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025806_894476_365053" xmi:uuid="397537a0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041512_781245_182039"/>
        <bounds x="255" y="97" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025804_350840_365011"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025805_955231_365050"/>
      <waypoint x="252" y="112"/>
      <waypoint x="252" y="68"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169696148_763691_133519" xmi:uuid="dae1d4f0-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167458204_442443_126382"/>
      <ownedElement xmi:id="da755760-6c41-013d-931b-0800270c66d6" xmi:uuid="da755870-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167458204_442443_126382"/>
        <text>DeltaChangeRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="da7f65b0-6c41-013d-931b-0800270c66d6" xmi:uuid="da7f6660-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="dae0b050-6c41-013d-931b-0800270c66d6" xmi:uuid="dae0b210-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dae10c40-6c41-013d-931b-0800270c66d6" xmi:uuid="dae10cd0-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="dae1cfb0-6c41-013d-931b-0800270c66d6" xmi:uuid="dae1d040-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459471_215084_126459"/>
          <text>RelationType</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="112" y="273" width="220" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169785805_520161_133687" xmi:uuid="db0ce760-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169785780_923636_133672"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169855399_42790_133760" xmi:uuid="db01be20-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169785780_105556_133673"/>
        <bounds x="311" y="258" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169785788_991973_133677" xmi:uuid="db056950-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459470_67707_126457"/>
        <bounds x="274" y="197" width="31" height="12"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169785789_237640_133679" xmi:uuid="db0ce090-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459470_67707_126457"/>
        <bounds x="311" y="197" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1727169696148_763691_133519"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_350840_365011"/>
      <waypoint x="308" y="273"/>
      <waypoint x="308" y="194"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169789392_268746_133715" xmi:uuid="db243fe0-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169789369_306767_133700"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169835618_179018_133748" xmi:uuid="db1ed420-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169789370_66633_133701"/>
        <bounds x="217" y="258" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169789379_69936_133705" xmi:uuid="db23d730-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459470_463691_126458"/>
        <bounds x="176" y="207" width="35" height="12"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169789379_832897_133707" xmi:uuid="db243ad0-6c41-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459470_463691_126458"/>
        <bounds x="217" y="207" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1727169696148_763691_133519"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_350840_365011"/>
      <waypoint x="214" y="273"/>
      <waypoint x="214" y="194"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1036" height="514"/>
    <name>DeltaChange</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703182726461_464501_257591" xmi:uuid="b1d592f0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1690217571302_913930_87146"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182726512_583250_257624" xmi:uuid="b1de1880-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977630_247997_164586"/>
      <ownedElement xmi:id="b1dc57b0-9153-013c-7148-0a5172f4a469" xmi:uuid="b1dc58e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977630_247997_164586"/>
        <text>DeltaChangeManagementObjectSelect</text>
      </ownedElement>
      <ownedElement xmi:id="b1dd3070-9153-013c-7148-0a5172f4a469" xmi:uuid="b1dd3160-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="b1dd8f00-9153-013c-7148-0a5172f4a469" xmi:uuid="b1dd8fb0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1317" height="1113"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182727529_771663_257695" xmi:uuid="b21f13b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="b1e6cf90-9153-013c-7148-0a5172f4a469" xmi:uuid="b1e6d0c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="b1e8e2f0-9153-013c-7148-0a5172f4a469" xmi:uuid="b1e8e430-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="170" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182727834_882531_257755" xmi:uuid="b2345a90-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityAssignment"/>
      <ownedElement xmi:id="b2213be0-9153-013c-7148-0a5172f4a469" xmi:uuid="b2213ce0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityAssignment"/>
        <text>ActivityAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="b22334f0-9153-013c-7148-0a5172f4a469" xmi:uuid="b2233600-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="255" y="95" width="170" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182728668_484385_257849" xmi:uuid="b278b290-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
      <ownedElement xmi:id="b2367800-9153-013c-7148-0a5172f4a469" xmi:uuid="b2367910-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
        <text>ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="b2387d30-9153-013c-7148-0a5172f4a469" xmi:uuid="b2387e40-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="445" y="95" width="170" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182728944_879291_257909" xmi:uuid="b28d91a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethodAssignment"/>
      <ownedElement xmi:id="b27b29b0-9153-013c-7148-0a5172f4a469" xmi:uuid="b27b2ac0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethodAssignment"/>
        <text>ActivityMethodAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="b27d2850-9153-013c-7148-0a5172f4a469" xmi:uuid="b27d2960-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="635" y="95" width="170" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182729432_13638_257981" xmi:uuid="b2a45770-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityRelationship"/>
      <ownedElement xmi:id="b28fc0c0-9153-013c-7148-0a5172f4a469" xmi:uuid="b28fc1d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityRelationship"/>
        <text>ActivityRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="b291cff0-9153-013c-7148-0a5172f4a469" xmi:uuid="b291d120-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="825" y="95" width="170" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182729580_30563_258030" xmi:uuid="b2facb20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_AddressAssignment"/>
      <ownedElement xmi:id="b2bac540-9153-013c-7148-0a5172f4a469" xmi:uuid="b2bac650-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_AddressAssignment"/>
        <text>AddressAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="b2c29600-9153-013c-7148-0a5172f4a469" xmi:uuid="b2c29720-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="143" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182729782_954398_258084" xmi:uuid="b347ec60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AlternatePartRelationship"/>
      <ownedElement xmi:id="b30a3c50-9153-013c-7148-0a5172f4a469" xmi:uuid="b30a3d50-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AlternatePartRelationship"/>
        <text>AlternatePartRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="b30f2df0-9153-013c-7148-0a5172f4a469" xmi:uuid="b30f2f00-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="313" y="143" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182730029_519797_258132" xmi:uuid="b386e770-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_ApprovalAssignment"/>
      <ownedElement xmi:id="b34eca20-9153-013c-7148-0a5172f4a469" xmi:uuid="b34ecb50-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_ApprovalAssignment"/>
        <text>ApprovalAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="b35537e0-9153-013c-7148-0a5172f4a469" xmi:uuid="b3553930-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="570" y="143" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182730351_815603_258182" xmi:uuid="b3b88020-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyOccurrenceRelationshipSubstitution"/>
      <ownedElement xmi:id="b38bed70-9153-013c-7148-0a5172f4a469" xmi:uuid="b38bee80-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyOccurrenceRelationshipSubstitution"/>
        <text>AssemblyOccurrenceRelationshipSubstitution</text>
      </ownedElement>
      <ownedElement xmi:id="b3908eb0-9153-013c-7148-0a5172f4a469" xmi:uuid="b3908fd0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="818" y="143" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182730721_450899_258231" xmi:uuid="b3e51010-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyViewRelationshipSubstitution"/>
      <ownedElement xmi:id="b3bd5820-9153-013c-7148-0a5172f4a469" xmi:uuid="b3bd5940-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyViewRelationshipSubstitution"/>
        <text>AssemblyViewRelationshipSubstitution</text>
      </ownedElement>
      <ownedElement xmi:id="b3c20760-9153-013c-7148-0a5172f4a469" xmi:uuid="b3c208a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="191" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182730934_130149_258278" xmi:uuid="b4575970-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_AssignmentObjectRelationship"/>
      <ownedElement xmi:id="b40bf4c0-9153-013c-7148-0a5172f4a469" xmi:uuid="b40bf5d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_AssignmentObjectRelationship"/>
        <text>AssignmentObjectRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="b416b340-9153-013c-7148-0a5172f4a469" xmi:uuid="b416b460-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="322" y="191" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182731952_506268_258352" xmi:uuid="b4ba7350-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_Breakdown"/>
      <ownedElement xmi:id="b46215c0-9153-013c-7148-0a5172f4a469" xmi:uuid="b46216e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_Breakdown"/>
        <text>Breakdown</text>
      </ownedElement>
      <ownedElement xmi:id="b4652dd0-9153-013c-7148-0a5172f4a469" xmi:uuid="b4652f70-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="557" y="191" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182733004_163969_258426" xmi:uuid="b5145880-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
      <ownedElement xmi:id="b4bd5d20-9153-013c-7148-0a5172f4a469" xmi:uuid="b4bd5e20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
        <text>BreakdownElement</text>
      </ownedElement>
      <ownedElement xmi:id="b4c029b0-9153-013c-7148-0a5172f4a469" xmi:uuid="b4c02ac0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="759" y="191" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182733252_908377_258479" xmi:uuid="b53b70c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementRealization"/>
      <ownedElement xmi:id="b5176e00-9153-013c-7148-0a5172f4a469" xmi:uuid="b5176f60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementRealization"/>
        <text>BreakdownElementRealization</text>
      </ownedElement>
      <ownedElement xmi:id="b51a5140-9153-013c-7148-0a5172f4a469" xmi:uuid="b51a5270-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="961" y="191" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182734169_783574_258552" xmi:uuid="b5765bf0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersion"/>
      <ownedElement xmi:id="b53e8fd0-9153-013c-7148-0a5172f4a469" xmi:uuid="b53e90e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersion"/>
        <text>BreakdownElementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="b5416bd0-9153-013c-7148-0a5172f4a469" xmi:uuid="b5416d00-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="239" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182734582_519177_258620" xmi:uuid="b58e2540-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersionRelationship"/>
      <ownedElement xmi:id="b5796290-9153-013c-7148-0a5172f4a469" xmi:uuid="b5796390-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersionRelationship"/>
        <text>BreakdownElementVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="b57c5ac0-9153-013c-7148-0a5172f4a469" xmi:uuid="b57c5bf0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="267" y="239" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182735691_793076_258703" xmi:uuid="b5e10e40-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
      <ownedElement xmi:id="b5911d40-9153-013c-7148-0a5172f4a469" xmi:uuid="b5911e50-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
        <text>BreakdownElementView</text>
      </ownedElement>
      <ownedElement xmi:id="b593f540-9153-013c-7148-0a5172f4a469" xmi:uuid="b593f670-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="469" y="239" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182736038_272546_258769" xmi:uuid="b5f440b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementViewRelationship"/>
      <ownedElement xmi:id="b5e42b50-9153-013c-7148-0a5172f4a469" xmi:uuid="b5e42c70-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementViewRelationship"/>
        <text>BreakdownElementViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="b5e714b0-9153-013c-7148-0a5172f4a469" xmi:uuid="b5e715e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="671" y="239" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182736768_566642_258840" xmi:uuid="b6299b20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersion"/>
      <ownedElement xmi:id="b5f733a0-9153-013c-7148-0a5172f4a469" xmi:uuid="b5f734d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersion"/>
        <text>BreakdownVersion</text>
      </ownedElement>
      <ownedElement xmi:id="b5fa0bd0-9153-013c-7148-0a5172f4a469" xmi:uuid="b5fa0cf0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="873" y="239" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182737134_149215_258908" xmi:uuid="b64106f0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersionRelationship"/>
      <ownedElement xmi:id="b62ca070-9153-013c-7148-0a5172f4a469" xmi:uuid="b62ca190-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersionRelationship"/>
        <text>BreakdownVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="b62f7380-9153-013c-7148-0a5172f4a469" xmi:uuid="b62f74b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="287" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182737375_280328_258957" xmi:uuid="b6804280-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_CertificationAssignment"/>
      <ownedElement xmi:id="b647af90-9153-013c-7148-0a5172f4a469" xmi:uuid="b647b090-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_CertificationAssignment"/>
        <text>CertificationAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="b64e04f0-9153-013c-7148-0a5172f4a469" xmi:uuid="b64e0610-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="267" y="287" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182737873_471127_259016" xmi:uuid="b7591090-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Class"/>
      <ownedElement xmi:id="b68b9d00-9153-013c-7148-0a5172f4a469" xmi:uuid="b68b9e10-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Class"/>
        <text>Class</text>
      </ownedElement>
      <ownedElement xmi:id="b6963140-9153-013c-7148-0a5172f4a469" xmi:uuid="b6963260-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="515" y="287" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182738802_428904_259094" xmi:uuid="b8ff5110-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Condition"/>
      <ownedElement xmi:id="b7647520-9153-013c-7148-0a5172f4a469" xmi:uuid="b7647620-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Condition"/>
        <text>Condition</text>
      </ownedElement>
      <ownedElement xmi:id="b76f50a0-9153-013c-7148-0a5172f4a469" xmi:uuid="b76f51d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="750" y="287" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182739130_380147_259155" xmi:uuid="b98a2140-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_ConditionAssignment"/>
      <ownedElement xmi:id="b90aee60-9153-013c-7148-0a5172f4a469" xmi:uuid="b90aef70-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_ConditionAssignment"/>
        <text>ConditionAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="b91578f0-9153-013c-7148-0a5172f4a469" xmi:uuid="b9157a20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="985" y="287" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182740250_31257_259230" xmi:uuid="b9de1510-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ConfiguredAssemblyEffectivity"/>
      <ownedElement xmi:id="b9930ff0-9153-013c-7148-0a5172f4a469" xmi:uuid="b99311e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ConfiguredAssemblyEffectivity"/>
        <text>ConfiguredAssemblyEffectivity</text>
      </ownedElement>
      <ownedElement xmi:id="b99574e0-9153-013c-7148-0a5172f4a469" xmi:uuid="b9957600-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="335" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182740854_377009_259294" xmi:uuid="ba7b2550-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Contract"/>
      <ownedElement xmi:id="b9e48e40-9153-013c-7148-0a5172f4a469" xmi:uuid="b9e48f50-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Contract"/>
        <text>Contract</text>
      </ownedElement>
      <ownedElement xmi:id="b9eb5850-9153-013c-7148-0a5172f4a469" xmi:uuid="b9eb5970-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="378" y="335" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182741177_35691_259355" xmi:uuid="bacbad20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_ContractAssignment"/>
      <ownedElement xmi:id="ba81ea90-9153-013c-7148-0a5172f4a469" xmi:uuid="ba81ebb0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_ContractAssignment"/>
        <text>ContractAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="ba884030-9153-013c-7148-0a5172f4a469" xmi:uuid="ba884140-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="626" y="335" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182741304_145620_259405" xmi:uuid="bb4bbb20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_DateTimeAssignment"/>
      <ownedElement xmi:id="bad6f640-9153-013c-7148-0a5172f4a469" xmi:uuid="bad6f860-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_DateTimeAssignment"/>
        <text>DateTimeAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="bae19840-9153-013c-7148-0a5172f4a469" xmi:uuid="bae19970-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="874" y="335" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182742354_370369_259479" xmi:uuid="bb9313f0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_Document"/>
      <ownedElement xmi:id="bb535d70-9153-013c-7148-0a5172f4a469" xmi:uuid="bb535e80-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_Document"/>
        <text>Document</text>
      </ownedElement>
      <ownedElement xmi:id="bb559370-9153-013c-7148-0a5172f4a469" xmi:uuid="bb559480-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="383" width="229" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182742492_109456_259529" xmi:uuid="bbaa01d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentAssignment"/>
      <ownedElement xmi:id="bb956650-9153-013c-7148-0a5172f4a469" xmi:uuid="bb956770-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentAssignment"/>
        <text>DocumentAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="bb978d60-9153-013c-7148-0a5172f4a469" xmi:uuid="bb978e80-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="314" y="383" width="229" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182743436_775054_259595" xmi:uuid="bbddf8c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
      <ownedElement xmi:id="bbac5330-9153-013c-7148-0a5172f4a469" xmi:uuid="bbac5490-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
        <text>DocumentDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="bbaeaee0-9153-013c-7148-0a5172f4a469" xmi:uuid="bbaeb010-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="563" y="383" width="229" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182743826_484028_259664" xmi:uuid="bbf14480-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinitionRelationship"/>
      <ownedElement xmi:id="bbe041c0-9153-013c-7148-0a5172f4a469" xmi:uuid="bbe042c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinitionRelationship"/>
        <text>DocumentDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="bbe26560-9153-013c-7148-0a5172f4a469" xmi:uuid="bbe26680-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="812" y="383" width="229" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182744758_572421_259749" xmi:uuid="bc1bd8b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
      <ownedElement xmi:id="bbf39790-9153-013c-7148-0a5172f4a469" xmi:uuid="bbf3a160-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
        <text>DocumentVersion</text>
      </ownedElement>
      <ownedElement xmi:id="bbf5e410-9153-013c-7148-0a5172f4a469" xmi:uuid="bbf5e7a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="431" width="229" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182745177_269209_259817" xmi:uuid="bc2d2aa0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersionRelationship"/>
      <ownedElement xmi:id="bc1e1510-9153-013c-7148-0a5172f4a469" xmi:uuid="bc1e1670-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersionRelationship"/>
        <text>DocumentVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="bc2041b0-9153-013c-7148-0a5172f4a469" xmi:uuid="bc2042d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="314" y="431" width="229" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182745900_314343_259892" xmi:uuid="bd4a8ee0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Effectivity"/>
      <ownedElement xmi:id="bc38e430-9153-013c-7148-0a5172f4a469" xmi:uuid="bc38e8d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Effectivity"/>
        <text>Effectivity</text>
      </ownedElement>
      <ownedElement xmi:id="bc43ac00-9153-013c-7148-0a5172f4a469" xmi:uuid="bc43ad20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="563" y="431" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182746192_982189_259954" xmi:uuid="bde92400-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_EffectivityAssignment"/>
      <ownedElement xmi:id="bd55d8d0-9153-013c-7148-0a5172f4a469" xmi:uuid="bd55d9d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_EffectivityAssignment"/>
        <text>EffectivityAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="bd60b090-9153-013c-7148-0a5172f4a469" xmi:uuid="bd60b1c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="798" y="431" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182746790_719955_260019" xmi:uuid="bf0743d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Event"/>
      <ownedElement xmi:id="bdf496c0-9153-013c-7148-0a5172f4a469" xmi:uuid="bdf497c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Event"/>
        <text>Event</text>
      </ownedElement>
      <ownedElement xmi:id="bdff3cf0-9153-013c-7148-0a5172f4a469" xmi:uuid="bdff3e30-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="479" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182747039_611475_260079" xmi:uuid="bf88ec10-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_EventAssignment"/>
      <ownedElement xmi:id="bf128b40-9153-013c-7148-0a5172f4a469" xmi:uuid="bf128c80-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_EventAssignment"/>
        <text>EventAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="bf1d98c0-9153-013c-7148-0a5172f4a469" xmi:uuid="bf1d99e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="300" y="479" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182747089_264155_260124" xmi:uuid="bfcdafb0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_ExternalOwlClass"/>
      <ownedElement xmi:id="bf9517f0-9153-013c-7148-0a5172f4a469" xmi:uuid="bf951930-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_ExternalOwlClass"/>
        <text>ExternalOwlClass</text>
      </ownedElement>
      <ownedElement xmi:id="bfa08730-9153-013c-7148-0a5172f4a469" xmi:uuid="bfa08870-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="535" y="479" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182747768_517323_260189" xmi:uuid="c0013d90-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_File"/>
      <ownedElement xmi:id="bfd03620-9153-013c-7148-0a5172f4a469" xmi:uuid="bfd03740-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_File"/>
        <text>File</text>
      </ownedElement>
      <ownedElement xmi:id="bfd26dd0-9153-013c-7148-0a5172f4a469" xmi:uuid="bfd26ee0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="770" y="479" width="229" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182747954_889300_260249" xmi:uuid="c0073810-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_219927_164584"/>
      <ownedElement xmi:id="c0022b50-9153-013c-7148-0a5172f4a469" xmi:uuid="c0022c50-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_219927_164584"/>
        <text>FrozenAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="c0030d00-9153-013c-7148-0a5172f4a469" xmi:uuid="c0030e80-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="527" width="188" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182748389_801249_260303" xmi:uuid="c028cfc0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualAssemblyRelationship"/>
      <ownedElement xmi:id="c00ff5f0-9153-013c-7148-0a5172f4a469" xmi:uuid="c00ff6f0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualAssemblyRelationship"/>
        <text>IndividualAssemblyRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c01236f0-9153-013c-7148-0a5172f4a469" xmi:uuid="c0123800-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="273" y="527" width="194" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182749319_875977_260372" xmi:uuid="c0636750-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
      <ownedElement xmi:id="c02b4750-9153-013c-7148-0a5172f4a469" xmi:uuid="c02b4880-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
        <text>IndividualPart</text>
      </ownedElement>
      <ownedElement xmi:id="c02da900-9153-013c-7148-0a5172f4a469" xmi:uuid="c02daa40-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="487" y="527" width="194" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182750242_977910_260446" xmi:uuid="c09127c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
      <ownedElement xmi:id="c065cd40-9153-013c-7148-0a5172f4a469" xmi:uuid="c065ce70-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
        <text>IndividualPartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="c06840e0-9153-013c-7148-0a5172f4a469" xmi:uuid="c0684210-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="701" y="527" width="194" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182750667_672469_260514" xmi:uuid="c0a32e90-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersionRelationship"/>
      <ownedElement xmi:id="c0938ef0-9153-013c-7148-0a5172f4a469" xmi:uuid="c0939000-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersionRelationship"/>
        <text>IndividualPartVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c095d790-9153-013c-7148-0a5172f4a469" xmi:uuid="c095da40-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="915" y="527" width="194" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182751610_762831_260599" xmi:uuid="c0d42620-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="c0a5dd80-9153-013c-7148-0a5172f4a469" xmi:uuid="c0a5df60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="c0a84060-9153-013c-7148-0a5172f4a469" xmi:uuid="c0a841b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="575" width="194" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182751962_317232_260665" xmi:uuid="c0e2ee60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartViewRelationship"/>
      <ownedElement xmi:id="c0d673a0-9153-013c-7148-0a5172f4a469" xmi:uuid="c0d674b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartViewRelationship"/>
        <text>IndividualPartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c0d8ba90-9153-013c-7148-0a5172f4a469" xmi:uuid="c0d8bbd0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="279" y="575" width="194" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182752224_696674_260715" xmi:uuid="c12d6e30-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_InformationUsageRightAssignment"/>
      <ownedElement xmi:id="c0e985d0-9153-013c-7148-0a5172f4a469" xmi:uuid="c0e986e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_InformationUsageRightAssignment"/>
        <text>InformationUsageRightAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="c0efe6f0-9153-013c-7148-0a5172f4a469" xmi:uuid="c0efe830-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="493" y="575" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182752811_114399_260781" xmi:uuid="c15ec640-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1690302888451_91067_85148"/>
      <ownedElement xmi:id="c134b700-9153-013c-7148-0a5172f4a469" xmi:uuid="c134b810-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1690302888451_91067_85148"/>
        <text>ModelPropertyAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="c136ae00-9153-013c-7148-0a5172f4a469" xmi:uuid="c136af10-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="741" y="575" width="261" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182753070_241744_260830" xmi:uuid="c16af040-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625041013271_622061_69733"/>
      <ownedElement xmi:id="c1637200-9153-013c-7148-0a5172f4a469" xmi:uuid="c1637300-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625041013271_622061_69733"/>
        <text>ObservationAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="c1648d30-9153-013c-7148-0a5172f4a469" xmi:uuid="c1648e70-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="623" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182753555_996864_260890" xmi:uuid="c17a7850-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625040927267_106169_69647"/>
      <ownedElement xmi:id="c16c3a10-9153-013c-7148-0a5172f4a469" xmi:uuid="c16c3b40-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625040927267_106169_69647"/>
        <text>ObservationConsequence</text>
      </ownedElement>
      <ownedElement xmi:id="c16d5ec0-9153-013c-7148-0a5172f4a469" xmi:uuid="c16d6010-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="270" y="623" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182754229_73673_260952" xmi:uuid="c1e17460-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Occurrence"/>
      <ownedElement xmi:id="c17f4640-9153-013c-7148-0a5172f4a469" xmi:uuid="c17f4760-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Occurrence"/>
        <text>Occurrence</text>
      </ownedElement>
      <ownedElement xmi:id="c183e660-9153-013c-7148-0a5172f4a469" xmi:uuid="c183e790-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="475" y="623" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182754583_790663_261018" xmi:uuid="c200e2d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_OccurrenceRelationship"/>
      <ownedElement xmi:id="c1e64fb0-9153-013c-7148-0a5172f4a469" xmi:uuid="c1e650b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_OccurrenceRelationship"/>
        <text>OccurrenceRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c1eaecc0-9153-013c-7148-0a5172f4a469" xmi:uuid="c1eaedd0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="732" y="623" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182755353_153080_261095" xmi:uuid="c2afcb00-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
      <ownedElement xmi:id="c2077870-9153-013c-7148-0a5172f4a469" xmi:uuid="c2077990-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
        <text>Organization</text>
      </ownedElement>
      <ownedElement xmi:id="c20dc250-9153-013c-7148-0a5172f4a469" xmi:uuid="c20dc370-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="989" y="623" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182756422_385016_261170" xmi:uuid="c352cb70-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
      <ownedElement xmi:id="c2b4c550-9153-013c-7148-0a5172f4a469" xmi:uuid="c2b4c770-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
        <text>Part</text>
      </ownedElement>
      <ownedElement xmi:id="c2b97dc0-9153-013c-7148-0a5172f4a469" xmi:uuid="c2b97f20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="671" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182757460_185713_261245" xmi:uuid="c3bf8990-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
      <ownedElement xmi:id="c357a510-9153-013c-7148-0a5172f4a469" xmi:uuid="c357a6c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
        <text>PartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="c35c4c70-9153-013c-7148-0a5172f4a469" xmi:uuid="c35c4da0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="322" y="671" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182757898_170381_261313" xmi:uuid="c3e75e40-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersionRelationship"/>
      <ownedElement xmi:id="c3c49ce0-9153-013c-7148-0a5172f4a469" xmi:uuid="c3c49e00-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersionRelationship"/>
        <text>PartVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c3c93560-9153-013c-7148-0a5172f4a469" xmi:uuid="c3c93680-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="579" y="671" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182758894_741856_261390" xmi:uuid="c45735c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="c3ec2a60-9153-013c-7148-0a5172f4a469" xmi:uuid="c3ec2b70-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="c3f0d470-9153-013c-7148-0a5172f4a469" xmi:uuid="c3f0d5a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="836" y="671" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182759271_349512_261456" xmi:uuid="c47678e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
      <ownedElement xmi:id="c45c10e0-9153-013c-7148-0a5172f4a469" xmi:uuid="c45c1280-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
        <text>PartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c460acb0-9153-013c-7148-0a5172f4a469" xmi:uuid="c460add0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="719" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182760073_910121_261519" xmi:uuid="c50e03a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
      <ownedElement xmi:id="c47cff90-9153-013c-7148-0a5172f4a469" xmi:uuid="c47d0090-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
        <text>Person</text>
      </ownedElement>
      <ownedElement xmi:id="c4835e60-9153-013c-7148-0a5172f4a469" xmi:uuid="c4835ff0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="322" y="719" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182761104_390045_261609" xmi:uuid="c5c4c7b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
      <ownedElement xmi:id="c514cb20-9153-013c-7148-0a5172f4a469" xmi:uuid="c514cc60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
        <text>PersonInOrganization</text>
      </ownedElement>
      <ownedElement xmi:id="c51b4650-9153-013c-7148-0a5172f4a469" xmi:uuid="c51b4780-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="570" y="719" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182762021_110923_261681" xmi:uuid="c5fea120-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977023_906034_164255"/>
      <ownedElement xmi:id="c5cc0fb0-9153-013c-7148-0a5172f4a469" xmi:uuid="c5cc10d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977023_906034_164255"/>
        <text>ProcessOperationDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="c5ce01b0-9153-013c-7148-0a5172f4a469" xmi:uuid="c5ce02d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="818" y="719" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182762787_907749_261752" xmi:uuid="c623ce10-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
      <ownedElement xmi:id="c600bbc0-9153-013c-7148-0a5172f4a469" xmi:uuid="c600bcf0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
        <text>ProcessOperationOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="c602c660-9153-013c-7148-0a5172f4a469" xmi:uuid="c602c7a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="767" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182763176_12188_261820" xmi:uuid="c644afc0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977046_532260_164273"/>
      <ownedElement xmi:id="c6265280-9153-013c-7148-0a5172f4a469" xmi:uuid="c6265430-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977046_532260_164273"/>
        <text>ProcessOperationResourceAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="c6287e80-9153-013c-7148-0a5172f4a469" xmi:uuid="c6288040-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="270" y="767" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182764158_659910_261908" xmi:uuid="c6753160-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977013_677082_164248"/>
      <ownedElement xmi:id="c646d8d0-9153-013c-7148-0a5172f4a469" xmi:uuid="c646d9e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977013_677082_164248"/>
        <text>ProcessPlan</text>
      </ownedElement>
      <ownedElement xmi:id="c648fd50-9153-013c-7148-0a5172f4a469" xmi:uuid="c648fe90-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="475" y="767" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182764286_574241_261954" xmi:uuid="c6880410-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductClass"/>
      <ownedElement xmi:id="c677e9b0-9153-013c-7148-0a5172f4a469" xmi:uuid="c677eac0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductClass"/>
        <text>ProductClass</text>
      </ownedElement>
      <ownedElement xmi:id="c67a7c10-9153-013c-7148-0a5172f4a469" xmi:uuid="c67a7e20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="680" y="767" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182765369_891181_262023" xmi:uuid="c6ca85c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConfiguration"/>
      <ownedElement xmi:id="c68ae4a0-9153-013c-7148-0a5172f4a469" xmi:uuid="c68ae5d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConfiguration"/>
        <text>ProductConfiguration</text>
      </ownedElement>
      <ownedElement xmi:id="c68d8700-9153-013c-7148-0a5172f4a469" xmi:uuid="c68d8870-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="993" y="767" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182766243_805138_262093" xmi:uuid="c78e3dc0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Project"/>
      <ownedElement xmi:id="c6d142f0-9153-013c-7148-0a5172f4a469" xmi:uuid="c6d146f0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Project"/>
        <text>Project</text>
      </ownedElement>
      <ownedElement xmi:id="c6d7bb20-9153-013c-7148-0a5172f4a469" xmi:uuid="c6d7bc80-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="815" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182766535_62824_262153" xmi:uuid="c7d99e70-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_ProjectAssignment"/>
      <ownedElement xmi:id="c794d770-9153-013c-7148-0a5172f4a469" xmi:uuid="c794d880-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_ProjectAssignment"/>
        <text>ProjectAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="c79b41d0-9153-013c-7148-0a5172f4a469" xmi:uuid="c79b42f0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="313" y="815" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182766912_207809_262222" xmi:uuid="c818f6a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_ProjectRelationship"/>
      <ownedElement xmi:id="c7e06810-9153-013c-7148-0a5172f4a469" xmi:uuid="c7e06950-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_ProjectRelationship"/>
        <text>ProjectRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c7e6c3a0-9153-013c-7148-0a5172f4a469" xmi:uuid="c7e6c4d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="561" y="815" width="228" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182767283_891824_262273" xmi:uuid="c896f1b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionAssignment"/>
      <ownedElement xmi:id="c82495f0-9153-013c-7148-0a5172f4a469" xmi:uuid="c8249720-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionAssignment"/>
        <text>PropertyDefinitionAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="c82f7e90-9153-013c-7148-0a5172f4a469" xmi:uuid="c82f7fc0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="809" y="815" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182767849_436260_262322" xmi:uuid="c9051f20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionRelationship"/>
      <ownedElement xmi:id="c8a27760-9153-013c-7148-0a5172f4a469" xmi:uuid="c8a278b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionRelationship"/>
        <text>PropertyDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c8ad6a90-9153-013c-7148-0a5172f4a469" xmi:uuid="c8ad6bb0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="863" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182768620_321440_262377" xmi:uuid="c9d45190-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValue"/>
      <ownedElement xmi:id="c910a7d0-9153-013c-7148-0a5172f4a469" xmi:uuid="c910a960-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValue"/>
        <text>PropertyValue</text>
      </ownedElement>
      <ownedElement xmi:id="c91b8e30-9153-013c-7148-0a5172f4a469" xmi:uuid="c91b8f60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="300" y="863" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182769096_526027_262450" xmi:uuid="ca77b0d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueAssignment"/>
      <ownedElement xmi:id="c9dfa420-9153-013c-7148-0a5172f4a469" xmi:uuid="c9dfa540-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueAssignment"/>
        <text>PropertyValueAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="c9ea9a80-9153-013c-7148-0a5172f4a469" xmi:uuid="c9ea9be0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="535" y="863" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182769419_400097_262518" xmi:uuid="cadb7c30-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueRelationship"/>
      <ownedElement xmi:id="ca833360-9153-013c-7148-0a5172f4a469" xmi:uuid="ca833490-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueRelationship"/>
        <text>PropertyValueRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="ca8ea2c0-9153-013c-7148-0a5172f4a469" xmi:uuid="ca8ea400-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="770" y="863" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182770470_289577_262589" xmi:uuid="cb1ed300-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_Representation"/>
      <ownedElement xmi:id="cae3cdc0-9153-013c-7148-0a5172f4a469" xmi:uuid="cae3d0c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_Representation"/>
        <text>Representation</text>
      </ownedElement>
      <ownedElement xmi:id="cae621c0-9153-013c-7148-0a5172f4a469" xmi:uuid="cae62310-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="1005" y="863" width="317" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182771508_664310_262658" xmi:uuid="cb6dcaa0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
      <ownedElement xmi:id="cb2921b0-9153-013c-7148-0a5172f4a469" xmi:uuid="cb2922e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
        <text>Requirement</text>
      </ownedElement>
      <ownedElement xmi:id="cb2bc520-9153-013c-7148-0a5172f4a469" xmi:uuid="cb2bc640-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="911" width="239" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182772304_261234_262714" xmi:uuid="cb986170-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementAssignment"/>
      <ownedElement xmi:id="cb7096c0-9153-013c-7148-0a5172f4a469" xmi:uuid="cb709830-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementAssignment"/>
        <text>RequirementAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="cb734390-9153-013c-7148-0a5172f4a469" xmi:uuid="cb7344d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="324" y="911" width="239" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182773817_601146_262788" xmi:uuid="cbcfd2e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
      <ownedElement xmi:id="cb9b15c0-9153-013c-7148-0a5172f4a469" xmi:uuid="cb9b16d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
        <text>RequirementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="cb9dba70-9153-013c-7148-0a5172f4a469" xmi:uuid="cb9dbba0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="583" y="911" width="239" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182774451_88976_262856" xmi:uuid="cbe57e20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersionRelationship"/>
      <ownedElement xmi:id="cbd2a1a0-9153-013c-7148-0a5172f4a469" xmi:uuid="cbd2a310-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersionRelationship"/>
        <text>RequirementVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cbd54240-9153-013c-7148-0a5172f4a469" xmi:uuid="cbd54360-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="842" y="911" width="239" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182775769_670321_262955" xmi:uuid="cc27cea0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
      <ownedElement xmi:id="cbe869e0-9153-013c-7148-0a5172f4a469" xmi:uuid="cbe86b20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
        <text>RequirementView</text>
      </ownedElement>
      <ownedElement xmi:id="cbeb1ae0-9153-013c-7148-0a5172f4a469" xmi:uuid="cbeb1c00-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="959" width="239" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182776217_706222_263021" xmi:uuid="cc3958f0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementViewRelationship"/>
      <ownedElement xmi:id="cc2aa4b0-9153-013c-7148-0a5172f4a469" xmi:uuid="cc2aa5e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementViewRelationship"/>
        <text>RequirementViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cc2d6ae0-9153-013c-7148-0a5172f4a469" xmi:uuid="cc2d6c60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="324" y="959" width="239" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182776553_848939_263072" xmi:uuid="ccc793b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_SecurityClassificationAssignment"/>
      <ownedElement xmi:id="cc44f4a0-9153-013c-7148-0a5172f4a469" xmi:uuid="cc44f5c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_SecurityClassificationAssignment"/>
        <text>SecurityClassificationAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="cc4fe660-9153-013c-7148-0a5172f4a469" xmi:uuid="cc4fe790-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="583" y="959" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182777404_620590_263148" xmi:uuid="cd0413d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_Specification"/>
      <ownedElement xmi:id="ccca4e90-9153-013c-7148-0a5172f4a469" xmi:uuid="ccca4fe0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_Specification"/>
        <text>Specification</text>
      </ownedElement>
      <ownedElement xmi:id="cccce610-9153-013c-7148-0a5172f4a469" xmi:uuid="cccce730-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="818" y="959" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182777743_23076_263218" xmi:uuid="cd1ed5a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationAssignment"/>
      <ownedElement xmi:id="cd06e960-9153-013c-7148-0a5172f4a469" xmi:uuid="cd06ea90-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationAssignment"/>
        <text>SpecificationAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="cd097450-9153-013c-7148-0a5172f4a469" xmi:uuid="cd097720-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1007" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182778267_909884_263286" xmi:uuid="cd4ada50-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationCategory"/>
      <ownedElement xmi:id="cd2189d0-9153-013c-7148-0a5172f4a469" xmi:uuid="cd218b40-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationCategory"/>
        <text>SpecificationCategory</text>
      </ownedElement>
      <ownedElement xmi:id="cd2410c0-9153-013c-7148-0a5172f4a469" xmi:uuid="cd2411f0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="378" y="1007" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182778674_413319_263357" xmi:uuid="cd67ddd0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationCategoryAssignment"/>
      <ownedElement xmi:id="cd4dc900-9153-013c-7148-0a5172f4a469" xmi:uuid="cd4dca30-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationCategoryAssignment"/>
        <text>SpecificationCategoryAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="cd505820-9153-013c-7148-0a5172f4a469" xmi:uuid="cd505960-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="691" y="1007" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182779026_87785_263426" xmi:uuid="cd804250-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationConditionAssignment"/>
      <ownedElement xmi:id="cd6a6600-9153-013c-7148-0a5172f4a469" xmi:uuid="cd6a6720-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationConditionAssignment"/>
        <text>SpecificationConditionAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="cd6cea00-9153-013c-7148-0a5172f4a469" xmi:uuid="cd6ceb40-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="1004" y="1007" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182779560_266196_263485" xmi:uuid="cdad2980-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationInclusion"/>
      <ownedElement xmi:id="cd82f540-9153-013c-7148-0a5172f4a469" xmi:uuid="cd82f640-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationInclusion"/>
        <text>SpecificationInclusion</text>
      </ownedElement>
      <ownedElement xmi:id="cd857b70-9153-013c-7148-0a5172f4a469" xmi:uuid="cd857cb0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1055" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182779937_899157_263554" xmi:uuid="cdc5a0c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationInclusionAssignment"/>
      <ownedElement xmi:id="cdafcbc0-9153-013c-7148-0a5172f4a469" xmi:uuid="cdafcce0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationInclusionAssignment"/>
        <text>SpecificationInclusionAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="cdb24260-9153-013c-7148-0a5172f4a469" xmi:uuid="cdb243a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="378" y="1055" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182780190_972712_263606" xmi:uuid="ce5d8cd0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_TimeIntervalAssignment"/>
      <ownedElement xmi:id="cdd1be30-9153-013c-7148-0a5172f4a469" xmi:uuid="cdd1bf50-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_TimeIntervalAssignment"/>
        <text>TimeIntervalAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="cddc75d0-9153-013c-7148-0a5172f4a469" xmi:uuid="cddc7710-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="691" y="1055" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182780667_829715_263668" xmi:uuid="ce9cfc50-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ViewOccurrenceRelationship"/>
      <ownedElement xmi:id="ce62af40-9153-013c-7148-0a5172f4a469" xmi:uuid="ce62b080-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ViewOccurrenceRelationship"/>
        <text>ViewOccurrenceRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="ce676da0-9153-013c-7148-0a5172f4a469" xmi:uuid="ce676f90-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="926" y="1055" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182781119_26625_263724" xmi:uuid="ceb137a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkOrderAssignment"/>
      <ownedElement xmi:id="cea206c0-9153-013c-7148-0a5172f4a469" xmi:uuid="cea207c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkOrderAssignment"/>
        <text>WorkOrderAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="cea34990-9153-013c-7148-0a5172f4a469" xmi:uuid="cea34ac0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1103" width="210" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182781528_8716_263776" xmi:uuid="cebed5d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkRequestAssignment"/>
      <ownedElement xmi:id="ceb2a090-9153-013c-7148-0a5172f4a469" xmi:uuid="ceb2a1c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkRequestAssignment"/>
        <text>WorkRequestAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="ceb3f170-9153-013c-7148-0a5172f4a469" xmi:uuid="ceb3f290-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="295" y="1103" width="210" height="33"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1377" height="1183"/>
    <name>DeltaChangeManagementObjectSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703182781554_25613_263817" xmi:uuid="cebf6630-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1690217571302_913930_87146"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182781584_658763_263849" xmi:uuid="cec3c010-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977639_949146_164592"/>
      <ownedElement xmi:id="cec1e1e0-9153-013c-7148-0a5172f4a469" xmi:uuid="cec1e310-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977639_949146_164592"/>
        <text>DeltaChangeRelationshipSelect</text>
      </ownedElement>
      <ownedElement xmi:id="cec2b810-9153-013c-7148-0a5172f4a469" xmi:uuid="cec2b920-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="cec31610-9153-013c-7148-0a5172f4a469" xmi:uuid="cec316e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1165" height="297"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182782129_726397_263901" xmi:uuid="ceda6790-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityRelationship"/>
      <ownedElement xmi:id="cec5f340-9153-013c-7148-0a5172f4a469" xmi:uuid="cec5f470-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityRelationship"/>
        <text>ActivityRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cec7fc20-9153-013c-7148-0a5172f4a469" xmi:uuid="cec7fd50-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="170" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182782587_123753_263949" xmi:uuid="cef2d2e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersionRelationship"/>
      <ownedElement xmi:id="cedd8fe0-9153-013c-7148-0a5172f4a469" xmi:uuid="cedd90e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersionRelationship"/>
        <text>BreakdownElementVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cee07600-9153-013c-7148-0a5172f4a469" xmi:uuid="cee07730-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="255" y="95" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182783060_54823_263997" xmi:uuid="cf048350-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersionRelationship"/>
      <ownedElement xmi:id="cef54a30-9153-013c-7148-0a5172f4a469" xmi:uuid="cef54b60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersionRelationship"/>
        <text>DocumentVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cef78ca0-9153-013c-7148-0a5172f4a469" xmi:uuid="cef78dd0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="457" y="95" width="229" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182783470_373079_264046" xmi:uuid="cf729770-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_EffectivityRelationship"/>
      <ownedElement xmi:id="cf0feb70-9153-013c-7148-0a5172f4a469" xmi:uuid="cf0fec80-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_EffectivityRelationship"/>
        <text>EffectivityRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cf1a9d10-9153-013c-7148-0a5172f4a469" xmi:uuid="cf1a9e80-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="706" y="95" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182783823_799381_264095" xmi:uuid="cf86a3e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_FileRelationship"/>
      <ownedElement xmi:id="cf74e1e0-9153-013c-7148-0a5172f4a469" xmi:uuid="cf74e2e0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_FileRelationship"/>
        <text>FileRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cf772d00-9153-013c-7148-0a5172f4a469" xmi:uuid="cf772e40-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="941" y="95" width="229" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182784235_305523_264145" xmi:uuid="cf8f3ad0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625040898729_393158_69604"/>
      <ownedElement xmi:id="cf87e430-9153-013c-7148-0a5172f4a469" xmi:uuid="cf87e550-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625040898729_393158_69604"/>
        <text>ObservationRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cf891920-9153-013c-7148-0a5172f4a469" xmi:uuid="cf891a40-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="143" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182784719_121889_264193" xmi:uuid="cfb933b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersionRelationship"/>
      <ownedElement xmi:id="cf940a60-9153-013c-7148-0a5172f4a469" xmi:uuid="cf940b60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersionRelationship"/>
        <text>PartVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cf98b670-9153-013c-7148-0a5172f4a469" xmi:uuid="cf98b7b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="270" y="143" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182785021_997762_264243" xmi:uuid="cfcc09f0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977062_967795_164287"/>
      <ownedElement xmi:id="cfbb6470-9153-013c-7148-0a5172f4a469" xmi:uuid="cfbb6570-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977062_967795_164287"/>
        <text>ProcessOperationDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cfbd73f0-9153-013c-7148-0a5172f4a469" xmi:uuid="cfbd7520-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="527" y="143" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182785527_957817_264299" xmi:uuid="cfe865c0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977057_168128_164282"/>
      <ownedElement xmi:id="cfce1820-9153-013c-7148-0a5172f4a469" xmi:uuid="cfce1930-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977057_168128_164282"/>
        <text>ProcessOperationOccurrenceRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cfd00580-9153-013c-7148-0a5172f4a469" xmi:uuid="cfd006a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="732" y="143" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182785860_52721_264348" xmi:uuid="cff89960-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977037_997300_164264"/>
      <ownedElement xmi:id="cfea8f70-9153-013c-7148-0a5172f4a469" xmi:uuid="cfea90a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688563977037_997300_164264"/>
        <text>ProcessPlanRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cfec7e80-9153-013c-7148-0a5172f4a469" xmi:uuid="cfec7f90-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="937" y="143" width="185" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182786090_110774_264397" xmi:uuid="d00f2af0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductClassRelationship"/>
      <ownedElement xmi:id="cffb2e00-9153-013c-7148-0a5172f4a469" xmi:uuid="cffb2ee0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductClassRelationship"/>
        <text>ProductClassRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cffda530-9153-013c-7148-0a5172f4a469" xmi:uuid="cffda750-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="191" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182786610_301498_264450" xmi:uuid="d02dbbe0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConfigurationRelationship"/>
      <ownedElement xmi:id="d0121140-9153-013c-7148-0a5172f4a469" xmi:uuid="d0121270-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConfigurationRelationship"/>
        <text>ProductConfigurationRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d014a050-9153-013c-7148-0a5172f4a469" xmi:uuid="d014a190-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="378" y="191" width="293" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182787207_494402_264499" xmi:uuid="d09b2df0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionRelationship"/>
      <ownedElement xmi:id="d03985d0-9153-013c-7148-0a5172f4a469" xmi:uuid="d0398c30-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionRelationship"/>
        <text>PropertyDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d0446120-9153-013c-7148-0a5172f4a469" xmi:uuid="d0446250-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="691" y="191" width="215" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182787271_421842_264541" xmi:uuid="d0aa2500-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ReplacedPartViewRelationship"/>
      <ownedElement xmi:id="d0a04570-9153-013c-7148-0a5172f4a469" xmi:uuid="d0a046a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ReplacedPartViewRelationship"/>
        <text>ReplacedPartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d0a4c990-9153-013c-7148-0a5172f4a469" xmi:uuid="d0a4caa0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="926" y="191" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182787377_264585_264585" xmi:uuid="d0c633b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ReplacedUsageRelationship"/>
      <ownedElement xmi:id="d0aeef80-9153-013c-7148-0a5172f4a469" xmi:uuid="d0aef0a0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ReplacedUsageRelationship"/>
        <text>ReplacedUsageRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d0b374b0-9153-013c-7148-0a5172f4a469" xmi:uuid="d0b378b0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="239" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182787867_329602_264633" xmi:uuid="d0dd3fb0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersionRelationship"/>
      <ownedElement xmi:id="d0c90590-9153-013c-7148-0a5172f4a469" xmi:uuid="d0c906d0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersionRelationship"/>
        <text>RequirementVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d0cbd040-9153-013c-7148-0a5172f4a469" xmi:uuid="d0cbd190-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="322" y="239" width="239" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182788357_102839_264685" xmi:uuid="d0f1ca60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012316_936928_175541"/>
      <ownedElement xmi:id="d0df84e0-9153-013c-7148-0a5172f4a469" xmi:uuid="d0df8610-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012316_936928_175541"/>
        <text>ShapeElementRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d0e18350-9153-013c-7148-0a5172f4a469" xmi:uuid="d0e185f0-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="581" y="239" width="261" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182788714_843560_264732" xmi:uuid="d0fa0a10-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkOrderRelationship"/>
      <ownedElement xmi:id="d0f34be0-9153-013c-7148-0a5172f4a469" xmi:uuid="d0f34d20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkOrderRelationship"/>
        <text>WorkOrderRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d0f4a930-9153-013c-7148-0a5172f4a469" xmi:uuid="d0f4aa60-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="862" y="239" width="210" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182789182_598220_264781" xmi:uuid="d103ef20-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkRequestRelationship"/>
      <ownedElement xmi:id="d0fb6f40-9153-013c-7148-0a5172f4a469" xmi:uuid="d0fb7060-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkRequestRelationship"/>
        <text>WorkRequestRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d0fcc120-9153-013c-7148-0a5172f4a469" xmi:uuid="d0fcc230-9153-013c-7148-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="287" width="210" height="33"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1225" height="367"/>
    <name>DeltaChangeRelationshipSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446236347_161630_208615" xmi:uuid="0b1fe3b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977621_186432_164575"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236368_63177_208647" xmi:uuid="0bb9ba10-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040788_486877_181714"/>
      <ownedElement xmi:id="0b962530-6c44-013d-931b-0800270c66d6" xmi:uuid="0b9625f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040788_486877_181714"/>
        <text>delta_change:Change</text>
      </ownedElement>
      <ownedElement xmi:id="0ba98aa0-6c44-013d-931b-0800270c66d6" xmi:uuid="0ba98b60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040788_486877_181714"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="152" height="90"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236382_66072_208681" xmi:uuid="0bba17d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="475" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236395_191877_208696" xmi:uuid="0bba6f80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="475" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487436_123754_390050" xmi:uuid="0bba7d70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040774_972665_181709"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236382_66072_208681"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236368_63177_208647"/>
      <waypoint x="475" y="62"/>
      <waypoint x="197" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487436_595077_390053" xmi:uuid="0bba8520-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040773_987207_181708"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236395_191877_208696"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236368_63177_208647"/>
      <waypoint x="475" y="82"/>
      <waypoint x="197" y="82"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="478" height="160"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564041464_641231_182010" xmi:uuid="397575d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977638_900768_164588"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_538113_372919" xmi:uuid="3976b970-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040053_182122_181516"/>
      <ownedElement xmi:id="3ef19210-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3ef192d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040053_182122_181516"/>
        <text>PreviousDesignObject:DeltaChangeManagementObjectSelect</text>
      </ownedElement>
      <ownedElement xmi:id="3ef21e60-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3ef21f20-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040053_182122_181516"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_169316_372920" xmi:uuid="3ef2c540-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
        <ownedElement xmi:id="3ef2a6d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3ef2a790-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
          <bounds x="360" y="140" width="351" height="13"/>
          <text>deltaChangeManagementObjectSelect : change_management_object [1]</text>
        </ownedElement>
        <bounds x="405" y="157" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="154" width="378" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_317084_372922" xmi:uuid="3976bbf0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041503_93166_182035"/>
      <ownedElement xmi:id="3f169130-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f169240-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041503_93166_182035"/>
        <text>modify_single_element:Modify_single_element</text>
      </ownedElement>
      <ownedElement xmi:id="3f175480-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f175660-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041503_93166_182035"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="3f179320-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f179410-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3f17bfe0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f17c130-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_778324_372923" xmi:uuid="3f3868e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Modify_single_element-current_design_object"/>
          <ownedElement xmi:id="3f2cec20-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f2ced20-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Modify_single_element-current_design_object"/>
            <text>current_design_object:change_management_object</text>
          </ownedElement>
          <ownedElement xmi:id="3f3843a0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f3844a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Modify_single_element-current_design_object"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="742" y="99" width="323" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_309346_372924" xmi:uuid="3f5920e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Modify_single_element-previous_design_object"/>
          <ownedElement xmi:id="3f4e16a0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f4e17a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Modify_single_element-previous_design_object"/>
            <text>previous_design_object:change_management_object</text>
          </ownedElement>
          <ownedElement xmi:id="3f58fed0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f58ffd0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Modify_single_element-previous_design_object"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="742" y="148" width="331" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="721" y="63" width="359" height="120"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_968656_372925" xmi:uuid="3976bee0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041248_325159_181838"/>
      <ownedElement xmi:id="3f5a3e00-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f5a3f00-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041248_325159_181838"/>
        <text>CurrentDesignObject:DeltaChangeManagementObjectSelect</text>
      </ownedElement>
      <ownedElement xmi:id="3f5ac730-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f5ac7f0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041248_325159_181838"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_770306_372926" xmi:uuid="3f5b6a30-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
        <ownedElement xmi:id="3f5b4bc0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f5b4c80-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
          <bounds x="360" y="84" width="351" height="13"/>
          <text>deltaChangeManagementObjectSelect : change_management_object [1]</text>
        </ownedElement>
        <bounds x="399" y="101" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="98" width="372" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_160653_402750" xmi:uuid="3976c800-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041500_786617_182031"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_309346_372924"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_169316_372920"/>
      <waypoint x="742" y="165"/>
      <waypoint x="420" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_783807_402751" xmi:uuid="3976d2f0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041501_358501_182032"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_778324_372923"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_770306_372926"/>
      <waypoint x="742" y="109"/>
      <waypoint x="414" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_785558_402752" xmi:uuid="3976d9a0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566025972_317084_372922"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026955_832089_411721"/>
      <waypoint x="721" y="72"/>
      <waypoint x="682" y="61"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_436182_402753" xmi:uuid="3976e0c0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041501_396266_182033"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_317084_372922"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_123459_372928"/>
      <waypoint x="1080" y="74"/>
      <waypoint x="1092" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026955_832089_411721" xmi:uuid="3976fbb0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="3976f780-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3976f820-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from DeltaChangeActivity</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="511" y="14" width="173" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_123459_372928" xmi:uuid="397708e0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041508_681668_182036"/>
      <bounds x="1092" y="67" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1095" height="198"/>
    <name>ModifySingleElement</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564040129_196482_181531" xmi:uuid="39772160-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977614_529768_164569"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_665449_372760" xmi:uuid="3977b7f0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040167_82714_181557"/>
      <ownedElement xmi:id="3f802ab0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f802bf0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040167_82714_181557"/>
        <text>AttributeName:CharacterString</text>
      </ownedElement>
      <ownedElement xmi:id="3f80b490-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f80b540-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040167_82714_181557"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="77" width="212" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_429859_372761" xmi:uuid="3977bd40-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040172_316734_181558"/>
      <ownedElement xmi:id="3f8232d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f8233d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040172_316734_181558"/>
        <text>ChangeLocationInAggregateAttribute:Integer</text>
      </ownedElement>
      <ownedElement xmi:id="3f82cea0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f82cf20-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040172_316734_181558"/>
        <text>[0..*]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="35" y="126" width="287" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_15224_372762" xmi:uuid="3977bfb0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040185_74152_181561"/>
      <ownedElement xmi:id="3f8e1600-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f8e1700-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040185_74152_181561"/>
        <text>delta_change_activity:Change_element</text>
      </ownedElement>
      <ownedElement xmi:id="3f8ea700-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f8ea7f0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040185_74152_181561"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="3f8ed3b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f8ed450-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3f8eee70-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f8eef10-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_948115_372763" xmi:uuid="3fa51cf0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-attribute_name"/>
          <ownedElement xmi:id="3f9a03c0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3f9a04e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-attribute_name"/>
            <text>attribute_name:String</text>
          </ownedElement>
          <ownedElement xmi:id="3fa4fa40-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fa4fb40-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-attribute_name"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="462" y="78" width="164" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_472813_372764" xmi:uuid="3fbbc7e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-change_location_in_aggregate_attribute"/>
          <ownedElement xmi:id="3fb051e0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fb052d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-change_location_in_aggregate_attribute"/>
            <text>change_location_in_aggregate_attribute:Integer</text>
          </ownedElement>
          <ownedElement xmi:id="3fbba550-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fbba650-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-change_location_in_aggregate_attribute"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="462" y="127" width="301" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_536309_372765" xmi:uuid="3fdc3550-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-change_set"/>
          <ownedElement xmi:id="3fd13450-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fd13560-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-change_set"/>
            <text>change_set:Change</text>
          </ownedElement>
          <ownedElement xmi:id="3fdc1260-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fdc1360-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-change_set"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="176" width="145" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="42" width="329" height="169"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_353683_372766" xmi:uuid="3fdd3630-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="1528c760-404e-013c-1d33-21143cc57b19" xmi:uuid="1528c870-404e-013c-1d33-21143cc57b19" xmi:type="umldi:UMLKeywordLabel">
        <text>Rationale</text>
      </ownedElement>
      <ownedElement xmi:id="3fdd2cb0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fdd2ee0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040167_714127_181556"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize=""/>
      <bounds x="49" y="168" width="345" height="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_770797_402691" xmi:uuid="3977c970-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040165_359592_181552"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_948115_372763"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_665449_372760"/>
      <waypoint x="462" y="88"/>
      <waypoint x="247" y="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_919926_402692" xmi:uuid="3977d190-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040166_458039_181553"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_472813_372764"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_429859_372761"/>
      <waypoint x="462" y="140"/>
      <waypoint x="322" y="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_85626_402693" xmi:uuid="3977d760-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040166_270505_181554"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_15224_372762"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_185262_372758"/>
      <waypoint x="770" y="60"/>
      <waypoint x="782" y="60"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_231389_402694" xmi:uuid="3977e080-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566025970_536309_372765"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_353683_372766"/>
      <waypoint x="462" y="191"/>
      <waypoint x="394" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_185262_372758" xmi:uuid="3977f160-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040180_973623_181560"/>
      <bounds x="782" y="53" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="785" height="247"/>
    <name>DeltaChangeActivity</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564041199_290435_181808" xmi:uuid="397807e0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977627_584741_164579"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_361255_372905" xmi:uuid="39788c80-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040866_237198_181735"/>
      <ownedElement xmi:id="3fdf8cc0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fdf8d90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040866_237198_181735"/>
        <text>CurrentDesignObject:DeltaChangeManagementObjectSelect</text>
      </ownedElement>
      <ownedElement xmi:id="3fe01ef0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fe01fe0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040866_237198_181735"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_943872_372906" xmi:uuid="3fe0e4a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
        <ownedElement xmi:id="3fe0c4f0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fe0c5e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
          <bounds x="406" y="77" width="351" height="13"/>
          <text>deltaChangeManagementObjectSelect : change_management_object [1]</text>
        </ownedElement>
        <bounds x="392" y="88" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="84" width="372" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_671890_372908" xmi:uuid="39788f40-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041237_925777_181832"/>
      <ownedElement xmi:id="3fec2eb0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fec2fb0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041237_925777_181832"/>
        <text>modify_element:Modify_element</text>
      </ownedElement>
      <ownedElement xmi:id="3fecbd60-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fecbe10-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041237_925777_181832"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="3fecf080-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fecf140-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3fed08b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="3fed0950-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_611088_372909" xmi:uuid="400dc8a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Modify_element-current_design_object"/>
          <ownedElement xmi:id="4002aca0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4002ada0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Modify_element-current_design_object"/>
            <text>current_design_object:change_management_object</text>
          </ownedElement>
          <ownedElement xmi:id="400da530-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="400da630-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Modify_element-current_design_object"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="798" y="85" width="333" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="777" y="49" width="361" height="71"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_25132_402745" xmi:uuid="39789840-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041235_758723_181829"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_611088_372909"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_943872_372906"/>
      <waypoint x="798" y="98"/>
      <waypoint x="407" y="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_954189_402746" xmi:uuid="39789f10-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566025972_671890_372908"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026955_717299_411720"/>
      <waypoint x="777" y="64"/>
      <waypoint x="691" y="54"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_352105_402747" xmi:uuid="3978aab0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041236_61728_181830"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_671890_372908"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_733214_372910"/>
      <waypoint x="1138" y="63"/>
      <waypoint x="1150" y="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026955_717299_411720" xmi:uuid="3978c2c0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="3978beb0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3978bf50-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from DeltaChangeActivity</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="518" y="21" width="173" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_733214_372910" xmi:uuid="3978d3f0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041241_874603_181833"/>
      <bounds x="1150" y="53" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1153" height="135"/>
    <name>ModifyElement</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564040349_437361_181613" xmi:uuid="3978e960-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977618_99552_164572"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_268261_372776" xmi:uuid="39797350-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040388_904940_181637"/>
      <ownedElement xmi:id="400ffe30-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="400fff00-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040388_904940_181637"/>
        <text>CurrentDesignObject:DeltaChangeManagementObjectSelect</text>
      </ownedElement>
      <ownedElement xmi:id="40107ca0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40107d50-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040388_904940_181637"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_629826_372777" xmi:uuid="40113750-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
        <ownedElement xmi:id="40111b50-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40111c30-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
          <bounds x="427" y="86" width="351" height="13"/>
          <text>deltaChangeManagementObjectSelect : change_management_object [1]</text>
        </ownedElement>
        <bounds x="409" y="95" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="91" width="382" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_517673_372779" xmi:uuid="39797630-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040393_347961_181638"/>
      <ownedElement xmi:id="401cef00-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="401cf130-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040393_347961_181638"/>
        <text>add_element:Add_element</text>
      </ownedElement>
      <ownedElement xmi:id="401d9b90-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="401d9c80-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040393_347961_181638"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="401ddb00-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="401dded0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="401dffd0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="401e0070-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_551071_372780" xmi:uuid="403e5f20-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Add_element-current_design_object"/>
          <ownedElement xmi:id="40332b80-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40332d90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Add_element-current_design_object"/>
            <text>current_design_object:change_management_object</text>
          </ownedElement>
          <ownedElement xmi:id="403e3990-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="403e3a90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Add_element-current_design_object"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="812" y="92" width="333" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="56" width="361" height="71"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_591756_402698" xmi:uuid="39797de0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040386_143922_181634"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_551071_372780"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_629826_372777"/>
      <waypoint x="812" y="102"/>
      <waypoint x="424" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_539588_402699" xmi:uuid="39798370-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566025970_517673_372779"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026955_854448_411719"/>
      <waypoint x="791" y="62"/>
      <waypoint x="726" y="51"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_631133_402700" xmi:uuid="39798b70-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040387_842128_181635"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_517673_372779"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_251284_372774"/>
      <waypoint x="1152" y="84"/>
      <waypoint x="1164" y="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026955_854448_411719" xmi:uuid="3979a8d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="3979a2c0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3979a380-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from DeltaChangeActivity</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="553" y="14" width="173" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_251284_372774" xmi:uuid="3979b990-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040397_553908_181639"/>
      <bounds x="1164" y="76" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1167" height="142"/>
    <name>AddElement</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564040249_584349_181575" xmi:uuid="3979cf00-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977616_967610_164571"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_527733_372769" xmi:uuid="397a5fd0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040287_957487_181599"/>
      <ownedElement xmi:id="4040b5f0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4040b680-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040287_957487_181599"/>
        <text>PreviousDesignObject:DeltaChangeManagementObjectSelect</text>
      </ownedElement>
      <ownedElement xmi:id="404149d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40414b30-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040287_957487_181599"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_461679_372770" xmi:uuid="404217a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
        <ownedElement xmi:id="4041f550-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4041f630-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
          <bounds x="283" y="84" width="351" height="13"/>
          <text>deltaChangeManagementObjectSelect : change_management_object [1]</text>
        </ownedElement>
        <bounds x="415" y="100" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="98" width="388" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_122547_372772" xmi:uuid="397a62d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040291_913083_181600"/>
      <ownedElement xmi:id="404d7cb0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="404d8320-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040291_913083_181600"/>
        <text>delete_element:Delete_element</text>
      </ownedElement>
      <ownedElement xmi:id="404e1640-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="404e1710-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040291_913083_181600"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="404e5c30-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="404e5d30-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="404e7fb0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="404e8060-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_890260_372773" xmi:uuid="40704030-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Delete_element-previous_design_object"/>
          <ownedElement xmi:id="4064ba10-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4064bb40-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Delete_element-previous_design_object"/>
            <text>previous_design_object:change_management_object</text>
          </ownedElement>
          <ownedElement xmi:id="407013d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="407014e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Delete_element-previous_design_object"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="735" y="99" width="341" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="714" y="63" width="381" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_828363_402695" xmi:uuid="397a6b20-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040285_431862_181596"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_890260_372773"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_461679_372770"/>
      <waypoint x="735" y="109"/>
      <waypoint x="430" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_36577_402696" xmi:uuid="397a6f30-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566025970_122547_372772"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026955_377661_411718"/>
      <waypoint x="714" y="65"/>
      <waypoint x="698" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_998814_402697" xmi:uuid="397a79d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040286_563135_181597"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_122547_372772"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_969231_372767"/>
      <waypoint x="1095" y="77"/>
      <waypoint x="1119" y="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026955_377661_411718" xmi:uuid="397a9230-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="397a8d60-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="397a8e00-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from DeltaChangeActivity</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="525" y="21" width="173" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_969231_372767" xmi:uuid="397aa5d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040295_822804_181601"/>
      <bounds x="1119" y="74" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1122" height="159"/>
    <name>DeleteElement</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564040690_73091_181657" xmi:uuid="397abaf0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977621_186432_164575"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_325592_372781" xmi:uuid="397c7ab0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040775_783352_181711"/>
      <ownedElement xmi:id="4074ef50-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4074f050-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040775_783352_181711"/>
        <text>ChangeActivities:DeltaChangeActivity</text>
      </ownedElement>
      <ownedElement xmi:id="40756ae0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40756b90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040775_783352_181711"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_395850_372782" xmi:uuid="40764360-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040180_973623_181560"/>
        <ownedElement xmi:id="407623d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="407624c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040180_973623_181560"/>
          <bounds x="303" y="100" width="203" height="13"/>
          <text>deltaChangeActivity : Change_element [1]</text>
        </ownedElement>
        <bounds x="285" y="109" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="98" width="258" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_308687_372784" xmi:uuid="397c7e40-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040401_200071_181642"/>
      <ownedElement xmi:id="40819ae0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40819bf0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040401_200071_181642"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="408234e0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="408235b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040401_200071_181642"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_216215_372785" xmi:uuid="b13b72e0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="b13b1b80-48ad-013c-be37-3733fc5daa49" xmi:uuid="b13b1d90-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="245" y="171" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="227" y="180" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="168" width="200" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_919845_372787" xmi:uuid="397c8180-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040778_936305_181712"/>
      <ownedElement xmi:id="408e0cc0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="408e0de0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040778_936305_181712"/>
        <text>DescribedChange:DeltaChangeRelationshipSelect</text>
      </ownedElement>
      <ownedElement xmi:id="408ea530-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="408ea5f0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040778_936305_181712"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_662918_372788" xmi:uuid="408f4e40-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
        <ownedElement xmi:id="408f2f00-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="408f2fc0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
          <bounds x="372" y="218" width="307" height="13"/>
          <text>deltaChangeRelationshipSelect : change_relationship_select [1]</text>
        </ownedElement>
        <bounds x="354" y="227" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="224" width="327" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_552502_372790" xmi:uuid="397c8350-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040190_295069_181564"/>
      <ownedElement xmi:id="409b0cf0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="409b0e00-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040190_295069_181564"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="409b99a0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="409b9a50-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040190_295069_181564"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="308" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_644580_372791" xmi:uuid="397c8510-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040406_178214_181644"/>
      <ownedElement xmi:id="40a647b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40a648b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040406_178214_181644"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="40a710d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40a711e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040406_178214_181644"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="525" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_621519_372792" xmi:uuid="397c8890-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040048_917187_181514"/>
      <ownedElement xmi:id="40b1d0c0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40b1d1c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040048_917187_181514"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="40b28480-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40b28590-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040048_917187_181514"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="658" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_894550_372793" xmi:uuid="397c8ab0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040788_486877_181714"/>
      <ownedElement xmi:id="40bdc2e0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40bdc4d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040788_486877_181714"/>
        <text>delta_change:Change</text>
      </ownedElement>
      <ownedElement xmi:id="40be6560-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40be6650-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040788_486877_181714"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="40be94f0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40be95a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="40bead20-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40beae10-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_158390_372794" xmi:uuid="40ded7a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-described_change"/>
          <ownedElement xmi:id="40d3fa90-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40d3fba0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-described_change"/>
            <text>described_change:change_relationship_select</text>
          </ownedElement>
          <ownedElement xmi:id="40deafc0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40deb1b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-described_change"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1274" y="224" width="305" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_561089_372795" xmi:uuid="40ff54b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-description"/>
          <ownedElement xmi:id="40f45880-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40f45970-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-description"/>
            <text>description:text</text>
          </ownedElement>
          <ownedElement xmi:id="40ff2ae0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="40ff2c00-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1272" y="273" width="135" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_769676_372796" xmi:uuid="41211f30-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-id"/>
          <ownedElement xmi:id="4114fea0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4114ffb0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-id"/>
            <text>id:identifier</text>
          </ownedElement>
          <ownedElement xmi:id="4120f010-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4120f110-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1274" y="519" width="111" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_966118_372797" xmi:uuid="414353a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-name"/>
          <ownedElement xmi:id="41379180-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="41379280-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-name"/>
            <text>name:label</text>
          </ownedElement>
          <ownedElement xmi:id="41432bb0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="41432cb0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1274" y="631" width="96" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1253" y="56" width="333" height="610"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_292814_402702" xmi:uuid="41721fc0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040750_625593_181680"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_894550_372793"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_682803_372799"/>
      <waypoint x="1253" y="116"/>
      <waypoint x="1090" y="116"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_921123_372798" xmi:uuid="397c8dc0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040793_554818_181715"/>
      <ownedElement xmi:id="414f96a0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="414f97a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040793_554818_181715"/>
        <text>ce:Change_element</text>
      </ownedElement>
      <ownedElement xmi:id="41503f50-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="41504010-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040793_554818_181715"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="415089c0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="41508a80-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4150a4b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4150a650-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_682803_372799" xmi:uuid="4171fe20-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-change_set"/>
          <ownedElement xmi:id="4166a000-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4166a0f0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-change_set"/>
            <text>change_set:Change</text>
          </ownedElement>
          <ownedElement xmi:id="4171dd60-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4171de50-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element-change_set"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="106" width="145" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="931" y="77" width="249" height="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_291524_372800" xmi:uuid="397c9130-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040797_867225_181716"/>
      <ownedElement xmi:id="417e92c0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="417e93b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040797_867225_181716"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_824384_372801" xmi:uuid="b238bce0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="b2386a00-48ad-013c-be37-3733fc5daa49" xmi:uuid="b2386af0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="538" y="328" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="520" y="337" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_165734_372803" xmi:uuid="b244a710-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b2445820-48ad-013c-be37-3733fc5daa49" xmi:uuid="b2445920-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="528" y="264" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="518" y="280" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_698079_372805" xmi:uuid="b250ebd0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="b2509d70-48ad-013c-be37-3733fc5daa49" xmi:uuid="b2509e70-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="543" y="370" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="520" y="381" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_458461_372807" xmi:uuid="b25d0fc0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="b25cb290-48ad-013c-be37-3733fc5daa49" xmi:uuid="b25cb3b0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="247" y="303" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="301" y="312" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="280" width="234" height="126"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_804894_372809" xmi:uuid="397c9470-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040799_271132_181717"/>
      <ownedElement xmi:id="41b6a800-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="41b6a900-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040799_271132_181717"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_853104_372810" xmi:uuid="b2762330-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="b275d0f0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b275d200-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="458" y="544" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="440" y="553" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_983249_372812" xmi:uuid="b2824bf0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="b281f6e0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b281f7e0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="458" y="514" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="440" y="523" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_123330_372814" xmi:uuid="b28e6740-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="b28e0ed0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b28e0fd0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="240" y="521" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="294" y="530" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="294" y="511" width="161" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_177021_372816" xmi:uuid="397c9a00-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040804_975569_181718"/>
      <ownedElement xmi:id="41e284b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="41e285c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040804_975569_181718"/>
        <text>selectDescription1:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_139272_372817" xmi:uuid="b2a78950-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="b2a73740-48ad-013c-be37-3733fc5daa49" xmi:uuid="b2a73850-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="537" y="671" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="519" y="680" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_630616_372819" xmi:uuid="b2b35980-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b2b30b70-48ad-013c-be37-3733fc5daa49" xmi:uuid="b2b30c70-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="537" y="629" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="519" y="638" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_201173_372821" xmi:uuid="b2bf5e60-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="b2bf1080-48ad-013c-be37-3733fc5daa49" xmi:uuid="b2bf1190-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="542" y="712" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="519" y="723" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_896479_372823" xmi:uuid="b2cb4a20-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="b2cafa60-48ad-013c-be37-3733fc5daa49" xmi:uuid="b2cafb70-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="240" y="653" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="294" y="662" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="294" y="630" width="240" height="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_639072_372825" xmi:uuid="397c9d30-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040807_877878_181719"/>
      <ownedElement xmi:id="4217f100-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4217f200-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040807_877878_181719"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="421897e0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="421898d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040807_877878_181719"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_187352_372826" xmi:uuid="b2e49360-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="b2e43900-48ad-013c-be37-3733fc5daa49" xmi:uuid="b2e43a10-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="693" y="315" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="780" y="335" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="623" y="329" width="165" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_28724_372828" xmi:uuid="397c9fa0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040811_161562_181720"/>
      <ownedElement xmi:id="422dfa20-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="422dfb30-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040811_161562_181720"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="422e8900-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="422e89b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040811_161562_181720"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_411946_372829" xmi:uuid="b2fdd830-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="b2fd8940-48ad-013c-be37-3733fc5daa49" xmi:uuid="b2fd8a40-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="795" y="429" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="777" y="438" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="623" y="434" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_365690_372831" xmi:uuid="397ca250-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040815_652656_181721"/>
      <ownedElement xmi:id="4244a6a0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4244a7b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040815_652656_181721"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="42454d60-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42454f80-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040815_652656_181721"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_944108_372832" xmi:uuid="b316caa0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="b3167470-48ad-013c-be37-3733fc5daa49" xmi:uuid="b3167570-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="723" y="532" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="738" y="549" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="623" y="546" width="123" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_67459_372834" xmi:uuid="397ca5a0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040819_309760_181722"/>
      <ownedElement xmi:id="425a9910-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="425a9a10-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040819_309760_181722"/>
        <text>descriptors1:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="425b3850-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="425b3910-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040819_309760_181722"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025970_273843_372835" xmi:uuid="b32f87e0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="b32f3850-48ad-013c-be37-3733fc5daa49" xmi:uuid="b32f3a50-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="693" y="665" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="786" y="685" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="623" y="679" width="171" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_340662_372837" xmi:uuid="397ca8a0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040823_251840_181723"/>
      <ownedElement xmi:id="4270b670-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4270b980-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040823_251840_181723"/>
        <text>language1:Language</text>
      </ownedElement>
      <ownedElement xmi:id="42715150-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42715210-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040823_251840_181723"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_431091_372838" xmi:uuid="b348b3c0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="b3486850-48ad-013c-be37-3733fc5daa49" xmi:uuid="b3486960-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="801" y="785" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="783" y="794" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="623" y="791" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_748928_402704" xmi:uuid="42a89160-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040754_637493_181684"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_894550_372793"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_84957_372841"/>
      <waypoint x="1253" y="193"/>
      <waypoint x="1129" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_872262_372840" xmi:uuid="397cab40-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040827_68464_181724"/>
      <ownedElement xmi:id="428745e0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42874700-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040827_68464_181724"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="4287d5c0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4287d700-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040827_68464_181724"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="42880d10-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42880dc0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="42882630-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="428826d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_84957_372841" xmi:uuid="42a86dc0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="429d49a0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="429d4aa0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="42a833e0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42a834e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="182" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="931" y="154" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_451964_402705" xmi:uuid="42d67c80-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040759_114696_181690"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_894550_372793"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_158310_372843"/>
      <waypoint x="1253" y="340"/>
      <waypoint x="1120" y="340"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_62129_372842" xmi:uuid="397cad40-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040831_249399_181725"/>
      <ownedElement xmi:id="42b4c3c0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42b4c4c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040831_249399_181725"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="42b55490-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42b55540-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040831_249399_181725"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="42b58270-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42b58310-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="42b59ec0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42b59f90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_158310_372843" xmi:uuid="42d65ae0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="42cad730-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42cad840-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="42d5fd30-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42d5ff70-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="329" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="931" y="301" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_125100_402706" xmi:uuid="433b2510-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040751_381340_181681"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_606589_372848"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_846809_372845"/>
      <waypoint x="907" y="473"/>
      <waypoint x="945" y="473"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_496292_402707" xmi:uuid="433bf9a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040761_640664_181693"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_894550_372793"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_451276_372846"/>
      <waypoint x="1253" y="417"/>
      <waypoint x="1173" y="417"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_801677_372844" xmi:uuid="397cb050-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040834_152304_181726"/>
      <ownedElement xmi:id="42e2c080-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42e2c190-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040834_152304_181726"/>
        <text>li:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="42e35830-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42e358e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040834_152304_181726"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="42e38860-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42e38ac0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="42e3a7e0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42e3a880-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_846809_372845" xmi:uuid="42f9e790-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="42eec6b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42eec7b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="42f9a940-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="42f9aa40-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="945" y="462" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_451276_372846" xmi:uuid="431a42b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="430f4230-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="430f4330-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="431a1f70-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="431a2070-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="406" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_433544_372847" xmi:uuid="433b0780-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="432f8e80-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="432f9560-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="433ae3f0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="433ae4e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="434" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="931" y="378" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_606589_372848" xmi:uuid="397cb290-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040839_415913_181727"/>
      <ownedElement xmi:id="433d6b60-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="433d6c60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040839_415913_181727"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="433df6d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="433df780-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040839_415913_181727"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="693" y="462" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_558435_402708" xmi:uuid="436aed60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040767_125759_181700"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_894550_372793"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_744919_372850"/>
      <waypoint x="1253" y="592"/>
      <waypoint x="1128" y="592"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_210046_372849" xmi:uuid="397cb680-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040843_228462_181728"/>
      <ownedElement xmi:id="43497e40-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43497f60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040843_228462_181728"/>
        <text>ia1:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="434a14f0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="434a15d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040843_228462_181728"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="434a4870-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="434a4a80-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="434a62f0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="434a6390-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_744919_372850" xmi:uuid="436ac460-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="435fac70-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="435fad90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="436a9540-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="436a9910-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="581" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="931" y="546" width="249" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_486815_402709" xmi:uuid="4398f130-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040770_689856_181703"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_894550_372793"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_379137_372852"/>
      <waypoint x="1530" y="666"/>
      <waypoint x="1530" y="697"/>
      <waypoint x="1120" y="697"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_717389_372851" xmi:uuid="397cb970-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040848_106916_181729"/>
      <ownedElement xmi:id="4376e4e0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4376e5e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040848_106916_181729"/>
        <text>dta1:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="4377a1d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4377a2c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040848_106916_181729"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4377d170-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4377d230-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4377eca0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4377ed40-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_379137_372852" xmi:uuid="4398c880-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="438d4f30-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="438d5140-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="43989d60-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43989e70-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="686" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="931" y="658" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_859585_402710" xmi:uuid="43fe0460-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040752_856022_181682"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_159428_372857"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_270114_372854"/>
      <waypoint x="901" y="830"/>
      <waypoint x="945" y="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_7576_402711" xmi:uuid="43fee870-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040772_953523_181706"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_894550_372793"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_191127_372855"/>
      <waypoint x="1530" y="666"/>
      <waypoint x="1530" y="774"/>
      <waypoint x="1173" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_361622_372853" xmi:uuid="397cc0a0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040851_629141_181730"/>
      <ownedElement xmi:id="43a54280-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43a544d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040851_629141_181730"/>
        <text>li1:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="43a5eca0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43a5ed90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040851_629141_181730"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="43a61b80-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43a61c20-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="43a63670-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43a63710-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_270114_372854" xmi:uuid="43bccc80-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="43b15190-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43b152a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="43bca320-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43bca440-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="819" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_191127_372855" xmi:uuid="43dd4060-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="43d20a90-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43d20b90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="43dd1cd0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43dd1dd0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="763" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_158765_372856" xmi:uuid="43fde4c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="43f29f60-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43f2a060-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="43fdbc00-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="43fdbd00-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="945" y="791" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="931" y="735" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_159428_372857" xmi:uuid="397cc4c0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040856_816791_181731"/>
      <ownedElement xmi:id="44002ee0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44002fa0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040856_816791_181731"/>
        <text>theAttribute1:String</text>
      </ownedElement>
      <ownedElement xmi:id="4400ade0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4400ae90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040856_816791_181731"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="713" y="819" width="188" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_883425_372860" xmi:uuid="397cc830-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040861_232609_181732"/>
      <ownedElement xmi:id="440bd640-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="440bd740-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040861_232609_181732"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_33457_372861" xmi:uuid="b4ebc0d0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="b4eb6da0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b4eb6e90-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="630" y="644" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="686" y="635" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_157624_372863" xmi:uuid="b4f842e0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="b4f7f1f0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b4f7f2f0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="881" y="627" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="863" y="636" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="686" y="623" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_177072_402701" xmi:uuid="397cd450-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040749_255420_181678"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_894550_372793"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_672952_372858"/>
      <waypoint x="1586" y="74"/>
      <waypoint x="1623" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_341858_402703" xmi:uuid="397d00b0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040750_486084_181679"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_921123_372798"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_395850_372782"/>
      <waypoint x="931" y="116"/>
      <waypoint x="300" y="116"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_147773_402712" xmi:uuid="397d13c0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040753_527199_181683"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_872262_372840"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_216215_372785"/>
      <waypoint x="931" y="189"/>
      <waypoint x="242" y="189"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_406717_402713" xmi:uuid="397d1ca0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040755_372824_181685"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_158390_372794"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_662918_372788"/>
      <waypoint x="1274" y="238"/>
      <waypoint x="369" y="238"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_655572_402714" xmi:uuid="397d24d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040756_663108_181686"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_552502_372790"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_458461_372807"/>
      <waypoint x="241" y="319"/>
      <waypoint x="301" y="319"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_612439_402715" xmi:uuid="397d2d80-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040757_756714_181687"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_561089_372795"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_165734_372803"/>
      <waypoint x="1272" y="286"/>
      <waypoint x="533" y="286"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_243619_402716" xmi:uuid="397d3410-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040758_50785_181688"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_639072_372825"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_824384_372801"/>
      <waypoint x="623" y="343"/>
      <waypoint x="535" y="343"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_641048_402717" xmi:uuid="397d4140-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040759_96340_181689"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_62129_372842"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_187352_372826"/>
      <waypoint x="931" y="343"/>
      <waypoint x="795" y="343"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_818200_402718" xmi:uuid="397d5200-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040760_729486_181691"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_28724_372828"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_698079_372805"/>
      <waypoint x="623" y="445"/>
      <waypoint x="609" y="445"/>
      <waypoint x="609" y="389"/>
      <waypoint x="535" y="389"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_469484_402719" xmi:uuid="397d5aa0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040761_419887_181692"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_433544_372847"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_411946_372829"/>
      <waypoint x="945" y="445"/>
      <waypoint x="792" y="445"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_53852_402720" xmi:uuid="397d6a80-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040763_508091_181694"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_644580_372791"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_123330_372814"/>
      <waypoint x="168" y="536"/>
      <waypoint x="294" y="536"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_508206_402721" xmi:uuid="397d7360-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040764_142810_181695"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_621519_372792"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_896479_372823"/>
      <waypoint x="209" y="669"/>
      <waypoint x="294" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_539013_402722" xmi:uuid="397d7ef0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040764_446905_181696"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_769676_372796"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_983249_372812"/>
      <waypoint x="1274" y="529"/>
      <waypoint x="455" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_703610_402723" xmi:uuid="397d8ca0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040765_540830_181697"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_33457_372861"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_630616_372819"/>
      <waypoint x="686" y="644"/>
      <waypoint x="534" y="644"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_588577_402724" xmi:uuid="397d9310-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040766_441704_181698"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_365690_372831"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_853104_372810"/>
      <waypoint x="623" y="560"/>
      <waypoint x="455" y="560"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_670870_402725" xmi:uuid="397d9c20-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040767_212286_181699"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_210046_372849"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_944108_372832"/>
      <waypoint x="931" y="557"/>
      <waypoint x="753" y="557"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_609484_402726" xmi:uuid="397da890-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040768_812918_181701"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_67459_372834"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_139272_372817"/>
      <waypoint x="623" y="686"/>
      <waypoint x="534" y="686"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_885010_402727" xmi:uuid="397db560-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040769_977930_181702"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_717389_372851"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_273843_372835"/>
      <waypoint x="931" y="697"/>
      <waypoint x="801" y="697"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_623730_402728" xmi:uuid="397dbe70-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040770_231112_181704"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_340662_372837"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025970_201173_372821"/>
      <waypoint x="623" y="802"/>
      <waypoint x="613" y="802"/>
      <waypoint x="613" y="732"/>
      <waypoint x="534" y="732"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_95004_402729" xmi:uuid="397dc780-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040771_880844_181705"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_158765_372856"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_431091_372838"/>
      <waypoint x="945" y="802"/>
      <waypoint x="798" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_610088_402730" xmi:uuid="397dd440-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040773_938935_181707"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025970_966118_372797"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_157624_372863"/>
      <waypoint x="1274" y="644"/>
      <waypoint x="878" y="644"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_672952_372858" xmi:uuid="397de740-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040783_443861_181713"/>
      <bounds x="1623" y="64" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1626" height="869"/>
    <name>DeltaChange</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564041030_309528_181746" xmi:uuid="397e0570-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977624_114863_164577"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_970372_372867" xmi:uuid="397f1a70-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041090_950060_181783"/>
      <ownedElement xmi:id="442f73d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="442f7780-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041090_950060_181783"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="44300550-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="443006e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041090_950060_181783"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_910743_372868" xmi:uuid="b52560f0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="b5251300-48ad-013c-be37-3733fc5daa49" xmi:uuid="b5251400-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="240" y="93" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="222" y="102" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="98" width="195" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_997685_372870" xmi:uuid="397f1d50-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041085_79312_181782"/>
      <ownedElement xmi:id="4445b030-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4445b2c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041085_79312_181782"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="444657b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="444658a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041085_79312_181782"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="196" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_47649_372871" xmi:uuid="397f1f50-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041097_68188_181785"/>
      <ownedElement xmi:id="444781a0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="444782a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041097_68188_181785"/>
        <text>Related:DeltaChangeActivity</text>
      </ownedElement>
      <ownedElement xmi:id="44482260-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44482350-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041097_68188_181785"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_672236_372872" xmi:uuid="4448e3c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040180_973623_181560"/>
        <ownedElement xmi:id="4448c280-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4448c360-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040180_973623_181560"/>
          <bounds x="240" y="388" width="203" height="13"/>
          <text>deltaChangeActivity : Change_element [1]</text>
        </ownedElement>
        <bounds x="222" y="397" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="392" width="195" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_794679_372874" xmi:uuid="397f2330-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041094_958887_181784"/>
      <ownedElement xmi:id="4449c850-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4449c910-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041094_958887_181784"/>
        <text>Relating:DeltaChangeActivity</text>
      </ownedElement>
      <ownedElement xmi:id="444a5ce0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="444a5f80-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041094_958887_181784"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_184492_372875" xmi:uuid="444b3860-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040180_973623_181560"/>
        <ownedElement xmi:id="444b1870-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="444b1970-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040180_973623_181560"/>
          <bounds x="244" y="430" width="203" height="13"/>
          <text>deltaChangeActivity : Change_element [1]</text>
        </ownedElement>
        <bounds x="226" y="439" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="434" width="199" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_259957_372877" xmi:uuid="397f3cf0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041106_748780_181787"/>
      <ownedElement xmi:id="44565a90-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44565b90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041106_748780_181787"/>
        <text>change_element_sequence:Change_element_sequence</text>
      </ownedElement>
      <ownedElement xmi:id="44570d50-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44570e40-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041106_748780_181787"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="44573850-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="445738f0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="44575370-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44575410-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_561302_372878" xmi:uuid="44779f70-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element_sequence-description"/>
          <ownedElement xmi:id="446c9fa0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="446ca0c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element_sequence-description"/>
            <text>description:text</text>
          </ownedElement>
          <ownedElement xmi:id="44777dc0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44777ed0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element_sequence-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1253" y="169" width="135" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_582189_372879" xmi:uuid="44982b10-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element_sequence-next"/>
          <ownedElement xmi:id="448d04d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="448d05c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element_sequence-next"/>
            <text>next:Change_element</text>
          </ownedElement>
          <ownedElement xmi:id="449808b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="449809b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element_sequence-next"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1253" y="400" width="157" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_955649_372880" xmi:uuid="44b8a670-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element_sequence-previous"/>
          <ownedElement xmi:id="44ad9250-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44ad9350-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element_sequence-previous"/>
            <text>previous:Change_element</text>
          </ownedElement>
          <ownedElement xmi:id="44b877b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44b878d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Change_element_sequence-previous"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1253" y="442" width="182" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1232" y="63" width="347" height="414"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_161432_372881" xmi:uuid="397f4a70-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041111_724971_181788"/>
      <ownedElement xmi:id="44c39aa0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44c39ba0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041111_724971_181788"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_817871_372882" xmi:uuid="b5c411f0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="b5c3bc50-48ad-013c-be37-3733fc5daa49" xmi:uuid="b5c3bd60-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="516" y="210" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="498" y="219" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_731828_372884" xmi:uuid="b5d01260-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b5cfc2b0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b5cfc3b0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="516" y="160" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="498" y="169" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_196148_372886" xmi:uuid="b5dc9830-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="b5dc3650-48ad-013c-be37-3733fc5daa49" xmi:uuid="b5dc3760-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="521" y="258" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="498" y="269" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_74267_372888" xmi:uuid="b5e8cc40-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="b5e86a20-48ad-013c-be37-3733fc5daa49" xmi:uuid="b5e86b30-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="240" y="191" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="294" y="200" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="294" y="161" width="219" height="126"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_804610_372890" xmi:uuid="397f4f90-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041114_190785_181789"/>
      <ownedElement xmi:id="44f97280-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44f97390-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041114_190785_181789"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="44fa27a0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="44fa28a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041114_190785_181789"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_25785_372891" xmi:uuid="b60215f0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="b601c5f0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b601c6f0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="700" y="196" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="780" y="216" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="616" y="210" width="172" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_793072_372893" xmi:uuid="397f5230-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041119_17491_181790"/>
      <ownedElement xmi:id="450f7610-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="450f7710-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041119_17491_181790"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="45100410-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="451004d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041119_17491_181790"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_243126_372894" xmi:uuid="b61ad3d0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="b61a7f00-48ad-013c-be37-3733fc5daa49" xmi:uuid="b61a8010-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="784" y="315" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="769" y="325" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="616" y="322" width="161" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_855734_402731" xmi:uuid="45481e60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041076_380401_181769"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_259957_372877"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_215180_372897"/>
      <waypoint x="1232" y="133"/>
      <waypoint x="1122" y="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_371944_372896" xmi:uuid="397f58f0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041124_153381_181791"/>
      <ownedElement xmi:id="45262b30-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="45262c50-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041124_153381_181791"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="4526e8c0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4526e990-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041124_153381_181791"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="45271540-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="452715f0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="45273390-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="45273430-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_215180_372897" xmi:uuid="4547fb30-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="453c9870-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="453c9980-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="4547d190-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4547d280-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="938" y="119" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="924" y="91" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_937317_402732" xmi:uuid="457076c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041079_313046_181774"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_259957_372877"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_610665_372899"/>
      <waypoint x="1232" y="228"/>
      <waypoint x="1113" y="228"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_744249_372898" xmi:uuid="397f5ca0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041128_435693_181792"/>
      <ownedElement xmi:id="454ec1b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="454ec2c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041128_435693_181792"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="454f5870-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="454f5950-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041128_435693_181792"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="454f8550-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="454f8600-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="454fa190-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="454fa230-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_610665_372899" xmi:uuid="45704370-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="45651960-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="45651a60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="45701aa0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="45701ba0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="938" y="217" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="924" y="189" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_556951_402733" xmi:uuid="45d42230-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041075_526955_181767"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_780604_372904"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_466455_372901"/>
      <waypoint x="907" y="368"/>
      <waypoint x="938" y="368"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_746473_402734" xmi:uuid="45d49e00-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041081_164593_181777"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_259957_372877"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_274767_372902"/>
      <waypoint x="1232" y="305"/>
      <waypoint x="1166" y="305"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_242256_372900" xmi:uuid="397f60e0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041132_659103_181793"/>
      <ownedElement xmi:id="457c0c60-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="457c0d60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041132_659103_181793"/>
        <text>li:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="457cbbf0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="457cbd00-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041132_659103_181793"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="457cf250-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="457cf310-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="457d0e20-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="457d0ec0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_466455_372901" xmi:uuid="45930a00-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="45880fd0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="458810c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="4592e520-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4592e620-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="938" y="350" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_274767_372902" xmi:uuid="45b396f0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="45a88840-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="45a88960-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="45b37030-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="45b37130-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="938" y="294" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_287420_372903" xmi:uuid="45d40260-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="45c8e170-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="45c8e260-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="45d3e2a0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="45d3e3a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="938" y="322" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="924" y="266" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_780604_372904" xmi:uuid="397f6470-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041136_768542_181794"/>
      <ownedElement xmi:id="45d5aa10-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="45d5ab00-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041136_768542_181794"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="45d63890-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="45d63960-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041136_768542_181794"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="693" y="357" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_56080_402735" xmi:uuid="397f6e50-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041075_266878_181768"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_561302_372878"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_731828_372884"/>
      <waypoint x="1253" y="182"/>
      <waypoint x="513" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_570383_402736" xmi:uuid="397f78b0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041077_368079_181770"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_371944_372896"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_910743_372868"/>
      <waypoint x="924" y="109"/>
      <waypoint x="237" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_60336_402737" xmi:uuid="397f8b10-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041077_310997_181771"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_997685_372870"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_74267_372888"/>
      <waypoint x="241" y="207"/>
      <waypoint x="294" y="207"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_329453_402738" xmi:uuid="397f9170-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041078_615860_181772"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_804610_372890"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_817871_372882"/>
      <waypoint x="616" y="224"/>
      <waypoint x="513" y="224"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_648561_402739" xmi:uuid="397f9c90-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041079_15464_181773"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_744249_372898"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_25785_372891"/>
      <waypoint x="924" y="224"/>
      <waypoint x="795" y="224"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_643133_402740" xmi:uuid="397fac20-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041080_391926_181775"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_793072_372893"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_196148_372886"/>
      <waypoint x="616" y="333"/>
      <waypoint x="599" y="333"/>
      <waypoint x="599" y="277"/>
      <waypoint x="513" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_748130_402741" xmi:uuid="397fb910-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041081_570561_181776"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_287420_372903"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_243126_372894"/>
      <waypoint x="938" y="333"/>
      <waypoint x="784" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_877013_402742" xmi:uuid="397fbf70-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041082_106909_181778"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_582189_372879"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_672236_372872"/>
      <waypoint x="1253" y="406"/>
      <waypoint x="237" y="406"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_288977_402743" xmi:uuid="397fd010-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041083_567470_181779"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_955649_372880"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_184492_372875"/>
      <waypoint x="1253" y="448"/>
      <waypoint x="241" y="448"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_691217_402744" xmi:uuid="397fde10-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041084_331063_181780"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025971_259957_372877"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025971_179718_372865"/>
      <waypoint x="1579" y="84"/>
      <waypoint x="1602" y="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025971_179718_372865" xmi:uuid="397fee00-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041101_808827_181786"/>
      <bounds x="1602" y="76" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1605" height="492"/>
    <name>ChangeElementSequence</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564041301_687843_181862" xmi:uuid="39800d20-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_219927_164584"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_389340_372914" xmi:uuid="398270b0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041141_569965_181797"/>
      <ownedElement xmi:id="39816510-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39816610-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041141_569965_181797"/>
        <text>FrozenObject:DeltaChangeManagementObjectSelect</text>
      </ownedElement>
      <ownedElement xmi:id="3981d170-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="3981d220-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041141_569965_181797"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_246026_372915" xmi:uuid="39826ad0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
        <ownedElement xmi:id="39824ef0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39824f70-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
          <bounds x="203" y="938" width="351" height="13"/>
          <text>deltaChangeManagementObjectSelect : change_management_object [1]</text>
        </ownedElement>
        <bounds x="359" y="956" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="952" width="332" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_955933_372917" xmi:uuid="39c7f990-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041351_669914_181896"/>
      <ownedElement xmi:id="39a67d20-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39a67e20-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041351_669914_181896"/>
        <text>frozen_assignment:Frozen_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="39a6ee00-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39a6eea0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041351_669914_181896"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="39a704d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39a70570-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="39a71410-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39a714a0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_300451_372918" xmi:uuid="39c7f1d0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Frozen_assignment-frozen_item"/>
          <ownedElement xmi:id="39bd4010-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39bd4120-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Frozen_assignment-frozen_item"/>
            <text>frozen_item:change_management_object</text>
          </ownedElement>
          <ownedElement xmi:id="39c7ddc0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:uuid="39c7dec0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Frozen_assignment-frozen_item"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="651" y="953" width="275" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="917" width="315" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_577978_402748" xmi:uuid="39c80590-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041339_850860_181883"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_300451_372918"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_246026_372915"/>
      <waypoint x="651" y="959"/>
      <waypoint x="374" y="959"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026832_642227_402749" xmi:uuid="39c80ba0-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041340_419214_181884"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_955933_372917"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025972_332819_372912"/>
      <waypoint x="819" y="917"/>
      <waypoint x="819" y="882"/>
      <waypoint x="957" y="882"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025972_332819_372912" xmi:uuid="39c81950-0d2d-013c-5e1d-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041347_727400_181895"/>
      <bounds x="957" y="868" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_862503_143098" xmi:uuid="4608ecc0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509987065721_230294_25388"/>
      <bounds x="462" y="28" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_576439_143099" xmi:uuid="460a4450-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023528_239070_143060"/>
      <ownedElement xmi:id="46098090-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="46098150-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023528_239070_143060"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="460a27d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="460a28d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023528_239070_143060"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="259" y="259" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722344054_23375_144401" xmi:uuid="4663cc50-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722346706_702292_144402"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_955933_372917"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026209_59505_143110"/>
      <waypoint x="714" y="917"/>
      <waypoint x="714" y="235"/>
      <waypoint x="631" y="235"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_524195_143100" xmi:uuid="466469c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023533_824376_143061"/>
      <ownedElement xmi:id="46155d20-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="46155e20-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023533_824376_143061"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="46160e80-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="46160f60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023533_824376_143061"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="461644e0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="46164590-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="46165cf0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="46165df0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_347877_143109" xmi:uuid="462cb070-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="462179b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="46217ab0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="462c7c10-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="462c7d10-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="448" y="189" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_59505_143110" xmi:uuid="464d5a90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="464244d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="464245d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="464d3800-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="464d3900-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="448" y="224" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_622824_143111" xmi:uuid="4663ad90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="46585900-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="465859f0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="46637ce0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="46637de0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="448" y="259" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="434" y="161" width="254" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722338319_81009_144382" xmi:uuid="b7b6e910-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722340703_229703_144383"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_955933_372917"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026209_406026_143112"/>
      <waypoint x="714" y="917"/>
      <waypoint x="714" y="347"/>
      <waypoint x="652" y="347"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_965610_143101" xmi:uuid="46a64250-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
      <ownedElement xmi:id="b7898630-48ad-013c-be37-3733fc5daa49" xmi:uuid="b7898740-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b7913df0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b7913fc0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b791a810-48ad-013c-be37-3733fc5daa49" xmi:uuid="b791a920-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b791e990-48ad-013c-be37-3733fc5daa49" xmi:uuid="b791ea40-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_406026_143112" xmi:uuid="b7b63090-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="b7a9c360-48ad-013c-be37-3733fc5daa49" xmi:uuid="b7a9c470-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b7b5c760-48ad-013c-be37-3733fc5daa49" xmi:uuid="b7b5ca70-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="469" y="336" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="455" y="308" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722350209_181493_144420" xmi:uuid="b8013a90-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722353693_887297_144421"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_955933_372917"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026209_139731_143113"/>
      <waypoint x="714" y="917"/>
      <waypoint x="714" y="123"/>
      <waypoint x="597" y="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_820746_143102" xmi:uuid="46e82490-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
      <ownedElement xmi:id="b7d07a80-48ad-013c-be37-3733fc5daa49" xmi:uuid="b7d07bb0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b7ddd0a0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b7ddd1c0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b7de4910-48ad-013c-be37-3733fc5daa49" xmi:uuid="b7de49f0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b7de8da0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b7de8f40-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_139731_143113" xmi:uuid="b800f010-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b7f57b80-48ad-013c-be37-3733fc5daa49" xmi:uuid="b7f57c80-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b800a310-48ad-013c-be37-3733fc5daa49" xmi:uuid="b800a410-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="112" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="84" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_684251_143103" xmi:uuid="4729e430-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
      <ownedElement xmi:id="b818a340-48ad-013c-be37-3733fc5daa49" xmi:uuid="b818a4a0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="b8254a30-48ad-013c-be37-3733fc5daa49" xmi:uuid="b8254b50-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b825b2e0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b825b3e0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b8260300-48ad-013c-be37-3733fc5daa49" xmi:uuid="b82603d0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_10638_143114" xmi:uuid="b8485100-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="b83cc790-48ad-013c-be37-3733fc5daa49" xmi:uuid="b83cc8b0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="b847ee80-48ad-013c-be37-3733fc5daa49" xmi:uuid="b847ef70-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="133" y="385" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="119" y="357" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722333066_42773_144363" xmi:uuid="4777d8e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722334932_124455_144364"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_955933_372917"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026209_880920_143116"/>
      <waypoint x="714" y="917"/>
      <waypoint x="714" y="424"/>
      <waypoint x="588" y="424"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_236736_143104" xmi:uuid="477885d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023538_384762_143062"/>
      <ownedElement xmi:id="473545b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="473547d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023538_384762_143062"/>
        <text>smplDescAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="4735e200-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4735e2d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023538_384762_143062"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="47363ef0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="47363ff0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="47366550-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="47366650-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_264443_143115" xmi:uuid="4756f300-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="474bced0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="474bcfe0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="4756ccf0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4756cdf0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="448" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_880920_143116" xmi:uuid="4777a920-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="476c6ef0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="476c6ff0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="47777640-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="47777750-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="413" y="413" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="385" width="287" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_610096_143105" xmi:uuid="479af390-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023544_552948_143063"/>
      <ownedElement xmi:id="4783ba80-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4783bb70-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023544_552948_143063"/>
        <text>descText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="47847290-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="47847390-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023544_552948_143063"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="4784a160-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4784a200-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4784ba50-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4784baf0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_669467_143117" xmi:uuid="479aea40-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="478fd0b0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="478fd1b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="479ac370-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="479ac470-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="231" y="532" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="217" y="504" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722324059_489816_144344" xmi:uuid="b8ff7440-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722328262_381890_144345"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_955933_372917"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026209_501925_143118"/>
      <waypoint x="714" y="917"/>
      <waypoint x="714" y="620"/>
      <waypoint x="581" y="620"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_296021_143106" xmi:uuid="47dd4e60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
      <ownedElement xmi:id="b8d15060-48ad-013c-be37-3733fc5daa49" xmi:uuid="b8d15160-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b8ddc3a0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b8ddc490-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b8de2ed0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b8de2f80-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b8de71a0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b8de7240-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_501925_143118" xmi:uuid="b8ff29a0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="b8f3c3c0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b8f3c4b0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="b8fedc10-48ad-013c-be37-3733fc5daa49" xmi:uuid="b8fedd00-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="406" y="609" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="392" y="581" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722313221_494251_144306" xmi:uuid="b94358d0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722315054_354265_144307"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_955933_372917"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026209_399282_143119"/>
      <waypoint x="714" y="917"/>
      <waypoint x="714" y="858"/>
      <waypoint x="639" y="858"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_213099_143107" xmi:uuid="481f29b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
      <ownedElement xmi:id="b91611e0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b91612f0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b921da60-48ad-013c-be37-3733fc5daa49" xmi:uuid="b921db60-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b9223710-48ad-013c-be37-3733fc5daa49" xmi:uuid="b92237c0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b9227830-48ad-013c-be37-3733fc5daa49" xmi:uuid="b92278d0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_399282_143119" xmi:uuid="b94309d0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b937c170-48ad-013c-be37-3733fc5daa49" xmi:uuid="b937c270-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b942b880-48ad-013c-be37-3733fc5daa49" xmi:uuid="b942b970-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="455" y="847" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="819" width="246" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026208_84015_143108" xmi:uuid="484a2610-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
      <ownedElement xmi:id="b95ba6a0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b95ba7b0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
        <text>roleSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_455134_143120" xmi:uuid="b9746b30-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="b9741f80-48ad-013c-be37-3733fc5daa49" xmi:uuid="b9742080-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="182" y="654" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="172" y="636" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="112" y="588" width="154" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_60035_143122" xmi:uuid="484a2ee0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023549_790797_143064"/>
      <source xmi:idref="_18_4_1_65b021e_1692722026209_622824_143111"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026208_576439_143099"/>
      <waypoint x="448" y="270"/>
      <waypoint x="393" y="270"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_373698_143123" xmi:uuid="484a3b60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023550_251527_143075"/>
      <source xmi:idref="_18_4_1_65b021e_1692722026209_264443_143115"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026208_610096_143105"/>
      <waypoint x="469" y="473"/>
      <waypoint x="469" y="539"/>
      <waypoint x="404" y="539"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722026209_923563_143124" xmi:uuid="484a43e0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722023550_319047_143076"/>
      <source xmi:idref="_18_4_1_65b021e_1692722026209_10638_143114"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026208_610096_143105"/>
      <waypoint x="354" y="410"/>
      <waypoint x="354" y="504"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722047891_440692_143796" xmi:uuid="48750b60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
      <ownedElement xmi:id="b98c25b0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b98c26c0-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692722047892_635239_143798" xmi:uuid="b9a3f940-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="b9a3a5b0-48ad-013c-be37-3733fc5daa49" xmi:uuid="b9a3a830-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="328" y="180" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="310" y="189" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="182" y="175" width="143" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722047892_170365_143797" xmi:uuid="489f7a60-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
      <ownedElement xmi:id="b9bb6190-48ad-013c-be37-3733fc5daa49" xmi:uuid="b9bb6290-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692722047892_98146_143800" xmi:uuid="b9d38c60-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b9d33570-48ad-013c-be37-3733fc5daa49" xmi:uuid="b9d33700-48ad-013c-be37-3733fc5daa49" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="185" y="486" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="175" y="468" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="112" y="434" width="220" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722078918_737149_143882" xmi:uuid="489f8780-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722079799_932409_143883"/>
      <source xmi:idref="_18_4_1_65b021e_1692722026208_347877_143109"/>
      <target xmi:idref="_18_4_1_65b021e_1692722047892_635239_143798"/>
      <waypoint x="448" y="196"/>
      <waypoint x="325" y="196"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722092760_735938_143904" xmi:uuid="489f91b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722094294_48310_143905"/>
      <source xmi:idref="_18_4_1_65b021e_1692722026209_669467_143117"/>
      <target xmi:idref="_18_4_1_65b021e_1692722047892_98146_143800"/>
      <waypoint x="231" y="543"/>
      <waypoint x="182" y="543"/>
      <waypoint x="182" y="483"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722230324_918373_143971" xmi:uuid="48d83e00-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227692_352930_143937"/>
      <ownedElement xmi:id="48aafa10-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48aafb20-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227692_352930_143937"/>
        <text>role:Class</text>
      </ownedElement>
      <ownedElement xmi:id="48ab8710-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48ab87c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227692_352930_143937"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="48abb790-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48abb830-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="48abd070-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48abd120-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722230325_462021_143974" xmi:uuid="48c21250-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="48b6de90-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48b6dfa0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="48c1cba0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48c1cca0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="245" y="693" width="103" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722230325_505689_143975" xmi:uuid="48d833a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="48cd11f0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48cd12f0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="48d80900-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48d80ab0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="245" y="728" width="82" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="238" y="665" width="117" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722318407_57776_144325" xmi:uuid="493c6310-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722320708_444446_144326"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025972_955933_372917"/>
      <target xmi:idref="_18_4_1_65b021e_1692722230325_624223_143977"/>
      <waypoint x="714" y="917"/>
      <waypoint x="714" y="739"/>
      <waypoint x="632" y="739"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722230325_307665_143972" xmi:uuid="493d0290-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227697_530747_143938"/>
      <ownedElement xmi:id="48e3afb0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48e3b0b0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227697_530747_143938"/>
        <text>roleAsgn2:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="48e463d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48e46500-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227697_530747_143938"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="48e49620-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48e496d0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="48e4b0d0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48e4b3c0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722230325_128884_143976" xmi:uuid="49054cf0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="48fa2780-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="48fa2880-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="49052990-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="49052a90-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="448" y="693" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722230325_624223_143977" xmi:uuid="4925ff30-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="491aa5f0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="491aa6f0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="4925d9e0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="4925dae0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="448" y="728" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692722230325_679190_143978" xmi:uuid="493c3e20-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="493102a0-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="493103a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="493c1920-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="493c1a30-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="448" y="770" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="665" width="246" height="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722230325_91820_143973" xmi:uuid="493e5380-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227703_915655_143939"/>
      <ownedElement xmi:id="493db720-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="493db800-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227703_915655_143939"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="493e3e90-249a-013c-5bf1-2bb9f4d923a9" xmi:uuid="493e4110-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227703_915655_143939"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="245" y="770" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722230325_127033_143979" xmi:uuid="493e5ba0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227709_543719_143944"/>
      <source xmi:idref="_18_4_1_65b021e_1692722230325_128884_143976"/>
      <target xmi:idref="_18_4_1_65b021e_1692722230324_918373_143971"/>
      <waypoint x="448" y="704"/>
      <waypoint x="355" y="704"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722230325_490311_143980" xmi:uuid="493e64a0-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722227710_936967_143952"/>
      <source xmi:idref="_18_4_1_65b021e_1692722230325_679190_143978"/>
      <target xmi:idref="_18_4_1_65b021e_1692722230325_91820_143973"/>
      <waypoint x="448" y="781"/>
      <waypoint x="407" y="781"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722267812_366866_144246" xmi:uuid="493e6d40-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722268794_187080_144247"/>
      <source xmi:idref="_18_4_1_65b021e_1692722230325_462021_143974"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026209_455134_143120"/>
      <waypoint x="245" y="704"/>
      <waypoint x="179" y="704"/>
      <waypoint x="179" y="651"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692722271046_120567_144268" xmi:uuid="493e7870-249a-013c-5bf1-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1692722272912_912366_144269"/>
      <source xmi:idref="_18_4_1_65b021e_1692722230325_505689_143975"/>
      <target xmi:idref="_18_4_1_65b021e_1692722026209_455134_143120"/>
      <waypoint x="245" y="739"/>
      <waypoint x="179" y="739"/>
      <waypoint x="179" y="651"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="960" height="1013"/>
    <name>FrozenAssignment</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446236074_662036_208296" xmi:uuid="4a95b610-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688563977628_219927_164584"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236121_247711_208329" xmi:uuid="4b5179e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041351_669914_181896"/>
      <ownedElement xmi:id="4b348c40-6c44-013d-931b-0800270c66d6" xmi:uuid="4b348cd0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041351_669914_181896"/>
        <text>frozen_assignment:Frozen_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="4b3c8ab0-6c44-013d-931b-0800270c66d6" xmi:uuid="4b3c8b60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041351_669914_181896"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="247" height="390"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236137_494863_208363" xmi:uuid="4b51dd40-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="699" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236147_452175_208378" xmi:uuid="4b523350-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="699" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236161_527797_208393" xmi:uuid="4b574ec0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="699" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236170_499029_208408" xmi:uuid="4b57ae00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="699" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236180_904148_208423" xmi:uuid="4b580f80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="699" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236195_938329_208438" xmi:uuid="4b5868c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="699" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236205_371428_208453" xmi:uuid="4b5d7d40-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="699" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236219_134025_208468" xmi:uuid="4b5dd070-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="699" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236233_207278_208483" xmi:uuid="4b5e2fe0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="699" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236247_429826_208498" xmi:uuid="4b5e8950-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="699" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236263_465211_208513" xmi:uuid="4b6e2300-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="699" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236279_643162_208528" xmi:uuid="4b6e85e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="699" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236290_958567_208543" xmi:uuid="4b6ee490-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="699" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236302_445847_208558" xmi:uuid="4b6f3cc0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="699" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236317_566418_208573" xmi:uuid="4b8699d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="699" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236331_942009_208588" xmi:uuid="4b86f540-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="699" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236341_685255_208603" xmi:uuid="4b8745f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="699" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_267890_389999" xmi:uuid="4b875230-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041343_370164_181889"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236137_494863_208363"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="62"/>
      <waypoint x="292" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_444975_390002" xmi:uuid="4b875840-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041346_727898_181893"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236147_452175_208378"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="82"/>
      <waypoint x="292" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_926867_390005" xmi:uuid="4b875f50-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041344_931503_181890"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236161_527797_208393"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="102"/>
      <waypoint x="292" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_48548_390008" xmi:uuid="4b876600-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041341_598348_181886"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236170_499029_208408"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="122"/>
      <waypoint x="292" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_996868_390011" xmi:uuid="4b876c20-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041340_518865_181885"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236180_904148_208423"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="142"/>
      <waypoint x="292" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_707216_390014" xmi:uuid="4b8774c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1696601162090_89244_176186"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236195_938329_208438"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="162"/>
      <waypoint x="292" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_416773_390017" xmi:uuid="4b877dd0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1696601162178_604366_176202"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236205_371428_208453"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="182"/>
      <waypoint x="292" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_830246_390020" xmi:uuid="4b878510-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041345_478923_181892"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236219_134025_208468"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="202"/>
      <waypoint x="292" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_503781_390023" xmi:uuid="4b878b80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041343_75710_181888"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236233_207278_208483"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="222"/>
      <waypoint x="292" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_402581_390026" xmi:uuid="4b879160-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1696601162292_733987_176248"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236247_429826_208498"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="242"/>
      <waypoint x="292" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_660689_390029" xmi:uuid="4b879890-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1696601162378_18019_176264"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236263_465211_208513"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="262"/>
      <waypoint x="292" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_722673_390032" xmi:uuid="4b879f60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1696601162468_201550_176280"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236279_643162_208528"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="282"/>
      <waypoint x="292" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_167210_390035" xmi:uuid="4b87a7f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1696601162558_907728_176296"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236290_958567_208543"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="302"/>
      <waypoint x="292" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_728754_390038" xmi:uuid="4b940430-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1696601162641_375468_176312"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236302_445847_208558"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="322"/>
      <waypoint x="292" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_927221_390041" xmi:uuid="4b940c50-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1696601162727_176512_176328"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236317_566418_208573"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="342"/>
      <waypoint x="292" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_921291_390044" xmi:uuid="4b941c00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1696601162811_123915_176344"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236331_942009_208588"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="362"/>
      <waypoint x="292" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487430_341782_390047" xmi:uuid="4b9426b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1696601162897_871928_176360"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236341_685255_208603"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236121_247711_208329"/>
      <waypoint x="699" y="382"/>
      <waypoint x="292" y="382"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="702" height="460"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727167459402_205312_126384" xmi:uuid="4b95f930-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167458204_442443_126382"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_332730_126963" xmi:uuid="4bef38d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459470_67707_126457"/>
      <ownedElement xmi:id="4bc2ee30-6c44-013d-931b-0800270c66d6" xmi:uuid="4bc2ef00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459470_67707_126457"/>
        <text>Related:DeltaChange</text>
      </ownedElement>
      <ownedElement xmi:id="4bd4bc90-6c44-013d-931b-0800270c66d6" xmi:uuid="4bd4bd30-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459470_67707_126457"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727168389023_999495_129551" xmi:uuid="4bef2c20-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040783_443861_181713"/>
        <ownedElement xmi:id="4bee2d90-6c44-013d-931b-0800270c66d6" xmi:uuid="4bee2e70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040783_443861_181713"/>
          <bounds x="200" y="802" width="124" height="13"/>
          <text>deltaChange : Change [1]</text>
        </ownedElement>
        <bounds x="182" y="811" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="805" width="155" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_28258_126964" xmi:uuid="4c1cc290-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459470_463691_126458"/>
      <ownedElement xmi:id="4bf0b810-6c44-013d-931b-0800270c66d6" xmi:uuid="4bf0b8c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459470_463691_126458"/>
        <text>Relating:DeltaChange</text>
      </ownedElement>
      <ownedElement xmi:id="4c0bb440-6c44-013d-931b-0800270c66d6" xmi:uuid="4c0bb4f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459470_463691_126458"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727168413507_73235_129567" xmi:uuid="4c1cb1c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040783_443861_181713"/>
        <ownedElement xmi:id="4c11a770-6c44-013d-931b-0800270c66d6" xmi:uuid="4c11a850-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564040783_443861_181713"/>
          <bounds x="204" y="1089" width="124" height="13"/>
          <text>deltaChange : Change [1]</text>
        </ownedElement>
        <bounds x="186" y="1098" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="1092" width="159" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_357371_126987" xmi:uuid="4c572360-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459481_293075_126473"/>
      <ownedElement xmi:id="4c257da0-6c44-013d-931b-0800270c66d6" xmi:uuid="4c257e70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459481_293075_126473"/>
        <text>theClassificationRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="4c4c8cb0-6c44-013d-931b-0800270c66d6" xmi:uuid="4c4c8d90-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459481_293075_126473"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="553" y="602" width="269" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_661605_127030" xmi:uuid="50f1a1a0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459462_33586_126425"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_503169_126992"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925394_856887_126989"/>
      <waypoint x="789" y="546"/>
      <waypoint x="861" y="546"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_276013_127031" xmi:uuid="51153740-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459463_607168_126439"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_561686_126997"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925394_579008_126990"/>
      <waypoint x="1246" y="578"/>
      <waypoint x="1045" y="578"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_572305_126988" xmi:uuid="5117bff0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459480_639560_126472"/>
      <ownedElement xmi:id="4cb86ad0-6c44-013d-931b-0800270c66d6" xmi:uuid="4cb86b80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459480_639560_126472"/>
        <text>ca2:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="4cd516c0-6c44-013d-931b-0800270c66d6" xmi:uuid="4cd517d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459480_639560_126472"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="4ce82160-6c44-013d-931b-0800270c66d6" xmi:uuid="4ce82200-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4ce9ca90-6c44-013d-931b-0800270c66d6" xmi:uuid="4ce9cb80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_856887_126989" xmi:uuid="4e3b2200-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="4dd6f4d0-6c44-013d-931b-0800270c66d6" xmi:uuid="4dd6f5b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="4e3ac350-6c44-013d-931b-0800270c66d6" xmi:uuid="4e3ac400-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="532" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_579008_126990" xmi:uuid="4fc49510-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="4f26ac70-6c44-013d-931b-0800270c66d6" xmi:uuid="4f26ad30-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="4fc43aa0-6c44-013d-931b-0800270c66d6" xmi:uuid="4fc43bd0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="567" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_367388_126991" xmi:uuid="50f14860-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="50860d80-6c44-013d-931b-0800270c66d6" xmi:uuid="50860ef0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="50f0e300-6c44-013d-931b-0800270c66d6" xmi:uuid="50f0e560-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="861" y="602" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="847" y="504" width="210" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_503169_126992" xmi:uuid="55c94070-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459481_112866_126474"/>
      <ownedElement xmi:id="51fad0c0-6c44-013d-931b-0800270c66d6" xmi:uuid="51fad220-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459481_112866_126474"/>
        <text>c:Class</text>
      </ownedElement>
      <ownedElement xmi:id="5212c700-6c44-013d-931b-0800270c66d6" xmi:uuid="5212c8c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459481_112866_126474"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="52261ef0-6c44-013d-931b-0800270c66d6" xmi:uuid="522620a0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="52267420-6c44-013d-931b-0800270c66d6" xmi:uuid="522674f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_556178_126993" xmi:uuid="53e4d7c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="53168720-6c44-013d-931b-0800270c66d6" xmi:uuid="53168870-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="53cab780-6c44-013d-931b-0800270c66d6" xmi:uuid="53cab8a0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="679" y="511" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_644799_126994" xmi:uuid="55c93150-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="550d4260-6c44-013d-931b-0800270c66d6" xmi:uuid="550dd060-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="55b24a20-6c44-013d-931b-0800270c66d6" xmi:uuid="55c0e090-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="679" y="539" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="665" y="483" width="124" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_561686_126997" xmi:uuid="5cbc02d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459483_649513_126476"/>
      <ownedElement xmi:id="5677e1c0-6c44-013d-931b-0800270c66d6" xmi:uuid="5677e3a0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459483_649513_126476"/>
        <text>delta_change_relationship:Activity_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="56b59830-6c44-013d-931b-0800270c66d6" xmi:uuid="56d339e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459483_649513_126476"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="56f9eac0-6c44-013d-931b-0800270c66d6" xmi:uuid="56fa3300-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="56faa6f0-6c44-013d-931b-0800270c66d6" xmi:uuid="56faa7b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_944889_126998" xmi:uuid="5834d050-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-description"/>
          <ownedElement xmi:id="57ce5150-6c44-013d-931b-0800270c66d6" xmi:uuid="57ce5270-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="58347180-6c44-013d-931b-0800270c66d6" xmi:uuid="58347240-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1267" y="140" width="144" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_104966_126999" xmi:uuid="59327e90-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-name"/>
          <ownedElement xmi:id="58ab9f40-6c44-013d-931b-0800270c66d6" xmi:uuid="58ab9fe0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="59321dd0-6c44-013d-931b-0800270c66d6" xmi:uuid="59321ee0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1267" y="364" width="101" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_917290_127000" xmi:uuid="5b1cad60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-related_activity"/>
          <ownedElement xmi:id="5a95ea40-6c44-013d-931b-0800270c66d6" xmi:uuid="5a95ebe0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-related_activity"/>
            <text>related_activity:Activity</text>
          </ownedElement>
          <ownedElement xmi:id="5b19a660-6c44-013d-931b-0800270c66d6" xmi:uuid="5b1a9910-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-related_activity"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1267" y="840" width="160" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_178195_127001" xmi:uuid="5cbbee60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-relating_activity"/>
          <ownedElement xmi:id="5c23e370-6c44-013d-931b-0800270c66d6" xmi:uuid="5c475220-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-relating_activity"/>
            <text>relating_activity:Activity</text>
          </ownedElement>
          <ownedElement xmi:id="5cbb6cf0-6c44-013d-931b-0800270c66d6" xmi:uuid="5cbb6ee0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_relationship-relating_activity"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1267" y="1099" width="164" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1246" y="42" width="289" height="1092"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_755935_127002" xmi:uuid="66205340-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459484_692715_126477"/>
      <ownedElement xmi:id="5f697b80-6c44-013d-931b-0800270c66d6" xmi:uuid="5f697ca0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459484_692715_126477"/>
        <text>related:Activity</text>
      </ownedElement>
      <ownedElement xmi:id="5f871cd0-6c44-013d-931b-0800270c66d6" xmi:uuid="5f871da0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459484_692715_126477"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="5f9e1e50-6c44-013d-931b-0800270c66d6" xmi:uuid="5f9e1f10-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5f9e7c00-6c44-013d-931b-0800270c66d6" xmi:uuid="5f9e7cd0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_667887_127003" xmi:uuid="622c0140-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
          <ownedElement xmi:id="61501bf0-6c44-013d-931b-0800270c66d6" xmi:uuid="616358e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
            <text>chosen_method:Activity_method</text>
          </ownedElement>
          <ownedElement xmi:id="622ba6b0-6c44-013d-931b-0800270c66d6" xmi:uuid="622ba7c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="994" y="889" width="213" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_363000_127004" xmi:uuid="63e58d10-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
          <ownedElement xmi:id="631dd630-6c44-013d-931b-0800270c66d6" xmi:uuid="631dd750-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="639eabf0-6c44-013d-931b-0800270c66d6" xmi:uuid="639eb1f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="994" y="854" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_700788_127005" xmi:uuid="65d463f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
          <ownedElement xmi:id="6468a910-6c44-013d-931b-0800270c66d6" xmi:uuid="6468a9f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="65d40020-6c44-013d-931b-0800270c66d6" xmi:uuid="65d40190-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="994" y="798" width="101" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="980" y="770" width="234" height="154"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_946504_127006" xmi:uuid="708cd650-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459485_696373_126478"/>
      <ownedElement xmi:id="677eb910-6c44-013d-931b-0800270c66d6" xmi:uuid="677ebb20-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459485_696373_126478"/>
        <text>relating:Activity</text>
      </ownedElement>
      <ownedElement xmi:id="67d1d150-6c44-013d-931b-0800270c66d6" xmi:uuid="67d1d290-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459485_696373_126478"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="67d24380-6c44-013d-931b-0800270c66d6" xmi:uuid="67d24450-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="67d2a100-6c44-013d-931b-0800270c66d6" xmi:uuid="67d2a1c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_480089_127007" xmi:uuid="6bdbb7b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
          <ownedElement xmi:id="6a66ba90-6c44-013d-931b-0800270c66d6" xmi:uuid="6a6777e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
            <text>chosen_method:Activity_method</text>
          </ownedElement>
          <ownedElement xmi:id="6bdb5b60-6c44-013d-931b-0800270c66d6" xmi:uuid="6bdb5c80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="994" y="1057" width="213" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_813025_127008" xmi:uuid="6e200230-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
          <ownedElement xmi:id="6ca9e840-6c44-013d-931b-0800270c66d6" xmi:uuid="6ca9e960-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="6e114990-6c44-013d-931b-0800270c66d6" xmi:uuid="6e1ecb40-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="994" y="1113" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_9460_127009" xmi:uuid="708cc870-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
          <ownedElement xmi:id="6f7781a0-6c44-013d-931b-0800270c66d6" xmi:uuid="6f8f1c00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="707e2c10-6c44-013d-931b-0800270c66d6" xmi:uuid="707e2d40-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="994" y="1155" width="101" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="980" y="1029" width="234" height="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_445534_127037" xmi:uuid="7cac2f10-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459462_80312_126428"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_755935_127002"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925395_288108_127011"/>
      <waypoint x="980" y="784"/>
      <waypoint x="571" y="784"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_300233_127010" xmi:uuid="7cd88500-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459485_497595_126479"/>
      <ownedElement xmi:id="71a532d0-6c44-013d-931b-0800270c66d6" xmi:uuid="71b81d00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459485_497595_126479"/>
        <text>related_aaa:Applied_activity_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="72213600-6c44-013d-931b-0800270c66d6" xmi:uuid="72216b30-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459485_497595_126479"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="72309d10-6c44-013d-931b-0800270c66d6" xmi:uuid="72309f70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="723b6e70-6c44-013d-931b-0800270c66d6" xmi:uuid="723b6f70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_288108_127011" xmi:uuid="76c43670-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-assigned_activity"/>
          <ownedElement xmi:id="7515ac70-6c44-013d-931b-0800270c66d6" xmi:uuid="7516a760-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-assigned_activity"/>
            <text>assigned_activity:Activity</text>
          </ownedElement>
          <ownedElement xmi:id="766ec760-6c44-013d-931b-0800270c66d6" xmi:uuid="767b5590-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-assigned_activity"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="399" y="771" width="172" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_584175_127012" xmi:uuid="7a25f830-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-items"/>
          <ownedElement xmi:id="78c5a840-6c44-013d-931b-0800270c66d6" xmi:uuid="78c5a910-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-items"/>
            <text>items:activity_item</text>
          </ownedElement>
          <ownedElement xmi:id="7a06fa30-6c44-013d-931b-0800270c66d6" xmi:uuid="7a0852f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="399" y="806" width="146" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_66052_127013" xmi:uuid="7c4e1440-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-role"/>
          <ownedElement xmi:id="7b4dafe0-6c44-013d-931b-0800270c66d6" xmi:uuid="7b4db0f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="7c2caa40-6c44-013d-931b-0800270c66d6" xmi:uuid="7c2cab50-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="399" y="841" width="92" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="385" y="742" width="253" height="134"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_689298_127038" xmi:uuid="8db89cf0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459463_932071_126431"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_946504_127006"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925395_412064_127015"/>
      <waypoint x="980" y="1071"/>
      <waypoint x="571" y="1071"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_546969_127014" xmi:uuid="8e1ba5b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459486_489239_126480"/>
      <ownedElement xmi:id="7ed48380-6c44-013d-931b-0800270c66d6" xmi:uuid="7ed4f5c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459486_489239_126480"/>
        <text>relating_aaa:Applied_activity_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="7f52cdc0-6c44-013d-931b-0800270c66d6" xmi:uuid="7f5669d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459486_489239_126480"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="80272b20-6c44-013d-931b-0800270c66d6" xmi:uuid="8027e290-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="802ae510-6c44-013d-931b-0800270c66d6" xmi:uuid="802ae6e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_412064_127015" xmi:uuid="848aefd0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-assigned_activity"/>
          <ownedElement xmi:id="82d0d050-6c44-013d-931b-0800270c66d6" xmi:uuid="82d0d170-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-assigned_activity"/>
            <text>assigned_activity:Activity</text>
          </ownedElement>
          <ownedElement xmi:id="8489a280-6c44-013d-931b-0800270c66d6" xmi:uuid="848a5db0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-assigned_activity"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="399" y="1058" width="172" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_12701_127016" xmi:uuid="88b839b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-items"/>
          <ownedElement xmi:id="86d0e260-6c44-013d-931b-0800270c66d6" xmi:uuid="86d805b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-items"/>
            <text>items:activity_item</text>
          </ownedElement>
          <ownedElement xmi:id="8893e260-6c44-013d-931b-0800270c66d6" xmi:uuid="889b2d90-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="399" y="1093" width="146" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_918291_127017" xmi:uuid="8ccd05a0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-role"/>
          <ownedElement xmi:id="8a8136f0-6c44-013d-931b-0800270c66d6" xmi:uuid="8a813830-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="8c926720-6c44-013d-931b-0800270c66d6" xmi:uuid="8c952b30-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="399" y="1128" width="92" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="385" y="1029" width="257" height="134"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_805517_127018" xmi:uuid="9628de70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459486_123577_126481"/>
      <ownedElement xmi:id="91fb5110-6c44-013d-931b-0800270c66d6" xmi:uuid="922be1e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459486_123577_126481"/>
        <text>dummyMethod:Activity_method</text>
      </ownedElement>
      <ownedElement xmi:id="961c74e0-6c44-013d-931b-0800270c66d6" xmi:uuid="961ca020-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459486_123577_126481"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="980" y="938" width="209" height="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_997153_127020" xmi:uuid="97c3bcc0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459487_766916_126484"/>
      <ownedElement xmi:id="967e29e0-6c44-013d-931b-0800270c66d6" xmi:uuid="96a9d4d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459487_766916_126484"/>
        <text>theRole1:String</text>
      </ownedElement>
      <ownedElement xmi:id="97266f20-6c44-013d-931b-0800270c66d6" xmi:uuid="97565f50-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459487_766916_126484"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="91" y="840" width="274" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_597916_127021" xmi:uuid="a3639dc0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459488_84124_126485"/>
      <ownedElement xmi:id="98d1e050-6c44-013d-931b-0800270c66d6" xmi:uuid="98e1bf60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459488_84124_126485"/>
        <text>theRole2:String</text>
      </ownedElement>
      <ownedElement xmi:id="a3636390-6c44-013d-931b-0800270c66d6" xmi:uuid="a36364a0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459488_84124_126485"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="91" y="1127" width="278" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_775438_127022" xmi:uuid="a384a170-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459489_88036_126486"/>
      <ownedElement xmi:id="a3775ac0-6c44-013d-931b-0800270c66d6" xmi:uuid="a3775b90-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459489_88036_126486"/>
        <text>theName1:String</text>
      </ownedElement>
      <ownedElement xmi:id="a3783060-6c44-013d-931b-0800270c66d6" xmi:uuid="a3783120-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459489_88036_126486"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="651" y="798" width="256" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_664821_127023" xmi:uuid="a3960a00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459489_190951_126487"/>
      <ownedElement xmi:id="a385b540-6c44-013d-931b-0800270c66d6" xmi:uuid="a385b610-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459489_190951_126487"/>
        <text>theName2:String</text>
      </ownedElement>
      <ownedElement xmi:id="a395f100-6c44-013d-931b-0800270c66d6" xmi:uuid="a395f1b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459489_190951_126487"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="658" y="1162" width="256" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_748457_127032" xmi:uuid="a3961e80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459459_868369_126405"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_454531_126995"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925394_561686_126997"/>
      <waypoint x="1547" y="32"/>
      <waypoint x="1425" y="32"/>
      <waypoint x="1425" y="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_674488_127033" xmi:uuid="a3962f80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459460_832389_126406"/>
      <source xmi:idref="_18_4_1_65b021e_1727168549670_612507_129727"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925394_561686_126997"/>
      <waypoint x="1045" y="102"/>
      <waypoint x="1246" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_48302_127034" xmi:uuid="a3964b70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459461_306532_126414"/>
      <source xmi:idref="_18_4_1_65b021e_1727168549670_955595_129723"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925394_561686_126997"/>
      <waypoint x="1036" y="235"/>
      <waypoint x="1246" y="235"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_398291_127039" xmi:uuid="a39663d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459463_218016_126432"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_917290_127000"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925394_755935_127002"/>
      <waypoint x="1267" y="851"/>
      <waypoint x="1214" y="851"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_161028_127040" xmi:uuid="a3966d70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459463_224543_126433"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_178195_127001"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925394_946504_127006"/>
      <waypoint x="1267" y="1110"/>
      <waypoint x="1214" y="1110"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_824724_127041" xmi:uuid="a3967a80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459463_226492_126434"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_667887_127003"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925395_805517_127018"/>
      <waypoint x="1019" y="914"/>
      <waypoint x="1019" y="938"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_321769_127042" xmi:uuid="a3968840-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459463_339426_126435"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_480089_127007"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925395_805517_127018"/>
      <waypoint x="1019" y="1057"/>
      <waypoint x="1019" y="1012"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_777319_127043" xmi:uuid="a3aa85c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459463_331691_126436"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_367388_126991"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925394_357371_126987"/>
      <waypoint x="861" y="616"/>
      <waypoint x="822" y="616"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_45900_127044" xmi:uuid="a3aa9260-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459464_821789_126443"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925395_66052_127013"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925395_997153_127020"/>
      <waypoint x="399" y="851"/>
      <waypoint x="365" y="851"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_497278_127045" xmi:uuid="a3aaa200-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459464_185906_126444"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925395_918291_127017"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925395_597916_127021"/>
      <waypoint x="399" y="1138"/>
      <waypoint x="369" y="1138"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_773088_127046" xmi:uuid="a3aab220-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459464_55373_126445"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925395_9460_127009"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925395_664821_127023"/>
      <waypoint x="994" y="1173"/>
      <waypoint x="914" y="1173"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925395_962900_127047" xmi:uuid="a3aabbd0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459464_830972_126446"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_700788_127005"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925395_775438_127022"/>
      <waypoint x="994" y="809"/>
      <waypoint x="907" y="809"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727167925394_454531_126995" xmi:uuid="a3ab27e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459472_438571_126460"/>
      <bounds x="1547" y="23" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168445119_301817_129679" xmi:uuid="a3ab36a0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="917" y="14" width="115" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168805555_169816_130477" xmi:uuid="a6c2a0f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727168807306_851249_130478"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_561686_126997"/>
      <target xmi:idref="_18_4_1_65b021e_1727168549670_381298_129722"/>
      <waypoint x="1246" y="459"/>
      <waypoint x="1044" y="459"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168549670_307812_129717" xmi:uuid="a6c33b60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="a4982dd0-6c44-013d-931b-0800270c66d6" xmi:uuid="a4982eb0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a52c52f0-6c44-013d-931b-0800270c66d6" xmi:uuid="a52c55c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a53daf90-6c44-013d-931b-0800270c66d6" xmi:uuid="a53db050-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a5487ca0-6c44-013d-931b-0800270c66d6" xmi:uuid="a5487da0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727168549670_381298_129722" xmi:uuid="a6c23c50-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="a6459b50-6c44-013d-931b-0800270c66d6" xmi:uuid="a6459c30-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="a6b11420-6c44-013d-931b-0800270c66d6" xmi:uuid="a6b114d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="448" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="847" y="420" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168549670_228915_129718" xmi:uuid="a9c0dac0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="a7b317a0-6c44-013d-931b-0800270c66d6" xmi:uuid="a7b31840-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a83bb910-6c44-013d-931b-0800270c66d6" xmi:uuid="a83bb9b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a83c19a0-6c44-013d-931b-0800270c66d6" xmi:uuid="a83c1a00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a83c64f0-6c44-013d-931b-0800270c66d6" xmi:uuid="a83c6550-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727168549670_955595_129723" xmi:uuid="a9c0cd00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="a929a6c0-6c44-013d-931b-0800270c66d6" xmi:uuid="a929a780-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="a9c05d70-6c44-013d-931b-0800270c66d6" xmi:uuid="a9c05e60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="224" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="847" y="196" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168774503_157536_130424" xmi:uuid="acc1f570-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727168776314_188205_130425"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_561686_126997"/>
      <target xmi:idref="_18_4_1_65b021e_1727168549670_435977_129725"/>
      <waypoint x="1246" y="315"/>
      <waypoint x="1079" y="315"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168549670_349352_129719" xmi:uuid="acc2a460-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="aac5bac0-6c44-013d-931b-0800270c66d6" xmi:uuid="aac5bb80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="ab3f13d0-6c44-013d-931b-0800270c66d6" xmi:uuid="ab3f14d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ab3f9790-6c44-013d-931b-0800270c66d6" xmi:uuid="ab3f9850-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ab56a420-6c44-013d-931b-0800270c66d6" xmi:uuid="ab56a4d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727168549670_435977_129725" xmi:uuid="acc17d80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="ac2f21a0-6c44-013d-931b-0800270c66d6" xmi:uuid="ac2f2260-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="acb73170-6c44-013d-931b-0800270c66d6" xmi:uuid="acb73260-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="302" width="218" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="847" y="273" width="272" height="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168549670_512589_129720" xmi:uuid="afca6250-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="adf601e0-6c44-013d-931b-0800270c66d6" xmi:uuid="adf602b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ae6742d0-6c44-013d-931b-0800270c66d6" xmi:uuid="ae674380-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ae771f80-6c44-013d-931b-0800270c66d6" xmi:uuid="ae772070-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ae78b9a0-6c44-013d-931b-0800270c66d6" xmi:uuid="ae78ba70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727168549670_612507_129727" xmi:uuid="afca42c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="af63e590-6c44-013d-931b-0800270c66d6" xmi:uuid="af63e660-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="afc9dc60-6c44-013d-931b-0800270c66d6" xmi:uuid="afc9dd10-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="91" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="847" y="63" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169010472_909112_130585" xmi:uuid="b2bc6bb0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169011422_651251_130586"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_561686_126997"/>
      <target xmi:idref="_18_4_1_65b021e_1727168549670_899048_129729"/>
      <waypoint x="1246" y="690"/>
      <waypoint x="1045" y="690"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168549670_980390_129721" xmi:uuid="b2bd3830-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="b0b43920-6c44-013d-931b-0800270c66d6" xmi:uuid="b0b439d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b1402dd0-6c44-013d-931b-0800270c66d6" xmi:uuid="b1402ea0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b1464c70-6c44-013d-931b-0800270c66d6" xmi:uuid="b1464d30-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b1469e90-6c44-013d-931b-0800270c66d6" xmi:uuid="b146a310-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1727168549670_899048_129729" xmi:uuid="b2bc0780-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b22b1a00-6c44-013d-931b-0800270c66d6" xmi:uuid="b22b1a90-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b2a631e0-6c44-013d-931b-0800270c66d6" xmi:uuid="b2a632a0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="679" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="847" y="651" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168685007_636329_130171" xmi:uuid="b4a16fc0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="b3a56510-6c44-013d-931b-0800270c66d6" xmi:uuid="b3a565f0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727168685007_21216_130176" xmi:uuid="b4a16490-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="b49b84c0-6c44-013d-931b-0800270c66d6" xmi:uuid="b49b8560-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="759" y="359" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="741" y="368" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="588" y="357" width="168" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168685007_223960_130172" xmi:uuid="b6ea7e50-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="b5cfc4d0-6c44-013d-931b-0800270c66d6" xmi:uuid="b5cfc5b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727168685007_908411_130180" xmi:uuid="b6ea74d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="b6ea1300-6c44-013d-931b-0800270c66d6" xmi:uuid="b6ea13d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="570" y="519" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="552" y="528" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="364" y="504" width="203" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168685007_763847_130173" xmi:uuid="b8e663c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="b7e957a0-6c44-013d-931b-0800270c66d6" xmi:uuid="b7e95860-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727168685007_36586_130188" xmi:uuid="b8e657b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b8ce5130-6c44-013d-931b-0800270c66d6" xmi:uuid="b8ce5220-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="1075" y="137" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="1057" y="146" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="847" y="133" width="225" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168712517_146681_130378" xmi:uuid="b8e66bb0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727168713668_469529_130379"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_944889_126998"/>
      <target xmi:idref="_18_4_1_65b021e_1727168685007_36586_130188"/>
      <waypoint x="1267" y="154"/>
      <waypoint x="1072" y="154"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168796976_325976_130453" xmi:uuid="b8e67320-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727168798366_112681_130454"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_104966_126999"/>
      <target xmi:idref="_18_4_1_65b021e_1727169153948_757743_132018"/>
      <waypoint x="1267" y="375"/>
      <waypoint x="1064" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168987100_223691_130539" xmi:uuid="b8e67bf0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727168988391_662175_130540"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_556178_126993"/>
      <target xmi:idref="_18_4_1_65b021e_1727168685007_908411_130180"/>
      <waypoint x="679" y="522"/>
      <waypoint x="634" y="522"/>
      <waypoint x="634" y="536"/>
      <waypoint x="567" y="536"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727168992007_775491_130561" xmi:uuid="b8e689b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727168993445_699158_130562"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_644799_126994"/>
      <target xmi:idref="_18_4_1_65b021e_1727168685007_908411_130180"/>
      <waypoint x="679" y="550"/>
      <waypoint x="634" y="550"/>
      <waypoint x="634" y="536"/>
      <waypoint x="567" y="536"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169018312_766463_130604" xmi:uuid="b8e69220-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169019793_811307_130605"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925395_584175_127012"/>
      <target xmi:idref="_18_4_1_65b021e_1727168389023_999495_129551"/>
      <waypoint x="399" y="819"/>
      <waypoint x="197" y="819"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169023963_161553_130626" xmi:uuid="b8e69980-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169025313_416113_130627"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925395_12701_127016"/>
      <target xmi:idref="_18_4_1_65b021e_1727168413507_73235_129567"/>
      <waypoint x="399" y="1106"/>
      <waypoint x="201" y="1106"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169153948_922322_132015" xmi:uuid="ba78c1e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169153943_755535_132013"/>
      <ownedElement xmi:id="b991bac0-6c44-013d-931b-0800270c66d6" xmi:uuid="b991bcd0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169153943_755535_132013"/>
        <text>default:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169153948_567173_132016" xmi:uuid="ba004c80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="b9ffe8b0-6c44-013d-931b-0800270c66d6" xmi:uuid="b9ffe970-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="842" y="360" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="896" y="369" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169153948_757743_132018" xmi:uuid="ba78bb60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="ba786300-6c44-013d-931b-0800270c66d6" xmi:uuid="ba7863a0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="1067" y="358" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="1049" y="367" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="896" y="357" width="168" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169176233_846259_132072" xmi:uuid="ba78cab0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169177750_711445_132073"/>
      <source xmi:idref="_18_4_1_65b021e_1727169153948_567173_132016"/>
      <target xmi:idref="_18_4_1_65b021e_1727168685007_21216_130176"/>
      <waypoint x="896" y="375"/>
      <waypoint x="756" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169224936_981831_132932" xmi:uuid="bcb333c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169224932_997326_132930"/>
      <ownedElement xmi:id="bae7c600-6c44-013d-931b-0800270c66d6" xmi:uuid="bae7c700-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169224932_997326_132930"/>
        <text>cs2:ConcatString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169224936_908958_132933" xmi:uuid="bb9feb70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_206787_30431"/>
        <ownedElement xmi:id="bb913bc0-6c44-013d-931b-0800270c66d6" xmi:uuid="bb913c90-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_206787_30431"/>
          <bounds x="697" y="1110" width="42" height="13"/>
          <text>in1 [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="742" y="1119" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169224936_324493_132935" xmi:uuid="bc2ab6e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_900635_30432"/>
        <ownedElement xmi:id="bc1df8c0-6c44-013d-931b-0800270c66d6" xmi:uuid="bc1df970-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_900635_30432"/>
          <bounds x="813" y="1076" width="42" height="13"/>
          <text>in2 [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="803" y="1092" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169224936_916665_132937" xmi:uuid="bcb31f30-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_690247_30433"/>
        <ownedElement xmi:id="bcb29c90-6c44-013d-931b-0800270c66d6" xmi:uuid="bcb29d70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_690247_30433"/>
          <bounds x="886" y="1107" width="58" height="13"/>
          <text>output [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="868" y="1116" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="742" y="1092" width="141" height="57"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169226070_130190_132990" xmi:uuid="bed1dfc0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169226065_197175_132988"/>
      <ownedElement xmi:id="bd290240-6c44-013d-931b-0800270c66d6" xmi:uuid="bd290310-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169226065_197175_132988"/>
        <text>cs1:ConcatString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169226070_259976_132991" xmi:uuid="bdbf9b20-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_206787_30431"/>
        <ownedElement xmi:id="bdbf3c70-6c44-013d-931b-0800270c66d6" xmi:uuid="bdbf3d30-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_206787_30431"/>
          <bounds x="697" y="842" width="42" height="13"/>
          <text>in1 [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="742" y="851" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169226070_463895_132993" xmi:uuid="be4bdfc0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_900635_30432"/>
        <ownedElement xmi:id="be4b7500-6c44-013d-931b-0800270c66d6" xmi:uuid="be4b75d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_900635_30432"/>
          <bounds x="824" y="900" width="42" height="13"/>
          <text>in2 [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="807" y="882" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1727169226070_655967_132995" xmi:uuid="bed1d410-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_690247_30433"/>
        <ownedElement xmi:id="beb438e0-6c44-013d-931b-0800270c66d6" xmi:uuid="beb43a90-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1532008913444_690247_30433"/>
          <bounds x="886" y="849" width="58" height="13"/>
          <text>output [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="868" y="858" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="742" y="840" width="141" height="57"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169357570_350743_133079" xmi:uuid="bed1e9e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169359312_240996_133080"/>
      <source xmi:idref="_18_4_1_65b021e_1727169226070_259976_132991"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925395_775438_127022"/>
      <waypoint x="742" y="858"/>
      <waypoint x="676" y="858"/>
      <waypoint x="676" y="823"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169368635_743946_133098" xmi:uuid="bed1f270-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169369916_307666_133099"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925394_363000_127004"/>
      <target xmi:idref="_18_4_1_65b021e_1727169226070_655967_132995"/>
      <waypoint x="994" y="865"/>
      <waypoint x="883" y="865"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169373554_519909_133120" xmi:uuid="bed20640-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169375598_507770_133121"/>
      <source xmi:idref="_18_4_1_65b021e_1727169226070_463895_132993"/>
      <target xmi:idref="_18_4_1_65b021e_1727169153948_757743_132018"/>
      <waypoint x="816" y="897"/>
      <waypoint x="816" y="924"/>
      <waypoint x="952" y="924"/>
      <waypoint x="952" y="742"/>
      <waypoint x="1138" y="742"/>
      <waypoint x="1138" y="375"/>
      <waypoint x="1064" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169524641_400696_133168" xmi:uuid="bed20f60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169526408_106642_133169"/>
      <source xmi:idref="_18_4_1_65b021e_1727169224936_908958_132933"/>
      <target xmi:idref="_18_4_1_65b021e_1727167925395_664821_127023"/>
      <waypoint x="742" y="1127"/>
      <waypoint x="683" y="1127"/>
      <waypoint x="683" y="1162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169543359_130053_133191" xmi:uuid="bed21800-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169545696_879494_133192"/>
      <source xmi:idref="_18_4_1_65b021e_1727169224936_324493_132935"/>
      <target xmi:idref="_18_4_1_65b021e_1727169153948_757743_132018"/>
      <waypoint x="809" y="1092"/>
      <waypoint x="809" y="1022"/>
      <waypoint x="952" y="1022"/>
      <waypoint x="952" y="742"/>
      <waypoint x="1138" y="742"/>
      <waypoint x="1138" y="375"/>
      <waypoint x="1064" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727169577098_492640_133215" xmi:uuid="bed22120-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727169578238_137603_133216"/>
      <source xmi:idref="_18_4_1_65b021e_1727167925395_813025_127008"/>
      <target xmi:idref="_18_4_1_65b021e_1727169224936_916665_132937"/>
      <waypoint x="994" y="1124"/>
      <waypoint x="883" y="1124"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1550" height="1205"/>
    <name>DeltaChangeRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446236399_906825_208708" xmi:uuid="bed2ae80-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167458204_442443_126382"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236424_406856_208740" xmi:uuid="bf63c790-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459483_649513_126476"/>
      <ownedElement xmi:id="bf390dd0-6c44-013d-931b-0800270c66d6" xmi:uuid="bf390ec0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459483_649513_126476"/>
        <text>delta_change_relationship:Activity_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="bf63b240-6c44-013d-931b-0800270c66d6" xmi:uuid="bf63b330-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727167459483_649513_126476"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="289" height="370"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236514_452407_208775" xmi:uuid="bf7b1a50-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="727" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236591_383222_208791" xmi:uuid="bf7b8240-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="727" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236671_271001_208807" xmi:uuid="bf7be340-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="727" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236746_528455_208823" xmi:uuid="bf7c3910-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="727" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236826_804707_208839" xmi:uuid="bf7c8ec0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="727" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236902_697607_208855" xmi:uuid="bf93efe0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="727" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446236980_673066_208871" xmi:uuid="bf944e00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="727" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446237059_691440_208887" xmi:uuid="bf94a4e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="727" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446237138_40924_208903" xmi:uuid="bfa5f790-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="727" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446237219_877996_208919" xmi:uuid="bfa679a0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="727" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446237299_974880_208935" xmi:uuid="bfa6ef20-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="727" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446237387_174044_208951" xmi:uuid="bfb9d450-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="727" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446237464_49732_208967" xmi:uuid="bfbabe00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="727" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446237545_276522_208983" xmi:uuid="bfcf5010-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="727" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446237626_204920_208999" xmi:uuid="bfcfbce0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="727" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446237701_143982_209015" xmi:uuid="bfd02760-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="727" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_198230_390056" xmi:uuid="bfd039e0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446236424_369160_208771"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236514_452407_208775"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="62"/>
      <waypoint x="334" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_652133_390059" xmi:uuid="bfd04200-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446236515_922973_208787"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236591_383222_208791"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="82"/>
      <waypoint x="334" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_820606_390062" xmi:uuid="bfd04c10-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446236592_299174_208803"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236671_271001_208807"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="102"/>
      <waypoint x="334" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_857965_390065" xmi:uuid="bfd054d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446236672_897145_208819"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236746_528455_208823"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="122"/>
      <waypoint x="334" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_729869_390068" xmi:uuid="bfd05e70-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446236747_726489_208835"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236826_804707_208839"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="142"/>
      <waypoint x="334" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_741556_390071" xmi:uuid="bfd06710-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446236827_333198_208851"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236902_697607_208855"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="162"/>
      <waypoint x="334" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_690068_390074" xmi:uuid="bfd06fb0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446236902_307868_208867"/>
      <source xmi:idref="_18_4_1_65b021e_1727446236980_673066_208871"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="182"/>
      <waypoint x="334" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_118160_390077" xmi:uuid="bfd07800-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446236981_875938_208883"/>
      <source xmi:idref="_18_4_1_65b021e_1727446237059_691440_208887"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="202"/>
      <waypoint x="334" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_168271_390080" xmi:uuid="bfe168b0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446237060_69963_208899"/>
      <source xmi:idref="_18_4_1_65b021e_1727446237138_40924_208903"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="222"/>
      <waypoint x="334" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_862470_390083" xmi:uuid="bfe179c0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446237139_983914_208915"/>
      <source xmi:idref="_18_4_1_65b021e_1727446237219_877996_208919"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="242"/>
      <waypoint x="334" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_348687_390086" xmi:uuid="bfe18290-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446237220_609515_208931"/>
      <source xmi:idref="_18_4_1_65b021e_1727446237299_974880_208935"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="262"/>
      <waypoint x="334" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_415362_390089" xmi:uuid="bfe18b60-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446237300_754608_208947"/>
      <source xmi:idref="_18_4_1_65b021e_1727446237387_174044_208951"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="282"/>
      <waypoint x="334" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_217423_390092" xmi:uuid="bfe1a2d0-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446237388_543548_208963"/>
      <source xmi:idref="_18_4_1_65b021e_1727446237464_49732_208967"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="302"/>
      <waypoint x="334" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_669550_390095" xmi:uuid="bfe1ae00-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446237465_999633_208979"/>
      <source xmi:idref="_18_4_1_65b021e_1727446237545_276522_208983"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="322"/>
      <waypoint x="334" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_694010_390098" xmi:uuid="bfe1b850-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446237546_209563_208995"/>
      <source xmi:idref="_18_4_1_65b021e_1727446237626_204920_208999"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="342"/>
      <waypoint x="334" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446487437_945532_390101" xmi:uuid="bfe1c600-6c44-013d-931b-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="DeltaChange.xmi#_18_4_1_65b021e_1727446237627_569928_209011"/>
      <source xmi:idref="_18_4_1_65b021e_1727446237701_143982_209015"/>
      <target xmi:idref="_18_4_1_65b021e_1727446236424_406856_208740"/>
      <waypoint x="727" y="362"/>
      <waypoint x="334" y="362"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="730" height="440"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
