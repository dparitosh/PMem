<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_8be0287_1622213806654_542895_69129" xmi:uuid="058b5720-b6f6-0139-1753-45cc4a55db9f">
    <base_UMLClassDiagram xmi:idref="_18_4_1_8be0287_1622213806635_867778_69118"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8e001ed_1498551955670_756141_14118"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703186307802_352468_477154" xmi:uuid="cc2290a0-915e-013c-7163-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703186307797_822404_477143"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8e001ed_1498551955670_756141_14118"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703186328703_968086_477825" xmi:uuid="cf82bfe0-915e-013c-7163-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703186328698_675707_477814"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8e001ed_1498551955670_756141_14118"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1623136672647_863743_78734" xmi:uuid="07f05030-b6f6-0139-1753-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1623136672629_545970_78723"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446410903_773908_347311" xmi:uuid="1c59d270-6c45-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446410894_200297_347300"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622535892317_254657_73801"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446411729_966342_348367" xmi:uuid="1f97c800-6c44-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446411722_178058_348356"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214343240_255641_69449"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1623158012155_980056_81240" xmi:uuid="2a4b0450-b6f6-0139-1753-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1623158012147_298117_81229"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446411139_421703_347584" xmi:uuid="3b711d10-6c43-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446411132_305752_347573"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1623362462033_485977_84322" xmi:uuid="3c4a4600-b6f6-0139-1753-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1623362462008_127798_84311"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446408921_415650_346465" xmi:uuid="6acf4900-6c44-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446408913_534255_346454"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622408324396_295926_72418"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1624958572227_563952_73174" xmi:uuid="725c9ab0-339c-013a-17e4-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1624958572207_103899_73163"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214164469_64413_69277"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446406562_765568_345543" xmi:uuid="7521ea70-6c44-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446406553_96571_345532"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622535729628_957239_73706"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446416104_282811_350314" xmi:uuid="76fa46d0-6c43-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446416097_962858_350303"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214164469_64413_69277"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1624274993663_42523_74657" xmi:uuid="8418dc70-339c-013a-17e4-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1624274993648_600552_74646"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214197111_257229_69320"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1624973239943_66298_74291" xmi:uuid="922e73b0-339c-013a-17e4-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1624973239928_614068_74280"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214296568_664807_69363"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1625029647094_604428_72171" xmi:uuid="928c1000-339c-013a-17e4-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1625029647094_845920_72160"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214318254_324090_69406"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1625031702158_494561_74687" xmi:uuid="9317fc30-339c-013a-17e4-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1625031702158_330389_74676"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214343240_255641_69449"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446413990_996369_349288" xmi:uuid="a15b3fb0-6c43-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446413982_358282_349277"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214197111_257229_69320"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446414281_544576_349666" xmi:uuid="a64afac0-6c43-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446414274_962550_349655"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214296568_664807_69363"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1624965282169_160718_71509" xmi:uuid="ab2dead0-339c-013a-17e4-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1624965282159_142612_71498"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622408324396_295926_72418"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446413486_836729_348640" xmi:uuid="ad157fd0-6c43-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446413477_821565_348629"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214318254_324090_69406"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446416329_942126_350587" xmi:uuid="af9f30f0-6c42-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446416321_452002_350576"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1625029442302_542494_72103" xmi:uuid="c20dd3e0-339c-013a-17e4-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1625029442286_772086_72092"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622535729628_957239_73706"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1625031444570_754814_74440" xmi:uuid="c2571620-339c-013a-17e4-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1625031444554_955324_74429"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622535849807_770291_73755"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_8be0287_1625031791627_644356_74934" xmi:uuid="d6fa9460-339c-013a-17e4-45cc4a55db9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_8be0287_1625031791611_384005_74923"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622535892317_254657_73801"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446408699_713041_346192" xmi:uuid="df470c50-6c44-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446408692_311479_346181"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622535849807_770291_73755"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446409081_782844_346663" xmi:uuid="e8d22ad0-6c42-013d-d60e-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446409074_554637_346652"/>
    <defaultNamespace href="Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_8be0287_1622213806635_867778_69118" xmi:uuid="058af5a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8e001ed_1498551955670_756141_14118"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1622213824933_34420_69150" xmi:uuid="060b8be0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
      <ownedElement xmi:id="059673e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="05967630-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
        <text>Slot</text>
      </ownedElement>
      <ownedElement xmi:id="059a3360-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="059a3520-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="05f75b10-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="05f75ca0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="05f763f0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="05f76980-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="05faf110-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="05faf800-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622570782448_528292_75095"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="05fe5cb0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="05fe5e40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574464803_512866_75103"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="06034f70-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06035180-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574553086_104308_75111"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="06075a30-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06075c20-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574625794_544014_75119"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="060b6fb0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="060b7160-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574703456_391374_75127"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="35" y="77" width="179" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214122721_628341_69193" xmi:uuid="068201b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
      <ownedElement xmi:id="060f8d60-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="060f8f00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
        <text>SlotVersion</text>
      </ownedElement>
      <ownedElement xmi:id="061261a0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06126330-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="066760b0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="066761e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="06676910-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06676990-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="066bbdd0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="066bbf10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574783299_326518_75135"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="066ef680-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="066ef840-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574857327_282905_75143"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="0672d510-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0672d840-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574921548_858078_75151"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="06780010-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="067801d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574990873_700250_75159"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="189" y="245" width="179" height="120"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214143557_844703_69236" xmi:uuid="06d10c30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
      <ownedElement xmi:id="0687b290-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0687b900-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
        <text>SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="068c32a0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="068c3640-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="06b1c660-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06b1c8a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="06b219e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06b22370-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="06b56610-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06b567b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581045292_50007_75168"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="06b8c4e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06b8c660-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581189433_540148_75184"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="06bc8990-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06bc8b10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581244102_258898_75192"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="34d20ba0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="34d20d70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623769559714_915577_73626"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="34d82c20-339c-013a-17e4-45cc4a55db9f" xmi:uuid="34d82d30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623876683153_525139_73824"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="06c55820-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06c55a50-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="06c56720-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06c56810-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="06c98b00-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06c98d70-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618063083_498516_76663"/>
          <text>InitialContext</text>
        </ownedElement>
        <ownedElement xmi:id="06ccfe00-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06cd0020-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618167454_602622_76668"/>
          <text>AdditionalContexts</text>
        </ownedElement>
        <ownedElement xmi:id="06d0f370-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06d0f540-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618235533_875990_76673"/>
          <text>DefiningGeometry</text>
        </ownedElement>
      </ownedElement>
      <bounds x="511" y="259" width="211" height="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214177727_272289_69279" xmi:uuid="06dea530-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214164469_64413_69277"/>
      <ownedElement xmi:id="06d54a80-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06d550c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214164469_64413_69277"/>
        <text>SlotOn</text>
      </ownedElement>
      <ownedElement xmi:id="06d88f20-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06d890e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="f20a5320-6c41-013d-d60e-0800270c66d6" xmi:uuid="f20a53d0-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f229f740-6c41-013d-d60e-0800270c66d6" xmi:uuid="f229f800-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="f2735ac0-6c41-013d-d60e-0800270c66d6" xmi:uuid="f2735b90-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1624958915414_865462_74085"/>
          <text>defaultId</text>
        </ownedElement>
        <ownedElement xmi:id="f275fc40-6c41-013d-d60e-0800270c66d6" xmi:uuid="f275fd00-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668261_721687_70831"/>
          <text>nameSelect</text>
        </ownedElement>
        <ownedElement xmi:id="f2e72d00-6c41-013d-d60e-0800270c66d6" xmi:uuid="f2e72dd0-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_411759_70835"/>
          <text>defaultName</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="35513e40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="35513fe0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="35535f50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="35536110-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="355a6ab0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="355a6c90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964438438_221877_70789"/>
          <text>Name</text>
        </ownedElement>
      </ownedElement>
      <bounds x="539" y="119" width="153" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214211851_530403_69322" xmi:uuid="06ed9e50-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214197111_257229_69320"/>
      <ownedElement xmi:id="06e245f0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06e247b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214197111_257229_69320"/>
        <text>SlotDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="06e5aa50-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06e5aca0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="f4de3210-6c41-013d-d60e-0800270c66d6" xmi:uuid="f4de32a0-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f4fd0a20-6c41-013d-d60e-0800270c66d6" xmi:uuid="f4fd0ae0-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="f5367a10-6c41-013d-d60e-0800270c66d6" xmi:uuid="f5367ab0-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_65b021e_1648719846490_409939_68021"/>
          <text>WR1</text>
        </ownedElement>
      </ownedElement>
      <bounds x="819" y="301" width="148" height="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214308090_502541_69365" xmi:uuid="06f52b60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214296568_664807_69363"/>
      <ownedElement xmi:id="06f152a0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06f15680-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214296568_664807_69363"/>
        <text>SlotDesign</text>
      </ownedElement>
      <ownedElement xmi:id="06f42630-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06f43910-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="63" y="413" width="98" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214327254_751759_69408" xmi:uuid="06fcaa50-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214318254_324090_69406"/>
      <ownedElement xmi:id="06f86670-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06f86800-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214318254_324090_69406"/>
        <text>SlotAsRealized</text>
      </ownedElement>
      <ownedElement xmi:id="06fbab50-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="06fbb350-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="385" y="413" width="98" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214359397_643078_69451" xmi:uuid="0709b240-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214343240_255641_69449"/>
      <ownedElement xmi:id="070092c0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0700a250-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214343240_255641_69449"/>
        <text>SlotDesignToRealized</text>
      </ownedElement>
      <ownedElement xmi:id="0703b150-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0703b310-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="f8cc1df0-6c41-013d-d60e-0800270c66d6" xmi:uuid="f8cc1e80-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f8e8ebb0-6c41-013d-d60e-0800270c66d6" xmi:uuid="f8e8ec70-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="f90fad80-6c41-013d-d60e-0800270c66d6" xmi:uuid="f90fae30-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556448_221717_78766"/>
          <text>nameSelect</text>
        </ownedElement>
        <ownedElement xmi:id="f949e0a0-6c41-013d-d60e-0800270c66d6" xmi:uuid="f949e170-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556449_907262_78767"/>
          <text>defaultName</text>
        </ownedElement>
        <ownedElement xmi:id="f98989a0-6c41-013d-d60e-0800270c66d6" xmi:uuid="f9898a60-6c41-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388120770_305619_75896"/>
          <text>defaultId</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="364741f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="364742e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3647fe20-339c-013a-17e4-45cc4a55db9f" xmi:uuid="3647ff00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="364d97d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="364d98f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625056056171_760868_80239"/>
          <text>Name</text>
        </ownedElement>
      </ownedElement>
      <bounds x="217" y="630" width="153" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214384202_98043_69493" xmi:uuid="071143b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214386657_700108_69494"/>
      <source xmi:idref="_18_4_1_8be0287_1622214308090_502541_69365"/>
      <target xmi:idref="_18_4_1_8be0287_1622214122721_628341_69193"/>
      <waypoint x="102" y="413"/>
      <waypoint x="102" y="399"/>
      <waypoint x="277" y="399"/>
      <waypoint x="277" y="365"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214423214_657104_69496" xmi:uuid="071b69f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214424261_87144_69497"/>
      <source xmi:idref="_18_4_1_8be0287_1622214327254_751759_69408"/>
      <target xmi:idref="_18_4_1_8be0287_1622214122721_628341_69193"/>
      <waypoint x="429" y="413"/>
      <waypoint x="429" y="399"/>
      <waypoint x="277" y="399"/>
      <waypoint x="277" y="365"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214441497_928299_69501" xmi:uuid="0724b200-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214442353_986997_69502"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622214442422_423558_69514" xmi:uuid="0723bbd0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214442353_602339_69503"/>
        <bounds x="43" y="465" width="35" height="13"/>
        <text>Design</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637095713641_606518_66079" xmi:uuid="366b9dd0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214442353_602339_69503"/>
        <bounds x="84" y="465" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640686338423_373761_67729" xmi:uuid="2931e0d0-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214442354_357655_69504"/>
        <bounds x="178" y="672" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622214359397_643078_69451"/>
      <target xmi:idref="_18_4_1_8be0287_1622214308090_502541_69365"/>
      <waypoint x="217" y="669"/>
      <waypoint x="81" y="669"/>
      <waypoint x="81" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214468146_914090_69533" xmi:uuid="072cf590-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214469214_371361_69534"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622214469258_192566_69544" xmi:uuid="072cbc10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214469214_445686_69535"/>
        <bounds x="420" y="465" width="43" height="13"/>
        <text>Realized</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637095728908_921191_66085" xmi:uuid="3677b050-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214469214_445686_69535"/>
        <bounds x="469" y="465" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640686324856_394807_67723" xmi:uuid="293a05d0-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214469214_819711_69536"/>
        <bounds x="385" y="672" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622214359397_643078_69451"/>
      <target xmi:idref="_18_4_1_8be0287_1622214327254_751759_69408"/>
      <waypoint x="370" y="669"/>
      <waypoint x="466" y="669"/>
      <waypoint x="466" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214496482_950370_69565" xmi:uuid="073afd40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214497664_248524_69566"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622214497727_902335_69576" xmi:uuid="073a9870-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214497665_843170_69567"/>
        <bounds x="254" y="229" width="44" height="13"/>
        <text>Versions</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637084697983_591114_66014" xmi:uuid="3683e150-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214497665_843170_69567"/>
        <bounds x="304" y="229" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1637853714125_965881_65951" xmi:uuid="36854a90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214497665_883888_69568"/>
        <bounds x="229" y="121" width="50" height="13"/>
        <text>VersionOf</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1637853715729_360208_65957" xmi:uuid="368647a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214497665_883888_69568"/>
        <bounds x="229" y="140" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622213824933_34420_69150"/>
      <target xmi:idref="_18_4_1_8be0287_1622214122721_628341_69193"/>
      <waypoint x="214" y="137"/>
      <waypoint x="301" y="137"/>
      <waypoint x="301" y="245"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214521606_405054_69597" xmi:uuid="07468700-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214522749_272582_69598"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622214522800_774617_69608" xmi:uuid="07466460-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214522749_245490_69599"/>
        <bounds x="457" y="282" width="51" height="13"/>
        <text>Definitions</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637096220661_318296_66121" xmi:uuid="36a50d60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214522749_245490_69599"/>
        <bounds x="484" y="301" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1637853932392_752808_65961" xmi:uuid="36a67670-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214522749_322425_69600"/>
        <bounds x="383" y="282" width="57" height="13"/>
        <text>DefinitionOf</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1637853934330_521574_65967" xmi:uuid="36a7e2c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214522749_322425_69600"/>
        <bounds x="383" y="301" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622214143557_844703_69236"/>
      <target xmi:idref="_18_4_1_8be0287_1622214122721_628341_69193"/>
      <waypoint x="511" y="298"/>
      <waypoint x="368" y="298"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214552669_27009_69629" xmi:uuid="07507350-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214554246_602750_69630"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622214554305_675746_69642" xmi:uuid="07504d70-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214554246_243156_69631"/>
        <bounds x="588" y="230" width="24" height="13"/>
        <text>Slot</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637095986988_516316_66099" xmi:uuid="36b3ee20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214554246_243156_69631"/>
        <bounds x="616" y="231" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1637855209037_873762_66431" xmi:uuid="36b52840-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214554247_636233_69632"/>
        <bounds x="616" y="203" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622214177727_272289_69279"/>
      <target xmi:idref="_18_4_1_8be0287_1622214143557_844703_69236"/>
      <waypoint x="613" y="200"/>
      <waypoint x="613" y="259"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214608882_427527_69661" xmi:uuid="07629780-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214610219_941960_69662"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622214610255_539368_69672" xmi:uuid="07626980-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214610219_92164_69663"/>
        <bounds x="737" y="299" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637095111665_562494_66063" xmi:uuid="36c26390-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214610219_92164_69663"/>
        <bounds x="737" y="318" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640686294361_899755_67711" xmi:uuid="295ee080-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214610220_368457_69664"/>
        <bounds x="792" y="318" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622214211851_530403_69322"/>
      <target xmi:idref="_18_4_1_8be0287_1622214143557_844703_69236"/>
      <waypoint x="819" y="315"/>
      <waypoint x="722" y="315"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622214701592_868427_69711" xmi:uuid="076d7ac0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214702594_365919_69712"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622214702648_472841_69724" xmi:uuid="076d4960-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214702594_116340_69713"/>
        <bounds x="725" y="334" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637095117923_479382_66069" xmi:uuid="36ce8f70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214702594_116340_69713"/>
        <bounds x="725" y="353" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640686310046_360184_67717" xmi:uuid="296724d0-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214702594_417477_69714"/>
        <bounds x="792" y="353" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622214211851_530403_69322"/>
      <target xmi:idref="_18_4_1_8be0287_1622214143557_844703_69236"/>
      <waypoint x="819" y="350"/>
      <waypoint x="722" y="350"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622215247604_643432_72340" xmi:uuid="0775f650-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215122607_133306_72338"/>
      <ownedElement xmi:id="07729c70-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="07729dd0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215122607_133306_72338"/>
        <text>SlotOnSelect</text>
      </ownedElement>
      <ownedElement xmi:id="077518d0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="07751a80-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="07752500-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="077525c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="546" y="35" width="133" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622215334721_100268_72384" xmi:uuid="077c9000-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215336166_6987_72385"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622215336226_896367_72395" xmi:uuid="077c20e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215336167_924885_72386"/>
        <bounds x="576" y="86" width="34" height="13"/>
        <text>SlotOn</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637095900526_861230_66091" xmi:uuid="36ea9c70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215336167_924885_72386"/>
        <bounds x="616" y="86" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1637854797875_878048_66415" xmi:uuid="36ebdd30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215336167_656323_72387"/>
        <bounds x="616" y="103" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622214177727_272289_69279"/>
      <target xmi:idref="_18_4_1_8be0287_1622215247604_643432_72340"/>
      <waypoint x="613" y="119"/>
      <waypoint x="613" y="83"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622408324429_285713_72420" xmi:uuid="078874c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408324396_295926_72418"/>
      <ownedElement xmi:id="077ef790-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="078071d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408324396_295926_72418"/>
        <text>ItemInSlot</text>
      </ownedElement>
      <ownedElement xmi:id="07827da0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="07827f30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="3748b080-339c-013a-17e4-45cc4a55db9f" xmi:uuid="3748b1a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3749c050-339c-013a-17e4-45cc4a55db9f" xmi:uuid="3749c180-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="374f9a70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="374f9b90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1624968095913_108930_71195"/>
          <text>Name</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="2af18640-3ed5-013c-a15b-4b23c1d46efd" xmi:uuid="2af18770-3ed5-013c-a15b-4b23c1d46efd" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2af2b910-3ed5-013c-a15b-4b23c1d46efd" xmi:uuid="2af2ba20-3ed5-013c-a15b-4b23c1d46efd" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="2af591e0-3ed5-013c-a15b-4b23c1d46efd" xmi:uuid="2af59390-3ed5-013c-a15b-4b23c1d46efd" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1624968182021_491228_71207"/>
          <text>AssociationType</text>
        </ownedElement>
      </ownedElement>
      <bounds x="532" y="511" width="182" height="115"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622408404579_853837_72464" xmi:uuid="07903380-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408405867_194004_72465"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622408405929_642394_72475" xmi:uuid="078febf0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408405867_75040_72466"/>
        <bounds x="593" y="467" width="24" height="13"/>
        <text>Slot</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637084938102_816285_66027" xmi:uuid="37623850-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408405867_75040_72466"/>
        <bounds x="623" y="467" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1637855153322_929524_66423" xmi:uuid="3763c370-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408405868_645908_72467"/>
        <bounds x="623" y="495" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622408324429_285713_72420"/>
      <target xmi:idref="_18_4_1_8be0287_1622214143557_844703_69236"/>
      <waypoint x="620" y="511"/>
      <waypoint x="620" y="452"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622408423574_644665_72498" xmi:uuid="079dcde0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408423549_729009_72496"/>
      <ownedElement xmi:id="0795e9d0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0795eb60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408423549_729009_72496"/>
        <text>ItemInSlotSelect</text>
      </ownedElement>
      <ownedElement xmi:id="079cfd70-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="079cff40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="079d11e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="079d1300-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="567" y="665" width="121" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622408700282_197382_72546" xmi:uuid="07a55c00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408700899_701911_72547"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622408700948_313161_72557" xmi:uuid="07a53ca0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408700900_492970_72548"/>
        <bounds x="600" y="649" width="24" height="13"/>
        <text>Item</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637084932286_325335_66021" xmi:uuid="378cbc50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408700900_492970_72548"/>
        <bounds x="630" y="649" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1637854734456_884464_66405" xmi:uuid="378e1b90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408700900_998500_72549"/>
        <bounds x="630" y="629" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622408324429_285713_72420"/>
      <target xmi:idref="_18_4_1_8be0287_1622408423574_644665_72498"/>
      <waypoint x="627" y="626"/>
      <waypoint x="627" y="665"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622535729672_681968_73708" xmi:uuid="07aa5e40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535729628_957239_73706"/>
      <ownedElement xmi:id="07a7eb10-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="07a7ec10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535729628_957239_73706"/>
        <text>SlotAsPlanned</text>
      </ownedElement>
      <ownedElement xmi:id="07a9dc20-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="07a9ded0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="217" y="413" width="98" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622535763261_940273_73750" xmi:uuid="07af1480-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535764277_47346_73751"/>
      <source xmi:idref="_18_4_1_8be0287_1622535729672_681968_73708"/>
      <target xmi:idref="_18_4_1_8be0287_1622214122721_628341_69193"/>
      <waypoint x="260" y="413"/>
      <waypoint x="260" y="399"/>
      <waypoint x="277" y="399"/>
      <waypoint x="277" y="365"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622535849838_906921_73757" xmi:uuid="07bc80f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535849807_770291_73755"/>
      <ownedElement xmi:id="07b20150-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="07b203a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535849807_770291_73755"/>
        <text>SlotDesignToPlanned</text>
      </ownedElement>
      <ownedElement xmi:id="07b47950-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="07b47eb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="0983a620-6c42-013d-d60e-0800270c66d6" xmi:uuid="0983a6b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="099be260-6c42-013d-d60e-0800270c66d6" xmi:uuid="099be330-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="09b25220-6c42-013d-d60e-0800270c66d6" xmi:uuid="09b252f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682470_774784_71474"/>
          <text>nameSelect</text>
        </ownedElement>
        <ownedElement xmi:id="09e91d80-6c42-013d-d60e-0800270c66d6" xmi:uuid="09e91e20-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_622838_71478"/>
          <text>defaultName</text>
        </ownedElement>
        <ownedElement xmi:id="0a1fd5d0-6c42-013d-d60e-0800270c66d6" xmi:uuid="0a1fd6a0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625052261857_397121_76183"/>
          <text>defaultId</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="388dd2e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="388dd4b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="388f0240-339c-013a-17e4-45cc4a55db9f" xmi:uuid="388f0370-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="3895b320-339c-013a-17e4-45cc4a55db9f" xmi:uuid="3895b4d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035828054_203883_71820"/>
          <text>Name</text>
        </ownedElement>
      </ownedElement>
      <bounds x="112" y="525" width="153" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622535892352_413938_73803" xmi:uuid="07cc8920-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535892317_254657_73801"/>
      <ownedElement xmi:id="07c101c0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="07c103d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535892317_254657_73801"/>
        <text>SlotPlannedToRealized</text>
      </ownedElement>
      <ownedElement xmi:id="07c4dfa0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="07c4e180-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="0c660b20-6c42-013d-d60e-0800270c66d6" xmi:uuid="0c660bc0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0c6752f0-6c42-013d-d60e-0800270c66d6" xmi:uuid="0c6753c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="0ccfe1a0-6c42-013d-d60e-0800270c66d6" xmi:uuid="0ccfe250-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625335_577986_79375"/>
          <text>nameSelect</text>
        </ownedElement>
        <ownedElement xmi:id="0d0fff70-6c42-013d-d60e-0800270c66d6" xmi:uuid="0d100030-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625336_413972_79376"/>
          <text>defaultName</text>
        </ownedElement>
        <ownedElement xmi:id="0d127f10-6c42-013d-d60e-0800270c66d6" xmi:uuid="0d127fd0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388460828_195141_76720"/>
          <text>defaultId</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="39273930-339c-013a-17e4-45cc4a55db9f" xmi:uuid="39273a40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="39284790-339c-013a-17e4-45cc4a55db9f" xmi:uuid="392848c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="392f6dd0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="392f6f50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055771214_408819_80209"/>
          <text>Name</text>
        </ownedElement>
      </ownedElement>
      <bounds x="280" y="525" width="153" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622535961409_134676_73847" xmi:uuid="07d3fb30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535962294_214832_73848"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622535962369_813394_73860" xmi:uuid="07d37ca0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535962294_864637_73849"/>
        <bounds x="99" y="465" width="35" height="13"/>
        <text>Design</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637077149100_272665_65470" xmi:uuid="393d0800-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535962294_864637_73849"/>
        <bounds x="140" y="465" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640686352531_826893_67735" xmi:uuid="2a2baca0-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535962295_354986_73850"/>
        <bounds x="140" y="497" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622535849838_906921_73757"/>
      <target xmi:idref="_18_4_1_8be0287_1622214308090_502541_69365"/>
      <waypoint x="137" y="525"/>
      <waypoint x="137" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622535980373_845473_73879" xmi:uuid="07dc48b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535981151_193600_73880"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622535981173_632580_73890" xmi:uuid="07dc15f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535981151_929673_73881"/>
        <bounds x="188" y="465" width="40" height="13"/>
        <text>Planned</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637077462609_648508_65531" xmi:uuid="39491c30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535981151_929673_73881"/>
        <bounds x="234" y="465" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640686364238_271640_67741" xmi:uuid="2a333a90-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535981151_40730_73882"/>
        <bounds x="238" y="503" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622535849838_906921_73757"/>
      <target xmi:idref="_18_4_1_8be0287_1622535729672_681968_73708"/>
      <waypoint x="231" y="525"/>
      <waypoint x="231" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622535994974_168821_73911" xmi:uuid="07e3f780-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535995861_343580_73912"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622535995930_399888_73922" xmi:uuid="07e3d6f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535995861_391383_73913"/>
        <bounds x="255" y="465" width="40" height="13"/>
        <text>Planned</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637096178334_804289_66109" xmi:uuid="3955d180-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535995861_391383_73913"/>
        <bounds x="301" y="465" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640686378351_908151_67747" xmi:uuid="2a3b9030-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535995861_288907_73914"/>
        <bounds x="308" y="503" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622535892352_413938_73803"/>
      <target xmi:idref="_18_4_1_8be0287_1622535729672_681968_73708"/>
      <waypoint x="298" y="525"/>
      <waypoint x="298" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1622536016963_418980_73943" xmi:uuid="07ee1b30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622536017869_819066_73944"/>
      <ownedElement xmi:id="_18_4_1_8be0287_1622536017896_633594_73954" xmi:uuid="07ede4b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622536017869_250974_73945"/>
        <bounds x="357" y="465" width="43" height="13"/>
        <text>Realized</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637096186489_351140_66115" xmi:uuid="3963f6b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622536017869_250974_73945"/>
        <bounds x="406" y="465" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640686390001_177766_67753" xmi:uuid="2a4394d0-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622536017870_859791_73946"/>
        <bounds x="406" y="503" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_8be0287_1622535892352_413938_73803"/>
      <target xmi:idref="_18_4_1_8be0287_1622214327254_751759_69408"/>
      <waypoint x="403" y="525"/>
      <waypoint x="403" y="462"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="982" height="728"/>
    <name>Slot</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703186307797_822404_477143" xmi:uuid="cc20d780-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8e001ed_1498551955670_756141_14118"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186307855_513706_477176" xmi:uuid="cc2dcb30-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408423549_729009_72496"/>
      <ownedElement xmi:id="cc272470-915e-013c-7163-0a5172f4a469" xmi:uuid="cc2726b0-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408423549_729009_72496"/>
        <text>ItemInSlotSelect</text>
      </ownedElement>
      <ownedElement xmi:id="cc2a5620-915e-013c-7163-0a5172f4a469" xmi:uuid="cc2a5750-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="cc2bc0f0-915e-013c-7163-0a5172f4a469" xmi:uuid="cc2bc310-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1065" height="205"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186310514_974012_477243" xmi:uuid="cca10340-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
      <ownedElement xmi:id="cc393930-915e-013c-7163-0a5172f4a469" xmi:uuid="cc393a70-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
        <text>BreakdownElementView</text>
      </ownedElement>
      <ownedElement xmi:id="14e65a90-6c42-013d-d60e-0800270c66d6" xmi:uuid="14e65b50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="19823000-6c42-013d-d60e-0800270c66d6" xmi:uuid="198230a0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="19977080-6c42-013d-d60e-0800270c66d6" xmi:uuid="19977150-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="19cb9bb0-6c42-013d-d60e-0800270c66d6" xmi:uuid="19cb9c80-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551700281091_86980_44146"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="1a10a320-6c42-013d-d60e-0800270c66d6" xmi:uuid="1a10a3e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551702070586_339964_46336"/>
          <text>selectId</text>
        </ownedElement>
        <ownedElement xmi:id="1a2de7d0-6c42-013d-d60e-0800270c66d6" xmi:uuid="1a2de890-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551702138524_57824_46412"/>
          <text>defaultId</text>
        </ownedElement>
        <ownedElement xmi:id="1a979560-6c42-013d-d60e-0800270c66d6" xmi:uuid="1a979620-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560928666630_463684_40059"/>
          <text>selectName</text>
        </ownedElement>
      </ownedElement>
      <bounds x="65" y="95" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186312548_406756_477301" xmi:uuid="ccd6b920-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
      <ownedElement xmi:id="cca838e0-915e-013c-7163-0a5172f4a469" xmi:uuid="cca83a50-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
        <text>CollectionView</text>
      </ownedElement>
      <ownedElement xmi:id="1b7d9930-6c42-013d-d60e-0800270c66d6" xmi:uuid="1b7d99d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="1cea5b70-6c42-013d-d60e-0800270c66d6" xmi:uuid="1cea5c00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="1d0be210-6c42-013d-d60e-0800270c66d6" xmi:uuid="1d0be2d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="1d39d4a0-6c42-013d-d60e-0800270c66d6" xmi:uuid="1d39d5a0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581949370578_83871_59163"/>
          <text>WR1</text>
        </ownedElement>
        <ownedElement xmi:id="1d6ce830-6c42-013d-d60e-0800270c66d6" xmi:uuid="1d6ce8f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582013836566_959587_64408"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="1d8acc00-6c42-013d-d60e-0800270c66d6" xmi:uuid="1d8accc0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582013836581_373776_64418"/>
          <text>selectId</text>
        </ownedElement>
      </ownedElement>
      <bounds x="298" y="95" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186314791_561308_477364" xmi:uuid="cd20a840-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
      <ownedElement xmi:id="ccdf00f0-915e-013c-7163-0a5172f4a469" xmi:uuid="ccdf0230-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
        <text>DocumentDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="1f6cb0d0-6c42-013d-d60e-0800270c66d6" xmi:uuid="1f6cb160-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="21d33790-6c42-013d-d60e-0800270c66d6" xmi:uuid="21d33830-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2211f090-6c42-013d-d60e-0800270c66d6" xmi:uuid="2211f160-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="2214f8f0-6c42-013d-d60e-0800270c66d6" xmi:uuid="2214f9c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525438538822_1962_32169"/>
          <text>selectId</text>
        </ownedElement>
        <ownedElement xmi:id="2274e9e0-6c42-013d-d60e-0800270c66d6" xmi:uuid="2274eab0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525438612815_90414_32370"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="22ad9650-6c42-013d-d60e-0800270c66d6" xmi:uuid="22ad96f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525793775173_726362_32403"/>
          <text>selectName</text>
        </ownedElement>
      </ownedElement>
      <bounds x="523" y="95" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186314933_715014_477406" xmi:uuid="cd6d3640-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517522314447_931284_35547"/>
      <ownedElement xmi:id="cd48c930-915e-013c-7163-0a5172f4a469" xmi:uuid="cd48ca70-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517522314447_931284_35547"/>
        <text>EnvironmentDefinitionView</text>
      </ownedElement>
      <ownedElement xmi:id="28d037d0-6c42-013d-d60e-0800270c66d6" xmi:uuid="28d03870-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="814" y="95" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186317181_833959_477467" xmi:uuid="cdad24e0-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="cd75a6c0-915e-013c-7163-0a5172f4a469" xmi:uuid="cd75a7f0-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="2b905bc0-6c42-013d-d60e-0800270c66d6" xmi:uuid="2b905c50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="2df782a0-6c42-013d-d60e-0800270c66d6" xmi:uuid="2df78360-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2df91180-6c42-013d-d60e-0800270c66d6" xmi:uuid="2df91250-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="2e4b2b20-6c42-013d-d60e-0800270c66d6" xmi:uuid="2e4b2be0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578046625087_447455_57832"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="2e8a0950-6c42-013d-d60e-0800270c66d6" xmi:uuid="2e8a0a10-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578046625090_832197_57835"/>
          <text>selectId</text>
        </ownedElement>
      </ownedElement>
      <bounds x="65" y="145" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186319239_745279_477526" xmi:uuid="ce042040-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
      <ownedElement xmi:id="cdb8bf10-915e-013c-7163-0a5172f4a469" xmi:uuid="cdb8c050-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
        <text>InterfaceConnectorView</text>
      </ownedElement>
      <ownedElement xmi:id="306c7ea0-6c42-013d-d60e-0800270c66d6" xmi:uuid="306c7f50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="337eb4b0-6c42-013d-d60e-0800270c66d6" xmi:uuid="337eb540-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="337ffca0-6c42-013d-d60e-0800270c66d6" xmi:uuid="337ffd60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="33b57f10-6c42-013d-d60e-0800270c66d6" xmi:uuid="33b57fc0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577977960818_245454_66221"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="3424dc30-6c42-013d-d60e-0800270c66d6" xmi:uuid="3424ddc0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577977960823_118745_66224"/>
          <text>selectId</text>
        </ownedElement>
      </ownedElement>
      <bounds x="308" y="145" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186321279_829283_477584" xmi:uuid="ce5186e0-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
      <ownedElement xmi:id="ce08adc0-915e-013c-7163-0a5172f4a469" xmi:uuid="ce08aef0-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
        <text>InterfaceSpecificationView</text>
      </ownedElement>
      <ownedElement xmi:id="34b33860-6c42-013d-d60e-0800270c66d6" xmi:uuid="34b338f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="376ff030-6c42-013d-d60e-0800270c66d6" xmi:uuid="376ff0d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="37712ea0-6c42-013d-d60e-0800270c66d6" xmi:uuid="37712f60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="37d61a80-6c42-013d-d60e-0800270c66d6" xmi:uuid="37d61b50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577980925745_226334_72328"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="381bc1c0-6c42-013d-d60e-0800270c66d6" xmi:uuid="381bc290-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577980925751_481193_72331"/>
          <text>selectId</text>
        </ownedElement>
      </ownedElement>
      <bounds x="529" y="145" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186323573_258597_477644" xmi:uuid="ceea6d40-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="ce62ca10-915e-013c-7163-0a5172f4a469" xmi:uuid="ce62cb50-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="3aae55b0-6c42-013d-d60e-0800270c66d6" xmi:uuid="3aae5650-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="40cb4890-6c42-013d-d60e-0800270c66d6" xmi:uuid="40cb4920-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="40eb9960-6c42-013d-d60e-0800270c66d6" xmi:uuid="40eb9a20-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="414570f0-6c42-013d-d60e-0800270c66d6" xmi:uuid="414571b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_271a0567_1575306574233_773766_47039"/>
          <text>WR1</text>
        </ownedElement>
        <ownedElement xmi:id="4191b250-6c42-013d-d60e-0800270c66d6" xmi:uuid="4191b320-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516290628652_484547_38739"/>
          <text>initialConvert</text>
        </ownedElement>
        <ownedElement xmi:id="41dacba0-6c42-013d-d60e-0800270c66d6" xmi:uuid="41dacc60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1568988378234_935366_63819"/>
          <text>additionalConvert</text>
        </ownedElement>
        <ownedElement xmi:id="42211200-6c42-013d-d60e-0800270c66d6" xmi:uuid="422112c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569312933527_515827_42519"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="42704b00-6c42-013d-d60e-0800270c66d6" xmi:uuid="42704bb0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569313322159_654490_44586"/>
          <text>selectId</text>
        </ownedElement>
      </ownedElement>
      <bounds x="750" y="145" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186326096_487125_477708" xmi:uuid="cf403b30-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
      <ownedElement xmi:id="cef3ce10-915e-013c-7163-0a5172f4a469" xmi:uuid="cef3cf50-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
        <text>RequirementView</text>
      </ownedElement>
      <ownedElement xmi:id="43f21110-6c42-013d-d60e-0800270c66d6" xmi:uuid="43f211b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="46deb3e0-6c42-013d-d60e-0800270c66d6" xmi:uuid="46deb470-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4708dd90-6c42-013d-d60e-0800270c66d6" xmi:uuid="4708de50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="4736b7a0-6c42-013d-d60e-0800270c66d6" xmi:uuid="4736b850-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570026712227_795000_68617"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="476dddf0-6c42-013d-d60e-0800270c66d6" xmi:uuid="476ddeb0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570026712261_357609_68624"/>
          <text>selectId</text>
        </ownedElement>
        <ownedElement xmi:id="47b5f5e0-6c42-013d-d60e-0800270c66d6" xmi:uuid="47b5f680-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570026712269_352030_68626"/>
          <text>defaultId</text>
        </ownedElement>
      </ownedElement>
      <bounds x="65" y="195" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186328663_822523_477773" xmi:uuid="cf7f5400-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
      <ownedElement xmi:id="cf436800-915e-013c-7163-0a5172f4a469" xmi:uuid="cf436920-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
        <text>SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="483bc640-6c42-013d-d60e-0800270c66d6" xmi:uuid="483bc6f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="4a999250-6c42-013d-d60e-0800270c66d6" xmi:uuid="4a9992e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4ab4d5d0-6c42-013d-d60e-0800270c66d6" xmi:uuid="4ab4d690-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="4aee78c0-6c42-013d-d60e-0800270c66d6" xmi:uuid="4aee79a0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768436995_518729_71185"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="4b0af780-6c42-013d-d60e-0800270c66d6" xmi:uuid="4b0af850-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437005_565845_71190"/>
          <text>selectId</text>
        </ownedElement>
        <ownedElement xmi:id="4b275700-6c42-013d-d60e-0800270c66d6" xmi:uuid="4b2757d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_619314_72555"/>
          <text>selectName</text>
        </ownedElement>
      </ownedElement>
      <bounds x="368" y="195" width="176" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1125" height="275"/>
    <name>ItemInSlotSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703186328698_675707_477814" xmi:uuid="cf80c510-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8e001ed_1498551955670_756141_14118"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186328731_146123_477846" xmi:uuid="cf8cd7b0-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215122607_133306_72338"/>
      <ownedElement xmi:id="cf866820-915e-013c-7163-0a5172f4a469" xmi:uuid="cf866960-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215122607_133306_72338"/>
        <text>SlotOnSelect</text>
      </ownedElement>
      <ownedElement xmi:id="cf896680-915e-013c-7163-0a5172f4a469" xmi:uuid="cf8967b0-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="cf8ab730-915e-013c-7163-0a5172f4a469" xmi:uuid="cf8ab840-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1033" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186331409_183065_477913" xmi:uuid="cff6c7b0-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
      <ownedElement xmi:id="cf9105a0-915e-013c-7163-0a5172f4a469" xmi:uuid="cf9106c0-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
        <text>BreakdownElementView</text>
      </ownedElement>
      <ownedElement xmi:id="4cac5580-6c42-013d-d60e-0800270c66d6" xmi:uuid="4cac5610-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="50e49900-6c42-013d-d60e-0800270c66d6" xmi:uuid="50e499a0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="511b6d80-6c42-013d-d60e-0800270c66d6" xmi:uuid="511b6e00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="514b0ec0-6c42-013d-d60e-0800270c66d6" xmi:uuid="514b0f80-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551700281091_86980_44146"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="5166ddf0-6c42-013d-d60e-0800270c66d6" xmi:uuid="5166deb0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551702070586_339964_46336"/>
          <text>selectId</text>
        </ownedElement>
        <ownedElement xmi:id="51a2a4f0-6c42-013d-d60e-0800270c66d6" xmi:uuid="51a2a5b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551702138524_57824_46412"/>
          <text>defaultId</text>
        </ownedElement>
        <ownedElement xmi:id="520691b0-6c42-013d-d60e-0800270c66d6" xmi:uuid="520692a0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560928666630_463684_40059"/>
          <text>selectName</text>
        </ownedElement>
      </ownedElement>
      <bounds x="65" y="95" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186333665_426095_477974" xmi:uuid="d031f100-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="cffa31f0-915e-013c-7163-0a5172f4a469" xmi:uuid="cffa3320-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="5253ad90-6c42-013d-d60e-0800270c66d6" xmi:uuid="5253ae20-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="54ac77e0-6c42-013d-d60e-0800270c66d6" xmi:uuid="54ac7870-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="54c7d630-6c42-013d-d60e-0800270c66d6" xmi:uuid="54c7d700-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="54fa3aa0-6c42-013d-d60e-0800270c66d6" xmi:uuid="54fa3b50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578046625087_447455_57832"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="552b6440-6c42-013d-d60e-0800270c66d6" xmi:uuid="552b6500-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578046625090_832197_57835"/>
          <text>selectId</text>
        </ownedElement>
      </ownedElement>
      <bounds x="298" y="95" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186335970_335774_478034" xmi:uuid="d0cd2410-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="d037cd90-915e-013c-7163-0a5172f4a469" xmi:uuid="d037cec0-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="55cb93e0-6c42-013d-d60e-0800270c66d6" xmi:uuid="55cb9470-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="5ae9ca90-6c42-013d-d60e-0800270c66d6" xmi:uuid="5ae9cb20-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5b021b80-6c42-013d-d60e-0800270c66d6" xmi:uuid="5b021c40-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="5b561f70-6c42-013d-d60e-0800270c66d6" xmi:uuid="5b562030-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_271a0567_1575306574233_773766_47039"/>
          <text>WR1</text>
        </ownedElement>
        <ownedElement xmi:id="5b905a00-6c42-013d-d60e-0800270c66d6" xmi:uuid="5b905b50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516290628652_484547_38739"/>
          <text>initialConvert</text>
        </ownedElement>
        <ownedElement xmi:id="5bf77f90-6c42-013d-d60e-0800270c66d6" xmi:uuid="5bf78040-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1568988378234_935366_63819"/>
          <text>additionalConvert</text>
        </ownedElement>
        <ownedElement xmi:id="5c40d6a0-6c42-013d-d60e-0800270c66d6" xmi:uuid="5c40d760-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569312933527_515827_42519"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="5c888ae0-6c42-013d-d60e-0800270c66d6" xmi:uuid="5c888bb0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569313322159_654490_44586"/>
          <text>selectId</text>
        </ownedElement>
      </ownedElement>
      <bounds x="541" y="95" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186338530_509080_478099" xmi:uuid="d0fafc10-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199044_378163_63005"/>
      <ownedElement xmi:id="d0d34380-915e-013c-7163-0a5172f4a469" xmi:uuid="d0d34660-915e-013c-7163-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199044_378163_63005"/>
        <text>SystemView</text>
      </ownedElement>
      <ownedElement xmi:id="5d3902e0-6c42-013d-d60e-0800270c66d6" xmi:uuid="5d390380-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="5e535080-6c42-013d-d60e-0800270c66d6" xmi:uuid="5e535110-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5e7336b0-6c42-013d-d60e-0800270c66d6" xmi:uuid="5e7337b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="5ea3beb0-6c42-013d-d60e-0800270c66d6" xmi:uuid="5ea3bf80-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1634042566378_630701_72825"/>
          <text>UR1</text>
        </ownedElement>
        <ownedElement xmi:id="5ed0d280-6c42-013d-d60e-0800270c66d6" xmi:uuid="5ed0d350-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962200348_765311_63381"/>
          <text>selectDescription</text>
        </ownedElement>
        <ownedElement xmi:id="5eea15d0-6c42-013d-d60e-0800270c66d6" xmi:uuid="5eea16a0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962200350_866880_63386"/>
          <text>selectId</text>
        </ownedElement>
        <ownedElement xmi:id="5f17c790-6c42-013d-d60e-0800270c66d6" xmi:uuid="5f17c8a0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962200353_499189_63393"/>
          <text>selectName</text>
        </ownedElement>
      </ownedElement>
      <bounds x="843" y="95" width="195" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1093" height="175"/>
    <name>SlotOnSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1623136672629_545970_78723" xmi:uuid="07ef3380-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1623138161171_898688_79129" xmi:uuid="07ffc540-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623138161163_632544_79125"/>
      <bounds x="1119" y="258" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623136702008_823630_78755" xmi:uuid="094fe490-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574625794_544014_75119"/>
      <ownedElement xmi:id="094b5a00-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="094b5bb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574625794_544014_75119"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="094e82c0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="094e8460-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574625794_544014_75119"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623152279883_840062_81051" xmi:uuid="094fb3e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="60f09360-6c42-013d-d60e-0800270c66d6" xmi:uuid="60f09540-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="227" y="772" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="209" y="781" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="777" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623136702018_758994_78786" xmi:uuid="09b84d00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574553086_104308_75111"/>
      <ownedElement xmi:id="09af0d10-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="09af0f00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574553086_104308_75111"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="09b72660-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="09b727e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574553086_104308_75111"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="105" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623136702027_118283_78817" xmi:uuid="0a4a3e40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622570782448_528292_75095"/>
      <ownedElement xmi:id="0a3ff7f0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0a3ff9d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622570782448_528292_75095"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="0a48ce50-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0a48d080-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622570782448_528292_75095"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="343" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623136702035_222175_78848" xmi:uuid="0aefa680-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574464803_512866_75103"/>
      <ownedElement xmi:id="0ae86500-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0ae86690-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574464803_512866_75103"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="0aef49b0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0aef4c30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574464803_512866_75103"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="483" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623136702044_911345_78879" xmi:uuid="0b627d20-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574703456_391374_75127"/>
      <ownedElement xmi:id="0b5cd920-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0b5cdb10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574703456_391374_75127"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="0b620420-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0b6205d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574703456_391374_75127"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623152417093_810521_81131" xmi:uuid="0b625bb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="65eb81b0-6c42-013d-d60e-0800270c66d6" xmi:uuid="65eb8240-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="164" y="849" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="146" y="858" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="854" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623136702052_31997_78910" xmi:uuid="0b70fde0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214497665_843170_69567"/>
      <ownedElement xmi:id="0b6bb2a0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0b6bb490-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214497665_843170_69567"/>
        <text>Versions:SlotVersion</text>
      </ownedElement>
      <ownedElement xmi:id="3bdecb40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="3bdeccd0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214497665_843170_69567"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623169411598_644506_81581" xmi:uuid="0b70d4d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623169221863_297479_81554"/>
        <ownedElement xmi:id="66abfb20-6c42-013d-d60e-0800270c66d6" xmi:uuid="66abfbc0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623169221863_297479_81554"/>
          <bounds x="199" y="927" width="199" height="13"/>
          <text>slotVersion : Attachment_slot_version [1]</text>
        </ownedElement>
        <bounds x="181" y="936" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="931" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623137935052_858465_78989" xmi:uuid="101dd430-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623137934973_564696_78987"/>
      <ownedElement xmi:id="0d12dbd0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0d12dd80-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623137934973_564696_78987"/>
        <text>theSlot:Attachment_slot</text>
      </ownedElement>
      <ownedElement xmi:id="3cc42d90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="3cc42f10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623137934973_564696_78987"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="6a585630-6c42-013d-d60e-0800270c66d6" xmi:uuid="6a5856c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="6a6ef660-6c42-013d-d60e-0800270c66d6" xmi:uuid="6a6ef730-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623137985544_523459_79025" xmi:uuid="0e0ce750-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-description"/>
          <ownedElement xmi:id="0d8f8660-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0d8f87d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="0e0ca000-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0e0ca170-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="882" y="308" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623137985558_968276_79056" xmi:uuid="0f2a5bf0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-id"/>
          <ownedElement xmi:id="0e9d12e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0e9d1560-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="0f2a33d0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0f2a3560-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="882" y="343" width="88" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623137985581_197835_79087" xmi:uuid="101d9c40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-name"/>
          <ownedElement xmi:id="0f9ec3a0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="0f9ec6c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="101d5a80-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="101d5c70-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="882" y="483" width="109" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="861" y="280" width="196" height="238"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623138242142_827754_79150" xmi:uuid="101e1820-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623138243483_708938_79151"/>
      <source xmi:idref="_18_4_1_8be0287_1623138161171_898688_79129"/>
      <target xmi:idref="_18_4_1_8be0287_1623137935052_858465_78989"/>
      <waypoint x="1119" y="266"/>
      <waypoint x="1022" y="266"/>
      <waypoint x="1022" y="280"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623138956960_735916_79348" xmi:uuid="10b6ff90-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623138952358_252397_79345"/>
      <ownedElement xmi:id="10b38930-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="10b38af0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623138952358_252397_79345"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623139026774_368032_79368" xmi:uuid="10b694e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="70954690-6c42-013d-d60e-0800270c66d6" xmi:uuid="70954730-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="240" y="101" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="294" y="110" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623139026797_694381_79378" xmi:uuid="10b6b3a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="716219d0-6c42-013d-d60e-0800270c66d6" xmi:uuid="71621a60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="358" y="136" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="348" y="118" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623139026812_857883_79388" xmi:uuid="10b6cf00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="720c3a80-6c42-013d-d60e-0800270c66d6" xmi:uuid="720c3b80-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="385" y="48" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="447" y="63" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623139026826_958807_79398" xmi:uuid="10b6e9c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="7305cbf0-6c42-013d-d60e-0800270c66d6" xmi:uuid="7305cc90-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="456" y="136" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="446" y="118" width="15" height="15"/>
      </ownedElement>
      <bounds x="294" y="63" width="244" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623139076343_176018_79423" xmi:uuid="10b722c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623139078955_345374_79424"/>
      <source xmi:idref="_18_4_1_8be0287_1623139026774_368032_79368"/>
      <target xmi:idref="_18_4_1_8be0287_1623136702018_758994_78786"/>
      <waypoint x="294" y="119"/>
      <waypoint x="220" y="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150120169_243185_79440" xmi:uuid="10b86010-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150121703_64981_79441"/>
      <source xmi:idref="_18_4_1_8be0287_1623137985544_523459_79025"/>
      <target xmi:idref="_18_4_1_8be0287_1623139026797_694381_79378"/>
      <waypoint x="882" y="319"/>
      <waypoint x="354" y="319"/>
      <waypoint x="354" y="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150191296_212564_79461" xmi:uuid="112af530-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150188712_99358_79453"/>
      <ownedElement xmi:id="11267c20-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="11267f30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150188712_99358_79453"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="112a5e30-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="112a6030-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150188712_99358_79453"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623150359877_39735_79492" xmi:uuid="112ac660-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="74e5b6c0-6c42-013d-d60e-0800270c66d6" xmi:uuid="74e5b760-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="728" y="17" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="710" y="26" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="532" y="21" width="186" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150401313_963733_79511" xmi:uuid="112b51d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150404103_178310_79512"/>
      <source xmi:idref="_18_4_1_8be0287_1623150191296_212564_79461"/>
      <target xmi:idref="_18_4_1_8be0287_1623139026812_857883_79388"/>
      <waypoint x="532" y="35"/>
      <waypoint x="455" y="35"/>
      <waypoint x="455" y="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150492477_955192_79598" xmi:uuid="137899f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150494385_314224_79599"/>
      <source xmi:idref="_18_4_1_8be0287_1623137935052_858465_78989"/>
      <target xmi:idref="_18_4_1_8be0287_1623150467720_277971_79560"/>
      <waypoint x="984" y="280"/>
      <waypoint x="984" y="102"/>
      <waypoint x="924" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150444893_920079_79529" xmi:uuid="1378b280-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150441452_747609_79521"/>
      <ownedElement xmi:id="11b546f0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="11b54870-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150441452_747609_79521"/>
        <text>descrAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="11bad300-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="11badbf0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150441452_747609_79521"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="760e9320-6c42-013d-d60e-0800270c66d6" xmi:uuid="760e93c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="760fce60-6c42-013d-d60e-0800270c66d6" xmi:uuid="760fcf00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623150467720_277971_79560" xmi:uuid="13787b80-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="12c5ccf0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="12c5cf80-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="137866c0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="13786830-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="749" y="91" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="686" y="63" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151971168_599523_80824" xmi:uuid="190ef5a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151973993_849959_80825"/>
      <source xmi:idref="_18_4_1_8be0287_1623137935052_858465_78989"/>
      <target xmi:idref="_18_4_1_8be0287_1623151845178_651826_80694"/>
      <waypoint x="973" y="518"/>
      <waypoint x="973" y="613"/>
      <waypoint x="893" y="613"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150523311_170881_79616" xmi:uuid="190f1c90-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150520125_994982_79608"/>
      <ownedElement xmi:id="14035530-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="14035750-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150520125_994982_79608"/>
        <text>nameLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="140929e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="14092b40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150520125_994982_79608"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="79b02220-6c42-013d-d60e-0800270c66d6" xmi:uuid="79b022c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="79cbc310-6c42-013d-d60e-0800270c66d6" xmi:uuid="79cbc460-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623151845153_109646_80663" xmi:uuid="15617570-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="14a77b60-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="14a77d10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="155eeab0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="155eec20-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="665" y="637" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623151845178_651826_80694" xmi:uuid="1756ed90-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="168e8130-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="168e85d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="1756cf40-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1756d380-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="665" y="602" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623151845195_501657_80725" xmi:uuid="190e8a30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="18772670-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="18772890-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="190e6680-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="190e6870-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="665" y="567" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="651" y="539" width="294" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150855139_70646_79874" xmi:uuid="1de45ba0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150856711_692603_79875"/>
      <source xmi:idref="_18_4_1_8be0287_1623137935052_858465_78989"/>
      <target xmi:idref="_18_4_1_8be0287_1623150597250_969088_79717"/>
      <waypoint x="984" y="280"/>
      <waypoint x="984" y="207"/>
      <waypoint x="935" y="207"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150555285_331272_79655" xmi:uuid="1de49dc0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150550114_206750_79647"/>
      <ownedElement xmi:id="1995ab90-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1995ad20-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150550114_206750_79647"/>
        <text>descrLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="199b23c0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="199b2540-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150550114_206750_79647"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="81c1b9e0-6c42-013d-d60e-0800270c66d6" xmi:uuid="81c1bab0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="81da1990-6c42-013d-d60e-0800270c66d6" xmi:uuid="81da1a50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623150597221_21359_79686" xmi:uuid="1af313f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="1a336a00-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1a336be0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="1af2e250-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1af2e4c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="707" y="231" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623150597250_969088_79717" xmi:uuid="1c6630a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="1bf1e170-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1bf1e3d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="1c660b80-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1c660d00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="707" y="196" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623150597268_846775_79748" xmi:uuid="1de41e10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="1d6537b0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1d653930-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="1de3ec90-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1de3f030-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="707" y="161" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="686" y="133" width="276" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150683617_328947_79787" xmi:uuid="1e505ce0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150679999_591294_79779"/>
      <ownedElement xmi:id="1e4bd3e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1e4bd5e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150679999_591294_79779"/>
        <text>descrLang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="1e4f83b0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1e4f8590-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150679999_591294_79779"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623150787303_378183_79852" xmi:uuid="1e503230-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="8b858dc0-6c42-013d-d60e-0800270c66d6" xmi:uuid="8b858e80-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="564" y="151" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="552" y="166" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="385" y="161" width="175" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150743673_705983_79825" xmi:uuid="1e50b800-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150745271_223738_79826"/>
      <source xmi:idref="_18_4_1_8be0287_1623150683617_328947_79787"/>
      <target xmi:idref="_18_4_1_8be0287_1623139026826_958807_79398"/>
      <waypoint x="452" y="161"/>
      <waypoint x="452" y="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150749535_682909_79842" xmi:uuid="1e50e9e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150752625_19096_79843"/>
      <source xmi:idref="_18_4_1_8be0287_1623150597268_846775_79748"/>
      <target xmi:idref="_18_4_1_8be0287_1623150787303_378183_79852"/>
      <waypoint x="707" y="172"/>
      <waypoint x="567" y="172"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150889120_683507_79890" xmi:uuid="1e5b9990-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150882036_537143_79884"/>
      <ownedElement xmi:id="1e560d20-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1e560f40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150882036_537143_79884"/>
        <text>descrAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="1e5abbf0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1e5aea30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150882036_537143_79884"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="378" y="231" width="228" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150908917_173353_79928" xmi:uuid="1e5bd060-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150911103_443248_79929"/>
      <source xmi:idref="_18_4_1_8be0287_1623150597221_21359_79686"/>
      <target xmi:idref="_18_4_1_8be0287_1623150889120_683507_79890"/>
      <waypoint x="707" y="242"/>
      <waypoint x="606" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623150958755_260568_79945" xmi:uuid="1e5c4070-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623150960536_396924_79946"/>
      <source xmi:idref="_18_4_1_8be0287_1623150444893_920079_79529"/>
      <target xmi:idref="_18_4_1_8be0287_1623150359877_39735_79492"/>
      <waypoint x="826" y="63"/>
      <waypoint x="826" y="35"/>
      <waypoint x="725" y="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151063326_861908_79975" xmi:uuid="1eeb0bd0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151049183_7892_79955"/>
      <ownedElement xmi:id="1ee6e510-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1ee6e6b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151049183_7892_79955"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151089614_678570_80077" xmi:uuid="1eeaa880-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="8e325dd0-6c42-013d-d60e-0800270c66d6" xmi:uuid="8e325e70-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="163" y="339" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="217" y="348" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151089627_463242_80087" xmi:uuid="1eeacd60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="8ed42260-6c42-013d-d60e-0800270c66d6" xmi:uuid="8ed42300-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="374" y="339" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="356" y="348" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151089637_920097_80097" xmi:uuid="1eeaee50-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="8f8edd70-6c42-013d-d60e-0800270c66d6" xmi:uuid="8f8ede00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="245" y="388" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="235" y="370" width="15" height="15"/>
      </ownedElement>
      <bounds x="217" y="336" width="154" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151067395_301506_79995" xmi:uuid="1f52a980-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151049189_964100_79956"/>
      <ownedElement xmi:id="1f4d9ac0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1f4d9cb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151049189_964100_79956"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151099418_148963_80113" xmi:uuid="1f525840-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="91609ae0-6c42-013d-d60e-0800270c66d6" xmi:uuid="91609b70-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="499" y="339" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="553" y="348" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151099433_20164_80123" xmi:uuid="1f528d60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="92265fa0-6c42-013d-d60e-0800270c66d6" xmi:uuid="92266040-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="735" y="335" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="709" y="347" width="15" height="15"/>
      </ownedElement>
      <bounds x="553" y="336" width="171" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151071186_202042_80015" xmi:uuid="1fb83510-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151049194_534314_79957"/>
      <ownedElement xmi:id="1fb390c0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1fb39250-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151049194_534314_79957"/>
        <text>identifiers:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="1fb6aa60-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="1fb6ac80-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151049194_534314_79957"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151244170_559043_80225" xmi:uuid="1fb79700-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="93c41920-6c42-013d-d60e-0800270c66d6" xmi:uuid="93c419d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="430" y="409" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="412" y="418" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="252" y="413" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151349805_302587_80309" xmi:uuid="21970690-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151353215_260127_80310"/>
      <source xmi:idref="_18_4_1_8be0287_1623137935052_858465_78989"/>
      <target xmi:idref="_18_4_1_8be0287_1623151301041_25646_80237"/>
      <waypoint x="861" y="438"/>
      <waypoint x="834" y="438"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151074831_347872_80046" xmi:uuid="21972300-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151049201_721701_79958"/>
      <ownedElement xmi:id="201ecb10-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="201ece60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151049201_721701_79958"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="20216eb0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="20217040-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151049201_721701_79958"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="94f98ab0-6c42-013d-d60e-0800270c66d6" xmi:uuid="94f98c00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="95262d10-6c42-013d-d60e-0800270c66d6" xmi:uuid="95262e00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623151301041_25646_80237" xmi:uuid="2196e130-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="210a8270-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="210a9410-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="2196b750-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2196be00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="651" y="427" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="616" y="399" width="231" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151129741_468473_80144" xmi:uuid="21973f80-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151131391_425468_80145"/>
      <source xmi:idref="_18_4_1_8be0287_1623151089614_678570_80077"/>
      <target xmi:idref="_18_4_1_8be0287_1623136702027_118283_78817"/>
      <waypoint x="217" y="354"/>
      <waypoint x="147" y="354"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151154966_789134_80161" xmi:uuid="21975fb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151156479_540535_80162"/>
      <source xmi:idref="_18_4_1_8be0287_1623151099418_148963_80113"/>
      <target xmi:idref="_18_4_1_8be0287_1623151089627_463242_80087"/>
      <waypoint x="553" y="361"/>
      <waypoint x="371" y="361"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151161975_242928_80181" xmi:uuid="21977be0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151164052_413328_80182"/>
      <source xmi:idref="_18_4_1_8be0287_1623137985558_968276_79056"/>
      <target xmi:idref="_18_4_1_8be0287_1623151099433_20164_80123"/>
      <waypoint x="882" y="354"/>
      <waypoint x="724" y="354"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151328077_208327_80275" xmi:uuid="21979970-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151329035_457723_80276"/>
      <source xmi:idref="_18_4_1_8be0287_1623151071186_202042_80015"/>
      <target xmi:idref="_18_4_1_8be0287_1623151089637_920097_80097"/>
      <waypoint x="252" y="427"/>
      <waypoint x="242" y="427"/>
      <waypoint x="242" y="385"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151333693_786579_80292" xmi:uuid="2197ccb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151335542_530857_80293"/>
      <source xmi:idref="_18_4_1_8be0287_1623151074831_347872_80046"/>
      <target xmi:idref="_18_4_1_8be0287_1623151244170_559043_80225"/>
      <waypoint x="616" y="427"/>
      <waypoint x="427" y="427"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151513175_742521_80353" xmi:uuid="2215cf10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497422_232648_80319"/>
      <ownedElement xmi:id="220fa700-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="220fa930-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497422_232648_80319"/>
        <text>selectName:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151594361_620604_80517" xmi:uuid="22142f40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="98f8e430-6c42-013d-d60e-0800270c66d6" xmi:uuid="98f8e4d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="198" y="476" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="252" y="485" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151594376_250692_80527" xmi:uuid="22145f40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="99b66a00-6c42-013d-d60e-0800270c66d6" xmi:uuid="99b66a90-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="472" y="480" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="454" y="489" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151594386_572748_80537" xmi:uuid="221490f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="9a500340-6c42-013d-d60e-0800270c66d6" xmi:uuid="9a5003e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="282" y="528" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="272" y="510" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151594396_645249_80547" xmi:uuid="2214bf90-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="9b3d9df0-6c42-013d-d60e-0800270c66d6" xmi:uuid="9b3d9e90-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="406" y="532" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="394" y="510" width="15" height="15"/>
      </ownedElement>
      <bounds x="252" y="476" width="217" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151516917_725588_80373" xmi:uuid="2286a9e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497426_541339_80320"/>
      <ownedElement xmi:id="22819330-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="22819740-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497426_541339_80320"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151657531_131444_80582" xmi:uuid="228649e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="9cbf5aa0-6c42-013d-d60e-0800270c66d6" xmi:uuid="9cbf5b80-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="541" y="481" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="595" y="490" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151657550_200429_80592" xmi:uuid="22868470-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="9d86d990-6c42-013d-d60e-0800270c66d6" xmi:uuid="9d86db90-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="790" y="477" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="772" y="486" width="15" height="15"/>
      </ownedElement>
      <bounds x="595" y="476" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151521089_741410_80393" xmi:uuid="23024250-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497430_96239_80321"/>
      <ownedElement xmi:id="22fb9f30-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="22fba1a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497430_96239_80321"/>
        <text>nameLang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="2300f600-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2300f790-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497430_96239_80321"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623151907424_361505_80783" xmi:uuid="23017780-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="9f724040-6c42-013d-d60e-0800270c66d6" xmi:uuid="9f7240d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="542" y="563" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="524" y="572" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="357" y="567" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151524713_338174_80424" xmi:uuid="2308faf0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497434_614412_80322"/>
      <ownedElement xmi:id="230593e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="23059580-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497434_614412_80322"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="2308d5a0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2308d7d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497434_614412_80322"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="392" y="637" width="195" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151531332_341523_80455" xmi:uuid="2370fb30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497438_579683_80323"/>
      <ownedElement xmi:id="236c1110-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="236c1360-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497438_579683_80323"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="236ff690-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="236ff930-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497438_579683_80323"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623152022502_166254_80848" xmi:uuid="237074f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="a18321b0-6c42-013d-d60e-0800270c66d6" xmi:uuid="a1832240-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="410" y="689" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="392" y="698" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="693" width="155" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623152093066_886778_80918" xmi:uuid="252e3820-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152099939_233719_80919"/>
      <source xmi:idref="_18_4_1_8be0287_1623137935052_858465_78989"/>
      <target xmi:idref="_18_4_1_8be0287_1623152067908_809293_80863"/>
      <waypoint x="987" y="518"/>
      <waypoint x="987" y="718"/>
      <waypoint x="840" y="718"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151535329_796859_80486" xmi:uuid="252e5810-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497442_551784_80324"/>
      <ownedElement xmi:id="23ef0290-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="23ef0430-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497442_551784_80324"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="23f2cea0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="23f2d0b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151497442_551784_80324"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a19ecb50-6c42-013d-d60e-0800270c66d6" xmi:uuid="a19ecbf0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a1bb9ee0-6c42-013d-d60e-0800270c66d6" xmi:uuid="a1bb9fa0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623152067908_809293_80863" xmi:uuid="252e1320-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="24be8f40-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="24be9110-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="252dfb50-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="252dfca0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="665" y="707" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="651" y="679" width="292" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151631478_889864_80572" xmi:uuid="252e7ae0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151632253_850806_80573"/>
      <source xmi:idref="_18_4_1_8be0287_1623151594361_620604_80517"/>
      <target xmi:idref="_18_4_1_8be0287_1623136702035_222175_78848"/>
      <waypoint x="252" y="494"/>
      <waypoint x="188" y="494"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151680303_985348_80613" xmi:uuid="252ed2c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151681712_91488_80614"/>
      <source xmi:idref="_18_4_1_8be0287_1623151657531_131444_80582"/>
      <target xmi:idref="_18_4_1_8be0287_1623151594376_250692_80527"/>
      <waypoint x="595" y="497"/>
      <waypoint x="469" y="497"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151706584_620452_80633" xmi:uuid="252f0d60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151707586_790331_80634"/>
      <source xmi:idref="_18_4_1_8be0287_1623137985581_197835_79087"/>
      <target xmi:idref="_18_4_1_8be0287_1623151657550_200429_80592"/>
      <waypoint x="882" y="494"/>
      <waypoint x="787" y="494"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151796233_843427_80653" xmi:uuid="252f5cc0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151797651_126914_80654"/>
      <source xmi:idref="_18_4_1_8be0287_1623151521089_741410_80393"/>
      <target xmi:idref="_18_4_1_8be0287_1623151594396_645249_80547"/>
      <waypoint x="403" y="567"/>
      <waypoint x="403" y="525"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151887171_371369_80763" xmi:uuid="252fee90-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151887861_310907_80764"/>
      <source xmi:idref="_18_4_1_8be0287_1623151845153_109646_80663"/>
      <target xmi:idref="_18_4_1_8be0287_1623151524713_338174_80424"/>
      <waypoint x="665" y="648"/>
      <waypoint x="587" y="648"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151959095_389262_80804" xmi:uuid="253034e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151960361_683765_80805"/>
      <source xmi:idref="_18_4_1_8be0287_1623151845195_501657_80725"/>
      <target xmi:idref="_18_4_1_8be0287_1623151907424_361505_80783"/>
      <waypoint x="665" y="581"/>
      <waypoint x="539" y="581"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623151996269_705484_80841" xmi:uuid="25305430-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623151997759_172515_80842"/>
      <source xmi:idref="_18_4_1_8be0287_1623151531332_341523_80455"/>
      <target xmi:idref="_18_4_1_8be0287_1623151594386_572748_80537"/>
      <waypoint x="280" y="693"/>
      <waypoint x="280" y="525"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623152079187_26029_80901" xmi:uuid="25307470-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152081086_490062_80902"/>
      <source xmi:idref="_18_4_1_8be0287_1623151535329_796859_80486"/>
      <target xmi:idref="_18_4_1_8be0287_1623152022502_166254_80848"/>
      <waypoint x="651" y="707"/>
      <waypoint x="407" y="707"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623152314327_926562_81073" xmi:uuid="26e45e50-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152316869_675552_81074"/>
      <source xmi:idref="_18_4_1_8be0287_1623137935052_858465_78989"/>
      <target xmi:idref="_18_4_1_8be0287_1623152237579_500526_81006"/>
      <waypoint x="987" y="518"/>
      <waypoint x="987" y="795"/>
      <waypoint x="849" y="795"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623152206754_383199_80944" xmi:uuid="26e49080-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152198211_364756_80928"/>
      <ownedElement xmi:id="258f9320-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="258f94e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152198211_364756_80928"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="2593ba50-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2593bcd0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152198211_364756_80928"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a4b79ea0-6c42-013d-d60e-0800270c66d6" xmi:uuid="a4b79f40-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a4b8e1c0-6c42-013d-d60e-0800270c66d6" xmi:uuid="a4b8e310-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623152237579_500526_81006" xmi:uuid="26e3f330-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="266826b0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="26682b80-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="26e3d5c0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="26e3d730-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="665" y="784" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="651" y="756" width="292" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623152376283_824950_81121" xmi:uuid="28a0e260-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152378788_3683_81122"/>
      <source xmi:idref="_18_4_1_8be0287_1623137935052_858465_78989"/>
      <target xmi:idref="_18_4_1_8be0287_1623152363381_910819_81083"/>
      <waypoint x="987" y="518"/>
      <waypoint x="987" y="872"/>
      <waypoint x="888" y="872"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623152216243_281147_80975" xmi:uuid="28a14850-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152198217_394012_80929"/>
      <ownedElement xmi:id="27548c80-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="27548e10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152198217_394012_80929"/>
        <text>sameAsItem:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="2758d8f0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2758daf0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152198217_394012_80929"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a90e16a0-6c42-013d-d60e-0800270c66d6" xmi:uuid="a90e1740-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a9312600-6c42-013d-d60e-0800270c66d6" xmi:uuid="a93126c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623152363381_910819_81083" xmi:uuid="289fb9f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="283d5b80-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="283d5d00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="289f9e80-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="289fa0e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="665" y="861" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="651" y="833" width="293" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623152247703_511691_81044" xmi:uuid="28a173a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152251357_918000_81045"/>
      <source xmi:idref="_18_4_1_8be0287_1623152206754_383199_80944"/>
      <target xmi:idref="_18_4_1_8be0287_1623152279883_840062_81051"/>
      <waypoint x="651" y="788"/>
      <waypoint x="224" y="788"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623152443720_788515_81150" xmi:uuid="28a19d10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623152445917_105172_81151"/>
      <source xmi:idref="_18_4_1_8be0287_1623152417093_810521_81131"/>
      <target xmi:idref="_18_4_1_8be0287_1623152216243_281147_80975"/>
      <waypoint x="161" y="865"/>
      <waypoint x="651" y="865"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623169601045_246221_81692" xmi:uuid="2a48ab10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623169610157_437738_81693"/>
      <source xmi:idref="_18_4_1_8be0287_1623137935052_858465_78989"/>
      <target xmi:idref="_18_4_1_8be0287_1623169578789_373887_81630"/>
      <waypoint x="987" y="518"/>
      <waypoint x="987" y="949"/>
      <waypoint x="862" y="949"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623169533609_687143_81594" xmi:uuid="2a48ca60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623169533592_636458_81593"/>
      <ownedElement xmi:id="29072500-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="29072cb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623169533592_636458_81593"/>
        <text>slotVersion:Attachment_slot_version</text>
      </ownedElement>
      <ownedElement xmi:id="4c34cee0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="4c34d230-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623169533592_636458_81593"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="acc7bd60-6c42-013d-d60e-0800270c66d6" xmi:uuid="acc7be30-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="acdaa450-6c42-013d-d60e-0800270c66d6" xmi:uuid="acdaa550-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623169578789_373887_81630" xmi:uuid="2a487d40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_version-of_product"/>
          <ownedElement xmi:id="29e21db0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="29e21f60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_version-of_product"/>
            <text>of_product:Attachment_slot</text>
          </ownedElement>
          <ownedElement xmi:id="2a485600-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2a485780-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_version-of_product"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="672" y="938" width="190" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="651" y="910" width="295" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623169593131_934449_81675" xmi:uuid="2a495310-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623169595395_870370_81676"/>
      <source xmi:idref="_18_4_1_8be0287_1623169533609_687143_81594"/>
      <target xmi:idref="_18_4_1_8be0287_1623169411598_644506_81581"/>
      <waypoint x="651" y="942"/>
      <waypoint x="196" y="942"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1122" height="988"/>
    <name>Slot</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446410894_200297_347300" xmi:uuid="1c4281f0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535892317_254657_73801"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446410924_114507_347332" xmi:uuid="1d35e420-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034007716_900214_75482"/>
      <ownedElement xmi:id="1d022c50-6c45-013d-d60e-0800270c66d6" xmi:uuid="1d022d30-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034007716_900214_75482"/>
        <text>slotPlannedToRealized:Attachment_slot_planned_to_realized</text>
      </ownedElement>
      <ownedElement xmi:id="1d35c560-6c45-013d-d60e-0800270c66d6" xmi:uuid="1d35c670-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034007716_900214_75482"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="363" height="330"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446410941_626865_347366" xmi:uuid="1d5221d0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="748" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446410956_854102_347381" xmi:uuid="1d6b38a0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="748" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446410971_84782_347396" xmi:uuid="1d823f40-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="748" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446410985_315137_347411" xmi:uuid="1d9aa010-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="748" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446410999_866684_347426" xmi:uuid="1dc960b0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="748" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411013_45488_347441" xmi:uuid="1dd6e530-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="748" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411027_695915_347456" xmi:uuid="1dea8410-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="748" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411039_407248_347471" xmi:uuid="1dec48c0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="748" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411056_243044_347486" xmi:uuid="1e1b06e0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="748" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411073_500190_347501" xmi:uuid="1e1caae0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="748" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411088_112391_347516" xmi:uuid="1e5550d0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="748" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411101_547796_347531" xmi:uuid="1e697fa0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="748" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411113_722845_347546" xmi:uuid="1e781d00-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="748" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411124_602687_347561" xmi:uuid="1e8a71a0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="748" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_436323_416000" xmi:uuid="1e8a9190-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918670_435230_73206"/>
      <source xmi:idref="_18_4_1_65b021e_1727446410941_626865_347366"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="62"/>
      <waypoint x="408" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_958122_416003" xmi:uuid="1e8aa310-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918733_116509_73222"/>
      <source xmi:idref="_18_4_1_65b021e_1727446410956_854102_347381"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="82"/>
      <waypoint x="408" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_995467_416006" xmi:uuid="1e8aabb0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918798_102171_73238"/>
      <source xmi:idref="_18_4_1_65b021e_1727446410971_84782_347396"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="102"/>
      <waypoint x="408" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_474857_416009" xmi:uuid="1e8ab410-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918860_702899_73254"/>
      <source xmi:idref="_18_4_1_65b021e_1727446410985_315137_347411"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="122"/>
      <waypoint x="408" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_571126_416012" xmi:uuid="1e8abc60-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918923_637311_73270"/>
      <source xmi:idref="_18_4_1_65b021e_1727446410999_866684_347426"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="142"/>
      <waypoint x="408" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_232520_416015" xmi:uuid="1e9e8f20-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919006_179932_73286"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411013_45488_347441"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="162"/>
      <waypoint x="408" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_396032_416018" xmi:uuid="1e9e9840-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919071_906835_73302"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411027_695915_347456"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="182"/>
      <waypoint x="408" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_645707_416021" xmi:uuid="1e9e9f80-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919130_538932_73318"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411039_407248_347471"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="202"/>
      <waypoint x="408" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_382714_416024" xmi:uuid="1e9ea8b0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919194_382920_73334"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411056_243044_347486"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="222"/>
      <waypoint x="408" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_372516_416027" xmi:uuid="1e9eb070-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919265_869889_73350"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411073_500190_347501"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="242"/>
      <waypoint x="408" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_206257_416030" xmi:uuid="1e9eb9a0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919329_691583_73366"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411088_112391_347516"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="262"/>
      <waypoint x="408" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_591939_416033" xmi:uuid="1e9ec110-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919391_34315_73382"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411101_547796_347531"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="282"/>
      <waypoint x="408" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_486755_416036" xmi:uuid="1e9ec8c0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919450_410540_73398"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411113_722845_347546"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="302"/>
      <waypoint x="408" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513315_9451_416039" xmi:uuid="1e9ed020-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919509_588088_73414"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411124_602687_347561"/>
      <target xmi:idref="_18_4_1_65b021e_1727446410924_114507_347332"/>
      <waypoint x="748" y="322"/>
      <waypoint x="408" y="322"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="751" height="400"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446411722_178058_348356" xmi:uuid="1f80ebc0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214343240_255641_69449"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411749_953158_348388" xmi:uuid="207c9e40-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033954065_360763_75446"/>
      <ownedElement xmi:id="203f6f00-6c44-013d-d60e-0800270c66d6" xmi:uuid="203f7070-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033954065_360763_75446"/>
        <text>slotDesignToRealized:Attachment_slot_design_to_realized</text>
      </ownedElement>
      <ownedElement xmi:id="20685e70-6c44-013d-d60e-0800270c66d6" xmi:uuid="207c8d90-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033954065_360763_75446"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="350" height="330"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411765_128952_348422" xmi:uuid="207dea40-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="727" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411780_381321_348437" xmi:uuid="209ab820-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="727" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411794_825426_348452" xmi:uuid="209c06c0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="727" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411808_933829_348467" xmi:uuid="20c1f950-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="727" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411821_678366_348482" xmi:uuid="20dd6e80-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="727" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411837_141606_348497" xmi:uuid="20efd380-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="727" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411851_893110_348512" xmi:uuid="2104e850-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="727" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411864_637934_348527" xmi:uuid="21063df0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="727" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411882_112999_348542" xmi:uuid="212de210-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="727" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413419_245392_348557" xmi:uuid="214e0a10-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="727" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413436_647531_348572" xmi:uuid="2161e630-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="727" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413448_269028_348587" xmi:uuid="2170f900-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="727" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413458_95553_348602" xmi:uuid="2187c0c0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="727" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413469_580109_348617" xmi:uuid="21a14b80-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="727" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513345_729051_416186" xmi:uuid="21c1a5c0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147917419_608437_72919"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411765_128952_348422"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="62"/>
      <waypoint x="395" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513345_732321_416189" xmi:uuid="21c1ae50-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147917501_286383_72935"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411780_381321_348437"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="82"/>
      <waypoint x="395" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513345_328398_416192" xmi:uuid="21c1b650-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147917598_854525_72951"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411794_825426_348452"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="102"/>
      <waypoint x="395" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513345_440583_416195" xmi:uuid="21c1be30-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147917776_251940_72967"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411808_933829_348467"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="122"/>
      <waypoint x="395" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513345_856007_416198" xmi:uuid="21c1c650-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147917922_382804_72983"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411821_678366_348482"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="142"/>
      <waypoint x="395" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513345_949190_416201" xmi:uuid="21c1cd20-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918024_412077_72999"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411837_141606_348497"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="162"/>
      <waypoint x="395" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513345_481971_416204" xmi:uuid="21c1d3f0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918089_815096_73015"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411851_893110_348512"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="182"/>
      <waypoint x="395" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513346_224545_416207" xmi:uuid="21c1db00-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918154_681070_73031"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411864_637934_348527"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="202"/>
      <waypoint x="395" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513346_891280_416210" xmi:uuid="21c1e1f0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918225_770484_73047"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411882_112999_348542"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="222"/>
      <waypoint x="395" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513346_572476_416213" xmi:uuid="21c1e930-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918313_826410_73063"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413419_245392_348557"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="242"/>
      <waypoint x="395" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513346_835118_416216" xmi:uuid="21c1f1a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918398_639721_73079"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413436_647531_348572"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="262"/>
      <waypoint x="395" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513346_903643_416219" xmi:uuid="21c1f940-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918469_368215_73095"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413448_269028_348587"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="282"/>
      <waypoint x="395" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513346_710210_416222" xmi:uuid="21c20090-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918527_609644_73111"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413458_95553_348602"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="302"/>
      <waypoint x="395" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513346_457663_416225" xmi:uuid="21c27400-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147918587_728647_73127"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413469_580109_348617"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411749_953158_348388"/>
      <waypoint x="727" y="322"/>
      <waypoint x="395" y="322"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="730" height="400"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1623158012147_298117_81229" xmi:uuid="2a4a8c20-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1623158020735_644090_81261" xmi:uuid="2abb0650-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574921548_858078_75151"/>
      <ownedElement xmi:id="2ab56280-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2ab56490-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574921548_858078_75151"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="2aba7d40-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2aba7fa0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574921548_858078_75151"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623361171475_342393_82676" xmi:uuid="2abae110-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="b5f74750-6c42-013d-d60e-0800270c66d6" xmi:uuid="b5f747f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="227" y="662" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="209" y="671" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="665" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623158020743_882918_81292" xmi:uuid="2b190ca0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574857327_282905_75143"/>
      <ownedElement xmi:id="2b1477b0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2b147ab0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574857327_282905_75143"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="2b18ce70-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2b18d000-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574857327_282905_75143"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="105" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623158020750_337838_81323" xmi:uuid="2b757290-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574783299_326518_75135"/>
      <ownedElement xmi:id="2b71a610-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2b71a7a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574783299_326518_75135"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="2b751df0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2b752000-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574783299_326518_75135"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="385" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623158020758_663159_81354" xmi:uuid="2be27ab0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574990873_700250_75159"/>
      <ownedElement xmi:id="2bdd52f0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2bdd5900-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574990873_700250_75159"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="2be20ac0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2be20c80-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622574990873_700250_75159"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623361317438_437920_82798" xmi:uuid="2be25720-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="ba9aa9b0-6c42-013d-d60e-0800270c66d6" xmi:uuid="ba9aaa50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="164" y="730" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="146" y="739" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="735" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623158020765_24896_81385" xmi:uuid="2bf23a00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214522749_245490_69599"/>
      <ownedElement xmi:id="2be9bcf0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2be9be70-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214522749_245490_69599"/>
        <text>Definitions:SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="4e392130-339c-013a-17e4-45cc4a55db9f" xmi:uuid="4e392280-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214522749_245490_69599"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623362789351_85117_84637" xmi:uuid="2bf20090-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
        <ownedElement xmi:id="bb585580-6c42-013d-d60e-0800270c66d6" xmi:uuid="bb585620-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
          <bounds x="220" y="794" width="212" height="13"/>
          <text>slotDefinition : Attachment_slot_definition [1]</text>
        </ownedElement>
        <bounds x="202" y="803" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="798" width="196" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623158103862_742736_81417" xmi:uuid="2f7e24e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623158103837_46892_81416"/>
      <ownedElement xmi:id="2c664650-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2c6647e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623158103837_46892_81416"/>
        <text>attachmentSlotVersion:Attachment_slot_version</text>
      </ownedElement>
      <ownedElement xmi:id="4e9199e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="4e919b50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623158103837_46892_81416"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="bcb3b290-6c42-013d-d60e-0800270c66d6" xmi:uuid="bcb3b320-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bcb4f3e0-6c42-013d-d60e-0800270c66d6" xmi:uuid="bcb4f840-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623158144216_30295_81453" xmi:uuid="2d5156b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-description"/>
          <ownedElement xmi:id="2cd95700-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2cd95860-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="2d511a80-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2d511c20-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="784" y="343" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623158144230_594121_81484" xmi:uuid="2e39b570-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-id"/>
          <ownedElement xmi:id="2dbdd1a0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2dbdd360-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="2e395460-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2e3958d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="784" y="392" width="88" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623158144238_404655_81515" xmi:uuid="2f7de400-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_version-of_product"/>
          <ownedElement xmi:id="2f0ef870-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2f0efa70-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_version-of_product"/>
            <text>of_product:Attachment_slot</text>
          </ownedElement>
          <ownedElement xmi:id="2f7db270-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2f7db4d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_version-of_product"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="784" y="560" width="190" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="763" y="308" width="305" height="287"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623169335418_462018_81575" xmi:uuid="2f7e5660-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623169338213_444675_81576"/>
      <source xmi:idref="_18_4_1_8be0287_1623169221906_537254_81558"/>
      <target xmi:idref="_18_4_1_8be0287_1623158103862_742736_81417"/>
      <waypoint x="1147" y="284"/>
      <waypoint x="1019" y="284"/>
      <waypoint x="1019" y="308"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623348897432_291976_81754" xmi:uuid="2fcc6870-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887958_596343_81702"/>
      <ownedElement xmi:id="2fc87ba0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="2fc87cf0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887958_596343_81702"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360060372_299263_82000" xmi:uuid="2fcb7080-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="c3214a60-6c42-013d-d60e-0800270c66d6" xmi:uuid="c3214b00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="233" y="101" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="287" y="110" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360060383_201355_82010" xmi:uuid="2fcb9c80-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="c3ea0390-6c42-013d-d60e-0800270c66d6" xmi:uuid="c3ea0420-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="315" y="171" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="305" y="153" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360060391_429476_82020" xmi:uuid="2fcc0340-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="c491a250-6c42-013d-d60e-0800270c66d6" xmi:uuid="c491a2e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="371" y="82" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="361" y="98" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360060401_677064_82030" xmi:uuid="2fcc4790-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="c5332fa0-6c42-013d-d60e-0800270c66d6" xmi:uuid="c5333040-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="393" y="171" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="383" y="153" width="15" height="15"/>
      </ownedElement>
      <bounds x="287" y="98" width="245" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623348900876_410663_81774" xmi:uuid="301c6b30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887964_433323_81703"/>
      <ownedElement xmi:id="30185840-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="30185ab0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887964_433323_81703"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="301bd840-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="301bda50-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887964_433323_81703"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360179920_284302_82082" xmi:uuid="301c3a70-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="c6fe3380-6c42-013d-d60e-0800270c66d6" xmi:uuid="c6fe3420-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="647" y="44" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="629" y="53" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="49" width="196" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360252741_174747_82152" xmi:uuid="317ad4c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360254160_309169_82153"/>
      <source xmi:idref="_18_4_1_8be0287_1623158103862_742736_81417"/>
      <target xmi:idref="_18_4_1_8be0287_1623360242446_997592_82114"/>
      <waypoint x="938" y="308"/>
      <waypoint x="938" y="130"/>
      <waypoint x="868" y="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623348903021_179583_81805" xmi:uuid="317b03b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887969_358851_81704"/>
      <ownedElement xmi:id="307cb7e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="307cb960-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887969_358851_81704"/>
        <text>descrAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="30801eb0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="30802040-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887969_358851_81704"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c81c8c20-6c42-013d-d60e-0800270c66d6" xmi:uuid="c81c8cc0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c834e8d0-6c42-013d-d60e-0800270c66d6" xmi:uuid="c834ea00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623360242446_997592_82114" xmi:uuid="317a8340-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="31286f50-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="31288d20-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="317a4500-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="317a46b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="693" y="119" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="623" y="91" width="280" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623348905348_271492_81836" xmi:uuid="31cd2790-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887974_258447_81705"/>
      <ownedElement xmi:id="31c9b760-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="31c9b920-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887974_258447_81705"/>
        <text>descrLang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="31cccba0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="31cccd60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887974_258447_81705"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360449146_147809_82372" xmi:uuid="31cd0d60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="cbac4a40-6c42-013d-d60e-0800270c66d6" xmi:uuid="cbac4af0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="524" y="192" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="506" y="201" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="336" y="196" width="178" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623348907339_54432_81867" xmi:uuid="31d53690-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887977_391741_81706"/>
      <ownedElement xmi:id="31d10fe0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="31d111d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887977_391741_81706"/>
        <text>descrAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="31d4e0d0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="31d4e2d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887977_391741_81706"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="336" y="266" width="228" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623348909618_499576_81898" xmi:uuid="32377b70-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887980_110348_81707"/>
      <ownedElement xmi:id="32336740-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="323368b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887980_110348_81707"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360574540_730307_82387" xmi:uuid="32370690-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="ce04b390-6c42-013d-d60e-0800270c66d6" xmi:uuid="ce04b430-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="156" y="381" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="210" y="390" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360574551_516223_82397" xmi:uuid="323732d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="cec00940-6c42-013d-d60e-0800270c66d6" xmi:uuid="cec00c90-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="374" y="386" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="356" y="395" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360574558_369835_82407" xmi:uuid="32375480-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="cf617250-6c42-013d-d60e-0800270c66d6" xmi:uuid="cf6172e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="241" y="430" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="231" y="412" width="15" height="15"/>
      </ownedElement>
      <bounds x="210" y="378" width="161" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623348911585_561537_81918" xmi:uuid="3290cdc0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887984_369617_81708"/>
      <ownedElement xmi:id="328b7160-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="328b73e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887984_369617_81708"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360613552_329027_82457" xmi:uuid="329086c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="d1691310-6c42-013d-d60e-0800270c66d6" xmi:uuid="d16913b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="427" y="405" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="483" y="397" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360613562_320214_82467" xmi:uuid="3290aea0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="d24c1230-6c42-013d-d60e-0800270c66d6" xmi:uuid="d24c12d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="661" y="385" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="643" y="394" width="15" height="15"/>
      </ownedElement>
      <bounds x="483" y="378" width="175" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623348913795_747769_81938" xmi:uuid="32eab7d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887988_951331_81709"/>
      <ownedElement xmi:id="32e74c10-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="32e74e40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887988_951331_81709"/>
        <text>identifiers:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="32ea4290-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="32ea4460-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887988_951331_81709"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623360723155_856991_82504" xmi:uuid="32ea9b60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="d443fcc0-6c42-013d-d60e-0800270c66d6" xmi:uuid="d443fd50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="444" y="458" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="426" y="467" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="266" y="462" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360794643_823292_82588" xmi:uuid="34781e10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360796453_109087_82589"/>
      <source xmi:idref="_18_4_1_8be0287_1623158103862_742736_81417"/>
      <target xmi:idref="_18_4_1_8be0287_1623360768320_27008_82533"/>
      <waypoint x="763" y="529"/>
      <waypoint x="708" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623348916959_65154_81969" xmi:uuid="347831c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887991_538051_81710"/>
      <ownedElement xmi:id="33529660-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="335297e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887991_538051_81710"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="3359a520-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3359a6a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623348887991_538051_81710"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="d56815e0-6c42-013d-d60e-0800270c66d6" xmi:uuid="d56816b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d5698010-6c42-013d-d60e-0800270c66d6" xmi:uuid="d56980d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623360768320_27008_82533" xmi:uuid="347802d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="341abb20-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="341abcf0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="3477efd0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3477f140-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="525" y="518" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="490" y="490" width="231" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360099518_300487_82055" xmi:uuid="3478a540-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360100924_253590_82056"/>
      <source xmi:idref="_18_4_1_8be0287_1623360060372_299263_82000"/>
      <target xmi:idref="_18_4_1_8be0287_1623158020743_882918_81292"/>
      <waypoint x="287" y="116"/>
      <waypoint x="220" y="116"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360157415_592354_82072" xmi:uuid="34791300-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360158979_831348_82073"/>
      <source xmi:idref="_18_4_1_8be0287_1623348900876_410663_81774"/>
      <target xmi:idref="_18_4_1_8be0287_1623360060391_429476_82020"/>
      <waypoint x="441" y="67"/>
      <waypoint x="368" y="67"/>
      <waypoint x="368" y="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360217017_439085_82104" xmi:uuid="34793870-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360223520_837108_82105"/>
      <source xmi:idref="_18_4_1_8be0287_1623348903021_179583_81805"/>
      <target xmi:idref="_18_4_1_8be0287_1623360179920_284302_82082"/>
      <waypoint x="704" y="91"/>
      <waypoint x="704" y="60"/>
      <waypoint x="644" y="60"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1632386960549_969520_75054" xmi:uuid="583f7d40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632386964481_820613_75055"/>
      <source xmi:idref="_18_4_1_8be0287_1623158103862_742736_81417"/>
      <target xmi:idref="_18_4_1_8be0287_1623360307564_396040_82232"/>
      <waypoint x="938" y="308"/>
      <waypoint x="938" y="242"/>
      <waypoint x="865" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360287690_931583_82170" xmi:uuid="37483000-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360284423_62093_82162"/>
      <ownedElement xmi:id="34c89390-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="34c89500-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360284423_62093_82162"/>
        <text>descrLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="34cb3e80-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="34cb3ff0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360284423_62093_82162"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d8a79520-6c42-013d-d60e-0800270c66d6" xmi:uuid="d8a795c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d8c2c750-6c42-013d-d60e-0800270c66d6" xmi:uuid="d8c2c810-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623360307541_913733_82201" xmi:uuid="3570a8c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="35127480-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="35127580-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="35707ff0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="357081c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="637" y="266" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623360307564_396040_82232" xmi:uuid="365058b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="360ac730-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="360ac8c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="36502b60-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="36502eb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="637" y="231" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623360307580_266040_82263" xmi:uuid="37480ab0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="36ebeec0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="36ebf040-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="3747f010-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3747f180-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="637" y="196" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="623" y="168" width="280" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360351296_202448_82301" xmi:uuid="37485520-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360352499_592800_82302"/>
      <source xmi:idref="_18_4_1_8be0287_1623360307541_913733_82201"/>
      <target xmi:idref="_18_4_1_8be0287_1623348907339_54432_81867"/>
      <waypoint x="637" y="277"/>
      <waypoint x="564" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360381347_833099_82325" xmi:uuid="37487830-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360383245_543215_82326"/>
      <source xmi:idref="_18_4_1_8be0287_1623158144216_30295_81453"/>
      <target xmi:idref="_18_4_1_8be0287_1623360060383_201355_82010"/>
      <waypoint x="784" y="354"/>
      <waypoint x="312" y="354"/>
      <waypoint x="312" y="168"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360403818_336396_82345" xmi:uuid="374895a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360405073_372914_82346"/>
      <source xmi:idref="_18_4_1_8be0287_1623348905348_271492_81836"/>
      <target xmi:idref="_18_4_1_8be0287_1623360060401_677064_82030"/>
      <waypoint x="389" y="196"/>
      <waypoint x="389" y="168"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360409220_609093_82362" xmi:uuid="3748be60-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360409962_615322_82363"/>
      <source xmi:idref="_18_4_1_8be0287_1623360307580_266040_82263"/>
      <target xmi:idref="_18_4_1_8be0287_1623360449146_147809_82372"/>
      <waypoint x="637" y="207"/>
      <waypoint x="521" y="207"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360593842_289500_82430" xmi:uuid="374916d0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360594923_379632_82431"/>
      <source xmi:idref="_18_4_1_8be0287_1623360574540_730307_82387"/>
      <target xmi:idref="_18_4_1_8be0287_1623158020750_337838_81323"/>
      <waypoint x="210" y="396"/>
      <waypoint x="147" y="396"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360598861_776024_82447" xmi:uuid="37494580-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360605478_835066_82448"/>
      <source xmi:idref="_18_4_1_8be0287_1623360613552_329027_82457"/>
      <target xmi:idref="_18_4_1_8be0287_1623360574551_516223_82397"/>
      <waypoint x="483" y="403"/>
      <waypoint x="371" y="403"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360649449_665256_82491" xmi:uuid="37499a90-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360650954_931958_82492"/>
      <source xmi:idref="_18_4_1_8be0287_1623158144230_594121_81484"/>
      <target xmi:idref="_18_4_1_8be0287_1623360613562_320214_82467"/>
      <waypoint x="784" y="403"/>
      <waypoint x="658" y="403"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360741604_612125_82523" xmi:uuid="3749cd50-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360742552_920193_82524"/>
      <source xmi:idref="_18_4_1_8be0287_1623348913795_747769_81938"/>
      <target xmi:idref="_18_4_1_8be0287_1623360574558_369835_82407"/>
      <waypoint x="266" y="473"/>
      <waypoint x="238" y="473"/>
      <waypoint x="238" y="427"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623360789821_359466_82571" xmi:uuid="3749fe00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623360791343_859783_82572"/>
      <source xmi:idref="_18_4_1_8be0287_1623348916959_65154_81969"/>
      <target xmi:idref="_18_4_1_8be0287_1623360723155_856991_82504"/>
      <waypoint x="595" y="490"/>
      <waypoint x="595" y="473"/>
      <waypoint x="441" y="473"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623361218205_393392_82712" xmi:uuid="38a74db0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623361223418_158682_82713"/>
      <source xmi:idref="_18_4_1_8be0287_1623158103862_742736_81417"/>
      <target xmi:idref="_18_4_1_8be0287_1623361139222_948909_82645"/>
      <waypoint x="977" y="595"/>
      <waypoint x="977" y="676"/>
      <waypoint x="639" y="676"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623361107843_887955_82614" xmi:uuid="38a76e50-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623361102081_203491_82598"/>
      <ownedElement xmi:id="379549e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="37954bc0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623361102081_203491_82598"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="37980d70-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="37980f30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623361102081_203491_82598"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="df034b90-6c42-013d-d60e-0800270c66d6" xmi:uuid="df034c30-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="df1d4350-6c42-013d-d60e-0800270c66d6" xmi:uuid="df1d4410-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623361139222_948909_82645" xmi:uuid="38a72a00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="384fb140-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="384fb400-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="38a71150-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="38a712c0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="455" y="665" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="441" y="637" width="292" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623361211402_732102_82695" xmi:uuid="38a78fc0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623361213853_281981_82696"/>
      <source xmi:idref="_18_4_1_8be0287_1623361107843_887955_82614"/>
      <target xmi:idref="_18_4_1_8be0287_1623361171475_342393_82676"/>
      <waypoint x="441" y="679"/>
      <waypoint x="224" y="679"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623361349828_370129_82820" xmi:uuid="3a6eac20-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623361352013_391266_82821"/>
      <source xmi:idref="_18_4_1_8be0287_1623158103862_742736_81417"/>
      <target xmi:idref="_18_4_1_8be0287_1623361277434_748539_82753"/>
      <waypoint x="977" y="595"/>
      <waypoint x="977" y="753"/>
      <waypoint x="678" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623361249876_612177_82722" xmi:uuid="3a6ecb50-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623361102091_265164_82599"/>
      <ownedElement xmi:id="390cde30-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="390cdfb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623361102091_265164_82599"/>
        <text>sameAsItem:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="39106840-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="39106a10-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623361102091_265164_82599"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e1f93fd0-6c42-013d-d60e-0800270c66d6" xmi:uuid="e1f94080-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e1fa7fb0-6c42-013d-d60e-0800270c66d6" xmi:uuid="e1fa8060-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623361277434_748539_82753" xmi:uuid="3a6e81e0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="39dca730-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="39dca9f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="3a6e5c30-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3a6e6270-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="455" y="742" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="441" y="714" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623361305658_548403_82791" xmi:uuid="3a6eeec0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623361307355_171801_82792"/>
      <source xmi:idref="_18_4_1_8be0287_1623361249876_612177_82722"/>
      <target xmi:idref="_18_4_1_8be0287_1623361317438_437920_82798"/>
      <waypoint x="441" y="746"/>
      <waypoint x="161" y="746"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623363014033_425978_84741" xmi:uuid="3c473ce0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623363017359_266222_84742"/>
      <source xmi:idref="_18_4_1_8be0287_1623158103862_742736_81417"/>
      <target xmi:idref="_18_4_1_8be0287_1623362987189_868209_84686"/>
      <waypoint x="977" y="595"/>
      <waypoint x="977" y="823"/>
      <waypoint x="723" y="823"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623362951080_843919_84650" xmi:uuid="3c47a360-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362951064_607871_84649"/>
      <ownedElement xmi:id="3ae89490-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3ae89680-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362951064_607871_84649"/>
        <text>slotDefinition:Attachment_slot_definition</text>
      </ownedElement>
      <ownedElement xmi:id="5ad9bb70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="5ad9bd10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362951064_607871_84649"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e5f48ae0-6c42-013d-d60e-0800270c66d6" xmi:uuid="e5f48b90-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e5f5c830-6c42-013d-d60e-0800270c66d6" xmi:uuid="e5f5c8f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623362987189_868209_84686" xmi:uuid="3c46bb80-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_definition-defined_version"/>
          <ownedElement xmi:id="3bc6df20-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3bc6e1b0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_definition-defined_version"/>
            <text>defined_version:Attachment_slot_version</text>
          </ownedElement>
          <ownedElement xmi:id="3c469c80-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3c469e20-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_definition-defined_version"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="455" y="812" width="268" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="441" y="784" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623363000392_444065_84724" xmi:uuid="3c47d4a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623363002537_681263_84725"/>
      <source xmi:idref="_18_4_1_8be0287_1623362951080_843919_84650"/>
      <target xmi:idref="_18_4_1_8be0287_1623362789351_85117_84637"/>
      <waypoint x="441" y="809"/>
      <waypoint x="217" y="809"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623169221906_537254_81558" xmi:uuid="2a54c750-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623169221863_297479_81554"/>
      <bounds x="1147" y="273" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1643620586219_320130_74516" xmi:uuid="a6a88190-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="df362430-0d32-013c-5e37-5b8e392dc4e5" xmi:uuid="df362550-0d32-013c-5e37-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Rationale</text>
      </ownedElement>
      <ownedElement xmi:id="df3758e0-0d32-013c-5e37-5b8e392dc4e5" xmi:uuid="df375e90-0d32-013c-5e37-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <modelElement href="Slot.xmi#_18_4_1_65b021e_1643620586217_812961_74514"/>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="427" y="560" width="238" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1643620722901_657284_75370" xmi:uuid="a6a88770-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_8be0287_1623158144238_404655_81515"/>
      <target xmi:idref="_18_4_1_65b021e_1643620586219_320130_74516"/>
      <waypoint x="784" y="577"/>
      <waypoint x="665" y="584"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1150" height="863"/>
    <name>SlotVersion</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446411132_305752_347573" xmi:uuid="3b50dce0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411161_56264_347605" xmi:uuid="3cab7d50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362586171_699594_84560"/>
      <ownedElement xmi:id="3c767df0-6c43-013d-d60e-0800270c66d6" xmi:uuid="3c767e80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362586171_699594_84560"/>
        <text>attachmentSlotDefinition:Attachment_slot_definition</text>
      </ownedElement>
      <ownedElement xmi:id="3cab6540-6c43-013d-d60e-0800270c66d6" xmi:uuid="3cab6650-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362586171_699594_84560"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="318" height="1010"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411178_797772_347639" xmi:uuid="3cc3fd50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="1028" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411189_876685_347654" xmi:uuid="3cddc8a0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="1028" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411207_63974_347669" xmi:uuid="3cffec90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="1028" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411217_85304_347684" xmi:uuid="3d0182c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="1028" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411226_999202_347699" xmi:uuid="3d2bbf10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551433642363_802478_36217"/>
      <bounds x="1028" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411236_886881_347714" xmi:uuid="3d4888e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="1028" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411252_571407_347729" xmi:uuid="3d5fc080-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="1028" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411266_964995_347744" xmi:uuid="3d73d330-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="1028" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411275_433290_347759" xmi:uuid="3d758990-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973058873_539759_54381"/>
      <bounds x="1028" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411283_709977_347774" xmi:uuid="3d970a00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973091565_761824_54391"/>
      <bounds x="1028" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411292_921089_347789" xmi:uuid="3dadeb40-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="1028" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411301_155681_347804" xmi:uuid="3dcadfe0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564143467_618360_192628"/>
      <bounds x="1028" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411317_474174_347819" xmi:uuid="3dd87280-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="1028" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411332_655566_347834" xmi:uuid="3de63a10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="1028" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411347_282000_347849" xmi:uuid="3e060740-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="1028" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411362_235002_347864" xmi:uuid="3e0793f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="1028" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411373_301697_347879" xmi:uuid="3e096250-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="1028" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411386_426363_347894" xmi:uuid="3e4ca8b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="1028" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411398_667902_347909" xmi:uuid="3e4e6d20-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973151145_247037_54405"/>
      <bounds x="1028" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411409_504442_347924" xmi:uuid="3e9039c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973215473_235782_54417"/>
      <bounds x="1028" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411418_660194_347939" xmi:uuid="3e91a370-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632389717469_699649_77674"/>
      <bounds x="1028" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411429_295476_347954" xmi:uuid="3eaa3b30-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="1028" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411440_697944_347969" xmi:uuid="3eac68e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="1028" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411450_333699_347984" xmi:uuid="3ef5f040-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="1028" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411460_615202_347999" xmi:uuid="3effc4f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510325553618_189011_33055"/>
      <bounds x="1028" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411477_831942_348014" xmi:uuid="3f14f9c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="1028" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411494_718384_348029" xmi:uuid="3f422770-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="1028" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411506_261367_348044" xmi:uuid="3f5e0910-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="1028" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411515_758361_348059" xmi:uuid="3f5f7b90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564135540_870467_190875"/>
      <bounds x="1028" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411523_890678_348074" xmi:uuid="3f86e270-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317852_610905_217937"/>
      <bounds x="1028" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411532_38946_348089" xmi:uuid="3f9dee50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564141926_556119_192266"/>
      <bounds x="1028" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411541_304906_348104" xmi:uuid="3fb32b80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564137313_718057_191236"/>
      <bounds x="1028" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411549_940693_348119" xmi:uuid="3fca1180-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578048114027_922117_59250"/>
      <bounds x="1028" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411564_142580_348134" xmi:uuid="3fddad10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="1028" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411573_339064_348149" xmi:uuid="4009b120-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643268851717_322008_86077"/>
      <bounds x="1028" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411582_289315_348164" xmi:uuid="4021e1e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643269416144_30883_86580"/>
      <bounds x="1028" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411592_838053_348179" xmi:uuid="402339c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643270131067_298147_86914"/>
      <bounds x="1028" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411606_823800_348194" xmi:uuid="404314a0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="1028" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411617_694807_348209" xmi:uuid="4055ed60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="1028" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411628_704122_348224" xmi:uuid="40684840-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="1028" y="835" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411638_469937_348239" xmi:uuid="407f38d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="1028" y="855" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411648_630347_348254" xmi:uuid="409a55d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="1028" y="875" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411660_166501_348269" xmi:uuid="409bd0f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="1028" y="895" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411670_642255_348284" xmi:uuid="409d1ce0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="1028" y="915" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411681_203968_348299" xmi:uuid="40cdfce0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="1028" y="935" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411693_774913_348314" xmi:uuid="40e20530-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="1028" y="955" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411706_470100_348329" xmi:uuid="40fd5600-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="1028" y="975" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446411716_762034_348344" xmi:uuid="4127bf50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="1028" y="995" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_704547_416042" xmi:uuid="4127d260-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913660_702776_71945"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411178_797772_347639"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="62"/>
      <waypoint x="363" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_234834_416045" xmi:uuid="4127dad0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913726_315410_71961"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411189_876685_347654"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="82"/>
      <waypoint x="363" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_810118_416048" xmi:uuid="4127e260-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913789_935589_71977"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411207_63974_347669"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="102"/>
      <waypoint x="363" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_507597_416051" xmi:uuid="4127e950-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913892_394391_71993"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411217_85304_347684"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="122"/>
      <waypoint x="363" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_741625_416054" xmi:uuid="4127f000-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913994_201833_72009"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411226_999202_347699"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="142"/>
      <waypoint x="363" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_995583_416057" xmi:uuid="4127f9b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914120_327421_72025"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411236_886881_347714"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="162"/>
      <waypoint x="363" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_256903_416060" xmi:uuid="412804f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914217_297104_72041"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411252_571407_347729"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="182"/>
      <waypoint x="363" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_917833_416063" xmi:uuid="41280bf0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914301_106632_72057"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411266_964995_347744"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="202"/>
      <waypoint x="363" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_628411_416066" xmi:uuid="412812d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914373_451326_72073"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411275_433290_347759"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="222"/>
      <waypoint x="363" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_509519_416069" xmi:uuid="41281950-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914432_772252_72089"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411283_709977_347774"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="242"/>
      <waypoint x="363" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_78103_416072" xmi:uuid="41282380-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914495_618796_72105"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411292_921089_347789"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="262"/>
      <waypoint x="363" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_679727_416075" xmi:uuid="41282ac0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601563655_356607_319422"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411301_155681_347804"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="282"/>
      <waypoint x="363" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_68338_416078" xmi:uuid="41283170-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914562_827651_72121"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411317_474174_347819"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="302"/>
      <waypoint x="363" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_46866_416081" xmi:uuid="412838c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914624_18214_72137"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411332_655566_347834"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="322"/>
      <waypoint x="363" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_172662_416084" xmi:uuid="41283f70-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914685_904376_72153"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411347_282000_347849"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="342"/>
      <waypoint x="363" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513321_665239_416087" xmi:uuid="41284610-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914747_922732_72169"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411362_235002_347864"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="362"/>
      <waypoint x="363" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_668987_416090" xmi:uuid="41284d40-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914813_677189_72185"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411373_301697_347879"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="382"/>
      <waypoint x="363" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_83324_416093" xmi:uuid="412854f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914877_699985_72201"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411386_426363_347894"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="402"/>
      <waypoint x="363" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_904101_416096" xmi:uuid="41285b80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147914938_29109_72217"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411398_667902_347909"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="422"/>
      <waypoint x="363" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_662166_416099" xmi:uuid="41286280-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915000_102134_72233"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411409_504442_347924"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="442"/>
      <waypoint x="363" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_33746_416102" xmi:uuid="413ad4b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915058_466450_72249"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411418_660194_347939"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="462"/>
      <waypoint x="363" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_203078_416105" xmi:uuid="413b5e60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915117_805906_72265"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411429_295476_347954"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="482"/>
      <waypoint x="363" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_842139_416108" xmi:uuid="413b6530-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915178_783860_72281"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411440_697944_347969"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="502"/>
      <waypoint x="363" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_619072_416111" xmi:uuid="413b6ae0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915234_202630_72297"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411450_333699_347984"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="522"/>
      <waypoint x="363" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_868762_416114" xmi:uuid="413b7070-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915291_979359_72313"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411460_615202_347999"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="542"/>
      <waypoint x="363" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_474828_416117" xmi:uuid="413b7cf0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915403_419379_72345"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411477_831942_348014"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="562"/>
      <waypoint x="363" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_132617_416120" xmi:uuid="413b8780-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915465_703500_72361"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411494_718384_348029"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="582"/>
      <waypoint x="363" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_915840_416123" xmi:uuid="413b9200-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915526_253805_72377"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411506_261367_348044"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="602"/>
      <waypoint x="363" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_943781_416126" xmi:uuid="413b97c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601563969_462799_319678"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411515_758361_348059"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="622"/>
      <waypoint x="363" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_618191_416129" xmi:uuid="413b9d90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601564092_716186_319694"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411523_890678_348074"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="642"/>
      <waypoint x="363" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_961774_416132" xmi:uuid="413ba450-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601564170_460343_319710"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411532_38946_348089"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="662"/>
      <waypoint x="363" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_585094_416135" xmi:uuid="413ba9d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601564240_750522_319726"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411541_304906_348104"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="682"/>
      <waypoint x="363" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_117533_416138" xmi:uuid="413bafc0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915580_773674_72393"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411549_940693_348119"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="702"/>
      <waypoint x="363" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_673336_416141" xmi:uuid="413bb670-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915638_81009_72409"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411564_142580_348134"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="722"/>
      <waypoint x="363" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_812360_416144" xmi:uuid="413bbc10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915699_798932_72425"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411573_339064_348149"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="742"/>
      <waypoint x="363" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_789653_416147" xmi:uuid="413bc330-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915756_862896_72441"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411582_289315_348164"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="762"/>
      <waypoint x="363" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_979158_416150" xmi:uuid="413bcd70-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915813_344206_72457"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411592_838053_348179"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="782"/>
      <waypoint x="363" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_500964_416153" xmi:uuid="413bd390-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915868_89936_72473"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411606_823800_348194"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="802"/>
      <waypoint x="363" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_909243_416156" xmi:uuid="413bd920-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915924_679265_72489"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411617_694807_348209"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="822"/>
      <waypoint x="363" y="822"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_959786_416159" xmi:uuid="413bdf50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147915983_196208_72505"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411628_704122_348224"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="842"/>
      <waypoint x="363" y="842"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_966705_416162" xmi:uuid="413be4d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916043_318758_72521"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411638_469937_348239"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="862"/>
      <waypoint x="363" y="862"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_272770_416165" xmi:uuid="413be9c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916098_224437_72537"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411648_630347_348254"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="880"/>
      <waypoint x="363" y="880"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_421145_416168" xmi:uuid="413c1bf0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916177_812247_72553"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411660_166501_348269"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="903"/>
      <waypoint x="363" y="903"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_811427_416171" xmi:uuid="413c22b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916256_741033_72569"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411670_642255_348284"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="921"/>
      <waypoint x="363" y="921"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_102109_416174" xmi:uuid="413c2900-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916361_784249_72585"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411681_203968_348299"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="942"/>
      <waypoint x="363" y="942"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_164260_416177" xmi:uuid="413c3100-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916424_1132_72601"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411693_774913_348314"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="963"/>
      <waypoint x="363" y="963"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_622814_416180" xmi:uuid="413c3760-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916507_224277_72617"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411706_470100_348329"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="984"/>
      <waypoint x="363" y="984"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513322_2652_416183" xmi:uuid="413c3db0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916578_363631_72633"/>
      <source xmi:idref="_18_4_1_65b021e_1727446411716_762034_348344"/>
      <target xmi:idref="_18_4_1_65b021e_1727446411161_56264_347605"/>
      <waypoint x="1028" y="1001"/>
      <waypoint x="363" y="1001"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1031" height="1080"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1623362462008_127798_84311" xmi:uuid="3c4933a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1623362691616_579963_84608" xmi:uuid="3c4d1db0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
      <bounds x="1196" y="250" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623362472852_887033_84343" xmi:uuid="3d267af0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618167454_602622_76668"/>
      <ownedElement xmi:id="3d235280-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3d235450-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618167454_602622_76668"/>
        <text>AdditionalContexts:ViewContext</text>
      </ownedElement>
      <ownedElement xmi:id="3d264ac0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3d264c30-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618167454_602622_76668"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623875913333_21659_73237" xmi:uuid="5c4a8dd0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516290047903_693170_38626"/>
        <ownedElement xmi:id="efba6d10-6c42-013d-d60e-0800270c66d6" xmi:uuid="efba6dc0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516290047903_693170_38626"/>
          <bounds x="262" y="1004" width="269" height="13"/>
          <text>additionalView : Additional_view_definition_context [0..1]</text>
        </ownedElement>
        <bounds x="244" y="1013" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="1008" width="238" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623362472860_829609_84374" xmi:uuid="3dc12940-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581244102_258898_75192"/>
      <ownedElement xmi:id="3dbd4e30-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3dbd4fe0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581244102_258898_75192"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="3dc0e990-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3dc0eb00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581244102_258898_75192"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623877153084_980093_74052" xmi:uuid="5c97ddb0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="f1626dc0-6c42-013d-d60e-0800270c66d6" xmi:uuid="f1626e60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="234" y="1171" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="216" y="1180" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="1176" width="210" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623362472866_229361_84405" xmi:uuid="3e03d250-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618235533_875990_76673"/>
      <ownedElement xmi:id="3dfc49c0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3dfc4bd0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618235533_875990_76673"/>
        <text>DefiningGeometry:GeometricModel</text>
      </ownedElement>
      <ownedElement xmi:id="3e032ef0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3e036080-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618235533_875990_76673"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623876425286_63262_73354" xmi:uuid="5cbd7b60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_271a0567_1572451952291_416023_53493"/>
        <ownedElement xmi:id="f525bb50-6c42-013d-d60e-0800270c66d6" xmi:uuid="f525bbf0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_271a0567_1572451952291_416023_53493"/>
          <bounds x="276" y="1053" width="188" height="13"/>
          <text>geometricModel : Geometric_model [1]</text>
        </ownedElement>
        <bounds x="258" y="1062" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="1057" width="252" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623362472874_342161_84436" xmi:uuid="3edbe740-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581189433_540148_75184"/>
      <ownedElement xmi:id="3ed71430-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3ed715f0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581189433_540148_75184"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="3edb5850-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3edb5a90-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581189433_540148_75184"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="91" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623362472880_233325_84467" xmi:uuid="3f7cf240-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581045292_50007_75168"/>
      <ownedElement xmi:id="3f77edf0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3f77ef90-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581045292_50007_75168"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="3f7c9ec0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3f7ca060-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622581045292_50007_75168"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="378" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623362472887_109173_84498" xmi:uuid="3fa86160-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618063083_498516_76663"/>
      <ownedElement xmi:id="3fa4c680-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3fa4cda0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618063083_498516_76663"/>
        <text>InitialContext:ViewContext</text>
      </ownedElement>
      <ownedElement xmi:id="3fa81e00-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="3fa81fb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622618063083_498516_76663"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623876044489_932097_73252" xmi:uuid="5d613760-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516289943404_493045_38585"/>
        <ownedElement xmi:id="f836abb0-6c42-013d-d60e-0800270c66d6" xmi:uuid="f836ac50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516289943404_493045_38585"/>
          <bounds x="220" y="961" width="225" height="13"/>
          <text>initialView : Initial_view_definition_context [0..1]</text>
        </ownedElement>
        <bounds x="202" y="970" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="966" width="196" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623362586194_718187_84561" xmi:uuid="49bd81a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362586171_699594_84560"/>
      <ownedElement xmi:id="405cf5f0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="405cf770-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362586171_699594_84560"/>
        <text>attachmentSlotDefinition:Attachment_slot_definition</text>
      </ownedElement>
      <ownedElement xmi:id="5daac110-339c-013a-17e4-45cc4a55db9f" xmi:uuid="5daac4c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362586171_699594_84560"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="f9317730-6c42-013d-d60e-0800270c66d6" xmi:uuid="f93177e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f99b15e0-6c42-013d-d60e-0800270c66d6" xmi:uuid="f99b1790-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623363188530_29924_84782" xmi:uuid="423e3960-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_contexts"/>
          <ownedElement xmi:id="41d80250-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="41d80460-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_contexts"/>
            <text>additional_contexts:Additional_view_definition_context</text>
          </ownedElement>
          <ownedElement xmi:id="423dbcb0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="423dbe40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_contexts"/>
            <text>[0..*]</text>
          </ownedElement>
          <bounds x="777" y="1015" width="354" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623363188545_925355_84844" xmi:uuid="45035b00-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_definition-defined_version"/>
          <ownedElement xmi:id="449287c0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="44928960-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_definition-defined_version"/>
            <text>defined_version:Attachment_slot_version</text>
          </ownedElement>
          <ownedElement xmi:id="450340f0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="45034270-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_definition-defined_version"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="777" y="1113" width="268" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623363188554_961145_84875" xmi:uuid="45bb24a0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-id"/>
          <ownedElement xmi:id="455c2a90-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="455c2bb0-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="45baf7a0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="45baf990-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="784" y="371" width="100" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623363188562_387776_84906" xmi:uuid="46fa2e70-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
          <ownedElement xmi:id="469a61e0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="469a6440-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
            <text>initial_context:Initial_view_definition_context</text>
          </ownedElement>
          <ownedElement xmi:id="46fa16d0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="46fa1850-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="777" y="973" width="287" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623363188582_460711_84968" xmi:uuid="48c17010-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-primary_shape_representation"/>
          <ownedElement xmi:id="485d3ae0-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="485d3c40-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-primary_shape_representation"/>
            <text>primary_shape_representation:shape_model</text>
          </ownedElement>
          <ownedElement xmi:id="48c14270-b6f6-0139-1753-45cc4a55db9f" xmi:uuid="48c14510-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-primary_shape_representation"/>
            <text>[0..1]</text>
          </ownedElement>
          <bounds x="777" y="1057" width="304" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623843495479_584670_72320" xmi:uuid="61633070-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-name"/>
          <ownedElement xmi:id="610d0880-339c-013a-17e4-45cc4a55db9f" xmi:uuid="610d09c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="61613a60-339c-013a-17e4-45cc4a55db9f" xmi:uuid="61613c40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-name"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="784" y="567" width="121" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1643618733986_998112_71067" xmi:uuid="33bf8770-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_characterization"/>
          <ownedElement xmi:id="33aef8e0-6af0-013a-da2c-3770a1b6a6fd" xmi:uuid="33aefa10-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_characterization"/>
            <text>additional_characterization:String</text>
          </ownedElement>
          <ownedElement xmi:id="33bdc9a0-6af0-013a-da2c-3770a1b6a6fd" xmi:uuid="33bdcaf0-6af0-013a-da2c-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_characterization"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="784" y="322" width="237" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="763" y="294" width="392" height="875"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623362747452_224769_84629" xmi:uuid="49bdb060-b6f6-0139-1753-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362749985_856816_84630"/>
      <source xmi:idref="_18_4_1_8be0287_1623362691616_579963_84608"/>
      <target xmi:idref="_18_4_1_8be0287_1623362586194_718187_84561"/>
      <waypoint x="1196" y="256"/>
      <waypoint x="1068" y="256"/>
      <waypoint x="1068" y="294"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623768447668_77546_71245" xmi:uuid="a7c2d010-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768436995_518729_71185"/>
      <ownedElement xmi:id="61a4ecd0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="61a4ee90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768436995_518729_71185"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623768504945_439292_71420" xmi:uuid="61ab5320-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="07c449b0-6c43-013d-d60e-0800270c66d6" xmi:uuid="07c44a50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="240" y="90" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="294" y="99" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623768504970_273411_71430" xmi:uuid="61acab00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="08d7a190-6c43-013d-d60e-0800270c66d6" xmi:uuid="08d7a290-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="336" y="150" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="326" y="132" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623768504985_163312_71440" xmi:uuid="61ae0410-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="0a368b40-6c43-013d-d60e-0800270c66d6" xmi:uuid="0a368c70-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="335" y="61" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="325" y="77" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623768504998_119531_71450" xmi:uuid="61aeeb60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="0ad43870-6c43-013d-d60e-0800270c66d6" xmi:uuid="0ad43900-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="403" y="150" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="393" y="132" width="15" height="15"/>
      </ownedElement>
      <bounds x="294" y="77" width="259" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623768452766_998093_71265" xmi:uuid="a7cefa90-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768436998_911155_71186"/>
      <ownedElement xmi:id="61d94060-339c-013a-17e4-45cc4a55db9f" xmi:uuid="61d94220-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768436998_911155_71186"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="61dfe4c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="61dfe680-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768436998_911155_71186"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623842940963_85734_70887" xmi:uuid="61e1a330-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="0dd4a320-6c43-013d-d60e-0800270c66d6" xmi:uuid="0dd4a3c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="605" y="24" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="587" y="33" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="406" y="28" width="189" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623843133660_872742_71090" xmi:uuid="630f20f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623843138093_463060_71091"/>
      <source xmi:idref="_18_4_1_8be0287_1623362586194_718187_84561"/>
      <target xmi:idref="_18_4_1_8be0287_1623842967315_980809_70899"/>
      <waypoint x="952" y="294"/>
      <waypoint x="952" y="109"/>
      <waypoint x="840" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623768456919_976093_71296" xmi:uuid="a7fae0f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437000_199744_71187"/>
      <ownedElement xmi:id="621cc5d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="621cc780-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437000_199744_71187"/>
        <text>descrAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="6222b6c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6222b840-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437000_199744_71187"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="0ed6b620-6c43-013d-d60e-0800270c66d6" xmi:uuid="0ed6b6c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0eebd8a0-6c43-013d-d60e-0800270c66d6" xmi:uuid="0eebd970-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623842967315_980809_70899" xmi:uuid="630ca930-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="62c46830-339c-013a-17e4-45cc4a55db9f" xmi:uuid="62c469f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="63096c90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="63096e70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="665" y="98" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="651" y="70" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623768460769_408347_71327" xmi:uuid="a8070ed0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437001_325942_71188"/>
      <ownedElement xmi:id="63b0b360-339c-013a-17e4-45cc4a55db9f" xmi:uuid="63b0b670-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437001_325942_71188"/>
        <text>descrLang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="63be6e00-339c-013a-17e4-45cc4a55db9f" xmi:uuid="63be70b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437001_325942_71188"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623843044721_595753_70964" xmi:uuid="63c0ade0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="128ae1f0-6c43-013d-d60e-0800270c66d6" xmi:uuid="128ae280-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="549" y="164" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="531" y="173" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="364" y="168" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623768465060_486665_71358" xmi:uuid="a80a2600-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437003_480900_71189"/>
      <ownedElement xmi:id="63df3470-339c-013a-17e4-45cc4a55db9f" xmi:uuid="63df3760-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437003_480900_71189"/>
        <text>descrAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="63f8bc10-339c-013a-17e4-45cc4a55db9f" xmi:uuid="63f8be10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437003_480900_71189"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="343" y="210" width="312" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623843462982_69675_72293" xmi:uuid="661c1590-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623843464479_165893_72294"/>
      <source xmi:idref="_18_4_1_8be0287_1623362586194_718187_84561"/>
      <target xmi:idref="_18_4_1_8be0287_1623843075001_493835_71007"/>
      <waypoint x="952" y="294"/>
      <waypoint x="952" y="256"/>
      <waypoint x="893" y="256"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623768469158_961368_71389" xmi:uuid="a869d800-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437009_118169_71194"/>
      <ownedElement xmi:id="6454ff40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="64550120-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437009_118169_71194"/>
        <text>descrLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="645cb3f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="645cb600-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437009_118169_71194"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="13bd4590-6c43-013d-d60e-0800270c66d6" xmi:uuid="13bd4710-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="13d98720-6c43-013d-d60e-0800270c66d6" xmi:uuid="13d987e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623843074985_649955_70976" xmi:uuid="64c01df0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="648e6350-339c-013a-17e4-45cc4a55db9f" xmi:uuid="648e6520-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="64befe40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="64beffe0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="665" y="210" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623843075001_493835_71007" xmi:uuid="65441fb0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="651717b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="65171960-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="65432d90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="65432ec0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="665" y="245" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623843075016_212660_71038" xmi:uuid="661ad120-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="65d93e70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="65d94310-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="66197740-339c-013a-17e4-45cc4a55db9f" xmi:uuid="66197960-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="665" y="175" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="651" y="147" width="276" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623768562370_91175_71475" xmi:uuid="a869e0d0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768565402_718285_71476"/>
      <source xmi:idref="_18_4_1_8be0287_1623768504945_439292_71420"/>
      <target xmi:idref="_18_4_1_8be0287_1623362472874_342161_84436"/>
      <waypoint x="294" y="105"/>
      <waypoint x="227" y="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623843795041_643289_72538" xmi:uuid="66e1bb40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623843795899_652691_72539"/>
      <source xmi:idref="_18_4_1_8be0287_1623362586194_718187_84561"/>
      <target xmi:idref="_18_4_1_8be0287_1623843775151_538448_72483"/>
      <waypoint x="763" y="508"/>
      <waypoint x="638" y="508"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623769440501_643714_73523" xmi:uuid="a895a6b0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437008_647198_71193"/>
      <ownedElement xmi:id="66508460-339c-013a-17e4-45cc4a55db9f" xmi:uuid="665085e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437008_647198_71193"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="665744d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="66574610-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437008_647198_71193"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="19ae85f0-6c43-013d-d60e-0800270c66d6" xmi:uuid="19ae8680-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="19d455e0-6c43-013d-d60e-0800270c66d6" xmi:uuid="19d45670-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623843775151_538448_72483" xmi:uuid="66e08660-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="66acf3c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="66acf560-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="66df3d50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="66df3fa0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="455" y="497" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="441" y="469" width="231" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623769440514_777514_73554" xmi:uuid="a8a17a70-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437006_449297_71191"/>
      <ownedElement xmi:id="67174de0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="67174f30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437006_449297_71191"/>
        <text>identifiers:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="671da390-339c-013a-17e4-45cc4a55db9f" xmi:uuid="671da4e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437006_449297_71191"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623843739857_467653_72454" xmi:uuid="671ef5b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="1d3c9870-6c43-013d-d60e-0800270c66d6" xmi:uuid="1d3c9910-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="397" y="451" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="379" y="460" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="224" y="455" width="163" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623769474628_409166_73605" xmi:uuid="a8ae02a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437005_565845_71190"/>
      <ownedElement xmi:id="6779ebb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6779ed70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623768437005_565845_71190"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623843640152_455771_72354" xmi:uuid="6782af40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="1f08ccd0-6c43-013d-d60e-0800270c66d6" xmi:uuid="1f08cd60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="177" y="374" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="231" y="383" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623843640168_78880_72364" xmi:uuid="6784dc80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="1fd42e00-6c43-013d-d60e-0800270c66d6" xmi:uuid="1fd42e90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="395" y="374" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="377" y="383" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623843640183_583019_72374" xmi:uuid="67867fe0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="20799b60-6c43-013d-d60e-0800270c66d6" xmi:uuid="20799bf0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="265" y="430" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="255" y="412" width="15" height="15"/>
      </ownedElement>
      <bounds x="231" y="371" width="161" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623769625637_532186_73638" xmi:uuid="a8b99ff0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623769559714_915577_73626"/>
      <ownedElement xmi:id="680fe230-339c-013a-17e4-45cc4a55db9f" xmi:uuid="680fe440-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623769559714_915577_73626"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="681715f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="68171a00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623769559714_915577_73626"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="567" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623842923958_35088_70877" xmi:uuid="a8b9a940-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623842925332_354627_70878"/>
      <source xmi:idref="_18_4_1_8be0287_1623768452766_998093_71265"/>
      <target xmi:idref="_18_4_1_8be0287_1623768504985_163312_71440"/>
      <waypoint x="406" y="39"/>
      <waypoint x="333" y="39"/>
      <waypoint x="333" y="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623842976308_118927_70937" xmi:uuid="a8b9b1f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623842977635_727843_70938"/>
      <source xmi:idref="_18_4_1_8be0287_1623768456919_976093_71296"/>
      <target xmi:idref="_18_4_1_8be0287_1623842940963_85734_70887"/>
      <waypoint x="774" y="70"/>
      <waypoint x="774" y="39"/>
      <waypoint x="602" y="39"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623843018055_230500_70954" xmi:uuid="a8b9bf00-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623843019944_156429_70955"/>
      <source xmi:idref="_18_4_1_8be0287_1623768460769_408347_71327"/>
      <target xmi:idref="_18_4_1_8be0287_1623768504998_119531_71450"/>
      <waypoint x="399" y="168"/>
      <waypoint x="399" y="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623843166627_121431_71107" xmi:uuid="a8b9c780-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623843169185_860811_71108"/>
      <source xmi:idref="_18_4_1_8be0287_1623843075016_212660_71038"/>
      <target xmi:idref="_18_4_1_8be0287_1623843044721_595753_70964"/>
      <waypoint x="665" y="182"/>
      <waypoint x="546" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623843185955_724601_71127" xmi:uuid="a8b9cfa0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623843187219_112233_71128"/>
      <source xmi:idref="_18_4_1_8be0287_1623843074985_649955_70976"/>
      <target xmi:idref="_18_4_1_8be0287_1623768465060_486665_71358"/>
      <waypoint x="665" y="224"/>
      <waypoint x="655" y="224"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623843408687_149495_72194" xmi:uuid="a8b9d830-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623843410233_251865_72195"/>
      <source xmi:idref="_18_4_1_65b021e_1643618733986_998112_71067"/>
      <target xmi:idref="_18_4_1_8be0287_1623768504970_273411_71430"/>
      <waypoint x="784" y="333"/>
      <waypoint x="333" y="333"/>
      <waypoint x="333" y="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623843662273_553258_72397" xmi:uuid="a8b9e4e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623843663568_817940_72398"/>
      <source xmi:idref="_18_4_1_8be0287_1623843640152_455771_72354"/>
      <target xmi:idref="_18_4_1_8be0287_1623362472880_233325_84467"/>
      <waypoint x="231" y="389"/>
      <waypoint x="161" y="389"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623843756349_693094_72473" xmi:uuid="a8ba18c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623843757316_49666_72474"/>
      <source xmi:idref="_18_4_1_8be0287_1623769440514_777514_73554"/>
      <target xmi:idref="_18_4_1_8be0287_1623843640183_583019_72374"/>
      <waypoint x="263" y="455"/>
      <waypoint x="263" y="427"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623843789144_828482_72521" xmi:uuid="a8ba20e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623843790579_899235_72522"/>
      <source xmi:idref="_18_4_1_8be0287_1623769440501_643714_73523"/>
      <target xmi:idref="_18_4_1_8be0287_1623843739857_467653_72454"/>
      <waypoint x="441" y="497"/>
      <waypoint x="417" y="497"/>
      <waypoint x="417" y="469"/>
      <waypoint x="394" y="469"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856584020_369688_73082" xmi:uuid="6cfe62d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856585034_563438_73083"/>
      <source xmi:idref="_18_4_1_8be0287_1623362586194_718187_84561"/>
      <target xmi:idref="_18_4_1_8be0287_1623856543377_786636_72993"/>
      <waypoint x="763" y="795"/>
      <waypoint x="704" y="795"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856277101_373195_72592" xmi:uuid="a91a71c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258563_582960_72561"/>
      <ownedElement xmi:id="6a80d030-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6a80d1c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258563_582960_72561"/>
        <text>nameLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="6a87c050-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6a87c200-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258563_582960_72561"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="22bfc4e0-6c43-013d-d60e-0800270c66d6" xmi:uuid="22bfc580-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="22ce9bf0-6c43-013d-d60e-0800270c66d6" xmi:uuid="22ce9cc0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623856543346_930322_72962" xmi:uuid="6b28e280-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="6acc1640-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6acc5cc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="6b227210-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6b229030-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="476" y="819" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623856543377_786636_72993" xmi:uuid="6bd93a30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="6ba78840-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6ba789e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="6bd81800-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6bd819a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="476" y="784" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623856543393_141236_73024" xmi:uuid="6cf81800-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="6c6c57d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6c6c59a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="6cf5a2d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6cf5a430-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="476" y="749" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="455" y="721" width="275" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856277101_144364_72623" xmi:uuid="a9268640-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_507665_72559"/>
      <ownedElement xmi:id="6d720620-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6d720840-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_507665_72559"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="6d788ae0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6d788c20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_507665_72559"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623856768458_485463_73171" xmi:uuid="6d7a4a30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="2aa71d90-6c43-013d-d60e-0800270c66d6" xmi:uuid="2aa71e60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="400" y="859" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="382" y="868" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="238" y="861" width="152" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856277117_435766_72674" xmi:uuid="a9293780-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_877525_72558"/>
      <ownedElement xmi:id="6d8081e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6d8082e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_877525_72558"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="6d869b60-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6d869cc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_877525_72558"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="308" y="686" width="195" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856826719_835816_73207" xmi:uuid="6eaa58e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856828420_819713_73208"/>
      <source xmi:idref="_18_4_1_8be0287_1623362586194_718187_84561"/>
      <target xmi:idref="_18_4_1_8be0287_1623856640049_176725_73140"/>
      <waypoint x="763" y="935"/>
      <waypoint x="644" y="935"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856277132_10524_72705" xmi:uuid="a9549f20-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_755251_72560"/>
      <ownedElement xmi:id="6db9d360-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6db9d4a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_755251_72560"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="6dbfeff0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6dbff310-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_755251_72560"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="2bfb6370-6c43-013d-d60e-0800270c66d6" xmi:uuid="2bfb6470-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2bfcbdf0-6c43-013d-d60e-0800270c66d6" xmi:uuid="2bfcbec0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623856640049_176725_73140" xmi:uuid="6ea7c110-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="6e3b1c50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6e3b1e60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="6ea5e900-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6ea5eeb0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="469" y="917" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="455" y="889" width="271" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856277132_998109_72736" xmi:uuid="a9613420-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_619314_72555"/>
      <ownedElement xmi:id="6ee2a730-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6ee2a900-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_619314_72555"/>
        <text>selectName:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623856332443_556696_72787" xmi:uuid="6ee916f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="2f9f7b50-6c43-013d-d60e-0800270c66d6" xmi:uuid="2f9f7c00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="212" y="563" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="266" y="572" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623856332459_855642_72797" xmi:uuid="6eea0410-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="305c2bb0-6c43-013d-d60e-0800270c66d6" xmi:uuid="305c2c60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="486" y="565" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="468" y="574" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623856332474_4538_72807" xmi:uuid="6eeb5d50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="31269210-6c43-013d-d60e-0800270c66d6" xmi:uuid="312692a0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="299" y="626" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="289" y="608" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623856332490_500246_72817" xmi:uuid="6eec6f00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="31cb4b70-6c43-013d-d60e-0800270c66d6" xmi:uuid="31cb4c00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="394" y="626" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="384" y="608" width="15" height="15"/>
      </ownedElement>
      <bounds x="266" y="560" width="217" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856277148_47623_72756" xmi:uuid="a96d3ad0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_545102_72557"/>
      <ownedElement xmi:id="6f1f4780-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6f1f4950-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_545102_72557"/>
        <text>nameLang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="6f25cc80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6f25cf80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856258547_545102_72557"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623856520196_201945_72950" xmi:uuid="6f271d30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="335735b0-6c43-013d-d60e-0800270c66d6" xmi:uuid="33573660-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="586" y="642" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="568" y="651" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="406" y="644" width="170" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856350087_949633_72842" xmi:uuid="a96d4380-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856350804_331517_72843"/>
      <source xmi:idref="_18_4_1_8be0287_1623856332443_556696_72787"/>
      <target xmi:idref="_18_4_1_8be0287_1623769625637_532186_73638"/>
      <waypoint x="266" y="578"/>
      <waypoint x="202" y="578"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856476434_375157_72923" xmi:uuid="a96d7520-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856477168_625186_72924"/>
      <source xmi:idref="_18_4_1_8be0287_1623856277148_47623_72756"/>
      <target xmi:idref="_18_4_1_8be0287_1623856332490_500246_72817"/>
      <waypoint x="406" y="662"/>
      <waypoint x="385" y="662"/>
      <waypoint x="385" y="623"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856485950_824727_72940" xmi:uuid="a96d7f60-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856486528_413781_72941"/>
      <source xmi:idref="_18_4_1_8be0287_1623856277101_144364_72623"/>
      <target xmi:idref="_18_4_1_8be0287_1623856332474_4538_72807"/>
      <waypoint x="298" y="861"/>
      <waypoint x="298" y="623"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856570698_99593_73062" xmi:uuid="a96d8bc0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856572148_698448_73063"/>
      <source xmi:idref="_18_4_1_8be0287_1623856543393_141236_73024"/>
      <target xmi:idref="_18_4_1_8be0287_1623856520196_201945_72950"/>
      <waypoint x="592" y="749"/>
      <waypoint x="592" y="658"/>
      <waypoint x="583" y="658"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856609641_782406_73099" xmi:uuid="a96d9490-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856612231_810583_73100"/>
      <source xmi:idref="_18_4_1_8be0287_1623856543346_930322_72962"/>
      <target xmi:idref="_18_4_1_8be0287_1623856277117_435766_72674"/>
      <waypoint x="476" y="830"/>
      <waypoint x="385" y="830"/>
      <waypoint x="385" y="711"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623856792146_557627_73190" xmi:uuid="a96d9f60-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623856794112_941128_73191"/>
      <source xmi:idref="_18_4_1_8be0287_1623856277132_10524_72705"/>
      <target xmi:idref="_18_4_1_8be0287_1623856768458_485463_73171"/>
      <waypoint x="578" y="889"/>
      <waypoint x="578" y="875"/>
      <waypoint x="397" y="875"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623875888791_996269_73227" xmi:uuid="a96da7a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623875891739_762426_73228"/>
      <source xmi:idref="_18_4_1_8be0287_1623363188530_29924_84782"/>
      <target xmi:idref="_18_4_1_8be0287_1623875913333_21659_73237"/>
      <waypoint x="777" y="1022"/>
      <waypoint x="259" y="1022"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623876104555_691504_73271" xmi:uuid="a96daf30-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623876106832_379699_73272"/>
      <source xmi:idref="_18_4_1_8be0287_1623363188562_387776_84906"/>
      <target xmi:idref="_18_4_1_8be0287_1623876044489_932097_73252"/>
      <waypoint x="777" y="977"/>
      <waypoint x="217" y="977"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623876439607_873038_73373" xmi:uuid="a96db6c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623876441777_924703_73374"/>
      <source xmi:idref="_18_4_1_8be0287_1623363188582_460711_84968"/>
      <target xmi:idref="_18_4_1_8be0287_1623876425286_63262_73354"/>
      <waypoint x="777" y="1071"/>
      <waypoint x="273" y="1071"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623876869630_168084_73839" xmi:uuid="a979f180-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623876683153_525139_73824"/>
      <ownedElement xmi:id="6f88db70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6f88dd90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623876683153_525139_73824"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="6faa5bb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="6faa5d90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623876683153_525139_73824"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1623877218262_654969_74098" xmi:uuid="6fb19d60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="34f4f290-6c43-013d-d60e-0800270c66d6" xmi:uuid="34f4f330-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="164" y="1248" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="146" y="1257" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="14" y="1253" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623877202379_734728_74088" xmi:uuid="716b8f20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623877205171_378878_74089"/>
      <source xmi:idref="_18_4_1_8be0287_1623362586194_718187_84561"/>
      <target xmi:idref="_18_4_1_8be0287_1623877097650_754395_73990"/>
      <waypoint x="889" y="1169"/>
      <waypoint x="889" y="1201"/>
      <waypoint x="639" y="1201"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623877031709_179871_73888" xmi:uuid="a9a6a500-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623877023160_740486_73870"/>
      <ownedElement xmi:id="70a47150-339c-013a-17e4-45cc4a55db9f" xmi:uuid="70a472a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623877023160_740486_73870"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="70abf7b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="70abf950-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623877023160_740486_73870"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="35dcec00-6c43-013d-d60e-0800270c66d6" xmi:uuid="35dcec90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3604ecf0-6c43-013d-d60e-0800270c66d6" xmi:uuid="3604edc0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623877097650_754395_73990" xmi:uuid="716a62b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="7116ebe0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7116ed50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="7168cc20-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7168ce20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="455" y="1190" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="441" y="1162" width="292" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623877267358_259197_74148" xmi:uuid="7258eed0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623877269698_540194_74149"/>
      <source xmi:idref="_18_4_1_8be0287_1623362586194_718187_84561"/>
      <target xmi:idref="_18_4_1_8be0287_1623877119074_236436_74021"/>
      <waypoint x="889" y="1169"/>
      <waypoint x="889" y="1271"/>
      <waypoint x="678" y="1271"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623877078851_321566_73959" xmi:uuid="a9d298c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623877074264_807785_73951"/>
      <ownedElement xmi:id="71bf05f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="71bf0750-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623877074264_807785_73951"/>
        <text>sameAsItem:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="71c526f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="71c528a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623877074264_807785_73951"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="38f6e170-6c43-013d-d60e-0800270c66d6" xmi:uuid="38f6e210-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="390c2c20-6c43-013d-d60e-0800270c66d6" xmi:uuid="390c2cf0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1623877119074_236436_74021" xmi:uuid="7257a320-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="7228e7b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7228e960-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="725659d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="72565b20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="455" y="1260" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="441" y="1232" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623877194813_801015_74071" xmi:uuid="a9d2ac00-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623877196263_928880_74072"/>
      <source xmi:idref="_18_4_1_8be0287_1623877031709_179871_73888"/>
      <target xmi:idref="_18_4_1_8be0287_1623877153084_980093_74052"/>
      <waypoint x="441" y="1187"/>
      <waypoint x="231" y="1187"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1623877244673_675169_74131" xmi:uuid="a9d2b490-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623877246826_243441_74132"/>
      <source xmi:idref="_18_4_1_8be0287_1623877078851_321566_73959"/>
      <target xmi:idref="_18_4_1_8be0287_1623877218262_654969_74098"/>
      <waypoint x="441" y="1264"/>
      <waypoint x="161" y="1264"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1632388852107_918698_76811" xmi:uuid="a9d2bca0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388853852_210464_76812"/>
      <source xmi:idref="_18_4_1_8be0287_1623363188554_961145_84875"/>
      <target xmi:idref="_18_4_1_8be0287_1623843640168_78880_72364"/>
      <waypoint x="784" y="389"/>
      <waypoint x="392" y="389"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1632388989988_743110_76831" xmi:uuid="a9d2c680-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388991822_242927_76832"/>
      <source xmi:idref="_18_4_1_8be0287_1623843495479_584670_72320"/>
      <target xmi:idref="_18_4_1_8be0287_1623856332459_855642_72797"/>
      <waypoint x="784" y="581"/>
      <waypoint x="483" y="581"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1643620421132_354480_74466" xmi:uuid="a9d2d3e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="e422a4d0-0d32-013c-5e37-5b8e392dc4e5" xmi:uuid="e422a5d0-0d32-013c-5e37-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Rationale</text>
      </ownedElement>
      <ownedElement xmi:id="e423b8c0-0d32-013c-5e37-5b8e392dc4e5" xmi:uuid="e423bc30-0d32-013c-5e37-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <modelElement href="Slot.xmi#_18_4_1_65b021e_1643620421129_719004_74464"/>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="392" y="1085" width="280" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1643620486011_674022_74494" xmi:uuid="a9d2da40-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_8be0287_1623363188545_925355_84844"/>
      <target xmi:idref="_18_4_1_65b021e_1643620421132_354480_74466"/>
      <waypoint x="777" y="1122"/>
      <waypoint x="672" y="1119"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1199" height="1310"/>
    <name>SlotDefinition</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446408913_534255_346454" xmi:uuid="6ac6b360-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408324396_295926_72418"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408939_679359_346486" xmi:uuid="6e23c870-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965812086_661979_71756"/>
      <ownedElement xmi:id="6d7e8d30-6c44-013d-d60e-0800270c66d6" xmi:uuid="6d993ab0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965812086_661979_71756"/>
        <text>slotItem:Product_in_attachment_slot</text>
      </ownedElement>
      <ownedElement xmi:id="6e23b490-6c44-013d-d60e-0800270c66d6" xmi:uuid="6e23b640-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965812086_661979_71756"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="233" height="230"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408955_757162_346520" xmi:uuid="6e362fd0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="657" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408970_640089_346535" xmi:uuid="6e8a1ad0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="657" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408984_451758_346550" xmi:uuid="6f274ce0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="657" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408997_893163_346565" xmi:uuid="6f807710-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="657" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409011_207063_346580" xmi:uuid="6fc9de60-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="657" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409027_423870_346595" xmi:uuid="704a3c80-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="657" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409043_129197_346610" xmi:uuid="706f2e50-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="657" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409058_354173_346625" xmi:uuid="70707fe0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="657" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409068_912055_346640" xmi:uuid="7071de20-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="657" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511600_827209_415856" xmi:uuid="7071ef90-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916665_810864_72712"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408955_757162_346520"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408939_679359_346486"/>
      <waypoint x="657" y="62"/>
      <waypoint x="278" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511600_79526_415859" xmi:uuid="7071f6c0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916746_316985_72728"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408970_640089_346535"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408939_679359_346486"/>
      <waypoint x="657" y="82"/>
      <waypoint x="278" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511600_44856_415862" xmi:uuid="7071fd40-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916826_292920_72744"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408984_451758_346550"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408939_679359_346486"/>
      <waypoint x="657" y="102"/>
      <waypoint x="278" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511600_742780_415865" xmi:uuid="707203a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147916898_115777_72760"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408997_893163_346565"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408939_679359_346486"/>
      <waypoint x="657" y="122"/>
      <waypoint x="278" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511600_463773_415868" xmi:uuid="7093bd60-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147917020_726847_72776"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409011_207063_346580"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408939_679359_346486"/>
      <waypoint x="657" y="142"/>
      <waypoint x="278" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511600_215582_415871" xmi:uuid="7093d3a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147917088_49608_72792"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409027_423870_346595"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408939_679359_346486"/>
      <waypoint x="657" y="162"/>
      <waypoint x="278" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511600_259238_415874" xmi:uuid="7093dc00-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147917155_67872_72808"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409043_129197_346610"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408939_679359_346486"/>
      <waypoint x="657" y="182"/>
      <waypoint x="278" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511600_462291_415877" xmi:uuid="7093e370-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147917232_64107_72824"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409058_354173_346625"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408939_679359_346486"/>
      <waypoint x="657" y="202"/>
      <waypoint x="278" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511600_729925_415880" xmi:uuid="7093ead0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147917308_517897_72840"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409068_912055_346640"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408939_679359_346486"/>
      <waypoint x="657" y="222"/>
      <waypoint x="278" y="222"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="660" height="300"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1624958572207_103899_73163" xmi:uuid="725adef0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214164469_64413_69277"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1624959061628_803779_74162" xmi:uuid="7260e970-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624959061608_830285_74158"/>
      <bounds x="1193" y="279" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624958606182_27967_73195" xmi:uuid="a9d97af0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214554246_243156_69631"/>
      <ownedElement xmi:id="726b2b30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="726b2ce0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214554246_243156_69631"/>
        <text>Slot:SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="72727310-339c-013a-17e4-45cc4a55db9f" xmi:uuid="72727440-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214554246_243156_69631"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624959761732_693020_69927" xmi:uuid="7273e180-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
        <ownedElement xmi:id="42389880-6c43-013d-d60e-0800270c66d6" xmi:uuid="42389920-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
          <bounds x="192" y="493" width="212" height="13"/>
          <text>slotDefinition : Attachment_slot_definition [1]</text>
        </ownedElement>
        <bounds x="174" y="502" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="497" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624958606192_243042_73226" xmi:uuid="a9de4980-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215336167_924885_72386"/>
      <ownedElement xmi:id="72871b50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="72871d10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215336167_924885_72386"/>
        <text>SlotOn:SlotOnSelect</text>
      </ownedElement>
      <ownedElement xmi:id="72aa7590-339c-013a-17e4-45cc4a55db9f" xmi:uuid="72aa7770-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622215336167_924885_72386"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1632389400941_344242_77275" xmi:uuid="72b06cf0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1632389299841_783300_77269"/>
        <ownedElement xmi:id="42f642d0-6c43-013d-d60e-0800270c66d6" xmi:uuid="42f64400-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1632389299841_783300_77269"/>
          <bounds x="199" y="541" width="201" height="13"/>
          <text>slotOnSelect : Product_view_definition [1]</text>
        </ownedElement>
        <bounds x="181" y="550" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="546" width="154" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624958606202_437035_73257" xmi:uuid="a9fa63f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953435_876357_43190"/>
      <ownedElement xmi:id="7366e0e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7366e2c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953435_876357_43190"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624959458702_905403_69771" xmi:uuid="73c6a320-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="45deca00-6c43-013d-d60e-0800270c66d6" xmi:uuid="45decb10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="707" y="303" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="689" y="312" width="15" height="15"/>
      </ownedElement>
      <bounds x="448" y="301" width="256" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624958606222_860910_73277" xmi:uuid="aa1691a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1603908626115_53358_89521"/>
      <ownedElement xmi:id="744955f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="744957c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1603908626115_53358_89521"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624959702440_87342_69883" xmi:uuid="7484d1c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="486efe00-6c43-013d-d60e-0800270c66d6" xmi:uuid="486efea0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="384" y="438" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="366" y="447" width="15" height="15"/>
      </ownedElement>
      <bounds x="224" y="434" width="157" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624959349630_549963_69665" xmi:uuid="7617e890-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624959351190_75218_69666"/>
      <source xmi:idref="_18_4_1_8be0287_1624958966752_425973_74108"/>
      <target xmi:idref="_18_4_1_8be0287_1624959340226_11408_69627"/>
      <waypoint x="844" y="315"/>
      <waypoint x="844" y="109"/>
      <waypoint x="674" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624958824633_736_73904" xmi:uuid="aa536180-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953432_937477_43188"/>
      <ownedElement xmi:id="74fb1380-339c-013a-17e4-45cc4a55db9f" xmi:uuid="74fb1550-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953432_937477_43188"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="753759c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="75375b40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953432_937477_43188"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4aa8e4d0-6c43-013d-d60e-0800270c66d6" xmi:uuid="4aa8e550-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4ac73f10-6c43-013d-d60e-0800270c66d6" xmi:uuid="4ac74000-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624959340226_11408_69627" xmi:uuid="7616c480-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="75c248e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="75c24a10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="76157130-339c-013a-17e4-45cc4a55db9f" xmi:uuid="761576a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="490" y="98" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="392" y="70" width="305" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624959378213_38151_69713" xmi:uuid="77f420c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624959382546_273993_69714"/>
      <source xmi:idref="_18_4_1_8be0287_1624958966752_425973_74108"/>
      <target xmi:idref="_18_4_1_8be0287_1624959369890_694297_69675"/>
      <waypoint x="844" y="315"/>
      <waypoint x="844" y="186"/>
      <waypoint x="679" y="186"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624958824643_684668_73935" xmi:uuid="aa8f56a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953428_893403_43187"/>
      <ownedElement xmi:id="76b50520-339c-013a-17e4-45cc4a55db9f" xmi:uuid="76b506d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953428_893403_43187"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="77072cc0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="77073200-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953428_893403_43187"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4e4032e0-6c43-013d-d60e-0800270c66d6" xmi:uuid="4e4033a0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4e5b68f0-6c43-013d-d60e-0800270c66d6" xmi:uuid="4e5b69b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624959369890_694297_69675" xmi:uuid="77f28990-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="77ad16a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="77ad1ac0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="77f0e500-339c-013a-17e4-45cc4a55db9f" xmi:uuid="77f0e6c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="504" y="175" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="392" y="147" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624959510277_475331_69841" xmi:uuid="792b3280-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624959511990_833952_69842"/>
      <source xmi:idref="_18_4_1_8be0287_1624958966752_425973_74108"/>
      <target xmi:idref="_18_4_1_8be0287_1624959497264_237392_69803"/>
      <waypoint x="805" y="396"/>
      <waypoint x="617" y="396"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624958824653_789458_73966" xmi:uuid="aacb6120-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1603908626108_560808_89520"/>
      <ownedElement xmi:id="785ed6a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="785ed7e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1603908626108_560808_89520"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="78a103c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="78a10550-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1603908626108_560808_89520"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="523c4370-6c43-013d-d60e-0800270c66d6" xmi:uuid="523c44a0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5254d160-6c43-013d-d60e-0800270c66d6" xmi:uuid="5254d220-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624959497264_237392_69803" xmi:uuid="792a0000-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="78fcc630-339c-013a-17e4-45cc4a55db9f" xmi:uuid="78fcc750-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="79290f40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="79291050-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="434" y="385" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="392" y="357" width="314" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624959420211_314963_69761" xmi:uuid="7ad212f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624959422863_23931_69762"/>
      <source xmi:idref="_18_4_1_8be0287_1624958966752_425973_74108"/>
      <target xmi:idref="_18_4_1_8be0287_1624959408888_963812_69723"/>
      <waypoint x="844" y="315"/>
      <waypoint x="844" y="263"/>
      <waypoint x="648" y="263"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624958824653_541479_73997" xmi:uuid="ab08d130-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953433_443016_43189"/>
      <ownedElement xmi:id="797deaa0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="797debe0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953433_443016_43189"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="79ae97c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="79ae99f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953433_443016_43189"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="5610ef00-6c43-013d-d60e-0800270c66d6" xmi:uuid="5610ef90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5628fd40-6c43-013d-d60e-0800270c66d6" xmi:uuid="5628fe20-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624959408888_963812_69723" xmi:uuid="7ace3a30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="7a39da10-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7a39dbe0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="7ac115e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7ac11800-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="420" y="252" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="392" y="224" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624958920585_866085_74087" xmi:uuid="ab154140-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624958915414_865462_74085"/>
      <ownedElement xmi:id="7b5aa9a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7b5aac10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624958915414_865462_74085"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624959548726_736843_69851" xmi:uuid="7b6a2c00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="59c1b410-6c43-013d-d60e-0800270c66d6" xmi:uuid="59c1b4c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="713" y="436" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="695" y="445" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624959724476_293213_69895" xmi:uuid="7b6b9c70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="5a655f10-6c43-013d-d60e-0800270c66d6" xmi:uuid="5a655fb0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="485" y="437" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="539" y="446" width="15" height="15"/>
      </ownedElement>
      <bounds x="539" y="434" width="171" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624958966752_425973_74108" xmi:uuid="ab9fbd80-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624958966732_694389_74107"/>
      <ownedElement xmi:id="7ba5e170-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7ba5e360-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624958966732_694389_74107"/>
        <text>slotOnProd:Attachment_slot_on_product</text>
      </ownedElement>
      <ownedElement xmi:id="7baca140-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7baca2e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624958966732_694389_74107"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="5b9ac3e0-6c43-013d-d60e-0800270c66d6" xmi:uuid="5b9ac480-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5bb92d10-6c43-013d-d60e-0800270c66d6" xmi:uuid="5bb92dc0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624959263936_669098_69472" xmi:uuid="7c68a0d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-attachment_slot"/>
          <ownedElement xmi:id="7c18bb50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7c18bcf0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-attachment_slot"/>
            <text>attachment_slot:Attachment_slot_definition</text>
          </ownedElement>
          <ownedElement xmi:id="7c6724f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7c672650-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-attachment_slot"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="819" y="497" width="277" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624959263971_917522_69503" xmi:uuid="7cf176f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-description"/>
          <ownedElement xmi:id="7caa3c90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7caa3ef0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="7cefc550-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7cefc6f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="819" y="350" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624959263982_103594_69534" xmi:uuid="7dcc24e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-id"/>
          <ownedElement xmi:id="7d3f40f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7d3f42f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="7dca9430-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7dca95c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="819" y="441" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624959264017_187522_69565" xmi:uuid="7e718320-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-name"/>
          <ownedElement xmi:id="7e103f90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7e104200-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="7e704310-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7e704450-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="819" y="609" width="103" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624959264047_322942_69596" xmi:uuid="7f0a35a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-product"/>
          <ownedElement xmi:id="7ed59da0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7ed59f90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-product"/>
            <text>product:Product_view_definition</text>
          </ownedElement>
          <ownedElement xmi:id="7f0894f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7f0896c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_on_product-product"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="819" y="553" width="215" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="805" y="315" width="305" height="329"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624959251823_967672_69465" xmi:uuid="ab9fca30-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624959253414_302832_69466"/>
      <source xmi:idref="_18_4_1_8be0287_1624959061628_803779_74162"/>
      <target xmi:idref="_18_4_1_8be0287_1624958966752_425973_74108"/>
      <waypoint x="1193" y="287"/>
      <waypoint x="980" y="287"/>
      <waypoint x="980" y="315"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624959475626_507984_69790" xmi:uuid="ab9fd690-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624959476746_97768_69791"/>
      <source xmi:idref="_18_4_1_8be0287_1624959263971_917522_69503"/>
      <target xmi:idref="_18_4_1_8be0287_1624959458702_905403_69771"/>
      <waypoint x="819" y="361"/>
      <waypoint x="753" y="361"/>
      <waypoint x="753" y="319"/>
      <waypoint x="704" y="319"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624959563368_979353_69870" xmi:uuid="ab9fe660-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624959564878_840887_69871"/>
      <source xmi:idref="_18_4_1_8be0287_1624959263982_103594_69534"/>
      <target xmi:idref="_18_4_1_8be0287_1624959548726_736843_69851"/>
      <waypoint x="819" y="452"/>
      <waypoint x="710" y="452"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624959732038_735250_69914" xmi:uuid="ab9feda0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624959733358_942635_69915"/>
      <source xmi:idref="_18_4_1_8be0287_1624959724476_293213_69895"/>
      <target xmi:idref="_18_4_1_8be0287_1624959702440_87342_69883"/>
      <waypoint x="539" y="455"/>
      <waypoint x="381" y="455"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624959773153_144116_69946" xmi:uuid="ab9ff670-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624959775598_157261_69947"/>
      <source xmi:idref="_18_4_1_8be0287_1624959263936_669098_69472"/>
      <target xmi:idref="_18_4_1_8be0287_1624959761732_693020_69927"/>
      <waypoint x="819" y="508"/>
      <waypoint x="189" y="508"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964679925_836764_70873" xmi:uuid="ababd130-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_152261_70832"/>
      <ownedElement xmi:id="7f3a77c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7f3a7900-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_152261_70832"/>
        <text>lang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="7f4075b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7f407af0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_152261_70832"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624964903385_584810_71245" xmi:uuid="7f423170-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="6468b6f0-6c43-013d-d60e-0800270c66d6" xmi:uuid="6468b780-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="437" y="730" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="419" y="739" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="280" y="735" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965220622_587011_71488" xmi:uuid="81a09b20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965222602_989681_71489"/>
      <source xmi:idref="_18_4_1_8be0287_1624958966752_425973_74108"/>
      <target xmi:idref="_18_4_1_8be0287_1624965168287_62558_71382"/>
      <waypoint x="949" y="644"/>
      <waypoint x="949" y="886"/>
      <waypoint x="809" y="886"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964679935_643545_70904" xmi:uuid="ac0b2450-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_608944_70836"/>
      <ownedElement xmi:id="7f91e320-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7f91e480-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_608944_70836"/>
        <text>nameLang:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="7f987980-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7f987f90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_608944_70836"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="657eb680-6c43-013d-d60e-0800270c66d6" xmi:uuid="657eb720-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="6596e450-6c43-013d-d60e-0800270c66d6" xmi:uuid="6596e520-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624965168277_673538_71351" xmi:uuid="8053d2a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="7ff2bd70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="7ff2c250-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="80528a50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="80528be0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="581" y="910" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624965168287_62558_71382" xmi:uuid="80f78ab0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="80c849f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="80c84bb0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="80f63b00-339c-013a-17e4-45cc4a55db9f" xmi:uuid="80f63d50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="581" y="875" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624965168307_809495_71413" xmi:uuid="819f3840-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="815059b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="81505b00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="819d8ea0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="819d9060-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="581" y="840" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="567" y="812" width="270" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964679945_631950_70935" xmi:uuid="ac187d40-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668261_721687_70831"/>
      <ownedElement xmi:id="82047e80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="82048050-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668261_721687_70831"/>
        <text>nameSelect:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624964724356_2035_71099" xmi:uuid="820b72d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="6bf7a820-6c43-013d-d60e-0800270c66d6" xmi:uuid="6bf7a8f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="219" y="598" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="273" y="607" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624964724376_577310_71109" xmi:uuid="820cf440-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="6d015010-6c43-013d-d60e-0800270c66d6" xmi:uuid="6d0150b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="488" y="600" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="470" y="609" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624964724386_343534_71119" xmi:uuid="820e5ee0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="6dca7e60-6c43-013d-d60e-0800270c66d6" xmi:uuid="6dca7f00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="426" y="654" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="416" y="636" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624964724396_142915_71129" xmi:uuid="820fcf20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="6e6b1f30-6c43-013d-d60e-0800270c66d6" xmi:uuid="6e6b2060-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="321" y="654" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="311" y="636" width="15" height="15"/>
      </ownedElement>
      <bounds x="273" y="595" width="212" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964679955_309822_70955" xmi:uuid="ac246fa0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_549044_70833"/>
      <ownedElement xmi:id="824863a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="82486730-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_549044_70833"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="824e9730-339c-013a-17e4-45cc4a55db9f" xmi:uuid="824e9880-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_549044_70833"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624965091397_133583_71305" xmi:uuid="824fe400-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="700ae930-6c43-013d-d60e-0800270c66d6" xmi:uuid="700ae9c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="577" y="682" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="559" y="691" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="406" y="686" width="161" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965127269_937191_71341" xmi:uuid="838e0960-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965129531_859771_71342"/>
      <source xmi:idref="_18_4_1_8be0287_1624958966752_425973_74108"/>
      <target xmi:idref="_18_4_1_8be0287_1624965073994_232901_71274"/>
      <waypoint x="949" y="644"/>
      <waypoint x="949" y="774"/>
      <waypoint x="826" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964679955_934928_70986" xmi:uuid="ac506760-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_332931_70834"/>
      <ownedElement xmi:id="82981b60-339c-013a-17e4-45cc4a55db9f" xmi:uuid="82981ca0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_332931_70834"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="829fe720-339c-013a-17e4-45cc4a55db9f" xmi:uuid="829ff0b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_332931_70834"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="71002050-6c43-013d-d60e-0800270c66d6" xmi:uuid="71002120-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="71141e30-6c43-013d-d60e-0800270c66d6" xmi:uuid="71141f00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624965073994_232901_71274" xmi:uuid="838cbe20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="832975b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="83297750-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="838b6340-339c-013a-17e4-45cc4a55db9f" xmi:uuid="838b6500-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="651" y="763" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="567" y="735" width="271" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964679965_863037_71017" xmi:uuid="ac5c9d50-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_411759_70835"/>
      <ownedElement xmi:id="83c2c2f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="83c2c4a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_411759_70835"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624964784809_672365_71164" xmi:uuid="83c8bd00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="74def9b0-6c43-013d-d60e-0800270c66d6" xmi:uuid="74defa60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="511" y="622" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="574" y="611" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624964784819_385676_71174" xmi:uuid="83c9fe00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="75805160-6c43-013d-d60e-0800270c66d6" xmi:uuid="75805230-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="769" y="602" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="751" y="611" width="15" height="15"/>
      </ownedElement>
      <bounds x="574" y="595" width="192" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964679965_16243_71037" xmi:uuid="ac5f81c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_672603_70837"/>
      <ownedElement xmi:id="83d0f410-339c-013a-17e4-45cc4a55db9f" xmi:uuid="83d0f5b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_672603_70837"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="83d67670-339c-013a-17e4-45cc4a55db9f" xmi:uuid="83d67980-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964668271_672603_70837"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="301" y="910" width="207" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964684197_339564_71068" xmi:uuid="ac6bae50-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964438438_221877_70789"/>
      <ownedElement xmi:id="84099f90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8409a770-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964438438_221877_70789"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="841114b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="84111650-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964438438_221877_70789"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="602" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964757304_366891_71154" xmi:uuid="ac6bbaa0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964759474_975415_71155"/>
      <source xmi:idref="_18_4_1_8be0287_1624964724356_2035_71099"/>
      <target xmi:idref="_18_4_1_8be0287_1624964684197_339564_71068"/>
      <waypoint x="273" y="613"/>
      <waypoint x="209" y="613"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964825167_885289_71195" xmi:uuid="ac6bc440-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964827258_749777_71196"/>
      <source xmi:idref="_18_4_1_8be0287_1624964784809_672365_71164"/>
      <target xmi:idref="_18_4_1_8be0287_1624964724376_577310_71109"/>
      <waypoint x="574" y="616"/>
      <waypoint x="485" y="616"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964832421_863577_71215" xmi:uuid="ac6bd030-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964833721_153065_71216"/>
      <source xmi:idref="_18_4_1_8be0287_1624959264017_187522_69565"/>
      <target xmi:idref="_18_4_1_8be0287_1624964784819_385676_71174"/>
      <waypoint x="819" y="620"/>
      <waypoint x="766" y="620"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964872259_586978_71235" xmi:uuid="ac6bdde0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964873110_570124_71236"/>
      <source xmi:idref="_18_4_1_8be0287_1624964679955_309822_70955"/>
      <target xmi:idref="_18_4_1_8be0287_1624964724386_343534_71119"/>
      <waypoint x="424" y="686"/>
      <waypoint x="424" y="651"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624964915726_662925_71264" xmi:uuid="ac6be6e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624964916936_870848_71265"/>
      <source xmi:idref="_18_4_1_8be0287_1624964679925_836764_70873"/>
      <target xmi:idref="_18_4_1_8be0287_1624964724396_142915_71129"/>
      <waypoint x="319" y="735"/>
      <waypoint x="319" y="651"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965120077_172494_71324" xmi:uuid="ac6bf590-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965122028_450178_71325"/>
      <source xmi:idref="_18_4_1_8be0287_1624964679955_934928_70986"/>
      <target xmi:idref="_18_4_1_8be0287_1624965091397_133583_71305"/>
      <waypoint x="683" y="735"/>
      <waypoint x="683" y="700"/>
      <waypoint x="574" y="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965207289_658277_71451" xmi:uuid="ac6bfdf0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965207929_603276_71452"/>
      <source xmi:idref="_18_4_1_8be0287_1624965168277_673538_71351"/>
      <target xmi:idref="_18_4_1_8be0287_1624964679965_16243_71037"/>
      <waypoint x="581" y="921"/>
      <waypoint x="508" y="921"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965213610_106058_71468" xmi:uuid="ac6c0dc0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965216241_703311_71469"/>
      <source xmi:idref="_18_4_1_8be0287_1624965168307_809495_71413"/>
      <target xmi:idref="_18_4_1_8be0287_1624964903385_584810_71245"/>
      <waypoint x="581" y="851"/>
      <waypoint x="487" y="851"/>
      <waypoint x="487" y="749"/>
      <waypoint x="434" y="749"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625030197451_238706_74068" xmi:uuid="ac6c15e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1571651889195_770640_42366"/>
      <bounds x="273" y="21" width="113" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1632389416856_459453_77294" xmi:uuid="ac6c2140-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632389419155_63975_77295"/>
      <source xmi:idref="_18_4_1_8be0287_1624959264047_322942_69596"/>
      <target xmi:idref="_18_4_1_8be0287_1632389400941_344242_77275"/>
      <waypoint x="819" y="557"/>
      <waypoint x="196" y="557"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1196" height="994"/>
    <name>SlotOn</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446406553_96571_345532" xmi:uuid="74ad0490-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535729628_957239_73706"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406613_39611_345565" xmi:uuid="7985b260-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029491836_413270_72124"/>
      <ownedElement xmi:id="78ec6a40-6c44-013d-d60e-0800270c66d6" xmi:uuid="78f59280-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029491836_413270_72124"/>
        <text>theSlot:Attachment_slot_as_planned</text>
      </ownedElement>
      <ownedElement xmi:id="798488b0-6c44-013d-d60e-0800270c66d6" xmi:uuid="79850310-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029491836_413270_72124"/>
        <text>[0..1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="245" height="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406632_960880_345599" xmi:uuid="79a8be90-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="608" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406644_818693_345614" xmi:uuid="7a764c40-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="608" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406661_721921_345629" xmi:uuid="7aa44220-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="608" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406671_695724_345644" xmi:uuid="7afb8a20-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="608" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406681_102945_345659" xmi:uuid="7b9833d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="608" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406691_637865_345674" xmi:uuid="7bdb5c00-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="608" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406703_203512_345689" xmi:uuid="7c13a510-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="608" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406724_203615_345704" xmi:uuid="7c347b40-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="608" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406738_148311_345719" xmi:uuid="7cb32060-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="608" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406749_230399_345734" xmi:uuid="7d15b8f0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="608" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406765_983093_345749" xmi:uuid="7d19cfa0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="608" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406780_103804_345764" xmi:uuid="7d90d610-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="608" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406796_412984_345779" xmi:uuid="7df6fc70-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="608" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406812_274733_345794" xmi:uuid="7e308450-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="608" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406823_198106_345809" xmi:uuid="7ea6cb80-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="608" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406838_524552_345824" xmi:uuid="7ef7bf10-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="608" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406849_478444_345839" xmi:uuid="7f83c830-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="608" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406861_935107_345854" xmi:uuid="7faca940-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="608" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406873_310413_345869" xmi:uuid="804e4070-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="608" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406891_261579_345884" xmi:uuid="80f851e0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="608" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406911_797502_345899" xmi:uuid="818aaae0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="608" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406925_647517_345914" xmi:uuid="82110c50-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="608" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406943_94984_345929" xmi:uuid="82593070-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="608" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406954_875551_345944" xmi:uuid="82a399b0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643268851717_322008_86077"/>
      <bounds x="608" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406966_393594_345959" xmi:uuid="82ce77d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643269416144_30883_86580"/>
      <bounds x="608" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446406976_673957_345974" xmi:uuid="834fcde0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643270131067_298147_86914"/>
      <bounds x="608" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408561_541272_345989" xmi:uuid="83fa3530-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="608" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408574_854781_346004" xmi:uuid="848a0e60-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="608" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408585_969025_346019" xmi:uuid="850dd1d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="608" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408595_146980_346034" xmi:uuid="85e75dc0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="608" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408604_942278_346049" xmi:uuid="86ff93d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="608" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408613_708225_346064" xmi:uuid="87ad4080-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="608" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408623_180081_346079" xmi:uuid="8847de80-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="608" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408635_198635_346094" xmi:uuid="88d4beb0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="608" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408645_560559_346109" xmi:uuid="892e1ac0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="608" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408656_522795_346124" xmi:uuid="89e7ba90-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="608" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408668_873027_346139" xmi:uuid="8a943300-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="608" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408676_483723_346154" xmi:uuid="8b1c6d30-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570204497794_443467_105732"/>
      <bounds x="608" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408685_468431_346169" xmi:uuid="8b7985a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="608" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_347357_415697" xmi:uuid="8b9e4b00-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601568260_682274_321278"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406632_960880_345599"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="62"/>
      <waypoint x="290" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_77629_415700" xmi:uuid="8b9e5390-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601568349_335625_321294"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406644_818693_345614"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="82"/>
      <waypoint x="290" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_826002_415703" xmi:uuid="8b9e5b30-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601568430_934273_321310"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406661_721921_345629"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="102"/>
      <waypoint x="290" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_858714_415706" xmi:uuid="8b9e6230-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601568510_631409_321326"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406671_695724_345644"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="122"/>
      <waypoint x="290" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_414812_415709" xmi:uuid="8b9e68d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601568582_875805_321342"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406681_102945_345659"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="142"/>
      <waypoint x="290" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_450316_415712" xmi:uuid="8b9e6fc0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601568658_579572_321358"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406691_637865_345674"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="162"/>
      <waypoint x="290" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_613092_415715" xmi:uuid="8b9e74e0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601568735_664819_321374"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406703_203512_345689"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="182"/>
      <waypoint x="290" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_484545_415718" xmi:uuid="8b9e7c00-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601568811_489219_321390"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406724_203615_345704"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="202"/>
      <waypoint x="290" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_700000_415721" xmi:uuid="8b9e8290-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601568891_650488_321406"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406738_148311_345719"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="222"/>
      <waypoint x="290" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_260579_415724" xmi:uuid="8b9e8910-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601568968_669761_321422"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406749_230399_345734"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="242"/>
      <waypoint x="290" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_136723_415727" xmi:uuid="8b9e8fc0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569044_53880_321438"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406765_983093_345749"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="262"/>
      <waypoint x="290" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_207338_415730" xmi:uuid="8b9e96a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569125_236585_321454"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406780_103804_345764"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="282"/>
      <waypoint x="290" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_596986_415733" xmi:uuid="8b9e9d20-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569208_898616_321470"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406796_412984_345779"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="302"/>
      <waypoint x="290" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_281430_415736" xmi:uuid="8b9ea3c0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569293_166713_321486"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406812_274733_345794"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="322"/>
      <waypoint x="290" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_428497_415739" xmi:uuid="8b9eaa70-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569380_191535_321502"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406823_198106_345809"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="342"/>
      <waypoint x="290" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_316281_415742" xmi:uuid="8b9eb110-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569454_604470_321518"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406838_524552_345824"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="362"/>
      <waypoint x="290" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_993915_415745" xmi:uuid="8b9eb7c0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569534_353362_321534"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406849_478444_345839"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="382"/>
      <waypoint x="290" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_262029_415748" xmi:uuid="8b9ebe90-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569609_417144_321550"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406861_935107_345854"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="402"/>
      <waypoint x="290" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_757299_415751" xmi:uuid="8b9ec5d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569688_899368_321566"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406873_310413_345869"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="422"/>
      <waypoint x="290" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_154392_415754" xmi:uuid="8b9ecc50-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569764_654_321582"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406891_261579_345884"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="442"/>
      <waypoint x="290" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_949086_415757" xmi:uuid="8b9ed2b0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569847_370034_321598"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406911_797502_345899"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="462"/>
      <waypoint x="290" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_76218_415760" xmi:uuid="8b9ed8e0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601569931_335211_321614"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406925_647517_345914"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="482"/>
      <waypoint x="290" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_297275_415763" xmi:uuid="8b9edf10-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570009_511718_321630"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406943_94984_345929"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="502"/>
      <waypoint x="290" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_363794_415766" xmi:uuid="8b9ee3d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570093_290986_321646"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406954_875551_345944"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="522"/>
      <waypoint x="290" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_401474_415769" xmi:uuid="8b9ee970-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570165_707317_321662"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406966_393594_345959"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="542"/>
      <waypoint x="290" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_631840_415772" xmi:uuid="8b9eef50-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570240_183768_321678"/>
      <source xmi:idref="_18_4_1_65b021e_1727446406976_673957_345974"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="562"/>
      <waypoint x="290" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_456580_415775" xmi:uuid="8b9ef530-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570319_656933_321694"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408561_541272_345989"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="582"/>
      <waypoint x="290" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_601231_415778" xmi:uuid="8b9efae0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570397_580635_321710"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408574_854781_346004"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="602"/>
      <waypoint x="290" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_919584_415781" xmi:uuid="8b9f0150-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570480_308532_321726"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408585_969025_346019"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="622"/>
      <waypoint x="290" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_201236_415784" xmi:uuid="8b9f07e0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570558_355612_321742"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408595_146980_346034"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="642"/>
      <waypoint x="290" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_431823_415787" xmi:uuid="8b9f0d90-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570631_38614_321758"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408604_942278_346049"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="662"/>
      <waypoint x="290" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_456973_415790" xmi:uuid="8b9f13a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570718_995339_321774"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408613_708225_346064"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="682"/>
      <waypoint x="290" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_544263_415793" xmi:uuid="8b9f1990-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570796_82876_321790"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408623_180081_346079"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="702"/>
      <waypoint x="290" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511578_470953_415796" xmi:uuid="8b9f2030-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570874_154733_321806"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408635_198635_346094"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="722"/>
      <waypoint x="290" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511579_89236_415799" xmi:uuid="8b9f2680-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601570952_216872_321822"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408645_560559_346109"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="742"/>
      <waypoint x="290" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511579_557273_415802" xmi:uuid="8b9f2de0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601571027_462654_321838"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408656_522795_346124"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="762"/>
      <waypoint x="290" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511579_51611_415805" xmi:uuid="8b9f3470-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601571103_686682_321854"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408668_873027_346139"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="782"/>
      <waypoint x="290" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511579_715203_415808" xmi:uuid="8b9f3b00-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601571180_577565_321870"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408676_483723_346154"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="802"/>
      <waypoint x="290" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511579_528518_415811" xmi:uuid="8b9f3fe0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601571256_389573_321886"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408685_468431_346169"/>
      <target xmi:idref="_18_4_1_65b021e_1727446406613_39611_345565"/>
      <waypoint x="608" y="822"/>
      <waypoint x="290" y="822"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="611" height="900"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446416097_962858_350303" xmi:uuid="76e48d80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214164469_64413_69277"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416125_734938_350335" xmi:uuid="77ce3780-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624958966732_694389_74107"/>
      <ownedElement xmi:id="77b34660-6c43-013d-d60e-0800270c66d6" xmi:uuid="77b34760-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624958966732_694389_74107"/>
        <text>slotOnProd:Attachment_slot_on_product</text>
      </ownedElement>
      <ownedElement xmi:id="77ce2600-6c43-013d-d60e-0800270c66d6" xmi:uuid="77ce26d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624958966732_694389_74107"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="257" height="330"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416141_89768_350369" xmi:uuid="77f5b0d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="622" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416156_379306_350384" xmi:uuid="780703f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="622" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416172_694987_350399" xmi:uuid="78085a20-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="622" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416186_278596_350414" xmi:uuid="7809a990-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="622" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416200_447931_350429" xmi:uuid="7852f6f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="622" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416213_501462_350444" xmi:uuid="785f7af0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="622" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416227_138102_350459" xmi:uuid="786f02a0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="622" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416239_997802_350474" xmi:uuid="787e4470-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="622" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416255_438706_350489" xmi:uuid="78991270-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="622" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416271_120612_350504" xmi:uuid="78b47160-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="622" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416286_583360_350519" xmi:uuid="78c87c90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="622" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416296_892654_350534" xmi:uuid="78e6d030-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="622" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416306_376980_350549" xmi:uuid="79068600-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="622" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416315_679755_350564" xmi:uuid="7907e560-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="622" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_497575_416525" xmi:uuid="7907f790-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919596_844865_73493"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416141_89768_350369"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="62"/>
      <waypoint x="302" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_72853_416528" xmi:uuid="79080000-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919658_410367_73509"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416156_379306_350384"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="82"/>
      <waypoint x="302" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_811176_416531" xmi:uuid="79080640-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919726_851918_73525"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416172_694987_350399"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="102"/>
      <waypoint x="302" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_106575_416534" xmi:uuid="79080eb0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919788_238067_73541"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416186_278596_350414"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="122"/>
      <waypoint x="302" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_210645_416537" xmi:uuid="79221b70-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919846_167954_73557"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416200_447931_350429"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="142"/>
      <waypoint x="302" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_604122_416540" xmi:uuid="79222f60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919914_492280_73573"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416213_501462_350444"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="162"/>
      <waypoint x="302" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_363489_416543" xmi:uuid="792239c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147919971_725695_73589"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416227_138102_350459"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="182"/>
      <waypoint x="302" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_757151_416546" xmi:uuid="792247b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920031_650587_73605"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416239_997802_350474"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="202"/>
      <waypoint x="302" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_133987_416549" xmi:uuid="792254a0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920089_612282_73621"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416255_438706_350489"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="222"/>
      <waypoint x="302" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_630760_416552" xmi:uuid="79225d60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920146_5640_73637"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416271_120612_350504"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="242"/>
      <waypoint x="302" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_961101_416555" xmi:uuid="79226560-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920204_453071_73653"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416286_583360_350519"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="262"/>
      <waypoint x="302" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_833926_416558" xmi:uuid="79226d80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920263_173945_73669"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416296_892654_350534"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="282"/>
      <waypoint x="302" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_294291_416561" xmi:uuid="792274f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920318_45417_73685"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416306_376980_350549"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="302"/>
      <waypoint x="302" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513400_187560_416564" xmi:uuid="79227c10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920375_854653_73701"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416315_679755_350564"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416125_734938_350335"/>
      <waypoint x="622" y="322"/>
      <waypoint x="302" y="322"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="625" height="400"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1624274993648_600552_74646" xmi:uuid="8416a140-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214197111_257229_69320"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277261877_954888_71219" xmi:uuid="841f4670-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277261815_152186_71215"/>
      <bounds x="922" y="196" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277945874_466538_71637" xmi:uuid="85d01650-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277951397_810988_71638"/>
      <source xmi:idref="_18_4_1_8be0287_1624277126518_190559_70904"/>
      <target xmi:idref="_18_4_1_8be0287_1624277939042_203210_71599"/>
      <waypoint x="606" y="581"/>
      <waypoint x="606" y="711"/>
      <waypoint x="492" y="711"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624275026392_303367_74833" xmi:uuid="acab7e60-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="8500a690-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8500a860-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="853e2a00-339c-013a-17e4-45cc4a55db9f" xmi:uuid="853e2b50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="7b5a0610-6c43-013d-d60e-0800270c66d6" xmi:uuid="7b5a06b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7b67ca10-6c43-013d-d60e-0800270c66d6" xmi:uuid="7b67cac0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624277939042_203210_71599" xmi:uuid="85ce5b00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="859be360-339c-013a-17e4-45cc4a55db9f" xmi:uuid="859bea10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="85cd5490-339c-013a-17e4-45cc4a55db9f" xmi:uuid="85cd55d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="308" y="700" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="210" y="672" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277379316_679160_71285" xmi:uuid="8726e910-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277380580_597612_71286"/>
      <source xmi:idref="_18_4_1_8be0287_1624277126518_190559_70904"/>
      <target xmi:idref="_18_4_1_8be0287_1624277369706_171357_71247"/>
      <waypoint x="606" y="238"/>
      <waypoint x="606" y="123"/>
      <waypoint x="497" y="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624275026392_274172_74864" xmi:uuid="ace768c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="865c2be0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="865c2d90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="86997180-339c-013a-17e4-45cc4a55db9f" xmi:uuid="869972d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="7f3d0550-6c43-013d-d60e-0800270c66d6" xmi:uuid="7f3d0600-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7f53f1c0-6c43-013d-d60e-0800270c66d6" xmi:uuid="7f53f270-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624277369706_171357_71247" xmi:uuid="8725e270-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="86f66e50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="86f672c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="8724b790-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8724b9c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="322" y="112" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="203" y="84" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277566590_154923_71445" xmi:uuid="88831680-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277568213_99558_71446"/>
      <source xmi:idref="_18_4_1_8be0287_1624277126518_190559_70904"/>
      <target xmi:idref="_18_4_1_8be0287_1624277556809_616825_71407"/>
      <waypoint x="532" y="410"/>
      <waypoint x="428" y="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624275026408_52139_74926" xmi:uuid="ad237320-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="87b2bb40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="87b2bd00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="87f7b4b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="87f7b620-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="8309e8d0-6c43-013d-d60e-0800270c66d6" xmi:uuid="8309e970-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="831f3f60-6c43-013d-d60e-0800270c66d6" xmi:uuid="831f4020-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624277556809_616825_71407" xmi:uuid="8881d650-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="88540bc0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="88540f30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="888086c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="88808830-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="245" y="399" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="203" y="371" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277438706_158107_71333" xmi:uuid="8a5f8e00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277441358_754466_71334"/>
      <source xmi:idref="_18_4_1_8be0287_1624277126518_190559_70904"/>
      <target xmi:idref="_18_4_1_8be0287_1624277427109_954202_71295"/>
      <waypoint x="606" y="238"/>
      <waypoint x="606" y="193"/>
      <waypoint x="459" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624275026439_352039_75019" xmi:uuid="ad5ffab0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="88f85e30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="88f86680-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="893cde80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="893ce050-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="874b6860-6c43-013d-d60e-0800270c66d6" xmi:uuid="874b6900-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="874e3d20-6c43-013d-d60e-0800270c66d6" xmi:uuid="874e3de0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624277427109_954202_71295" xmi:uuid="8a5daf70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="89b20cb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="89b20e70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="8a554720-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8a554970-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="231" y="182" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="203" y="154" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624275026439_963382_75050" xmi:uuid="ad642300-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214702594_116340_69713"/>
      <ownedElement xmi:id="8a77e830-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8a77ea40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214702594_116340_69713"/>
        <text>Related:SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="8a7fc1b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8a7fc3b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214702594_116340_69713"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624277756858_71677_71487" xmi:uuid="8a813130-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
        <ownedElement xmi:id="89a59560-6c43-013d-d60e-0800270c66d6" xmi:uuid="89a59600-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
          <bounds x="244" y="497" width="212" height="13"/>
          <text>slotDefinition : Attachment_slot_definition [1]</text>
        </ownedElement>
        <bounds x="208" y="504" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="56" y="497" width="160" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624275026454_14254_75081" xmi:uuid="ad68a0c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214610219_92164_69663"/>
      <ownedElement xmi:id="8a8c0400-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8a8c1830-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214610219_92164_69663"/>
        <text>Relating:SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="8a96e7e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8a96eb00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214610219_92164_69663"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624277705952_338851_71455" xmi:uuid="8a995ca0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
        <ownedElement xmi:id="8a432c40-6c43-013d-d60e-0800270c66d6" xmi:uuid="8a432ce0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
          <bounds x="248" y="447" width="212" height="13"/>
          <text>slotDefinition : Attachment_slot_definition [1]</text>
        </ownedElement>
        <bounds x="212" y="454" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="56" y="448" width="164" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624275026470_5686_75112" xmi:uuid="ad8566b0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="8af7f180-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8af7f370-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624277490407_141767_71343" xmi:uuid="8b5e80c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="8c9dee80-6c43-013d-d60e-0800270c66d6" xmi:uuid="8c9def50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="420" y="270" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="402" y="279" width="15" height="15"/>
      </ownedElement>
      <bounds x="168" y="266" width="249" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624275026501_908932_75132" xmi:uuid="ada1c8b0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="8c2d8ba0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8c2d8d70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624277522299_228195_71375" xmi:uuid="8cbc68a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="8ed34340-6c43-013d-d60e-0800270c66d6" xmi:uuid="8ed343e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="423" y="317" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="405" y="326" width="15" height="15"/>
      </ownedElement>
      <bounds x="168" y="315" width="252" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277922340_681085_71589" xmi:uuid="8e43ef10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277924825_841501_71590"/>
      <source xmi:idref="_18_4_1_8be0287_1624277126518_190559_70904"/>
      <target xmi:idref="_18_4_1_8be0287_1624277913604_181585_71551"/>
      <waypoint x="606" y="581"/>
      <waypoint x="606" y="634"/>
      <waypoint x="450" y="634"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624275026532_216855_75183" xmi:uuid="addda980-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="8d25af30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8d25b0d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="8d53d590-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8d53d6e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="90a92120-6c43-013d-d60e-0800270c66d6" xmi:uuid="90a921d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="90bcfc50-6c43-013d-d60e-0800270c66d6" xmi:uuid="90bcfe10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624277913604_181585_71551" xmi:uuid="8e414e40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="8dd1f620-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8dd1f760-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="8e3f8c80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8e3f8ea0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="266" y="623" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="210" y="595" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624275026548_389354_75214" xmi:uuid="adf9b210-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="8ebce5b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8ebce750-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624277872310_8632_71519" xmi:uuid="8ee8e640-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="987ac020-6c43-013d-d60e-0800270c66d6" xmi:uuid="987ac2c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="402" y="543" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <bounds x="384" y="552" width="15" height="15"/>
      </ownedElement>
      <bounds x="182" y="539" width="217" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277126518_190559_70904" xmi:uuid="ae83b070-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277126487_243291_70903"/>
      <ownedElement xmi:id="8f1abc10-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8f1abda0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277126487_243291_70903"/>
        <text>slotDefinitionRel:View_definition_usage</text>
      </ownedElement>
      <ownedElement xmi:id="8f20da80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8f20dbf0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277126487_243291_70903"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="99d516a0-6c43-013d-d60e-0800270c66d6" xmi:uuid="99d51740-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="99ea4ac0-6c43-013d-d60e-0800270c66d6" xmi:uuid="99ea4de0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624277178832_46833_70970" xmi:uuid="8f7f0890-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
          <ownedElement xmi:id="8f51bd10-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8f51bec0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="8f7dba20-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8f7dbbb0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="553" y="273" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624277178863_189699_71001" xmi:uuid="8fec09f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
          <ownedElement xmi:id="8fad19d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8fad1b30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="8fea6df0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="8fea6fa0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="553" y="322" width="100" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624277178879_708558_71063" xmi:uuid="913a3af0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-related_view"/>
          <ownedElement xmi:id="90f7fc00-339c-013a-17e4-45cc4a55db9f" xmi:uuid="90f7fdc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-related_view"/>
            <text>related_view:as_product_view_definition_or_reference</text>
          </ownedElement>
          <ownedElement xmi:id="913904a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="91390650-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-related_view"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="553" y="497" width="347" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624277178894_175826_71094" xmi:uuid="91c81f00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relating_view"/>
          <ownedElement xmi:id="91958770-339c-013a-17e4-45cc4a55db9f" xmi:uuid="91958940-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relating_view"/>
            <text>relating_view:as_product_view_definition_or_reference</text>
          </ownedElement>
          <ownedElement xmi:id="91c73740-339c-013a-17e4-45cc4a55db9f" xmi:uuid="91c738b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relating_view"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="553" y="448" width="350" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624277178910_317098_71125" xmi:uuid="9229e290-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
          <ownedElement xmi:id="91f47040-339c-013a-17e4-45cc4a55db9f" xmi:uuid="91f47210-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="92288570-339c-013a-17e4-45cc4a55db9f" xmi:uuid="922886a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="553" y="546" width="162" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="532" y="238" width="375" height="343"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277321118_673442_71240" xmi:uuid="ae83bb00-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277328045_997220_71241"/>
      <source xmi:idref="_18_4_1_8be0287_1624277261877_954888_71219"/>
      <target xmi:idref="_18_4_1_8be0287_1624277126518_190559_70904"/>
      <waypoint x="922" y="207"/>
      <waypoint x="791" y="207"/>
      <waypoint x="791" y="238"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277500157_502456_71362" xmi:uuid="ae83c380-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277501483_244870_71363"/>
      <source xmi:idref="_18_4_1_8be0287_1624277178832_46833_70970"/>
      <target xmi:idref="_18_4_1_8be0287_1624277490407_141767_71343"/>
      <waypoint x="553" y="287"/>
      <waypoint x="417" y="287"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277534404_218161_71394" xmi:uuid="ae83cbe0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277535808_592905_71395"/>
      <source xmi:idref="_18_4_1_8be0287_1624277178863_189699_71001"/>
      <target xmi:idref="_18_4_1_8be0287_1624277522299_228195_71375"/>
      <waypoint x="553" y="333"/>
      <waypoint x="420" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277717481_736797_71474" xmi:uuid="ae83d650-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277719472_913956_71475"/>
      <source xmi:idref="_18_4_1_8be0287_1624277178894_175826_71094"/>
      <target xmi:idref="_18_4_1_8be0287_1624277705952_338851_71455"/>
      <waypoint x="553" y="462"/>
      <waypoint x="227" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277774892_707051_71506" xmi:uuid="ae83df50-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277778636_470029_71507"/>
      <source xmi:idref="_18_4_1_8be0287_1624277178879_708558_71063"/>
      <target xmi:idref="_18_4_1_8be0287_1624277756858_71677_71487"/>
      <waypoint x="553" y="511"/>
      <waypoint x="223" y="511"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624277893699_454220_71538" xmi:uuid="ae83e760-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277894806_841305_71539"/>
      <source xmi:idref="_18_4_1_8be0287_1624277178910_317098_71125"/>
      <target xmi:idref="_18_4_1_8be0287_1624277872310_8632_71519"/>
      <waypoint x="553" y="560"/>
      <waypoint x="399" y="560"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625030250019_496026_74120" xmi:uuid="ae83ecd0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="616" y="28" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="925" height="750"/>
    <name>SlotDefinitionRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1624973239928_614068_74280" xmi:uuid="922c6f90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214296568_664807_69363"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1624973497835_370330_74360" xmi:uuid="92307690-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973497803_843232_74356"/>
      <bounds x="363" y="98" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624973412449_383948_74313" xmi:uuid="ae927210-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973412418_371479_74312"/>
      <ownedElement xmi:id="9282b930-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9282bad0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973412418_371479_74312"/>
        <text>theSlot:Attachment_slot_design</text>
      </ownedElement>
      <ownedElement xmi:id="92890ae0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="92890da0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973412418_371479_74312"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="84" y="119" width="213" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624973645214_365952_74382" xmi:uuid="ae927f00-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973647554_289592_74383"/>
      <source xmi:idref="_18_4_1_8be0287_1624973497835_370330_74360"/>
      <target xmi:idref="_18_4_1_8be0287_1624973412449_383948_74313"/>
      <waypoint x="363" y="109"/>
      <waypoint x="189" y="109"/>
      <waypoint x="189" y="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031224814_592740_74270" xmi:uuid="ae928420-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_8be0287_1623158012147_298117_81229"/>
      <bounds x="189" y="28" width="78" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="366" height="170"/>
    <name>SlotDesign</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1625029647094_845920_72160" xmi:uuid="928a9da0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214318254_324090_69406"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031345351_902024_74399" xmi:uuid="928db330-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031345304_678040_74395"/>
      <bounds x="363" y="121" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625029698854_92055_72193" xmi:uuid="aea0a860-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029698854_337666_72192"/>
      <ownedElement xmi:id="930c9830-339c-013a-17e4-45cc4a55db9f" xmi:uuid="930c99e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029698854_337666_72192"/>
        <text>theSlot:Attachment_slot_as_realized</text>
      </ownedElement>
      <ownedElement xmi:id="93148780-339c-013a-17e4-45cc4a55db9f" xmi:uuid="93148970-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029698854_337666_72192"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="56" y="154" width="231" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031323836_66249_74374" xmi:uuid="aea0aed0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_8be0287_1623158012147_298117_81229"/>
      <bounds x="168" y="35" width="78" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031394883_807421_74422" xmi:uuid="aea0b820-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031395897_962792_74423"/>
      <source xmi:idref="_18_4_1_8be0287_1625031345351_902024_74399"/>
      <target xmi:idref="_18_4_1_8be0287_1625029698854_92055_72193"/>
      <waypoint x="363" y="130"/>
      <waypoint x="175" y="130"/>
      <waypoint x="175" y="154"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="366" height="198"/>
    <name>SlotAsRealized</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1625031702158_330389_74676" xmi:uuid="93162730-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214343240_255641_69449"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039494304_15017_74186" xmi:uuid="949ae090-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039496488_428031_74187"/>
      <source xmi:idref="_18_4_1_8be0287_1625033954080_454025_75447"/>
      <target xmi:idref="_18_4_1_8be0287_1625039485395_575160_74148"/>
      <waypoint x="907" y="581"/>
      <waypoint x="907" y="910"/>
      <waypoint x="807" y="910"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031772673_921675_74708" xmi:uuid="aee0c5f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="93986030-339c-013a-17e4-45cc4a55db9f" xmi:uuid="93986190-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="93d2a8b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="93d2aab0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b41290f0-6c43-013d-d60e-0800270c66d6" xmi:uuid="b4129190-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b42331a0-6c43-013d-d60e-0800270c66d6" xmi:uuid="b4233270-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625039485395_575160_74148" xmi:uuid="9499ead0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="944cdcf0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="944cde40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9498f460-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9498f5b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="623" y="896" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="525" y="868" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039032825_531484_73740" xmi:uuid="95f83010-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039034635_251760_73741"/>
      <source xmi:idref="_18_4_1_8be0287_1625033954080_454025_75447"/>
      <target xmi:idref="_18_4_1_8be0287_1625039024401_65980_73702"/>
      <waypoint x="872" y="217"/>
      <waypoint x="872" y="123"/>
      <waypoint x="672" y="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031772688_468721_74739" xmi:uuid="af1dcb80-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="94f68fd0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="94f69190-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="953cd250-339c-013a-17e4-45cc4a55db9f" xmi:uuid="953cd390-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b821b220-6c43-013d-d60e-0800270c66d6" xmi:uuid="b821b2f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b8417770-6c43-013d-d60e-0800270c66d6" xmi:uuid="b8417850-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625039024401_65980_73702" xmi:uuid="95f68750-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="95a5c990-339c-013a-17e4-45cc4a55db9f" xmi:uuid="95a5cb90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="95f26a60-339c-013a-17e4-45cc4a55db9f" xmi:uuid="95f26c10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="497" y="112" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="378" y="84" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039191961_740917_73900" xmi:uuid="97eba810-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039193833_764885_73901"/>
      <source xmi:idref="_18_4_1_8be0287_1625033954080_454025_75447"/>
      <target xmi:idref="_18_4_1_8be0287_1625039182305_705083_73862"/>
      <waypoint x="812" y="396"/>
      <waypoint x="603" y="396"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031772704_1_74770" xmi:uuid="af5a7d30-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="968342e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="968344e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="96b06260-339c-013a-17e4-45cc4a55db9f" xmi:uuid="96b063a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="d8beb2f0-6c43-013d-d60e-0800270c66d6" xmi:uuid="d9a63350-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dd15f630-6c43-013d-d60e-0800270c66d6" xmi:uuid="dd161990-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625039182305_705083_73862" xmi:uuid="97ea13b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="972eba80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="972ebc40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="97e85720-339c-013a-17e4-45cc4a55db9f" xmi:uuid="97e858c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="420" y="385" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="378" y="357" width="314" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039061764_335081_73788" xmi:uuid="997a3ce0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039065149_589750_73789"/>
      <source xmi:idref="_18_4_1_8be0287_1625033954080_454025_75447"/>
      <target xmi:idref="_18_4_1_8be0287_1625039052590_657716_73750"/>
      <waypoint x="872" y="217"/>
      <waypoint x="872" y="200"/>
      <waypoint x="641" y="200"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031772704_270086_74801" xmi:uuid="af96e750-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="9863e2c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9863e440-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="989f3100-339c-013a-17e4-45cc4a55db9f" xmi:uuid="989f32a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="edb27250-6c43-013d-d60e-0800270c66d6" xmi:uuid="edb27360-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="edb3ca20-6c43-013d-d60e-0800270c66d6" xmi:uuid="edb3cb00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625039052590_657716_73750" xmi:uuid="99781840-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="993bff60-339c-013a-17e4-45cc4a55db9f" xmi:uuid="993c0140-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="99765a00-339c-013a-17e4-45cc4a55db9f" xmi:uuid="99765bc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="413" y="189" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="378" y="161" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031772735_214038_74832" xmi:uuid="afb30ef0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="9a19d840-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9a19d9e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625039103461_715546_73798" xmi:uuid="9a54cf00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="f1c14d70-6c43-013d-d60e-0800270c66d6" xmi:uuid="f1c14e10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="693" y="247" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="675" y="256" width="15" height="15"/>
      </ownedElement>
      <bounds x="420" y="245" width="270" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031772751_434101_74852" xmi:uuid="afcf9050-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="9af4f2b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9af50010-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625039146120_131972_73830" xmi:uuid="9b2af750-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="f407f540-6c43-013d-d60e-0800270c66d6" xmi:uuid="f407f5e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="370" y="304" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="352" y="313" width="15" height="15"/>
      </ownedElement>
      <bounds x="210" y="301" width="157" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039283177_252689_73960" xmi:uuid="9c91f4d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039285408_619879_73961"/>
      <source xmi:idref="_18_4_1_8be0287_1625033954080_454025_75447"/>
      <target xmi:idref="_18_4_1_8be0287_1625039245188_365252_73910"/>
      <waypoint x="907" y="581"/>
      <waypoint x="907" y="987"/>
      <waypoint x="765" y="987"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031772751_391659_74872" xmi:uuid="b00b6a60-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="9b7f4ef0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9b7f50a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9bad20b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9bad21e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f5c243c0-6c43-013d-d60e-0800270c66d6" xmi:uuid="f5c24470-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f5dd3f00-6c43-013d-d60e-0800270c66d6" xmi:uuid="f5dd3fd0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625039245188_365252_73910" xmi:uuid="9c909ac0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="9c51d710-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9c51d910-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9c8f2db0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9c8f2ef0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="581" y="973" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="525" y="945" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031772766_128566_74903" xmi:uuid="b0284220-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="9cf2c280-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9cf2c660-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625039269699_751292_73941" xmi:uuid="9d3d9010-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="f9afcac0-6c43-013d-d60e-0800270c66d6" xmi:uuid="f9afcb80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="272" y="1046" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <bounds x="254" y="1055" width="15" height="15"/>
      </ownedElement>
      <bounds x="77" y="1043" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031879719_910089_75262" xmi:uuid="b02848a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="371" y="21" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625033954080_454025_75447" xmi:uuid="b0ad7480-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033954065_360763_75446"/>
      <ownedElement xmi:id="9d8b68b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9d8b6f30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033954065_360763_75446"/>
        <text>slotDesignToRealized:Attachment_slot_design_to_realized</text>
      </ownedElement>
      <ownedElement xmi:id="9d98e500-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9d98e6b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033954065_360763_75446"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="faa69650-6c43-013d-d60e-0800270c66d6" xmi:uuid="faa69700-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="fabd9710-6c43-013d-d60e-0800270c66d6" xmi:uuid="fabd97e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034499533_37517_70144" xmi:uuid="9e47b880-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-description"/>
          <ownedElement xmi:id="9dfb8d80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9dfb9200-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="9e45aa70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9e45ac80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="833" y="252" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034499548_179911_70175" xmi:uuid="9f67c3f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-design"/>
          <ownedElement xmi:id="9f3001a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9f300380-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-design"/>
            <text>design:Attachment_slot_design</text>
          </ownedElement>
          <ownedElement xmi:id="9f66d3a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9f66d4f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-design"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="840" y="434" width="212" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034499564_723970_70206" xmi:uuid="9fcabd90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-id"/>
          <ownedElement xmi:id="9f9a4540-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9f9a4690-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="9fc95650-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9fc95880-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="833" y="308" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034499580_521822_70237" xmi:uuid="a04c0550-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-name"/>
          <ownedElement xmi:id="9ffb30c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="9ffb3410-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="a04a0860-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a04a0a50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="840" y="532" width="103" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034499595_343724_70268" xmi:uuid="a1378a90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-realized"/>
          <ownedElement xmi:id="a0ef76e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a0ef7cc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-realized"/>
            <text>realized:Attachment_slot_as_realized</text>
          </ownedElement>
          <ownedElement xmi:id="a1338540-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a1338700-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_realized-realized"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="840" y="476" width="243" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="812" y="217" width="378" height="364"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625034524167_584997_70306" xmi:uuid="b0ad83c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034525711_965557_70307"/>
      <source xmi:idref="_18_4_1_8be0287_1625032093962_163891_75364"/>
      <target xmi:idref="_18_4_1_8be0287_1625033954080_454025_75447"/>
      <waypoint x="1235" y="182"/>
      <waypoint x="991" y="182"/>
      <waypoint x="991" y="217"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039122120_7203_73817" xmi:uuid="b0ad8ca0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039123196_359996_73818"/>
      <source xmi:idref="_18_4_1_8be0287_1625034499533_37517_70144"/>
      <target xmi:idref="_18_4_1_8be0287_1625039103461_715546_73798"/>
      <waypoint x="833" y="263"/>
      <waypoint x="690" y="263"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039161096_362646_73849" xmi:uuid="b0ad9610-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039162672_195513_73850"/>
      <source xmi:idref="_18_4_1_8be0287_1632388158695_327070_75918"/>
      <target xmi:idref="_18_4_1_8be0287_1625039146120_131972_73830"/>
      <waypoint x="504" y="319"/>
      <waypoint x="367" y="319"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039378661_324184_74065" xmi:uuid="b0ad9f00-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039380221_626966_74066"/>
      <source xmi:idref="_18_4_1_8be0287_1625034499548_179911_70175"/>
      <target xmi:idref="_18_4_1_271a0567_1640167234010_648291_95414"/>
      <waypoint x="840" y="445"/>
      <waypoint x="185" y="445"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039451786_557272_74135" xmi:uuid="b0adaa30-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039456234_739582_74136"/>
      <source xmi:idref="_18_4_1_8be0287_1625034499595_343724_70268"/>
      <target xmi:idref="_18_4_1_271a0567_1640167248340_620980_95428"/>
      <waypoint x="840" y="490"/>
      <waypoint x="216" y="490"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055602352_160128_79180" xmi:uuid="b0ba0520-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556449_907262_78767"/>
      <ownedElement xmi:id="a2323fa0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a23241b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556449_907262_78767"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625062771816_130598_71870" xmi:uuid="a23bf320-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="03aa74f0-6c44-013d-d60e-0800270c66d6" xmi:uuid="03aa7660-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="518" y="552" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="574" y="542" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625062771835_157410_71880" xmi:uuid="a23ddb90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="045a25a0-6c44-013d-d60e-0800270c66d6" xmi:uuid="045a2650-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="769" y="530" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="751" y="539" width="15" height="15"/>
      </ownedElement>
      <bounds x="574" y="525" width="192" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063074551_491446_72194" xmi:uuid="a4abe090-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063077082_324542_72195"/>
      <source xmi:idref="_18_4_1_8be0287_1625033954080_454025_75447"/>
      <target xmi:idref="_18_4_1_8be0287_1625063015022_975521_72088"/>
      <waypoint x="907" y="581"/>
      <waypoint x="907" y="830"/>
      <waypoint x="767" y="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055602357_780536_79200" xmi:uuid="b119e9b0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556452_90821_78771"/>
      <ownedElement xmi:id="a279ab90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a279ad40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556452_90821_78771"/>
        <text>nameLang:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="a27f7b20-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a27f7c50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556452_90821_78771"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="05365dc0-6c44-013d-d60e-0800270c66d6" xmi:uuid="05365e50-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="054a18a0-6c44-013d-d60e-0800270c66d6" xmi:uuid="054a1950-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063015004_132785_72057" xmi:uuid="a2e8df80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="a2b3b460-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a2b3b670-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="a2e7b8b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a2e7b9f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="539" y="784" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063015022_975521_72088" xmi:uuid="a3d2fc00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="a366f710-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a366f930-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="a3d12b30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a3d12d80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="539" y="819" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063015040_576363_72119" xmi:uuid="a4aa5230-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="a45a3db0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a45a3ef0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="a4a91450-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a4a915c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="539" y="749" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="525" y="721" width="301" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055602361_709046_79231" xmi:uuid="b125ebe0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556451_983155_78769"/>
      <ownedElement xmi:id="a50610d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a5061260-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556451_983155_78769"/>
        <text>lang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="a50b3f20-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a50b4060-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556451_983155_78769"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625062934454_731892_71980" xmi:uuid="a50c7440-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="0b3eaa70-6c44-013d-d60e-0800270c66d6" xmi:uuid="0b3eab00-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="388" y="646" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="370" y="655" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="231" y="651" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625062981591_560606_72047" xmi:uuid="a6235890-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625062984237_531283_72048"/>
      <source xmi:idref="_18_4_1_8be0287_1625033954080_454025_75447"/>
      <target xmi:idref="_18_4_1_8be0287_1625062963976_92037_71992"/>
      <waypoint x="907" y="581"/>
      <waypoint x="907" y="683"/>
      <waypoint x="784" y="683"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055602366_598636_79262" xmi:uuid="b151bf00-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556452_669243_78770"/>
      <ownedElement xmi:id="a5411950-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a5411aa0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556452_669243_78770"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a5471830-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a5471cc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556452_669243_78770"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="0c4bfdb0-6c44-013d-d60e-0800270c66d6" xmi:uuid="0c4bff10-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0c62e0d0-6c44-013d-d60e-0800270c66d6" xmi:uuid="0c62e1a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625062963976_92037_71992" xmi:uuid="a61c0db0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="a5aeb0d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a5aeb260-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="a61aa810-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a61aa9e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="609" y="672" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="525" y="644" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055602370_847436_79293" xmi:uuid="b15dd500-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556450_622528_78768"/>
      <ownedElement xmi:id="a6af34c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a6af3610-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556450_622528_78768"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="a6b72960-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a6b72aa0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556450_622528_78768"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625062911586_571556_71968" xmi:uuid="a6b8b150-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="0f71af20-6c44-013d-d60e-0800270c66d6" xmi:uuid="0f71afd0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="514" y="605" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="496" y="614" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="350" y="609" width="154" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055602375_937546_79324" xmi:uuid="b160b180-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556454_382430_78772"/>
      <ownedElement xmi:id="a6c1cc00-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a6c1d630-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556454_382430_78772"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="a6c96f50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a6c97100-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556454_382430_78772"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="224" y="784" width="207" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055602390_347824_79355" xmi:uuid="b16d6b40-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556448_221717_78766"/>
      <ownedElement xmi:id="a70336e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a70338c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055556448_221717_78766"/>
        <text>nameSelect:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625062723082_646250_71805" xmi:uuid="a7092e00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="1133c020-6c44-013d-d60e-0800270c66d6" xmi:uuid="1133c0c0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="219" y="528" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="273" y="537" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625062723112_593138_71815" xmi:uuid="a70a4300-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="11b9a510-6c44-013d-d60e-0800270c66d6" xmi:uuid="11b9a5b0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="488" y="535" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="470" y="544" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625062723126_492530_71825" xmi:uuid="a70b4890-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="1282cb40-6c44-013d-d60e-0800270c66d6" xmi:uuid="1282cbe0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="401" y="584" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="391" y="566" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625062723138_52607_71835" xmi:uuid="a70ca060-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="132c6be0-6c44-013d-d60e-0800270c66d6" xmi:uuid="132c6c90-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="319" y="584" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="309" y="566" width="15" height="15"/>
      </ownedElement>
      <bounds x="273" y="525" width="212" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625062692079_838154_71774" xmi:uuid="b1794920-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625056056171_760868_80239"/>
      <ownedElement xmi:id="a740f150-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a740f300-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625056056171_760868_80239"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="a7476360-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a74764f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625056056171_760868_80239"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="532" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625062756297_30805_71860" xmi:uuid="b1795490-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625062757809_913584_71861"/>
      <source xmi:idref="_18_4_1_8be0287_1625062723082_646250_71805"/>
      <target xmi:idref="_18_4_1_8be0287_1625062692079_838154_71774"/>
      <waypoint x="273" y="543"/>
      <waypoint x="209" y="543"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625062828308_898638_71901" xmi:uuid="b17961d0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625062829742_332763_71902"/>
      <source xmi:idref="_18_4_1_8be0287_1625062771816_130598_71870"/>
      <target xmi:idref="_18_4_1_8be0287_1625062723112_593138_71815"/>
      <waypoint x="574" y="550"/>
      <waypoint x="485" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625062849032_131578_71921" xmi:uuid="b1796f20-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625062850422_178893_71922"/>
      <source xmi:idref="_18_4_1_8be0287_1625034499580_521822_70237"/>
      <target xmi:idref="_18_4_1_8be0287_1625062771835_157410_71880"/>
      <waypoint x="840" y="546"/>
      <waypoint x="766" y="546"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625062870231_963692_71941" xmi:uuid="b1797b10-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625062871884_623439_71942"/>
      <source xmi:idref="_18_4_1_8be0287_1625055602361_709046_79231"/>
      <target xmi:idref="_18_4_1_8be0287_1625062723138_52607_71835"/>
      <waypoint x="315" y="651"/>
      <waypoint x="315" y="581"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625062895860_696166_71958" xmi:uuid="b1798e20-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625062896935_398933_71959"/>
      <source xmi:idref="_18_4_1_8be0287_1625055602370_847436_79293"/>
      <target xmi:idref="_18_4_1_8be0287_1625062723126_492530_71825"/>
      <waypoint x="399" y="609"/>
      <waypoint x="399" y="581"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625062975395_36513_72030" xmi:uuid="b17998f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625062977253_468318_72031"/>
      <source xmi:idref="_18_4_1_8be0287_1625055602366_598636_79262"/>
      <target xmi:idref="_18_4_1_8be0287_1625062911586_571556_71968"/>
      <waypoint x="669" y="644"/>
      <waypoint x="669" y="623"/>
      <waypoint x="511" y="623"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063059829_926305_72157" xmi:uuid="b179a4e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063060985_222688_72158"/>
      <source xmi:idref="_18_4_1_8be0287_1625063015004_132785_72057"/>
      <target xmi:idref="_18_4_1_8be0287_1625055602375_937546_79324"/>
      <waypoint x="539" y="795"/>
      <waypoint x="431" y="795"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063066019_815382_72174" xmi:uuid="b179b3c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063068908_167416_72175"/>
      <source xmi:idref="_18_4_1_8be0287_1625063015040_576363_72119"/>
      <target xmi:idref="_18_4_1_8be0287_1625062934454_731892_71980"/>
      <waypoint x="539" y="760"/>
      <waypoint x="448" y="760"/>
      <waypoint x="448" y="662"/>
      <waypoint x="385" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063170840_570033_72225" xmi:uuid="b1b14320-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063161350_770387_72204"/>
      <ownedElement xmi:id="a777a570-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a777a710-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063161350_770387_72204"/>
        <text>simpleType:Class</text>
      </ownedElement>
      <ownedElement xmi:id="a78e2d90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a78e3a70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063161350_770387_72204"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="14ece960-6c44-013d-d60e-0800270c66d6" xmi:uuid="14ecea40-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="151656c0-6c44-013d-d60e-0800270c66d6" xmi:uuid="151657c0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063230794_623651_72442" xmi:uuid="a82c8730-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="a7e84580-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a7e84760-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="a82b7ee0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a82b8030-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="336" y="1099" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063230805_951773_72473" xmi:uuid="a88a4f10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="a85abf40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a85ac160-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="a88929a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a8892d30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="336" y="1050" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="322" y="1022" width="147" height="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063170849_652799_72256" xmi:uuid="b1b457a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063161354_323239_72206"/>
      <ownedElement xmi:id="a89112b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a8911400-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063161354_323239_72206"/>
        <text>ignore:String</text>
      </ownedElement>
      <ownedElement xmi:id="a8976a80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a8976c10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063161354_323239_72206"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="105" y="1099" width="165" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063317435_452396_72565" xmi:uuid="aa6714e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063319876_164802_72566"/>
      <source xmi:idref="_18_4_1_8be0287_1625033954080_454025_75447"/>
      <target xmi:idref="_18_4_1_8be0287_1625063205435_225023_72349"/>
      <waypoint x="907" y="581"/>
      <waypoint x="907" y="1096"/>
      <waypoint x="723" y="1096"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063170858_773176_72287" xmi:uuid="b20058f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063161353_297103_72205"/>
      <ownedElement xmi:id="a8cdb8e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a8cdbba0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063161353_297103_72205"/>
        <text>simpleTypeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a8d3ed40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a8d3ef40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063161353_297103_72205"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="18aed440-6c44-013d-d60e-0800270c66d6" xmi:uuid="18aed4f0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="18d0d940-6c44-013d-d60e-0800270c66d6" xmi:uuid="18d0da00-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063205413_173878_72318" xmi:uuid="a9cfcf00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="a9719230-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a97193f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="a9ce8b70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="a9ce8d20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="539" y="1050" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063205435_225023_72349" xmi:uuid="aa654780-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="aa2a1720-339c-013a-17e4-45cc4a55db9f" xmi:uuid="aa2a1870-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="aa63ab40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="aa63ad50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="539" y="1085" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="525" y="1022" width="298" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063292307_179841_72511" xmi:uuid="b2006160-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063293532_167799_72512"/>
      <source xmi:idref="_18_4_1_8be0287_1625063230805_951773_72473"/>
      <target xmi:idref="_18_4_1_8be0287_1625039269699_751292_73941"/>
      <waypoint x="336" y="1061"/>
      <waypoint x="269" y="1061"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063302826_115247_72531" xmi:uuid="b2007010-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063303876_762453_72532"/>
      <source xmi:idref="_18_4_1_8be0287_1625063230794_623651_72442"/>
      <target xmi:idref="_18_4_1_8be0287_1625063170849_652799_72256"/>
      <waypoint x="336" y="1110"/>
      <waypoint x="270" y="1110"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063310290_416716_72548" xmi:uuid="b20077e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063311606_547337_72549"/>
      <source xmi:idref="_18_4_1_8be0287_1625063205413_173878_72318"/>
      <target xmi:idref="_18_4_1_8be0287_1625063170840_570033_72225"/>
      <waypoint x="539" y="1061"/>
      <waypoint x="469" y="1061"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1632388148541_580872_75898" xmi:uuid="b20cf0f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388120770_305619_75896"/>
      <ownedElement xmi:id="aabdd790-339c-013a-17e4-45cc4a55db9f" xmi:uuid="aabdd950-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388120770_305619_75896"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1632388158695_327070_75918" xmi:uuid="aad3a1b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="1d585fb0-6c44-013d-d60e-0800270c66d6" xmi:uuid="1d586180-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="450" y="304" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="504" y="313" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1632388158709_556885_75928" xmi:uuid="aad5ad20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="1df380a0-6c44-013d-d60e-0800270c66d6" xmi:uuid="1df38150-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="685" y="307" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="667" y="316" width="15" height="15"/>
      </ownedElement>
      <bounds x="504" y="301" width="178" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1632388180487_709412_75949" xmi:uuid="b20cf770-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388181767_217465_75950"/>
      <source xmi:idref="_18_4_1_8be0287_1625034499564_723970_70206"/>
      <target xmi:idref="_18_4_1_8be0287_1632388158709_556885_75928"/>
      <waypoint x="833" y="322"/>
      <waypoint x="682" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625032093962_163891_75364" xmi:uuid="931e52e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625032093946_386061_75360"/>
      <bounds x="1235" y="176" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1640167211754_86424_94432" xmi:uuid="b2114820-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214442353_602339_69503"/>
      <ownedElement xmi:id="c4315280-458b-013a-17ff-45cc4a55db9f" xmi:uuid="c4315360-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214442353_602339_69503"/>
        <text>Design:SlotDesign</text>
      </ownedElement>
      <ownedElement xmi:id="c436d790-458b-013a-17ff-45cc4a55db9f" xmi:uuid="c436d890-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214442353_602339_69503"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1640167234010_648291_95414" xmi:uuid="c438e350-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973497803_843232_74356"/>
        <ownedElement xmi:id="1eb29850-6c44-013d-d60e-0800270c66d6" xmi:uuid="1eb29910-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973497803_843232_74356"/>
          <bounds x="188" y="425" width="158" height="13"/>
          <text>slot : Attachment_slot_design [1]</text>
        </ownedElement>
        <bounds x="170" y="434" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="427" width="143" height="27"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1640167211754_216746_94463" xmi:uuid="b2154570-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214469214_445686_69535"/>
      <ownedElement xmi:id="c442ad80-458b-013a-17ff-45cc4a55db9f" xmi:uuid="c442aeb0-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214469214_445686_69535"/>
        <text>Realized:SlotAsRealized</text>
      </ownedElement>
      <ownedElement xmi:id="c44a1bb0-458b-013a-17ff-45cc4a55db9f" xmi:uuid="c44a1cc0-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214469214_445686_69535"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1640167248340_620980_95428" xmi:uuid="c44c0030-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031345304_678040_74395"/>
        <ownedElement xmi:id="1f45da70-6c44-013d-d60e-0800270c66d6" xmi:uuid="1f45db20-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031345304_678040_74395"/>
          <bounds x="219" y="472" width="182" height="13"/>
          <text>slot : Attachment_slot_as_realized [1]</text>
        </ownedElement>
        <bounds x="201" y="481" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="476" width="174" height="26"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1238" height="1149"/>
    <name>SlotDesignToRealized</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446413982_358282_349277" xmi:uuid="a14121c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214197111_257229_69320"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414011_132297_349309" xmi:uuid="a241b760-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277126487_243291_70903"/>
      <ownedElement xmi:id="a2227580-6c43-013d-d60e-0800270c66d6" xmi:uuid="a2227640-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277126487_243291_70903"/>
        <text>slotDefinitionRel:View_definition_usage</text>
      </ownedElement>
      <ownedElement xmi:id="a2417710-6c43-013d-d60e-0800270c66d6" xmi:uuid="a24179f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624277126487_243291_70903"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="249" height="470"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414026_238478_349343" xmi:uuid="a25c6930-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="636" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414036_619904_349358" xmi:uuid="a25f0da0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="636" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414052_341681_349373" xmi:uuid="a2884e50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="636" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414060_217951_349388" xmi:uuid="a2947380-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="636" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414069_966015_349403" xmi:uuid="a2a09420-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="636" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414079_456728_349418" xmi:uuid="a2d1fb30-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="636" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414094_163159_349433" xmi:uuid="a2e8d200-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="636" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414108_277244_349448" xmi:uuid="a2ea2820-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="636" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414121_961871_349463" xmi:uuid="a2eb7300-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="636" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414134_981768_349478" xmi:uuid="a311d190-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="636" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414144_772773_349493" xmi:uuid="a33bdcc0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="636" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414156_87216_349508" xmi:uuid="a36f7f80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="636" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414171_942468_349523" xmi:uuid="a39e8200-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="636" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414187_969566_349538" xmi:uuid="a3b465f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="636" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414198_293324_349553" xmi:uuid="a3ca1a90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="636" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414212_612342_349568" xmi:uuid="a3de8510-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="636" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414226_927673_349583" xmi:uuid="a415c520-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="636" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414236_425210_349598" xmi:uuid="a41703b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="636" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414248_555335_349613" xmi:uuid="a440fa90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="636" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414259_645586_349628" xmi:uuid="a45c3cb0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="636" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414268_907495_349643" xmi:uuid="a45e4cc0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="636" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_79366_416345" xmi:uuid="a45e65f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147907576_780271_70204"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414026_238478_349343"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="62"/>
      <waypoint x="294" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_955871_416348" xmi:uuid="a45e7260-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147907649_656283_70220"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414036_619904_349358"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="82"/>
      <waypoint x="294" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_712927_416351" xmi:uuid="a45e8320-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147907724_940272_70236"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414052_341681_349373"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="102"/>
      <waypoint x="294" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_322611_416354" xmi:uuid="a45e9240-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147907797_336944_70252"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414060_217951_349388"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="122"/>
      <waypoint x="294" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_167880_416357" xmi:uuid="a45e9ef0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147907867_300471_70268"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414069_966015_349403"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="142"/>
      <waypoint x="294" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_458763_416360" xmi:uuid="a45eac30-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147907937_301120_70284"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414079_456728_349418"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="162"/>
      <waypoint x="294" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_1394_416363" xmi:uuid="a45eb6e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908014_377045_70300"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414094_163159_349433"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="182"/>
      <waypoint x="294" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_103072_416366" xmi:uuid="a45ec3d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908084_471228_70316"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414108_277244_349448"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="202"/>
      <waypoint x="294" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_515020_416369" xmi:uuid="a489c740-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908151_53581_70332"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414121_961871_349463"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="222"/>
      <waypoint x="294" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_561992_416372" xmi:uuid="a489cec0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908215_528202_70348"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414134_981768_349478"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="242"/>
      <waypoint x="294" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_149519_416375" xmi:uuid="a489d690-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908275_925793_70364"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414144_772773_349493"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="262"/>
      <waypoint x="294" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_942923_416378" xmi:uuid="a489dde0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908331_381221_70380"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414156_87216_349508"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="282"/>
      <waypoint x="294" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_837615_416381" xmi:uuid="a489e610-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908389_896255_70396"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414171_942468_349523"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="302"/>
      <waypoint x="294" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_33133_416384" xmi:uuid="a489ed10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908451_887436_70412"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414187_969566_349538"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="322"/>
      <waypoint x="294" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_691729_416387" xmi:uuid="a489f4b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908511_19125_70428"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414198_293324_349553"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="342"/>
      <waypoint x="294" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513373_662907_416390" xmi:uuid="a489fb40-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908572_821694_70444"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414212_612342_349568"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="362"/>
      <waypoint x="294" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513374_810710_416393" xmi:uuid="a48a03b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908754_515009_70492"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414226_927673_349583"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="382"/>
      <waypoint x="294" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513374_488187_416396" xmi:uuid="a48a0af0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908823_230582_70508"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414236_425210_349598"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="402"/>
      <waypoint x="294" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513374_695284_416399" xmi:uuid="a48a1140-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908885_856801_70524"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414248_555335_349613"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="422"/>
      <waypoint x="294" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513374_508351_416402" xmi:uuid="a48a18a0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147908947_70937_70540"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414259_645586_349628"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="442"/>
      <waypoint x="294" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513374_857221_416405" xmi:uuid="a48a2020-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909005_728013_70556"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414268_907495_349643"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414011_132297_349309"/>
      <waypoint x="636" y="462"/>
      <waypoint x="294" y="462"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="639" height="540"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446414274_962550_349655" xmi:uuid="a61309d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214296568_664807_69363"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414300_221152_349687" xmi:uuid="a7ba5ca0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973412418_371479_74312"/>
      <ownedElement xmi:id="a7869e50-6c43-013d-d60e-0800270c66d6" xmi:uuid="a7869f70-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973412418_371479_74312"/>
        <text>theSlot:Attachment_slot_design</text>
      </ownedElement>
      <ownedElement xmi:id="a7ba4940-6c43-013d-d60e-0800270c66d6" xmi:uuid="a7ba4a10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973412418_371479_74312"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="208" height="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414317_684588_349721" xmi:uuid="a7cf86b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="608" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414327_774372_349736" xmi:uuid="a7e65be0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="608" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414342_716875_349751" xmi:uuid="a7fd0390-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="608" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414351_340737_349766" xmi:uuid="a81cc8a0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="608" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414359_146027_349781" xmi:uuid="a81e23f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="608" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414368_572104_349796" xmi:uuid="a83b1d60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="608" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414377_67654_349811" xmi:uuid="a850a700-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="608" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414391_671397_349826" xmi:uuid="a8662310-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="608" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414402_957673_349841" xmi:uuid="a890ebc0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="608" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414410_228974_349856" xmi:uuid="a8acb6c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="608" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446414424_971870_349871" xmi:uuid="a8c56710-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="608" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415797_785678_349886" xmi:uuid="a8ddba80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="608" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415810_133447_349901" xmi:uuid="a8f326d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="608" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415824_273915_349916" xmi:uuid="a9070b00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="608" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415833_784724_349931" xmi:uuid="a91dc700-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="608" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415845_159500_349946" xmi:uuid="a92feb40-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="608" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415855_145093_349961" xmi:uuid="a9440750-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="608" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415864_945211_349976" xmi:uuid="a9643700-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="608" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415873_616896_349991" xmi:uuid="a9796850-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="608" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415889_763833_350006" xmi:uuid="a994ff90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="608" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415904_915912_350021" xmi:uuid="a9969280-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="608" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415916_440551_350036" xmi:uuid="a9be7a60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="608" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415932_397214_350051" xmi:uuid="a9d3c970-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="608" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415942_44997_350066" xmi:uuid="a9ebf9c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643268851717_322008_86077"/>
      <bounds x="608" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415951_495849_350081" xmi:uuid="aa251590-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643269416144_30883_86580"/>
      <bounds x="608" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415960_282440_350096" xmi:uuid="aa43be20-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643270131067_298147_86914"/>
      <bounds x="608" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415969_822394_350111" xmi:uuid="aa61fe60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="608" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415983_338473_350126" xmi:uuid="aa6da1d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="608" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446415993_635285_350141" xmi:uuid="aa833f50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="608" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416003_36111_350156" xmi:uuid="aa971be0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="608" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416012_566027_350171" xmi:uuid="aaaab9b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="608" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416020_479265_350186" xmi:uuid="aac30db0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="608" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416031_182934_350201" xmi:uuid="aae7c850-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="608" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416040_129802_350216" xmi:uuid="aaf74e30-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="608" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416050_248834_350231" xmi:uuid="ab2915f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="608" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416060_431406_350246" xmi:uuid="ab499700-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="608" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416072_34988_350261" xmi:uuid="ab727340-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="608" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416081_383663_350276" xmi:uuid="ab880680-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570204497794_443467_105732"/>
      <bounds x="608" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416090_395888_350291" xmi:uuid="ab98ac10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="608" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_662989_416408" xmi:uuid="ab98bef0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573104_753811_323675"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414317_684588_349721"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="62"/>
      <waypoint x="253" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_142327_416411" xmi:uuid="ab98c7d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573191_929116_323691"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414327_774372_349736"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="82"/>
      <waypoint x="253" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_376349_416414" xmi:uuid="ab98cff0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573268_762734_323707"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414342_716875_349751"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="102"/>
      <waypoint x="253" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_121764_416417" xmi:uuid="ab98d8d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573360_102764_323723"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414351_340737_349766"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="122"/>
      <waypoint x="253" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_522375_416420" xmi:uuid="ab992260-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573471_454196_323739"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414359_146027_349781"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="142"/>
      <waypoint x="253" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_558960_416423" xmi:uuid="ab993920-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573545_951610_323755"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414368_572104_349796"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="162"/>
      <waypoint x="253" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_534508_416426" xmi:uuid="ab994a10-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573618_992007_323771"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414377_67654_349811"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="182"/>
      <waypoint x="253" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_458700_416429" xmi:uuid="ab9955e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573691_27817_323787"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414391_671397_349826"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="202"/>
      <waypoint x="253" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_84278_416432" xmi:uuid="ab996ae0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573771_20050_323803"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414402_957673_349841"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="222"/>
      <waypoint x="253" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_938666_416435" xmi:uuid="ab9a2ca0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573859_51612_323819"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414410_228974_349856"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="242"/>
      <waypoint x="253" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_187405_416438" xmi:uuid="ab9a5400-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601573934_600766_323835"/>
      <source xmi:idref="_18_4_1_65b021e_1727446414424_971870_349871"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="262"/>
      <waypoint x="253" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_128709_416441" xmi:uuid="ab9a7220-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574015_974762_323851"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415797_785678_349886"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="282"/>
      <waypoint x="253" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_786106_416444" xmi:uuid="ab9a89f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574096_403619_323867"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415810_133447_349901"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="302"/>
      <waypoint x="253" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_356064_416447" xmi:uuid="ab9a9240-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574175_294054_323883"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415824_273915_349916"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="322"/>
      <waypoint x="253" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_806514_416450" xmi:uuid="ab9aa390-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574259_143583_323899"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415833_784724_349931"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="342"/>
      <waypoint x="253" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_981190_416453" xmi:uuid="ab9ab720-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574333_614765_323915"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415845_159500_349946"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="362"/>
      <waypoint x="253" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513382_639715_416456" xmi:uuid="ab9acc80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574411_269611_323931"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415855_145093_349961"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="382"/>
      <waypoint x="253" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_734321_416459" xmi:uuid="ab9ad880-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574488_464144_323947"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415864_945211_349976"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="402"/>
      <waypoint x="253" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_667657_416462" xmi:uuid="abbcc7f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574564_903118_323963"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415873_616896_349991"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="422"/>
      <waypoint x="253" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_201586_416465" xmi:uuid="abbcf010-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574641_354889_323979"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415889_763833_350006"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="442"/>
      <waypoint x="253" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_308982_416468" xmi:uuid="abbe5910-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574737_26450_323995"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415904_915912_350021"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="462"/>
      <waypoint x="253" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_15718_416471" xmi:uuid="abbe6cd0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574820_98617_324011"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415916_440551_350036"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="482"/>
      <waypoint x="253" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_537107_416474" xmi:uuid="abbe78e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574901_921369_324027"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415932_397214_350051"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="502"/>
      <waypoint x="253" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_223175_416477" xmi:uuid="abbe7ef0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601574992_369349_324043"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415942_44997_350066"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="522"/>
      <waypoint x="253" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_600418_416480" xmi:uuid="abbe8c00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575065_857521_324059"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415951_495849_350081"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="542"/>
      <waypoint x="253" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_489730_416483" xmi:uuid="abbe9770-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575138_516981_324075"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415960_282440_350096"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="562"/>
      <waypoint x="253" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_913299_416486" xmi:uuid="abbe9d40-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575212_30922_324091"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415969_822394_350111"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="582"/>
      <waypoint x="253" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_142206_416489" xmi:uuid="abbeb200-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575286_630762_324107"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415983_338473_350126"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="602"/>
      <waypoint x="253" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_682477_416492" xmi:uuid="abbec820-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575366_752424_324123"/>
      <source xmi:idref="_18_4_1_65b021e_1727446415993_635285_350141"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="622"/>
      <waypoint x="253" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_256617_416495" xmi:uuid="abbee170-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575443_852772_324139"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416003_36111_350156"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="642"/>
      <waypoint x="253" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_665681_416498" xmi:uuid="abbee7b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575517_886202_324155"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416012_566027_350171"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="662"/>
      <waypoint x="253" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_933185_416501" xmi:uuid="abbf0920-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575592_941395_324171"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416020_479265_350186"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="682"/>
      <waypoint x="253" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_643130_416504" xmi:uuid="abbf28d0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575668_538222_324187"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416031_182934_350201"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="702"/>
      <waypoint x="253" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_746903_416507" xmi:uuid="abbf3f80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575749_84801_324203"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416040_129802_350216"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="722"/>
      <waypoint x="253" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_315518_416510" xmi:uuid="abbf4670-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575828_994722_324219"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416050_248834_350231"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="742"/>
      <waypoint x="253" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_937942_416513" xmi:uuid="abbf5520-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575905_964417_324235"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416060_431406_350246"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="762"/>
      <waypoint x="253" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_758012_416516" xmi:uuid="abbf5b20-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601575989_910690_324251"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416072_34988_350261"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="782"/>
      <waypoint x="253" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_878257_416519" xmi:uuid="abbf60c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601576067_68406_324267"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416081_383663_350276"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="802"/>
      <waypoint x="253" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513383_575604_416522" xmi:uuid="abbf6650-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601576143_748335_324283"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416090_395888_350291"/>
      <target xmi:idref="_18_4_1_65b021e_1727446414300_221152_349687"/>
      <waypoint x="608" y="822"/>
      <waypoint x="253" y="822"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="611" height="900"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1624965282159_142612_71498" xmi:uuid="ab2bd290-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408324396_295926_72418"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965915054_158215_71811" xmi:uuid="ab3a88a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965915024_504207_71807"/>
      <bounds x="1259" y="231" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624966380133_17279_74587" xmi:uuid="acd7eed0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624966382253_502944_74588"/>
      <source xmi:idref="_18_4_1_8be0287_1624965812106_299022_71757"/>
      <target xmi:idref="_18_4_1_8be0287_1624966355602_150270_74549"/>
      <waypoint x="1001" y="280"/>
      <waypoint x="1001" y="91"/>
      <waypoint x="730" y="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965379618_69815_71530" xmi:uuid="b253af10-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953432_937477_43188"/>
      <ownedElement xmi:id="abd1cac0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="abd1cc80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953432_937477_43188"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ac1b35c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ac1b3760-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953432_937477_43188"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="23f16150-6c44-013d-d60e-0800270c66d6" xmi:uuid="23f16200-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2403e880-6c44-013d-d60e-0800270c66d6" xmi:uuid="2403e960-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624966355602_150270_74549" xmi:uuid="acd66b70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="ac965b20-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ac965c40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="acd4ec80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="acd4edf0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="546" y="84" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="448" y="56" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624967277304_464010_69609" xmi:uuid="ae887120-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624967279941_762270_69610"/>
      <source xmi:idref="_18_4_1_8be0287_1624965812106_299022_71757"/>
      <target xmi:idref="_18_4_1_8be0287_1624967269052_721595_69571"/>
      <waypoint x="1001" y="280"/>
      <waypoint x="1001" y="168"/>
      <waypoint x="742" y="168"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965379648_859087_71561" xmi:uuid="b28fef70-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953428_893403_43187"/>
      <ownedElement xmi:id="ad62a9f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ad62ab60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953428_893403_43187"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ada8b950-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ada8bb30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953428_893403_43187"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="27679d40-6c44-013d-d60e-0800270c66d6" xmi:uuid="27679e00-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="277b8d00-6c44-013d-d60e-0800270c66d6" xmi:uuid="277b8dd0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624967269052_721595_69571" xmi:uuid="ae84b020-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="ae36dc40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ae36ddc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="ae830e90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ae831000-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="567" y="161" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="448" y="133" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624967401382_25255_69737" xmi:uuid="b02a4440-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624967402474_921101_69738"/>
      <source xmi:idref="_18_4_1_8be0287_1624965812106_299022_71757"/>
      <target xmi:idref="_18_4_1_8be0287_1624967391444_420886_69699"/>
      <waypoint x="840" y="403"/>
      <waypoint x="673" y="403"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965379658_448654_71592" xmi:uuid="b2cc1680-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1603908626108_560808_89520"/>
      <ownedElement xmi:id="af0f3b40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="af0fe6b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1603908626108_560808_89520"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="af5294d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="af5296b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1603908626108_560808_89520"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="2acb0b80-6c44-013d-d60e-0800270c66d6" xmi:uuid="2acb0c10-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2acc6090-6c44-013d-d60e-0800270c66d6" xmi:uuid="2acc6150-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624967391444_420886_69699" xmi:uuid="b028cc30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="afe012d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="afe015e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b0268ae0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b0268c90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="490" y="385" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="448" y="357" width="307" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624967322981_196646_69657" xmi:uuid="b1d44b00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624967324759_761402_69658"/>
      <source xmi:idref="_18_4_1_8be0287_1624965812106_299022_71757"/>
      <target xmi:idref="_18_4_1_8be0287_1624967305883_396842_69619"/>
      <waypoint x="1001" y="280"/>
      <waypoint x="1001" y="245"/>
      <waypoint x="711" y="245"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965379668_156643_71623" xmi:uuid="b30840d0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953433_443016_43189"/>
      <ownedElement xmi:id="b0b0e480-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b0b0e5f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953433_443016_43189"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="b0f8fef0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b0f90080-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953433_443016_43189"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="2ea4f960-6c44-013d-d60e-0800270c66d6" xmi:uuid="2ea4fa40-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2eb6f910-6c44-013d-d60e-0800270c66d6" xmi:uuid="2eb6fa00-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624967305883_396842_69619" xmi:uuid="b1d2c8a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="b1885a30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b1885cd0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="b1d14440-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b1d145d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="483" y="238" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="448" y="210" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965379678_7705_71654" xmi:uuid="b30c2170-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408700900_492970_72548"/>
      <ownedElement xmi:id="b1df8a30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b1df8b50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408700900_492970_72548"/>
        <text>Item:ItemInSlotSelect</text>
      </ownedElement>
      <ownedElement xmi:id="b1e5f220-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b1e5f3c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408700900_492970_72548"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1632389876223_843537_77684" xmi:uuid="b1e747c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1632389717469_699649_77674"/>
        <ownedElement xmi:id="30d37e40-6c44-013d-d60e-0800270c66d6" xmi:uuid="30d37ee0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1632389717469_699649_77674"/>
          <bounds x="213" y="526" width="208" height="13"/>
          <text>slotRealSelect : Product_view_definition [1]</text>
        </ownedElement>
        <bounds x="195" y="535" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="532" width="161" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965379688_291276_71685" xmi:uuid="b3285780-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953435_876357_43190"/>
      <ownedElement xmi:id="b2372f10-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b2373040-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1571651953435_876357_43190"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624967353629_508493_69667" xmi:uuid="b260b850-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="32f4eb10-6c44-013d-d60e-0800270c66d6" xmi:uuid="32f4ebc0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="630" y="311" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="612" y="320" width="15" height="15"/>
      </ownedElement>
      <bounds x="371" y="308" width="256" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965379698_609411_71705" xmi:uuid="b3447bd0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1603908626115_53358_89521"/>
      <ownedElement xmi:id="b2b527e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b2b528d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1603908626115_53358_89521"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624967525343_317553_69813" xmi:uuid="b2e4acc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="350f0260-6c44-013d-d60e-0800270c66d6" xmi:uuid="350f0310-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="762" y="445" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="744" y="454" width="15" height="15"/>
      </ownedElement>
      <bounds x="588" y="441" width="171" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965379708_521758_71725" xmi:uuid="b3487120-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408405867_75040_72466"/>
      <ownedElement xmi:id="b308e8f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b308eac0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408405867_75040_72466"/>
        <text>Slot:SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="b30fb8c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b30fba10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622408405867_75040_72466"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624967741885_686290_70278" xmi:uuid="b3111e70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
        <ownedElement xmi:id="35b6b750-6c44-013d-d60e-0800270c66d6" xmi:uuid="35b6b920-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1623362691558_311755_84604"/>
          <bounds x="199" y="478" width="212" height="13"/>
          <text>slotDefinition : Attachment_slot_definition [1]</text>
        </ownedElement>
        <bounds x="181" y="488" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="483" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624965812106_299022_71757" xmi:uuid="b445ea50-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965812086_661979_71756"/>
      <ownedElement xmi:id="b3600f50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b36011c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965812086_661979_71756"/>
        <text>slotItem:Product_in_attachment_slot</text>
      </ownedElement>
      <ownedElement xmi:id="b3676630-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b36768a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624965812086_661979_71756"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="369ede60-6c44-013d-d60e-0800270c66d6" xmi:uuid="369edef0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="36b438c0-6c44-013d-d60e-0800270c66d6" xmi:uuid="36b43990-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624966212767_617664_74270" xmi:uuid="b44ed430-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-auxiliary_shape_representations"/>
          <ownedElement xmi:id="b40d1120-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b40d12e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-auxiliary_shape_representations"/>
            <text>auxiliary_shape_representations:shape_model</text>
          </ownedElement>
          <ownedElement xmi:id="b44d91e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b44d93b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-auxiliary_shape_representations"/>
            <text>[0..*]</text>
          </ownedElement>
          <bounds x="861" y="679" width="311" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624966212787_307771_74301" xmi:uuid="b4fb1c70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
          <ownedElement xmi:id="b4bc9b80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b4bc9d60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="b4f9e290-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b4f9e410-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="861" y="315" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624966212797_496388_74332" xmi:uuid="b55a6f10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
          <ownedElement xmi:id="b5287900-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b5287b10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="b558a170-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b558a380-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="861" y="448" width="100" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624966212807_845369_74363" xmi:uuid="b6056720-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_in_attachment_slot-name"/>
          <ownedElement xmi:id="b5a81be0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b5a81e00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_in_attachment_slot-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="b602dd10-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b602e320-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_in_attachment_slot-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="861" y="595" width="103" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624966212817_159999_74394" xmi:uuid="b71f7570-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-primary_shape_representation"/>
          <ownedElement xmi:id="b6cc35d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b6cc3770-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-primary_shape_representation"/>
            <text>primary_shape_representation:shape_model</text>
          </ownedElement>
          <ownedElement xmi:id="b71aa810-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b71aa9b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-primary_shape_representation"/>
            <text>[0..1]</text>
          </ownedElement>
          <bounds x="861" y="735" width="304" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624966212827_266492_74425" xmi:uuid="b7da9e40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_in_attachment_slot-related_view"/>
          <ownedElement xmi:id="b7a27bd0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b7a27d80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_in_attachment_slot-related_view"/>
            <text>related_view:Attachment_slot_definition</text>
          </ownedElement>
          <ownedElement xmi:id="b7d96c00-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b7d96de0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_in_attachment_slot-related_view"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="861" y="490" width="259" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624966212837_213447_74456" xmi:uuid="b885d3a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_in_attachment_slot-relating_view"/>
          <ownedElement xmi:id="b83ed860-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b83edbf0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_in_attachment_slot-relating_view"/>
            <text>relating_view:Product_view_definition</text>
          </ownedElement>
          <ownedElement xmi:id="b8845890-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b8845a00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_in_attachment_slot-relating_view"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="861" y="539" width="246" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624966212847_465829_74487" xmi:uuid="b91f3980-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
          <ownedElement xmi:id="b8d670d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b8d672b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="b91d1140-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b91d1300-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="861" y="973" width="162" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624966212857_340724_74518" xmi:uuid="ba021c60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-shape_type"/>
          <ownedElement xmi:id="b9b303d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b9b307c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-shape_type"/>
            <text>shape_type:contextual_shape_type_enumeration</text>
          </ownedElement>
          <ownedElement xmi:id="b9fea9f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="b9feabc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-shape_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="707" width="325" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="840" y="280" width="353" height="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624966406704_163372_74604" xmi:uuid="b445f2a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624966408325_272117_74605"/>
      <source xmi:idref="_18_4_1_8be0287_1624965915054_158215_71811"/>
      <target xmi:idref="_18_4_1_8be0287_1624965812106_299022_71757"/>
      <waypoint x="1259" y="238"/>
      <waypoint x="1138" y="238"/>
      <waypoint x="1138" y="280"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624967363894_920379_69686" xmi:uuid="b445fa70-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624967365641_502084_69687"/>
      <source xmi:idref="_18_4_1_8be0287_1624966212787_307771_74301"/>
      <target xmi:idref="_18_4_1_8be0287_1624967353629_508493_69667"/>
      <waypoint x="861" y="329"/>
      <waypoint x="627" y="329"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624967757750_126277_70297" xmi:uuid="b4460240-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624967759700_137861_70298"/>
      <source xmi:idref="_18_4_1_8be0287_1624966212827_266492_74425"/>
      <target xmi:idref="_18_4_1_8be0287_1624967741885_686290_70278"/>
      <waypoint x="861" y="501"/>
      <waypoint x="196" y="501"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969391604_169043_71219" xmi:uuid="b451cc60-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624968182021_491228_71207"/>
      <ownedElement xmi:id="ba516940-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ba516ac0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624968182021_491228_71207"/>
        <text>AssociationType:ClassSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ba5a7d50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ba5a81b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624968182021_491228_71207"/>
        <text>[0..1]</text>
      </ownedElement>
      <bounds x="42" y="973" width="208" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969433521_187879_71250" xmi:uuid="b45d9870-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624968095913_108930_71195"/>
      <ownedElement xmi:id="ba9effc0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ba9f0160-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624968095913_108930_71195"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="baab32d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="baab3470-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624968095913_108930_71195"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="595" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969497106_806163_71323" xmi:uuid="b46061e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_159061_71287"/>
      <ownedElement xmi:id="bab40450-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bab40760-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_159061_71287"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="bac30c40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bac30e10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_159061_71287"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="224" y="889" width="207" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969497122_369248_71354" xmi:uuid="b46c4380-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_624013_71283"/>
      <ownedElement xmi:id="bb0eb7e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bb0eba10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_624013_71283"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="bb15f270-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bb15f390-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_624013_71283"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969705704_617307_71712" xmi:uuid="bb170830-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="46d839e0-6c44-013d-d60e-0800270c66d6" xmi:uuid="46d83ab0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="542" y="667" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="524" y="676" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="371" y="672" width="161" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969497122_328920_71385" xmi:uuid="b4787520-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_148169_71285"/>
      <ownedElement xmi:id="bb414020-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bb4141c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_148169_71285"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969581070_150441_71583" xmi:uuid="bb4698e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="4827cac0-6c44-013d-d60e-0800270c66d6" xmi:uuid="4827cb70-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="532" y="608" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="595" y="600" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969581070_146461_71593" xmi:uuid="bb478320-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="48e85c90-6c44-013d-d60e-0800270c66d6" xmi:uuid="48e8cb50-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="794" y="592" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="776" y="601" width="15" height="15"/>
      </ownedElement>
      <bounds x="595" y="588" width="196" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969844125_602456_71907" xmi:uuid="bd2a2650-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969846122_183559_71908"/>
      <source xmi:idref="_18_4_1_8be0287_1624965812106_299022_71757"/>
      <target xmi:idref="_18_4_1_8be0287_1624969748635_101631_71789"/>
      <waypoint x="840" y="865"/>
      <waypoint x="725" y="865"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969497138_280847_71405" xmi:uuid="b4d7bcd0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_367185_71286"/>
      <ownedElement xmi:id="bb772210-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bb7723d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_367185_71286"/>
        <text>nameLang:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="bb7e5d30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bb7e5ec0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_367185_71286"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="49e6c000-6c44-013d-d60e-0800270c66d6" xmi:uuid="49e6c0a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="49f74780-6c44-013d-d60e-0800270c66d6" xmi:uuid="49f74860-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624969748604_506684_71758" xmi:uuid="bbfbad80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="bbb0f000-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bbb0f1b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="bbf8b530-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bbf8b6e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="497" y="889" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624969748635_101631_71789" xmi:uuid="bca6fa20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="bc76ccd0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bc76ced0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="bca5a790-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bca5a930-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="497" y="854" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624969748651_60656_71820" xmi:uuid="bd28f3b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="bcfa1230-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bcfa13a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="bd27c080-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bd27c260-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="497" y="819" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="483" y="784" width="273" height="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969497138_645188_71436" xmi:uuid="b4e3d430-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_112091_71282"/>
      <ownedElement xmi:id="bd592940-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bd592a60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_112091_71282"/>
        <text>lang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="bd60c9c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bd60cbc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_112091_71282"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969825249_375975_71868" xmi:uuid="bd62d710-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="4fc82330-6c44-013d-d60e-0800270c66d6" xmi:uuid="4fc82450-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="327" y="752" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="317" y="734" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="280" y="714" width="133" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969497153_436635_71467" xmi:uuid="b4f09980-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_55822_71281"/>
      <ownedElement xmi:id="bdc1cd40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bdc1cf40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_55822_71281"/>
        <text>nameSelect:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969525577_683235_71518" xmi:uuid="bdc87070-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="52271480-6c44-013d-d60e-0800270c66d6" xmi:uuid="522715f0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="226" y="591" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="280" y="600" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969525593_935948_71528" xmi:uuid="bdc9b420-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="53a93590-6c44-013d-d60e-0800270c66d6" xmi:uuid="53a99b40-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="502" y="591" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="484" y="600" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969525609_588601_71538" xmi:uuid="bdcb2e20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="554c8cb0-6c44-013d-d60e-0800270c66d6" xmi:uuid="554db830-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="422" y="647" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="412" y="629" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969525624_690837_71548" xmi:uuid="bdcd41b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="56482770-6c44-013d-d60e-0800270c66d6" xmi:uuid="5651d7c0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="326" y="647" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="316" y="629" width="15" height="15"/>
      </ownedElement>
      <bounds x="280" y="588" width="219" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969724658_69782_71748" xmi:uuid="bf0ae4b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969726561_310134_71749"/>
      <source xmi:idref="_18_4_1_8be0287_1624965812106_299022_71757"/>
      <target xmi:idref="_18_4_1_8be0287_1624969684985_503929_71681"/>
      <waypoint x="840" y="753"/>
      <waypoint x="742" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969497153_31996_71487" xmi:uuid="b51d39f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_127903_71284"/>
      <ownedElement xmi:id="be614b60-339c-013a-17e4-45cc4a55db9f" xmi:uuid="be614d20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_127903_71284"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="be6c17c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="be6c1980-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969486342_127903_71284"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="57d2ec00-6c44-013d-d60e-0800270c66d6" xmi:uuid="57d2ed10-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="57e367d0-6c44-013d-d60e-0800270c66d6" xmi:uuid="57e36890-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624969684985_503929_71681" xmi:uuid="bf0988f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="bed68600-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bed687e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="bf086310-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bf086470-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="567" y="742" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="483" y="714" width="271" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969562097_864916_71573" xmi:uuid="b51d4310-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969563017_465443_71574"/>
      <source xmi:idref="_18_4_1_8be0287_1624969525577_683235_71518"/>
      <target xmi:idref="_18_4_1_8be0287_1624969433521_187879_71250"/>
      <waypoint x="280" y="606"/>
      <waypoint x="216" y="606"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969608962_765085_71614" xmi:uuid="b51d4ca0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969610117_26134_71615"/>
      <source xmi:idref="_18_4_1_8be0287_1624969581070_150441_71583"/>
      <target xmi:idref="_18_4_1_8be0287_1624969525593_935948_71528"/>
      <waypoint x="595" y="606"/>
      <waypoint x="499" y="606"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969616781_401428_71634" xmi:uuid="b51d9130-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969617889_583395_71635"/>
      <source xmi:idref="_18_4_1_8be0287_1624966212807_845369_74363"/>
      <target xmi:idref="_18_4_1_8be0287_1624969581070_146461_71593"/>
      <waypoint x="861" y="609"/>
      <waypoint x="791" y="609"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969644909_138428_71654" xmi:uuid="b51d9a20-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969646344_972632_71655"/>
      <source xmi:idref="_18_4_1_8be0287_1624969497122_369248_71354"/>
      <target xmi:idref="_18_4_1_8be0287_1624969525609_588601_71538"/>
      <waypoint x="420" y="672"/>
      <waypoint x="420" y="644"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969662147_660382_71671" xmi:uuid="b51da230-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969663691_761607_71672"/>
      <source xmi:idref="_18_4_1_8be0287_1624969497138_645188_71436"/>
      <target xmi:idref="_18_4_1_8be0287_1624969525624_690837_71548"/>
      <waypoint x="322" y="714"/>
      <waypoint x="322" y="644"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969718543_571972_71731" xmi:uuid="b51dad50-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969720243_93230_71732"/>
      <source xmi:idref="_18_4_1_8be0287_1624969497153_31996_71487"/>
      <target xmi:idref="_18_4_1_8be0287_1624969705704_617307_71712"/>
      <waypoint x="620" y="714"/>
      <waypoint x="620" y="683"/>
      <waypoint x="539" y="683"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969809663_263217_71858" xmi:uuid="b51db530-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969811145_533633_71859"/>
      <source xmi:idref="_18_4_1_8be0287_1624969748604_506684_71758"/>
      <target xmi:idref="_18_4_1_8be0287_1624969497106_806163_71323"/>
      <waypoint x="497" y="900"/>
      <waypoint x="431" y="900"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969837370_158956_71887" xmi:uuid="b51dbd30-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969838368_626309_71888"/>
      <source xmi:idref="_18_4_1_8be0287_1624969748651_60656_71820"/>
      <target xmi:idref="_18_4_1_8be0287_1624969825249_375975_71868"/>
      <waypoint x="497" y="830"/>
      <waypoint x="326" y="830"/>
      <waypoint x="326" y="749"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624972856668_615998_72188" xmi:uuid="c1b591e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624972858384_160247_72189"/>
      <source xmi:idref="_18_4_1_8be0287_1624965812106_299022_71757"/>
      <target xmi:idref="_18_4_1_8be0287_1624972821942_333723_72119"/>
      <waypoint x="1005" y="1022"/>
      <waypoint x="1005" y="1110"/>
      <waypoint x="681" y="1110"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969960503_225407_71933" xmi:uuid="b57cb450-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969952516_738849_71917"/>
      <ownedElement xmi:id="bf425540-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bf425670-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969952516_738849_71917"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bf480930-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bf480a60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969952516_738849_71917"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="5aca0480-6c44-013d-d60e-0800270c66d6" xmi:uuid="5acb4190-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5ae0bc30-6c44-013d-d60e-0800270c66d6" xmi:uuid="5ae4cb10-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624972821911_183154_72088" xmi:uuid="c05dd300-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="bfeebfa0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="bfeec1b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="c05c62b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c05c6440-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="497" y="1064" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624972821942_333723_72119" xmi:uuid="c13f33c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c0f7adb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c0f7af60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c13e0be0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c13e0d30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="497" y="1099" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1624972821958_743837_72150" xmi:uuid="c1b41ef0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="c178c210-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c178c380-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="c1b29b80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c1b29f80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="497" y="1134" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="483" y="1036" width="273" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969960518_20592_71964" xmi:uuid="b58921b0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969952516_797138_71919"/>
      <ownedElement xmi:id="c1efcb80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c1efcd40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969952516_797138_71919"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969992709_441621_72015" xmi:uuid="c1f6d960-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="646defc0-6c44-013d-d60e-0800270c66d6" xmi:uuid="646df0a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="542" y="969" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <bounds x="524" y="978" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969992709_142771_72025" xmi:uuid="c1f84b40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
        <ownedElement xmi:id="661fedc0-6c44-013d-d60e-0800270c66d6" xmi:uuid="661ff0e0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
          <bounds x="289" y="970" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="343" y="979" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1624969992725_285139_72035" xmi:uuid="c1f9b3b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
        <ownedElement xmi:id="67e29650-6c44-013d-d60e-0800270c66d6" xmi:uuid="67e29730-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
          <bounds x="390" y="1018" width="54" height="13"/>
          <text>class [0..1]</text>
        </ownedElement>
        <bounds x="380" y="1000" width="15" height="15"/>
      </ownedElement>
      <bounds x="343" y="966" width="196" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624969960518_166348_71984" xmi:uuid="b58bf810-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969952516_560692_71918"/>
      <ownedElement xmi:id="c200e080-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c200e230-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969952516_560692_71918"/>
        <text>theType:String</text>
      </ownedElement>
      <ownedElement xmi:id="c20810f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c20812b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624969952516_560692_71918"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="196" y="1134" width="212" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624970011819_302968_72058" xmi:uuid="b58c06a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624970015111_510133_72059"/>
      <source xmi:idref="_18_4_1_8be0287_1624969992709_142771_72025"/>
      <target xmi:idref="_18_4_1_8be0287_1624969391604_169043_71219"/>
      <waypoint x="343" y="984"/>
      <waypoint x="250" y="984"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624972776653_344397_72075" xmi:uuid="b58c0e40-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624972778463_207124_72076"/>
      <source xmi:idref="_18_4_1_8be0287_1624966212847_465829_74487"/>
      <target xmi:idref="_18_4_1_8be0287_1624969992709_441621_72015"/>
      <waypoint x="861" y="984"/>
      <waypoint x="539" y="984"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624972937249_40802_72205" xmi:uuid="b58c15f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624972938201_250603_72206"/>
      <source xmi:idref="_18_4_1_8be0287_1624972821958_743837_72150"/>
      <target xmi:idref="_18_4_1_8be0287_1624969960518_166348_71984"/>
      <waypoint x="497" y="1145"/>
      <waypoint x="408" y="1145"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1624972945923_684908_72222" xmi:uuid="b58c1d90-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1624972947545_113210_72223"/>
      <source xmi:idref="_18_4_1_8be0287_1624972821911_183154_72088"/>
      <target xmi:idref="_18_4_1_8be0287_1624969992725_285139_72035"/>
      <waypoint x="497" y="1075"/>
      <waypoint x="389" y="1075"/>
      <waypoint x="389" y="1015"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031017920_757304_74175" xmi:uuid="b58c21e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1571651889195_770640_42366"/>
      <bounds x="273" y="35" width="113" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625052198576_842778_76170" xmi:uuid="b58c2e70-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625052200481_306364_76171"/>
      <source xmi:idref="_18_4_1_8be0287_1624966212797_496388_74332"/>
      <target xmi:idref="_18_4_1_8be0287_1624967525343_317553_69813"/>
      <waypoint x="861" y="462"/>
      <waypoint x="759" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1632389885545_270703_77703" xmi:uuid="b58c37d0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632389886699_103162_77704"/>
      <source xmi:idref="_18_4_1_8be0287_1624966212837_213447_74456"/>
      <target xmi:idref="_18_4_1_8be0287_1632389876223_843537_77684"/>
      <waypoint x="861" y="543"/>
      <waypoint x="210" y="543"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1262" height="1184"/>
    <name>ItemInSlot</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446413477_821565_348629" xmi:uuid="ace27430-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214318254_324090_69406"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413511_518194_348661" xmi:uuid="ae42bf90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029698854_337666_72192"/>
      <ownedElement xmi:id="ae08d6c0-6c43-013d-d60e-0800270c66d6" xmi:uuid="ae08d840-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029698854_337666_72192"/>
        <text>theSlot:Attachment_slot_as_realized</text>
      </ownedElement>
      <ownedElement xmi:id="ae4137d0-6c43-013d-d60e-0800270c66d6" xmi:uuid="ae413890-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029698854_337666_72192"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="231" height="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413530_50033_348695" xmi:uuid="ae521680-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="587" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413543_488772_348710" xmi:uuid="ae6aaee0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="587" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413560_204923_348725" xmi:uuid="ae8a6990-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="587" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413569_297234_348740" xmi:uuid="ae8bb300-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="587" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413580_525447_348755" xmi:uuid="ae9aee60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="587" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413591_810268_348770" xmi:uuid="aec58f00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="587" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413601_380404_348785" xmi:uuid="aec6db30-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="587" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413617_564997_348800" xmi:uuid="aee3ca30-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="587" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413630_978580_348815" xmi:uuid="aefd3d00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="587" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413639_773694_348830" xmi:uuid="af16e990-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="587" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413655_545071_348845" xmi:uuid="af18b9f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="587" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413670_648359_348860" xmi:uuid="af4e94e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="587" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413686_189214_348875" xmi:uuid="af679bd0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="587" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413702_267111_348890" xmi:uuid="af690c60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="587" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413713_827509_348905" xmi:uuid="afad94e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="587" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413727_757884_348920" xmi:uuid="afc2bf20-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="587" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413738_968059_348935" xmi:uuid="afc41680-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="587" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413748_418168_348950" xmi:uuid="afc56440-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="587" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413756_194754_348965" xmi:uuid="b007bc40-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="587" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413773_646047_348980" xmi:uuid="b0219640-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="587" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413791_783301_348995" xmi:uuid="b03cc4c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="587" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413804_380896_349010" xmi:uuid="b04f10c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="587" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413821_182825_349025" xmi:uuid="b0691540-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="587" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413828_592007_349040" xmi:uuid="b0781ae0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643268851717_322008_86077"/>
      <bounds x="587" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413837_673397_349055" xmi:uuid="b08e45f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643269416144_30883_86580"/>
      <bounds x="587" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413845_207137_349070" xmi:uuid="b098f300-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643270131067_298147_86914"/>
      <bounds x="587" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413854_600934_349085" xmi:uuid="b0b2d6a0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="587" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413868_534540_349100" xmi:uuid="b0e87440-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="587" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413879_357339_349115" xmi:uuid="b0e9bcd0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="587" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413888_542211_349130" xmi:uuid="b0eb06f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="587" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413898_48805_349145" xmi:uuid="b11a00f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="587" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413907_454540_349160" xmi:uuid="b133c520-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="587" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413917_333493_349175" xmi:uuid="b13511b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="587" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413927_693972_349190" xmi:uuid="b15c6320-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="587" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413937_638315_349205" xmi:uuid="b15db120-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="587" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413947_714946_349220" xmi:uuid="b17bfcd0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="587" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413958_231754_349235" xmi:uuid="b1973100-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="587" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413967_277749_349250" xmi:uuid="b1aaed50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570204497794_443467_105732"/>
      <bounds x="587" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446413976_956166_349265" xmi:uuid="b1c93f30-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="587" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_154172_416228" xmi:uuid="b1c950c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601564582_191720_320045"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413530_50033_348695"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="62"/>
      <waypoint x="276" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_138117_416231" xmi:uuid="b1c957c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601564672_776791_320061"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413543_488772_348710"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="82"/>
      <waypoint x="276" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_116750_416234" xmi:uuid="b1c95ea0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601564747_569522_320077"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413560_204923_348725"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="102"/>
      <waypoint x="276" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_564994_416237" xmi:uuid="b1c965b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601564830_626008_320093"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413569_297234_348740"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="122"/>
      <waypoint x="276" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_381140_416240" xmi:uuid="b1c96d00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601564904_911627_320109"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413580_525447_348755"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="142"/>
      <waypoint x="276" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_983647_416243" xmi:uuid="b1c973f0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601564982_35933_320125"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413591_810268_348770"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="162"/>
      <waypoint x="276" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_852483_416246" xmi:uuid="b1c97b30-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565059_710202_320141"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413601_380404_348785"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="182"/>
      <waypoint x="276" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_776941_416249" xmi:uuid="b1c98300-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565139_427643_320157"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413617_564997_348800"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="202"/>
      <waypoint x="276" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_622571_416252" xmi:uuid="b1c989e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565222_866258_320173"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413630_978580_348815"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="222"/>
      <waypoint x="276" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_866482_416255" xmi:uuid="b1ca0700-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565299_514363_320189"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413639_773694_348830"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="242"/>
      <waypoint x="276" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_365678_416258" xmi:uuid="b1ca0da0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565376_18760_320205"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413655_545071_348845"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="262"/>
      <waypoint x="276" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_225433_416261" xmi:uuid="b1ca12c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565460_755570_320221"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413670_648359_348860"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="282"/>
      <waypoint x="276" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_759529_416264" xmi:uuid="b1ca17c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565542_123721_320237"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413686_189214_348875"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="302"/>
      <waypoint x="276" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_884588_416267" xmi:uuid="b1ca1ee0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565624_61090_320253"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413702_267111_348890"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="322"/>
      <waypoint x="276" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_581329_416270" xmi:uuid="b1ca23c0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565713_283306_320269"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413713_827509_348905"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="342"/>
      <waypoint x="276" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_629790_416273" xmi:uuid="b1ca2af0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565789_745203_320285"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413727_757884_348920"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="362"/>
      <waypoint x="276" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_859558_416276" xmi:uuid="b1ca2fe0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565869_824936_320301"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413738_968059_348935"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="382"/>
      <waypoint x="276" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_356193_416279" xmi:uuid="b1ca36b0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601565944_730746_320317"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413748_418168_348950"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="402"/>
      <waypoint x="276" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_910184_416282" xmi:uuid="b1ca3b60-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566022_630388_320333"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413756_194754_348965"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="422"/>
      <waypoint x="276" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_166829_416285" xmi:uuid="b1ca4a20-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566095_3210_320349"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413773_646047_348980"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="442"/>
      <waypoint x="276" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_427969_416288" xmi:uuid="b1ca52e0-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566175_714893_320365"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413791_783301_348995"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="462"/>
      <waypoint x="276" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513351_541950_416291" xmi:uuid="b1ca5a30-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566262_314844_320381"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413804_380896_349010"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="482"/>
      <waypoint x="276" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_700581_416294" xmi:uuid="b1ca6100-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566335_56245_320397"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413821_182825_349025"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="502"/>
      <waypoint x="276" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_633830_416297" xmi:uuid="b1ca6600-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566418_138759_320413"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413828_592007_349040"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="522"/>
      <waypoint x="276" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_860950_416300" xmi:uuid="b1ca6e50-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566493_673894_320429"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413837_673397_349055"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="542"/>
      <waypoint x="276" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_190612_416303" xmi:uuid="b1ca7460-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566567_873023_320445"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413845_207137_349070"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="562"/>
      <waypoint x="276" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_271512_416306" xmi:uuid="b1ca7e80-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566642_958056_320461"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413854_600934_349085"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="582"/>
      <waypoint x="276" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_123109_416309" xmi:uuid="b1ca8390-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566725_294771_320477"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413868_534540_349100"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="602"/>
      <waypoint x="276" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_256978_416312" xmi:uuid="b1ca8b00-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566807_248806_320493"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413879_357339_349115"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="622"/>
      <waypoint x="276" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_444_416315" xmi:uuid="b1ca9400-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566885_264299_320509"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413888_542211_349130"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="642"/>
      <waypoint x="276" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_568595_416318" xmi:uuid="b1ca9960-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601566960_665189_320525"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413898_48805_349145"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="662"/>
      <waypoint x="276" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_103658_416321" xmi:uuid="b1caa100-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601567038_679171_320541"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413907_454540_349160"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="682"/>
      <waypoint x="276" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_5687_416324" xmi:uuid="b1caa620-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601567113_184312_320557"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413917_333493_349175"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="702"/>
      <waypoint x="276" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_249790_416327" xmi:uuid="b1caac90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601567191_678317_320573"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413927_693972_349190"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="722"/>
      <waypoint x="276" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_356784_416330" xmi:uuid="b1cabc40-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601567268_970454_320589"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413937_638315_349205"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="742"/>
      <waypoint x="276" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_700835_416333" xmi:uuid="b1cac410-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601567346_96136_320605"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413947_714946_349220"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="762"/>
      <waypoint x="276" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_304791_416336" xmi:uuid="b1cac980-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601567420_954159_320621"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413958_231754_349235"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="782"/>
      <waypoint x="276" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_730042_416339" xmi:uuid="b1cace90-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601567496_166597_320637"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413967_277749_349250"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="802"/>
      <waypoint x="276" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513352_704389_416342" xmi:uuid="b1cad460-6c43-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1696601567571_661348_320653"/>
      <source xmi:idref="_18_4_1_65b021e_1727446413976_956166_349265"/>
      <target xmi:idref="_18_4_1_65b021e_1727446413511_518194_348661"/>
      <waypoint x="587" y="822"/>
      <waypoint x="276" y="822"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="590" height="900"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446416321_452002_350576" xmi:uuid="af86a350-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416349_195251_350608" xmi:uuid="b0c127d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623137934973_564696_78987"/>
      <ownedElement xmi:id="b0a49700-6c42-013d-d60e-0800270c66d6" xmi:uuid="b0a497c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623137934973_564696_78987"/>
        <text>theSlot:Attachment_slot</text>
      </ownedElement>
      <ownedElement xmi:id="b0c11ac0-6c42-013d-d60e-0800270c66d6" xmi:uuid="b0c11b60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623137934973_564696_78987"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="166" height="750"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416365_325737_350642" xmi:uuid="b0e56790-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="615" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416376_57226_350657" xmi:uuid="b0fc28d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="615" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416392_954250_350672" xmi:uuid="b11c16e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="615" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416402_588266_350687" xmi:uuid="b137a190-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="615" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416410_675377_350702" xmi:uuid="b138fe60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="615" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416420_81129_350717" xmi:uuid="b155f710-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="615" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416429_400444_350732" xmi:uuid="b16e3bf0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="615" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416443_831194_350747" xmi:uuid="b16f7c30-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="615" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416454_239960_350762" xmi:uuid="b187d940-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="615" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416463_279822_350777" xmi:uuid="b19875e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="615" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416477_7738_350792" xmi:uuid="b1c80f00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="615" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416493_8199_350807" xmi:uuid="b1c95500-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="615" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416504_595383_350822" xmi:uuid="b1cad5e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="615" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416517_113846_350837" xmi:uuid="b22316a0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="615" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416527_285028_350852" xmi:uuid="b23d8480-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="615" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416537_371109_350867" xmi:uuid="b2403630-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="615" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416546_661285_350882" xmi:uuid="b2473790-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="615" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416562_160289_350897" xmi:uuid="b25cb450-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="615" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416578_447999_350912" xmi:uuid="b28a7790-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="615" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416591_875668_350927" xmi:uuid="b29b1580-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="615" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416606_453521_350942" xmi:uuid="b2b4d0d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="615" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416614_754818_350957" xmi:uuid="b2b61d60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643268851717_322008_86077"/>
      <bounds x="615" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416622_778863_350972" xmi:uuid="b2cfe060-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643269416144_30883_86580"/>
      <bounds x="615" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416631_96393_350987" xmi:uuid="b2d12a00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643270131067_298147_86914"/>
      <bounds x="615" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416640_492033_351002" xmi:uuid="b31fbe30-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="615" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416655_109065_351017" xmi:uuid="b3337a70-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="615" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416666_361760_351032" xmi:uuid="b348a970-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="615" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416677_40285_351047" xmi:uuid="b349f270-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="615" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416686_784402_351062" xmi:uuid="b366e450-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="615" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416695_321908_351077" xmi:uuid="b386cd60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="615" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416706_335280_351092" xmi:uuid="b3885fa0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="615" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446416716_713974_351107" xmi:uuid="b3ab7390-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="615" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446418090_83632_351122" xmi:uuid="b3bdc280-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="615" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446418102_473699_351137" xmi:uuid="b3d77ea0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="615" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446418113_878743_351152" xmi:uuid="b3f5ce20-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="615" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_538518_416567" xmi:uuid="b3f5df90-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911532_745445_71322"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416365_325737_350642"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="62"/>
      <waypoint x="211" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_193393_416570" xmi:uuid="b3f5e610-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911603_588850_71338"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416376_57226_350657"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="82"/>
      <waypoint x="211" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_149071_416573" xmi:uuid="b3f5eca0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911665_876251_71354"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416392_954250_350672"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="102"/>
      <waypoint x="211" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_977209_416576" xmi:uuid="b3f5f400-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911728_273172_71370"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416402_588266_350687"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="122"/>
      <waypoint x="211" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_57572_416579" xmi:uuid="b3f5fad0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911794_725939_71386"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416410_675377_350702"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="142"/>
      <waypoint x="211" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_164726_416582" xmi:uuid="b3f60120-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911852_938763_71402"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416420_81129_350717"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="162"/>
      <waypoint x="211" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_124940_416585" xmi:uuid="b3f60900-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911914_573475_71418"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416429_400444_350732"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="182"/>
      <waypoint x="211" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_493189_416588" xmi:uuid="b3f61440-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911975_671921_71434"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416443_831194_350747"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="202"/>
      <waypoint x="211" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_286425_416591" xmi:uuid="b3f61ce0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912037_801010_71450"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416454_239960_350762"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="222"/>
      <waypoint x="211" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_496400_416594" xmi:uuid="b3f62370-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912097_420423_71466"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416463_279822_350777"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="242"/>
      <waypoint x="211" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_69083_416597" xmi:uuid="b3f629e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912156_972977_71482"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416477_7738_350792"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="262"/>
      <waypoint x="211" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_189710_416600" xmi:uuid="b3f63030-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912223_197637_71498"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416493_8199_350807"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="282"/>
      <waypoint x="211" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_173268_416603" xmi:uuid="b3f63650-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912286_165199_71514"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416504_595383_350822"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="302"/>
      <waypoint x="211" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_673058_416606" xmi:uuid="b3f63e20-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912343_536615_71530"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416517_113846_350837"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="322"/>
      <waypoint x="211" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_376607_416609" xmi:uuid="b3f644b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912404_543986_71546"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416527_285028_350852"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="342"/>
      <waypoint x="211" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_47489_416612" xmi:uuid="b3f64c10-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912464_194200_71562"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416537_371109_350867"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="362"/>
      <waypoint x="211" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_560312_416615" xmi:uuid="b3f65210-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912523_195238_71578"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416546_661285_350882"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="382"/>
      <waypoint x="211" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_71089_416618" xmi:uuid="b3f65770-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912582_105126_71594"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416562_160289_350897"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="402"/>
      <waypoint x="211" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_701930_416621" xmi:uuid="b3f65e00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912644_203548_71610"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416578_447999_350912"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="422"/>
      <waypoint x="211" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_865696_416624" xmi:uuid="b3f66380-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912708_586118_71626"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416591_875668_350927"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="442"/>
      <waypoint x="211" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_113519_416627" xmi:uuid="b3f66930-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912767_981300_71642"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416606_453521_350942"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="462"/>
      <waypoint x="211" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_512234_416630" xmi:uuid="b3f66e40-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912830_789995_71658"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416614_754818_350957"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="482"/>
      <waypoint x="211" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_526640_416633" xmi:uuid="b3f67480-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912887_847774_71674"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416622_778863_350972"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="502"/>
      <waypoint x="211" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_60542_416636" xmi:uuid="b3f67b00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147912943_409774_71690"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416631_96393_350987"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="522"/>
      <waypoint x="211" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_192160_416639" xmi:uuid="b3f68130-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913003_858246_71706"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416640_492033_351002"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="542"/>
      <waypoint x="211" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_834062_416642" xmi:uuid="b3f68760-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913058_632766_71722"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416655_109065_351017"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="562"/>
      <waypoint x="211" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_439271_416645" xmi:uuid="b4099030-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913117_883090_71738"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416666_361760_351032"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="582"/>
      <waypoint x="211" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_669930_416648" xmi:uuid="b40997f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913176_344681_71754"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416677_40285_351047"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="602"/>
      <waypoint x="211" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_949686_416651" xmi:uuid="b4099df0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913235_936879_71770"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416686_784402_351062"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="622"/>
      <waypoint x="211" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_124515_416654" xmi:uuid="b409a510-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913292_583732_71786"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416695_321908_351077"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="642"/>
      <waypoint x="211" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_784186_416657" xmi:uuid="b409ab00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913348_757486_71802"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416706_335280_351092"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="662"/>
      <waypoint x="211" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_651328_416660" xmi:uuid="b409b110-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913404_244730_71818"/>
      <source xmi:idref="_18_4_1_65b021e_1727446416716_713974_351107"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="682"/>
      <waypoint x="211" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_243501_416663" xmi:uuid="b409b740-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913462_635189_71834"/>
      <source xmi:idref="_18_4_1_65b021e_1727446418090_83632_351122"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="702"/>
      <waypoint x="211" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_264785_416666" xmi:uuid="b409bd60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913520_33190_71850"/>
      <source xmi:idref="_18_4_1_65b021e_1727446418102_473699_351137"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="722"/>
      <waypoint x="211" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446513406_357264_416669" xmi:uuid="b409c350-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147913578_491768_71866"/>
      <source xmi:idref="_18_4_1_65b021e_1727446418113_878743_351152"/>
      <target xmi:idref="_18_4_1_65b021e_1727446416349_195251_350608"/>
      <waypoint x="615" y="742"/>
      <waypoint x="211" y="742"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="618" height="820"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1625029442286_772086_72092" xmi:uuid="c20b9a10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535729628_957239_73706"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031077964_356466_74200" xmi:uuid="c20fb400-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031077917_475237_74196"/>
      <bounds x="356" y="128" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625029491852_114755_72125" xmi:uuid="b59b5800-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029491836_413270_72124"/>
      <ownedElement xmi:id="c24bbf70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c24bc0f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029491836_413270_72124"/>
        <text>theSlot:Attachment_slot_as_planned</text>
      </ownedElement>
      <ownedElement xmi:id="c25339e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c2533b60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625029491836_413270_72124"/>
        <text>[0..1]</text>
      </ownedElement>
      <bounds x="77" y="161" width="245" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031148977_114595_74223" xmi:uuid="b59b6040-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031151051_640670_74224"/>
      <source xmi:idref="_18_4_1_8be0287_1625031077964_356466_74200"/>
      <target xmi:idref="_18_4_1_8be0287_1625029491852_114755_72125"/>
      <waypoint x="356" y="137"/>
      <waypoint x="186" y="137"/>
      <waypoint x="186" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031254487_138747_74322" xmi:uuid="b59b67c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_8be0287_1623158012147_298117_81229"/>
      <bounds x="105" y="42" width="78" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="359" height="201"/>
    <name>SlotAsPlanned</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1625031444554_955324_74429" xmi:uuid="c2552180-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535849807_770291_73755"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036525479_392754_72317" xmi:uuid="c3a757b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036529098_936461_72318"/>
      <source xmi:idref="_18_4_1_8be0287_1625033900190_28471_75411"/>
      <target xmi:idref="_18_4_1_8be0287_1625036513122_13045_72279"/>
      <waypoint x="956" y="546"/>
      <waypoint x="956" y="886"/>
      <waypoint x="821" y="886"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031662332_738473_74461" xmi:uuid="b5d9b580-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="c2c65720-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c2c658c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c2fb9150-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c2fb92e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="962aec70-6c44-013d-d60e-0800270c66d6" xmi:uuid="967c4970-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="97571ee0-6c44-013d-d60e-0800270c66d6" xmi:uuid="975720c0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625036513122_13045_72279" xmi:uuid="c3a5da20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c36a3330-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c36a35b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c3a462d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c3a46450-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="637" y="875" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="539" y="847" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625034610247_461787_70695" xmi:uuid="c4ee3120-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034612197_833898_70696"/>
      <source xmi:idref="_18_4_1_8be0287_1625033900190_28471_75411"/>
      <target xmi:idref="_18_4_1_8be0287_1625034597876_256703_70657"/>
      <waypoint x="847" y="210"/>
      <waypoint x="847" y="119"/>
      <waypoint x="672" y="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031662348_806065_74492" xmi:uuid="b6166200-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="c4117450-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c41175b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c4441cb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c4441e10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a5dad610-6c44-013d-d60e-0800270c66d6" xmi:uuid="a5dad700-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a5f473a0-6c44-013d-d60e-0800270c66d6" xmi:uuid="a5f47470-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034597876_256703_70657" xmi:uuid="c4ecd2f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="c4b44420-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c4b445a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="c4eb7bb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c4eb7d20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="497" y="105" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="378" y="77" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625034979321_560533_70864" xmi:uuid="c633d5e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034981240_355896_70865"/>
      <source xmi:idref="_18_4_1_8be0287_1625033900190_28471_75411"/>
      <target xmi:idref="_18_4_1_8be0287_1625034968352_359918_70826"/>
      <waypoint x="812" y="382"/>
      <waypoint x="603" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031662363_810896_74523" xmi:uuid="b652ffd0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="c555e610-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c555e7f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c58b8360-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c58b8500-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a9aad420-6c44-013d-d60e-0800270c66d6" xmi:uuid="a9aad5d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a9ac2280-6c44-013d-d60e-0800270c66d6" xmi:uuid="a9ac2370-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034968352_359918_70826" xmi:uuid="c6325ef0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="c5f8d0a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c5f8d1e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c630f460-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c630f5a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="420" y="371" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="378" y="343" width="307" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625034654659_936671_70743" xmi:uuid="c76ce4c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034657109_183469_70744"/>
      <source xmi:idref="_18_4_1_8be0287_1625033900190_28471_75411"/>
      <target xmi:idref="_18_4_1_8be0287_1625034630854_853135_70705"/>
      <waypoint x="847" y="210"/>
      <waypoint x="847" y="193"/>
      <waypoint x="634" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031662379_294336_74554" xmi:uuid="b68f37d0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="c69bbbf0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c69bbd60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="c6d12fe0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c6d13150-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ad2537f0-6c44-013d-d60e-0800270c66d6" xmi:uuid="ad2538a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ad3c06b0-6c44-013d-d60e-0800270c66d6" xmi:uuid="ad3c0dd0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034630854_853135_70705" xmi:uuid="c76baf80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="c73f3400-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c73f3520-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="c76ac380-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c76ac6d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="406" y="182" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="378" y="154" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031662395_707838_74585" xmi:uuid="b6ab3790-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="c7c42190-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c7c422e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625034878565_386127_70765" xmi:uuid="c7eff3a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b0faab90-6c44-013d-d60e-0800270c66d6" xmi:uuid="b0faac30-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="623" y="241" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="605" y="250" width="15" height="15"/>
      </ownedElement>
      <bounds x="371" y="238" width="249" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031662410_368235_74605" xmi:uuid="b6c88c00-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="c84591c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c8459380-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625034939336_458530_70797" xmi:uuid="c88e6c30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="b3482ef0-6c44-013d-d60e-0800270c66d6" xmi:uuid="b3483040-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="342" y="290" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="324" y="299" width="15" height="15"/>
      </ownedElement>
      <bounds x="182" y="287" width="157" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036626720_22832_72377" xmi:uuid="c9bcfa30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036630029_488262_72378"/>
      <source xmi:idref="_18_4_1_8be0287_1625033900190_28471_75411"/>
      <target xmi:idref="_18_4_1_8be0287_1625036610964_666588_72339"/>
      <waypoint x="956" y="546"/>
      <waypoint x="956" y="963"/>
      <waypoint x="779" y="963"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031662426_24674_74625" xmi:uuid="b7059790-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="c903f4d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c903f680-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c9304de0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c9305170-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b525dfc0-6c44-013d-d60e-0800270c66d6" xmi:uuid="b525e060-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b53e3200-6c44-013d-d60e-0800270c66d6" xmi:uuid="b53e3340-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625036610964_666588_72339" xmi:uuid="c9bbf830-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c98bd530-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c98bd8f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c9bb0cc0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="c9bb0e00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="595" y="952" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="539" y="924" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031662441_223597_74656" xmi:uuid="b721c580-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="ca11b9b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ca11bac0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625036593512_845596_72327" xmi:uuid="ca6d1220-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="b981b690-6c44-013d-d60e-0800270c66d6" xmi:uuid="b981b870-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="314" y="1017" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <bounds x="296" y="1026" width="15" height="15"/>
      </ownedElement>
      <bounds x="119" y="1015" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031874587_56092_75210" xmi:uuid="b721c9f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="371" y="21" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625033900190_28471_75411" xmi:uuid="b7aafb40-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033900159_655693_75410"/>
      <ownedElement xmi:id="cb014c30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cb015100-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033900159_655693_75410"/>
        <text>slotDesignToPlanned:Attachment_slot_design_to_planned</text>
      </ownedElement>
      <ownedElement xmi:id="cb0d09f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cb0d0be0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033900159_655693_75410"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="ba472dc0-6c44-013d-d60e-0800270c66d6" xmi:uuid="ba472e70-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ba57c160-6c44-013d-d60e-0800270c66d6" xmi:uuid="ba57c260-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034433313_19942_69800" xmi:uuid="cbc74ca0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-description"/>
          <ownedElement xmi:id="cb5c79c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cb5c7b70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="cbc5a6e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cbc5acd0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="833" y="245" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034433344_160893_69831" xmi:uuid="cca1a640-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-design"/>
          <ownedElement xmi:id="cc5cb2f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cc5cb4a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-design"/>
            <text>design:Attachment_slot_design</text>
          </ownedElement>
          <ownedElement xmi:id="cca03770-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cca03d50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-design"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="826" y="420" width="212" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034433359_166136_69862" xmi:uuid="cd144fc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-id"/>
          <ownedElement xmi:id="ccdaf8d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ccdafa40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="cd127ce0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cd1281e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="833" y="294" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034433359_714068_69893" xmi:uuid="cd88be20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-name"/>
          <ownedElement xmi:id="cd49c810-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cd49c9b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="cd86e2f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cd86e850-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="826" y="511" width="103" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034433375_549890_69924" xmi:uuid="ce58b920-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-planned"/>
          <ownedElement xmi:id="ce1a82b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ce1a8450-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-planned"/>
            <text>planned:Attachment_slot_as_planned</text>
          </ownedElement>
          <ownedElement xmi:id="ce574630-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ce5747c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_design_to_planned-planned"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="826" y="462" width="243" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="812" y="210" width="364" height="336"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625034455346_788318_69962" xmi:uuid="b7ab0560-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034459277_37262_69963"/>
      <source xmi:idref="_18_4_1_8be0287_1625031931046_660532_75337"/>
      <target xmi:idref="_18_4_1_8be0287_1625033900190_28471_75411"/>
      <waypoint x="1188" y="179"/>
      <waypoint x="991" y="179"/>
      <waypoint x="991" y="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625034910327_806918_70784" xmi:uuid="b7ab0fb0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034911513_887086_70785"/>
      <source xmi:idref="_18_4_1_8be0287_1625034433313_19942_69800"/>
      <target xmi:idref="_18_4_1_8be0287_1625034878565_386127_70765"/>
      <waypoint x="833" y="256"/>
      <waypoint x="620" y="256"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625034948072_929927_70816" xmi:uuid="b7ab16a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034949492_364636_70817"/>
      <source xmi:idref="_18_4_1_8be0287_1625052288365_430762_76205"/>
      <target xmi:idref="_18_4_1_8be0287_1625034939336_458530_70797"/>
      <waypoint x="518" y="305"/>
      <waypoint x="339" y="305"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035121733_281133_70934" xmi:uuid="b7ab1d90-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035123746_470131_70935"/>
      <source xmi:idref="_18_4_1_8be0287_1625034433344_160893_69831"/>
      <target xmi:idref="_18_4_1_9dd021a_1637077276054_813735_65474"/>
      <waypoint x="826" y="431"/>
      <waypoint x="192" y="431"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035184410_855918_71004" xmi:uuid="b7ab2450-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035186282_409851_71005"/>
      <source xmi:idref="_18_4_1_8be0287_1625034433375_549890_69924"/>
      <target xmi:idref="_18_4_1_9dd021a_1637077405814_250404_65517"/>
      <waypoint x="826" y="480"/>
      <waypoint x="219" y="480"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035694060_473181_71512" xmi:uuid="b7b6e900-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_892836_71476"/>
      <ownedElement xmi:id="ce931ca0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ce931e30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_892836_71476"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="ce9aba90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ce9abc00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_892836_71476"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625036250676_962793_72043" xmi:uuid="ce9c7140-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="c2d9c0d0-6c44-013d-d60e-0800270c66d6" xmi:uuid="c2d9c170-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="563" y="576" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="545" y="585" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="581" width="154" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035694076_2240_71543" xmi:uuid="b7c2d380-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682470_322247_71475"/>
      <ownedElement xmi:id="ced5fe30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ced5ffd0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682470_322247_71475"/>
        <text>lang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="cedda4a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cedda620-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682470_322247_71475"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625036206122_433180_72014" xmi:uuid="cedf5210-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="c4e2e3d0-6c44-013d-d60e-0800270c66d6" xmi:uuid="c4e2e480-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="430" y="626" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="412" y="635" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="273" y="630" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036311897_158223_72110" xmi:uuid="cfb43d20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036314012_260557_72111"/>
      <source xmi:idref="_18_4_1_8be0287_1625033900190_28471_75411"/>
      <target xmi:idref="_18_4_1_8be0287_1625036291641_227301_72055"/>
      <waypoint x="956" y="546"/>
      <waypoint x="956" y="662"/>
      <waypoint x="798" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035694076_274473_71574" xmi:uuid="b7ef2de0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_546244_71477"/>
      <ownedElement xmi:id="cf1c8690-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cf1c8800-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_546244_71477"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cf243970-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cf243ad0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_546244_71477"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c5d68720-6c44-013d-d60e-0800270c66d6" xmi:uuid="c5d687d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c5d7c840-6c44-013d-d60e-0800270c66d6" xmi:uuid="c5d7c8d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625036291641_227301_72055" xmi:uuid="cfb30f20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="cf7fce50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cf7fcf50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="cfb20db0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cfb20ee0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="623" y="651" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="539" y="623" width="292" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036402608_255588_72257" xmi:uuid="d2630bd0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036404387_435044_72258"/>
      <source xmi:idref="_18_4_1_8be0287_1625033900190_28471_75411"/>
      <target xmi:idref="_18_4_1_8be0287_1625036346680_86387_72151"/>
      <waypoint x="956" y="546"/>
      <waypoint x="956" y="809"/>
      <waypoint x="788" y="809"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035694076_709470_71605" xmi:uuid="b84ebf40-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_860081_71479"/>
      <ownedElement xmi:id="cfe241e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cfe24510-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_860081_71479"/>
        <text>nameLang:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="cfe78640-339c-013a-17e4-45cc4a55db9f" xmi:uuid="cfe787d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_860081_71479"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="c8a09b20-6c44-013d-d60e-0800270c66d6" xmi:uuid="c8a09bc0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c8afcf70-6c44-013d-d60e-0800270c66d6" xmi:uuid="c8afd040-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625036346664_366915_72120" xmi:uuid="d0932ae0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="d03982d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d0398410-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="d0918620-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d09187d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="560" y="763" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625036346680_86387_72151" xmi:uuid="d1473120-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="d1165b90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d1165cf0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="d145eea0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d145f000-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="560" y="798" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625036346695_845493_72182" xmi:uuid="d2610610-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="d1b9c810-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d1b9c9b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="d25ef700-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d25ef8d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="560" y="728" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="539" y="700" width="294" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035694092_335084_71636" xmi:uuid="b851a0b0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_656205_71480"/>
      <ownedElement xmi:id="d27ae490-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d27ae650-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_656205_71480"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="d2873d90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d2873fa0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_656205_71480"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="301" y="763" width="207" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035694107_765404_71667" xmi:uuid="b85e6c70-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682470_774784_71474"/>
      <ownedElement xmi:id="d2cb5430-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d2cb5630-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682470_774784_71474"/>
        <text>nameSelect:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625035948702_361465_71868" xmi:uuid="d2d253f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="ced64890-6c44-013d-d60e-0800270c66d6" xmi:uuid="ced64920-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="219" y="507" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="273" y="516" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625035948718_738633_71878" xmi:uuid="d2d36e70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="cf8c7b90-6c44-013d-d60e-0800270c66d6" xmi:uuid="cf8c7c40-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="488" y="510" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="470" y="519" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625035948718_125609_71888" xmi:uuid="d2d4d180-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="d03b85d0-6c44-013d-d60e-0800270c66d6" xmi:uuid="d03b8680-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="423" y="556" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="413" y="538" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625035948733_973665_71898" xmi:uuid="d2d63360-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="d0dd4a10-6c44-013d-d60e-0800270c66d6" xmi:uuid="d0dd4ab0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="324" y="556" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="314" y="538" width="15" height="15"/>
      </ownedElement>
      <bounds x="273" y="504" width="212" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035694107_178217_71687" xmi:uuid="b86ac7d0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_622838_71478"/>
      <ownedElement xmi:id="d32babb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d32bada0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035682485_622838_71478"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625035988686_627232_71933" xmi:uuid="d33198b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="d2200bd0-6c44-013d-d60e-0800270c66d6" xmi:uuid="d2200c70-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="511" y="531" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="567" y="518" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625035988701_68866_71943" xmi:uuid="d332d090-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="d2e52da0-6c44-013d-d60e-0800270c66d6" xmi:uuid="d2e52e60-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="762" y="508" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="744" y="517" width="15" height="15"/>
      </ownedElement>
      <bounds x="567" y="504" width="192" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035919204_282889_71837" xmi:uuid="b876e150-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035828054_203883_71820"/>
      <ownedElement xmi:id="d360b480-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d360b610-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035828054_203883_71820"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d3666560-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d36666a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035828054_203883_71820"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="511" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625035972539_896933_71923" xmi:uuid="b876ed70-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625035973849_842189_71924"/>
      <source xmi:idref="_18_4_1_8be0287_1625035948702_361465_71868"/>
      <target xmi:idref="_18_4_1_8be0287_1625035919204_282889_71837"/>
      <waypoint x="273" y="522"/>
      <waypoint x="209" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036149842_439184_71964" xmi:uuid="b876f600-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036151028_118812_71965"/>
      <source xmi:idref="_18_4_1_8be0287_1625035988686_627232_71933"/>
      <target xmi:idref="_18_4_1_8be0287_1625035948718_738633_71878"/>
      <waypoint x="567" y="525"/>
      <waypoint x="485" y="525"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036157128_705816_71984" xmi:uuid="b8770240-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036158376_555543_71985"/>
      <source xmi:idref="_18_4_1_8be0287_1625034433359_714068_69893"/>
      <target xmi:idref="_18_4_1_8be0287_1625035988701_68866_71943"/>
      <waypoint x="826" y="525"/>
      <waypoint x="759" y="525"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036174280_851504_72004" xmi:uuid="b8770990-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036175309_566877_72005"/>
      <source xmi:idref="_18_4_1_8be0287_1625035694076_2240_71543"/>
      <target xmi:idref="_18_4_1_8be0287_1625035948733_973665_71898"/>
      <waypoint x="322" y="630"/>
      <waypoint x="322" y="553"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036221207_741908_72033" xmi:uuid="b87714e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036222767_723366_72034"/>
      <source xmi:idref="_18_4_1_8be0287_1625035694060_473181_71512"/>
      <target xmi:idref="_18_4_1_8be0287_1625035948718_125609_71888"/>
      <waypoint x="420" y="581"/>
      <waypoint x="420" y="553"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036305245_526411_72093" xmi:uuid="b8771d50-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036307246_216102_72094"/>
      <source xmi:idref="_18_4_1_8be0287_1625035694076_274473_71574"/>
      <target xmi:idref="_18_4_1_8be0287_1625036250676_962793_72043"/>
      <waypoint x="686" y="623"/>
      <waypoint x="686" y="592"/>
      <waypoint x="560" y="592"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036389988_897491_72220" xmi:uuid="b8772680-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036391501_827949_72221"/>
      <source xmi:idref="_18_4_1_8be0287_1625036346664_366915_72120"/>
      <target xmi:idref="_18_4_1_8be0287_1625035694092_335084_71636"/>
      <waypoint x="560" y="774"/>
      <waypoint x="508" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036395354_552252_72237" xmi:uuid="b8772f60-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036396961_744223_72238"/>
      <source xmi:idref="_18_4_1_8be0287_1625036346695_845493_72182"/>
      <target xmi:idref="_18_4_1_8be0287_1625036206122_433180_72014"/>
      <waypoint x="560" y="739"/>
      <waypoint x="494" y="739"/>
      <waypoint x="494" y="644"/>
      <waypoint x="427" y="644"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625036694338_311277_72394" xmi:uuid="b8773b40-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625036696007_164199_72395"/>
      <source xmi:idref="_18_4_1_8be0287_1625051832757_403728_70835"/>
      <target xmi:idref="_18_4_1_8be0287_1625036593512_845596_72327"/>
      <waypoint x="385" y="1036"/>
      <waypoint x="311" y="1036"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625051767879_32146_70737" xmi:uuid="b8ae0420-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625051767788_23566_70736"/>
      <ownedElement xmi:id="d39f1450-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d39f1610-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625051767788_23566_70736"/>
        <text>simpleType:Class</text>
      </ownedElement>
      <ownedElement xmi:id="d3b96ff0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d3b971b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625051767788_23566_70736"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d4b5e290-6c44-013d-d60e-0800270c66d6" xmi:uuid="d4b5e340-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d4c56f60-6c44-013d-d60e-0800270c66d6" xmi:uuid="d4c57030-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625051832741_853943_70804" xmi:uuid="d449f1e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="d3faa870-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d3faaa10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="d4481e60-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d4482020-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="385" y="1071" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625051832757_403728_70835" xmi:uuid="d4d5a420-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="d48f2bc0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d48f2d90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="d4d42db0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d4d42fa0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="385" y="1022" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="364" y="994" width="142" height="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625052278673_89862_76185" xmi:uuid="b8baafb0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625052261857_397121_76183"/>
      <ownedElement xmi:id="d5203500-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d5203680-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625052261857_397121_76183"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625052288365_430762_76205" xmi:uuid="d5280f30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="d85ff660-6c44-013d-d60e-0800270c66d6" xmi:uuid="d85ff710-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="464" y="290" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="518" y="299" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625052288385_163488_76215" xmi:uuid="d5298090-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="d8f9dd20-6c44-013d-d60e-0800270c66d6" xmi:uuid="d8f9ddc0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="692" y="292" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="674" y="301" width="15" height="15"/>
      </ownedElement>
      <bounds x="518" y="287" width="171" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625052350391_602465_76236" xmi:uuid="b8babcb0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625052351678_588760_76237"/>
      <source xmi:idref="_18_4_1_8be0287_1625034433359_166136_69862"/>
      <target xmi:idref="_18_4_1_8be0287_1625052288385_163488_76215"/>
      <waypoint x="833" y="308"/>
      <waypoint x="689" y="308"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625052857881_70213_78701" xmi:uuid="d6b89040-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625052860992_869213_78702"/>
      <source xmi:idref="_18_4_1_8be0287_1625033900190_28471_75411"/>
      <target xmi:idref="_18_4_1_8be0287_1625052658399_295193_78613"/>
      <waypoint x="956" y="546"/>
      <waypoint x="956" y="1075"/>
      <waypoint x="744" y="1075"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625052611714_342978_78546" xmi:uuid="b904e7b0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625052611695_790682_78545"/>
      <ownedElement xmi:id="d5644e40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d5644fe0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625052611695_790682_78545"/>
        <text>simpleTypeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d56b6a30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d56b6be0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625052611695_790682_78545"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d9f3cc40-6c44-013d-d60e-0800270c66d6" xmi:uuid="d9f3ccf0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d9fe7610-6c44-013d-d60e-0800270c66d6" xmi:uuid="d9fe7780-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625052658379_208593_78582" xmi:uuid="d60ec800-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="d5d38e20-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d5d39240-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="d60d5220-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d60d5390-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="560" y="1029" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625052658399_295193_78613" xmi:uuid="d6b723b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="d67c3920-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d67c3aa0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d6b5a610-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d6b5a780-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="560" y="1064" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="539" y="1001" width="294" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625052682584_808046_78682" xmi:uuid="b904f130-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625052684077_20473_78683"/>
      <source xmi:idref="_18_4_1_8be0287_1625052658379_208593_78582"/>
      <target xmi:idref="_18_4_1_8be0287_1625051767879_32146_70737"/>
      <waypoint x="560" y="1040"/>
      <waypoint x="506" y="1040"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625053033764_252144_78716" xmi:uuid="b907d550-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625053026086_418300_78711"/>
      <ownedElement xmi:id="d6c0a060-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d6c0a220-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625053026086_418300_78711"/>
        <text>ignore:String</text>
      </ownedElement>
      <ownedElement xmi:id="d6c88f30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d6c89090-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625053026086_418300_78711"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="112" y="1071" width="201" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625053133344_455649_78754" xmi:uuid="b907e1d0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625053134554_222986_78755"/>
      <source xmi:idref="_18_4_1_8be0287_1625051832741_853943_70804"/>
      <target xmi:idref="_18_4_1_8be0287_1625053033764_252144_78716"/>
      <waypoint x="385" y="1082"/>
      <waypoint x="313" y="1082"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_9dd021a_1637077100800_278820_65437" xmi:uuid="b90c1af0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535962294_864637_73849"/>
      <ownedElement xmi:id="d6d62be0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d6d62d50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535962294_864637_73849"/>
        <text>Design:SlotDesign</text>
      </ownedElement>
      <ownedElement xmi:id="d6ddb1b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d6ddb330-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535962294_864637_73849"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637077276054_813735_65474" xmi:uuid="d6df67f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973497803_843232_74356"/>
        <ownedElement xmi:id="de62e9e0-6c44-013d-d60e-0800270c66d6" xmi:uuid="de62ea90-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1624973497803_843232_74356"/>
          <bounds x="195" y="410" width="158" height="13"/>
          <text>slot : Attachment_slot_design [1]</text>
        </ownedElement>
        <bounds x="177" y="419" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="413" width="143" height="29"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_9dd021a_1637077376425_359263_65486" xmi:uuid="b9102ea0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535981151_929673_73881"/>
      <ownedElement xmi:id="d6ed0930-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d6ed0ae0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535981151_929673_73881"/>
        <text>Planned:SlotAsPlanned</text>
      </ownedElement>
      <ownedElement xmi:id="d6f523b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d6f52500-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535981151_929673_73881"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_9dd021a_1637077405814_250404_65517" xmi:uuid="d6f6b690-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031077917_475237_74196"/>
        <ownedElement xmi:id="def80750-6c44-013d-d60e-0800270c66d6" xmi:uuid="def80800-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031077917_475237_74196"/>
          <bounds x="222" y="459" width="182" height="13"/>
          <text>slot : Attachment_slot_as_planned [1]</text>
        </ownedElement>
        <bounds x="204" y="468" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="462" width="170" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031931046_660532_75337" xmi:uuid="c25d0d10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031931015_784499_75333"/>
      <bounds x="1188" y="170" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1191" height="1121"/>
    <name>SlotDesignToPlanned</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_8be0287_1625031791611_384005_74923" xmi:uuid="d6f8b120-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535892317_254657_73801"/>
    <ownedElement xmi:id="_18_4_1_8be0287_1625040089877_582557_74630" xmi:uuid="d8732d40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625040092701_950817_74631"/>
      <source xmi:idref="_18_4_1_8be0287_1625034007732_213565_75483"/>
      <target xmi:idref="_18_4_1_8be0287_1625040077519_969814_74592"/>
      <waypoint x="949" y="567"/>
      <waypoint x="949" y="886"/>
      <waypoint x="835" y="886"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031845182_214456_74955" xmi:uuid="b94fefd0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="d7801bb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d7801da0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d7c56de0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d7c570c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e3415b10-6c44-013d-d60e-0800270c66d6" xmi:uuid="e3415bb0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e35f4e30-6c44-013d-d60e-0800270c66d6" xmi:uuid="e35f4ef0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625040077519_969814_74592" xmi:uuid="d87125c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="d8428940-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d8428a80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d86f5d40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d86f5e90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="651" y="875" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="553" y="847" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039579150_869064_74234" xmi:uuid="da05f3a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039580788_791349_74235"/>
      <source xmi:idref="_18_4_1_8be0287_1625034007732_213565_75483"/>
      <target xmi:idref="_18_4_1_8be0287_1625039568789_585251_74196"/>
      <waypoint x="914" y="203"/>
      <waypoint x="914" y="109"/>
      <waypoint x="714" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031845197_341933_74986" xmi:uuid="b98c4330-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="d8ce2c90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d8ce2de0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d9188f70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d9189180-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e67f92c0-6c44-013d-d60e-0800270c66d6" xmi:uuid="e67f9360-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e68b9b80-6c44-013d-d60e-0800270c66d6" xmi:uuid="e68b9c50-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625039568789_585251_74196" xmi:uuid="da0498f0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="d9cec0c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="d9cec260-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="da0344b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="da034640-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="539" y="98" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="420" y="70" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039874410_132213_74394" xmi:uuid="db84cff0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039875925_611946_74395"/>
      <source xmi:idref="_18_4_1_8be0287_1625034007732_213565_75483"/>
      <target xmi:idref="_18_4_1_8be0287_1625039863771_654598_74356"/>
      <waypoint x="833" y="375"/>
      <waypoint x="645" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031845197_865820_75017" xmi:uuid="b9c8c560-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="da5e9730-339c-013a-17e4-45cc4a55db9f" xmi:uuid="da5e98e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="da894f70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="da895330-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e9a44030-6c44-013d-d60e-0800270c66d6" xmi:uuid="e9a44150-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e9b220f0-6c44-013d-d60e-0800270c66d6" xmi:uuid="e9b221d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625039863771_654598_74356" xmi:uuid="db83cd20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="db436150-339c-013a-17e4-45cc4a55db9f" xmi:uuid="db436330-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="db824bf0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="db824dc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="462" y="364" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="427" y="336" width="307" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039793146_258011_74282" xmi:uuid="dd6ee100-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039794894_150088_74283"/>
      <source xmi:idref="_18_4_1_8be0287_1625034007732_213565_75483"/>
      <target xmi:idref="_18_4_1_8be0287_1625039591583_381004_74244"/>
      <waypoint x="914" y="203"/>
      <waypoint x="914" y="186"/>
      <waypoint x="676" y="186"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031845213_280210_75048" xmi:uuid="ba042700-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="dbfc7ff0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="dbfc8130-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="dc5f1730-339c-013a-17e4-45cc4a55db9f" xmi:uuid="dc5f19b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ed0e69f0-6c44-013d-d60e-0800270c66d6" xmi:uuid="ed0e6a90-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ed0fb750-6c44-013d-d60e-0800270c66d6" xmi:uuid="ed0fb830-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625039591583_381004_74244" xmi:uuid="dd6d5d80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="dd22e220-339c-013a-17e4-45cc4a55db9f" xmi:uuid="dd22e3c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="dd6bbac0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="dd6bbc60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="448" y="175" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="420" y="147" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031845228_343073_75079" xmi:uuid="ba2041b0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="ddf6ace0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ddf6ae80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625039809606_886225_74292" xmi:uuid="de2a7f00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="f0e13430-6c44-013d-d60e-0800270c66d6" xmi:uuid="f0e134d0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="735" y="233" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="717" y="242" width="15" height="15"/>
      </ownedElement>
      <bounds x="483" y="231" width="249" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031845244_445789_75099" xmi:uuid="ba3c9020-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="de97e220-339c-013a-17e4-45cc4a55db9f" xmi:uuid="de97e3b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625039835487_923466_74324" xmi:uuid="decf7f40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="f3213870-6c44-013d-d60e-0800270c66d6" xmi:uuid="f3213910-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="433" y="282" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="415" y="291" width="15" height="15"/>
      </ownedElement>
      <bounds x="266" y="280" width="164" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625040062619_447742_74582" xmi:uuid="e01e16e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625040064850_786203_74583"/>
      <source xmi:idref="_18_4_1_8be0287_1625034007732_213565_75483"/>
      <target xmi:idref="_18_4_1_8be0287_1625040047268_797983_74544"/>
      <waypoint x="949" y="567"/>
      <waypoint x="949" y="963"/>
      <waypoint x="793" y="963"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031845260_268369_75119" xmi:uuid="ba7899b0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="df3a07f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="df3a0a00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="df711ea0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="df712000-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f46d64f0-6c44-013d-d60e-0800270c66d6" xmi:uuid="f46d65a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f4a70b50-6c44-013d-d60e-0800270c66d6" xmi:uuid="f4a70c10-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625040047268_797983_74544" xmi:uuid="e01ca470-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="dfe1b120-339c-013a-17e4-45cc4a55db9f" xmi:uuid="dfe1b290-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e01b0210-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e01b03d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="609" y="952" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="553" y="924" width="301" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031845275_48286_75150" xmi:uuid="ba94b1a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="e08fcd10-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e08fceb0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625063953942_704230_73325" xmi:uuid="e0c94cf0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="f86178e0-6c44-013d-d60e-0800270c66d6" xmi:uuid="f8617980-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="300" y="1021" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <bounds x="282" y="1030" width="15" height="15"/>
      </ownedElement>
      <bounds x="112" y="1015" width="185" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625031886006_838089_75314" xmi:uuid="ba94b7c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="315" y="21" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625034007732_213565_75483" xmi:uuid="bb1ef550-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034007716_900214_75482"/>
      <ownedElement xmi:id="e107e5e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e107e770-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034007716_900214_75482"/>
        <text>slotPlannedToRealized:Attachment_slot_planned_to_realized</text>
      </ownedElement>
      <ownedElement xmi:id="e10fa810-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e10fa970-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034007716_900214_75482"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="f9372cd0-6c44-013d-d60e-0800270c66d6" xmi:uuid="f9372d70-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f9462100-6c44-013d-d60e-0800270c66d6" xmi:uuid="f9462190-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034557216_648269_70488" xmi:uuid="e180ff20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-description"/>
          <ownedElement xmi:id="e15025d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e1502770-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="e17fb940-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e17fba70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="854" y="238" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034557231_197063_70519" xmi:uuid="e1e25110-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-id"/>
          <ownedElement xmi:id="e1b273f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e1b275a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="e1e11cf0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e1e11fd0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="854" y="287" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034557231_455265_70550" xmi:uuid="e2457a90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-name"/>
          <ownedElement xmi:id="e216c810-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e216c9b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="e2442960-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e2442a70-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="854" y="518" width="103" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034557247_208771_70581" xmi:uuid="e3468b20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-planned"/>
          <ownedElement xmi:id="e302b900-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e302bb20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-planned"/>
            <text>planned:Attachment_slot_as_planned</text>
          </ownedElement>
          <ownedElement xmi:id="e3450880-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e3450a30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-planned"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="854" y="413" width="243" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625034557262_292997_70612" xmi:uuid="e45c1390-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-realized"/>
          <ownedElement xmi:id="e41b30d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e41b32b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-realized"/>
            <text>realized:Attachment_slot_as_realized</text>
          </ownedElement>
          <ownedElement xmi:id="e45ae4a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e45ae690-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Attachment_slot_planned_to_realized-realized"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="854" y="455" width="243" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="833" y="203" width="392" height="364"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625034563549_710226_70650" xmi:uuid="bb1f0500-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625034565343_924463_70651"/>
      <source xmi:idref="_18_4_1_8be0287_1625032162535_679159_75391"/>
      <target xmi:idref="_18_4_1_8be0287_1625034007732_213565_75483"/>
      <waypoint x="1277" y="151"/>
      <waypoint x="1092" y="151"/>
      <waypoint x="1092" y="203"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039818342_638776_74311" xmi:uuid="bb1f0de0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039820090_720989_74312"/>
      <source xmi:idref="_18_4_1_8be0287_1625034557216_648269_70488"/>
      <target xmi:idref="_18_4_1_8be0287_1625039809606_886225_74292"/>
      <waypoint x="854" y="249"/>
      <waypoint x="732" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039846594_466981_74343" xmi:uuid="bb1f15e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039848092_699823_74344"/>
      <source xmi:idref="_18_4_1_8be0287_1632388490074_117601_76742"/>
      <target xmi:idref="_18_4_1_8be0287_1625039835487_923466_74324"/>
      <waypoint x="553" y="298"/>
      <waypoint x="430" y="298"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625039961983_448794_74461" xmi:uuid="bb1f1f00-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625039963964_269759_74462"/>
      <source xmi:idref="_18_4_1_8be0287_1625034557247_208771_70581"/>
      <target xmi:idref="_18_4_1_271a0567_1640167391793_606210_95516"/>
      <waypoint x="854" y="424"/>
      <waypoint x="231" y="424"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625040022880_625113_74531" xmi:uuid="bb1f2d20-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625040024721_746178_74532"/>
      <source xmi:idref="_18_4_1_8be0287_1625034557262_292997_70612"/>
      <target xmi:idref="_18_4_1_271a0567_1640167411975_754088_95532"/>
      <waypoint x="854" y="469"/>
      <waypoint x="231" y="469"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055684021_109148_80009" xmi:uuid="bb2b77f0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625336_413972_79376"/>
      <ownedElement xmi:id="e4b94eb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e4b95000-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625336_413972_79376"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625063463483_978551_72674" xmi:uuid="e4bf9440-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="00922020-6c45-013d-d60e-0800270c66d6" xmi:uuid="009220d0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="539" y="531" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="595" y="523" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625063463495_251415_72684" xmi:uuid="e4c0e760-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="011ebd00-6c45-013d-d60e-0800270c66d6" xmi:uuid="011ebda0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="790" y="514" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="772" y="523" width="15" height="15"/>
      </ownedElement>
      <bounds x="595" y="511" width="192" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055684025_175963_80029" xmi:uuid="bb37a390-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625337_81445_79378"/>
      <ownedElement xmi:id="e4ee4b60-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e4ee4d10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625337_81445_79378"/>
        <text>lang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="e4f4d220-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e4f4d3a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625337_81445_79378"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625063727795_542201_72976" xmi:uuid="e4f63120-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="02bac360-6c45-013d-d60e-0800270c66d6" xmi:uuid="02bac630-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="423" y="689" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="405" y="698" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="266" y="693" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055684041_146753_80060" xmi:uuid="bb4451a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625335_577986_79375"/>
      <ownedElement xmi:id="e567be90-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e567c040-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625335_577986_79375"/>
        <text>nameSelect:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625063418065_612114_72609" xmi:uuid="e57a51d0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="03d91190-6c45-013d-d60e-0800270c66d6" xmi:uuid="03d91200-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="240" y="507" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="294" y="516" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625063418081_485453_72619" xmi:uuid="e5807ad0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="04634db0-6c45-013d-d60e-0800270c66d6" xmi:uuid="04634e70-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="509" y="514" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="491" y="523" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625063418091_710212_72629" xmi:uuid="e5830210-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="04ed6c10-6c45-013d-d60e-0800270c66d6" xmi:uuid="04ed6d50-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="430" y="556" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="420" y="538" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625063418130_258860_72639" xmi:uuid="e5871b90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="0553f1e0-6c45-013d-d60e-0800270c66d6" xmi:uuid="0553f2b0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="336" y="556" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="326" y="538" width="15" height="15"/>
      </ownedElement>
      <bounds x="294" y="504" width="212" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063594412_820362_72824" xmi:uuid="e6e2cac0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063600725_556398_72825"/>
      <source xmi:idref="_18_4_1_8be0287_1625034007732_213565_75483"/>
      <target xmi:idref="_18_4_1_8be0287_1625063579001_576195_72772"/>
      <waypoint x="949" y="567"/>
      <waypoint x="949" y="662"/>
      <waypoint x="805" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055684047_225325_80080" xmi:uuid="bb70e230-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625338_881608_79379"/>
      <ownedElement xmi:id="e5f37c50-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e5f37dc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625338_881608_79379"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e6021040-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e6021260-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625338_881608_79379"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="06517680-6c45-013d-d60e-0800270c66d6" xmi:uuid="06517730-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0652bba0-6c45-013d-d60e-0800270c66d6" xmi:uuid="0652bc70-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063579001_576195_72772" xmi:uuid="e6de9c30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="e695c3d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e695c560-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="e6dd23a0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e6dd2550-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="630" y="651" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="553" y="623" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055684054_471683_80111" xmi:uuid="bb73a8e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625339_58338_79381"/>
      <ownedElement xmi:id="e6eb73d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e6eb7580-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625339_58338_79381"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="e6f50c40-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e6f50e40-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625339_58338_79381"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="259" y="763" width="207" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063711330_21216_72966" xmi:uuid="e92a86c0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063713188_429628_72967"/>
      <source xmi:idref="_18_4_1_8be0287_1625034007732_213565_75483"/>
      <target xmi:idref="_18_4_1_8be0287_1625063672674_454472_72880"/>
      <waypoint x="949" y="567"/>
      <waypoint x="949" y="809"/>
      <waypoint x="802" y="809"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055684061_459687_80142" xmi:uuid="bbd2f6e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625339_185711_79380"/>
      <ownedElement xmi:id="e743bc70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e743be50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625339_185711_79380"/>
        <text>nameLang:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="e74ca1c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e74ca3b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625339_185711_79380"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="08d0a2a0-6c45-013d-d60e-0800270c66d6" xmi:uuid="08d0a510-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="08d1f390-6c45-013d-d60e-0800270c66d6" xmi:uuid="08d1f450-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063672658_426119_72849" xmi:uuid="e7cd17a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="e7908f80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e7909100-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="e7cb8b70-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e7cb8cd0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="574" y="763" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063672674_454472_72880" xmi:uuid="e8769010-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="e83af640-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e83afd00-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="e87514c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e8751640-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="574" y="798" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063672690_297570_72911" xmi:uuid="e9290a90-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="e8e669b0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e8e66b50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="e92775e0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e9277770-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="574" y="728" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="553" y="700" width="294" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625055684066_804999_80173" xmi:uuid="bbdeb330-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625337_39617_79377"/>
      <ownedElement xmi:id="e9728fb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e9729130-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625337_39617_79377"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="e97b5bb0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e97b5db0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055625337_39617_79377"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1625063615373_790072_72834" xmi:uuid="e97d7300-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="0dfaa7f0-6c45-013d-d60e-0800270c66d6" xmi:uuid="0dfaa8b0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="591" y="575" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="573" y="584" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="420" y="581" width="161" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063398524_998764_72578" xmi:uuid="bbea9510-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055771214_408819_80209"/>
      <ownedElement xmi:id="e9ba2500-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e9ba2630-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055771214_408819_80209"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e9c019d0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e9c01bc0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625055771214_408819_80209"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="49" y="511" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063448473_979502_72664" xmi:uuid="bbea9e00-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063452672_640444_72665"/>
      <source xmi:idref="_18_4_1_8be0287_1625063418065_612114_72609"/>
      <target xmi:idref="_18_4_1_8be0287_1625063398524_998764_72578"/>
      <waypoint x="294" y="522"/>
      <waypoint x="223" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063483594_352285_72705" xmi:uuid="bbeaa6d0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063484748_545953_72706"/>
      <source xmi:idref="_18_4_1_8be0287_1625034557231_455265_70550"/>
      <target xmi:idref="_18_4_1_8be0287_1625063463495_251415_72684"/>
      <waypoint x="854" y="529"/>
      <waypoint x="787" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063490505_97796_72725" xmi:uuid="bbeab320-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063492626_150160_72726"/>
      <source xmi:idref="_18_4_1_8be0287_1625063463483_978551_72674"/>
      <target xmi:idref="_18_4_1_8be0287_1625063418081_485453_72619"/>
      <waypoint x="595" y="529"/>
      <waypoint x="506" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063535095_117427_72745" xmi:uuid="bbeabdf0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063536194_575845_72746"/>
      <source xmi:idref="_18_4_1_8be0287_1625055684025_175963_80029"/>
      <target xmi:idref="_18_4_1_8be0287_1625063418130_258860_72639"/>
      <waypoint x="333" y="693"/>
      <waypoint x="333" y="553"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063558270_30933_72762" xmi:uuid="bbeac6c0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063559456_294879_72763"/>
      <source xmi:idref="_18_4_1_8be0287_1625055684066_804999_80173"/>
      <target xmi:idref="_18_4_1_8be0287_1625063418091_710212_72629"/>
      <waypoint x="427" y="581"/>
      <waypoint x="427" y="553"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063589247_220994_72810" xmi:uuid="bbeacfd0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063591576_375893_72811"/>
      <source xmi:idref="_18_4_1_8be0287_1625055684047_225325_80080"/>
      <target xmi:idref="_18_4_1_8be0287_1625063615373_790072_72834"/>
      <waypoint x="714" y="623"/>
      <waypoint x="714" y="592"/>
      <waypoint x="588" y="592"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063706685_286011_72949" xmi:uuid="bbeadb60-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063708131_843273_72950"/>
      <source xmi:idref="_18_4_1_8be0287_1625063672658_426119_72849"/>
      <target xmi:idref="_18_4_1_8be0287_1625055684054_471683_80111"/>
      <waypoint x="574" y="774"/>
      <waypoint x="466" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063774846_253507_72995" xmi:uuid="bbeae630-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063777374_308424_72996"/>
      <source xmi:idref="_18_4_1_8be0287_1625063672690_297570_72911"/>
      <target xmi:idref="_18_4_1_8be0287_1625063727795_542201_72976"/>
      <waypoint x="574" y="739"/>
      <waypoint x="462" y="739"/>
      <waypoint x="462" y="707"/>
      <waypoint x="420" y="707"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063833643_19780_73029" xmi:uuid="bc2220a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063827539_987161_73008"/>
      <ownedElement xmi:id="e9efe9f0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e9efeb80-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063827539_987161_73008"/>
        <text>simpleType:Class</text>
      </ownedElement>
      <ownedElement xmi:id="e9f6a780-339c-013a-17e4-45cc4a55db9f" xmi:uuid="e9f6a8e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063827539_987161_73008"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="0fd4c6a0-6c45-013d-d60e-0800270c66d6" xmi:uuid="0fd4c790-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0fe73c10-6c45-013d-d60e-0800270c66d6" xmi:uuid="0fe73d10-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063901468_257747_73263" xmi:uuid="ea559a50-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="ea263800-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ea2639b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="ea546e00-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ea546f60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="378" y="1064" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063901479_10627_73294" xmi:uuid="eaf27e20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="ea880610-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ea880cb0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="eaecd210-339c-013a-17e4-45cc4a55db9f" xmi:uuid="eaecd3e0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="378" y="1029" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="357" y="1001" width="147" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063888191_721564_73222" xmi:uuid="ecdc72b0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063891776_97869_73223"/>
      <source xmi:idref="_18_4_1_8be0287_1625034007732_213565_75483"/>
      <target xmi:idref="_18_4_1_8be0287_1625063861921_618923_73153"/>
      <waypoint x="949" y="567"/>
      <waypoint x="949" y="1075"/>
      <waypoint x="751" y="1075"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063835985_86596_73060" xmi:uuid="bc6d7f10-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063827540_737659_73009"/>
      <ownedElement xmi:id="eb7119c0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="eb711b30-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063827540_737659_73009"/>
        <text>simpleTypeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="eb792330-339c-013a-17e4-45cc4a55db9f" xmi:uuid="eb792500-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063827540_737659_73009"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="13e01070-6c45-013d-d60e-0800270c66d6" xmi:uuid="13e01120-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="13f43ec0-6c45-013d-d60e-0800270c66d6" xmi:uuid="13f43fe0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063861900_531820_73122" xmi:uuid="ec132810-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="ebdefa80-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ebdefcb0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="ec11ab30-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ec11ad20-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="567" y="1029" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_8be0287_1625063861921_618923_73153" xmi:uuid="ecdad430-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="ec8ffef0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ec9000a0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ecd73f00-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ecd74110-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="567" y="1064" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="553" y="1001" width="301" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063838539_844949_73091" xmi:uuid="bc7036e0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063827541_465493_73010"/>
      <ownedElement xmi:id="ece79bc0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ece79d60-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063827541_465493_73010"/>
        <text>ignore:String</text>
      </ownedElement>
      <ownedElement xmi:id="ecf07bf0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ecf07db0-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063827541_465493_73010"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="133" y="1064" width="165" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063967576_192057_73344" xmi:uuid="bc704290-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063969104_813423_73345"/>
      <source xmi:idref="_18_4_1_8be0287_1625063901479_10627_73294"/>
      <target xmi:idref="_18_4_1_8be0287_1625063953942_704230_73325"/>
      <waypoint x="378" y="1036"/>
      <waypoint x="297" y="1036"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625063974047_321529_73364" xmi:uuid="bc704aa0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625063975150_85611_73365"/>
      <source xmi:idref="_18_4_1_8be0287_1625063901468_257747_73263"/>
      <target xmi:idref="_18_4_1_8be0287_1625063838539_844949_73091"/>
      <waypoint x="378" y="1075"/>
      <waypoint x="298" y="1075"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1632388476345_881421_76722" xmi:uuid="bc7c7580-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388460828_195141_76720"/>
      <ownedElement xmi:id="ed1ecbf0-339c-013a-17e4-45cc4a55db9f" xmi:uuid="ed1ecd10-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388460828_195141_76720"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1632388490074_117601_76742" xmi:uuid="ed245570-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="19da2d10-6c45-013d-d60e-0800270c66d6" xmi:uuid="19da2dc0-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="497" y="300" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="553" y="292" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_8be0287_1632388490102_612109_76752" xmi:uuid="ed256360-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="1a814870-6c45-013d-d60e-0800270c66d6" xmi:uuid="1a814930-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="734" y="284" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="716" y="293" width="15" height="15"/>
      </ownedElement>
      <bounds x="553" y="280" width="178" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1632388520591_538999_76773" xmi:uuid="bc7c7f00-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388522358_224003_76774"/>
      <source xmi:idref="_18_4_1_8be0287_1625034557231_197063_70519"/>
      <target xmi:idref="_18_4_1_8be0287_1632388490102_612109_76752"/>
      <waypoint x="854" y="301"/>
      <waypoint x="731" y="301"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1632388598753_747432_76793" xmi:uuid="bc7c87a0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1632388602553_850756_76794"/>
      <source xmi:idref="_18_4_1_8be0287_1625063861900_531820_73122"/>
      <target xmi:idref="_18_4_1_8be0287_1625063833643_19780_73029"/>
      <waypoint x="567" y="1040"/>
      <waypoint x="504" y="1040"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_8be0287_1625032162535_679159_75391" xmi:uuid="d700b340-339c-013a-17e4-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625032162504_773127_75387"/>
      <bounds x="1277" y="142" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1640167375389_601657_95452" xmi:uuid="bc80e9d0-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622536017869_250974_73945"/>
      <ownedElement xmi:id="e21a0f50-458b-013a-17ff-45cc4a55db9f" xmi:uuid="e21a1020-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622536017869_250974_73945"/>
        <text>Realized:SlotAsRealized</text>
      </ownedElement>
      <ownedElement xmi:id="e21fada0-458b-013a-17ff-45cc4a55db9f" xmi:uuid="e21fae80-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622536017869_250974_73945"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1640167411975_754088_95532" xmi:uuid="e22178d0-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031345304_678040_74395"/>
        <ownedElement xmi:id="1b666150-6c45-013d-d60e-0800270c66d6" xmi:uuid="1b666200-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031345304_678040_74395"/>
          <bounds x="234" y="452" width="182" height="13"/>
          <text>slot : Attachment_slot_as_realized [1]</text>
        </ownedElement>
        <bounds x="216" y="461" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="49" y="455" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1640167375404_62561_95483" xmi:uuid="bc84dd70-76cc-013a-5c0a-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535995861_391383_73913"/>
      <ownedElement xmi:id="e22ae620-458b-013a-17ff-45cc4a55db9f" xmi:uuid="e22ae700-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535995861_391383_73913"/>
        <text>Planned:SlotAsPlanned</text>
      </ownedElement>
      <ownedElement xmi:id="e2312b80-458b-013a-17ff-45cc4a55db9f" xmi:uuid="e2312cd0-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535995861_391383_73913"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1640167391793_606210_95516" xmi:uuid="e235dee0-458b-013a-17ff-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031077917_475237_74196"/>
        <ownedElement xmi:id="1c079ff0-6c45-013d-d60e-0800270c66d6" xmi:uuid="1c07a090-6c45-013d-d60e-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Slot.xmi#_18_4_1_8be0287_1625031077917_475237_74196"/>
          <bounds x="234" y="409" width="182" height="13"/>
          <text>slot : Attachment_slot_as_planned [1]</text>
        </ownedElement>
        <bounds x="216" y="418" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="49" y="413" width="175" height="25"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1280" height="1122"/>
    <name>SlotPlannedToRealized</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446408692_311479_346181" xmi:uuid="df2d1500-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622535849807_770291_73755"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408718_900645_346213" xmi:uuid="e0210aa0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033900159_655693_75410"/>
      <ownedElement xmi:id="dff55480-6c44-013d-d60e-0800270c66d6" xmi:uuid="dff55550-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033900159_655693_75410"/>
        <text>slotDesignToPlanned:Attachment_slot_design_to_planned</text>
      </ownedElement>
      <ownedElement xmi:id="e020fa50-6c44-013d-d60e-0800270c66d6" xmi:uuid="e020fb40-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1625033900159_655693_75410"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="350" height="330"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408734_660596_346247" xmi:uuid="e0225540-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="699" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408749_422756_346262" xmi:uuid="e02d07e0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="699" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408764_867691_346277" xmi:uuid="e056cd60-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="699" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408778_178831_346292" xmi:uuid="e0678dc0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="699" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408792_48132_346307" xmi:uuid="e0795c20-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="699" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408805_734638_346322" xmi:uuid="e07aa400-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="699" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408819_253107_346337" xmi:uuid="e08fdba0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="699" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408830_559343_346352" xmi:uuid="e0b98eb0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="699" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408846_109419_346367" xmi:uuid="e0cd0fa0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="699" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408863_901170_346382" xmi:uuid="e0ce6160-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="699" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408878_485503_346397" xmi:uuid="e0e07f10-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="699" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408889_971457_346412" xmi:uuid="e0fbc620-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="699" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408898_437103_346427" xmi:uuid="e0fd5390-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="699" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446408908_399836_346442" xmi:uuid="e1236cd0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="699" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_46416_415814" xmi:uuid="e1237ed0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920449_145214_73780"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408734_660596_346247"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="62"/>
      <waypoint x="395" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_451403_415817" xmi:uuid="e12385b0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920510_340866_73796"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408749_422756_346262"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="82"/>
      <waypoint x="395" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_72762_415820" xmi:uuid="e1238df0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920569_245135_73812"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408764_867691_346277"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="102"/>
      <waypoint x="395" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_658882_415823" xmi:uuid="e1239570-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920629_302502_73828"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408778_178831_346292"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="122"/>
      <waypoint x="395" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_828932_415826" xmi:uuid="e123a6e0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920686_749865_73844"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408792_48132_346307"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="142"/>
      <waypoint x="395" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_244405_415829" xmi:uuid="e123ae60-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920745_303096_73860"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408805_734638_346322"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="162"/>
      <waypoint x="395" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_950958_415832" xmi:uuid="e123b510-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920805_878747_73876"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408819_253107_346337"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="182"/>
      <waypoint x="395" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_809277_415835" xmi:uuid="e123bc20-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920868_850918_73892"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408830_559343_346352"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="202"/>
      <waypoint x="395" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_105886_415838" xmi:uuid="e123c2a0-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147920939_343282_73908"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408846_109419_346367"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="222"/>
      <waypoint x="395" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_888780_415841" xmi:uuid="e123c960-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147921036_56260_73924"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408863_901170_346382"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="242"/>
      <waypoint x="395" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_93114_415844" xmi:uuid="e13ad750-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147921116_129360_73940"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408878_485503_346397"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="262"/>
      <waypoint x="395" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_805835_415847" xmi:uuid="e13ae750-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147921180_538666_73956"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408889_971457_346412"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="282"/>
      <waypoint x="395" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_861204_415850" xmi:uuid="e13aee60-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147921235_529486_73972"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408898_437103_346427"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="302"/>
      <waypoint x="395" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511595_71221_415853" xmi:uuid="e13af590-6c44-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147921295_584156_73988"/>
      <source xmi:idref="_18_4_1_65b021e_1727446408908_399836_346442"/>
      <target xmi:idref="_18_4_1_65b021e_1727446408718_900645_346213"/>
      <waypoint x="699" y="322"/>
      <waypoint x="395" y="322"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="702" height="400"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446409074_554637_346652" xmi:uuid="e8b68910-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409100_83589_346684" xmi:uuid="ea261740-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Slot.xmi#_18_4_1_8be0287_1623158103837_46892_81416"/>
      <ownedElement xmi:id="e9f5a030-6c42-013d-d60e-0800270c66d6" xmi:uuid="e9f5a0f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623158103837_46892_81416"/>
        <text>attachmentSlotVersion:Attachment_slot_version</text>
      </ownedElement>
      <ownedElement xmi:id="ea260750-6c42-013d-d60e-0800270c66d6" xmi:uuid="ea260820-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Slot.xmi#_18_4_1_8be0287_1623158103837_46892_81416"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="294" height="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409116_532310_346718" xmi:uuid="ea42c860-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="650" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409126_676137_346733" xmi:uuid="ea5c5dd0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="650" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409140_55276_346748" xmi:uuid="ea797300-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="650" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409149_155983_346763" xmi:uuid="ea8d45c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="650" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409157_29082_346778" xmi:uuid="eaa42df0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="650" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409167_594414_346793" xmi:uuid="eac0f5f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="650" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409176_826854_346808" xmi:uuid="eace9c30-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="650" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409192_55119_346823" xmi:uuid="eacfeb90-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="650" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409205_974811_346838" xmi:uuid="eb001740-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="650" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409214_176450_346853" xmi:uuid="eb10ab80-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="650" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409228_205915_346868" xmi:uuid="eb2f7000-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="650" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409243_504588_346883" xmi:uuid="eb30db70-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="650" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409257_945024_346898" xmi:uuid="eb602aa0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="650" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409271_177140_346913" xmi:uuid="eb76cb70-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="650" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409281_281990_346928" xmi:uuid="eb8dcfa0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="650" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409295_323849_346943" xmi:uuid="ebadc3c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="650" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409305_270632_346958" xmi:uuid="ebc91b30-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="650" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409315_210447_346973" xmi:uuid="ebde6890-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="650" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409324_637053_346988" xmi:uuid="ebdfd260-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="650" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409340_892813_347003" xmi:uuid="ec10d210-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="650" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409356_31156_347018" xmi:uuid="ec123b20-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="650" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409368_804400_347033" xmi:uuid="ec141120-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="650" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409384_448200_347048" xmi:uuid="ec5de8a0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="650" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409392_525425_347063" xmi:uuid="ec750970-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643268851717_322008_86077"/>
      <bounds x="650" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409401_567343_347078" xmi:uuid="ec996030-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643269416144_30883_86580"/>
      <bounds x="650" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409409_904057_347093" xmi:uuid="ecad13d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643270131067_298147_86914"/>
      <bounds x="650" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409418_482794_347108" xmi:uuid="ecc8d0e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="650" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409432_566766_347123" xmi:uuid="ece2c4e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="650" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409443_668785_347138" xmi:uuid="ecf67fa0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="650" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409453_687285_347153" xmi:uuid="ed10a2d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="650" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409462_347288_347168" xmi:uuid="ed2f0d00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="650" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409472_123934_347183" xmi:uuid="ed4150b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="650" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409482_589210_347198" xmi:uuid="ed5e25d0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="650" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409492_797440_347213" xmi:uuid="ed762050-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="650" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409502_144812_347228" xmi:uuid="ed98f950-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="650" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409513_502091_347243" xmi:uuid="edae3f10-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="650" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446409524_882959_347258" xmi:uuid="edc9d490-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="650" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446410877_430061_347273" xmi:uuid="edcb2170-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570204497794_443467_105732"/>
      <bounds x="650" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446410888_834367_347288" xmi:uuid="ede83270-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="650" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_923694_415883" xmi:uuid="ede84110-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909090_425369_70635"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409116_532310_346718"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="62"/>
      <waypoint x="339" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_783454_415886" xmi:uuid="ede84770-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909157_269634_70651"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409126_676137_346733"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="82"/>
      <waypoint x="339" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_392121_415889" xmi:uuid="ede854b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909224_61667_70667"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409140_55276_346748"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="102"/>
      <waypoint x="339" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_514199_415892" xmi:uuid="ede85e10-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909297_267041_70683"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409149_155983_346763"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="122"/>
      <waypoint x="339" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_694061_415895" xmi:uuid="ede86460-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909368_502563_70699"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409157_29082_346778"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="142"/>
      <waypoint x="339" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_767249_415898" xmi:uuid="ede86b30-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909434_164969_70715"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409167_594414_346793"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="162"/>
      <waypoint x="339" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_311426_415901" xmi:uuid="ede87180-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909499_438518_70731"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409176_826854_346808"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="182"/>
      <waypoint x="339" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_53217_415904" xmi:uuid="ede877b0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909556_181501_70747"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409192_55119_346823"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="202"/>
      <waypoint x="339" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_409301_415907" xmi:uuid="ede87e00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909620_191649_70763"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409205_974811_346838"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="222"/>
      <waypoint x="339" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_392171_415910" xmi:uuid="ede88410-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909678_350455_70779"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409214_176450_346853"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="242"/>
      <waypoint x="339" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_251380_415913" xmi:uuid="ede88bf0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909739_146395_70795"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409228_205915_346868"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="262"/>
      <waypoint x="339" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_16487_415916" xmi:uuid="ede892e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909803_77056_70811"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409243_504588_346883"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="282"/>
      <waypoint x="339" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_905836_415919" xmi:uuid="ede89a00-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909862_430177_70827"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409257_945024_346898"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="302"/>
      <waypoint x="339" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_732109_415922" xmi:uuid="ede8a0f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909922_943591_70843"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409271_177140_346913"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="322"/>
      <waypoint x="339" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_814861_415925" xmi:uuid="ede8a720-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147909998_844069_70859"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409281_281990_346928"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="342"/>
      <waypoint x="339" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_739539_415928" xmi:uuid="ede909c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910065_765082_70875"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409295_323849_346943"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="362"/>
      <waypoint x="339" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_920752_415931" xmi:uuid="ede910e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910126_43455_70891"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409305_270632_346958"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="382"/>
      <waypoint x="339" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_948675_415934" xmi:uuid="ede91860-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910184_894942_70907"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409315_210447_346973"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="402"/>
      <waypoint x="339" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_919799_415937" xmi:uuid="ede91e70-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910246_968696_70923"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409324_637053_346988"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="422"/>
      <waypoint x="339" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_118299_415940" xmi:uuid="ede92450-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910306_780648_70939"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409340_892813_347003"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="442"/>
      <waypoint x="339" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_21283_415943" xmi:uuid="ede92a50-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910371_525795_70955"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409356_31156_347018"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="462"/>
      <waypoint x="339" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_328966_415946" xmi:uuid="ede93090-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910437_769395_70971"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409368_804400_347033"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="482"/>
      <waypoint x="339" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_600934_415949" xmi:uuid="ede937f0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910498_517060_70987"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409384_448200_347048"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="502"/>
      <waypoint x="339" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_409070_415952" xmi:uuid="ede93da0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910558_163767_71003"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409392_525425_347063"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="522"/>
      <waypoint x="339" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_993925_415955" xmi:uuid="ede94390-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910617_821767_71019"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409401_567343_347078"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="542"/>
      <waypoint x="339" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_514066_415958" xmi:uuid="ede94910-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910671_527402_71035"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409409_904057_347093"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="562"/>
      <waypoint x="339" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_618979_415961" xmi:uuid="ede94f40-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910736_826828_71051"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409418_482794_347108"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="582"/>
      <waypoint x="339" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_378651_415964" xmi:uuid="ede954e0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910799_240648_71067"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409432_566766_347123"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="602"/>
      <waypoint x="339" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_768851_415967" xmi:uuid="ede95c60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910856_107448_71083"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409443_668785_347138"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="622"/>
      <waypoint x="339" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_76220_415970" xmi:uuid="ede96430-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910914_306237_71099"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409453_687285_347153"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="642"/>
      <waypoint x="339" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_959181_415973" xmi:uuid="ede96b90-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147910971_357798_71115"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409462_347288_347168"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="662"/>
      <waypoint x="339" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_918108_415976" xmi:uuid="ede97160-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911029_404941_71131"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409472_123934_347183"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="682"/>
      <waypoint x="339" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_272641_415979" xmi:uuid="ede97790-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911087_571670_71147"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409482_589210_347198"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="702"/>
      <waypoint x="339" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_380918_415982" xmi:uuid="ede97e30-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911146_201242_71163"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409492_797440_347213"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="722"/>
      <waypoint x="339" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_853041_415985" xmi:uuid="ede996c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911211_473148_71179"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409502_144812_347228"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="742"/>
      <waypoint x="339" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_371375_415988" xmi:uuid="ede99d20-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911274_898991_71195"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409513_502091_347243"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="762"/>
      <waypoint x="339" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_638518_415991" xmi:uuid="ede9a300-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911332_197271_71211"/>
      <source xmi:idref="_18_4_1_65b021e_1727446409524_882959_347258"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="782"/>
      <waypoint x="339" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_417224_415994" xmi:uuid="ede9a8c0-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911389_47077_71227"/>
      <source xmi:idref="_18_4_1_65b021e_1727446410877_430061_347273"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="802"/>
      <waypoint x="339" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446511604_727465_415997" xmi:uuid="ede9ae60-6c42-013d-d60e-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Slot.xmi#_18_4_1_65b021e_1663147911448_220691_71243"/>
      <source xmi:idref="_18_4_1_65b021e_1727446410888_834367_347288"/>
      <target xmi:idref="_18_4_1_65b021e_1727446409100_83589_346684"/>
      <waypoint x="650" y="822"/>
      <waypoint x="339" y="822"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="653" height="900"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
