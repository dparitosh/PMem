<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_6b1022a_1575017940671_140031_44879" xmi:uuid="904c30d0-3aa6-0138-3eec-418b172fba9f">
    <base_UMLClassDiagram xmi:idref="_18_4_1_6b1022a_1575017940667_565914_44868"/>
    <defaultNamespace href="WorkManagement.xmi#_18_4_1_8e001ed_1498551953993_839020_14116"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703186394999_709826_480813" xmi:uuid="919a4520-915f-013c-7167-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703186394994_406648_480802"/>
    <defaultNamespace href="WorkManagement.xmi#_18_4_1_8e001ed_1498551953993_839020_14116"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703186413338_174712_481501" xmi:uuid="93a4c790-915f-013c-7167-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703186413333_749576_481490"/>
    <defaultNamespace href="WorkManagement.xmi#_18_4_1_8e001ed_1498551953993_839020_14116"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_271a0567_1577965270212_499833_60389" xmi:uuid="9112e0d0-3aa6-0138-3eec-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_271a0567_1577965270200_255077_60378"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkRequestRelationship"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_271a0567_1577962770460_830708_51095" xmi:uuid="9118b040-3aa6-0138-3eec-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_271a0567_1577962770444_648435_51084"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkOrderAssignment"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1518011784794_625777_32031" xmi:uuid="91203c30-3aa6-0138-3eec-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1518011784732_793523_32019"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkOrder"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_271a0567_1577964460924_953879_58598" xmi:uuid="912bc380-3aa6-0138-3eec-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_271a0567_1577964460915_445214_58587"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkOrderRelationship"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_271a0567_1577956013131_762902_55279" xmi:uuid="912f66f0-3aa6-0138-3eec-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_271a0567_1577956013115_235999_55268"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkRequest"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_271a0567_1577963956898_653922_57030" xmi:uuid="913b16c0-3aa6-0138-3eec-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_271a0567_1577963956891_907332_57019"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkRequestAssignment"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446469488_773550_373581" xmi:uuid="d950fc60-6c76-013d-d644-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446469480_986753_373570"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkRequestRelationship"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446467477_953555_373139" xmi:uuid="ddaf7150-6c76-013d-d644-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446467469_300750_373128"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkOrderAssignment"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446469850_270052_374023" xmi:uuid="e27b2210-6c76-013d-d644-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446469843_918227_374012"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkOrder"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446462773_458682_371624" xmi:uuid="e6edf2b0-6c76-013d-d644-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446462766_66390_371613"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkOrderRelationship"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446467029_742866_372509" xmi:uuid="eca921c0-6c76-013d-d644-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446467022_92148_372498"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkRequest"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446463158_492559_372067" xmi:uuid="f3b7bfc0-6c76-013d-d644-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446463151_781213_372056"/>
    <defaultNamespace href="WorkManagement.xmi#_WorkRequestAssignment"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_6b1022a_1575017940667_565914_44868" xmi:uuid="904c12a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="WorkManagement.xmi#_18_4_1_8e001ed_1498551953993_839020_14116"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1575017982399_920568_44907" xmi:uuid="906af3a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="WorkManagement.xmi#_WorkOrder"/>
      <ownedElement xmi:id="904df470-3aa6-0138-3eec-418b172fba9f" xmi:uuid="904df4e0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="WorkManagement.xmi#_WorkOrder"/>
        <text>WorkOrder</text>
      </ownedElement>
      <ownedElement xmi:id="90504890-3aa6-0138-3eec-418b172fba9f" xmi:uuid="905048f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="906a4450-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906a44d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="906a4830-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906a4860-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="906a4d90-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906a4dc0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-Id"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="906a5170-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906a51a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-Description"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="906a5620-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906a5650-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-ClassifiedAs"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="906a59f0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906a5a20-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-SameAs"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="906ae4d0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906ae510-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="906ae840-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906ae880-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="906aec90-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906aecc0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-OrderType"/>
          <text>OrderType</text>
        </ownedElement>
      </ownedElement>
      <bounds x="70" y="161" width="179" height="166"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1575017990176_992113_44956" xmi:uuid="908e87c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="WorkManagement.xmi#_WorkRequest"/>
      <ownedElement xmi:id="906c1530-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906c16d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="WorkManagement.xmi#_WorkRequest"/>
        <text>WorkRequest</text>
      </ownedElement>
      <ownedElement xmi:id="906e0810-3aa6-0138-3eec-418b172fba9f" xmi:uuid="906e0850-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="908de190-3aa6-0138-3eec-418b172fba9f" xmi:uuid="908de210-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="908de600-3aa6-0138-3eec-418b172fba9f" xmi:uuid="908de630-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="908dead0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="908deb00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Id"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="908def70-3aa6-0138-3eec-418b172fba9f" xmi:uuid="908defb0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Description"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="908df320-3aa6-0138-3eec-418b172fba9f" xmi:uuid="908df350-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-ClassifiedAs"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="908df780-3aa6-0138-3eec-418b172fba9f" xmi:uuid="908df7b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-SameAs"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="908e7820-3aa6-0138-3eec-418b172fba9f" xmi:uuid="908e7860-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="908e7b90-3aa6-0138-3eec-418b172fba9f" xmi:uuid="908e7bb0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="908e8020-3aa6-0138-3eec-418b172fba9f" xmi:uuid="908e8050-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-RequestType"/>
          <text>RequestType</text>
        </ownedElement>
      </ownedElement>
      <bounds x="448" y="161" width="179" height="166"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1575018023342_256542_45066" xmi:uuid="90a56960-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="WorkManagement.xmi#_WorkOrderAssignment"/>
      <ownedElement xmi:id="908f9430-3aa6-0138-3eec-418b172fba9f" xmi:uuid="908f9460-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="WorkManagement.xmi#_WorkOrderAssignment"/>
        <text>WorkOrderAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="909188d0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90918910-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="90a55470-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90a55520-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="90a558d0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90a55900-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="90a55d30-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90a55d60-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-Role"/>
          <text>Role</text>
        </ownedElement>
      </ownedElement>
      <bounds x="70" y="371" width="189" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1575018037112_475462_45110" xmi:uuid="90af20f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="WorkManagement.xmi#_WorkOrderRelationship"/>
      <ownedElement xmi:id="90a67440-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90a67480-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="WorkManagement.xmi#_WorkOrderRelationship"/>
        <text>WorkOrderRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="90a866b0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90a866f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="90af0cc0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90af0d10-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="90af11c0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90af11f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="90af15a0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90af15c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-RelationType"/>
          <text>RelationType</text>
        </ownedElement>
      </ownedElement>
      <bounds x="28" y="42" width="273" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1575018051044_935460_45154" xmi:uuid="90bb01f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="WorkManagement.xmi#_WorkRequestRelationship"/>
      <ownedElement xmi:id="90b04b60-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90b04bb0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="WorkManagement.xmi#_WorkRequestRelationship"/>
        <text>WorkRequestRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="90b23c60-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90b23c90-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="90baed60-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90baedd0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="90baf140-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90baf160-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="90baf660-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90baf680-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-RelationType"/>
          <text>RelationType</text>
        </ownedElement>
      </ownedElement>
      <bounds x="406" y="42" width="273" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577953805342_700572_49452" xmi:uuid="90bd6ef0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_1_association_WorkOrder-InResponseTo"/>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953805142_813997_49438" xmi:uuid="90bd4f70-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-InResponseTo"/>
        <bounds x="372" y="198" width="73" height="13"/>
        <text>InResponseTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953805173_252512_49440" xmi:uuid="90bd5da0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-InResponseTo"/>
        <bounds x="421" y="217" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953805173_602197_49444" xmi:uuid="90bd6910-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_1_association_WorkOrder-InResponseTo-end"/>
        <bounds x="252" y="217" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1575017982399_920568_44907"/>
      <target xmi:idref="_18_4_1_6b1022a_1575017990176_992113_44956"/>
      <waypoint x="249" y="214"/>
      <waypoint x="448" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577953823862_796165_49469" xmi:uuid="90c2bca0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="WorkManagement.xmi#_WorkOrderAssignmentSelect"/>
      <ownedElement xmi:id="90be87b0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90be87f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="WorkManagement.xmi#_WorkOrderAssignmentSelect"/>
        <text>WorkOrderAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="90c08e70-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90c08ec0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="90c09300-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90c09330-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="91" y="490" width="169" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577953832147_426052_49524" xmi:uuid="90c50f70-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_1_association_WorkOrderAssignment-AssignedTo"/>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953832093_513121_49510" xmi:uuid="90c4f170-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-AssignedTo"/>
        <bounds x="106" y="462" width="59" height="13"/>
        <text>AssignedTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953832109_838040_49512" xmi:uuid="90c4fd50-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-AssignedTo"/>
        <bounds x="171" y="462" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953832109_912083_49516" xmi:uuid="90c50920-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_1_association_WorkOrderAssignment-AssignedTo-end"/>
        <bounds x="171" y="455" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1575018023342_256542_45066"/>
      <target xmi:idref="_18_4_1_271a0567_1577953823862_796165_49469"/>
      <waypoint x="168" y="452"/>
      <waypoint x="168" y="490"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577953837287_549061_49551" xmi:uuid="90c76270-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_1_association_WorkOrderAssignment-AssignedWorkOrder"/>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953837225_242339_49537" xmi:uuid="90c745d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-AssignedWorkOrder"/>
        <bounds x="50" y="330" width="101" height="13"/>
        <text>AssignedWorkOrder</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953837225_697592_49539" xmi:uuid="90c75090-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-AssignedWorkOrder"/>
        <bounds x="157" y="330" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953837240_370938_49543" xmi:uuid="90c75c30-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_1_association_WorkOrderAssignment-AssignedWorkOrder-end"/>
        <bounds x="157" y="355" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1575018023342_256542_45066"/>
      <target xmi:idref="_18_4_1_6b1022a_1575017982399_920568_44907"/>
      <waypoint x="154" y="371"/>
      <waypoint x="154" y="327"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577953859674_432902_49590" xmi:uuid="90c9d0d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_1_association_WorkRequestRelationship-Relating"/>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953859620_20936_49576" xmi:uuid="90c9afd0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-Relating"/>
        <bounds x="458" y="133" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953859636_267571_49578" xmi:uuid="90c9bb90-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-Relating"/>
        <bounds x="504" y="133" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953859636_656635_49582" xmi:uuid="90c9c9a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_1_association_WorkRequestRelationship-Relating-end"/>
        <bounds x="504" y="114" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1575018051044_935460_45154"/>
      <target xmi:idref="_18_4_1_6b1022a_1575017990176_992113_44956"/>
      <waypoint x="501" y="111"/>
      <waypoint x="501" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577953861565_849439_49619" xmi:uuid="90cc24e0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_1_association_WorkRequestRelationship-Related"/>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953861525_924916_49605" xmi:uuid="90cc05f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-Related"/>
        <bounds x="551" y="145" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953861525_646396_49607" xmi:uuid="90cc1130-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-Related"/>
        <bounds x="595" y="145" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953861533_607566_49611" xmi:uuid="90cc1e20-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_1_association_WorkRequestRelationship-Related-end"/>
        <bounds x="595" y="114" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1575018051044_935460_45154"/>
      <target xmi:idref="_18_4_1_6b1022a_1575017990176_992113_44956"/>
      <waypoint x="592" y="111"/>
      <waypoint x="592" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577953889750_41809_49660" xmi:uuid="90ce7210-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_1_association_WorkOrderRelationship-Related"/>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953889728_595155_49646" xmi:uuid="90ce4f30-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-Related"/>
        <bounds x="64" y="145" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953889735_863916_49648" xmi:uuid="90ce5ca0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-Related"/>
        <bounds x="108" y="145" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953889735_11242_49652" xmi:uuid="90ce6af0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_1_association_WorkOrderRelationship-Related-end"/>
        <bounds x="108" y="114" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1575018037112_475462_45110"/>
      <target xmi:idref="_18_4_1_6b1022a_1575017982399_920568_44907"/>
      <waypoint x="105" y="111"/>
      <waypoint x="105" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577953893054_776368_49689" xmi:uuid="90d0d200-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_1_association_WorkOrderRelationship-Relating"/>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953893016_272190_49675" xmi:uuid="90d0a6b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-Relating"/>
        <bounds x="153" y="133" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953893016_287008_49677" xmi:uuid="90d0b8e0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-Relating"/>
        <bounds x="199" y="133" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577953893016_776270_49681" xmi:uuid="90d0c790-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_1_association_WorkOrderRelationship-Relating-end"/>
        <bounds x="199" y="114" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1575018037112_475462_45110"/>
      <target xmi:idref="_18_4_1_6b1022a_1575017982399_920568_44907"/>
      <waypoint x="196" y="111"/>
      <waypoint x="196" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954365709_903652_49898" xmi:uuid="90e14c60-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="WorkManagement.xmi#_WorkRequestAssignment"/>
      <ownedElement xmi:id="90d1e0b0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90d1e0f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="WorkManagement.xmi#_WorkRequestAssignment"/>
        <text>WorkRequestAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="90d3d3f0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90d3d430-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="90e13590-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90e135f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="90e13950-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90e13970-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="90e13d50-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90e13d80-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-Role"/>
          <text>Role</text>
        </ownedElement>
      </ownedElement>
      <bounds x="455" y="364" width="189" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954371939_21160_49955" xmi:uuid="90e3ac80-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_1_association_WorkRequestAssignment-AssignedWorkRequest"/>
      <ownedElement xmi:id="_18_4_1_271a0567_1577954371901_816647_49941" xmi:uuid="90e385e0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-AssignedWorkRequest"/>
        <bounds x="444" y="330" width="113" height="13"/>
        <text>AssignedWorkRequest</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577954371916_126102_49943" xmi:uuid="90e39500-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-AssignedWorkRequest"/>
        <bounds x="563" y="330" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577954371916_810727_49947" xmi:uuid="90e3a6d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_1_association_WorkRequestAssignment-AssignedWorkRequest-end"/>
        <bounds x="563" y="348" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_271a0567_1577954365709_903652_49898"/>
      <target xmi:idref="_18_4_1_6b1022a_1575017990176_992113_44956"/>
      <waypoint x="560" y="364"/>
      <waypoint x="560" y="327"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954381323_90264_49980" xmi:uuid="90e91ad0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="WorkManagement.xmi#_WorkRequestAssignmentSelect"/>
      <ownedElement xmi:id="90e4e2b0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90e4e2f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="WorkManagement.xmi#_WorkRequestAssignmentSelect"/>
        <text>WorkRequestAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="90e6dcb0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90e6dcf0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="90e6e1c0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90e6e1f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="476" y="490" width="180" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954381338_783939_50025" xmi:uuid="90eb7550-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_1_association_WorkRequestAssignment-AssignedTo"/>
      <ownedElement xmi:id="_18_4_1_271a0567_1577954381307_646610_49970" xmi:uuid="90eb5830-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-AssignedTo"/>
        <bounds x="456" y="462" width="59" height="13"/>
        <text>AssignedTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577954381307_419803_49972" xmi:uuid="90eb63e0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-AssignedTo"/>
        <bounds x="521" y="462" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577954381323_723955_49976" xmi:uuid="90eb6f10-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_1_association_WorkRequestAssignment-AssignedTo-end"/>
        <bounds x="521" y="436" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_271a0567_1577954365709_903652_49898"/>
      <target xmi:idref="_18_4_1_271a0567_1577954381323_90264_49980"/>
      <waypoint x="518" y="433"/>
      <waypoint x="518" y="490"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954482711_675640_50054" xmi:uuid="90fdc5b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityAssignmentSelect"/>
      <ownedElement xmi:id="90f09780-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90f09800-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityAssignmentSelect"/>
        <text>ActivityAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="90f72930-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90f729b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="90f72dd0-3aa6-0138-3eec-418b172fba9f" xmi:uuid="90f72e00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="280" y="320" width="149" height="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954482726_204282_50099" xmi:uuid="9104ae40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_1_association_WorkRequest-Scope"/>
      <ownedElement xmi:id="_18_4_1_271a0567_1577954482695_123906_50044" xmi:uuid="91048d40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Scope"/>
        <bounds x="315" y="304" width="32" height="13"/>
        <text>Scope</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577954482695_90101_50046" xmi:uuid="91049cd0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Scope"/>
        <bounds x="353" y="304" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577954482695_217401_50050" xmi:uuid="9104a900-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_1_association_WorkRequest-Scope-end"/>
        <bounds x="421" y="266" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1575017990176_992113_44956"/>
      <target xmi:idref="_18_4_1_271a0567_1577954482711_675640_50054"/>
      <waypoint x="448" y="263"/>
      <waypoint x="350" y="263"/>
      <waypoint x="350" y="320"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="694" height="553"/>
    <name>WorkManagement</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703186394994_406648_480802" xmi:uuid="919933e0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="WorkManagement.xmi#_18_4_1_8e001ed_1498551953993_839020_14116"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186395050_351029_480835" xmi:uuid="91a12cc0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="WorkManagement.xmi#_WorkOrderAssignmentSelect"/>
      <ownedElement xmi:id="919d8c10-915f-013c-7167-0a5172f4a469" xmi:uuid="919d8d50-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="WorkManagement.xmi#_WorkOrderAssignmentSelect"/>
        <text>WorkOrderAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="919f3e70-915f-013c-7167-0a5172f4a469" xmi:uuid="919f3f70-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="91a01170-915f-013c-7167-0a5172f4a469" xmi:uuid="91a01280-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1086" height="155"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186397601_882411_480906" xmi:uuid="91d81f00-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="91a3d3e0-915f-013c-7167-0a5172f4a469" xmi:uuid="91a3d500-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="c33c2b60-6c76-013d-d644-0800270c66d6" xmi:uuid="c33c2d10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186399729_238036_481000" xmi:uuid="92190e30-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
      <ownedElement xmi:id="91daba00-915f-013c-7167-0a5172f4a469" xmi:uuid="91dabb40-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
        <text>ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="c3688be0-6c76-013d-d644-0800270c66d6" xmi:uuid="c3689310-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="278" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186402022_721213_481069" xmi:uuid="92458690-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
      <ownedElement xmi:id="921f30b0-915f-013c-7167-0a5172f4a469" xmi:uuid="921f31e0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
        <text>Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="c3ab4990-6c76-013d-d644-0800270c66d6" xmi:uuid="c3ab4a30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="491" y="95" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186403912_601521_481136" xmi:uuid="926d9650-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
      <ownedElement xmi:id="924824b0-915f-013c-7167-0a5172f4a469" xmi:uuid="924825e0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
        <text>SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="c3d66a90-6c76-013d-d644-0800270c66d6" xmi:uuid="c3d66b30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="763" y="95" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186406195_620297_481221" xmi:uuid="9296fed0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
      <ownedElement xmi:id="926fdb40-915f-013c-7167-0a5172f4a469" xmi:uuid="926fdc60-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
        <text>SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="c3f657c0-6c76-013d-d644-0800270c66d6" xmi:uuid="c3f65870-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="145" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186408095_259920_481288" xmi:uuid="92f1fd80-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
      <ownedElement xmi:id="92a289a0-915f-013c-7167-0a5172f4a469" xmi:uuid="92a28d40-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
        <text>TaskElement</text>
      </ownedElement>
      <ownedElement xmi:id="c43a7c60-6c76-013d-d644-0800270c66d6" xmi:uuid="c43a7d10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="337" y="145" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186410725_914018_481358" xmi:uuid="934aa190-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
      <ownedElement xmi:id="92f63940-915f-013c-7167-0a5172f4a469" xmi:uuid="92f63a90-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
        <text>TaskMethod</text>
      </ownedElement>
      <ownedElement xmi:id="c48b80d0-6c76-013d-d644-0800270c66d6" xmi:uuid="c48b8170-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="595" y="145" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186413297_517049_481449" xmi:uuid="93a2d8e0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
      <ownedElement xmi:id="934e8090-915f-013c-7167-0a5172f4a469" xmi:uuid="934e81b0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
        <text>TaskMethodVersion</text>
      </ownedElement>
      <ownedElement xmi:id="c4e5a210-6c76-013d-d644-0800270c66d6" xmi:uuid="c4e5a2c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="853" y="145" width="238" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1146" height="225"/>
    <name>WorkOrderAssignmentSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703186413333_749576_481490" xmi:uuid="93a3c7e0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="WorkManagement.xmi#_18_4_1_8e001ed_1498551953993_839020_14116"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186413368_345878_481522" xmi:uuid="93acaa90-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="WorkManagement.xmi#_WorkRequestAssignmentSelect"/>
      <ownedElement xmi:id="93a8e9f0-915f-013c-7167-0a5172f4a469" xmi:uuid="93a8eb10-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="WorkManagement.xmi#_WorkRequestAssignmentSelect"/>
        <text>WorkRequestAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="93aaae90-915f-013c-7167-0a5172f4a469" xmi:uuid="93aaafc0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="93ab90f0-915f-013c-7167-0a5172f4a469" xmi:uuid="93ab91f0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1260" height="905"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186415908_639582_481593" xmi:uuid="93e33f10-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="93af5be0-915f-013c-7167-0a5172f4a469" xmi:uuid="93af5d20-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="c545b6b0-6c76-013d-d644-0800270c66d6" xmi:uuid="c545b760-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186418025_517075_481687" xmi:uuid="942430c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
      <ownedElement xmi:id="93e5b9e0-915f-013c-7167-0a5172f4a469" xmi:uuid="93e5bb10-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
        <text>ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="c5702ac0-6c76-013d-d644-0800270c66d6" xmi:uuid="c5702b70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="278" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186420640_394743_481761" xmi:uuid="948a5c60-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_Breakdown"/>
      <ownedElement xmi:id="942fd370-915f-013c-7167-0a5172f4a469" xmi:uuid="942fd4a0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_Breakdown"/>
        <text>Breakdown</text>
      </ownedElement>
      <ownedElement xmi:id="c5b91f10-6c76-013d-d644-0800270c66d6" xmi:uuid="c5b91fd0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="491" y="95" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186423312_749361_481835" xmi:uuid="94e83a90-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
      <ownedElement xmi:id="948df740-915f-013c-7167-0a5172f4a469" xmi:uuid="948df890-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
        <text>BreakdownElement</text>
      </ownedElement>
      <ownedElement xmi:id="c602cac0-6c76-013d-d644-0800270c66d6" xmi:uuid="c602cb70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="724" y="95" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186425783_660422_481908" xmi:uuid="95248260-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersion"/>
      <ownedElement xmi:id="94ebc6a0-915f-013c-7167-0a5172f4a469" xmi:uuid="94ebc7c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersion"/>
        <text>BreakdownElementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="c64c6af0-6c76-013d-d644-0800270c66d6" xmi:uuid="c64c6ba0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="957" y="95" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186428600_286652_481991" xmi:uuid="957a7800-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
      <ownedElement xmi:id="95282560-915f-013c-7167-0a5172f4a469" xmi:uuid="95282690-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
        <text>BreakdownElementView</text>
      </ownedElement>
      <ownedElement xmi:id="c67d5030-6c76-013d-d644-0800270c66d6" xmi:uuid="c67d50e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186429433_746370_482057" xmi:uuid="958f18c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementViewRelationship"/>
      <ownedElement xmi:id="957e2c50-915f-013c-7167-0a5172f4a469" xmi:uuid="957e2d80-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementViewRelationship"/>
        <text>BreakdownElementViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c6bfd1c0-6c76-013d-d644-0800270c66d6" xmi:uuid="c6bfd280-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="298" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186431262_485184_482128" xmi:uuid="95c6fff0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersion"/>
      <ownedElement xmi:id="9592b5a0-915f-013c-7167-0a5172f4a469" xmi:uuid="9592b7c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersion"/>
        <text>BreakdownVersion</text>
      </ownedElement>
      <ownedElement xmi:id="c6cfa220-6c76-013d-d644-0800270c66d6" xmi:uuid="c6cfa2d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="531" y="145" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186433548_78086_482197" xmi:uuid="95f51810-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581927879268_726070_55882"/>
      <ownedElement xmi:id="95cd2c00-915f-013c-7167-0a5172f4a469" xmi:uuid="95cd2d20-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581927879268_726070_55882"/>
        <text>Collection</text>
      </ownedElement>
      <ownedElement xmi:id="c70943a0-6c76-013d-d644-0800270c66d6" xmi:uuid="c7094440-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="764" y="145" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186435750_994637_482272" xmi:uuid="961665d0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
      <ownedElement xmi:id="95f79470-915f-013c-7167-0a5172f4a469" xmi:uuid="95f795b0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
        <text>CollectionVersion</text>
      </ownedElement>
      <ownedElement xmi:id="c72a10f0-6c76-013d-d644-0800270c66d6" xmi:uuid="c72a11a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="989" y="145" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186437876_589958_482345" xmi:uuid="9635b100-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
      <ownedElement xmi:id="9618b7f0-915f-013c-7167-0a5172f4a469" xmi:uuid="9618b920-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
        <text>CollectionView</text>
      </ownedElement>
      <ownedElement xmi:id="c74250f0-6c76-013d-d644-0800270c66d6" xmi:uuid="c74252a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="195" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186438662_151132_482410" xmi:uuid="96401cf0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582642454437_633211_62145"/>
      <ownedElement xmi:id="9637eac0-915f-013c-7167-0a5172f4a469" xmi:uuid="9637ebe0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582642454437_633211_62145"/>
        <text>CollectionViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c759cbb0-6c76-013d-d644-0800270c66d6" xmi:uuid="c759cc60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="290" y="195" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186440147_918040_482474" xmi:uuid="96f820c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Contract"/>
      <ownedElement xmi:id="96564980-915f-013c-7167-0a5172f4a469" xmi:uuid="96565770-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Contract"/>
        <text>Contract</text>
      </ownedElement>
      <ownedElement xmi:id="c7a10070-6c76-013d-d644-0800270c66d6" xmi:uuid="c7a10110-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="515" y="195" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186442795_174508_482548" xmi:uuid="974925a0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_Document"/>
      <ownedElement xmi:id="970042b0-915f-013c-7167-0a5172f4a469" xmi:uuid="97004400-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_Document"/>
        <text>Document</text>
      </ownedElement>
      <ownedElement xmi:id="c82e99c0-6c76-013d-d644-0800270c66d6" xmi:uuid="c82e9a60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="810" y="195" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186445207_262484_482614" xmi:uuid="977d7030-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
      <ownedElement xmi:id="974bf410-915f-013c-7167-0a5172f4a469" xmi:uuid="974bf540-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
        <text>DocumentDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="c8629ef0-6c76-013d-d644-0800270c66d6" xmi:uuid="c8629f90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="245" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186446167_237684_482683" xmi:uuid="97919610-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinitionRelationship"/>
      <ownedElement xmi:id="97802b10-915f-013c-7167-0a5172f4a469" xmi:uuid="978037b0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinitionRelationship"/>
        <text>DocumentDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c889ebc0-6c76-013d-d644-0800270c66d6" xmi:uuid="c889ec60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="356" y="245" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186448499_668609_482768" xmi:uuid="97be3140-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
      <ownedElement xmi:id="97945820-915f-013c-7167-0a5172f4a469" xmi:uuid="97945990-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
        <text>DocumentVersion</text>
      </ownedElement>
      <ownedElement xmi:id="c89a3150-6c76-013d-d644-0800270c66d6" xmi:uuid="c89a3200-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="647" y="245" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186450198_420529_482833" xmi:uuid="97f597c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_File"/>
      <ownedElement xmi:id="97c16a30-915f-013c-7167-0a5172f4a469" xmi:uuid="97c16b80-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_File"/>
        <text>File</text>
      </ownedElement>
      <ownedElement xmi:id="c8bb2f70-6c76-013d-d644-0800270c66d6" xmi:uuid="c8bb3150-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="938" y="245" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186452553_836134_482902" xmi:uuid="98376d00-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
      <ownedElement xmi:id="97fe0430-915f-013c-7167-0a5172f4a469" xmi:uuid="97fe0590-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
        <text>IndividualPart</text>
      </ownedElement>
      <ownedElement xmi:id="c8f17300-6c76-013d-d644-0800270c66d6" xmi:uuid="c8f173a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="295" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186454843_447040_482976" xmi:uuid="98693f20-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
      <ownedElement xmi:id="983a6a00-915f-013c-7167-0a5172f4a469" xmi:uuid="983a6b20-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
        <text>IndividualPartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="c921af40-6c76-013d-d644-0800270c66d6" xmi:uuid="c921afe0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="308" y="295" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186457187_134847_483051" xmi:uuid="989ab770-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="986c39e0-915f-013c-7167-0a5172f4a469" xmi:uuid="986c3d40-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="c945c750-6c76-013d-d644-0800270c66d6" xmi:uuid="c945c800-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="551" y="295" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186458040_76453_483117" xmi:uuid="98aa8480-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartViewRelationship"/>
      <ownedElement xmi:id="989da300-915f-013c-7167-0a5172f4a469" xmi:uuid="989da420-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartViewRelationship"/>
        <text>IndividualPartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="c96be8d0-6c76-013d-d644-0800270c66d6" xmi:uuid="c96be970-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="794" y="295" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186459550_999456_483182" xmi:uuid="99002c40-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133691013_484756_38870"/>
      <ownedElement xmi:id="98b557e0-915f-013c-7167-0a5172f4a469" xmi:uuid="98b55900-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133691013_484756_38870"/>
        <text>InterfaceConnection</text>
      </ownedElement>
      <ownedElement xmi:id="c993f8b0-6c76-013d-d644-0800270c66d6" xmi:uuid="c993f950-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186461875_800337_483250" xmi:uuid="99584b30-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133997057_424483_38872"/>
      <ownedElement xmi:id="9903d990-915f-013c-7167-0a5172f4a469" xmi:uuid="9903dad0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133997057_424483_38872"/>
        <text>InterfaceConnector</text>
      </ownedElement>
      <ownedElement xmi:id="c9cfcd60-6c76-013d-d644-0800270c66d6" xmi:uuid="c9cfce00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186463594_938723_483311" xmi:uuid="999c1850-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134009996_168675_38876"/>
      <ownedElement xmi:id="995c4760-915f-013c-7167-0a5172f4a469" xmi:uuid="995c48a0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134009996_168675_38876"/>
        <text>InterfaceConnectorOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="ca150cf0-6c76-013d-d644-0800270c66d6" xmi:uuid="ca150d90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="507" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186464387_340379_483378" xmi:uuid="99b90430-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1588154755027_637191_58929"/>
      <ownedElement xmi:id="999ff410-915f-013c-7167-0a5172f4a469" xmi:uuid="999ff540-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1588154755027_637191_58929"/>
        <text>InterfaceConnectorOccurrenceRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="ca49b100-6c76-013d-d644-0800270c66d6" xmi:uuid="ca49b1b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="728" y="345" width="237" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186466593_813541_483451" xmi:uuid="99fc5e40-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134019779_950347_38878"/>
      <ownedElement xmi:id="99bd2ba0-915f-013c-7167-0a5172f4a469" xmi:uuid="99bd2cd0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134019779_950347_38878"/>
        <text>InterfaceConnectorVersion</text>
      </ownedElement>
      <ownedElement xmi:id="ca610910-6c76-013d-d644-0800270c66d6" xmi:uuid="ca6109c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="985" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186468756_491419_483532" xmi:uuid="9a3fa2d0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
      <ownedElement xmi:id="9a005f60-915f-013c-7167-0a5172f4a469" xmi:uuid="9a006080-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
        <text>InterfaceConnectorView</text>
      </ownedElement>
      <ownedElement xmi:id="ca971400-6c76-013d-d644-0800270c66d6" xmi:uuid="ca9714b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="395" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186469573_910523_483596" xmi:uuid="9a537ad0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586343911301_668423_78254"/>
      <ownedElement xmi:id="9a43b220-915f-013c-7167-0a5172f4a469" xmi:uuid="9a43b350-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586343911301_668423_78254"/>
        <text>InterfaceConnectorViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cacc5100-6c76-013d-d644-0800270c66d6" xmi:uuid="cacc51b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="395" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186471083_915459_483661" xmi:uuid="9aa1fe80-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134027947_222114_38880"/>
      <ownedElement xmi:id="9a5793d0-915f-013c-7167-0a5172f4a469" xmi:uuid="9a579550-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134027947_222114_38880"/>
        <text>InterfaceDefinitionConnection</text>
      </ownedElement>
      <ownedElement xmi:id="cadc5f50-6c76-013d-d644-0800270c66d6" xmi:uuid="cadc5ff0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="507" y="395" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186473412_898209_483729" xmi:uuid="9af821a0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134059448_942822_38888"/>
      <ownedElement xmi:id="9aa5ecb0-915f-013c-7167-0a5172f4a469" xmi:uuid="9aa5ee60-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134059448_942822_38888"/>
        <text>InterfaceSpecification</text>
      </ownedElement>
      <ownedElement xmi:id="cb1ebb30-6c76-013d-d644-0800270c66d6" xmi:uuid="cb1ebbe0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="728" y="395" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186475637_436125_483802" xmi:uuid="9b3b8b00-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134081745_171261_38892"/>
      <ownedElement xmi:id="9afc1c40-915f-013c-7167-0a5172f4a469" xmi:uuid="9afc1d70-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134081745_171261_38892"/>
        <text>InterfaceSpecificationVersion</text>
      </ownedElement>
      <ownedElement xmi:id="cb64dc00-6c76-013d-d644-0800270c66d6" xmi:uuid="cb64dce0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="949" y="395" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186477796_846709_483874" xmi:uuid="9b7ac910-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
      <ownedElement xmi:id="9b3f6350-915f-013c-7167-0a5172f4a469" xmi:uuid="9b3f6470-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
        <text>InterfaceSpecificationView</text>
      </ownedElement>
      <ownedElement xmi:id="cb99a780-6c76-013d-d644-0800270c66d6" xmi:uuid="cb99a820-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="445" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186478602_187699_483938" xmi:uuid="9b8edac0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586340770059_699987_67672"/>
      <ownedElement xmi:id="9b7eaba0-915f-013c-7167-0a5172f4a469" xmi:uuid="9b7eae20-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586340770059_699987_67672"/>
        <text>InterfaceSpecificationViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cbd301b0-6c76-013d-d644-0800270c66d6" xmi:uuid="cbd302c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="445" width="214" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186480289_344876_484002" xmi:uuid="9bcdd2f0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832794448_726739_56316"/>
      <ownedElement xmi:id="9b9743e0-915f-013c-7167-0a5172f4a469" xmi:uuid="9b974510-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832794448_726739_56316"/>
        <text>ManagedResource</text>
      </ownedElement>
      <ownedElement xmi:id="cbee7ab0-6c76-013d-d644-0800270c66d6" xmi:uuid="cbee7b80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="520" y="445" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186480897_54195_484051" xmi:uuid="9bd9a570-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625041013271_622061_69733"/>
      <ownedElement xmi:id="9bd25550-915f-013c-7167-0a5172f4a469" xmi:uuid="9bd25670-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625041013271_622061_69733"/>
        <text>ObservationAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="cc23e6f0-6c76-013d-d644-0800270c66d6" xmi:uuid="cc23f130-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="752" y="445" width="218" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186482793_743500_484118" xmi:uuid="9c8d1ba0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
      <ownedElement xmi:id="9be0f7c0-915f-013c-7167-0a5172f4a469" xmi:uuid="9be0f8f0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
        <text>Organization</text>
      </ownedElement>
      <ownedElement xmi:id="cc34bd00-6c76-013d-d644-0800270c66d6" xmi:uuid="cc34bf50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="990" y="445" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186485463_913059_484193" xmi:uuid="9d36e920-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
      <ownedElement xmi:id="9c9d9430-915f-013c-7167-0a5172f4a469" xmi:uuid="9c9d9560-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
        <text>Part</text>
      </ownedElement>
      <ownedElement xmi:id="cce74a00-6c76-013d-d644-0800270c66d6" xmi:uuid="cce74aa0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186488008_68535_484268" xmi:uuid="9da3d580-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
      <ownedElement xmi:id="9d3c58a0-915f-013c-7167-0a5172f4a469" xmi:uuid="9d3c59c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
        <text>PartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="cd770890-6c76-013d-d644-0800270c66d6" xmi:uuid="cd770950-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="367" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186490477_3797_484345" xmi:uuid="9e14fff0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="9da94380-915f-013c-7167-0a5172f4a469" xmi:uuid="9da944b0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="cdd088c0-6c76-013d-d644-0800270c66d6" xmi:uuid="cdd08970-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="669" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186491367_63320_484411" xmi:uuid="9e35ef20-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
      <ownedElement xmi:id="9e1a8a30-915f-013c-7167-0a5172f4a469" xmi:uuid="9e1a8ca0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
        <text>PartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="ce2bc4a0-6c76-013d-d644-0800270c66d6" xmi:uuid="ce2bc540-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="971" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186493246_294713_484474" xmi:uuid="9ece34e0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
      <ownedElement xmi:id="9e3d4f00-915f-013c-7167-0a5172f4a469" xmi:uuid="9e3d52e0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
        <text>Person</text>
      </ownedElement>
      <ownedElement xmi:id="ce4ad400-6c76-013d-d644-0800270c66d6" xmi:uuid="ce4ad4b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="545" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186495606_521584_484564" xmi:uuid="9f85f9b0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
      <ownedElement xmi:id="9ed587a0-915f-013c-7167-0a5172f4a469" xmi:uuid="9ed588e0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
        <text>PersonInOrganization</text>
      </ownedElement>
      <ownedElement xmi:id="cec7e900-6c76-013d-d644-0800270c66d6" xmi:uuid="cec7e9b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="360" y="545" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186497431_650975_484629" xmi:uuid="9fcd9d40-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642443739607_782068_67427"/>
      <ownedElement xmi:id="9f900860-915f-013c-7167-0a5172f4a469" xmi:uuid="9f900c00-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642443739607_782068_67427"/>
        <text>Position</text>
      </ownedElement>
      <ownedElement xmi:id="cf68a6e0-6c76-013d-d644-0800270c66d6" xmi:uuid="cf68a7a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="655" y="545" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186498835_203029_484691" xmi:uuid="a007b710-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642443886020_132400_67489"/>
      <ownedElement xmi:id="9fd12010-915f-013c-7167-0a5172f4a469" xmi:uuid="9fd12140-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642443886020_132400_67489"/>
        <text>PositionGroup</text>
      </ownedElement>
      <ownedElement xmi:id="cf9d2180-6c76-013d-d644-0800270c66d6" xmi:uuid="cf9d2220-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="921" y="545" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186501420_512380_484760" xmi:uuid="a0524950-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConfiguration"/>
      <ownedElement xmi:id="a010ac30-915f-013c-7167-0a5172f4a469" xmi:uuid="a010ad90-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConfiguration"/>
        <text>ProductConfiguration</text>
      </ownedElement>
      <ownedElement xmi:id="cfd82be0-6c76-013d-d644-0800270c66d6" xmi:uuid="cfd82c90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="595" width="340" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186503070_295110_484835" xmi:uuid="a0f3b950-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639072510862_608091_65724"/>
      <ownedElement xmi:id="a057df90-915f-013c-7167-0a5172f4a469" xmi:uuid="a057e0a0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639072510862_608091_65724"/>
        <text>ProductGroup</text>
      </ownedElement>
      <ownedElement xmi:id="d018fe60-6c76-013d-d644-0800270c66d6" xmi:uuid="d018ffb0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="425" y="595" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186503665_299369_484894" xmi:uuid="a1259b40-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639073584258_168482_66595"/>
      <ownedElement xmi:id="a0f91f60-915f-013c-7167-0a5172f4a469" xmi:uuid="a0f92080-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639073584258_168482_66595"/>
        <text>ProductGroupMembership</text>
      </ownedElement>
      <ownedElement xmi:id="d0a56100-6c76-013d-d644-0800270c66d6" xmi:uuid="d0a561d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="727" y="595" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186505544_822190_484964" xmi:uuid="a1ea11b0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Project"/>
      <ownedElement xmi:id="a12d0990-915f-013c-7167-0a5172f4a469" xmi:uuid="a12d0ab0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Project"/>
        <text>Project</text>
      </ownedElement>
      <ownedElement xmi:id="d0e1fb50-6c76-013d-d644-0800270c66d6" xmi:uuid="d0e1fc50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="645" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186507898_262931_485033" xmi:uuid="a2349ed0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
      <ownedElement xmi:id="a1f2fcb0-915f-013c-7167-0a5172f4a469" xmi:uuid="a1f2fdd0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
        <text>Requirement</text>
      </ownedElement>
      <ownedElement xmi:id="d18cfeb0-6c76-013d-d644-0800270c66d6" xmi:uuid="d18cff60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="360" y="645" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186510237_136337_485107" xmi:uuid="a26b90e0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
      <ownedElement xmi:id="a237cfe0-915f-013c-7167-0a5172f4a469" xmi:uuid="a237d100-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
        <text>RequirementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d1c4fa60-6c76-013d-d644-0800270c66d6" xmi:uuid="d1c4fb00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="663" y="645" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186512916_624330_485186" xmi:uuid="a2acf4f0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
      <ownedElement xmi:id="a26eb790-915f-013c-7167-0a5172f4a469" xmi:uuid="a26eb8f0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
        <text>RequirementView</text>
      </ownedElement>
      <ownedElement xmi:id="d1f14400-6c76-013d-d644-0800270c66d6" xmi:uuid="d1f144b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="966" y="645" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186513889_628708_485252" xmi:uuid="a2bf0c40-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementViewRelationship"/>
      <ownedElement xmi:id="a2b034b0-915f-013c-7167-0a5172f4a469" xmi:uuid="a2b035f0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementViewRelationship"/>
        <text>RequirementViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d2266580-6c76-013d-d644-0800270c66d6" xmi:uuid="d2266630-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="695" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186515746_874940_485324" xmi:uuid="a2f4f1c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832142352_199733_56200"/>
      <ownedElement xmi:id="a2c25920-915f-013c-7167-0a5172f4a469" xmi:uuid="a2c25a50-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832142352_199733_56200"/>
        <text>ResourceEvent</text>
      </ownedElement>
      <ownedElement xmi:id="d2351370-6c76-013d-d644-0800270c66d6" xmi:uuid="d2351420-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="368" y="695" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186517174_163010_485384" xmi:uuid="a3289690-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
      <ownedElement xmi:id="a2f82530-915f-013c-7167-0a5172f4a469" xmi:uuid="a2f82660-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
        <text>ResourceItem</text>
      </ownedElement>
      <ownedElement xmi:id="d2603d70-6c76-013d-d644-0800270c66d6" xmi:uuid="d2603f50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="600" y="695" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186519514_73315_485453" xmi:uuid="a35ca420-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
      <ownedElement xmi:id="a32f03a0-915f-013c-7167-0a5172f4a469" xmi:uuid="a32f04c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
        <text>Risk</text>
      </ownedElement>
      <ownedElement xmi:id="d2921ae0-6c76-013d-d644-0800270c66d6" xmi:uuid="d2921b80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="832" y="695" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186521794_930324_485527" xmi:uuid="a3803f10-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
      <ownedElement xmi:id="a35f2920-915f-013c-7167-0a5172f4a469" xmi:uuid="a35f2a60-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
        <text>RiskVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d2b615f0-6c76-013d-d644-0800270c66d6" xmi:uuid="d2b61690-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="745" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186524028_106072_485600" xmi:uuid="a3a1fd10-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_912952_62430"/>
      <ownedElement xmi:id="a3829980-915f-013c-7167-0a5172f4a469" xmi:uuid="a3829ab0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_912952_62430"/>
        <text>RiskView</text>
      </ownedElement>
      <ownedElement xmi:id="d2d44db0-6c76-013d-d644-0800270c66d6" xmi:uuid="d2d44e70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="265" y="745" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186526367_892339_485669" xmi:uuid="a3cb7580-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
      <ownedElement xmi:id="a3a45670-915f-013c-7167-0a5172f4a469" xmi:uuid="a3a45790-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
        <text>Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="d2f05190-6c76-013d-d644-0800270c66d6" xmi:uuid="d2f05240-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="465" y="745" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186528318_453366_485736" xmi:uuid="a3f1b0c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
      <ownedElement xmi:id="a3cdae70-915f-013c-7167-0a5172f4a469" xmi:uuid="a3cdaf90-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
        <text>SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="d31bdd80-6c76-013d-d644-0800270c66d6" xmi:uuid="d31bde30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="737" y="745" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186530629_988830_485821" xmi:uuid="a41aea60-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
      <ownedElement xmi:id="a3f3e830-915f-013c-7167-0a5172f4a469" xmi:uuid="a3f3e960-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
        <text>SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d34063a0-6c76-013d-d644-0800270c66d6" xmi:uuid="d3406450-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="795" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186532981_564854_485889" xmi:uuid="a451ca60-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
      <ownedElement xmi:id="a42259c0-915f-013c-7167-0a5172f4a469" xmi:uuid="a4225ae0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
        <text>Slot</text>
      </ownedElement>
      <ownedElement xmi:id="d3737550-6c76-013d-d644-0800270c66d6" xmi:uuid="d3737600-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="337" y="795" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186535751_455083_485957" xmi:uuid="a4838140-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
      <ownedElement xmi:id="a4546230-915f-013c-7167-0a5172f4a469" xmi:uuid="a4546350-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
        <text>SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="d39d43f0-6c76-013d-d644-0800270c66d6" xmi:uuid="d39d44b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="533" y="795" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186536571_628427_486022" xmi:uuid="a48f8c20-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214197111_257229_69320"/>
      <ownedElement xmi:id="a4863d60-915f-013c-7167-0a5172f4a469" xmi:uuid="a4863e90-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214197111_257229_69320"/>
        <text>SlotDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d3c7d5f0-6c76-013d-d644-0800270c66d6" xmi:uuid="d3c7d6a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="729" y="795" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186538828_375596_486107" xmi:uuid="a4b56ed0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
      <ownedElement xmi:id="a4921f30-915f-013c-7167-0a5172f4a469" xmi:uuid="a4922060-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
        <text>SlotVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d3d2ddd0-6c76-013d-d644-0800270c66d6" xmi:uuid="d3d2de80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="925" y="795" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186541175_385652_486175" xmi:uuid="a4d13c80-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_392073_63003"/>
      <ownedElement xmi:id="a4ba2940-915f-013c-7167-0a5172f4a469" xmi:uuid="a4ba2a60-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_392073_63003"/>
        <text>System</text>
      </ownedElement>
      <ownedElement xmi:id="d3fdcce0-6c76-013d-d644-0800270c66d6" xmi:uuid="d3fdcdc0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="845" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186543409_490292_486248" xmi:uuid="a4e4f800-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_348435_63004"/>
      <ownedElement xmi:id="a4d30170-915f-013c-7167-0a5172f4a469" xmi:uuid="a4d30290-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_348435_63004"/>
        <text>SystemVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d4168e00-6c76-013d-d644-0800270c66d6" xmi:uuid="d4168eb0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="280" y="845" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186546188_157255_486329" xmi:uuid="a4f8a990-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199044_378163_63005"/>
      <ownedElement xmi:id="a4e6bb90-915f-013c-7167-0a5172f4a469" xmi:uuid="a4e6bcb0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199044_378163_63005"/>
        <text>SystemView</text>
      </ownedElement>
      <ownedElement xmi:id="d42a2f30-6c76-013d-d644-0800270c66d6" xmi:uuid="d42a3120-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="495" y="845" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186546998_824610_486394" xmi:uuid="a4ff93b0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_6b1022a_1639047670600_911347_65028"/>
      <ownedElement xmi:id="a4fa6d20-915f-013c-7167-0a5172f4a469" xmi:uuid="a4fa6e60-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_6b1022a_1639047670600_911347_65028"/>
        <text>SystemViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d44235b0-6c76-013d-d644-0800270c66d6" xmi:uuid="d4423660-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="710" y="845" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186548930_166605_486461" xmi:uuid="a5519c90-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
      <ownedElement xmi:id="a5037680-915f-013c-7167-0a5172f4a469" xmi:uuid="a5037790-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
        <text>TaskElement</text>
      </ownedElement>
      <ownedElement xmi:id="d44e6070-6c76-013d-d644-0800270c66d6" xmi:uuid="d44e6110-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="925" y="845" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186551640_138768_486531" xmi:uuid="a5adcbb0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
      <ownedElement xmi:id="a5558550-915f-013c-7167-0a5172f4a469" xmi:uuid="a5558680-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
        <text>TaskMethod</text>
      </ownedElement>
      <ownedElement xmi:id="d4aacde0-6c76-013d-d644-0800270c66d6" xmi:uuid="d4aace90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="895" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703186554279_866056_486622" xmi:uuid="a60832c0-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
      <ownedElement xmi:id="a5b1c280-915f-013c-7167-0a5172f4a469" xmi:uuid="a5b1c780-915f-013c-7167-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
        <text>TaskMethodVersion</text>
      </ownedElement>
      <ownedElement xmi:id="d507b6f0-6c76-013d-d644-0800270c66d6" xmi:uuid="d507b790-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="323" y="895" width="238" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1320" height="975"/>
    <name>WorkRequestAssignmentSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_271a0567_1577965270200_255077_60378" xmi:uuid="9112bb90-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkRequestRelationship"/>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965590383_224059_61547" xmi:uuid="9113c4f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965590363_776318_61543"/>
      <bounds x="1137" y="445" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965282210_133184_60414" xmi:uuid="91142ff0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-Related"/>
      <ownedElement xmi:id="b2982320-7cb5-0138-411c-418b172fba9f" xmi:uuid="b29824f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-Related"/>
        <text>Related:WorkRequest</text>
      </ownedElement>
      <ownedElement xmi:id="b299c220-7cb5-0138-411c-418b172fba9f" xmi:uuid="b299c260-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-Related"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577965509311_768056_61384" xmi:uuid="9113e720-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956874270_39656_56914"/>
        <ownedElement xmi:id="d568e4e0-6c76-013d-d644-0800270c66d6" xmi:uuid="d568e5e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956874270_39656_56914"/>
          <bounds x="213" y="654" width="159" height="13"/>
          <text>workRequest : Work_request [1]</text>
        </ownedElement>
        <bounds x="195" y="663" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="658" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965282220_258054_60445" xmi:uuid="91152b60-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-Relating"/>
      <ownedElement xmi:id="b29d1610-7cb5-0138-411c-418b172fba9f" xmi:uuid="b29d1670-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-Relating"/>
        <text>Relating:WorkRequest</text>
      </ownedElement>
      <ownedElement xmi:id="b29eadd0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b29eae40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestRelationship-Relating"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577965496881_780014_61370" xmi:uuid="91144330-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956874270_39656_56914"/>
        <ownedElement xmi:id="d570c210-6c76-013d-d644-0800270c66d6" xmi:uuid="d570c2c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956874270_39656_56914"/>
          <bounds x="213" y="599" width="159" height="13"/>
          <text>workRequest : Work_request [1]</text>
        </ownedElement>
        <bounds x="195" y="608" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="602" width="168" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965317626_329800_60494" xmi:uuid="911547b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965317609_474895_60490"/>
      <ownedElement xmi:id="b2cdc8c0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b2cdc940-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965317609_474895_60490"/>
        <text>work_request_relationship:Work_request_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="b2cf8f20-7cb5-0138-411c-418b172fba9f" xmi:uuid="b2cf8f70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965317609_474895_60490"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="d5b4f5b0-6c76-013d-d644-0800270c66d6" xmi:uuid="d5b4f6a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d5b5ec00-6c76-013d-d644-0800270c66d6" xmi:uuid="d5b5ece0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965317626_389323_60495" xmi:uuid="b2f35ce0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-description"/>
          <ownedElement xmi:id="b2e1bc30-7cb5-0138-411c-418b172fba9f" xmi:uuid="b2e1bca0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="b2f2d100-7cb5-0138-411c-418b172fba9f" xmi:uuid="b2f2d180-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="805" y="539" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965317626_812124_60496" xmi:uuid="b32463f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-related"/>
          <ownedElement xmi:id="b3131f70-7cb5-0138-411c-418b172fba9f" xmi:uuid="b3131ff0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-related"/>
            <text>related:Work_request</text>
          </ownedElement>
          <ownedElement xmi:id="b323deb0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b323df30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-related"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="602" width="157" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965317626_569232_60497" xmi:uuid="b3564850-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-relating"/>
          <ownedElement xmi:id="b344c150-7cb5-0138-411c-418b172fba9f" xmi:uuid="b344c1d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-relating"/>
            <text>relating:Work_request</text>
          </ownedElement>
          <ownedElement xmi:id="b355bb20-7cb5-0138-411c-418b172fba9f" xmi:uuid="b355bb90-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-relating"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="658" width="160" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965317626_845984_60498" xmi:uuid="b3791650-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-relation_type"/>
          <ownedElement xmi:id="b3679c20-7cb5-0138-411c-418b172fba9f" xmi:uuid="b3679ca0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="b3788e30-7cb5-0138-411c-418b172fba9f" xmi:uuid="b3788eb0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request_relationship-relation_type"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="805" y="714" width="144" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="784" y="504" width="341" height="259"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_690549_60677" xmi:uuid="91154c10-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="539" y="21" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965676610_918598_61691" xmi:uuid="bfab30a0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965678635_687513_61692"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_329800_60494"/>
      <target xmi:idref="_18_4_1_271a0567_1577965359940_558362_60685"/>
      <waypoint x="840" y="504"/>
      <waypoint x="840" y="109"/>
      <waypoint x="639" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_870078_60678" xmi:uuid="91155700-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="b3b17690-7cb5-0138-411c-418b172fba9f" xmi:uuid="b3b17710-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b3c03cc0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b3c03d30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="d70a7da0-6c76-013d-d644-0800270c66d6" xmi:uuid="d70a7e50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d70b4c70-6c76-013d-d644-0800270c66d6" xmi:uuid="d70b4d50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_558362_60685" xmi:uuid="b3f22780-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b3e0fb20-7cb5-0138-411c-418b172fba9f" xmi:uuid="b3e0fba0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b3f1ad60-7cb5-0138-411c-418b172fba9f" xmi:uuid="b3f1add0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="455" y="98" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="70" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965644763_883520_61626" xmi:uuid="c007aa20-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965646520_481934_61627"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_329800_60494"/>
      <target xmi:idref="_18_4_1_271a0567_1577965359940_925617_60686"/>
      <waypoint x="840" y="504"/>
      <waypoint x="840" y="410"/>
      <waypoint x="630" y="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_360669_60679" xmi:uuid="91156780-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="b410cd40-7cb5-0138-411c-418b172fba9f" xmi:uuid="b410cdc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b41fcd10-7cb5-0138-411c-418b172fba9f" xmi:uuid="b41fcd80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="d76704a0-6c76-013d-d644-0800270c66d6" xmi:uuid="d7670660-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d768d330-6c76-013d-d644-0800270c66d6" xmi:uuid="d768d4e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_925617_60686" xmi:uuid="b4536080-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="b441ee40-7cb5-0138-411c-418b172fba9f" xmi:uuid="b441eec0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="b452e030-7cb5-0138-411c-418b172fba9f" xmi:uuid="b452e0b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="455" y="399" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="371" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965638708_303731_61607" xmi:uuid="c067b290-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965641063_437706_61608"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_329800_60494"/>
      <target xmi:idref="_18_4_1_271a0567_1577965359940_123520_60687"/>
      <waypoint x="840" y="504"/>
      <waypoint x="840" y="487"/>
      <waypoint x="683" y="487"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_186351_60680" xmi:uuid="911573d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="b4718380-7cb5-0138-411c-418b172fba9f" xmi:uuid="b47183f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="b4804820-7cb5-0138-411c-418b172fba9f" xmi:uuid="b48048a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d7bdd840-6c76-013d-d644-0800270c66d6" xmi:uuid="d7bdd900-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d7bea6e0-6c76-013d-d644-0800270c66d6" xmi:uuid="d7bea7c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_123520_60687" xmi:uuid="b4b27600-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="b4a13a30-7cb5-0138-411c-418b172fba9f" xmi:uuid="b4a13aa0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="b4b1f4d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b4b1f550-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="455" y="476" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="448" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_201170_60681" xmi:uuid="91159710-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="b4cfffc0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b4d00050-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577965359941_815704_60688" xmi:uuid="91157f30-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="d8068dc0-6c76-013d-d644-0800270c66d6" xmi:uuid="d8068e60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="420" y="534" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="402" y="543" width="15" height="15"/>
      </ownedElement>
      <bounds x="168" y="532" width="249" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965662663_769368_61653" xmi:uuid="c0f29bb0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965665370_366440_61654"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_329800_60494"/>
      <target xmi:idref="_18_4_1_271a0567_1577965359941_461636_60690"/>
      <waypoint x="840" y="504"/>
      <waypoint x="840" y="333"/>
      <waypoint x="638" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_311900_60682" xmi:uuid="9115a9c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="b4fd7230-7cb5-0138-411c-418b172fba9f" xmi:uuid="b4fd72c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b50c2bf0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b50c2c70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="d823ff00-6c76-013d-d644-0800270c66d6" xmi:uuid="d8240050-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d824d290-6c76-013d-d644-0800270c66d6" xmi:uuid="d824d360-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965359941_461636_60690" xmi:uuid="b53e6a40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="b52d2450-7cb5-0138-411c-418b172fba9f" xmi:uuid="b52d24d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b53dec90-7cb5-0138-411c-418b172fba9f" xmi:uuid="b53ded10-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="455" y="322" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="294" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965631112_736488_61588" xmi:uuid="c1501cb0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965633078_947038_61589"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_329800_60494"/>
      <target xmi:idref="_18_4_1_271a0567_1577965359941_734054_60691"/>
      <waypoint x="844" y="763"/>
      <waypoint x="844" y="809"/>
      <waypoint x="639" y="809"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_409141_60683" xmi:uuid="9115b760-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="b55d2ac0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b55d2b50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b56bfef0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b56bff60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d8616700-6c76-013d-d644-0800270c66d6" xmi:uuid="d86167b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d8624310-6c76-013d-d644-0800270c66d6" xmi:uuid="d86243e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965359941_734054_60691" xmi:uuid="b59e6a70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b58cff80-7cb5-0138-411c-418b172fba9f" xmi:uuid="b58d0020-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b59ded70-7cb5-0138-411c-418b172fba9f" xmi:uuid="b59dedf0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="455" y="798" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="770" width="256" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965359940_408222_60684" xmi:uuid="9115e680-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="b5bbbf40-7cb5-0138-411c-418b172fba9f" xmi:uuid="b5bbbfd0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577965359941_636289_60692" xmi:uuid="9115c8e0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="d8a469e0-6c76-013d-d644-0800270c66d6" xmi:uuid="d8a46a90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="368" y="712" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="350" y="721" width="15" height="15"/>
      </ownedElement>
      <bounds x="175" y="700" width="190" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965670098_18780_61672" xmi:uuid="c2043940-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965672313_179788_61673"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_329800_60494"/>
      <target xmi:idref="_18_4_1_271a0567_1577965379536_310863_61096"/>
      <waypoint x="840" y="504"/>
      <waypoint x="840" y="221"/>
      <waypoint x="638" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965379536_571904_61093" xmi:uuid="9115feb0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965379518_885494_61077"/>
      <ownedElement xmi:id="b5dbaae0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b5dbab60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965379518_885494_61077"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b5dd8410-7cb5-0138-411c-418b172fba9f" xmi:uuid="b5dd8460-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965379518_885494_61077"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d8b4d3d0-6c76-013d-d644-0800270c66d6" xmi:uuid="d8b4d480-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d8b5a270-6c76-013d-d644-0800270c66d6" xmi:uuid="d8b5ef90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965379536_177234_61095" xmi:uuid="b6078020-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="b5f240f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b5f24170-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="b606cc80-7cb5-0138-411c-418b172fba9f" xmi:uuid="b606cd00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="455" y="175" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965379536_310863_61096" xmi:uuid="b6442df0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="b62ec4b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b62ec530-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b6439020-7cb5-0138-411c-418b172fba9f" xmi:uuid="b64390b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="455" y="210" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577965379537_494077_61097" xmi:uuid="b66de8c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="b658a870-7cb5-0138-411c-418b172fba9f" xmi:uuid="b658a900-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="b66d4540-7cb5-0138-411c-418b172fba9f" xmi:uuid="b66d4780-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="455" y="245" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="441" y="147" width="308" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965379536_225800_61094" xmi:uuid="9116b140-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965379520_698321_61078"/>
      <ownedElement xmi:id="b6703980-7cb5-0138-411c-418b172fba9f" xmi:uuid="b6703a00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965379520_698321_61078"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="b6720f90-7cb5-0138-411c-418b172fba9f" xmi:uuid="b6720fe0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965379520_698321_61078"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="231" y="245" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965379537_242941_61098" xmi:uuid="9116ba00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965379522_653843_61082"/>
      <source xmi:idref="_18_4_1_271a0567_1577965379537_494077_61097"/>
      <target xmi:idref="_18_4_1_271a0567_1577965379536_225800_61094"/>
      <waypoint x="455" y="256"/>
      <waypoint x="365" y="256"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965408180_406148_61258" xmi:uuid="9116e050-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="b68f6860-7cb5-0138-411c-418b172fba9f" xmi:uuid="b68f68e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577965408180_427926_61259" xmi:uuid="9116c8b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="d92bf980-6c76-013d-d644-0800270c66d6" xmi:uuid="d92bfa20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="356" y="171" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="338" y="180" width="15" height="15"/>
      </ownedElement>
      <bounds x="182" y="168" width="171" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965439008_712623_61321" xmi:uuid="9116fa70-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965440418_24158_61322"/>
      <source xmi:idref="_18_4_1_271a0567_1577965379536_177234_61095"/>
      <target xmi:idref="_18_4_1_271a0567_1577965408180_427926_61259"/>
      <waypoint x="455" y="186"/>
      <waypoint x="353" y="186"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965467955_841237_61353" xmi:uuid="91170340-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965470206_431856_61354"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_389323_60495"/>
      <target xmi:idref="_18_4_1_271a0567_1577965359941_815704_60688"/>
      <waypoint x="805" y="550"/>
      <waypoint x="417" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965534668_63673_61467" xmi:uuid="911719c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965536619_928434_61468"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_812124_60496"/>
      <target xmi:idref="_18_4_1_271a0567_1577965496881_780014_61370"/>
      <waypoint x="805" y="616"/>
      <waypoint x="210" y="616"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965541251_205215_61489" xmi:uuid="911720a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965546482_823058_61490"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_569232_60497"/>
      <target xmi:idref="_18_4_1_271a0567_1577965509311_768056_61384"/>
      <waypoint x="805" y="669"/>
      <waypoint x="210" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965563672_330394_61515" xmi:uuid="911726e0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965565638_455354_61516"/>
      <source xmi:idref="_18_4_1_271a0567_1583168787520_668528_88439"/>
      <target xmi:idref="_18_4_1_271a0567_1577965359941_636289_60692"/>
      <waypoint x="490" y="728"/>
      <waypoint x="365" y="728"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965624497_577905_61572" xmi:uuid="91172d30-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965627236_139071_61573"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_329800_60494"/>
      <target xmi:idref="_18_4_1_271a0567_1577965590383_224059_61547"/>
      <waypoint x="1050" y="504"/>
      <waypoint x="1050" y="452"/>
      <waypoint x="1137" y="452"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1583168787520_458270_88438" xmi:uuid="b6b122f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1583168787513_807472_88436"/>
      <ownedElement xmi:id="b6aece20-7cb5-0138-411c-418b172fba9f" xmi:uuid="b6aecea0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1583168787513_807472_88436"/>
        <text>defaultType:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1583168787520_668528_88439" xmi:uuid="b6b09bc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="d9426740-6c76-013d-d644-0800270c66d6" xmi:uuid="d94267f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="434" y="734" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="490" y="719" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1583168787520_237551_88441" xmi:uuid="b6b11c50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="d94daa20-6c76-013d-d644-0800270c66d6" xmi:uuid="d94daac0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="681" y="708" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="663" y="717" width="15" height="15"/>
      </ownedElement>
      <bounds x="490" y="707" width="188" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1583168808990_369229_88491" xmi:uuid="b6b12dd0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1583168810091_890435_88492"/>
      <source xmi:idref="_18_4_1_271a0567_1577965317626_845984_60498"/>
      <target xmi:idref="_18_4_1_271a0567_1583168787520_237551_88441"/>
      <waypoint x="805" y="725"/>
      <waypoint x="678" y="725"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1140" height="855"/>
    <name>WorkRequestRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_271a0567_1577962770444_648435_51084" xmi:uuid="91188940-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkOrderAssignment"/>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963656201_393237_56810" xmi:uuid="911a5e10-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963656172_80809_56806"/>
      <bounds x="1274" y="832" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962784347_561996_51121" xmi:uuid="911abfe0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-AssignedTo"/>
      <ownedElement xmi:id="b6ccfe60-7cb5-0138-411c-418b172fba9f" xmi:uuid="b6ccfee0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-AssignedTo"/>
        <text>AssignedTo:WorkOrderAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="b6ceaa60-7cb5-0138-411c-418b172fba9f" xmi:uuid="b6ceaab0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-AssignedTo"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577963076525_289143_51654" xmi:uuid="911a7070-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962989407_4853_51636"/>
        <ownedElement xmi:id="d987c400-6c76-013d-d644-0800270c66d6" xmi:uuid="d987c930-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962989407_4853_51636"/>
          <bounds x="325" y="913" width="151" height="13"/>
          <text>woas : affected_item_select [1]</text>
        </ownedElement>
        <bounds x="307" y="922" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="917" width="280" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962784363_203143_51152" xmi:uuid="911bd020-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-AssignedWorkOrder"/>
      <ownedElement xmi:id="b6d22250-7cb5-0138-411c-418b172fba9f" xmi:uuid="b6d22440-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-AssignedWorkOrder"/>
        <text>AssignedWorkOrder:WorkOrder</text>
      </ownedElement>
      <ownedElement xmi:id="b6d3de20-7cb5-0138-411c-418b172fba9f" xmi:uuid="b6d3de70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderAssignment-AssignedWorkOrder"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577962936468_273919_51622" xmi:uuid="911ad4a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1518011863438_410659_32287"/>
        <ownedElement xmi:id="d98f51a0-6c76-013d-d644-0800270c66d6" xmi:uuid="d98f5260-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1518011863438_410659_32287"/>
          <bounds x="269" y="984" width="136" height="13"/>
          <text>workOrder : Work_order [1]</text>
        </ownedElement>
        <bounds x="251" y="993" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="987" width="224" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962862546_934966_51261" xmi:uuid="c335d0c0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860246_462029_51202"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862544_514796_51254"/>
      <target xmi:idref="_18_4_1_271a0567_1577962862544_429961_51255"/>
      <waypoint x="492" y="1113"/>
      <waypoint x="549" y="1113"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962862547_921180_51262" xmi:uuid="c3369330-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860246_798605_51203"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862543_619276_51252"/>
      <target xmi:idref="_18_4_1_271a0567_1577962862544_996366_51257"/>
      <waypoint x="493" y="1033"/>
      <waypoint x="549" y="1033"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962862547_37131_51263" xmi:uuid="c33767a0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860247_116050_51204"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862543_167161_51253"/>
      <target xmi:idref="_18_4_1_271a0567_1577962862544_102938_51258"/>
      <waypoint x="495" y="1068"/>
      <waypoint x="549" y="1068"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962862543_424368_51250" xmi:uuid="911beeb0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860238_519127_51195"/>
      <ownedElement xmi:id="b6e553b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b6e55430-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860238_519127_51195"/>
        <text>da:Directed_activity</text>
      </ownedElement>
      <ownedElement xmi:id="b6e725a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b6e725f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860238_519127_51195"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="d99f42e0-6c76-013d-d644-0800270c66d6" xmi:uuid="d99f4380-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d9a07780-6c76-013d-d644-0800270c66d6" xmi:uuid="d9a07870-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577962862544_429961_51255" xmi:uuid="b7192530-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
          <ownedElement xmi:id="b707fae0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b707fb60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
            <text>chosen_method:Activity_method</text>
          </ownedElement>
          <ownedElement xmi:id="b718a370-7cb5-0138-411c-418b172fba9f" xmi:uuid="b718a3f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="549" y="1100" width="224" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577962862544_578842_51256" xmi:uuid="b74b9740-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Directed_activity-directive"/>
          <ownedElement xmi:id="b73a2d30-7cb5-0138-411c-418b172fba9f" xmi:uuid="b73a2db0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Directed_activity-directive"/>
            <text>directive:Work_order</text>
          </ownedElement>
          <ownedElement xmi:id="b74b1780-7cb5-0138-411c-418b172fba9f" xmi:uuid="b74b1800-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Directed_activity-directive"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="549" y="988" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577962862544_996366_51257" xmi:uuid="b76d0670-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
          <ownedElement xmi:id="b75c1c90-7cb5-0138-411c-418b172fba9f" xmi:uuid="b75c1d10-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="b76c8300-7cb5-0138-411c-418b172fba9f" xmi:uuid="b76c8380-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="549" y="1023" width="88" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577962862544_102938_51258" xmi:uuid="b78eec30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
          <ownedElement xmi:id="b77ddb70-7cb5-0138-411c-418b172fba9f" xmi:uuid="b77ddbf0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="b78e6440-7cb5-0138-411c-418b172fba9f" xmi:uuid="b78e6580-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="549" y="1058" width="109" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="535" y="952" width="303" height="183"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962862547_269643_51264" xmi:uuid="c3b1d780-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860247_839230_51205"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862543_424368_51250"/>
      <target xmi:idref="_18_4_1_271a0567_1577962862544_139167_51259"/>
      <waypoint x="838" y="971"/>
      <waypoint x="906" y="971"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962862543_654228_51251" xmi:uuid="911c0170-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860241_42521_51196"/>
      <ownedElement xmi:id="b7a2a1b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b7a2a230-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860241_42521_51196"/>
        <text>work_order_assignment:Directed_activity_items_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b7a474a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b7a474f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860241_42521_51196"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="da28d1e0-6c76-013d-d644-0800270c66d6" xmi:uuid="da28d2c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="da29c980-6c76-013d-d644-0800270c66d6" xmi:uuid="da29ca60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577962862544_139167_51259" xmi:uuid="b7d85980-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Directed_activity_items_assignment-assigned_directed_activity"/>
          <ownedElement xmi:id="b7c5f610-7cb5-0138-411c-418b172fba9f" xmi:uuid="b7c5f690-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Directed_activity_items_assignment-assigned_directed_activity"/>
            <text>assigned_directed_activity:Directed_activity</text>
          </ownedElement>
          <ownedElement xmi:id="b7d7d8e0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b7d7d960-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Directed_activity_items_assignment-assigned_directed_activity"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="906" y="961" width="276" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577962862544_100138_51260" xmi:uuid="b80a1d40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Directed_activity_items_assignment-items"/>
          <ownedElement xmi:id="b7f8b500-7cb5-0138-411c-418b172fba9f" xmi:uuid="b7f8b580-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Directed_activity_items_assignment-items"/>
            <text>items:affected_item_select</text>
          </ownedElement>
          <ownedElement xmi:id="b8099aa0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b8099b20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Directed_activity_items_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="906" y="919" width="197" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="885" y="889" width="377" height="107"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962862543_619276_51252" xmi:uuid="911c0d50-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860242_774733_51197"/>
      <ownedElement xmi:id="b80c3110-7cb5-0138-411c-418b172fba9f" xmi:uuid="b80c3180-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860242_774733_51197"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="b80de490-7cb5-0138-411c-418b172fba9f" xmi:uuid="b80de4d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860242_774733_51197"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="294" y="1015" width="199" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962862543_167161_51253" xmi:uuid="911c18a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860243_662456_51198"/>
      <ownedElement xmi:id="b80fdd20-7cb5-0138-411c-418b172fba9f" xmi:uuid="b80fdd70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860243_662456_51198"/>
        <text>theName:String</text>
      </ownedElement>
      <ownedElement xmi:id="b8119ac0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b8119b10-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860243_662456_51198"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="245" y="1050" width="250" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577962862544_514796_51254" xmi:uuid="911c23a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860244_729796_51199"/>
      <ownedElement xmi:id="b822cf00-7cb5-0138-411c-418b172fba9f" xmi:uuid="b822d030-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860244_729796_51199"/>
        <text>dummyMethod:Activity_method</text>
      </ownedElement>
      <ownedElement xmi:id="b8249380-7cb5-0138-411c-418b172fba9f" xmi:uuid="b82493c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860244_729796_51199"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="280" y="1092" width="212" height="73"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963729837_640207_56851" xmi:uuid="c45baa70-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963732395_723525_56852"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862543_654228_51251"/>
      <target xmi:idref="_18_4_1_271a0567_1577963218082_616217_53972"/>
      <waypoint x="921" y="889"/>
      <waypoint x="921" y="165"/>
      <waypoint x="736" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_611975_53960" xmi:uuid="911c3220-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215633_924265_53920"/>
      <ownedElement xmi:id="b835caf0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b835cb60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215633_924265_53920"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b8379bb0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b8379c00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215633_924265_53920"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="da957b60-6c76-013d-d644-0800270c66d6" xmi:uuid="da957c20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="da967df0-6c76-013d-d644-0800270c66d6" xmi:uuid="da967ed0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_306720_53971" xmi:uuid="b85adf30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="b8498cd0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b8498d60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="b85a5f80-7cb5-0138-411c-418b172fba9f" xmi:uuid="b85a5ff0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="553" y="119" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_616217_53972" xmi:uuid="b88c3280-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="b87b05b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b87b0620-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b88bb620-7cb5-0138-411c-418b172fba9f" xmi:uuid="b88bb6a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="553" y="154" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_550419_53973" xmi:uuid="b8ad6220-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="b89c9b90-7cb5-0138-411c-418b172fba9f" xmi:uuid="b89c9cc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="b8ace810-7cb5-0138-411c-418b172fba9f" xmi:uuid="b8ace880-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="553" y="189" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="539" y="91" width="294" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_100535_53961" xmi:uuid="911c3d40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215635_997377_53921"/>
      <ownedElement xmi:id="b8af66b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b8af6710-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215635_997377_53921"/>
        <text>theId1:String</text>
      </ownedElement>
      <ownedElement xmi:id="b8b11b70-7cb5-0138-411c-418b172fba9f" xmi:uuid="b8b11bb0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215635_997377_53921"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="343" y="189" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_551695_53962" xmi:uuid="911c4210-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509987065721_230294_25388"/>
      <bounds x="497" y="28" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963736531_650460_56870" xmi:uuid="c4bfd510-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963738933_225025_56871"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862543_654228_51251"/>
      <target xmi:idref="_18_4_1_271a0567_1577963218082_19398_53974"/>
      <waypoint x="921" y="889"/>
      <waypoint x="921" y="277"/>
      <waypoint x="736" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_878541_53963" xmi:uuid="911c5c40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
      <ownedElement xmi:id="b8ceebc0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b8ceec40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b8ddada0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b8ddae20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="db0659e0-6c76-013d-d644-0800270c66d6" xmi:uuid="db065a80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="db074090-6c76-013d-d644-0800270c66d6" xmi:uuid="db074180-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_19398_53974" xmi:uuid="b90fed80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="b8fe67b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b8fe6820-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b90f6190-7cb5-0138-411c-418b172fba9f" xmi:uuid="b90f6220-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="553" y="266" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="539" y="238" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963742731_809069_56889" xmi:uuid="c51c0f50-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963746310_552369_56890"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862543_654228_51251"/>
      <target xmi:idref="_18_4_1_271a0567_1577963218083_850851_53975"/>
      <waypoint x="921" y="889"/>
      <waypoint x="921" y="354"/>
      <waypoint x="737" y="354"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_12662_53964" xmi:uuid="911c6790-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
      <ownedElement xmi:id="b92e9bc0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b92e9c50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b93db3f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b93db470-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="db48daf0-6c76-013d-d644-0800270c66d6" xmi:uuid="db48dba0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="db49ac80-6c76-013d-d644-0800270c66d6" xmi:uuid="db49ad50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218083_850851_53975" xmi:uuid="b97440e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b9609dd0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b9609e80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b973a860-7cb5-0138-411c-418b172fba9f" xmi:uuid="b973a8f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="553" y="343" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="539" y="315" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963753604_799360_56908" xmi:uuid="c59745e0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963757334_603067_56909"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862543_654228_51251"/>
      <target xmi:idref="_18_4_1_271a0567_1577963218083_921047_53977"/>
      <waypoint x="921" y="889"/>
      <waypoint x="921" y="445"/>
      <waypoint x="728" y="445"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_897292_53965" xmi:uuid="911c7430-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215637_363763_53922"/>
      <ownedElement xmi:id="b98727d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b9872850-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215637_363763_53922"/>
        <text>smplDescAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b988ec50-7cb5-0138-411c-418b172fba9f" xmi:uuid="b988eca0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215637_363763_53922"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="db753720-6c76-013d-d644-0800270c66d6" xmi:uuid="db7537d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="db761900-6c76-013d-d644-0800270c66d6" xmi:uuid="db761b60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218083_80869_53976" xmi:uuid="b9bb68e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="b9a9d1d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b9a9d280-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="b9bacf20-7cb5-0138-411c-418b172fba9f" xmi:uuid="b9bacfc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="553" y="469" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218083_921047_53977" xmi:uuid="b9ebe700-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="b9dadde0-7cb5-0138-411c-418b172fba9f" xmi:uuid="b9dade60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="b9eb6840-7cb5-0138-411c-418b172fba9f" xmi:uuid="b9eb68c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="553" y="434" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="539" y="406" width="287" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_319092_53966" xmi:uuid="911c7e40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
      <ownedElement xmi:id="ba0a3b20-7cb5-0138-411c-418b172fba9f" xmi:uuid="ba0a3ba0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="ba18f730-7cb5-0138-411c-418b172fba9f" xmi:uuid="ba18f7b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="dbd07380-6c76-013d-d644-0800270c66d6" xmi:uuid="dbd07420-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dbd16640-6c76-013d-d644-0800270c66d6" xmi:uuid="dbd16710-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218083_450586_53978" xmi:uuid="ba4bacb0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="ba39eec0-7cb5-0138-411c-418b172fba9f" xmi:uuid="ba39ef40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="ba4b2680-7cb5-0138-411c-418b172fba9f" xmi:uuid="ba4b2700-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="273" y="406" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="259" y="378" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_342452_53967" xmi:uuid="911c89f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215638_194780_53923"/>
      <ownedElement xmi:id="ba5ca420-7cb5-0138-411c-418b172fba9f" xmi:uuid="ba5ca4a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215638_194780_53923"/>
        <text>descText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="ba5e6190-7cb5-0138-411c-418b172fba9f" xmi:uuid="ba5e61e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215638_194780_53923"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="dbfd4f50-6c76-013d-d644-0800270c66d6" xmi:uuid="dbfd50e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dbfdece0-6c76-013d-d644-0800270c66d6" xmi:uuid="dbfdedb0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218083_796424_53979" xmi:uuid="ba80fdc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="ba6fd610-7cb5-0138-411c-418b172fba9f" xmi:uuid="ba6fd690-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="ba808010-7cb5-0138-411c-418b172fba9f" xmi:uuid="ba808080-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="371" y="560" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="357" y="532" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963762006_876112_56927" xmi:uuid="c68e2b70-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963765455_237690_56928"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862543_654228_51251"/>
      <target xmi:idref="_18_4_1_271a0567_1577963218083_2584_53980"/>
      <waypoint x="921" y="889"/>
      <waypoint x="921" y="641"/>
      <waypoint x="728" y="641"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_154128_53968" xmi:uuid="911c94b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
      <ownedElement xmi:id="ba9f4ec0-7cb5-0138-411c-418b172fba9f" xmi:uuid="ba9f4f50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="baae0140-7cb5-0138-411c-418b172fba9f" xmi:uuid="baae0280-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="dc2fe440-6c76-013d-d644-0800270c66d6" xmi:uuid="dc2fe4e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dc308fe0-6c76-013d-d644-0800270c66d6" xmi:uuid="dc3090b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218083_2584_53980" xmi:uuid="badfe960-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="bace9a10-7cb5-0138-411c-418b172fba9f" xmi:uuid="bace9a80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="badf6870-7cb5-0138-411c-418b172fba9f" xmi:uuid="badf68f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="553" y="630" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="539" y="602" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963769535_817424_56946" xmi:uuid="c6ec13d0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963771865_450036_56947"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862543_654228_51251"/>
      <target xmi:idref="_18_4_1_271a0567_1577963218083_834752_53981"/>
      <waypoint x="921" y="889"/>
      <waypoint x="921" y="732"/>
      <waypoint x="737" y="732"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218082_615556_53969" xmi:uuid="911ca3c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
      <ownedElement xmi:id="bafe8830-7cb5-0138-411c-418b172fba9f" xmi:uuid="bafe88b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bb0d2de0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bb0d2e60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="dc6c9510-6c76-013d-d644-0800270c66d6" xmi:uuid="dc6c96f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dc6d47e0-6c76-013d-d644-0800270c66d6" xmi:uuid="dc6d48d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963218083_834752_53981" xmi:uuid="bb3f0fb0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="bb2dcb20-7cb5-0138-411c-418b172fba9f" xmi:uuid="bb2dcc60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="bb3e90c0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bb3e9140-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="553" y="721" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="539" y="693" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218083_529983_53986" xmi:uuid="911caaa0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215642_776516_53928"/>
      <source xmi:idref="_18_4_1_271a0567_1577963218082_550419_53973"/>
      <target xmi:idref="_18_4_1_271a0567_1577963218082_100535_53961"/>
      <waypoint x="553" y="200"/>
      <waypoint x="483" y="200"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218083_699480_53987" xmi:uuid="911cb1e0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215645_434497_53936"/>
      <source xmi:idref="_18_4_1_271a0567_1577963218083_80869_53976"/>
      <target xmi:idref="_18_4_1_271a0567_1577963218082_342452_53967"/>
      <waypoint x="609" y="494"/>
      <waypoint x="609" y="567"/>
      <waypoint x="544" y="567"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963218083_194523_53988" xmi:uuid="911cb8d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963215645_146121_53937"/>
      <source xmi:idref="_18_4_1_271a0567_1577963218083_450586_53978"/>
      <target xmi:idref="_18_4_1_271a0567_1577963218082_342452_53967"/>
      <waypoint x="494" y="431"/>
      <waypoint x="494" y="532"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963366032_691413_54995" xmi:uuid="911ce4d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
      <ownedElement xmi:id="bb5c6290-7cb5-0138-411c-418b172fba9f" xmi:uuid="bb5c6310-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577963366032_577951_54998" xmi:uuid="911cc910-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="dcb1be70-6c76-013d-d644-0800270c66d6" xmi:uuid="dcb1bf10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="468" y="110" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="450" y="119" width="15" height="15"/>
      </ownedElement>
      <bounds x="280" y="105" width="185" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963366032_411659_54996" xmi:uuid="911d43d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
      <ownedElement xmi:id="bb881df0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bb881e60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577963366032_653263_55000" xmi:uuid="911cf720-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="dcd812f0-6c76-013d-d644-0800270c66d6" xmi:uuid="dcd81550-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="325" y="512" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="315" y="494" width="15" height="15"/>
      </ownedElement>
      <bounds x="252" y="455" width="220" height="54"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963366032_441987_54997" xmi:uuid="911da220-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
      <ownedElement xmi:id="bbb3a0f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bbb3a180-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
        <text>roleSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577963366033_411637_55002" xmi:uuid="911d5590-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="dcffea40-6c76-013d-d644-0800270c66d6" xmi:uuid="dcffeaf0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="322" y="815" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="306" y="802" width="15" height="15"/>
      </ownedElement>
      <bounds x="133" y="791" width="188" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963437494_877323_56272" xmi:uuid="911db920-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963435349_623265_56257"/>
      <ownedElement xmi:id="bbd30650-7cb5-0138-411c-418b172fba9f" xmi:uuid="bbd306d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963435349_623265_56257"/>
        <text>role:Class</text>
      </ownedElement>
      <ownedElement xmi:id="bbd4d270-7cb5-0138-411c-418b172fba9f" xmi:uuid="bbd4d2c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963435349_623265_56257"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="dd0e8e70-6c76-013d-d644-0800270c66d6" xmi:uuid="dd0e8f10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dd0f6e60-6c76-013d-d644-0800270c66d6" xmi:uuid="dd0f6f40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963437494_979671_56275" xmi:uuid="bbf6e460-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="bbe626a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bbe62710-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="bbf666d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bbf66750-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="392" y="798" width="103" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_19_0_2_aec0217_1579101632052_618543_31456" xmi:uuid="bc1cd180-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="bc07dc40-7cb5-0138-411c-418b172fba9f" xmi:uuid="bc07dcc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="bc1c30d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bc1c3160-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="392" y="833" width="82" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="385" y="770" width="117" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963776607_68473_56962" xmi:uuid="c83b4040-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963778743_522096_56963"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862543_654228_51251"/>
      <target xmi:idref="_18_4_1_271a0567_1577963437495_626793_56277"/>
      <waypoint x="921" y="889"/>
      <waypoint x="921" y="844"/>
      <waypoint x="730" y="844"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963437494_924911_56273" xmi:uuid="911dcd70-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963435350_698842_56258"/>
      <ownedElement xmi:id="bc31df50-7cb5-0138-411c-418b172fba9f" xmi:uuid="bc31dfc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963435350_698842_56258"/>
        <text>roleAsgn2:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bc345060-7cb5-0138-411c-418b172fba9f" xmi:uuid="bc3450c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963435350_698842_56258"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="dd492940-6c76-013d-d644-0800270c66d6" xmi:uuid="dd4929e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dd4a2370-6c76-013d-d644-0800270c66d6" xmi:uuid="dd4a2450-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963437494_32721_56276" xmi:uuid="bc725780-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="bc5cfed0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bc5cff50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="bc71ac20-7cb5-0138-411c-418b172fba9f" xmi:uuid="bc71acb0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="798" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577963437495_626793_56277" xmi:uuid="bcaf2820-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="bc99fca0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bc99fd20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="bcae8760-7cb5-0138-411c-418b172fba9f" xmi:uuid="bcae87e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="546" y="833" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_19_0_2_aec0217_1579101771880_131120_31643" xmi:uuid="bcd183b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="bcc034d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bcc03550-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="bcd10280-7cb5-0138-411c-418b172fba9f" xmi:uuid="bcd10310-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="546" y="875" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="539" y="770" width="294" height="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963437495_715667_56278" xmi:uuid="911ddad0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963435352_373444_56259"/>
      <source xmi:idref="_18_4_1_271a0567_1577963437494_32721_56276"/>
      <target xmi:idref="_18_4_1_271a0567_1577963437494_877323_56272"/>
      <waypoint x="546" y="809"/>
      <waypoint x="502" y="809"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963466692_859645_56618" xmi:uuid="911de290-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963467746_269932_56619"/>
      <source xmi:idref="_18_4_1_271a0567_1577963218082_306720_53971"/>
      <target xmi:idref="_18_4_1_271a0567_1577963366032_577951_54998"/>
      <waypoint x="553" y="126"/>
      <waypoint x="465" y="126"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963472522_947544_56640" xmi:uuid="911deae0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963473774_120617_56641"/>
      <source xmi:idref="_18_4_1_271a0567_1577963218083_796424_53979"/>
      <target xmi:idref="_18_4_1_271a0567_1577963366032_653263_55000"/>
      <waypoint x="371" y="571"/>
      <waypoint x="322" y="571"/>
      <waypoint x="322" y="509"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963500207_578139_56662" xmi:uuid="911df2f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963505803_637529_56663"/>
      <source xmi:idref="_18_4_1_271a0567_1577963437494_979671_56275"/>
      <target xmi:idref="_18_4_1_271a0567_1577963366033_411637_55002"/>
      <waypoint x="392" y="809"/>
      <waypoint x="321" y="809"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963574855_869096_56742" xmi:uuid="911e1900-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963579926_149988_56743"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862544_100138_51260"/>
      <target xmi:idref="_18_4_1_271a0567_1577963076525_289143_51654"/>
      <waypoint x="906" y="928"/>
      <waypoint x="322" y="928"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963594248_350304_56766" xmi:uuid="911e2030-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963596805_274488_56767"/>
      <source xmi:idref="_18_4_1_271a0567_1577962862544_578842_51256"/>
      <target xmi:idref="_18_4_1_271a0567_1577962936468_273919_51622"/>
      <waypoint x="549" y="1001"/>
      <waypoint x="266" y="1001"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963703551_954179_56835" xmi:uuid="911e2740-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963706985_972965_56836"/>
      <source xmi:idref="_18_4_1_271a0567_1577963656201_393237_56810"/>
      <target xmi:idref="_18_4_1_271a0567_1577962862543_654228_51251"/>
      <waypoint x="1274" y="840"/>
      <waypoint x="1141" y="840"/>
      <waypoint x="1141" y="889"/>
    </ownedElement>
    <ownedElement xmi:id="_19_0_2_aec0217_1579101650488_497540_31494" xmi:uuid="911e2f90-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579101652492_312225_31495"/>
      <source xmi:idref="_19_0_2_aec0217_1579101632052_618543_31456"/>
      <target xmi:idref="_18_4_1_271a0567_1577963366033_411637_55002"/>
      <waypoint x="392" y="844"/>
      <waypoint x="375" y="844"/>
      <waypoint x="375" y="809"/>
      <waypoint x="321" y="809"/>
    </ownedElement>
    <ownedElement xmi:id="_19_0_2_aec0217_1579101753477_176234_31612" xmi:uuid="911e3bc0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579101753446_362297_31607"/>
      <ownedElement xmi:id="bcd38a50-7cb5-0138-411c-418b172fba9f" xmi:uuid="bcd38aa0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579101753446_362297_31607"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="bcd52e00-7cb5-0138-411c-418b172fba9f" xmi:uuid="bcd52e40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579101753446_362297_31607"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="336" y="875" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_19_0_2_aec0217_1579101813936_132604_31681" xmi:uuid="911e42d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579101814687_264888_31682"/>
      <source xmi:idref="_19_0_2_aec0217_1579101771880_131120_31643"/>
      <target xmi:idref="_19_0_2_aec0217_1579101753477_176234_31612"/>
      <waypoint x="546" y="886"/>
      <waypoint x="498" y="886"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1277" height="1180"/>
    <name>WorkOrderAssignment</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_271a0567_1577964460915_445214_58587" xmi:uuid="912ba0a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkOrderRelationship"/>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965143657_183358_60328" xmi:uuid="912cb9b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965143639_954698_60324"/>
      <bounds x="999" y="250" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964483274_637277_58621" xmi:uuid="912d2a10-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-Related"/>
      <ownedElement xmi:id="c12d88b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c12d8930-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-Related"/>
        <text>Related:WorkOrder</text>
      </ownedElement>
      <ownedElement xmi:id="c12f2650-7cb5-0138-411c-418b172fba9f" xmi:uuid="c12f2690-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-Related"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577964769755_102732_60110" xmi:uuid="912ce6b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1518011863438_410659_32287"/>
        <ownedElement xmi:id="e3091d10-6c76-013d-d644-0800270c66d6" xmi:uuid="e3091e90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1518011863438_410659_32287"/>
          <bounds x="199" y="508" width="136" height="13"/>
          <text>workOrder : Work_order [1]</text>
        </ownedElement>
        <bounds x="181" y="517" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="511" width="154" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964483288_988455_58652" xmi:uuid="912d9d90-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-Relating"/>
      <ownedElement xmi:id="c1325b20-7cb5-0138-411c-418b172fba9f" xmi:uuid="c1325b70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-Relating"/>
        <text>Relating:WorkOrder</text>
      </ownedElement>
      <ownedElement xmi:id="c133efd0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c133f010-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrderRelationship-Relating"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577964784349_709533_60124" xmi:uuid="912d4130-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1518011863438_410659_32287"/>
        <ownedElement xmi:id="e318e070-6c76-013d-d644-0800270c66d6" xmi:uuid="e318e150-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1518011863438_410659_32287"/>
          <bounds x="199" y="558" width="136" height="13"/>
          <text>workOrder : Work_order [1]</text>
        </ownedElement>
        <bounds x="181" y="567" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="560" width="154" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964549121_501458_59342" xmi:uuid="912db510-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964549108_569686_59338"/>
      <ownedElement xmi:id="c1458480-7cb5-0138-411c-418b172fba9f" xmi:uuid="c1458570-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964549108_569686_59338"/>
        <text>work_order_relationship:Work_order_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="c1474f00-7cb5-0138-411c-418b172fba9f" xmi:uuid="c1474fe0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964549108_569686_59338"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="e34456f0-6c76-013d-d644-0800270c66d6" xmi:uuid="e3445810-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e346ac60-6c76-013d-d644-0800270c66d6" xmi:uuid="e346ae50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964549121_173944_59343" xmi:uuid="c16a2180-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-description"/>
          <ownedElement xmi:id="c1590500-7cb5-0138-411c-418b172fba9f" xmi:uuid="c1590580-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="c1699a50-7cb5-0138-411c-418b172fba9f" xmi:uuid="c1699ad0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="693" y="345" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964549121_818192_59344" xmi:uuid="c18bcf80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-id"/>
          <ownedElement xmi:id="c17acd10-7cb5-0138-411c-418b172fba9f" xmi:uuid="c17ace90-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="c18b4ec0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c18b4f40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="700" y="401" width="94" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964549121_440303_59345" xmi:uuid="c1bca1e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-related"/>
          <ownedElement xmi:id="c1ab7e40-7cb5-0138-411c-418b172fba9f" xmi:uuid="c1ab7ec0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-related"/>
            <text>related:Work_order</text>
          </ownedElement>
          <ownedElement xmi:id="c1bc22d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c1bc2340-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-related"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="693" y="511" width="144" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964549121_689965_59346" xmi:uuid="c1edf850-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-relating"/>
          <ownedElement xmi:id="c1dc63d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c1dc6450-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-relating"/>
            <text>relating:Work_order</text>
          </ownedElement>
          <ownedElement xmi:id="c1ed7710-7cb5-0138-411c-418b172fba9f" xmi:uuid="c1ed77a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-relating"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="693" y="564" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964549121_673677_59347" xmi:uuid="c2104090-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-relation_type"/>
          <ownedElement xmi:id="c1fee400-7cb5-0138-411c-418b172fba9f" xmi:uuid="c1fee480-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="c20fbcf0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c20fbdc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order_relationship-relation_type"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="693" y="625" width="144" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="672" y="301" width="315" height="359"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_157225_59540" xmi:uuid="912db9d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="532" y="28" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_727361_59541" xmi:uuid="912e0e00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="c22d55f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c22d5670-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_332683_59549" xmi:uuid="912dc710-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="e4de1f40-6c76-013d-d644-0800270c66d6" xmi:uuid="e4de2050-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="297" y="402" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="279" y="411" width="15" height="15"/>
      </ownedElement>
      <bounds x="126" y="399" width="168" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965120611_312226_60280" xmi:uuid="ce6eb360-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965123146_692894_60281"/>
      <source xmi:idref="_18_4_1_271a0567_1577964549121_501458_59342"/>
      <target xmi:idref="_18_4_1_271a0567_1577964645273_962904_59551"/>
      <waypoint x="672" y="480"/>
      <waypoint x="547" y="480"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_941777_59542" xmi:uuid="912e2040-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="c25ac260-7cb5-0138-411c-418b172fba9f" xmi:uuid="c25ac2e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c2696c80-7cb5-0138-411c-418b172fba9f" xmi:uuid="c2696cf0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e5278150-6c76-013d-d644-0800270c66d6" xmi:uuid="e5278200-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e5291e20-6c76-013d-d644-0800270c66d6" xmi:uuid="e5291f40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_962904_59551" xmi:uuid="c29bce20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="c28a7d20-7cb5-0138-411c-418b172fba9f" xmi:uuid="c28a7da0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c29b4f90-7cb5-0138-411c-418b172fba9f" xmi:uuid="c29b5010-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="364" y="469" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="350" y="441" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965088705_977975_60221" xmi:uuid="ced088c0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965090306_133014_60222"/>
      <source xmi:idref="_18_4_1_271a0567_1577964549121_501458_59342"/>
      <target xmi:idref="_18_4_1_271a0567_1577964645273_536010_59552"/>
      <waypoint x="686" y="301"/>
      <waypoint x="686" y="123"/>
      <waypoint x="541" y="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_782094_59543" xmi:uuid="912e2f00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="c2ba6f50-7cb5-0138-411c-418b172fba9f" xmi:uuid="c2ba6fd0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c2c93c70-7cb5-0138-411c-418b172fba9f" xmi:uuid="c2c93fd0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e57c02c0-6c76-013d-d644-0800270c66d6" xmi:uuid="e57c0470-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e57d1330-6c76-013d-d644-0800270c66d6" xmi:uuid="e57d1410-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_536010_59552" xmi:uuid="c2fbc960-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c2ea9790-7cb5-0138-411c-418b172fba9f" xmi:uuid="c2ea9930-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c2fb41e0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c2fb4250-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="357" y="112" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="343" y="84" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965095827_415185_60240" xmi:uuid="cf302ee0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965098882_901443_60241"/>
      <source xmi:idref="_18_4_1_271a0567_1577964549121_501458_59342"/>
      <target xmi:idref="_18_4_1_271a0567_1577964645273_398598_59553"/>
      <waypoint x="686" y="301"/>
      <waypoint x="686" y="207"/>
      <waypoint x="532" y="207"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_790266_59544" xmi:uuid="912e3ac0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="c319f500-7cb5-0138-411c-418b172fba9f" xmi:uuid="c319f5c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c328f2f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c328f370-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e5ca5da0-6c76-013d-d644-0800270c66d6" xmi:uuid="e5ca6230-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e5cb9b40-6c76-013d-d644-0800270c66d6" xmi:uuid="e5cb9c80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_398598_59553" xmi:uuid="c35b2bc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="c349cf20-7cb5-0138-411c-418b172fba9f" xmi:uuid="c349cfa0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="c35aa8e0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c35aa970-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="357" y="196" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="343" y="168" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965102131_981508_60259" xmi:uuid="cf917d10-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965106094_65490_60260"/>
      <source xmi:idref="_18_4_1_271a0567_1577964549121_501458_59342"/>
      <target xmi:idref="_18_4_1_271a0567_1577964645273_866324_59554"/>
      <waypoint x="686" y="301"/>
      <waypoint x="686" y="284"/>
      <waypoint x="585" y="284"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_243793_59545" xmi:uuid="912e4640-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="c3794820-7cb5-0138-411c-418b172fba9f" xmi:uuid="c37948a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="c3880790-7cb5-0138-411c-418b172fba9f" xmi:uuid="c3880810-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="e60b95a0-6c76-013d-d644-0800270c66d6" xmi:uuid="e60b9650-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e60c5520-6c76-013d-d644-0800270c66d6" xmi:uuid="e60c55e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_866324_59554" xmi:uuid="c3b9fcf0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="c3a8b730-7cb5-0138-411c-418b172fba9f" xmi:uuid="c3a8b7b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="c3b97360-7cb5-0138-411c-418b172fba9f" xmi:uuid="c3b973e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="357" y="273" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="343" y="245" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_734244_59546" xmi:uuid="912e6970-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="c3d73270-7cb5-0138-411c-418b172fba9f" xmi:uuid="c3d732e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_116983_59555" xmi:uuid="912e52f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="e65a2eb0-6c76-013d-d644-0800270c66d6" xmi:uuid="e65a3220-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="364" y="338" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="346" y="347" width="15" height="15"/>
      </ownedElement>
      <bounds x="126" y="336" width="235" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_523132_59547" xmi:uuid="912e95a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="c4028bd0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c4028c40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_92403_59557" xmi:uuid="912e7c30-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="e6848e30-6c76-013d-d644-0800270c66d6" xmi:uuid="e6848ed0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="314" y="621" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="296" y="630" width="15" height="15"/>
      </ownedElement>
      <bounds x="133" y="609" width="178" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965126808_676485_60299" xmi:uuid="d0468ab0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965131001_937408_60300"/>
      <source xmi:idref="_18_4_1_271a0567_1577964549121_501458_59342"/>
      <target xmi:idref="_18_4_1_271a0567_1577964645273_416453_59559"/>
      <waypoint x="725" y="660"/>
      <waypoint x="725" y="711"/>
      <waypoint x="548" y="711"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_84975_59548" xmi:uuid="912ea700-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="c439d510-7cb5-0138-411c-418b172fba9f" xmi:uuid="c439d580-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c44c33b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c44c3430-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="e6a82110-6c76-013d-d644-0800270c66d6" xmi:uuid="e6a821d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e6a90bc0-6c76-013d-d644-0800270c66d6" xmi:uuid="e6a90ca0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964645273_416453_59559" xmi:uuid="c489e370-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c474d430-7cb5-0138-411c-418b172fba9f" xmi:uuid="c474d4b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c4894360-7cb5-0138-411c-418b172fba9f" xmi:uuid="c48943e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="364" y="700" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="350" y="672" width="291" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964714118_684866_59993" xmi:uuid="912eaff0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964715834_860047_59994"/>
      <source xmi:idref="_18_4_1_271a0567_1577964549121_173944_59343"/>
      <target xmi:idref="_18_4_1_271a0567_1577964645273_116983_59555"/>
      <waypoint x="693" y="357"/>
      <waypoint x="361" y="357"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964732457_945033_60017" xmi:uuid="912eb870-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964733872_238190_60018"/>
      <source xmi:idref="_18_4_1_271a0567_1577964549121_818192_59344"/>
      <target xmi:idref="_18_4_1_271a0567_1577964645273_332683_59549"/>
      <waypoint x="700" y="417"/>
      <waypoint x="294" y="417"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964803911_70414_60147" xmi:uuid="912ebfb0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964805978_38569_60148"/>
      <source xmi:idref="_18_4_1_271a0567_1577964549121_440303_59345"/>
      <target xmi:idref="_18_4_1_271a0567_1577964769755_102732_60110"/>
      <waypoint x="693" y="522"/>
      <waypoint x="196" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964810115_912553_60169" xmi:uuid="912ec690-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964811940_890998_60170"/>
      <source xmi:idref="_18_4_1_271a0567_1577964549121_689965_59346"/>
      <target xmi:idref="_18_4_1_271a0567_1577964784349_709533_60124"/>
      <waypoint x="693" y="574"/>
      <waypoint x="196" y="574"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965045369_450367_60197" xmi:uuid="912ecdc0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965048292_812615_60198"/>
      <source xmi:idref="_18_4_1_271a0567_1583168756546_601548_87900"/>
      <target xmi:idref="_18_4_1_271a0567_1577964645273_92403_59557"/>
      <waypoint x="413" y="637"/>
      <waypoint x="311" y="637"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577965186671_694436_60357" xmi:uuid="912ed530-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965188822_411975_60358"/>
      <source xmi:idref="_18_4_1_271a0567_1577965143657_183358_60328"/>
      <target xmi:idref="_18_4_1_271a0567_1577964549121_501458_59342"/>
      <waypoint x="999" y="256"/>
      <waypoint x="858" y="256"/>
      <waypoint x="858" y="301"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1583168756546_171886_87899" xmi:uuid="c49ccdd0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1583168756538_182422_87897"/>
      <ownedElement xmi:id="c49a83b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c49a8430-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1583168756538_182422_87897"/>
        <text>defaultType:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1583168756546_601548_87900" xmi:uuid="c49c4900-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="e6df0400-6c76-013d-d644-0800270c66d6" xmi:uuid="e6df05b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="357" y="643" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="413" y="628" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1583168756546_950073_87902" xmi:uuid="c49cc7a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="e6e9e620-6c76-013d-d644-0800270c66d6" xmi:uuid="e6e9e6d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="604" y="617" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="586" y="626" width="15" height="15"/>
      </ownedElement>
      <bounds x="413" y="616" width="188" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1583168772321_960904_87955" xmi:uuid="c49cd4f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1583168773143_138050_87956"/>
      <source xmi:idref="_18_4_1_271a0567_1577964549121_673677_59347"/>
      <target xmi:idref="_18_4_1_271a0567_1583168756546_950073_87902"/>
      <waypoint x="693" y="634"/>
      <waypoint x="601" y="634"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1002" height="751"/>
    <name>WorkOrderRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_271a0567_1577956013115_235999_55268" xmi:uuid="912f4900-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkRequest"/>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956874317_439928_56918" xmi:uuid="91321900-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956874270_39656_56914"/>
      <bounds x="1532" y="24" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956033157_851588_55302" xmi:uuid="913288a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-ClassifiedAs"/>
      <ownedElement xmi:id="c4c46430-7cb5-0138-411c-418b172fba9f" xmi:uuid="c4c464b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-ClassifiedAs"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="c4c61a40-7cb5-0138-411c-418b172fba9f" xmi:uuid="c4c61a80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-ClassifiedAs"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956812743_318457_56883" xmi:uuid="91323450-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="e7331dd0-6c76-013d-d644-0800270c66d6" xmi:uuid="e7331e90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="269" y="85" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="251" y="94" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="84" width="224" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956033184_450075_55333" xmi:uuid="91329a60-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Description"/>
      <ownedElement xmi:id="c4d57b00-7cb5-0138-411c-418b172fba9f" xmi:uuid="c4d57b80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Description"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="c4d75c40-7cb5-0138-411c-418b172fba9f" xmi:uuid="c4d75c90-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Description"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="140" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956033185_722982_55364" xmi:uuid="9132a7d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Id"/>
      <ownedElement xmi:id="c4e6a090-7cb5-0138-411c-418b172fba9f" xmi:uuid="c4e6a100-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Id"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="c4e84a70-7cb5-0138-411c-418b172fba9f" xmi:uuid="c4e84ab0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Id"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="385" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956033201_13521_55395" xmi:uuid="9132b220-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-RequestType"/>
      <ownedElement xmi:id="c4f72960-7cb5-0138-411c-418b172fba9f" xmi:uuid="c4f729d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-RequestType"/>
        <text>RequestType:ClassSelect</text>
      </ownedElement>
      <ownedElement xmi:id="c4f8e4f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c4f8e540-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-RequestType"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="539" width="177" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956033216_401083_55426" xmi:uuid="9132fd70-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-SameAs"/>
      <ownedElement xmi:id="c507a1d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c507a250-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-SameAs"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="c5096d20-7cb5-0138-411c-418b172fba9f" xmi:uuid="c5096d90-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-SameAs"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577957254057_620183_58178" xmi:uuid="9132c1d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="e7784e80-6c76-013d-d644-0800270c66d6" xmi:uuid="e7784f30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="192" y="725" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="174" y="734" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="721" width="147" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956033225_982563_55457" xmi:uuid="91335580-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Scope"/>
      <ownedElement xmi:id="c50d93b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c50d9420-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Scope"/>
        <text>Scope:ActivityAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="c50f41b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c50f41f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequest-Scope"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577957537868_396489_58424" xmi:uuid="91331490-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
        <ownedElement xmi:id="e7829900-6c76-013d-d644-0800270c66d6" xmi:uuid="e78299b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
          <bounds x="283" y="879" width="93" height="13"/>
          <text>ai : activity_item [1]</text>
        </ownedElement>
        <bounds x="265" y="888" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="882" width="238" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_546437_55591" xmi:uuid="9133c4e0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_160344_55537"/>
      <ownedElement xmi:id="c51f9c90-7cb5-0138-411c-418b172fba9f" xmi:uuid="c51f9dc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_160344_55537"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_911000_55602" xmi:uuid="91336c40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="e7989ca0-6c76-013d-d644-0800270c66d6" xmi:uuid="e7989d50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="394" y="136" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="448" y="145" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_506492_55604" xmi:uuid="91338160-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="e7a38d60-6c76-013d-d644-0800270c66d6" xmi:uuid="e7a38e10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="709" y="139" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="691" y="148" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_286277_55606" xmi:uuid="91339b00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="e7b0ebd0-6c76-013d-d644-0800270c66d6" xmi:uuid="e7b0ecb0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="616" y="189" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="590" y="174" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_565120_55608" xmi:uuid="9133b2d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="e7bfe0d0-6c76-013d-d644-0800270c66d6" xmi:uuid="e7bfe170-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="479" y="192" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="469" y="174" width="15" height="15"/>
      </ownedElement>
      <bounds x="448" y="133" width="258" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956949126_580020_56979" xmi:uuid="d131a1a0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956950992_235582_56980"/>
      <source xmi:idref="_18_4_1_271a0567_1577956712969_774957_56717"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_536162_55610"/>
      <waypoint x="1323" y="109"/>
      <waypoint x="1220" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_562615_55592" xmi:uuid="9133fbb0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_109661_55538"/>
      <ownedElement xmi:id="c53470d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c5347150-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_109661_55538"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c5363e60-7cb5-0138-411c-418b172fba9f" xmi:uuid="c5363ff0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_109661_55538"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e7cf3480-6c76-013d-d644-0800270c66d6" xmi:uuid="e7cf36b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e7d03ce0-6c76-013d-d644-0800270c66d6" xmi:uuid="e7d03dd0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_536162_55610" xmi:uuid="c5686fc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c5571a30-7cb5-0138-411c-418b172fba9f" xmi:uuid="c5571aa0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c567eb00-7cb5-0138-411c-418b172fba9f" xmi:uuid="c567eb80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1036" y="98" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1022" y="70" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957062304_755669_57386" xmi:uuid="d1787130-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957063890_394430_57387"/>
      <source xmi:idref="_18_4_1_271a0567_1577956712969_774957_56717"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_200231_55611"/>
      <waypoint x="1323" y="221"/>
      <waypoint x="1211" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_65121_55593" xmi:uuid="91340770-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_942086_55539"/>
      <ownedElement xmi:id="c57a0190-7cb5-0138-411c-418b172fba9f" xmi:uuid="c57a0230-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_942086_55539"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c57bbe80-7cb5-0138-411c-418b172fba9f" xmi:uuid="c57bbed0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_942086_55539"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e800f050-6c76-013d-d644-0800270c66d6" xmi:uuid="e800f120-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e801dec0-6c76-013d-d644-0800270c66d6" xmi:uuid="e801e960-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_200231_55611" xmi:uuid="c5ae0e00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="c59cab00-7cb5-0138-411c-418b172fba9f" xmi:uuid="c59cab80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="c5ad8e70-7cb5-0138-411c-418b172fba9f" xmi:uuid="c5ad8ee0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1036" y="210" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1022" y="182" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957068000_402274_57405" xmi:uuid="d20df380-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957068887_676048_57406"/>
      <source xmi:idref="_18_4_1_271a0567_1577956712969_774957_56717"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_607875_55613"/>
      <waypoint x="1323" y="291"/>
      <waypoint x="1264" y="291"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_392071_55594" xmi:uuid="91341470-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_25536_55540"/>
      <ownedElement xmi:id="c5bfa280-7cb5-0138-411c-418b172fba9f" xmi:uuid="c5bfa300-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_25536_55540"/>
        <text>li:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="c5c16ac0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c5c16b30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_25536_55540"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="e83ebf00-6c76-013d-d644-0800270c66d6" xmi:uuid="e83ec000-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e8408370-6c76-013d-d644-0800270c66d6" xmi:uuid="e84084b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_171157_55612" xmi:uuid="c5e4f430-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="c5d368a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c5d36a50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="c5e46cb0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c5e46d40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1036" y="336" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_607875_55613" xmi:uuid="c61610e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="c604c5b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c604c760-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="c6159430-7cb5-0138-411c-418b172fba9f" xmi:uuid="c61594a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1036" y="280" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_560408_55614" xmi:uuid="c646d7f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="c635a020-7cb5-0138-411c-418b172fba9f" xmi:uuid="c635a0a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="c6465a20-7cb5-0138-411c-418b172fba9f" xmi:uuid="c6465a90-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1036" y="308" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1022" y="252" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_223767_55595" xmi:uuid="913420e0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_886492_55541"/>
      <ownedElement xmi:id="c648ed70-7cb5-0138-411c-418b172fba9f" xmi:uuid="c648ede0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_886492_55541"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="c64aca70-7cb5-0138-411c-418b172fba9f" xmi:uuid="c64acae0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_886492_55541"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="795" y="336" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957121653_946631_57539" xmi:uuid="d257ac90-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957122433_542676_57540"/>
      <source xmi:idref="_18_4_1_271a0567_1577956712969_774957_56717"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_762374_55615"/>
      <waypoint x="1323" y="480"/>
      <waypoint x="1219" y="480"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_206580_55596" xmi:uuid="91342d30-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_440961_55542"/>
      <ownedElement xmi:id="c65c2690-7cb5-0138-411c-418b172fba9f" xmi:uuid="c65c27a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_440961_55542"/>
        <text>ia:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c65deb90-7cb5-0138-411c-418b172fba9f" xmi:uuid="c65debf0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_440961_55542"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e8d26af0-6c76-013d-d644-0800270c66d6" xmi:uuid="e8d26be0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e8d37760-6c76-013d-d644-0800270c66d6" xmi:uuid="e8d37840-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_762374_55615" xmi:uuid="c6902ca0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="c67ef940-7cb5-0138-411c-418b172fba9f" xmi:uuid="c67ef9c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c68fb1e0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c68fb260-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1036" y="469" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1022" y="441" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_28699_55597" xmi:uuid="91349b60-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_453378_55543"/>
      <ownedElement xmi:id="c6a0bff0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c6a0c060-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_453378_55543"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_609423_55616" xmi:uuid="91343a60-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="e91ff5e0-6c76-013d-d644-0800270c66d6" xmi:uuid="e91ff6f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="408" y="381" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="462" y="390" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_263713_55618" xmi:uuid="91344c80-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="e9310690-6c76-013d-d644-0800270c66d6" xmi:uuid="e9310750-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="637" y="398" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="615" y="385" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_468405_55620" xmi:uuid="91347b50-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="e93da3f0-6c76-013d-d644-0800270c66d6" xmi:uuid="e93da5e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="494" y="437" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="484" y="419" width="15" height="15"/>
      </ownedElement>
      <bounds x="462" y="378" width="168" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_918476_55598" xmi:uuid="913573a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_93376_55544"/>
      <ownedElement xmi:id="c6b38b10-7cb5-0138-411c-418b172fba9f" xmi:uuid="c6b38b90-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_93376_55544"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_987966_55622" xmi:uuid="9134ae50-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="e956abe0-6c76-013d-d644-0800270c66d6" xmi:uuid="e956ad50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="615" y="532" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="597" y="541" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_506472_55624" xmi:uuid="91350f00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
        <ownedElement xmi:id="e964a670-6c76-013d-d644-0800270c66d6" xmi:uuid="e964a720-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
          <bounds x="366" y="534" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="420" y="543" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_234306_55626" xmi:uuid="91353290-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
        <ownedElement xmi:id="e9721ec0-6c76-013d-d644-0800270c66d6" xmi:uuid="e9721f70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
          <bounds x="481" y="584" width="54" height="13"/>
          <text>class [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="471" y="566" width="15" height="15"/>
      </ownedElement>
      <bounds x="420" y="525" width="192" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957423752_971396_58287" xmi:uuid="d31f1430-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957425694_752851_58288"/>
      <source xmi:idref="_18_4_1_271a0567_1577956712969_774957_56717"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_161690_55629"/>
      <waypoint x="1323" y="637"/>
      <waypoint x="1227" y="637"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_853117_55599" xmi:uuid="913583b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_903782_55545"/>
      <ownedElement xmi:id="c6c7b4d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c6c7b560-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_903782_55545"/>
        <text>ca1:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c6c97bc0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c6c97c10-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_903782_55545"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="e98671a0-6c76-013d-d644-0800270c66d6" xmi:uuid="e9867250-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e9875c30-6c76-013d-d644-0800270c66d6" xmi:uuid="e9875f00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_587344_55628" xmi:uuid="c6fb5e60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="c6ea0740-7cb5-0138-411c-418b172fba9f" xmi:uuid="c6ea07d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="c6faddd0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c6fadf20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1043" y="659" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_161690_55629" xmi:uuid="c72c6830-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c71af720-7cb5-0138-411c-418b172fba9f" xmi:uuid="c71af7c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c72be910-7cb5-0138-411c-418b172fba9f" xmi:uuid="c72be990-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1043" y="624" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_544669_55630" xmi:uuid="c7533c20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="c73f06e0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c73f0780-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="c7524af0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c7524ba0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1043" y="588" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1029" y="560" width="249" height="134"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_121431_55600" xmi:uuid="91358f20-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_279488_55546"/>
      <ownedElement xmi:id="c75584a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c75585b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_279488_55546"/>
        <text>theClassificationRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="c7578350-7cb5-0138-411c-418b172fba9f" xmi:uuid="c75784e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_279488_55546"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="735" y="588" width="271" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957513630_948168_58412" xmi:uuid="d36c2a30-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957514764_921601_58413"/>
      <source xmi:idref="_18_4_1_271a0567_1577956712969_774957_56717"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_933209_55631"/>
      <waypoint x="1365" y="678"/>
      <waypoint x="1365" y="753"/>
      <waypoint x="1266" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_928275_55601" xmi:uuid="91359de0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_913823_55547"/>
      <ownedElement xmi:id="c76967f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c7696870-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_913823_55547"/>
        <text>eii:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="c76b31b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c76b31f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093268_913823_55547"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e9fc50f0-6c76-013d-d644-0800270c66d6" xmi:uuid="e9fc51a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e9fd57b0-6c76-013d-d644-0800270c66d6" xmi:uuid="e9fd58c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_933209_55631" xmi:uuid="c7a1ff60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="c78f5a60-7cb5-0138-411c-418b172fba9f" xmi:uuid="c78f5b00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c7a17030-7cb5-0138-411c-418b172fba9f" xmi:uuid="c7a170c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1043" y="742" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1029" y="714" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_586200_55632" xmi:uuid="9135a5d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093284_734407_55558"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_171157_55612"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_223767_55595"/>
      <waypoint x="1036" y="350"/>
      <waypoint x="1009" y="350"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956100262_805885_55633" xmi:uuid="9135ade0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956093284_680009_55571"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_544669_55630"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_121431_55600"/>
      <waypoint x="1043" y="599"/>
      <waypoint x="1006" y="599"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956712969_774957_56717" xmi:uuid="9135be90-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956712953_4693_56713"/>
      <ownedElement xmi:id="c7b44f20-7cb5-0138-411c-418b172fba9f" xmi:uuid="c7b44fb0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956712953_4693_56713"/>
        <text>work_request:Work_request</text>
      </ownedElement>
      <ownedElement xmi:id="c7b63280-7cb5-0138-411c-418b172fba9f" xmi:uuid="c7b632f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956712953_4693_56713"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="ea2c19f0-6c76-013d-d644-0800270c66d6" xmi:uuid="ea2c1ae0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ea2db710-6c76-013d-d644-0800270c66d6" xmi:uuid="ea2db8f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956712969_552794_56718" xmi:uuid="c7dae3d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request-description"/>
          <ownedElement xmi:id="c7c8e7d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c7c8e850-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="c7da5c60-7cb5-0138-411c-418b172fba9f" xmi:uuid="c7da5e10-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1344" y="147" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956712969_584850_56719" xmi:uuid="c7fd8880-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request-purpose"/>
          <ownedElement xmi:id="c7ec5890-7cb5-0138-411c-418b172fba9f" xmi:uuid="c7ec5910-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request-purpose"/>
            <text>purpose:String</text>
          </ownedElement>
          <ownedElement xmi:id="c7fd00a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c7fd0120-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request-purpose"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1344" y="538" width="119" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577956712969_494297_56720" xmi:uuid="c81f05e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request-request_id"/>
          <ownedElement xmi:id="c80e0e00-7cb5-0138-411c-418b172fba9f" xmi:uuid="c80e0e70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request-request_id"/>
            <text>request_id:String</text>
          </ownedElement>
          <ownedElement xmi:id="c81e8510-7cb5-0138-411c-418b172fba9f" xmi:uuid="c81e8630-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_request-request_id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1344" y="377" width="132" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1323" y="49" width="197" height="629"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956924707_899951_56943" xmi:uuid="9135c6a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956926157_719984_56944"/>
      <source xmi:idref="_18_4_1_271a0567_1577956874317_439928_56918"/>
      <target xmi:idref="_18_4_1_271a0567_1577956712969_774957_56717"/>
      <waypoint x="1532" y="32"/>
      <waypoint x="1421" y="32"/>
      <waypoint x="1421" y="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956941789_555775_56959" xmi:uuid="9135cec0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956945937_471370_56960"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_562615_55592"/>
      <target xmi:idref="_18_4_1_271a0567_1577956812743_318457_56883"/>
      <waypoint x="1022" y="102"/>
      <waypoint x="266" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956962996_262758_56998" xmi:uuid="9135d570-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956964844_260573_56999"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_911000_55602"/>
      <target xmi:idref="_18_4_1_271a0567_1577956033184_450075_55333"/>
      <waypoint x="448" y="151"/>
      <waypoint x="241" y="151"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956971172_18812_57019" xmi:uuid="9135dca0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956973523_162818_57020"/>
      <source xmi:idref="_18_4_1_271a0567_1577956712969_552794_56718"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_506492_55604"/>
      <waypoint x="1344" y="154"/>
      <waypoint x="706" y="154"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956992497_722160_57050" xmi:uuid="91362730-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_214998_57034"/>
      <ownedElement xmi:id="c82ec320-7cb5-0138-411c-418b172fba9f" xmi:uuid="c82ec400-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_214998_57034"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="c8308ca0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c8308d10-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_214998_57034"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956992497_374323_57055" xmi:uuid="9135ec90-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="ea99ffd0-6c76-013d-d644-0800270c66d6" xmi:uuid="ea9a0070-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="773" y="193" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="769" y="215" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="210" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956992497_446722_57051" xmi:uuid="91366930-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_43443_57035"/>
      <ownedElement xmi:id="c84005c0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c8400670-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_43443_57035"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="c841e540-7cb5-0138-411c-418b172fba9f" xmi:uuid="c841e580-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_43443_57035"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956992497_729355_57057" xmi:uuid="91363a80-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="eab279f0-6c76-013d-d644-0800270c66d6" xmi:uuid="eab27aa0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="627" y="305" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="609" y="314" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="455" y="308" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956992497_349709_57052" xmi:uuid="9136d830-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_892265_57036"/>
      <ownedElement xmi:id="c8527800-7cb5-0138-411c-418b172fba9f" xmi:uuid="c8527880-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_892265_57036"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="c8544ec0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c8544f20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_892265_57036"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956992497_548465_57059" xmi:uuid="91367c80-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="eacc4670-6c76-013d-d644-0800270c66d6" xmi:uuid="eacc4720-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="598" y="457" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="580" y="466" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="462" y="462" width="126" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577956992497_152519_57053" xmi:uuid="91376430-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_457194_57037"/>
      <ownedElement xmi:id="c864abe0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c864ac50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956992459_457194_57037"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956992497_1583_57061" xmi:uuid="9136ed70-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="eae5ef20-6c76-013d-d644-0800270c66d6" xmi:uuid="eae5efd0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="765" y="377" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="819" y="386" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577956992497_359642_57063" xmi:uuid="91375170-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="eaf4e360-6c76-013d-d644-0800270c66d6" xmi:uuid="eaf4e410-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="1000" y="377" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="982" y="386" width="15" height="15"/>
      </ownedElement>
      <bounds x="819" y="371" width="178" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957020861_197521_57307" xmi:uuid="91376f40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957022280_391594_57308"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_65121_55593"/>
      <target xmi:idref="_18_4_1_271a0567_1577956992497_374323_57055"/>
      <waypoint x="1022" y="221"/>
      <waypoint x="784" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957026588_669170_57326" xmi:uuid="913777b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957028093_152605_57327"/>
      <source xmi:idref="_18_4_1_271a0567_1577956992497_722160_57050"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_286277_55606"/>
      <waypoint x="599" y="210"/>
      <waypoint x="599" y="189"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957032286_608995_57345" xmi:uuid="91378170-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957037513_629366_57346"/>
      <source xmi:idref="_18_4_1_271a0567_1577956992497_446722_57051"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_565120_55608"/>
      <waypoint x="476" y="308"/>
      <waypoint x="476" y="189"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957046637_423089_57364" xmi:uuid="91378840-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957049447_822456_57365"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_560408_55614"/>
      <target xmi:idref="_18_4_1_271a0567_1577956992497_729355_57057"/>
      <waypoint x="1036" y="319"/>
      <waypoint x="624" y="319"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957083113_423552_57438" xmi:uuid="91379090-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957084662_564694_57439"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_609423_55616"/>
      <target xmi:idref="_18_4_1_271a0567_1577956033185_722982_55364"/>
      <waypoint x="462" y="396"/>
      <waypoint x="168" y="396"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957088388_65153_57457" xmi:uuid="91379770-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957089925_204607_57458"/>
      <source xmi:idref="_18_4_1_271a0567_1577956992497_1583_57061"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_263713_55618"/>
      <waypoint x="819" y="396"/>
      <waypoint x="630" y="396"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957099660_248529_57479" xmi:uuid="91379f40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957101634_996626_57480"/>
      <source xmi:idref="_18_4_1_271a0567_1577956712969_494297_56720"/>
      <target xmi:idref="_18_4_1_271a0567_1577956992497_359642_57063"/>
      <waypoint x="1344" y="392"/>
      <waypoint x="997" y="392"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957107519_904613_57501" xmi:uuid="9137a620-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957108959_672762_57502"/>
      <source xmi:idref="_18_4_1_271a0567_1577956992497_349709_57052"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_468405_55620"/>
      <waypoint x="490" y="462"/>
      <waypoint x="490" y="434"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957112030_442106_57520" xmi:uuid="9137ade0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957116361_412811_57521"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_206580_55596"/>
      <target xmi:idref="_18_4_1_271a0567_1577956992497_548465_57059"/>
      <waypoint x="1022" y="473"/>
      <waypoint x="595" y="473"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_768214_57640" xmi:uuid="9137bf00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_487330_57551"/>
      <ownedElement xmi:id="c87855c0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c8785640-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_487330_57551"/>
        <text>aaa:Applied_activity_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c87a6a50-7cb5-0138-411c-418b172fba9f" xmi:uuid="c87a6ad0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_487330_57551"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="eb048fe0-6c76-013d-d644-0800270c66d6" xmi:uuid="eb0491d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="eb056a50-6c76-013d-d644-0800270c66d6" xmi:uuid="eb056b30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_113412_57646" xmi:uuid="c8acd4d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-items"/>
          <ownedElement xmi:id="c89b4590-7cb5-0138-411c-418b172fba9f" xmi:uuid="c89b4620-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-items"/>
            <text>items:activity_item</text>
          </ownedElement>
          <ownedElement xmi:id="c8ac5820-7cb5-0138-411c-418b172fba9f" xmi:uuid="c8ac59c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="392" y="883" width="150" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_885993_57647" xmi:uuid="c8dde070-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-assigned_activity"/>
          <ownedElement xmi:id="c8cc5700-7cb5-0138-411c-418b172fba9f" xmi:uuid="c8cc5780-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-assigned_activity"/>
            <text>assigned_activity:Activity</text>
          </ownedElement>
          <ownedElement xmi:id="c8dd5f00-7cb5-0138-411c-418b172fba9f" xmi:uuid="c8dd5f80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-assigned_activity"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="392" y="847" width="174" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_20475_57648" xmi:uuid="c90015f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-role"/>
          <ownedElement xmi:id="c8eece40-7cb5-0138-411c-418b172fba9f" xmi:uuid="c8eecec0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="c8ff9750-7cb5-0138-411c-418b172fba9f" xmi:uuid="c8ff97d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Applied_activity_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="392" y="812" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="378" y="784" width="215" height="134"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_800783_57641" xmi:uuid="9137c9a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_252954_57552"/>
      <ownedElement xmi:id="c901efb0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c901f000-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_252954_57552"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="c903a530-7cb5-0138-411c-418b172fba9f" xmi:uuid="c903a580-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_252954_57552"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="672" y="812" width="160" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_465303_57656" xmi:uuid="d55a1090-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_329828_57557"/>
      <source xmi:idref="_18_4_1_271a0567_1577957207336_17993_57644"/>
      <target xmi:idref="_18_4_1_271a0567_1577957207336_562055_57649"/>
      <waypoint x="868" y="887"/>
      <waypoint x="841" y="887"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_889521_57642" xmi:uuid="9137dbf0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_557585_57553"/>
      <ownedElement xmi:id="c9145830-7cb5-0138-411c-418b172fba9f" xmi:uuid="c91458b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_557585_57553"/>
        <text>a:Activity</text>
      </ownedElement>
      <ownedElement xmi:id="c9162410-7cb5-0138-411c-418b172fba9f" xmi:uuid="c9162460-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_557585_57553"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="eb7959d0-6c76-013d-d644-0800270c66d6" xmi:uuid="eb795a80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="eb7a8b00-6c76-013d-d644-0800270c66d6" xmi:uuid="eb7a8c20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_562055_57649" xmi:uuid="c9481a60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
          <ownedElement xmi:id="c936de90-7cb5-0138-411c-418b172fba9f" xmi:uuid="c936df30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
            <text>chosen_method:Activity_method</text>
          </ownedElement>
          <ownedElement xmi:id="c9479590-7cb5-0138-411c-418b172fba9f" xmi:uuid="c9479620-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-chosen_method"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="623" y="876" width="218" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_548795_57650" xmi:uuid="c96938c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
          <ownedElement xmi:id="c95882a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c9588320-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="c968ad60-7cb5-0138-411c-418b172fba9f" xmi:uuid="c968ade0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="623" y="918" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_571888_57651" xmi:uuid="c98a97b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
          <ownedElement xmi:id="c979af80-7cb5-0138-411c-418b172fba9f" xmi:uuid="c979b000-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="c98a0d60-7cb5-0138-411c-418b172fba9f" xmi:uuid="c98a0ea0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="623" y="953" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="609" y="847" width="239" height="141"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_303616_57643" xmi:uuid="9137e740-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_390454_57554"/>
      <ownedElement xmi:id="c98c8b70-7cb5-0138-411c-418b172fba9f" xmi:uuid="c98c8cb0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_390454_57554"/>
        <text>ignore:String</text>
      </ownedElement>
      <ownedElement xmi:id="c98e58f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c98e5a80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_390454_57554"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="882" y="952" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_17993_57644" xmi:uuid="9137f700-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_36928_57555"/>
      <ownedElement xmi:id="c99f1ba0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c99f1ce0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_36928_57555"/>
        <text>am:Activity_method</text>
      </ownedElement>
      <ownedElement xmi:id="c9a0cae0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c9a0cc40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_36928_57555"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="ebdaf770-6c76-013d-d644-0800270c66d6" xmi:uuid="ebdaf820-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ebdbdf10-6c76-013d-d644-0800270c66d6" xmi:uuid="ebdbe000-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_3099_57652" xmi:uuid="c9c35770-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
          <ownedElement xmi:id="c9b21720-7cb5-0138-411c-418b172fba9f" xmi:uuid="c9b217a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="c9c2d3e0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c9c2d470-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="882" y="854" width="103" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_536817_57653" xmi:uuid="c9e4ebe0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-purpose"/>
          <ownedElement xmi:id="c9d3fde0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c9d3fe50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-purpose"/>
            <text>purpose:String</text>
          </ownedElement>
          <ownedElement xmi:id="c9e46b60-7cb5-0138-411c-418b172fba9f" xmi:uuid="c9e46be0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Activity_method-purpose"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="882" y="812" width="119" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="868" y="784" width="145" height="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957632786_683489_58487" xmi:uuid="d628b5f0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957636357_585884_58488"/>
      <source xmi:idref="_18_4_1_271a0567_1577956712969_774957_56717"/>
      <target xmi:idref="_18_4_1_271a0567_1577957207336_122780_57654"/>
      <waypoint x="1365" y="678"/>
      <waypoint x="1365" y="866"/>
      <waypoint x="1297" y="866"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_255452_57645" xmi:uuid="913806a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_365867_57556"/>
      <ownedElement xmi:id="c9f60110-7cb5-0138-411c-418b172fba9f" xmi:uuid="c9f60190-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_365867_57556"/>
        <text>aia:Affected_items_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c9f7d230-7cb5-0138-411c-418b172fba9f" xmi:uuid="c9f7d280-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_365867_57556"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="ec217a80-6c76-013d-d644-0800270c66d6" xmi:uuid="ec217b20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ec225ca0-6c76-013d-d644-0800270c66d6" xmi:uuid="ec225dd0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_122780_57654" xmi:uuid="ca2a5070-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-assigned_work_request"/>
          <ownedElement xmi:id="ca18ac50-7cb5-0138-411c-418b172fba9f" xmi:uuid="ca18ad90-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-assigned_work_request"/>
            <text>assigned_work_request:Work_request</text>
          </ownedElement>
          <ownedElement xmi:id="ca29cf50-7cb5-0138-411c-418b172fba9f" xmi:uuid="ca29cfd0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-assigned_work_request"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1043" y="855" width="254" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_86431_57655" xmi:uuid="ca5b0610-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-items"/>
          <ownedElement xmi:id="ca49f990-7cb5-0138-411c-418b172fba9f" xmi:uuid="ca49fa20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-items"/>
            <text>items:affected_item_select</text>
          </ownedElement>
          <ownedElement xmi:id="ca5a7ec0-7cb5-0138-411c-418b172fba9f" xmi:uuid="ca5a7f30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1043" y="820" width="197" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1029" y="791" width="275" height="99"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_245864_57657" xmi:uuid="91380e80-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_789087_57566"/>
      <source xmi:idref="_18_4_1_271a0567_1577957207336_20475_57648"/>
      <target xmi:idref="_18_4_1_271a0567_1577957207336_800783_57641"/>
      <waypoint x="486" y="823"/>
      <waypoint x="672" y="823"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_102653_57658" xmi:uuid="91381720-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_28477_57567"/>
      <source xmi:idref="_18_4_1_271a0567_1577957207336_536817_57653"/>
      <target xmi:idref="_18_4_1_271a0567_1577957207336_800783_57641"/>
      <waypoint x="882" y="824"/>
      <waypoint x="832" y="824"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_432804_57659" xmi:uuid="91381ed0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_988358_57571"/>
      <source xmi:idref="_18_4_1_271a0567_1577957207336_885993_57647"/>
      <target xmi:idref="_18_4_1_271a0567_1577957207336_889521_57642"/>
      <waypoint x="566" y="858"/>
      <waypoint x="609" y="858"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_352838_57660" xmi:uuid="91382680-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_126077_57576"/>
      <source xmi:idref="_18_4_1_271a0567_1577957207336_3099_57652"/>
      <target xmi:idref="_18_4_1_271a0567_1577957207336_303616_57643"/>
      <waypoint x="928" y="879"/>
      <waypoint x="928" y="952"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_720615_57661" xmi:uuid="91382e40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_715017_57577"/>
      <source xmi:idref="_18_4_1_271a0567_1577957207336_571888_57651"/>
      <target xmi:idref="_18_4_1_271a0567_1577957207336_303616_57643"/>
      <waypoint x="726" y="967"/>
      <waypoint x="882" y="967"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_288822_57662" xmi:uuid="913836c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204313_218896_57578"/>
      <source xmi:idref="_18_4_1_271a0567_1577957207336_548795_57650"/>
      <target xmi:idref="_18_4_1_271a0567_1577957207336_303616_57643"/>
      <waypoint x="705" y="929"/>
      <waypoint x="907" y="929"/>
      <waypoint x="907" y="952"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957207336_280790_57663" xmi:uuid="91383ee0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957204328_481931_57582"/>
      <source xmi:idref="_18_4_1_271a0567_1577957207336_86431_57655"/>
      <target xmi:idref="_18_4_1_271a0567_1577957207336_17993_57644"/>
      <waypoint x="1043" y="831"/>
      <waypoint x="1013" y="831"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957300967_782978_58212" xmi:uuid="913846c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957302586_619168_58213"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_506472_55624"/>
      <target xmi:idref="_18_4_1_271a0567_1577956033201_13521_55395"/>
      <waypoint x="420" y="550"/>
      <waypoint x="212" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957375702_838936_58239" xmi:uuid="91384ea0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957378040_773440_58240"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_587344_55628"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_234306_55626"/>
      <waypoint x="1043" y="672"/>
      <waypoint x="480" y="672"/>
      <waypoint x="480" y="581"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957405314_152724_58263" xmi:uuid="91385610-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957407034_612557_58264"/>
      <source xmi:idref="_18_4_1_271a0567_1577957460442_816223_58312"/>
      <target xmi:idref="_18_4_1_271a0567_1577956100262_987966_55622"/>
      <waypoint x="819" y="550"/>
      <waypoint x="612" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957460442_309831_58311" xmi:uuid="9138b510-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957460442_215760_58309"/>
      <ownedElement xmi:id="ca6bea70-7cb5-0138-411c-418b172fba9f" xmi:uuid="ca6beb00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957460442_215760_58309"/>
        <text>defaultId1:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577957460442_816223_58312" xmi:uuid="91386470-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="ec820790-6c76-013d-d644-0800270c66d6" xmi:uuid="ec8208e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="765" y="535" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="819" y="544" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577957460442_411786_58314" xmi:uuid="91389a90-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="ec93a700-6c76-013d-d644-0800270c66d6" xmi:uuid="ec93a7e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="1006" y="534" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="988" y="543" width="15" height="15"/>
      </ownedElement>
      <bounds x="819" y="532" width="184" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957478716_633682_58365" xmi:uuid="9138c040-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957481067_855224_58366"/>
      <source xmi:idref="_18_4_1_271a0567_1577956712969_584850_56719"/>
      <target xmi:idref="_18_4_1_271a0567_1577957460442_411786_58314"/>
      <waypoint x="1344" y="550"/>
      <waypoint x="1003" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957499337_861935_58391" xmi:uuid="9138c9d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957502590_761581_58392"/>
      <source xmi:idref="_18_4_1_271a0567_1577956100262_928275_55601"/>
      <target xmi:idref="_18_4_1_271a0567_1577957254057_620183_58178"/>
      <waypoint x="1029" y="742"/>
      <waypoint x="189" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577957581505_955226_58453" xmi:uuid="9138d160-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577957583679_241018_58454"/>
      <source xmi:idref="_18_4_1_271a0567_1577957207336_113412_57646"/>
      <target xmi:idref="_18_4_1_271a0567_1577957537868_396489_58424"/>
      <waypoint x="392" y="896"/>
      <waypoint x="280" y="896"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1535" height="1003"/>
    <name>WorkRequest</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_271a0567_1577963956891_907332_57019" xmi:uuid="913af4a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkRequestAssignment"/>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964281078_950473_58529" xmi:uuid="913cba00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964281069_833701_58525"/>
      <bounds x="1178" y="847" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963969695_322336_57053" xmi:uuid="913d2050-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-AssignedTo"/>
      <ownedElement xmi:id="ca904600-7cb5-0138-411c-418b172fba9f" xmi:uuid="ca904720-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-AssignedTo"/>
        <text>AssignedTo:WorkRequestAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ca91e100-7cb5-0138-411c-418b172fba9f" xmi:uuid="ca91e150-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-AssignedTo"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577964037520_581311_57230" xmi:uuid="913cd350-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
        <ownedElement xmi:id="ecf1a070-6c76-013d-d644-0800270c66d6" xmi:uuid="ecf1a120-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
          <bounds x="346" y="914" width="149" height="13"/>
          <text>wras : affected_item_select [1]</text>
        </ownedElement>
        <bounds x="328" y="923" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="917" width="294" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577963969706_909165_57084" xmi:uuid="913d79d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-AssignedWorkRequest"/>
      <ownedElement xmi:id="ca9514d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="ca951520-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-AssignedWorkRequest"/>
        <text>AssignedWorkRequest:WorkRequest</text>
      </ownedElement>
      <ownedElement xmi:id="ca96b5f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="ca96b640-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkRequestAssignment-AssignedWorkRequest"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577964053133_478077_57244" xmi:uuid="913d4430-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956874270_39656_56914"/>
        <ownedElement xmi:id="ecfb4390-6c76-013d-d644-0800270c66d6" xmi:uuid="ecfb4790-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956874270_39656_56914"/>
          <bounds x="304" y="962" width="159" height="13"/>
          <text>workRequest : Work_request [1]</text>
        </ownedElement>
        <bounds x="286" y="971" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="966" width="252" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964024529_759929_57133" xmi:uuid="913da490-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964024518_366250_57129"/>
      <ownedElement xmi:id="caa838b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="caa83930-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964024518_366250_57129"/>
        <text>work_request_assignment:Affected_items_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="caaa0480-7cb5-0138-411c-418b172fba9f" xmi:uuid="caaa04d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964024518_366250_57129"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="ed3b2eb0-6c76-013d-d644-0800270c66d6" xmi:uuid="ed3b2f90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ed3d6e50-6c76-013d-d644-0800270c66d6" xmi:uuid="ed3d7040-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964024529_751695_57134" xmi:uuid="cadc6830-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-assigned_work_request"/>
          <ownedElement xmi:id="cacb15a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cacb1620-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-assigned_work_request"/>
            <text>assigned_work_request:Work_request</text>
          </ownedElement>
          <ownedElement xmi:id="cadbe100-7cb5-0138-411c-418b172fba9f" xmi:uuid="cadbe180-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-assigned_work_request"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="840" y="967" width="254" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964024529_734374_57135" xmi:uuid="cb0e2ff0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-items"/>
          <ownedElement xmi:id="cafc9720-7cb5-0138-411c-418b172fba9f" xmi:uuid="cafc9790-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-items"/>
            <text>items:affected_item_select</text>
          </ownedElement>
          <ownedElement xmi:id="cb0db310-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb0db390-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Affected_items_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="840" y="925" width="197" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="819" y="889" width="347" height="120"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107993_38241_57329" xmi:uuid="913dcc00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509987065721_230294_25388"/>
      <bounds x="490" y="21" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964174046_737895_58338" xmi:uuid="d77c3080-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964175905_278046_58339"/>
      <source xmi:idref="_18_4_1_271a0567_1577964024529_759929_57133"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_323456_57342"/>
      <waypoint x="847" y="889"/>
      <waypoint x="847" y="151"/>
      <waypoint x="694" y="151"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107993_201331_57330" xmi:uuid="913dd9c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101515_268413_57276"/>
      <ownedElement xmi:id="cb1f7df0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb1f7e70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101515_268413_57276"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cb2144e0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb214520-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101515_268413_57276"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="edce2330-6c76-013d-d644-0800270c66d6" xmi:uuid="edce2410-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="edd10870-6c76-013d-d644-0800270c66d6" xmi:uuid="edd10a00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_30004_57341" xmi:uuid="cb44b960-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="cb335390-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb335410-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="cb443260-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb4432e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="511" y="105" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_323456_57342" xmi:uuid="cb7663e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="cb64f860-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb64f8f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="cb75e290-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb75e430-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="511" y="140" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_882635_57343" xmi:uuid="cb9849b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="cb870d40-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb870dc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="cb97cac0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb97cb40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="511" y="175" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="77" width="294" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_380249_57331" xmi:uuid="913de450-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101517_584695_57277"/>
      <ownedElement xmi:id="cb9a84d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb9a8550-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101517_584695_57277"/>
        <text>theId1:String</text>
      </ownedElement>
      <ownedElement xmi:id="cb9c7400-7cb5-0138-411c-418b172fba9f" xmi:uuid="cb9c7480-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101517_584695_57277"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="301" y="175" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964179489_634954_58357" xmi:uuid="d7dd0830-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964184409_135098_58358"/>
      <source xmi:idref="_18_4_1_271a0567_1577964024529_759929_57133"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_111742_57344"/>
      <waypoint x="847" y="889"/>
      <waypoint x="847" y="263"/>
      <waypoint x="694" y="263"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_606319_57332" xmi:uuid="913deee0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
      <ownedElement xmi:id="cbba8820-7cb5-0138-411c-418b172fba9f" xmi:uuid="cbba88a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cbc94ac0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cbc94b40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="eefcecf0-6c76-013d-d644-0800270c66d6" xmi:uuid="eefcede0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="eefed8d0-6c76-013d-d644-0800270c66d6" xmi:uuid="eefeda20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_111742_57344" xmi:uuid="cbfba990-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="cbea1cd0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cbea1d50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="cbfb1e50-7cb5-0138-411c-418b172fba9f" xmi:uuid="cbfb1ed0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="511" y="252" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="224" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964189249_974373_58376" xmi:uuid="d83dec40-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964192491_495231_58377"/>
      <source xmi:idref="_18_4_1_271a0567_1577964024529_759929_57133"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_127796_57345"/>
      <waypoint x="847" y="889"/>
      <waypoint x="847" y="340"/>
      <waypoint x="695" y="340"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_403751_57333" xmi:uuid="913dfbc0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
      <ownedElement xmi:id="cc19ff70-7cb5-0138-411c-418b172fba9f" xmi:uuid="cc19fff0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cc28ad00-7cb5-0138-411c-418b172fba9f" xmi:uuid="cc28ad70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="efe3c390-6c76-013d-d644-0800270c66d6" xmi:uuid="efe3c4a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="efed8720-6c76-013d-d644-0800270c66d6" xmi:uuid="efed8900-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_127796_57345" xmi:uuid="cc5b3d10-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="cc49e610-7cb5-0138-411c-418b172fba9f" xmi:uuid="cc49e6a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="cc5abc50-7cb5-0138-411c-418b172fba9f" xmi:uuid="cc5abce0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="511" y="329" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="301" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_135212_57334" xmi:uuid="913e08d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
      <ownedElement xmi:id="cc79e8f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cc79e970-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="cc89a180-7cb5-0138-411c-418b172fba9f" xmi:uuid="cc89a240-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f067adb0-6c76-013d-d644-0800270c66d6" xmi:uuid="f067aea0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f069f480-6c76-013d-d644-0800270c66d6" xmi:uuid="f069f5c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_826037_57346" xmi:uuid="ccbcab60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="ccab46e0-7cb5-0138-411c-418b172fba9f" xmi:uuid="ccab47f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="ccbc2cd0-7cb5-0138-411c-418b172fba9f" xmi:uuid="ccbc2d50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="217" y="392" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="203" y="364" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964197303_798150_58395" xmi:uuid="d911a4e0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964201262_898059_58396"/>
      <source xmi:idref="_18_4_1_271a0567_1577964024529_759929_57133"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_993927_57348"/>
      <waypoint x="847" y="889"/>
      <waypoint x="847" y="431"/>
      <waypoint x="686" y="431"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_462802_57335" xmi:uuid="913e1510-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101518_424918_57278"/>
      <ownedElement xmi:id="cccdd420-7cb5-0138-411c-418b172fba9f" xmi:uuid="cccdd4a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101518_424918_57278"/>
        <text>smplDescAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cccfaee0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cccfaf40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101518_424918_57278"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f0e9e240-6c76-013d-d644-0800270c66d6" xmi:uuid="f0e9e330-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f0ebf5e0-6c76-013d-d644-0800270c66d6" xmi:uuid="f0ebf790-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_826458_57347" xmi:uuid="cd01d8c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="ccf0b390-7cb5-0138-411c-418b172fba9f" xmi:uuid="ccf0b410-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="cd015740-7cb5-0138-411c-418b172fba9f" xmi:uuid="cd0157b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="511" y="455" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_993927_57348" xmi:uuid="cd32f910-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="cd2180a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cd218120-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="cd327b40-7cb5-0138-411c-418b172fba9f" xmi:uuid="cd327bc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="511" y="420" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="392" width="287" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_57757_57336" xmi:uuid="913e2010-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101519_462122_57279"/>
      <ownedElement xmi:id="cd55fbb0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cd55fc30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101519_462122_57279"/>
        <text>descText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="cd57bce0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cd57bd20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101519_462122_57279"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f18eb6f0-6c76-013d-d644-0800270c66d6" xmi:uuid="f18eb7f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f190a470-6c76-013d-d644-0800270c66d6" xmi:uuid="f190a5b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_461334_57349" xmi:uuid="cd7b0860-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="cd697d00-7cb5-0138-411c-418b172fba9f" xmi:uuid="cd697d80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="cd7a88f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cd7a8960-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="315" y="546" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="301" y="518" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964204487_400785_58414" xmi:uuid="d9ac9640-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964211082_45095_58415"/>
      <source xmi:idref="_18_4_1_271a0567_1577964024529_759929_57133"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_152404_57350"/>
      <waypoint x="847" y="889"/>
      <waypoint x="847" y="627"/>
      <waypoint x="686" y="627"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_801849_57337" xmi:uuid="913e2ab0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
      <ownedElement xmi:id="cd9962d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cd996340-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cda80310-7cb5-0138-411c-418b172fba9f" xmi:uuid="cda80390-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="f1fb2780-6c76-013d-d644-0800270c66d6" xmi:uuid="f1fb2dd0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f1fc53b0-6c76-013d-d644-0800270c66d6" xmi:uuid="f1fc5520-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_152404_57350" xmi:uuid="cdda7cd0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="cdc8ff40-7cb5-0138-411c-418b172fba9f" xmi:uuid="cdc8ffc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="cdd9fd40-7cb5-0138-411c-418b172fba9f" xmi:uuid="cdd9fe40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="511" y="616" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="588" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964214439_767222_58433" xmi:uuid="da08fba0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964217290_901377_58434"/>
      <source xmi:idref="_18_4_1_271a0567_1577964024529_759929_57133"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_324298_57351"/>
      <waypoint x="847" y="889"/>
      <waypoint x="847" y="718"/>
      <waypoint x="695" y="718"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_409648_57338" xmi:uuid="913e3800-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
      <ownedElement xmi:id="cdf90fd0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cdf91050-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ce07f240-7cb5-0138-411c-418b172fba9f" xmi:uuid="ce07f360-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f2526420-6c76-013d-d644-0800270c66d6" xmi:uuid="f25264d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f2535990-6c76-013d-d644-0800270c66d6" xmi:uuid="f2535a70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_324298_57351" xmi:uuid="ce3a6820-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="ce28f770-7cb5-0138-411c-418b172fba9f" xmi:uuid="ce28f860-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ce39e370-7cb5-0138-411c-418b172fba9f" xmi:uuid="ce39e3e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="511" y="707" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="679" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964220447_801408_58452" xmi:uuid="da7f4b20-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964228601_922899_58453"/>
      <source xmi:idref="_18_4_1_271a0567_1577964024529_759929_57133"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_155373_57353"/>
      <waypoint x="847" y="889"/>
      <waypoint x="847" y="830"/>
      <waypoint x="688" y="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_543937_57339" xmi:uuid="913e4500-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101520_882901_57280"/>
      <ownedElement xmi:id="ce4bf270-7cb5-0138-411c-418b172fba9f" xmi:uuid="ce4bf300-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101520_882901_57280"/>
        <text>roleAsgn2:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ce4dc1b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="ce4dc200-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101520_882901_57280"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f284a7c0-6c76-013d-d644-0800270c66d6" xmi:uuid="f284a870-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f285c910-6c76-013d-d644-0800270c66d6" xmi:uuid="f285c9f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_758216_57352" xmi:uuid="ce7fc3b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="ce6e6f30-7cb5-0138-411c-418b172fba9f" xmi:uuid="ce6e6fb0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="ce7f4830-7cb5-0138-411c-418b172fba9f" xmi:uuid="ce7f48b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="504" y="784" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_155373_57353" xmi:uuid="ceb0cd80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="ce9fa0c0-7cb5-0138-411c-418b172fba9f" xmi:uuid="ce9fa140-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ceb05160-7cb5-0138-411c-418b172fba9f" xmi:uuid="ceb051e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="504" y="819" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_19_0_2_aec0217_1579102315431_836284_31836" xmi:uuid="ced31390-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="cec1ddb0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cec1de30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="ced29780-7cb5-0138-411c-418b172fba9f" xmi:uuid="ced29890-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="504" y="861" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="756" width="308" height="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_942365_57340" xmi:uuid="913e50d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101521_679438_57281"/>
      <ownedElement xmi:id="cee3fca0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cee3fd40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101521_679438_57281"/>
        <text>role:Class</text>
      </ownedElement>
      <ownedElement xmi:id="cee5c7f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cee5c840-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101521_679438_57281"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f2f4eb80-6c76-013d-d644-0800270c66d6" xmi:uuid="f2f4ec30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f2f5c5a0-6c76-013d-d644-0800270c66d6" xmi:uuid="f2f5c680-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577964107994_127297_57354" xmi:uuid="cf082f30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="cef72e80-7cb5-0138-411c-418b172fba9f" xmi:uuid="cef72f00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="cf07b140-7cb5-0138-411c-418b172fba9f" xmi:uuid="cf07b2f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="350" y="784" width="103" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_19_0_2_aec0217_1579102344309_406932_31884" xmi:uuid="cf297960-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="cf18b860-7cb5-0138-411c-418b172fba9f" xmi:uuid="cf18b8f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="cf28fbb0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cf28fc30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="357" y="819" width="82" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="343" y="756" width="117" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107995_607909_57355" xmi:uuid="913e5830-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101523_809873_57285"/>
      <source xmi:idref="_18_4_1_271a0567_1577964107994_882635_57343"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_380249_57331"/>
      <waypoint x="511" y="186"/>
      <waypoint x="441" y="186"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107995_274476_57356" xmi:uuid="913e5f60-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101523_255688_57293"/>
      <source xmi:idref="_18_4_1_271a0567_1577964107994_826458_57347"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_57757_57336"/>
      <waypoint x="567" y="480"/>
      <waypoint x="567" y="553"/>
      <waypoint x="488" y="553"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107995_835842_57357" xmi:uuid="913e6730-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101523_169276_57294"/>
      <source xmi:idref="_18_4_1_271a0567_1577964107994_826037_57346"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_57757_57336"/>
      <waypoint x="438" y="417"/>
      <waypoint x="438" y="518"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964107995_672634_57358" xmi:uuid="913e6ec0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964101524_820126_57301"/>
      <source xmi:idref="_18_4_1_271a0567_1577964107994_758216_57352"/>
      <target xmi:idref="_18_4_1_271a0567_1577964107994_942365_57340"/>
      <waypoint x="504" y="795"/>
      <waypoint x="460" y="795"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964138399_847159_58167" xmi:uuid="913e9660-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
      <ownedElement xmi:id="cf46d240-7cb5-0138-411c-418b172fba9f" xmi:uuid="cf46d2c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577964138399_200100_58170" xmi:uuid="913e7c40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="f34c6cf0-6c76-013d-d644-0800270c66d6" xmi:uuid="f34c6de0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="426" y="96" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="408" y="105" width="15" height="15"/>
      </ownedElement>
      <bounds x="273" y="91" width="150" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964138399_199677_58168" xmi:uuid="913ec320-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
      <ownedElement xmi:id="cf726ea0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cf727000-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577964138400_508746_58172" xmi:uuid="913eaa00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="f37b7650-6c76-013d-d644-0800270c66d6" xmi:uuid="f37b76f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="269" y="498" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="259" y="480" width="15" height="15"/>
      </ownedElement>
      <bounds x="196" y="441" width="220" height="54"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964138399_923749_58169" xmi:uuid="913ef1c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
      <ownedElement xmi:id="cf9e53b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cf9e5470-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
        <text>roleSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577964138400_806155_58174" xmi:uuid="913ed670-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="f3adcbd0-6c76-013d-d644-0800270c66d6" xmi:uuid="f3adcc80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="287" y="801" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="271" y="788" width="15" height="15"/>
      </ownedElement>
      <bounds x="98" y="777" width="188" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964154658_869765_58272" xmi:uuid="913efe30-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964156030_615892_58273"/>
      <source xmi:idref="_18_4_1_271a0567_1577964107994_30004_57341"/>
      <target xmi:idref="_18_4_1_271a0567_1577964138399_200100_58170"/>
      <waypoint x="511" y="112"/>
      <waypoint x="423" y="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964159941_843718_58294" xmi:uuid="913f0730-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964161917_314406_58295"/>
      <source xmi:idref="_18_4_1_271a0567_1577964107994_461334_57349"/>
      <target xmi:idref="_18_4_1_271a0567_1577964138400_508746_58172"/>
      <waypoint x="315" y="557"/>
      <waypoint x="266" y="557"/>
      <waypoint x="266" y="495"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964165434_136024_58316" xmi:uuid="913f0f70-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964166354_512718_58317"/>
      <source xmi:idref="_18_4_1_271a0567_1577964107994_127297_57354"/>
      <target xmi:idref="_18_4_1_271a0567_1577964138400_806155_58174"/>
      <waypoint x="350" y="795"/>
      <waypoint x="286" y="795"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964235297_786407_58471" xmi:uuid="913f1740-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964237030_639742_58472"/>
      <source xmi:idref="_18_4_1_271a0567_1577964024529_734374_57135"/>
      <target xmi:idref="_18_4_1_271a0567_1577964037520_581311_57230"/>
      <waypoint x="840" y="931"/>
      <waypoint x="343" y="931"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964241783_433280_58493" xmi:uuid="913f1d80-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964243463_483346_58494"/>
      <source xmi:idref="_18_4_1_271a0567_1577964024529_751695_57134"/>
      <target xmi:idref="_18_4_1_271a0567_1577964053133_478077_57244"/>
      <waypoint x="840" y="977"/>
      <waypoint x="301" y="977"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577964318855_429681_58554" xmi:uuid="913f2520-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964321058_538818_58555"/>
      <source xmi:idref="_18_4_1_271a0567_1577964281078_950473_58529"/>
      <target xmi:idref="_18_4_1_271a0567_1577964024529_759929_57133"/>
      <waypoint x="1178" y="854"/>
      <waypoint x="1043" y="854"/>
      <waypoint x="1043" y="889"/>
    </ownedElement>
    <ownedElement xmi:id="_19_0_2_aec0217_1579102304012_130009_31805" xmi:uuid="913f2fa0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579102304012_521487_31800"/>
      <ownedElement xmi:id="cfaf36c0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cfaf3740-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579102304012_521487_31800"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="cfb0e8a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="cfb0e8f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579102304012_521487_31800"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="294" y="861" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_19_0_2_aec0217_1579102331006_814123_31874" xmi:uuid="913f3760-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579102331711_509967_31875"/>
      <source xmi:idref="_19_0_2_aec0217_1579102315431_836284_31836"/>
      <target xmi:idref="_19_0_2_aec0217_1579102304012_130009_31805"/>
      <waypoint x="504" y="872"/>
      <waypoint x="456" y="872"/>
    </ownedElement>
    <ownedElement xmi:id="_19_0_2_aec0217_1579102355729_882337_31922" xmi:uuid="913f6ec0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579102357247_768291_31923"/>
      <source xmi:idref="_19_0_2_aec0217_1579102344309_406932_31884"/>
      <target xmi:idref="_18_4_1_271a0567_1577964138400_806155_58174"/>
      <waypoint x="357" y="830"/>
      <waypoint x="329" y="830"/>
      <waypoint x="329" y="795"/>
      <waypoint x="286" y="795"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1181" height="1024"/>
    <name>WorkRequestAssignment</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1518011784732_793523_32019" xmi:uuid="990c3837-1024-49ff-8a71-0e33859c7447" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkOrder"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1518011800529_189715_32052" xmi:uuid="912308f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-ClassifiedAs"/>
      <ownedElement xmi:id="bd028af0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd028b70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-ClassifiedAs"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="bd044290-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd044410-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-ClassifiedAs"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955006995_417132_52012" xmi:uuid="91226350-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="ddeee3a0-6c76-013d-d644-0800270c66d6" xmi:uuid="ddeee440-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="248" y="52" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="230" y="61" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="56" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1518011800545_954698_32083" xmi:uuid="91232040-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-Description"/>
      <ownedElement xmi:id="bd13b7f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd13b870-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-Description"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="bd157660-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd157710-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-Description"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="119" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1518011800576_105877_32114" xmi:uuid="91232e20-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-Id"/>
      <ownedElement xmi:id="bd247900-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd247980-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-Id"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="bd2621c0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd262200-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-Id"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="371" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1518011800576_994559_32145" xmi:uuid="9123b070-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-InResponseTo"/>
      <ownedElement xmi:id="bd28dea0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd28def0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-InResponseTo"/>
        <text>InResponseTo:WorkRequest</text>
      </ownedElement>
      <ownedElement xmi:id="bd2a7cc0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd2a7d00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-InResponseTo"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577958193851_406326_60839" xmi:uuid="91235270-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956874270_39656_56914"/>
        <ownedElement xmi:id="de0f1b20-6c76-013d-d644-0800270c66d6" xmi:uuid="de0f1bc0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956874270_39656_56914"/>
          <bounds x="256" y="486" width="159" height="13"/>
          <text>workRequest : Work_request [1]</text>
        </ownedElement>
        <bounds x="238" y="495" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="490" width="211" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1518011800607_330486_32176" xmi:uuid="9123c310-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-OrderType"/>
      <ownedElement xmi:id="bd39c070-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd39c100-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-OrderType"/>
        <text>OrderType:ClassSelect</text>
      </ownedElement>
      <ownedElement xmi:id="bd3b7ef0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd3b7f40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-OrderType"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="553" width="163" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1518011800623_871556_32207" xmi:uuid="912449a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-SameAs"/>
      <ownedElement xmi:id="bd4a42b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd4a4320-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-SameAs"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="bd4c01b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd4c01f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_2_attr_WorkOrder-SameAs"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955962284_962724_55221" xmi:uuid="9123d230-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="de43cf00-6c76-013d-d644-0800270c66d6" xmi:uuid="de43d000-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="185" y="702" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="167" y="711" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="707" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1518011863454_615802_32291" xmi:uuid="91245750-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1518011863438_410659_32287"/>
      <bounds x="1473" y="19" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959416_48143_50936" xmi:uuid="91246f30-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959144_913932_50804"/>
      <ownedElement xmi:id="bd5de010-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd5de090-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959144_913932_50804"/>
        <text>work_order:Work_order</text>
      </ownedElement>
      <ownedElement xmi:id="bd5fa370-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd5fa3c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959144_913932_50804"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="de8934c0-6c76-013d-d644-0800270c66d6" xmi:uuid="de8935b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="de8e6cd0-6c76-013d-d644-0800270c66d6" xmi:uuid="de8e6e20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_665857_50949" xmi:uuid="bd827a30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order-description"/>
          <ownedElement xmi:id="bd713780-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd713800-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="bd81f130-7cb5-0138-411c-418b172fba9f" xmi:uuid="bd81f1b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1239" y="126" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_525055_50950" xmi:uuid="bdb2b070-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order-in_response_to"/>
          <ownedElement xmi:id="bda1bd80-7cb5-0138-411c-418b172fba9f" xmi:uuid="bda1be00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order-in_response_to"/>
            <text>in_response_to:Work_request</text>
          </ownedElement>
          <ownedElement xmi:id="bdb22960-7cb5-0138-411c-418b172fba9f" xmi:uuid="bdb229e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order-in_response_to"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1239" y="490" width="215" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_190717_50951" xmi:uuid="bdd40b60-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order-name"/>
          <ownedElement xmi:id="bdc2fe40-7cb5-0138-411c-418b172fba9f" xmi:uuid="bdc2feb0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="bdd37df0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bdd37e70-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Work_order-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1246" y="364" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1218" y="49" width="243" height="483"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959419_217427_50971" xmi:uuid="c9bd2870-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959156_336291_50820"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959416_48143_50936"/>
      <target xmi:idref="_18_4_1_271a0567_1577954959417_323162_50952"/>
      <waypoint x="1218" y="88"/>
      <waypoint x="1143" y="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959416_534874_50937" xmi:uuid="91247ed0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959148_653764_50805"/>
      <ownedElement xmi:id="bde53f40-7cb5-0138-411c-418b172fba9f" xmi:uuid="bde54070-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959148_653764_50805"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bde70b00-7cb5-0138-411c-418b172fba9f" xmi:uuid="bde70b50-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959148_653764_50805"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="df3f1a10-6c76-013d-d644-0800270c66d6" xmi:uuid="df3f1ae0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="df3ffe50-6c76-013d-d644-0800270c66d6" xmi:uuid="df3fff60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_323162_50952" xmi:uuid="be1936d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="be0805b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="be080630-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="be18b820-7cb5-0138-411c-418b172fba9f" xmi:uuid="be18b8a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="77" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="49" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959419_622172_50972" xmi:uuid="ca0167e0-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959156_836096_50821"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959416_48143_50936"/>
      <target xmi:idref="_18_4_1_271a0567_1577954959417_64415_50953"/>
      <waypoint x="1218" y="196"/>
      <waypoint x="1134" y="196"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959416_811770_50938" xmi:uuid="91248de0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959149_323800_50806"/>
      <ownedElement xmi:id="be2adaa0-7cb5-0138-411c-418b172fba9f" xmi:uuid="be2adb20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959149_323800_50806"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="be2ca250-7cb5-0138-411c-418b172fba9f" xmi:uuid="be2ca290-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959149_323800_50806"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="df6ffae0-6c76-013d-d644-0800270c66d6" xmi:uuid="df6ffbc0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="df714d10-6c76-013d-d644-0800270c66d6" xmi:uuid="df714e00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_64415_50953" xmi:uuid="be5e6b00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="be4d5500-7cb5-0138-411c-418b172fba9f" xmi:uuid="be4d5670-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="be5decb0-7cb5-0138-411c-418b172fba9f" xmi:uuid="be5ded40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="182" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="154" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959419_816975_50973" xmi:uuid="ca9b5070-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959156_863897_50822"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959416_48143_50936"/>
      <target xmi:idref="_18_4_1_271a0567_1577954959417_802720_50955"/>
      <waypoint x="1218" y="263"/>
      <waypoint x="1187" y="263"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959416_94575_50939" xmi:uuid="9124a010-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959149_601867_50807"/>
      <ownedElement xmi:id="be7037d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="be703860-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959149_601867_50807"/>
        <text>li:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="be7207d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="be720820-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959149_601867_50807"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="dfa45c00-6c76-013d-d644-0800270c66d6" xmi:uuid="dfa45ca0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dfa53590-6c76-013d-d644-0800270c66d6" xmi:uuid="dfa536a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_5283_50954" xmi:uuid="be951c90-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="be83c310-7cb5-0138-411c-418b172fba9f" xmi:uuid="be83c380-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="be9499a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="be949a10-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="959" y="308" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_802720_50955" xmi:uuid="bec63c20-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="beb4dfe0-7cb5-0138-411c-418b172fba9f" xmi:uuid="beb4e060-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="bec5bf10-7cb5-0138-411c-418b172fba9f" xmi:uuid="bec5bf90-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="252" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_226183_50956" xmi:uuid="bef8f250-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="bee65110-7cb5-0138-411c-418b172fba9f" xmi:uuid="bee65190-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="bef87180-7cb5-0138-411c-418b172fba9f" xmi:uuid="bef87200-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="280" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="224" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959416_578560_50940" xmi:uuid="9124ab50-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959150_532854_50808"/>
      <ownedElement xmi:id="befaf500-7cb5-0138-411c-418b172fba9f" xmi:uuid="befaf570-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959150_532854_50808"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="befcd1a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="befcd200-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959150_532854_50808"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="718" y="308" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959419_637301_50974" xmi:uuid="cae55a60-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959157_23785_50823"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959416_48143_50936"/>
      <target xmi:idref="_18_4_1_271a0567_1577954959417_22622_50957"/>
      <waypoint x="1218" y="445"/>
      <waypoint x="1142" y="445"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959416_392329_50941" xmi:uuid="9124baa0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959150_921105_50809"/>
      <ownedElement xmi:id="bf0def90-7cb5-0138-411c-418b172fba9f" xmi:uuid="bf0df010-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959150_921105_50809"/>
        <text>ia:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bf0fb470-7cb5-0138-411c-418b172fba9f" xmi:uuid="bf0fb4b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959150_921105_50809"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e0156060-6c76-013d-d644-0800270c66d6" xmi:uuid="e0156100-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e01685c0-6c76-013d-d644-0800270c66d6" xmi:uuid="e0168700-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_22622_50957" xmi:uuid="bf4261e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="bf30a5c0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bf30a6e0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="bf41dc40-7cb5-0138-411c-418b172fba9f" xmi:uuid="bf41dcc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="434" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="406" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959419_224356_50975" xmi:uuid="cb816780-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959158_479733_50824"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959416_48143_50936"/>
      <target xmi:idref="_18_4_1_271a0567_1577954959418_183079_50959"/>
      <waypoint x="1362" y="532"/>
      <waypoint x="1362" y="627"/>
      <waypoint x="1143" y="627"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959416_492354_50942" xmi:uuid="9124cbc0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959151_11126_50810"/>
      <ownedElement xmi:id="bf53e180-7cb5-0138-411c-418b172fba9f" xmi:uuid="bf53e200-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959151_11126_50810"/>
        <text>ca1:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bf55bdb0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bf55be00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959151_11126_50810"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="e04c8bb0-6c76-013d-d644-0800270c66d6" xmi:uuid="e04c8e30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e04db4f0-6c76-013d-d644-0800270c66d6" xmi:uuid="e04db620-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_986346_50958" xmi:uuid="bf880dc0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="bf769320-7cb5-0138-411c-418b172fba9f" xmi:uuid="bf769390-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="bf878ea0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bf878f10-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="652" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959418_183079_50959" xmi:uuid="bfb933b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="bfa80320-7cb5-0138-411c-418b172fba9f" xmi:uuid="bfa803b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="bfb8b250-7cb5-0138-411c-418b172fba9f" xmi:uuid="bfb8b2d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="617" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959418_163929_50960" xmi:uuid="bfdabf00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="bfc9c650-7cb5-0138-411c-418b172fba9f" xmi:uuid="bfc9c6d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="bfda39d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bfda3a40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="959" y="581" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="553" width="249" height="134"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959416_572883_50943" xmi:uuid="9124d600-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959151_189581_50811"/>
      <ownedElement xmi:id="bfdcd200-7cb5-0138-411c-418b172fba9f" xmi:uuid="bfdcd340-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959151_189581_50811"/>
        <text>theClassificationRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="bfdec750-7cb5-0138-411c-418b172fba9f" xmi:uuid="bfdec7c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959151_189581_50811"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="672" y="581" width="258" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_338314_50944" xmi:uuid="9124e620-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959152_633027_50812"/>
      <ownedElement xmi:id="bfef69b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="bfef6a30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959152_633027_50812"/>
        <text>c:Class</text>
      </ownedElement>
      <ownedElement xmi:id="bff12620-7cb5-0138-411c-418b172fba9f" xmi:uuid="bff12670-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959152_633027_50812"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="e0c92720-6c76-013d-d644-0800270c66d6" xmi:uuid="e0c927d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e0c9e4a0-6c76-013d-d644-0800270c66d6" xmi:uuid="e0c9e570-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959418_408757_50961" xmi:uuid="c0134af0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="c00283a0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c00284b0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="c012c810-7cb5-0138-411c-418b172fba9f" xmi:uuid="c012c990-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="532" y="553" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959418_91376_50962" xmi:uuid="c034dbb0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="c023d230-7cb5-0138-411c-418b172fba9f" xmi:uuid="c023d2a0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="c0345d80-7cb5-0138-411c-418b172fba9f" xmi:uuid="c0345e00-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Times New Roman" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="532" y="581" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="518" y="525" width="124" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959419_393934_50976" xmi:uuid="cc279d80-3281-0139-a8d8-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959158_86664_50825"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959416_48143_50936"/>
      <target xmi:idref="_18_4_1_271a0567_1577954959418_975627_50963"/>
      <waypoint x="1362" y="532"/>
      <waypoint x="1362" y="732"/>
      <waypoint x="1182" y="732"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959417_659353_50945" xmi:uuid="9124f6a0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959152_242241_50813"/>
      <ownedElement xmi:id="c0461070-7cb5-0138-411c-418b172fba9f" xmi:uuid="c04610f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959152_242241_50813"/>
        <text>eii:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="c047dc30-7cb5-0138-411c-418b172fba9f" xmi:uuid="c047dc80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959152_242241_50813"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="e1092620-6c76-013d-d644-0800270c66d6" xmi:uuid="e1092710-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e10a3460-6c76-013d-d644-0800270c66d6" xmi:uuid="e10a3590-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1577954959418_975627_50963" xmi:uuid="c07af710-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="c06967d0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c06968d0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c07a6cb0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c07a6d40-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="721" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="693" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959418_151762_50968" xmi:uuid="9124fde0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959154_578134_50817"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959418_163929_50960"/>
      <target xmi:idref="_18_4_1_271a0567_1577954959416_572883_50943"/>
      <waypoint x="959" y="592"/>
      <waypoint x="930" y="592"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577954959419_180889_50970" xmi:uuid="91250510-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959155_418880_50819"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959417_5283_50954"/>
      <target xmi:idref="_18_4_1_271a0567_1577954959416_578560_50940"/>
      <waypoint x="959" y="322"/>
      <waypoint x="932" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955037131_959856_52103" xmi:uuid="91250f00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955039182_62233_52104"/>
      <source xmi:idref="_18_4_1_2b2015d_1518011863454_615802_32291"/>
      <target xmi:idref="_18_4_1_271a0567_1577954959416_48143_50936"/>
      <waypoint x="1473" y="25"/>
      <waypoint x="1341" y="25"/>
      <waypoint x="1341" y="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955329688_123607_54085" xmi:uuid="912517c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955334984_609408_54086"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959416_534874_50937"/>
      <target xmi:idref="_18_4_1_271a0567_1577955006995_417132_52012"/>
      <waypoint x="945" y="67"/>
      <waypoint x="245" y="67"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_955223_54123" xmi:uuid="9125bf50-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955358826_590564_54099"/>
      <ownedElement xmi:id="c08b7500-7cb5-0138-411c-418b172fba9f" xmi:uuid="c08b7580-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955358826_590564_54099"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_271390_54126" xmi:uuid="91252cc0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="e147f5d0-6c76-013d-d644-0800270c66d6" xmi:uuid="e147f680-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="331" y="115" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="385" y="124" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_238817_54128" xmi:uuid="91254af0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="e154bf10-6c76-013d-d644-0800270c66d6" xmi:uuid="e154bfe0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="632" y="118" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="614" y="127" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_212440_54130" xmi:uuid="91256bc0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="e1624670-6c76-013d-d644-0800270c66d6" xmi:uuid="e1624710-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="553" y="166" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="527" y="151" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_35150_54132" xmi:uuid="91258c20-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="e16d5ca0-6c76-013d-d644-0800270c66d6" xmi:uuid="e16d5d40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="416" y="169" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="406" y="151" width="15" height="15"/>
      </ownedElement>
      <bounds x="385" y="112" width="244" height="54"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_35130_54124" xmi:uuid="91261f20-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955358826_108900_54100"/>
      <ownedElement xmi:id="c09d8ea0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c09d8f10-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955358826_108900_54100"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="c09f5c30-7cb5-0138-411c-418b172fba9f" xmi:uuid="c09f5c80-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955358826_108900_54100"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_745436_54134" xmi:uuid="9125d550-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="e1850e10-6c76-013d-d644-0800270c66d6" xmi:uuid="e1850ec0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="682" y="163" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="678" y="185" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="182" width="189" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_19020_54125" xmi:uuid="91267b00-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955358826_810221_54101"/>
      <ownedElement xmi:id="c0aeef00-7cb5-0138-411c-418b172fba9f" xmi:uuid="c0aeef90-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955358826_810221_54101"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="c0b0bbe0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c0b0bc30-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955358826_810221_54101"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_292790_54136" xmi:uuid="91263590-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="e19dd3b0-6c76-013d-d644-0800270c66d6" xmi:uuid="e19dd450-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="570" y="276" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="552" y="285" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="385" y="280" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_560607_54140" xmi:uuid="91268870-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955358826_349437_54103"/>
      <source xmi:idref="_18_4_1_271a0567_1577955358857_212440_54130"/>
      <target xmi:idref="_18_4_1_271a0567_1577955358857_35130_54124"/>
      <waypoint x="536" y="166"/>
      <waypoint x="536" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955358857_536050_54141" xmi:uuid="912692c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955358826_283621_54107"/>
      <source xmi:idref="_18_4_1_271a0567_1577955358857_19020_54125"/>
      <target xmi:idref="_18_4_1_271a0567_1577955358857_35150_54132"/>
      <waypoint x="413" y="280"/>
      <waypoint x="413" y="166"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955387734_997443_54302" xmi:uuid="91269be0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955389541_12815_54303"/>
      <source xmi:idref="_18_4_1_271a0567_1577955358857_271390_54126"/>
      <target xmi:idref="_18_4_1_2b2015d_1518011800545_954698_32083"/>
      <waypoint x="385" y="130"/>
      <waypoint x="241" y="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955393164_649679_54321" xmi:uuid="9126b730-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955395177_685463_54322"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959417_665857_50949"/>
      <target xmi:idref="_18_4_1_271a0567_1577955358857_238817_54128"/>
      <waypoint x="1239" y="133"/>
      <waypoint x="629" y="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955420878_108771_54345" xmi:uuid="9126c270-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955429174_348111_54346"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959416_811770_50938"/>
      <target xmi:idref="_18_4_1_271a0567_1577955358857_745436_54134"/>
      <waypoint x="945" y="193"/>
      <waypoint x="693" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955460221_343389_54371" xmi:uuid="9126cb20-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955462928_248920_54372"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959417_226183_50956"/>
      <target xmi:idref="_18_4_1_271a0567_1577955358857_292790_54136"/>
      <waypoint x="959" y="294"/>
      <waypoint x="567" y="294"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955587981_630449_54587" xmi:uuid="91273410-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955587943_44011_54574"/>
      <ownedElement xmi:id="c0c16440-7cb5-0138-411c-418b172fba9f" xmi:uuid="c0c164c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955587943_44011_54574"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955587981_167258_54589" xmi:uuid="9126dca0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="e1b76cd0-6c76-013d-d644-0800270c66d6" xmi:uuid="e1b76d80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="331" y="367" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="385" y="376" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955587981_739482_54591" xmi:uuid="9126f890-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="e1c277b0-6c76-013d-d644-0800270c66d6" xmi:uuid="e1c27860-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="560" y="384" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="538" y="371" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955587981_21215_54593" xmi:uuid="912719b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="e1cd1f10-6c76-013d-d644-0800270c66d6" xmi:uuid="e1cd1fc0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="417" y="423" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="407" y="405" width="15" height="15"/>
      </ownedElement>
      <bounds x="385" y="364" width="168" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955587981_365354_54588" xmi:uuid="9127d630-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955587943_187817_54575"/>
      <ownedElement xmi:id="c0d31370-7cb5-0138-411c-418b172fba9f" xmi:uuid="c0d313f0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955587943_187817_54575"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="c0d4e3b0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c0d4e400-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955587943_187817_54575"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955587981_186786_54595" xmi:uuid="912760f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="e1e447a0-6c76-013d-d644-0800270c66d6" xmi:uuid="e1e44860-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="507" y="438" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="489" y="447" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="364" y="441" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955587981_662084_54598" xmi:uuid="9127eb20-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955587943_684791_54577"/>
      <source xmi:idref="_18_4_1_271a0567_1577955587981_365354_54588"/>
      <target xmi:idref="_18_4_1_271a0567_1577955587981_21215_54593"/>
      <waypoint x="413" y="441"/>
      <waypoint x="413" y="420"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955634130_481656_54712" xmi:uuid="912844f0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955634130_402135_54710"/>
      <ownedElement xmi:id="c0e55940-7cb5-0138-411c-418b172fba9f" xmi:uuid="c0e559c0-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955634130_402135_54710"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955634130_611889_54713" xmi:uuid="91280690-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="e1fbf960-6c76-013d-d644-0800270c66d6" xmi:uuid="e1fbfa10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="667" y="360" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="721" y="369" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955634130_541205_54715" xmi:uuid="912828d0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="e206f520-6c76-013d-d644-0800270c66d6" xmi:uuid="e206f5c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="902" y="359" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="884" y="368" width="15" height="15"/>
      </ownedElement>
      <bounds x="721" y="357" width="178" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955648601_254016_54766" xmi:uuid="91285280-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955650505_290308_54767"/>
      <source xmi:idref="_18_4_1_271a0567_1577955634130_611889_54713"/>
      <target xmi:idref="_18_4_1_271a0567_1577955587981_739482_54591"/>
      <waypoint x="721" y="378"/>
      <waypoint x="553" y="378"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955657292_998967_54788" xmi:uuid="91286890-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955659180_493431_54789"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959417_190717_50951"/>
      <target xmi:idref="_18_4_1_271a0567_1577955634130_541205_54715"/>
      <waypoint x="1246" y="375"/>
      <waypoint x="899" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955677452_801473_54812" xmi:uuid="91287780-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955680860_895617_54813"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959416_392329_50941"/>
      <target xmi:idref="_18_4_1_271a0567_1577955587981_186786_54595"/>
      <waypoint x="945" y="455"/>
      <waypoint x="504" y="455"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955697657_725091_54835" xmi:uuid="91288700-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955699260_125745_54836"/>
      <source xmi:idref="_18_4_1_271a0567_1577955587981_167258_54589"/>
      <target xmi:idref="_18_4_1_2b2015d_1518011800576_105877_32114"/>
      <waypoint x="385" y="382"/>
      <waypoint x="168" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955817068_877191_54984" xmi:uuid="9128ed60-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955817052_543185_54980"/>
      <ownedElement xmi:id="c0f7e1f0-7cb5-0138-411c-418b172fba9f" xmi:uuid="c0f7e270-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955817052_543185_54980"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955817068_673117_54986" xmi:uuid="912896b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="e22788c0-6c76-013d-d644-0800270c66d6" xmi:uuid="e2278960-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="468" y="546" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="450" y="555" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955817068_39053_54988" xmi:uuid="9128ae20-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
        <ownedElement xmi:id="e23382c0-6c76-013d-d644-0800270c66d6" xmi:uuid="e2338390-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
          <bounds x="219" y="548" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="273" y="557" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955817068_177360_54990" xmi:uuid="9128ce60-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
        <ownedElement xmi:id="e23f24a0-6c76-013d-d644-0800270c66d6" xmi:uuid="e23f2550-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
          <bounds x="334" y="598" width="54" height="13"/>
          <text>class [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="324" y="580" width="15" height="15"/>
      </ownedElement>
      <bounds x="273" y="539" width="192" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955817068_216073_54985" xmi:uuid="91295f50-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955817052_884863_54981"/>
      <ownedElement xmi:id="c10aa610-7cb5-0138-411c-418b172fba9f" xmi:uuid="c10aa690-7cb5-0138-411c-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955817052_884863_54981"/>
        <text>chooseType:ChooseClass</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955817068_798670_54992" xmi:uuid="91290790-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501864972579_247535_26926"/>
        <ownedElement xmi:id="e2596060-6c76-013d-d644-0800270c66d6" xmi:uuid="e2596140-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501864972579_247535_26926"/>
          <bounds x="571" y="621" width="42" height="13"/>
          <text>in2 [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="561" y="637" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955817068_796515_54994" xmi:uuid="91292740-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501864972579_849252_26928"/>
        <ownedElement xmi:id="e2684e10-6c76-013d-d644-0800270c66d6" xmi:uuid="e2684ec0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501864972579_849252_26928"/>
          <bounds x="417" y="645" width="42" height="13"/>
          <text>in1 [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="462" y="654" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1577955817068_420550_54996" xmi:uuid="91293ee0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501864972595_812760_26930"/>
        <ownedElement xmi:id="e276d420-6c76-013d-d644-0800270c66d6" xmi:uuid="e276d570-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501864972595_812760_26930"/>
          <bounds x="665" y="648" width="42" height="13"/>
          <text>class [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="647" y="657" width="15" height="15"/>
      </ownedElement>
      <bounds x="462" y="637" width="200" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955852369_517861_55116" xmi:uuid="912967b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955854003_817415_55117"/>
      <source xmi:idref="_18_4_1_271a0567_1577955817068_39053_54988"/>
      <target xmi:idref="_18_4_1_2b2015d_1518011800607_330486_32176"/>
      <waypoint x="273" y="564"/>
      <waypoint x="198" y="564"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955859583_314566_55135" xmi:uuid="912979b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955862052_586559_55136"/>
      <source xmi:idref="_18_4_1_271a0567_1577955817068_796515_54994"/>
      <target xmi:idref="_18_4_1_271a0567_1577955817068_177360_54990"/>
      <waypoint x="462" y="662"/>
      <waypoint x="333" y="662"/>
      <waypoint x="333" y="595"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955865815_987267_55157" xmi:uuid="912988c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955866834_454845_55158"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959418_408757_50961"/>
      <target xmi:idref="_18_4_1_271a0567_1577955817068_673117_54986"/>
      <waypoint x="532" y="564"/>
      <waypoint x="465" y="564"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955871242_461506_55176" xmi:uuid="912996c0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955873313_411914_55177"/>
      <source xmi:idref="_18_4_1_271a0567_1577955817068_798670_54992"/>
      <target xmi:idref="_18_4_1_271a0567_1577954959417_338314_50944"/>
      <waypoint x="567" y="637"/>
      <waypoint x="567" y="616"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955877685_443188_55195" xmi:uuid="91299d80-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955881176_118447_55196"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959417_986346_50958"/>
      <target xmi:idref="_18_4_1_271a0567_1577955817068_420550_54996"/>
      <waypoint x="959" y="665"/>
      <waypoint x="662" y="665"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577955971506_865887_55244" xmi:uuid="9129aa40-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577955973541_747058_55245"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959417_659353_50945"/>
      <target xmi:idref="_18_4_1_271a0567_1577955962284_962724_55221"/>
      <waypoint x="945" y="721"/>
      <waypoint x="182" y="721"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1577958565080_612618_60862" xmi:uuid="9129b7b0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577958567470_553873_60863"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959417_525055_50950"/>
      <target xmi:idref="_18_4_1_271a0567_1577958193851_406326_60839"/>
      <waypoint x="1239" y="504"/>
      <waypoint x="253" y="504"/>
    </ownedElement>
    <ownedElement xmi:id="_19_0_2_aec0217_1579101396856_840127_31386" xmi:uuid="9129bea0-3aa6-0138-3eec-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_19_0_2_aec0217_1579101399742_55852_31387"/>
      <source xmi:idref="_18_4_1_271a0567_1577954959418_91376_50962"/>
      <target xmi:idref="_18_4_1_271a0567_1577955817068_673117_54986"/>
      <waypoint x="532" y="592"/>
      <waypoint x="497" y="592"/>
      <waypoint x="497" y="564"/>
      <waypoint x="465" y="564"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1476" height="771"/>
    <name>WorkOrder</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446469480_986753_373570" xmi:uuid="d94f8d40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkRequestRelationship"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469512_371564_373602" xmi:uuid="d963cb40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965317609_474895_60490"/>
      <ownedElement xmi:id="d9608640-6c76-013d-d644-0800270c66d6" xmi:uuid="d9608740-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965317609_474895_60490"/>
        <text>work_request_relationship:Work_request_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d963b5a0-6c76-013d-d644-0800270c66d6" xmi:uuid="d963b770-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577965317609_474895_60490"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="323" height="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469529_615867_373636" xmi:uuid="d9652640-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="783" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469542_281995_373657" xmi:uuid="d9669850-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="783" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469559_745205_373678" xmi:uuid="d96804a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="783" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469572_954049_373699" xmi:uuid="d9691040-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="783" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469589_516382_373720" xmi:uuid="d96a4dc0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="783" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469600_362870_373741" xmi:uuid="d96b25c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="783" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469616_922636_373762" xmi:uuid="d96c5100-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="783" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469631_497318_373783" xmi:uuid="d96d6620-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="783" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469649_363127_373804" xmi:uuid="d96e92a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="783" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469662_209368_373825" xmi:uuid="d96f9550-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="783" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469677_285997_373846" xmi:uuid="d9707400-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="783" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469695_628103_373867" xmi:uuid="d9716060-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="783" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469713_167127_373888" xmi:uuid="d9723960-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="783" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469727_391083_373909" xmi:uuid="d9734fd0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="783" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469740_203635_373930" xmi:uuid="d9747e00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="783" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469759_14742_373951" xmi:uuid="d9755650-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="783" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469776_698391_373972" xmi:uuid="d9762d30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="783" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469834_828131_373994" xmi:uuid="d97733a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="783" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_307622_420986" xmi:uuid="d977aa40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156336606_54410_72175"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469529_615867_373636"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="62"/>
      <waypoint x="368" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_695220_420989" xmi:uuid="d977bc80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601666760_291151_349432"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469542_281995_373657"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="82"/>
      <waypoint x="368" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_645270_420992" xmi:uuid="d977d0b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156340193_570761_72195"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469559_745205_373678"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="102"/>
      <waypoint x="368" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_958490_420995" xmi:uuid="d977e0c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601666858_906071_349475"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469572_954049_373699"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="122"/>
      <waypoint x="368" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_949498_420998" xmi:uuid="d977e7b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156332977_780537_72155"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469589_516382_373720"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="142"/>
      <waypoint x="368" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_396793_421001" xmi:uuid="d977ed70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601666954_694219_349518"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469600_362870_373741"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="162"/>
      <waypoint x="368" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_83897_421004" xmi:uuid="d977f380-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601667026_234246_349540"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469616_922636_373762"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="182"/>
      <waypoint x="368" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_11752_421007" xmi:uuid="d977fa80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742759717_419570_102686"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469631_497318_373783"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="202"/>
      <waypoint x="368" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_298011_421010" xmi:uuid="d9780000-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156343786_835801_72215"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469649_363127_373804"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="222"/>
      <waypoint x="368" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_206395_421013" xmi:uuid="d97839a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601667147_191350_349604"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469662_209368_373825"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="242"/>
      <waypoint x="368" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_233138_421016" xmi:uuid="d9784100-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601667222_230397_349626"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469677_285997_373846"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="262"/>
      <waypoint x="368" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_268426_421019" xmi:uuid="d9784790-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156347357_581864_72235"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469695_628103_373867"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="282"/>
      <waypoint x="368" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_180792_421022" xmi:uuid="d97867a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156350771_50883_72255"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469713_167127_373888"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="302"/>
      <waypoint x="368" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_911866_421025" xmi:uuid="d9786da0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601667346_729964_349690"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469727_391083_373909"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="322"/>
      <waypoint x="368" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_956395_421028" xmi:uuid="d9787a20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601667423_755370_349712"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469740_203635_373930"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="342"/>
      <waypoint x="368" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_656803_421031" xmi:uuid="d9788b40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156329385_333985_72135"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469759_14742_373951"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="362"/>
      <waypoint x="368" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_705153_421034" xmi:uuid="d978a0c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742759852_906736_102702"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469776_698391_373972"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="382"/>
      <waypoint x="368" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515632_404424_421037" xmi:uuid="d978b060-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1727446469780_780592_373990"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469834_828131_373994"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469512_371564_373602"/>
      <waypoint x="783" y="402"/>
      <waypoint x="368" y="402"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="786" height="480"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446467469_300750_373128" xmi:uuid="ddae2e90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkOrderAssignment"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469147_295308_373160" xmi:uuid="ddc079b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860241_42521_51196"/>
      <ownedElement xmi:id="ddbdfbf0-6c76-013d-d644-0800270c66d6" xmi:uuid="ddbdfcd0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860241_42521_51196"/>
        <text>work_order_assignment:Directed_activity_items_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ddc05460-6c76-013d-d644-0800270c66d6" xmi:uuid="ddc056b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577962860241_42521_51196"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="359" height="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469164_723545_373194" xmi:uuid="ddc20c40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="797" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469176_705604_373215" xmi:uuid="ddc2fde0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="797" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469194_107551_373236" xmi:uuid="ddc40660-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="797" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469207_672697_373257" xmi:uuid="ddc4c910-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="797" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469221_259171_373278" xmi:uuid="ddc5b120-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="797" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469238_699505_373299" xmi:uuid="ddc6d8c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="797" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469252_225342_373320" xmi:uuid="ddc7aba0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="797" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469268_301914_373341" xmi:uuid="ddc87aa0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="797" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469284_842390_373362" xmi:uuid="ddc96ea0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="797" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469300_680165_373383" xmi:uuid="ddca2960-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="797" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469320_873700_373404" xmi:uuid="ddcb1600-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="797" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469339_772210_373425" xmi:uuid="ddcc2870-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="797" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469353_749143_373446" xmi:uuid="ddccef10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="797" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469366_477540_373467" xmi:uuid="ddcde4c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="797" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469384_558472_373488" xmi:uuid="ddcea210-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="797" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469400_735023_373509" xmi:uuid="ddcf87c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="797" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469412_411862_373530" xmi:uuid="ddd06550-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="797" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469471_894295_373552" xmi:uuid="ddd11890-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="797" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515590_862473_420824" xmi:uuid="ddd12a50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760508_672177_103115"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469164_723545_373194"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="62"/>
      <waypoint x="404" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515590_753034_420827" xmi:uuid="ddd130f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760539_479263_103131"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469176_705604_373215"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="82"/>
      <waypoint x="404" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515590_805848_420830" xmi:uuid="ddd13730-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760586_264431_103147"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469194_107551_373236"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="102"/>
      <waypoint x="404" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515590_987553_420833" xmi:uuid="ddd13dc0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760617_36590_103163"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469207_672697_373257"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="122"/>
      <waypoint x="404" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515590_157894_420836" xmi:uuid="ddd14450-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760680_680916_103179"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469221_259171_373278"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="142"/>
      <waypoint x="404" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515590_643330_420839" xmi:uuid="ddd14ae0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760711_944726_103195"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469238_699505_373299"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="162"/>
      <waypoint x="404" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515590_239139_420842" xmi:uuid="ddd15280-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601664918_492856_348098"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469252_225342_373320"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="182"/>
      <waypoint x="404" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_232993_420845" xmi:uuid="ddd15970-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760761_270999_103211"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469268_301914_373341"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="202"/>
      <waypoint x="404" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_604919_420848" xmi:uuid="ddd160e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760800_979568_103227"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469284_842390_373362"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="222"/>
      <waypoint x="404" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_390221_420851" xmi:uuid="ddd167b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155127621_143056_70498"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469300_680165_373383"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="242"/>
      <waypoint x="404" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_326450_420854" xmi:uuid="ddd1db20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155131406_433476_70518"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469320_873700_373404"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="262"/>
      <waypoint x="404" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_82272_420857" xmi:uuid="ddd1e4e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155134888_527894_70538"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469339_772210_373425"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="282"/>
      <waypoint x="404" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_613850_420860" xmi:uuid="ddd1eca0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601665099_881993_348225"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469353_749143_373446"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="302"/>
      <waypoint x="404" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_876441_420863" xmi:uuid="ddd1f2d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601665178_344978_348247"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469366_477540_373467"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="322"/>
      <waypoint x="404" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_741293_420866" xmi:uuid="ddd1fa30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760917_289278_103275"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469384_558472_373488"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="342"/>
      <waypoint x="404" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_646046_420869" xmi:uuid="ddd20040-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760948_72440_103291"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469400_735023_373509"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="362"/>
      <waypoint x="404" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_826708_420872" xmi:uuid="ddd20ec0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155256881_747567_70597"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469412_411862_373530"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="382"/>
      <waypoint x="404" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515591_88836_420875" xmi:uuid="ddd22250-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1727446469416_535899_373548"/>
      <source xmi:idref="_18_4_1_65b021e_1727446469471_894295_373552"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469147_295308_373160"/>
      <waypoint x="797" y="402"/>
      <waypoint x="404" y="402"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="800" height="480"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446469843_918227_374012" xmi:uuid="e279d9c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkOrder"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446469871_390211_374044" xmi:uuid="e2919d50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959144_913932_50804"/>
      <ownedElement xmi:id="e28f82b0-6c76-013d-d644-0800270c66d6" xmi:uuid="e28f83a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959144_913932_50804"/>
        <text>work_order:Work_order</text>
      </ownedElement>
      <ownedElement xmi:id="e2916ba0-6c76-013d-d644-0800270c66d6" xmi:uuid="e2916c80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577954959144_913932_50804"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="161" height="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472363_617588_374078" xmi:uuid="e2928a50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="538" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472384_165589_374099" xmi:uuid="e2935740-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="538" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472397_596571_374120" xmi:uuid="e2944bf0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="538" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472410_62123_374141" xmi:uuid="e295d2b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="538" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472429_35017_374162" xmi:uuid="e296ca50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="538" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472443_876608_374183" xmi:uuid="e297f700-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="538" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472464_947611_374204" xmi:uuid="e29f8c20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="538" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472483_14623_374225" xmi:uuid="e2a1e010-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="538" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472501_50531_374246" xmi:uuid="e2a421b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="538" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472519_403219_374267" xmi:uuid="e2a5edf0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="538" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472537_116187_374288" xmi:uuid="e2a78e00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="538" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472553_918920_374309" xmi:uuid="e2a94a00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="538" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472574_133728_374330" xmi:uuid="e2ab8490-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="538" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472598_681601_374351" xmi:uuid="e2ad18b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="538" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472614_496479_374372" xmi:uuid="e2b00d20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="538" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472630_820994_374393" xmi:uuid="e2c73a60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="538" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472648_363405_374414" xmi:uuid="e2c8e5c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="538" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472660_478909_374435" xmi:uuid="e2ca1bf0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643268851717_322008_86077"/>
      <bounds x="538" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472672_407260_374456" xmi:uuid="e2cc6bb0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643270131067_298147_86914"/>
      <bounds x="538" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472690_583241_374477" xmi:uuid="e2ce1f80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="538" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472705_12916_374498" xmi:uuid="e2cef720-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="538" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472718_879212_374519" xmi:uuid="e2d46430-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="538" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472731_411547_374540" xmi:uuid="e2d5fa40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="538" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472746_654188_374561" xmi:uuid="e2daed40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="538" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446472762_406595_374582" xmi:uuid="e2dd43a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="538" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515674_912061_421148" xmi:uuid="e2dd6070-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761623_393277_103673"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472363_617588_374078"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="62"/>
      <waypoint x="206" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515674_360899_421151" xmi:uuid="e2dd6920-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154879441_582329_70102"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472384_165589_374099"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="82"/>
      <waypoint x="206" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_686628_421154" xmi:uuid="e2dd8490-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154883043_468817_70122"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472397_596571_374120"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="102"/>
      <waypoint x="206" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_153707_421157" xmi:uuid="e2ddab00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154904453_261785_70182"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472410_62123_374141"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="122"/>
      <waypoint x="206" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_3267_421160" xmi:uuid="e2ddba20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154900131_844232_70162"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472429_35017_374162"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="142"/>
      <waypoint x="206" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_710342_421163" xmi:uuid="e2ddc690-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761669_824710_103689"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472443_876608_374183"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="162"/>
      <waypoint x="206" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_608665_421166" xmi:uuid="e2ddd300-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761716_766434_103705"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472464_947611_374204"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="182"/>
      <waypoint x="206" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_897975_421169" xmi:uuid="e2dddca0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761763_766143_103721"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472483_14623_374225"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="202"/>
      <waypoint x="206" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_165450_421172" xmi:uuid="e2dde6f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761826_821467_103737"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472501_50531_374246"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="222"/>
      <waypoint x="206" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_807047_421175" xmi:uuid="e2ddf230-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154870469_330071_70062"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472519_403219_374267"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="242"/>
      <waypoint x="206" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_772123_421178" xmi:uuid="e2ddfc60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761922_122529_103769"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472537_116187_374288"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="262"/>
      <waypoint x="206" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_887158_421181" xmi:uuid="e2de12e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154895873_282449_70142"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472553_918920_374309"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="282"/>
      <waypoint x="206" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_829729_421184" xmi:uuid="e2df9d00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154908864_518837_70202"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472574_133728_374330"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="302"/>
      <waypoint x="206" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_432523_421187" xmi:uuid="e2dfbdf0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154912677_286887_70222"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472598_681601_374351"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="322"/>
      <waypoint x="206" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_837555_421190" xmi:uuid="e2dfcaf0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154917053_178672_70242"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472614_496479_374372"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="342"/>
      <waypoint x="206" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_244582_421193" xmi:uuid="e2dff510-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154920948_984364_70262"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472630_820994_374393"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="362"/>
      <waypoint x="206" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_998100_421196" xmi:uuid="e2dfff70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761969_36324_103785"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472648_363405_374414"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="382"/>
      <waypoint x="206" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_596863_421199" xmi:uuid="e2e008f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154927039_908955_70282"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472660_478909_374435"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="402"/>
      <waypoint x="206" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_749303_421202" xmi:uuid="e2e01360-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154931316_463087_70302"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472672_407260_374456"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="422"/>
      <waypoint x="206" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_720522_421205" xmi:uuid="e2e01d10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742762016_933701_103801"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472690_583241_374477"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="442"/>
      <waypoint x="206" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_383943_421208" xmi:uuid="e2e03c00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742762047_260661_103817"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472705_12916_374498"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="462"/>
      <waypoint x="206" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_868385_421211" xmi:uuid="e2e05d90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742762078_688713_103833"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472718_879212_374519"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="482"/>
      <waypoint x="206" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_110840_421214" xmi:uuid="e2e06e50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742762125_658847_103849"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472731_411547_374540"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="502"/>
      <waypoint x="206" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_160256_421217" xmi:uuid="e2e08f70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154875443_666673_70082"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472746_654188_374561"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="522"/>
      <waypoint x="206" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515675_342918_421220" xmi:uuid="e2e0a990-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663154935111_449616_70322"/>
      <source xmi:idref="_18_4_1_65b021e_1727446472762_406595_374582"/>
      <target xmi:idref="_18_4_1_65b021e_1727446469871_390211_374044"/>
      <waypoint x="538" y="542"/>
      <waypoint x="206" y="542"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="541" height="620"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446462766_66390_371613" xmi:uuid="e6eca1c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkOrderRelationship"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462815_830562_371646" xmi:uuid="e700bc40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964549108_569686_59338"/>
      <ownedElement xmi:id="e6feb6a0-6c76-013d-d644-0800270c66d6" xmi:uuid="e6feb7c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964549108_569686_59338"/>
        <text>work_order_relationship:Work_order_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="e700a130-6c76-013d-d644-0800270c66d6" xmi:uuid="e700a210-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964549108_569686_59338"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="299" height="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462833_586367_371680" xmi:uuid="e701dd90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="720" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462848_743946_371701" xmi:uuid="e702f370-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="720" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462864_372085_371722" xmi:uuid="e703ec60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="720" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462878_472385_371743" xmi:uuid="e704fc50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="720" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462895_923794_371764" xmi:uuid="e70611f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="720" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462905_693241_371785" xmi:uuid="e70739e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="720" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462922_820462_371806" xmi:uuid="e7080640-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="720" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462938_594702_371827" xmi:uuid="e708f340-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="720" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462955_882896_371848" xmi:uuid="e709e600-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="720" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462967_474740_371869" xmi:uuid="e70aa160-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="720" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462981_467588_371890" xmi:uuid="e70b83f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="720" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446462999_651091_371911" xmi:uuid="e70c64f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="720" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463017_970777_371932" xmi:uuid="e70d1160-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="720" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463034_268025_371953" xmi:uuid="e70de3b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="720" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463050_483242_371974" xmi:uuid="e70edbd0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="720" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463067_251594_371995" xmi:uuid="e70fa5d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="720" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463083_335104_372016" xmi:uuid="e7105c30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="720" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463142_777861_372038" xmi:uuid="e71142a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="720" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515443_226200_420257" xmi:uuid="e7115490-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155425704_899850_70841"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462833_586367_371680"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="62"/>
      <waypoint x="344" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515443_418793_420260" xmi:uuid="e7115b90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601665904_779051_349004"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462848_743946_371701"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="82"/>
      <waypoint x="344" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515443_187343_420263" xmi:uuid="e71162b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155429362_89749_70861"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462864_372085_371722"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="102"/>
      <waypoint x="344" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515443_102712_420266" xmi:uuid="e7116940-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601666000_704849_349047"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462878_472385_371743"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="122"/>
      <waypoint x="344" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515443_166996_420269" xmi:uuid="e7117050-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155421956_912235_70821"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462895_923794_371764"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="142"/>
      <waypoint x="344" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515443_757895_420272" xmi:uuid="e71177b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601666096_4860_349090"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462905_693241_371785"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="162"/>
      <waypoint x="344" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515443_513407_420275" xmi:uuid="e7117ed0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601666175_5107_349112"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462922_820462_371806"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="182"/>
      <waypoint x="344" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_10042_420278" xmi:uuid="e7118620-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742759924_62198_102781"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462938_594702_371827"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="202"/>
      <waypoint x="344" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_300127_420281" xmi:uuid="e7118d50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155433095_433972_70881"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462955_882896_371848"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="222"/>
      <waypoint x="344" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_231692_420284" xmi:uuid="e7119410-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601666298_704382_349176"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462967_474740_371869"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="242"/>
      <waypoint x="344" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_869941_420287" xmi:uuid="e7119b30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601666373_226324_349198"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462981_467588_371890"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="262"/>
      <waypoint x="344" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_76869_420290" xmi:uuid="e711a190-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155436921_174440_70901"/>
      <source xmi:idref="_18_4_1_65b021e_1727446462999_651091_371911"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="282"/>
      <waypoint x="344" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_412091_420293" xmi:uuid="e711a870-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155440527_24360_70921"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463017_970777_371932"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="302"/>
      <waypoint x="344" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_198239_420296" xmi:uuid="e711af10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601666497_553226_349262"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463034_268025_371953"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="322"/>
      <waypoint x="344" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_665544_420299" xmi:uuid="e711b560-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601666573_710254_349284"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463050_483242_371974"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="342"/>
      <waypoint x="344" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_69287_420302" xmi:uuid="e711bb70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155416956_172928_70801"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463067_251594_371995"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="362"/>
      <waypoint x="344" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_288276_420305" xmi:uuid="e711d6d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155444885_441990_70941"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463083_335104_372016"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="382"/>
      <waypoint x="344" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515444_148769_420308" xmi:uuid="e71243e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1727446463086_782609_372034"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463142_777861_372038"/>
      <target xmi:idref="_18_4_1_65b021e_1727446462815_830562_371646"/>
      <waypoint x="720" y="402"/>
      <waypoint x="344" y="402"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="723" height="480"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446467022_92148_372498" xmi:uuid="eca2e240-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkRequest"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467051_809466_372530" xmi:uuid="ecc097b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956712953_4693_56713"/>
      <ownedElement xmi:id="ecbe0060-6c76-013d-d644-0800270c66d6" xmi:uuid="ecbe0150-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956712953_4693_56713"/>
        <text>work_request:Work_request</text>
      </ownedElement>
      <ownedElement xmi:id="ecc05a80-6c76-013d-d644-0800270c66d6" xmi:uuid="ecc05ba0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577956712953_4693_56713"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="185" height="590"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467063_720057_372564" xmi:uuid="ecc22610-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="615" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467082_369908_372585" xmi:uuid="ecc33970-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="615" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467093_470467_372606" xmi:uuid="ecc43490-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="615" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467104_955277_372627" xmi:uuid="ecc5e4f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="615" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467116_539507_372648" xmi:uuid="ecc6c300-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="615" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467133_730824_372669" xmi:uuid="ecc7d470-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="615" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467146_540959_372690" xmi:uuid="ecc8d9f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="615" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467159_475874_372711" xmi:uuid="ecc9f010-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="615" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467179_706739_372732" xmi:uuid="eccb4f00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="615" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467199_282307_372753" xmi:uuid="eccca0c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="615" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467218_242_372774" xmi:uuid="eccde080-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="615" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467236_310069_372795" xmi:uuid="eccf8ac0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="615" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467250_438623_372816" xmi:uuid="ecd0b940-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="615" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467271_140667_372837" xmi:uuid="ecd1f530-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="615" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467291_572806_372858" xmi:uuid="ecd32480-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="615" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467306_138842_372879" xmi:uuid="ecd46060-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="615" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467320_546712_372900" xmi:uuid="ecd563e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="615" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467338_200795_372921" xmi:uuid="ecd6bf40-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="615" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467349_546000_372942" xmi:uuid="ecd7de10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643268851717_322008_86077"/>
      <bounds x="615" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467360_89661_372963" xmi:uuid="ecd8f220-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643270131067_298147_86914"/>
      <bounds x="615" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467379_6340_372984" xmi:uuid="ecda3b50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="615" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467393_279201_373005" xmi:uuid="ecdb9480-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="615" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467407_827444_373026" xmi:uuid="ecdcaf00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="615" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467420_904560_373047" xmi:uuid="ecddd4b0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="615" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467432_317911_373068" xmi:uuid="ecdf0390-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="615" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467445_379596_373089" xmi:uuid="ece04160-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="615" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467460_354087_373110" xmi:uuid="ece17750-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="615" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_226506_420581" xmi:uuid="ece19670-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761016_438248_103370"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467063_720057_372564"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="62"/>
      <waypoint x="230" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_969884_420584" xmi:uuid="ece1a060-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761047_254150_103386"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467082_369908_372585"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="82"/>
      <waypoint x="230" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_27917_420587" xmi:uuid="ece1b240-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156002584_538472_71471"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467093_470467_372606"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="102"/>
      <waypoint x="230" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_247898_420590" xmi:uuid="ece1be80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156006309_198907_71491"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467104_955277_372627"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="122"/>
      <waypoint x="230" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_643068_420593" xmi:uuid="ece1c990-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156017119_907019_71551"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467116_539507_372648"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="142"/>
      <waypoint x="230" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_806615_420596" xmi:uuid="ece1d550-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156013827_73003_71531"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467133_730824_372669"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="162"/>
      <waypoint x="230" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_271813_420599" xmi:uuid="ece1df50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761094_933540_103402"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467146_540959_372690"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="182"/>
      <waypoint x="230" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_189994_420602" xmi:uuid="ece1ea60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761141_374722_103418"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467159_475874_372711"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="202"/>
      <waypoint x="230" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_898895_420605" xmi:uuid="ece1fb30-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761172_522102_103434"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467179_706739_372732"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="222"/>
      <waypoint x="230" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_550022_420608" xmi:uuid="ece205c0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761219_526626_103450"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467199_282307_372753"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="242"/>
      <waypoint x="230" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_591182_420611" xmi:uuid="ece22820-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155991910_745264_71411"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467218_242_372774"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="262"/>
      <waypoint x="230" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_217940_420614" xmi:uuid="ece24210-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761282_795982_103482"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467236_310069_372795"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="282"/>
      <waypoint x="230" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_525551_420617" xmi:uuid="ece24e50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156010170_866669_71511"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467250_438623_372816"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="302"/>
      <waypoint x="230" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_194685_420620" xmi:uuid="ece26110-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156020590_566040_71571"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467271_140667_372837"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="322"/>
      <waypoint x="230" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_658772_420623" xmi:uuid="ece26e70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156024264_532699_71591"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467291_572806_372858"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="342"/>
      <waypoint x="230" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_424749_420626" xmi:uuid="ece27750-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156029319_922888_71611"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467306_138842_372879"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="362"/>
      <waypoint x="230" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_284294_420629" xmi:uuid="ece28cc0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156032945_971492_71631"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467320_546712_372900"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="382"/>
      <waypoint x="230" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_77956_420632" xmi:uuid="ece29510-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761357_426017_103514"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467338_200795_372921"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="402"/>
      <waypoint x="230" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_331746_420635" xmi:uuid="ece29a20-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156036221_451979_71651"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467349_546000_372942"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="422"/>
      <waypoint x="230" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_857958_420638" xmi:uuid="ece2a110-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156040281_61233_71671"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467360_89661_372963"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="442"/>
      <waypoint x="230" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_212627_420641" xmi:uuid="ece2a8e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761404_56503_103530"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467379_6340_372984"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="462"/>
      <waypoint x="230" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_167560_420644" xmi:uuid="ece2b030-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761435_388358_103546"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467393_279201_373005"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="482"/>
      <waypoint x="230" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_219197_420647" xmi:uuid="ece2b770-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761482_588466_103562"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467407_827444_373026"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="502"/>
      <waypoint x="230" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_356748_420650" xmi:uuid="ece2bdf0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761513_204316_103578"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467420_904560_373047"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="522"/>
      <waypoint x="230" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_971206_420653" xmi:uuid="ece2d050-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742761560_797095_103594"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467432_317911_373068"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="542"/>
      <waypoint x="230" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_61196_420656" xmi:uuid="ece2e200-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155999106_460884_71451"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467445_379596_373089"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="562"/>
      <waypoint x="230" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515526_564533_420659" xmi:uuid="ece2e990-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663155995397_379435_71431"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467460_354087_373110"/>
      <target xmi:idref="_18_4_1_65b021e_1727446467051_809466_372530"/>
      <waypoint x="615" y="582"/>
      <waypoint x="230" y="582"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="618" height="660"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446463151_781213_372056" xmi:uuid="f3b64bb0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="WorkManagement.xmi#_WorkRequestAssignment"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463179_734615_372088" xmi:uuid="f3cb0220-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964024518_366250_57129"/>
      <ownedElement xmi:id="f3c8bc20-6c76-013d-d644-0800270c66d6" xmi:uuid="f3c8bcf0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964024518_366250_57129"/>
        <text>work_request_assignment:Affected_items_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f3caee00-6c76-013d-d644-0800270c66d6" xmi:uuid="f3caef60-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1577964024518_366250_57129"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="328" height="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463196_97100_372122" xmi:uuid="f3cc0340-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="783" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463209_173955_372143" xmi:uuid="f3ccfa10-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="783" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463229_902850_372164" xmi:uuid="f3cdfc00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="783" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463250_665706_372185" xmi:uuid="f3cf0ce0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="783" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463267_272143_372206" xmi:uuid="f3d018e0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="783" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446463285_336208_372227" xmi:uuid="f3d13450-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="783" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466757_124224_372248" xmi:uuid="f3d237d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="783" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466773_422423_372269" xmi:uuid="f3d348f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="783" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466792_255347_372290" xmi:uuid="f3d435f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="783" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466812_320404_372311" xmi:uuid="f3d53880-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="783" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466832_392159_372332" xmi:uuid="f3d67110-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="783" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466854_641899_372353" xmi:uuid="f3d777d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="783" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466874_980676_372374" xmi:uuid="f3d86d80-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="783" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466889_543894_372395" xmi:uuid="f3d94e90-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="783" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466906_358096_372416" xmi:uuid="f3da3050-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="783" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466926_55829_372437" xmi:uuid="f3db3fb0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="783" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446466946_564565_372458" xmi:uuid="f3dc43a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="783" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446467012_462529_372480" xmi:uuid="f3dd1fc0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="783" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515486_387044_420419" xmi:uuid="f3dd3300-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742759986_387470_102860"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463196_97100_372122"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="62"/>
      <waypoint x="373" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515486_334172_420422" xmi:uuid="f3dd4ad0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760033_223270_102876"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463209_173955_372143"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="82"/>
      <waypoint x="373" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515486_298119_420425" xmi:uuid="f3dd5820-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760080_133014_102892"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463229_902850_372164"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="102"/>
      <waypoint x="373" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515486_48410_420428" xmi:uuid="f3dd7020-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156171742_299802_71945"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463250_665706_372185"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="122"/>
      <waypoint x="373" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515486_283615_420431" xmi:uuid="f3dd7b70-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760127_940573_102908"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463267_272143_372206"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="142"/>
      <waypoint x="373" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515486_896862_420434" xmi:uuid="f3dd8270-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760158_244745_102924"/>
      <source xmi:idref="_18_4_1_65b021e_1727446463285_336208_372227"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="162"/>
      <waypoint x="373" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515486_116271_420437" xmi:uuid="f3dd8970-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760205_701274_102940"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466757_124224_372248"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="182"/>
      <waypoint x="373" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515486_904165_420440" xmi:uuid="f3dd9100-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601668265_96260_350616"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466773_422423_372269"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="202"/>
      <waypoint x="373" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515486_609133_420443" xmi:uuid="f3dd97f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760247_308760_102956"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466792_255347_372290"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="222"/>
      <waypoint x="373" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515487_168848_420446" xmi:uuid="f3dd9fa0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760273_198496_102972"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466812_320404_372311"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="242"/>
      <waypoint x="373" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515487_818953_420449" xmi:uuid="f3dda670-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156157333_269314_71865"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466832_392159_372332"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="262"/>
      <waypoint x="373" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515487_484652_420452" xmi:uuid="f3ddad50-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156160685_185772_71885"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466854_641899_372353"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="282"/>
      <waypoint x="373" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515487_533388_420455" xmi:uuid="f3ddb520-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_2b2015d_1663156164231_141379_71905"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466874_980676_372374"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="302"/>
      <waypoint x="373" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515487_8493_420458" xmi:uuid="f3ddbd00-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601668446_132087_350743"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466889_543894_372395"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="322"/>
      <waypoint x="373" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515487_511614_420461" xmi:uuid="f3ddc3a0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1696601668522_14952_350765"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466906_358096_372416"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="342"/>
      <waypoint x="373" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515487_908004_420464" xmi:uuid="f3ddc8f0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760398_560105_103020"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466926_55829_372437"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="362"/>
      <waypoint x="373" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515487_406220_420467" xmi:uuid="f3ddf3d0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_271a0567_1580742760445_408112_103036"/>
      <source xmi:idref="_18_4_1_65b021e_1727446466946_564565_372458"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="382"/>
      <waypoint x="373" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446515487_284012_420470" xmi:uuid="f3ddfbf0-6c76-013d-d644-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="WorkManagement.xmi#_18_4_1_65b021e_1727446466950_866392_372476"/>
      <source xmi:idref="_18_4_1_65b021e_1727446467012_462529_372480"/>
      <target xmi:idref="_18_4_1_65b021e_1727446463179_734615_372088"/>
      <waypoint x="783" y="402"/>
      <waypoint x="373" y="402"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="786" height="480"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
