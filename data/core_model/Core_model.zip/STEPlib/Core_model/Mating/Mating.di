<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1688564397455_812554_226827" xmi:uuid="2cab1240-0d30-013c-5e28-5b8e392dc4e5">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1688564028363_228816_178812"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1690212517823_613843_84457"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1688564397500_402771_226828" xmi:uuid="2d4357a0-0d30-013c-5e28-5b8e392dc4e5">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1688564028691_993183_178883"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1690212517823_613843_84457"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703184400906_131509_370871" xmi:uuid="78c70db0-9159-013c-7153-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703184400901_897753_370860"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1690212517823_613843_84457"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703184401196_922398_370991" xmi:uuid="78f1af40-9159-013c-7153-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703184401190_166415_370980"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1690212517823_613843_84457"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703184401526_779676_371163" xmi:uuid="79210fd0-9159-013c-7153-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703184401521_435556_371152"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1690212517823_613843_84457"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446292896_695811_276016" xmi:uuid="216937d0-6c42-013d-d601-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446292888_390429_276005"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028084_121207_178729"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446293122_13302_276320" xmi:uuid="2b03e950-6c42-013d-d601-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446293115_483193_276309"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028056_5845_178724"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564549963_58553_288975" xmi:uuid="2dc53410-0d30-013c-5e28-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564395866_996476_226613"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028084_121207_178729"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564549760_404275_288816" xmi:uuid="2dc71350-0d30-013c-5e28-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564394368_483642_226447"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028056_5845_178724"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564550031_143384_289013" xmi:uuid="2dc88580-0d30-013c-5e28-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564396315_463414_226691"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028096_324099_178734"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564549893_211443_288931" xmi:uuid="2dc95620-0d30-013c-5e28-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564395541_466413_226565"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028078_668575_178728"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564550084_297647_289049" xmi:uuid="2eacf030-0d30-013c-5e28-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564396900_276942_226738"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028109_381287_178740"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446294650_574539_278164" xmi:uuid="31ba8060-6c42-013d-d601-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446294643_650759_278153"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028096_324099_178734"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564549650_509323_288711" xmi:uuid="3252bf60-0d30-013c-5e28-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564393290_716781_226338"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028033_86160_178712"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564549730_772590_288799" xmi:uuid="32542fb0-0d30-013c-5e28-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564394050_545338_226408"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028049_734479_178723"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446293731_17431_277003" xmi:uuid="44fad210-6c42-013d-d601-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446293724_707581_276992"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028078_668575_178728"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446294457_684731_277981" xmi:uuid="766afd90-6c42-013d-d601-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446294450_148450_277970"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028109_381287_178740"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446294871_201569_278437" xmi:uuid="7d52fa40-6c42-013d-d601-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446294865_281911_278426"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028033_86160_178712"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446293309_799585_276623" xmi:uuid="83637e30-6c42-013d-d601-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446293302_375184_276612"/>
    <defaultNamespace href="Mating.xmi#_18_4_1_65b021e_1688564028049_734479_178723"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1688564028363_228816_178812" xmi:uuid="2caafe60-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1690212517823_613843_84457"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_472756_371333" xmi:uuid="2caf83f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028078_668575_178728"/>
      <ownedElement xmi:id="2cac4db0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cac4eb0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028078_668575_178728"/>
        <text>MatingDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="2cacb500-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cacb5e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="2caf0800-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2caf08f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2caf0b60-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2caf0be0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="2caf7e20-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2caf7f00-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393960_9880_226397"/>
          <text>MatingType</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="105" y="217" width="127" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_623114_371334" xmi:uuid="2cb1bfb0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028056_5845_178724"/>
      <ownedElement xmi:id="2cafe220-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cafe2c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028056_5845_178724"/>
        <text>AssemblyShapeJoint</text>
      </ownedElement>
      <ownedElement xmi:id="2cb02c40-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cb02cd0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="77" y="343" width="205" height="68"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_271599_371336" xmi:uuid="2cc4c5b0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028109_381287_178740"/>
      <ownedElement xmi:id="2cb23e80-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cb23f20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028109_381287_178740"/>
        <text>MatedPartRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="2cb28e80-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cb28f90-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="434" y="336" width="204" height="92"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_808597_371337" xmi:uuid="2cc8b850-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028049_734479_178723"/>
      <ownedElement xmi:id="2cc59510-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cc596e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028049_734479_178723"/>
        <text>MatedPartAssociation</text>
      </ownedElement>
      <ownedElement xmi:id="2cc665f0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cc66770-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="441" y="210" width="133" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_519255_371353" xmi:uuid="2cf721c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyDefinition"/>
      <ownedElement xmi:id="2cdd5770-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cdd5860-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyDefinition"/>
        <text>AssemblyDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="2ce10880-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2ce10980-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="77" y="70" width="175" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_424678_371355" xmi:uuid="2d025c70-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_NextAssemblyOccurrenceUsage"/>
      <ownedElement xmi:id="2cfaa9d0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cfaaaf0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_NextAssemblyOccurrenceUsage"/>
        <text>NextAssemblyOccurrenceUsage</text>
      </ownedElement>
      <ownedElement xmi:id="2cfdf490-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2cfdf7c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="406" y="70" width="175" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_652316_371357" xmi:uuid="2d25a580-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_DefinitionBasedOccurrence"/>
      <ownedElement xmi:id="2d064060-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d0641a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_DefinitionBasedOccurrence"/>
        <text>DefinitionBasedOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="2d098b60-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d098c60-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="441" y="490" width="175" height="45"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_542979_371362" xmi:uuid="2d3027b0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028064_608095_178725"/>
      <ownedElement xmi:id="2d2635b0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d263670-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028064_608095_178725"/>
        <text>MatingTypeEnum</text>
      </ownedElement>
      <ownedElement xmi:id="444fb500-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="444fb5d0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4450f9f0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="4450fb50-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394740_150425_226511"/>
          <text>bolted_joint</text>
        </ownedElement>
        <ownedElement xmi:id="4467a2e0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="4467a390-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394758_168133_226512"/>
          <text>brazing</text>
        </ownedElement>
        <ownedElement xmi:id="44689eb0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="44689f80-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394776_729_226513"/>
          <text>clasping</text>
        </ownedElement>
        <ownedElement xmi:id="446977d0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="44697860-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394794_32369_226514"/>
          <text>clinching</text>
        </ownedElement>
        <ownedElement xmi:id="446a6cf0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="446a6da0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394813_15109_226515"/>
          <text>clipping</text>
        </ownedElement>
        <ownedElement xmi:id="446b6a60-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="446b6b70-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394830_569900_226516"/>
          <text>doweling</text>
        </ownedElement>
        <ownedElement xmi:id="44cde3b0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="44cde4c0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394848_674730_226517"/>
          <text>flanging</text>
        </ownedElement>
        <ownedElement xmi:id="44e116a0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="44e11760-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394866_290695_226518"/>
          <text>foam_injection</text>
        </ownedElement>
        <ownedElement xmi:id="44e242b0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="44e24370-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394884_348725_226519"/>
          <text>gluing</text>
        </ownedElement>
        <ownedElement xmi:id="4507ee90-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="4507f070-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394902_952013_226520"/>
          <text>laser_welding</text>
        </ownedElement>
        <ownedElement xmi:id="45135a30-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="45135ae0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394921_589425_226521"/>
          <text>press_fit</text>
        </ownedElement>
        <ownedElement xmi:id="4523f530-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="4523f600-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394938_232548_226522"/>
          <text>riveting</text>
        </ownedElement>
        <ownedElement xmi:id="4540e0b0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="4540e2e0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394956_704002_226523"/>
          <text>sewing</text>
        </ownedElement>
        <ownedElement xmi:id="4562b740-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="4562b800-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394974_52306_226524"/>
          <text>spot_welding</text>
        </ownedElement>
        <ownedElement xmi:id="4563a940-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="4563aa20-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394992_873318_226525"/>
          <text>stapling</text>
        </ownedElement>
        <ownedElement xmi:id="45758a40-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="45758af0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395011_635978_226526"/>
          <text>welding</text>
        </ownedElement>
        <ownedElement xmi:id="45879550-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="45879640-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395029_946113_226527"/>
          <text>soldering</text>
        </ownedElement>
        <ownedElement xmi:id="45a49770-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="45a49830-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395048_335098_226528"/>
          <text>friction_welding</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="203" blue="255"/>
      </localStyle>
      <bounds x="763" y="336" width="87" height="276"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_500948_402269" xmi:uuid="2d319640-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028043_365635_178714"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_101834_371338" xmi:uuid="2d315590-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393796_397345_226382"/>
        <bounds x="285" y="346" width="54" height="12"/>
        <text>MatedShapes</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_877065_371339" xmi:uuid="2d3163c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393796_397345_226382"/>
        <bounds x="285" y="364" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_460781_371340" xmi:uuid="2d318f40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393795_171874_226381"/>
        <bounds x="409" y="364" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025939_271599_371336"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025939_623114_371334"/>
      <waypoint x="434" y="361"/>
      <waypoint x="282" y="361"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_491501_402270" xmi:uuid="2d3316a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028047_229556_178720"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_566326_371341" xmi:uuid="2d32bf90-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393916_698639_226393"/>
        <bounds x="428" y="286" width="35" height="12"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_145556_371342" xmi:uuid="2d32ea70-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393916_698639_226393"/>
        <bounds x="469" y="286" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_230353_371343" xmi:uuid="2d331230-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393914_592867_226392"/>
        <bounds x="469" y="321" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025939_271599_371336"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025939_808597_371337"/>
      <waypoint x="466" y="336"/>
      <waypoint x="466" y="273"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_617024_402271" xmi:uuid="2d346de0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028090_881551_178730"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_864810_371344" xmi:uuid="2d3434f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396169_59002_226676"/>
        <bounds x="516" y="276" width="31" height="12"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025939_408620_371345" xmi:uuid="2d3457f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396169_59002_226676"/>
        <bounds x="553" y="276" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025940_776192_371346" xmi:uuid="2d346910-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396168_157686_226675"/>
        <bounds x="553" y="321" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025939_271599_371336"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025939_808597_371337"/>
      <waypoint x="550" y="336"/>
      <waypoint x="550" y="273"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_933125_402272" xmi:uuid="2d35dd00-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028094_534474_178732"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025940_346601_371347" xmi:uuid="2d35ba50-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394163_818925_226432"/>
        <bounds x="245" y="223" width="35" height="12"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025940_759349_371348" xmi:uuid="2d35c7e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394163_818925_226432"/>
        <bounds x="245" y="241" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025940_227690_371350" xmi:uuid="2d35d100-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395664_364740_226596"/>
        <bounds x="392" y="223" width="46" height="12"/>
        <text>MatedParts</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025940_880255_371351" xmi:uuid="2d35d890-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395664_364740_226596"/>
        <bounds x="416" y="241" width="22" height="12"/>
        <text>2..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025939_808597_371337"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025939_472756_371333"/>
      <waypoint x="441" y="238"/>
      <waypoint x="232" y="238"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_602425_402273" xmi:uuid="2d3a26a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564263941_310258_210515"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_424678_371355"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025939_808597_371337"/>
      <waypoint x="501" y="119"/>
      <waypoint x="501" y="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_134408_402274" xmi:uuid="2d3e3010-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564267247_399583_211007"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_519255_371353"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025939_472756_371333"/>
      <waypoint x="172" y="119"/>
      <waypoint x="172" y="217"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_101165_402275" xmi:uuid="2d4244b0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028043_214251_178715"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_259818_371359" xmi:uuid="2d422a20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393820_979292_226384"/>
        <bounds x="466" y="475" width="67" height="12"/>
        <text>MatingMaterials</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_244803_371360" xmi:uuid="2d423320-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393820_979292_226384"/>
        <bounds x="539" y="475" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_321981_371361" xmi:uuid="2d423e60-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393819_70303_226383"/>
        <bounds x="539" y="431" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025939_271599_371336"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_652316_371357"/>
      <waypoint x="536" y="428"/>
      <waypoint x="536" y="490"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_440421_402276" xmi:uuid="2d4337c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028126_245349_178743"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_750357_371363" xmi:uuid="2d432600-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397105_884406_226787"/>
        <bounds x="710" y="360" width="50" height="12"/>
        <text>MatingType</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_193149_371364" xmi:uuid="2d433480-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397105_884406_226787"/>
        <bounds x="738" y="378" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025939_271599_371336"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_542979_371362"/>
      <waypoint x="638" y="375"/>
      <waypoint x="763" y="375"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="865" height="627"/>
    <name>Mating</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1688564028691_993183_178883" xmi:uuid="2d434960-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1690212517823_613843_84457"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_993612_371365" xmi:uuid="2d46ded0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028056_5845_178724"/>
      <ownedElement xmi:id="2d44ebe0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d44ecd0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028056_5845_178724"/>
        <text>AssemblyShapeJoint</text>
      </ownedElement>
      <ownedElement xmi:id="2d454050-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d4540f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="105" y="546" width="217" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_466608_371366" xmi:uuid="2d4ec1e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012336_933275_175542"/>
      <ownedElement xmi:id="2d4aaae0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d4aabe0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012336_933275_175542"/>
        <text>PartShapeElement</text>
      </ownedElement>
      <ownedElement xmi:id="2d4b6910-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d4b6f20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="14" y="49" width="192" height="45"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_326973_371368" xmi:uuid="2d51f9d0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028084_121207_178729"/>
      <ownedElement xmi:id="2d4f5610-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d4f5710-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028084_121207_178729"/>
        <text>AssemblyShapeConstraint</text>
      </ownedElement>
      <ownedElement xmi:id="2d4fbbb0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d4fbc70-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="105" y="210" width="217" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_667061_371370" xmi:uuid="2d54cf30-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028033_86160_178712"/>
      <ownedElement xmi:id="2d527c60-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d527d20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028033_86160_178712"/>
        <text>AssemblyShapeConstraintItemRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="2d5302e0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d5303f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="539" y="210" width="196" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_245237_371371" xmi:uuid="2d576590-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028096_324099_178734"/>
      <ownedElement xmi:id="2d554dd0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d555320-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028096_324099_178734"/>
        <text>AssemblyShapeJointItemRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="2d55c430-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d55c530-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="553" y="686" width="217" height="50"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_215715_371372" xmi:uuid="2d70ff30-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012316_936928_175541"/>
      <ownedElement xmi:id="2d5879d0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d587ac0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012316_936928_175541"/>
        <text>ShapeElementRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="2d5965f0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d5966f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="546" y="77" width="196" height="45"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_804822_371375" xmi:uuid="2d728e70-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028106_16710_178739"/>
      <ownedElement xmi:id="2d71a0b0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d71a1c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028106_16710_178739"/>
        <text>AssemblyDefinitionOrAssemblyShapeConstraintSelect</text>
      </ownedElement>
      <ownedElement xmi:id="f4cf0200-6c41-013d-d601-0800270c66d6" xmi:uuid="f4cf02a0-6c41-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="f4e1b640-6c41-013d-d601-0800270c66d6" xmi:uuid="f4e1b6c0-6c41-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize=""/>
      <bounds x="287" y="133" width="240" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_997356_371376" xmi:uuid="2d927bb0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyDefinition"/>
      <ownedElement xmi:id="2d769040-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d769150-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyDefinition"/>
        <text>AssemblyDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="2d7a89c0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d7a8ad0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="385" y="546" width="175" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_752075_371378" xmi:uuid="2d940050-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028091_26261_178731"/>
      <ownedElement xmi:id="2d931940-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d931a30-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028091_26261_178731"/>
        <text>AssemblyDefinitionOrAssemblyShapeJointSelect</text>
      </ownedElement>
      <ownedElement xmi:id="f7187b10-6c41-013d-d601-0800270c66d6" xmi:uuid="f7187ba0-6c41-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="f718e8a0-6c41-013d-d601-0800270c66d6" xmi:uuid="f718e8f0-6c41-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize=""/>
      <bounds x="298" y="455" width="216" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_153463_371381" xmi:uuid="2d99def0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028038_274051_178713"/>
      <ownedElement xmi:id="2d94aff0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d94b110-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028038_274051_178713"/>
        <text>AssemblyConstraintTypeEnum</text>
      </ownedElement>
      <ownedElement xmi:id="542da520-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="542da5c0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="54444c20-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="54444d30-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393515_652843_226368"/>
          <text>coaxial_assembly_constraint</text>
        </ownedElement>
        <ownedElement xmi:id="54602850-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="54602960-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393540_326047_226369"/>
          <text>complex</text>
        </ownedElement>
        <ownedElement xmi:id="548300f0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="548301c0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393574_763382_226370"/>
          <text>dimensioned_angle_assembly_constraint</text>
        </ownedElement>
        <ownedElement xmi:id="549ce2e0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="549ce3a0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393608_407531_226371"/>
          <text>dimensioned_parallel_assembly_constraint</text>
        </ownedElement>
        <ownedElement xmi:id="54af76e0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="54af7790-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393646_914856_226372"/>
          <text>dimensioned_surface_distance_assembly_constraint</text>
        </ownedElement>
        <ownedElement xmi:id="54e5e6a0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="54e5e770-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393664_7549_226373"/>
          <text>fixed_constituent_assembly_constraint</text>
        </ownedElement>
        <ownedElement xmi:id="5502bb10-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="5502bbc0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393687_333262_226374"/>
          <text>incidence_assembly_constraint</text>
        </ownedElement>
        <ownedElement xmi:id="5503c050-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="5503c370-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393708_125546_226375"/>
          <text>parallel_assembly_constraint</text>
        </ownedElement>
        <ownedElement xmi:id="551b9a20-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="551b9ad0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393730_634279_226376"/>
          <text>perpendicular_assembly_constraint</text>
        </ownedElement>
        <ownedElement xmi:id="551c8bd0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="551c8c80-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393751_807728_226377"/>
          <text>tangent_assembly_constraint</text>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="203" blue="255"/>
      </localStyle>
      <bounds x="301" y="273" width="213" height="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_726788_371382" xmi:uuid="2da26180-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028071_90096_178727"/>
      <ownedElement xmi:id="2d9a5a80-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2d9a5b60-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028071_90096_178727"/>
        <text>AssemblyJointTypeEnum</text>
      </ownedElement>
      <ownedElement xmi:id="55a5f760-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="55a5f800-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="55a6f000-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="55a6f140-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395103_407097_226534"/>
          <text>bolted_connection</text>
        </ownedElement>
        <ownedElement xmi:id="55c4e720-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="55c4e7f0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395121_803018_226535"/>
          <text>circular_compressed_crimped_connection</text>
        </ownedElement>
        <ownedElement xmi:id="55d41b90-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="55d41c50-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395138_440625_226536"/>
          <text>crimped_connection</text>
        </ownedElement>
        <ownedElement xmi:id="55f91f70-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="55f92080-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395157_248463_226537"/>
          <text>deep_indented_crimped_connection</text>
        </ownedElement>
        <ownedElement xmi:id="56174f40-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="56175000-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395175_904682_226538"/>
          <text>glued_connection</text>
        </ownedElement>
        <ownedElement xmi:id="562dd8d0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="562ddb00-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395193_938381_226539"/>
          <text>hexagonal_compressed_crimped_connection</text>
        </ownedElement>
        <ownedElement xmi:id="5653cbd0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="5653cdd0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395211_377668_226540"/>
          <text>insulation_displacement_connection</text>
        </ownedElement>
        <ownedElement xmi:id="566f8a60-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="566f8b20-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395228_352913_226541"/>
          <text>insulation_piercing_connection</text>
        </ownedElement>
        <ownedElement xmi:id="56891550-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="568916c0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395247_603759_226542"/>
          <text>promissory_connection</text>
        </ownedElement>
        <ownedElement xmi:id="56a8ffe0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="56a900a0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395265_419403_226543"/>
          <text>promissory_connection_for_higher_assembly</text>
        </ownedElement>
        <ownedElement xmi:id="56be7e10-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="56be7f10-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395283_724602_226544"/>
          <text>promissory_connection_for_installation_constraints</text>
        </ownedElement>
        <ownedElement xmi:id="56bf6d30-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="56bf6e20-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395301_346276_226545"/>
          <text>promissory_connection_for_missing_contributors</text>
        </ownedElement>
        <ownedElement xmi:id="56d8fe30-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="56d8fee0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395319_78115_226546"/>
          <text>push_connection</text>
        </ownedElement>
        <ownedElement xmi:id="56fa2040-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="56fa20e0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395336_999070_226547"/>
          <text>screwed_connection</text>
        </ownedElement>
        <ownedElement xmi:id="5713bed0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="5713c0b0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395354_836068_226548"/>
          <text>snap_connection</text>
        </ownedElement>
        <ownedElement xmi:id="5714b6d0-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="5714b790-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395373_351238_226549"/>
          <text>soldered_connection</text>
        </ownedElement>
        <ownedElement xmi:id="57312920-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="57312b50-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395392_343368_226550"/>
          <text>welded_connection</text>
        </ownedElement>
        <ownedElement xmi:id="574acc10-7e6d-013d-1a3b-0800270c66d6" xmi:uuid="574acce0-7e6d-013d-1a3b-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395409_186537_226551"/>
          <text>wrapped_connection</text>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="203" blue="255"/>
      </localStyle>
      <bounds x="35" y="637" width="214" height="243"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_371611_371383" xmi:uuid="2dab4460-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688563983869_75411_167058"/>
      <ownedElement xmi:id="2da69490-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2da69580-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688563983869_75411_167058"/>
        <text>OccurrenceShapeFeature</text>
      </ownedElement>
      <ownedElement xmi:id="2da76990-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2da76a90-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="560" y="406" width="140" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_821364_371385" xmi:uuid="2dac8f60-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028128_481358_178745"/>
      <ownedElement xmi:id="2dabb600-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2dabb7e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028128_481358_178745"/>
        <text>AssemblyShapeConstraintOrJointDefinitionSelect</text>
      </ownedElement>
      <ownedElement xmi:id="fe1f2270-6c41-013d-d601-0800270c66d6" xmi:uuid="fe1f22f0-6c41-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="fe281fe0-6c41-013d-d601-0800270c66d6" xmi:uuid="fe282070-6c41-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize=""/>
      <bounds x="28" y="355" width="218" height="22"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_616692_402277" xmi:uuid="2daddfb0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564317407_9764_217846"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_466608_371366"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_993612_371365"/>
      <waypoint x="18" y="221"/>
      <waypoint x="18" y="557"/>
      <waypoint x="105" y="557"/>
      <waypoint x="18" y="94"/>
      <waypoint x="18" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_316019_402278" xmi:uuid="2daf4120-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564317408_112621_217852"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_466608_371366"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_326973_371368"/>
      <waypoint x="105" y="210"/>
      <waypoint x="105" y="210"/>
      <waypoint x="18" y="94"/>
      <waypoint x="18" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_863964_402279" xmi:uuid="2db0a370-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564316147_507530_217709"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_215715_371372"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_245237_371371"/>
      <waypoint x="760" y="196"/>
      <waypoint x="760" y="686"/>
      <waypoint x="662" y="122"/>
      <waypoint x="662" y="196"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_948492_402280" xmi:uuid="2db20d20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564316147_594867_217707"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_215715_371372"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_667061_371370"/>
      <waypoint x="603" y="196"/>
      <waypoint x="603" y="210"/>
      <waypoint x="662" y="122"/>
      <waypoint x="662" y="196"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_449324_402281" xmi:uuid="2db31150-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028044_510625_178716"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_600454_371386" xmi:uuid="2db2fad0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393414_847747_226363"/>
        <bounds x="335" y="213" width="35" height="12"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025943_227784_371387" xmi:uuid="2db30ab0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393414_847747_226363"/>
        <bounds x="335" y="231" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_667061_371370"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_326973_371368"/>
      <waypoint x="539" y="228"/>
      <waypoint x="322" y="228"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_892924_402282" xmi:uuid="2db42150-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028070_685852_178726"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_547768_371389" xmi:uuid="2db40980-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395085_731524_226533"/>
        <bounds x="246" y="601" width="35" height="12"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_222261_371390" xmi:uuid="2db41550-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395085_731524_226533"/>
        <bounds x="287" y="601" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_245237_371371"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_993612_371365"/>
      <waypoint x="553" y="721"/>
      <waypoint x="284" y="721"/>
      <waypoint x="284" y="588"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_564644_402283" xmi:uuid="2db53020-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028048_712031_178721"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_73007_371392" xmi:uuid="2db51dc0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393937_42556_226395"/>
        <bounds x="72" y="340" width="58" height="12"/>
        <text>PartDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_986017_371393" xmi:uuid="2db52830-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393937_42556_226395"/>
        <bounds x="136" y="340" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_326973_371368"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_821364_371385"/>
      <waypoint x="133" y="252"/>
      <waypoint x="133" y="355"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_716220_402284" xmi:uuid="2db60a20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028104_946172_178737"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_162874_371395" xmi:uuid="2db5fdb0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394660_123219_226506"/>
        <bounds x="73" y="380" width="58" height="12"/>
        <text>PartDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_728948_371396" xmi:uuid="2db606e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394660_123219_226506"/>
        <bounds x="137" y="380" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_993612_371365"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_821364_371385"/>
      <waypoint x="134" y="546"/>
      <waypoint x="134" y="377"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_876257_402285" xmi:uuid="3ea33e90-3ed1-013c-a14c-4b23c1d46efd" xmi:type="umldi:UMLEdge">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_65b021e_1688564267247_744749_211006"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_804822_371375"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_997356_371376"/>
      <waypoint x="525" y="193"/>
      <waypoint x="525" y="546"/>
      <waypoint x="350" y="166"/>
      <waypoint x="350" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_206072_402286" xmi:uuid="2dbac870-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395758_274039_226602"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_326973_371368"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_804822_371375"/>
      <waypoint x="246" y="210"/>
      <waypoint x="246" y="193"/>
      <waypoint x="350" y="193"/>
      <waypoint x="350" y="166"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_182929_402287" xmi:uuid="2dbb9de0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394229_384370_226436"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_993612_371365"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_752075_371378"/>
      <waypoint x="242" y="546"/>
      <waypoint x="242" y="515"/>
      <waypoint x="312" y="515"/>
      <waypoint x="312" y="488"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_73168_402288" xmi:uuid="3ea900c0-3ed1-013c-a14c-4b23c1d46efd" xmi:type="umldi:UMLEdge">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_65b021e_1688564267247_500448_211008"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_752075_371378"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_997356_371376"/>
      <waypoint x="490" y="515"/>
      <waypoint x="490" y="546"/>
      <waypoint x="312" y="488"/>
      <waypoint x="312" y="515"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_278029_402289" xmi:uuid="2dc08300-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028045_240383_178718"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_435271_371398" xmi:uuid="2dc06c80-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393869_229806_226389"/>
        <bounds x="237" y="132" width="44" height="12"/>
        <text>ElementOf</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_662596_371399" xmi:uuid="2dc07e60-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393869_229806_226389"/>
        <bounds x="252" y="150" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_326973_371368"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_804822_371375"/>
      <waypoint x="172" y="210"/>
      <waypoint x="172" y="147"/>
      <waypoint x="287" y="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_263958_402290" xmi:uuid="2dc16b20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028102_739705_178735"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_634578_371401" xmi:uuid="2dc15a40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394681_421044_226507"/>
        <bounds x="241" y="454" width="44" height="12"/>
        <text>ElementOf</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_860572_371402" xmi:uuid="2dc167c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394681_421044_226507"/>
        <bounds x="263" y="472" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_993612_371365"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_752075_371378"/>
      <waypoint x="179" y="546"/>
      <waypoint x="179" y="469"/>
      <waypoint x="298" y="469"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_174461_402291" xmi:uuid="2dc23f70-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028125_999651_178741"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_947916_371404" xmi:uuid="2dc23450-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396109_1760_226671"/>
        <bounds x="235" y="276" width="63" height="12"/>
        <text>ConstraintType</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_119634_371405" xmi:uuid="2dc23c40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396109_1760_226671"/>
        <bounds x="266" y="294" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_326973_371368"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_153463_371381"/>
      <waypoint x="175" y="252"/>
      <waypoint x="175" y="291"/>
      <waypoint x="301" y="291"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_45602_402292" xmi:uuid="2dc339e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028126_61427_178742"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_342580_371406" xmi:uuid="2dc32710-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394641_734963_226505"/>
        <bounds x="69" y="622" width="41" height="12"/>
        <text>JointType</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_452725_371407" xmi:uuid="2dc33080-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394641_734963_226505"/>
        <bounds x="116" y="622" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_993612_371365"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_726788_371382"/>
      <waypoint x="113" y="588"/>
      <waypoint x="113" y="637"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_910691_402293" xmi:uuid="2dc42430-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028046_735435_178719"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_293042_371408" xmi:uuid="2dc41120-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393892_220466_226391"/>
        <bounds x="628" y="465" width="31" height="12"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_890371_371409" xmi:uuid="2dc41a70-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393892_220466_226391"/>
        <bounds x="665" y="465" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_245237_371371"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_371611_371383"/>
      <waypoint x="662" y="686"/>
      <waypoint x="662" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_155747_402294" xmi:uuid="2dc501f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028096_785166_178733"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_336440_371411" xmi:uuid="2dc4ed50-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393439_834309_226364"/>
        <bounds x="628" y="391" width="31" height="12"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025944_338694_371412" xmi:uuid="2dc4fa00-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393439_834309_226364"/>
        <bounds x="665" y="391" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025943_667061_371370"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025943_371611_371383"/>
      <waypoint x="662" y="252"/>
      <waypoint x="662" y="406"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="785" height="896"/>
    <name>AssemblyShapeConstraintAndJoint</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703184400901_897753_370860" xmi:uuid="78c67a90-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1690212517823_613843_84457"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184400952_913044_370893" xmi:uuid="78cbbd60-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028106_16710_178739"/>
      <ownedElement xmi:id="78c97a80-9159-013c-7153-0a5172f4a469" xmi:uuid="78c97b50-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028106_16710_178739"/>
        <text>AssemblyDefinitionOrAssemblyShapeConstraintSelect</text>
      </ownedElement>
      <ownedElement xmi:id="78ca8f20-9159-013c-7153-0a5172f4a469" xmi:uuid="78ca9030-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="78cb0520-9159-013c-7153-0a5172f4a469" xmi:uuid="78cb05d0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <bounds x="45" y="55" width="297" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184401157_757289_370939" xmi:uuid="78f08220-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyDefinition"/>
      <ownedElement xmi:id="78d0b4c0-9159-013c-7153-0a5172f4a469" xmi:uuid="78d0b5d0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyDefinition"/>
        <text>AssemblyDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="0389e6e0-6c42-013d-d601-0800270c66d6" xmi:uuid="0389e7b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="237" height="33"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="483" height="175"/>
    <name>AssemblyDefinitionOrAssemblyShapeConstraintSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703184401190_166415_370980" xmi:uuid="78f10e00-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1690212517823_613843_84457"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184401219_788177_371012" xmi:uuid="78f5e190-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028091_26261_178731"/>
      <ownedElement xmi:id="78f38f40-9159-013c-7153-0a5172f4a469" xmi:uuid="78f39050-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028091_26261_178731"/>
        <text>AssemblyDefinitionOrAssemblyShapeJointSelect</text>
      </ownedElement>
      <ownedElement xmi:id="78f4a6f0-9159-013c-7153-0a5172f4a469" xmi:uuid="78f4a830-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="78f52300-9159-013c-7153-0a5172f4a469" xmi:uuid="78f523d0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <bounds x="45" y="55" width="483" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184401414_354043_371058" xmi:uuid="791a9bb0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyDefinition"/>
      <ownedElement xmi:id="78fb11d0-9159-013c-7153-0a5172f4a469" xmi:uuid="78fb12e0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyDefinition"/>
        <text>AssemblyDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="063de170-6c42-013d-d601-0800270c66d6" xmi:uuid="063de1d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184401491_678529_371111" xmi:uuid="791fe150-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028056_5845_178724"/>
      <ownedElement xmi:id="791be3b0-9159-013c-7153-0a5172f4a469" xmi:uuid="791be4b0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028056_5845_178724"/>
        <text>AssemblyShapeJoint</text>
      </ownedElement>
      <ownedElement xmi:id="080356a0-6c42-013d-d601-0800270c66d6" xmi:uuid="08035720-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="322" y="95" width="166" height="33"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="543" height="175"/>
    <name>AssemblyDefinitionOrAssemblyShapeJointSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703184401521_435556_371152" xmi:uuid="79207a40-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1690212517823_613843_84457"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184401550_536015_371184" xmi:uuid="79252bb0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028128_481358_178745"/>
      <ownedElement xmi:id="7922fa10-9159-013c-7153-0a5172f4a469" xmi:uuid="7922fb10-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028128_481358_178745"/>
        <text>AssemblyShapeConstraintOrJointDefinitionSelect</text>
      </ownedElement>
      <ownedElement xmi:id="7923ff20-9159-013c-7153-0a5172f4a469" xmi:uuid="7923fff0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="79247350-9159-013c-7153-0a5172f4a469" xmi:uuid="79247400-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <bounds x="45" y="55" width="1164" height="153"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184401598_806036_371228" xmi:uuid="79307ff0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012336_933275_175542"/>
      <ownedElement xmi:id="79276ec0-9159-013c-7153-0a5172f4a469" xmi:uuid="79276fb0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012336_933275_175542"/>
        <text>PartShapeElement</text>
      </ownedElement>
      <ownedElement xmi:id="08d941f0-6c42-013d-d601-0800270c66d6" xmi:uuid="08d94280-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="261" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184401739_9139_371288" xmi:uuid="793cb230-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012394_880806_175565"/>
      <ownedElement xmi:id="79331260-9159-013c-7153-0a5172f4a469" xmi:uuid="79331370-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012394_880806_175565"/>
        <text>PartShapeElementRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="096076b0-6c42-013d-d601-0800270c66d6" xmi:uuid="09607740-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="346" y="95" width="261" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184402957_935435_371354" xmi:uuid="7969cab0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012298_32482_175540"/>
      <ownedElement xmi:id="793eee70-9159-013c-7153-0a5172f4a469" xmi:uuid="793ef020-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012298_32482_175540"/>
        <text>ShapeFeatureDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="0a1916e0-6c42-013d-d601-0800270c66d6" xmi:uuid="0a191770-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="627" y="95" width="261" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184403017_822399_371398" xmi:uuid="79730870-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012445_468478_175586"/>
      <ownedElement xmi:id="796c00a0-9159-013c-7153-0a5172f4a469" xmi:uuid="796c01b0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012445_468478_175586"/>
        <text>ShapeFeatureDefinitionElement</text>
      </ownedElement>
      <ownedElement xmi:id="0c0e6f70-6c42-013d-d601-0800270c66d6" xmi:uuid="0c0e7000-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="908" y="95" width="261" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184403149_21333_371460" xmi:uuid="797f68e0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012452_859387_175587"/>
      <ownedElement xmi:id="797556d0-9159-013c-7153-0a5172f4a469" xmi:uuid="797557e0-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012452_859387_175587"/>
        <text>ShapeFeatureDefinitionElementRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="0ca0a200-6c42-013d-d601-0800270c66d6" xmi:uuid="0ca0a2c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="143" width="261" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184404030_267937_371537" xmi:uuid="799e6540-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012368_615390_175557"/>
      <ownedElement xmi:id="7981a480-9159-013c-7153-0a5172f4a469" xmi:uuid="7981a590-9159-013c-7153-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564012368_615390_175557"/>
        <text>ShapeFeatureDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="0d420470-6c42-013d-d601-0800270c66d6" xmi:uuid="0d420500-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="346" y="143" width="261" height="33"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1224" height="223"/>
    <name>AssemblyShapeConstraintOrJointDefinitionSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446292888_390429_276005" xmi:uuid="21579450-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028084_121207_178729"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446292946_187099_276038" xmi:uuid="221970f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396128_454528_226672"/>
      <ownedElement xmi:id="2217e990-6c42-013d-d601-0800270c66d6" xmi:uuid="2217ea50-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396128_454528_226672"/>
        <text>assembly_shape_constraint:Assembly_shape_constraint</text>
      </ownedElement>
      <ownedElement xmi:id="22190b40-6c42-013d-d601-0800270c66d6" xmi:uuid="22190c30-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396128_454528_226672"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="338" height="370"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446292958_182239_276072" xmi:uuid="224f9180-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../AnnotatedModelPresentation/AnnotatedModelPresentation.xmi#_18_4_1_65b021e_1674590225569_36926_72230"/>
      <bounds x="1021" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446292966_505156_276087" xmi:uuid="22501200-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396499_54432_226725"/>
      <bounds x="1021" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446292975_48494_276102" xmi:uuid="22508d70-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1626444062384_160812_70113"/>
      <bounds x="1021" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446292983_982001_276117" xmi:uuid="226f8be0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397428_847441_226809"/>
      <bounds x="1021" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446292993_105415_276132" xmi:uuid="22700a00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1693389845452_895549_96322"/>
      <bounds x="1021" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293001_641073_276147" xmi:uuid="22891fb0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../GeometricDimensioningAndTolerancing/GeometricDimensioningAndTolerancing.xmi#_18_4_1_65b021e_1674590467120_965755_71727"/>
      <bounds x="1021" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293016_208644_276162" xmi:uuid="22989e30-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="1021" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293025_65238_276177" xmi:uuid="22991700-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../GeometricDimensioningAndTolerancing/GeometricDimensioningAndTolerancing.xmi#_18_4_1_65b021e_1674590466911_322671_71545"/>
      <bounds x="1021" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293038_534455_276192" xmi:uuid="229986a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="1021" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293047_358414_276207" xmi:uuid="22b72710-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564319079_782192_218094"/>
      <bounds x="1021" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293055_102161_276222" xmi:uuid="22b7a570-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317908_289960_217954"/>
      <bounds x="1021" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293064_329978_276237" xmi:uuid="22b81490-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317852_610905_217937"/>
      <bounds x="1021" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293079_915681_276252" xmi:uuid="22c80660-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="1021" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293089_774746_276267" xmi:uuid="22c8d680-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="1021" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293100_327651_276282" xmi:uuid="22df0f90-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="1021" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293109_230026_276297" xmi:uuid="22df8310-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317927_120586_217958"/>
      <bounds x="1021" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496340_535998_400685" xmi:uuid="22df9620-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377952_741097_249522"/>
      <source xmi:idref="_18_4_1_65b021e_1727446292958_182239_276072"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="62"/>
      <waypoint x="383" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496340_218705_400688" xmi:uuid="22df9cb0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396107_799852_226669"/>
      <source xmi:idref="_18_4_1_65b021e_1727446292966_505156_276087"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="82"/>
      <waypoint x="383" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496340_495340_400691" xmi:uuid="22dfa2a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378044_239415_249553"/>
      <source xmi:idref="_18_4_1_65b021e_1727446292975_48494_276102"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="102"/>
      <waypoint x="383" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496340_200006_400694" xmi:uuid="22dfa8b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378122_126377_249569"/>
      <source xmi:idref="_18_4_1_65b021e_1727446292983_982001_276117"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="122"/>
      <waypoint x="383" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496340_88659_400697" xmi:uuid="22dfae20-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378278_181119_249601"/>
      <source xmi:idref="_18_4_1_65b021e_1727446292993_105415_276132"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="142"/>
      <waypoint x="383" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496340_686921_400700" xmi:uuid="22dfb410-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378360_654161_249617"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293001_641073_276147"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="162"/>
      <waypoint x="383" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496340_43046_400703" xmi:uuid="22dfb9b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378440_950894_249633"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293016_208644_276162"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="182"/>
      <waypoint x="383" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496340_423582_400706" xmi:uuid="22dfbf40-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378523_199072_249649"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293025_65238_276177"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="202"/>
      <waypoint x="383" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496341_970860_400709" xmi:uuid="22dfc480-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378604_791852_249665"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293038_534455_276192"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="222"/>
      <waypoint x="383" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496341_114366_400712" xmi:uuid="22dfc9e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378764_87767_249697"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293047_358414_276207"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="242"/>
      <waypoint x="383" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496341_420024_400715" xmi:uuid="22dfd010-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378840_386412_249713"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293055_102161_276222"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="262"/>
      <waypoint x="383" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496341_514118_400718" xmi:uuid="22dfd5a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378919_235386_249729"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293064_329978_276237"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="282"/>
      <waypoint x="383" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496341_486146_400721" xmi:uuid="22dfdb90-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601378997_881172_249745"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293079_915681_276252"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="302"/>
      <waypoint x="383" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496341_58811_400724" xmi:uuid="22dfe0d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379076_879781_249761"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293089_774746_276267"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="322"/>
      <waypoint x="383" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496341_641806_400727" xmi:uuid="22dfe6d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379157_820900_249777"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293100_327651_276282"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="342"/>
      <waypoint x="383" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496341_786597_400730" xmi:uuid="22dfebf0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379232_399702_249793"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293109_230026_276297"/>
      <target xmi:idref="_18_4_1_65b021e_1727446292946_187099_276038"/>
      <waypoint x="1021" y="362"/>
      <waypoint x="383" y="362"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1024" height="440"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446293115_483193_276309" xmi:uuid="2b0359a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028056_5845_178724"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293138_58578_276341" xmi:uuid="2bbc7850-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394699_530693_226508"/>
      <ownedElement xmi:id="2ba2d6e0-6c42-013d-d601-0800270c66d6" xmi:uuid="2ba2d790-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394699_530693_226508"/>
        <text>shapeElement:Assembly_shape_joint</text>
      </ownedElement>
      <ownedElement xmi:id="2bbc60d0-6c42-013d-d601-0800270c66d6" xmi:uuid="2bbc6170-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394699_530693_226508"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="235" height="370"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293148_220501_276375" xmi:uuid="2bbcfa90-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../AnnotatedModelPresentation/AnnotatedModelPresentation.xmi#_18_4_1_65b021e_1674590225569_36926_72230"/>
      <bounds x="825" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293155_43680_276390" xmi:uuid="2bd44cd0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396188_204778_226677"/>
      <bounds x="825" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293163_323280_276405" xmi:uuid="2bd4c1d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1626444062384_160812_70113"/>
      <bounds x="825" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293172_271649_276420" xmi:uuid="2bd52a00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397428_847441_226809"/>
      <bounds x="825" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293181_907390_276435" xmi:uuid="2bf2a960-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1693389845452_895549_96322"/>
      <bounds x="825" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293190_551735_276450" xmi:uuid="2bf32300-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../GeometricDimensioningAndTolerancing/GeometricDimensioningAndTolerancing.xmi#_18_4_1_65b021e_1674590467120_965755_71727"/>
      <bounds x="825" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293204_544652_276465" xmi:uuid="2bf39040-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="825" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293212_751103_276480" xmi:uuid="2bf400d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../GeometricDimensioningAndTolerancing/GeometricDimensioningAndTolerancing.xmi#_18_4_1_65b021e_1674590466911_322671_71545"/>
      <bounds x="825" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293225_153989_276495" xmi:uuid="2c070580-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="825" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293233_837723_276510" xmi:uuid="2c267a10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564319079_782192_218094"/>
      <bounds x="825" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293242_685564_276525" xmi:uuid="2c271d30-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317908_289960_217954"/>
      <bounds x="825" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293250_589302_276540" xmi:uuid="2c2796c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317852_610905_217937"/>
      <bounds x="825" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293265_264819_276555" xmi:uuid="2c439aa0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="825" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293276_323884_276570" xmi:uuid="2c440b70-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="825" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293286_136604_276585" xmi:uuid="2c447d60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="825" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293296_738388_276600" xmi:uuid="2c450660-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317927_120586_217958"/>
      <bounds x="825" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_171595_400733" xmi:uuid="2c451990-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601371431_423893_248101"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293148_220501_276375"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="62"/>
      <waypoint x="280" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_361858_400736" xmi:uuid="2c452410-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394635_487110_226502"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293155_43680_276390"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="82"/>
      <waypoint x="280" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_795621_400739" xmi:uuid="2c452ab0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601371530_446816_248132"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293163_323280_276405"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="102"/>
      <waypoint x="280" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_226406_400742" xmi:uuid="2c4530e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601371613_232947_248148"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293172_271649_276420"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="122"/>
      <waypoint x="280" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_591202_400745" xmi:uuid="2c453930-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601371787_627058_248180"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293181_907390_276435"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="142"/>
      <waypoint x="280" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_157893_400748" xmi:uuid="2c453f60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601371871_742583_248196"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293190_551735_276450"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="162"/>
      <waypoint x="280" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_913990_400751" xmi:uuid="2c454530-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601371951_381404_248212"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293204_544652_276465"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="182"/>
      <waypoint x="280" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_695656_400754" xmi:uuid="2c454b10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372036_76074_248228"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293212_751103_276480"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="202"/>
      <waypoint x="280" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_516355_400757" xmi:uuid="2c455150-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372116_267437_248244"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293225_153989_276495"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="222"/>
      <waypoint x="280" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_112903_400760" xmi:uuid="2c455760-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372282_120576_248276"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293233_837723_276510"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="242"/>
      <waypoint x="280" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_662997_400763" xmi:uuid="2c455d60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372359_951154_248292"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293242_685564_276525"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="262"/>
      <waypoint x="280" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_469949_400766" xmi:uuid="2c456330-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372439_817750_248308"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293250_589302_276540"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="282"/>
      <waypoint x="280" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_560743_400769" xmi:uuid="2c456930-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372516_53483_248324"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293265_264819_276555"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="302"/>
      <waypoint x="280" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_109222_400772" xmi:uuid="2c457030-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372602_504932_248340"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293276_323884_276570"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="322"/>
      <waypoint x="280" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_520505_400775" xmi:uuid="2c4575c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372683_865416_248356"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293286_136604_276585"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="342"/>
      <waypoint x="280" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496347_66251_400778" xmi:uuid="2c457c80-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372763_74683_248372"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293296_738388_276600"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293138_58578_276341"/>
      <waypoint x="825" y="362"/>
      <waypoint x="280" y="362"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="828" height="440"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564395866_996476_226613" xmi:uuid="2dc51f90-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028084_121207_178729"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_325979_410823" xmi:uuid="d8b72790-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396099_636497_226665"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_473855_394341"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_49097_394332"/>
      <waypoint x="1057" y="259"/>
      <waypoint x="389" y="259"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_966277_394331" xmi:uuid="2dc5faf0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396109_1760_226671"/>
      <ownedElement xmi:id="d88df190-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d88df290-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396109_1760_226671"/>
        <text>ConstraintType:AssemblyConstraintTypeEnum</text>
      </ownedElement>
      <ownedElement xmi:id="d88e8f00-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d88e8fd0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396109_1760_226671"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="0ef3acc0-6c42-013d-d601-0800270c66d6" xmi:uuid="0ef3ad60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0ef412b0-6c42-013d-d601-0800270c66d6" xmi:uuid="0ef41310-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_49097_394332" xmi:uuid="d8b6e430-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393774_877672_226379"/>
          <ownedElement xmi:id="d8b5e770-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d8b5e880-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393774_877672_226379"/>
            <text>arm_mapping:assembly_constraint_type_enumeration</text>
          </ownedElement>
          <ownedElement xmi:id="d8b69230-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d8b69300-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393774_877672_226379"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="51" y="247" width="338" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="217" width="361" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_8560_394333" xmi:uuid="2dc5fdd0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393937_42556_226395"/>
      <ownedElement xmi:id="d8b8e490-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d8b8e5c0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393937_42556_226395"/>
        <text>PartDefinition:AssemblyShapeConstraintOrJointDefinitionSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d8b98bd0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d8b98ce0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393937_42556_226395"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_484622_394334" xmi:uuid="d8ba8980-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397428_847441_226809"/>
        <ownedElement xmi:id="1a538000-6c42-013d-d601-0800270c66d6" xmi:uuid="1a5381d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397428_847441_226809"/>
          <bounds x="456" y="104" width="524" height="13"/>
          <text>assemblyShapeConstraintOrJointDefinitionSelect : assembly_shape_constraint_or_joint_definition_select [1]</text>
        </ownedElement>
        <bounds x="433" y="116" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="112" width="406" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_899930_394336" xmi:uuid="2dc600d0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393869_229806_226389"/>
      <ownedElement xmi:id="d8bbf350-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d8bbf4a0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393869_229806_226389"/>
        <text>ElementOf:AssemblyDefinitionOrAssemblyShapeConstraintSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d8bca4c0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d8bca5f0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393869_229806_226389"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_594075_394337" xmi:uuid="d8bded90-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396499_54432_226725"/>
        <ownedElement xmi:id="1aa8d9e0-6c42-013d-d601-0800270c66d6" xmi:uuid="1aa8da70-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396499_54432_226725"/>
          <bounds x="455" y="160" width="542" height="13"/>
          <text>assemblyDefinitionOrAssemblyShapeConstraintSelect : assembly_definition_or_assembly_shape_constraint [1]</text>
        </ownedElement>
        <bounds x="433" y="170" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="168" width="406" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_727835_394339" xmi:uuid="2dc602d0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396128_454528_226672"/>
      <ownedElement xmi:id="d8ca9130-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d8ca9890-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396128_454528_226672"/>
        <text>assembly_shape_constraint:Assembly_shape_constraint</text>
      </ownedElement>
      <ownedElement xmi:id="d8cb5230-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d8cb5350-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396128_454528_226672"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="1b6126c0-6c42-013d-d601-0800270c66d6" xmi:uuid="1b612750-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="1b618880-6c42-013d-d601-0800270c66d6" xmi:uuid="1b618900-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_36827_394340" xmi:uuid="d8f2aba0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint-associated_definition"/>
          <ownedElement xmi:id="d8e492f0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d8e49440-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint-associated_definition"/>
            <text>associated_definition:assembly_definition_or_assembly_shape_constraint</text>
          </ownedElement>
          <ownedElement xmi:id="d8f24890-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d8f24b50-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint-associated_definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1057" y="161" width="449" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_473855_394341" xmi:uuid="d917d410-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint-constraint_type"/>
          <ownedElement xmi:id="d90af440-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d90af5c0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint-constraint_type"/>
            <text>constraint_type:assembly_constraint_type_enumeration</text>
          </ownedElement>
          <ownedElement xmi:id="d9178c60-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9178dc0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint-constraint_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1057" y="245" width="360" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_565153_394342" xmi:uuid="d93d8b50-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint-definition"/>
          <ownedElement xmi:id="d9306b00-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9306c60-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint-definition"/>
            <text>definition:assembly_shape_constraint_or_joint_definition_select</text>
          </ownedElement>
          <ownedElement xmi:id="d93d3cb0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d93d3dc0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint-definition"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1057" y="112" width="405" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1043" y="42" width="470" height="238"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_778854_410824" xmi:uuid="2dc60c90-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026957_631266_411917"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_727835_394339"/>
      <waypoint x="1017" y="63"/>
      <waypoint x="1043" y="73"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_981450_410825" xmi:uuid="2dc61820-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396101_739800_226666"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_565153_394342"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_484622_394334"/>
      <waypoint x="1057" y="123"/>
      <waypoint x="448" y="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_131294_410826" xmi:uuid="2dc61fb0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396103_275434_226667"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_36827_394340"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_594075_394337"/>
      <waypoint x="1057" y="179"/>
      <waypoint x="448" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_608218_410827" xmi:uuid="2dc62750-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396105_121692_226668"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_727835_394339"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_616602_394344"/>
      <waypoint x="1513" y="53"/>
      <waypoint x="1525" y="53"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026957_631266_411917" xmi:uuid="2dc63600-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="2dc630a0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2dc63130-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from PartShapeElement</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="917" y="21" width="100" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_616602_394344" xmi:uuid="2dc63d40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396147_307500_226673"/>
      <bounds x="1525" y="44" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1528" height="302"/>
    <name>AssemblyShapeConstraint</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564394368_483642_226447" xmi:uuid="2dc6e070-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028056_5845_178724"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_559986_394299" xmi:uuid="2dc793c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394660_123219_226506"/>
      <ownedElement xmi:id="d9413cc0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9413d80-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394660_123219_226506"/>
        <text>PartDefinition:AssemblyShapeConstraintOrJointDefinitionSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d9421460-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9421580-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394660_123219_226506"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_229008_394300" xmi:uuid="d9431330-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397428_847441_226809"/>
        <ownedElement xmi:id="233c2bb0-6c42-013d-d601-0800270c66d6" xmi:uuid="233c2c40-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397428_847441_226809"/>
          <bounds x="352" y="84" width="524" height="13"/>
          <text>assemblyShapeConstraintOrJointDefinitionSelect : assembly_shape_constraint_or_joint_definition_select [1]</text>
        </ownedElement>
        <bounds x="433" y="101" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="98" width="406" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_78202_394302" xmi:uuid="2dc79630-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394681_421044_226507"/>
      <ownedElement xmi:id="d9440150-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9440250-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394681_421044_226507"/>
        <text>ElementOf:AssemblyDefinitionOrAssemblyShapeJointSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d944afd0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d944b120-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394681_421044_226507"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_483213_394303" xmi:uuid="d945bc30-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396188_204778_226677"/>
        <ownedElement xmi:id="235fe970-6c42-013d-d601-0800270c66d6" xmi:uuid="235fea10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396188_204778_226677"/>
          <bounds x="361" y="140" width="486" height="13"/>
          <text>assemblyDefinitionOrAssemblyShapeJointSelect : assembly_definition_or_assembly_shape_joint [1]</text>
        </ownedElement>
        <bounds x="395" y="158" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="154" width="368" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_366351_410811" xmi:uuid="d95629b0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394639_95656_226503"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_186455_394310"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_827678_394306"/>
      <waypoint x="889" y="245"/>
      <waypoint x="404" y="245"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_142961_394305" xmi:uuid="2dc79b60-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394641_734963_226505"/>
      <ownedElement xmi:id="d946b640-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d946b770-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394641_734963_226505"/>
        <text>JointType:AssemblyJointTypeEnum</text>
      </ownedElement>
      <ownedElement xmi:id="d9477280-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d94773b0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394641_734963_226505"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="23b2c240-6c42-013d-d601-0800270c66d6" xmi:uuid="23b2c2d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="23cd95c0-6c42-013d-d601-0800270c66d6" xmi:uuid="23cd96a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_827678_394306" xmi:uuid="d955c950-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395427_224024_226553"/>
          <ownedElement xmi:id="d9546940-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9546a70-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395427_224024_226553"/>
            <text>arm_mapping:general_assembly_joint_type_enumeration</text>
          </ownedElement>
          <ownedElement xmi:id="d95514c0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9551590-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395427_224024_226553"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="50" y="233" width="354" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="203" width="376" height="65"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_295208_394307" xmi:uuid="2dc79fe0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394699_530693_226508"/>
      <ownedElement xmi:id="d9628aa0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9628bc0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394699_530693_226508"/>
        <text>shapeElement:Assembly_shape_joint</text>
      </ownedElement>
      <ownedElement xmi:id="d9638a00-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9638b30-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394699_530693_226508"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="255817a0-6c42-013d-d601-0800270c66d6" xmi:uuid="25581830-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2570ee50-6c42-013d-d601-0800270c66d6" xmi:uuid="2570ef20-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_875393_394308" xmi:uuid="d98990d0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint-associated_definition"/>
          <ownedElement xmi:id="d97c9e10-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d97c9f10-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint-associated_definition"/>
            <text>associated_definition:assembly_definition_or_assembly_shape_joint</text>
          </ownedElement>
          <ownedElement xmi:id="d98923c0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9892d50-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint-associated_definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="889" y="154" width="417" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_400854_394309" xmi:uuid="d9ae8e70-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint-definition"/>
          <ownedElement xmi:id="d9a1bad0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9a1bbe0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint-definition"/>
            <text>definition:assembly_shape_constraint_or_joint_definition_select</text>
          </ownedElement>
          <ownedElement xmi:id="d9ae3a50-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9ae3f20-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint-definition"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="889" y="98" width="405" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_186455_394310" xmi:uuid="d9d55860-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint-joint_type"/>
          <ownedElement xmi:id="d9c79f60-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9c7a0f0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint-joint_type"/>
            <text>joint_type:general_assembly_joint_type_enumeration</text>
          </ownedElement>
          <ownedElement xmi:id="d9d4f090-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9d4f1a0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint-joint_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="889" y="231" width="344" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="868" y="63" width="445" height="203"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_249058_410812" xmi:uuid="2dc7a530-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026957_52031_411916"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_295208_394307"/>
      <waypoint x="842" y="58"/>
      <waypoint x="868" y="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_377544_410813" xmi:uuid="2dc7ad70-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394621_231324_226499"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_120668_394297"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_295208_394307"/>
      <waypoint x="1325" y="70"/>
      <waypoint x="1313" y="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_805754_410814" xmi:uuid="2dc7b570-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394625_920205_226500"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_400854_394309"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_229008_394300"/>
      <waypoint x="889" y="109"/>
      <waypoint x="448" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_144187_410815" xmi:uuid="2dc7bd10-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394629_765314_226501"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_875393_394308"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_483213_394303"/>
      <waypoint x="889" y="165"/>
      <waypoint x="410" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026957_52031_411916" xmi:uuid="2dc7cd10-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="2dc7c930-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2dc7c9c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from PartShapeElement</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="742" y="14" width="100" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_120668_394297" xmi:uuid="2dc7d350-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394720_496132_226509"/>
      <bounds x="1325" y="62" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1328" height="283"/>
    <name>AssemblyShapeJoint</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564396315_463414_226691" xmi:uuid="2dc863a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028096_324099_178734"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_206985_394351" xmi:uuid="2dc8fa30-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393892_220466_226391"/>
      <ownedElement xmi:id="d9d97210-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9d97400-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393892_220466_226391"/>
        <text>Related:OccurrenceShapeFeature</text>
      </ownedElement>
      <ownedElement xmi:id="d9da5280-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9da53a0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393892_220466_226391"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_218219_394352" xmi:uuid="d9dc66e0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564139576_551997_191741"/>
        <ownedElement xmi:id="2ce164c0-6c42-013d-d601-0800270c66d6" xmi:uuid="2ce16550-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564139576_551997_191741"/>
          <bounds x="154" y="98" width="285" height="13"/>
          <text>occurrenceShapeFeature : Occurrence_shape_feature [1]</text>
        </ownedElement>
        <bounds x="248" y="117" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="112" width="221" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_49558_394354" xmi:uuid="2dc8fd10-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395085_731524_226533"/>
      <ownedElement xmi:id="d9ddbac0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9ddbd00-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395085_731524_226533"/>
        <text>Relating:AssemblyShapeJoint</text>
      </ownedElement>
      <ownedElement xmi:id="d9deb560-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9deb800-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395085_731524_226533"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_824753_394355" xmi:uuid="d9dfd930-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394720_496132_226509"/>
        <ownedElement xmi:id="2d307a60-6c42-013d-d601-0800270c66d6" xmi:uuid="2d307af0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394720_496132_226509"/>
          <bounds x="168" y="161" width="235" height="13"/>
          <text>assemblyShapeJoint : Assembly_shape_joint [1]</text>
        </ownedElement>
        <bounds x="234" y="180" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="175" width="207" height="26"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_690001_394357" xmi:uuid="2dc8fec0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396420_397695_226716"/>
      <ownedElement xmi:id="d9eb2a70-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9eb2c10-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396420_397695_226716"/>
        <text>shapeElementRelationship:Assembly_shape_joint_item_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d9ebe0c0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="d9ebe1c0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396420_397695_226716"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="2debfec0-6c42-013d-d601-0800270c66d6" xmi:uuid="2debff40-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2dec71b0-6c42-013d-d601-0800270c66d6" xmi:uuid="2dec7210-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_907533_394358" xmi:uuid="da113de0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint_item_relationship-related"/>
          <ownedElement xmi:id="da046eb0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="da046fc0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint_item_relationship-related"/>
            <text>related:Occurrence_shape_feature</text>
          </ownedElement>
          <ownedElement xmi:id="da10d5d0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="da10d6e0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint_item_relationship-related"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="483" y="112" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_307927_394359" xmi:uuid="da370700-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint_item_relationship-relating"/>
          <ownedElement xmi:id="da29ba80-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="da29c3d0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint_item_relationship-relating"/>
            <text>relating:Assembly_shape_joint</text>
          </ownedElement>
          <ownedElement xmi:id="da36bde0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="da36bee0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_joint_item_relationship-relating"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="483" y="176" width="207" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="469" y="77" width="415" height="134"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_254716_410829" xmi:uuid="2dc90540-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026957_384753_411918"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_690001_394357"/>
      <waypoint x="441" y="79"/>
      <waypoint x="469" y="87"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_241158_410830" xmi:uuid="2dc90c40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396414_990215_226712"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_907533_394358"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_218219_394352"/>
      <waypoint x="483" y="123"/>
      <waypoint x="263" y="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_10713_410831" xmi:uuid="2dc91420-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396416_934509_226713"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_307927_394359"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_824753_394355"/>
      <waypoint x="483" y="186"/>
      <waypoint x="249" y="186"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_276316_410832" xmi:uuid="2dc91bc0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396418_660935_226714"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_779785_394349"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_690001_394357"/>
      <waypoint x="923" y="88"/>
      <waypoint x="884" y="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026957_384753_411918" xmi:uuid="2dc92cd0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="2dc928d0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2dc92970-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from ShapeElementRelationship</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="287" y="35" width="154" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_779785_394349" xmi:uuid="2dc93310-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396438_182033_226717"/>
      <bounds x="923" y="81" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="926" height="226"/>
    <name>AssemblyShapeJointItemRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564395541_466413_226565" xmi:uuid="2dc93dd0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028078_668575_178728"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_643178_394316" xmi:uuid="2debaa10-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393960_9880_226397"/>
      <ownedElement xmi:id="2deb2300-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2deb2440-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393960_9880_226397"/>
        <text>MatingType:ClassSelect</text>
      </ownedElement>
      <ownedElement xmi:id="2deb9ab0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2deb9b60-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393960_9880_226397"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="75" width="180" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_184378_394317" xmi:uuid="2e236bf0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395682_203809_226597"/>
      <ownedElement xmi:id="2e0c2700-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e0c2800-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395682_203809_226597"/>
        <text>mating_definition:Assembly_definition</text>
      </ownedElement>
      <ownedElement xmi:id="2e0c9a70-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e0c9b20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395682_203809_226597"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="39f0f810-6c42-013d-d601-0800270c66d6" xmi:uuid="39f0f8a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="39f16ab0-6c42-013d-d601-0800270c66d6" xmi:uuid="39f16b50-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_197036_394318" xmi:uuid="2e236270-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_characterization"/>
          <ownedElement xmi:id="2e17f950-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e17fa40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_characterization"/>
            <text>additional_characterization:String</text>
          </ownedElement>
          <ownedElement xmi:id="2e235820-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e235900-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_characterization"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="854" y="78" width="237" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="847" y="56" width="251" height="57"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_390880_394326" xmi:uuid="2e244ac0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395721_885528_226599"/>
      <ownedElement xmi:id="2e23db60-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e23dc20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395721_885528_226599"/>
        <text>theClassificationRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="2e2439f0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e243aa0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395721_885528_226599"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="252" y="189" width="264" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_880752_410820" xmi:uuid="2e831bc0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395662_225280_226594"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_184378_394317"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_124438_394329"/>
      <waypoint x="1054" y="113"/>
      <waypoint x="1054" y="168"/>
      <waypoint x="758" y="168"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_920236_394327" xmi:uuid="2e834c10-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395740_450069_226600"/>
      <ownedElement xmi:id="2e2e9050-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e2e9170-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395740_450069_226600"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="2e2f0b20-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e2f0bd0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395740_450069_226600"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="3c3293a0-6c42-013d-d601-0800270c66d6" xmi:uuid="3c329430-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3c32f4b0-6c42-013d-d601-0800270c66d6" xmi:uuid="3c32f500-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_904022_394328" xmi:uuid="2e4e0310-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="2e439640-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e439740-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="2e4df930-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e4dfa20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="126" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_124438_394329" xmi:uuid="2e6cf4a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="2e61e9e0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e61eaf0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="2e6ce800-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e6cea00-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="154" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_855235_394330" xmi:uuid="2e831360-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="2e779310-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e779400-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="2e830660-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e830850-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="574" y="186" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="560" y="98" width="248" height="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_763602_410819" xmi:uuid="2e835700-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395654_722702_226590"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_254613_394314"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_184378_394317"/>
      <waypoint x="1115" y="67"/>
      <waypoint x="1098" y="67"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_939976_410822" xmi:uuid="2e835cf0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395659_61718_226593"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_855235_394330"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_390880_394326"/>
      <waypoint x="574" y="196"/>
      <waypoint x="516" y="196"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_254613_394314" xmi:uuid="2e836140-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395702_868067_226598"/>
      <bounds x="1115" y="62" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1690213048799_650028_88217" xmi:uuid="2eacc250-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1690213048789_393110_88215"/>
      <ownedElement xmi:id="2e8e02d0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2e8e03c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1690213048789_393110_88215"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1690213048799_111682_88218" xmi:uuid="2e98c0d0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="43477b10-6c42-013d-d601-0800270c66d6" xmi:uuid="43477bb0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="461" y="70" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="443" y="79" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1690213048799_70865_88220" xmi:uuid="2ea2e7f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
        <ownedElement xmi:id="441be770-6c42-013d-d601-0800270c66d6" xmi:uuid="441be840-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
          <bounds x="219" y="72" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="273" y="81" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1690213048799_1980_88222" xmi:uuid="2eacbce0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
        <ownedElement xmi:id="44df9390-6c42-013d-d601-0800270c66d6" xmi:uuid="44df9430-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
          <bounds x="357" y="112" width="54" height="13"/>
          <text>class [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="413" y="97" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="273" y="63" width="185" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1690213078421_844329_88286" xmi:uuid="2eacc840-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1690213079637_95780_88287"/>
      <source xmi:idref="_18_4_1_65b021e_1690213048799_70865_88220"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_643178_394316"/>
      <waypoint x="273" y="88"/>
      <waypoint x="208" y="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1690213083761_301583_88305" xmi:uuid="2eacd0a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1690213087305_864415_88306"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_904022_394328"/>
      <target xmi:idref="_18_4_1_65b021e_1690213048799_1980_88222"/>
      <waypoint x="574" y="133"/>
      <waypoint x="420" y="133"/>
      <waypoint x="420" y="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1690213136193_350284_88343" xmi:uuid="2eacd630-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1690213139044_666567_88344"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_197036_394318"/>
      <target xmi:idref="_18_4_1_65b021e_1690213048799_111682_88218"/>
      <waypoint x="854" y="88"/>
      <waypoint x="458" y="88"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1118" height="236"/>
    <name>MatingDefinition</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564396900_276942_226738" xmi:uuid="2eace0d0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028109_381287_178740"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_656097_394365" xmi:uuid="2eda0df0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393796_397345_226382"/>
      <ownedElement xmi:id="2ed93230-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2ed93540-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393796_397345_226382"/>
        <text>MatedShapes:AssemblyShapeJoint</text>
      </ownedElement>
      <ownedElement xmi:id="2ed99520-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2ed995c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393796_397345_226382"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_763084_394366" xmi:uuid="2eda07b0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394720_496132_226509"/>
        <ownedElement xmi:id="48c68a10-6c42-013d-d601-0800270c66d6" xmi:uuid="48c68aa0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394720_496132_226509"/>
          <bounds x="279" y="641" width="235" height="13"/>
          <text>assemblyShapeJoint : Assembly_shape_joint [1]</text>
        </ownedElement>
        <bounds x="261" y="650" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="644" width="248" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_800828_394368" xmi:uuid="2ee21d10-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393820_979292_226384"/>
      <ownedElement xmi:id="2eddd630-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2eddd720-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393820_979292_226384"/>
        <text>MatingMaterials:DefinitionBasedOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="2ede47d0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2ede4880-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393820_979292_226384"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692688676299_398006_151390" xmi:uuid="db401470-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569415101604_16246_63552"/>
        <ownedElement xmi:id="497a6cc0-6c42-013d-d601-0800270c66d6" xmi:uuid="497a6d60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569415101604_16246_63552"/>
          <bounds x="317" y="693" width="186" height="13"/>
          <text>^occurrence : Product_occurrence [1]</text>
        </ownedElement>
        <bounds x="299" y="702" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="700" width="286" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_843453_410833" xmi:uuid="2eee7e20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397058_777625_226763"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_933266_394382"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_529439_394372"/>
      <waypoint x="1043" y="796"/>
      <waypoint x="211" y="796"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_111759_394371" xmi:uuid="2eef5290-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397105_884406_226787"/>
      <ownedElement xmi:id="2ee2e740-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2ee2e810-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397105_884406_226787"/>
        <text>MatingType:MatingTypeEnum</text>
      </ownedElement>
      <ownedElement xmi:id="2ee35090-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2ee35260-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397105_884406_226787"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="49abf290-6c42-013d-d601-0800270c66d6" xmi:uuid="49abf330-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="49c66790-6c42-013d-d601-0800270c66d6" xmi:uuid="49c66830-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_529439_394372" xmi:uuid="2eee7500-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395066_667894_226530"/>
          <ownedElement xmi:id="2eede810-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2eede8c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395066_667894_226530"/>
            <text>arm_mapping:mating_type</text>
          </ownedElement>
          <ownedElement xmi:id="2eee66f0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2eee67c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395066_667894_226530"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="28" y="786" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="756" width="198" height="65"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_140047_394373" xmi:uuid="2ef14e20-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396169_59002_226676"/>
      <ownedElement xmi:id="2ef038b0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2ef03980-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396169_59002_226676"/>
        <text>Related:MatedPartAssociation</text>
      </ownedElement>
      <ownedElement xmi:id="2ef0b3b0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2ef0b500-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396169_59002_226676"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_482934_394374" xmi:uuid="2ef14850-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394185_878765_226433"/>
        <ownedElement xmi:id="4ab894b0-6c42-013d-d601-0800270c66d6" xmi:uuid="4ab89540-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394185_878765_226433"/>
          <bounds x="239" y="848" width="271" height="13"/>
          <text>matedPartAssociation : Assembled_part_association [1]</text>
        </ownedElement>
        <bounds x="221" y="857" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="854" width="208" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_126083_394376" xmi:uuid="2ef33c90-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393916_698639_226393"/>
      <ownedElement xmi:id="2ef22690-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2ef227b0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393916_698639_226393"/>
        <text>Relating:MatedPartAssociation</text>
      </ownedElement>
      <ownedElement xmi:id="2ef2bcf0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2ef2be40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393916_698639_226393"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_657028_394377" xmi:uuid="2ef33760-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394185_878765_226433"/>
        <ownedElement xmi:id="4b087000-6c42-013d-d601-0800270c66d6" xmi:uuid="4b087180-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394185_878765_226433"/>
          <bounds x="242" y="904" width="271" height="13"/>
          <text>matedPartAssociation : Assembled_part_association [1]</text>
        </ownedElement>
        <bounds x="224" y="913" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="910" width="211" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_657004_394379" xmi:uuid="2fc0c740-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397124_468034_226788"/>
      <ownedElement xmi:id="2efe3870-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2efe3980-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397124_468034_226788"/>
        <text>mated_part_relationship:Mated_assembly_occurrence_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="2efeec70-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2efeed80-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397124_468034_226788"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="4c3ac570-6c42-013d-d601-0800270c66d6" xmi:uuid="4c3ac640-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4c3b4730-6c42-013d-d601-0800270c66d6" xmi:uuid="4c3b47e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_936101_394380" xmi:uuid="2f2a6f40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-mating_joints"/>
          <ownedElement xmi:id="2f17f290-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2f17f490-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-mating_joints"/>
            <text>mating_joints:Assembly_shape_joint</text>
          </ownedElement>
          <ownedElement xmi:id="2f2a5450-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2f2a5750-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-mating_joints"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1043" y="644" width="250" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_906657_394381" xmi:uuid="2f4b5460-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-mating_material"/>
          <ownedElement xmi:id="2f404bb0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2f404cb0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-mating_material"/>
            <text>mating_material:definition_based_product_occurrence_or_assembled_part_association_select</text>
          </ownedElement>
          <ownedElement xmi:id="2f4b4680-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2f4b47a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-mating_material"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1043" y="693" width="548" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_933266_394382" xmi:uuid="2f752270-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-mating_types"/>
          <ownedElement xmi:id="2f657870-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2f657a10-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-mating_types"/>
            <text>mating_types:mating_type</text>
          </ownedElement>
          <ownedElement xmi:id="2f750920-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2f750a90-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-mating_types"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1043" y="777" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_517447_394383" xmi:uuid="2f9c75a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-related"/>
          <ownedElement xmi:id="2f8edf70-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2f8ee070-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-related"/>
            <text>related:Assembled_part_association</text>
          </ownedElement>
          <ownedElement xmi:id="2f9c6b50-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2f9c6c50-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-related"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1043" y="847" width="239" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_661959_394384" xmi:uuid="2fc0b810-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-relating"/>
          <ownedElement xmi:id="2fb4f890-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2fb4f980-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-relating"/>
            <text>relating:Assembled_part_association</text>
          </ownedElement>
          <ownedElement xmi:id="2fc0a800-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="2fc0a900-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Mated_assembly_occurrence_relationship-relating"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1043" y="903" width="242" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1022" y="595" width="576" height="343"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_523855_410844" xmi:uuid="30af5490-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397084_163805_226776"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_657004_394379"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_111882_394400"/>
      <waypoint x="1106" y="595"/>
      <waypoint x="1106" y="256"/>
      <waypoint x="819" y="256"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_859460_394399" xmi:uuid="30aff8f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397241_349469_226794"/>
      <ownedElement xmi:id="306c1b10-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="306c1c60-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397241_349469_226794"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="306cabc0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="306cacc0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397241_349469_226794"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="560622d0-6c42-013d-d601-0800270c66d6" xmi:uuid="56062370-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="561f06a0-6c42-013d-d601-0800270c66d6" xmi:uuid="561f0770-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_111882_394400" xmi:uuid="308f01e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="308443d0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="308444d0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="308ef2b0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="308ef3b0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="644" y="245" width="175" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026346_744657_394401" xmi:uuid="30af48c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="30a3fa50-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="30a3fb40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="30af3e30-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="30af3f30-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="644" y="203" width="192" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="168" width="309" height="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_939712_394416" xmi:uuid="3187b2e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397314_402281_226798"/>
      <ownedElement xmi:id="316d2fe0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="316d3200-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397314_402281_226798"/>
        <text>dt:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="316dfbe0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="316dfce0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397314_402281_226798"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="5a7b7750-6c42-013d-d601-0800270c66d6" xmi:uuid="5a7b7860-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5a7be390-6c42-013d-d601-0800270c66d6" xmi:uuid="5a7be440-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_675660_394417" xmi:uuid="3187a840-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="317af1e0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="317af370-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="31879a60-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="31879b80-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="476" y="231" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="462" y="203" width="153" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_572715_410856" xmi:uuid="3222b4d0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397101_989358_226784"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_657004_394379"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_775274_394425"/>
      <waypoint x="1106" y="595"/>
      <waypoint x="1106" y="473"/>
      <waypoint x="827" y="473"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_636951_394424" xmi:uuid="32235290-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397370_746334_226801"/>
      <ownedElement xmi:id="31ca3770-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="31ca3880-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397370_746334_226801"/>
        <text>ia:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="31cab920-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="31cab9e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397370_746334_226801"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="5c528980-6c42-013d-d601-0800270c66d6" xmi:uuid="5c528a70-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5c535d30-6c42-013d-d601-0800270c66d6" xmi:uuid="5c535e30-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_775274_394425" xmi:uuid="31f217a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="31e4b800-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="31e4ba40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="31f1f550-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="31f1f740-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="644" y="462" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_857749_394426" xmi:uuid="320bbfa0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="31ff8570-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="31ff87a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="320baa50-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="320bacc0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="644" y="434" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_142380_394427" xmi:uuid="3222ac30-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="321793e0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="321794f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="32229e70-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="32229f60-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="644" y="406" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="378" width="309" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_590467_394430" xmi:uuid="3251c3a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397407_345908_226803"/>
      <ownedElement xmi:id="32514a90-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="32514b80-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397407_345908_226803"/>
        <text>theRole1:String</text>
      </ownedElement>
      <ownedElement xmi:id="3251b0e0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="3251b190-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397407_345908_226803"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="479" y="406" width="142" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_879330_410835" xmi:uuid="3251cb30-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397051_6105_226759"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_607923_394431"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_657004_394379"/>
      <waypoint x="1610" y="525"/>
      <waypoint x="1481" y="525"/>
      <waypoint x="1481" y="595"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_393301_410837" xmi:uuid="3251db30-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397056_84077_226762"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_936101_394380"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_763084_394366"/>
      <waypoint x="1043" y="654"/>
      <waypoint x="276" y="654"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_122647_410838" xmi:uuid="3251e8a0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397060_77485_226764"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_517447_394383"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_482934_394374"/>
      <waypoint x="1043" y="867"/>
      <waypoint x="236" y="867"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_933705_410839" xmi:uuid="3251f130-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397062_231584_226765"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_661959_394384"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026346_657028_394377"/>
      <waypoint x="1043" y="920"/>
      <waypoint x="239" y="920"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_798218_410847" xmi:uuid="32521ae0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397073_281401_226770"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_744657_394401"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_939712_394416"/>
      <waypoint x="644" y="214"/>
      <waypoint x="615" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_914619_410852" xmi:uuid="32524620-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397090_756991_226779"/>
      <source xmi:idref="_18_4_1_65b021e_1692688784592_728514_151423"/>
      <target xmi:idref="_18_4_1_65b021e_1692688676299_398006_151390"/>
      <waypoint x="637" y="711"/>
      <waypoint x="314" y="711"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026942_475213_410858" xmi:uuid="325267d0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397098_386368_226783"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_142380_394427"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026347_590467_394430"/>
      <waypoint x="644" y="416"/>
      <waypoint x="621" y="416"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026347_607923_394431" xmi:uuid="32526f70-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397166_189885_226790"/>
      <bounds x="1610" y="518" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692688784592_728514_151423" xmi:uuid="dd1446e0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1692688784576_202827_151422"/>
      <ownedElement xmi:id="dd1338b0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dd1339d0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1692688784576_202827_151422"/>
        <text>dbpo:Definition_based_product_occurrence</text>
      </ownedElement>
      <ownedElement xmi:id="dd141290-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dd1413c0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1692688784576_202827_151422"/>
        <text>[0..*]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="637" y="700" width="281" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692688825793_708584_151471" xmi:uuid="dd1451c0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1692688828094_738170_151472"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_906657_394381"/>
      <target xmi:idref="_18_4_1_65b021e_1692688784592_728514_151423"/>
      <waypoint x="1043" y="710"/>
      <waypoint x="918" y="710"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698432074_776952_97799" xmi:uuid="dd145660-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="630" y="21" width="115" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698807044_201325_98269" xmi:uuid="dd5da600-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1692698809211_617636_98270"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_657004_394379"/>
      <target xmi:idref="_18_4_1_65b021e_1692698484499_976782_97839"/>
      <waypoint x="1106" y="595"/>
      <waypoint x="1106" y="116"/>
      <waypoint x="828" y="116"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698484498_50515_97833" xmi:uuid="dd5e5bc0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="dd2b8bf0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dd2b8d00-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="dd379360-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dd3794f0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="63cbdad0-6c42-013d-d601-0800270c66d6" xmi:uuid="63cbdb60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="63cc42b0-6c42-013d-d601-0800270c66d6" xmi:uuid="63cc4320-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692698484499_976782_97839" xmi:uuid="dd5d3ce0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="dd5034b0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dd5035b0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="dd5cd2f0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dd5cd3f0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="644" y="105" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="77" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698868195_716621_98327" xmi:uuid="ddaab840-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1692698870765_406712_98328"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_657004_394379"/>
      <target xmi:idref="_18_4_1_65b021e_1692698484499_730979_97840"/>
      <waypoint x="1106" y="595"/>
      <waypoint x="1106" y="550"/>
      <waypoint x="827" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698484499_954843_97834" xmi:uuid="ddab87a0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="dd765640-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dd765780-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="dd828a50-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dd828bd0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="6780ea00-6c42-013d-d601-0800270c66d6" xmi:uuid="6780eaa0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="679ff680-6c42-013d-d601-0800270c66d6" xmi:uuid="679ff730-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692698484499_730979_97840" xmi:uuid="ddaa6520-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="dd9d36d0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dd9d3820-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ddaa0000-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="ddaa0130-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="644" y="539" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="511" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698689111_958395_98232" xmi:uuid="ddf59700-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1692698690829_606627_98233"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026346_657004_394379"/>
      <target xmi:idref="_18_4_1_65b021e_1692698484499_245926_97843"/>
      <waypoint x="1106" y="595"/>
      <waypoint x="1106" y="333"/>
      <waypoint x="819" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698484499_31628_97836" xmi:uuid="ddf66d80-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="ddc2c9b0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="ddc2cae0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ddcee2b0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="ddcee3d0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="6b0c6df0-6c42-013d-d601-0800270c66d6" xmi:uuid="6b0c6e90-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="6b0cdf50-6c42-013d-d601-0800270c66d6" xmi:uuid="6b0cdfd0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692698484499_245926_97843" xmi:uuid="ddf54e80-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="dde83d40-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dde84030-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="ddf4fd20-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="ddf4fe30-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="644" y="322" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="294" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692699183725_406707_106606" xmi:uuid="de3ebc50-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1692699185641_652142_106607"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_939712_394416"/>
      <target xmi:idref="_18_4_1_65b021e_1692698484499_145584_97844"/>
      <waypoint x="585" y="266"/>
      <waypoint x="585" y="333"/>
      <waypoint x="529" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698484499_364923_97837" xmi:uuid="de3f63e0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="de0d2e60-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="de0d2f60-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="de191170-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="de191280-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="6f12c1d0-6c42-013d-d601-0800270c66d6" xmi:uuid="6f12c250-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="6f132de0-6c42-013d-d601-0800270c66d6" xmi:uuid="6f132e60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692698484499_145584_97844" xmi:uuid="de3e6550-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="de31c070-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="de31c2c0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="de3e1f80-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="de3e2090-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="301" y="322" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="287" y="294" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698484499_765415_97838" xmi:uuid="de6f4e10-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="de56f300-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="de56f410-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692698484499_773997_97845" xmi:uuid="de6f4490-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="736b5560-6c42-013d-d601-0800270c66d6" xmi:uuid="736b59a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="389" y="228" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="371" y="237" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="161" y="224" width="225" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698530212_118841_98149" xmi:uuid="de9e6de0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="de86f480-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="de86f6b0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692698530212_935986_98150" xmi:uuid="de9e5ab0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="76471470-6c42-013d-d601-0800270c66d6" xmi:uuid="764715a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="414" y="431" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="396" y="440" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="273" y="427" width="138" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698638584_523272_98204" xmi:uuid="de9e7b70-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1692698639248_180499_98205"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_675660_394417"/>
      <target xmi:idref="_18_4_1_65b021e_1692698484499_773997_97845"/>
      <waypoint x="476" y="245"/>
      <waypoint x="386" y="245"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692698836595_154000_98292" xmi:uuid="de9e8710-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1692698838011_874482_98293"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026347_857749_394426"/>
      <target xmi:idref="_18_4_1_65b021e_1692698530212_935986_98150"/>
      <waypoint x="644" y="448"/>
      <waypoint x="411" y="448"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1613" height="953"/>
    <name>MatedPartRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446294643_650759_278153" xmi:uuid="31b9ba20-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028096_324099_178734"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294668_855315_278185" xmi:uuid="32869990-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396420_397695_226716"/>
      <ownedElement xmi:id="3285a350-6c42-013d-d601-0800270c66d6" xmi:uuid="3285a400-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396420_397695_226716"/>
        <text>shapeElementRelationship:Assembly_shape_joint_item_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="328688c0-6c42-013d-d601-0800270c66d6" xmi:uuid="32868950-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396420_397695_226716"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="400" height="330"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294684_831751_278219" xmi:uuid="328707b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="839" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294693_926251_278234" xmi:uuid="32879230-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../AnnotatedModelPresentation/AnnotatedModelPresentation.xmi#_18_4_1_65b021e_1674590225569_36926_72230"/>
      <bounds x="839" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294708_8364_278249" xmi:uuid="32884360-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="839" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294717_836117_278264" xmi:uuid="32bb0cb0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1693389845452_895549_96322"/>
      <bounds x="839" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294731_167189_278279" xmi:uuid="32bb85e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="839" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294739_532128_278294" xmi:uuid="32d68ba0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="839" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294754_860156_278309" xmi:uuid="32d70280-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="839" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294768_981707_278324" xmi:uuid="32d76bb0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="839" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294782_563541_278339" xmi:uuid="32d7e340-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="839" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294796_958163_278354" xmi:uuid="32d84ca0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="839" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294812_43235_278369" xmi:uuid="32d8b9a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="839" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294829_570_278384" xmi:uuid="32f97790-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="839" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294844_309901_278399" xmi:uuid="32f9f7a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="839" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294859_466776_278414" xmi:uuid="330fbc50-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="839" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496397_993632_401051" xmi:uuid="330fcd00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601380692_641982_250191"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294684_831751_278219"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="62"/>
      <waypoint x="445" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496397_915854_401054" xmi:uuid="330fd460-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601380782_243435_250207"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294693_926251_278234"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="82"/>
      <waypoint x="445" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496397_63397_401057" xmi:uuid="330fdae0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601380859_430104_250223"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294708_8364_278249"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="102"/>
      <waypoint x="445" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496397_5727_401060" xmi:uuid="330fe1e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381024_742613_250255"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294717_836117_278264"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="122"/>
      <waypoint x="445" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496397_806_401063" xmi:uuid="330fed50-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381102_760450_250271"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294731_167189_278279"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="142"/>
      <waypoint x="445" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496397_785409_401066" xmi:uuid="330ff3e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381187_669042_250287"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294739_532128_278294"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="162"/>
      <waypoint x="445" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496397_511068_401069" xmi:uuid="331004e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381263_637123_250303"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294754_860156_278309"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="182"/>
      <waypoint x="445" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496397_111071_401072" xmi:uuid="33100be0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381353_889960_250319"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294768_981707_278324"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="202"/>
      <waypoint x="445" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496397_681286_401075" xmi:uuid="33101340-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381445_468172_250335"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294782_563541_278339"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="222"/>
      <waypoint x="445" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496398_254149_401078" xmi:uuid="331018e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381540_271703_250351"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294796_958163_278354"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="242"/>
      <waypoint x="445" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496398_434480_401081" xmi:uuid="33101f90-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381713_711093_250383"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294812_43235_278369"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="262"/>
      <waypoint x="445" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496398_397345_401084" xmi:uuid="331025e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381797_831452_250399"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294829_570_278384"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="282"/>
      <waypoint x="445" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496398_740855_401087" xmi:uuid="33102c50-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381884_230175_250415"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294844_309901_278399"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="302"/>
      <waypoint x="445" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496398_556536_401090" xmi:uuid="33103410-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601381966_743952_250431"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294859_466776_278414"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294668_855315_278185"/>
      <waypoint x="839" y="322"/>
      <waypoint x="445" y="322"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="842" height="400"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564393290_716781_226338" xmi:uuid="3252a130-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028033_86160_178712"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_854579_394281" xmi:uuid="32539fb0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393439_834309_226364"/>
      <ownedElement xmi:id="dea1b1a0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dea1b2d0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393439_834309_226364"/>
        <text>Related:OccurrenceShapeFeature</text>
      </ownedElement>
      <ownedElement xmi:id="dea25690-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dea25760-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393439_834309_226364"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_768854_394282" xmi:uuid="dea40c20-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564139576_551997_191741"/>
        <ownedElement xmi:id="77e0b440-6c42-013d-d601-0800270c66d6" xmi:uuid="77e0b670-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564139576_551997_191741"/>
          <bounds x="238" y="105" width="285" height="13"/>
          <text>occurrenceShapeFeature : Occurrence_shape_feature [1]</text>
        </ownedElement>
        <bounds x="248" y="122" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="119" width="221" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_11630_394284" xmi:uuid="3253a360-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393414_847747_226363"/>
      <ownedElement xmi:id="dea55790-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dea558a0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393414_847747_226363"/>
        <text>Relating:AssemblyShapeConstraint</text>
      </ownedElement>
      <ownedElement xmi:id="dea60220-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="dea60310-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393414_847747_226363"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_720037_394285" xmi:uuid="dea70cf0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396147_307500_226673"/>
        <ownedElement xmi:id="7816fbe0-6c42-013d-d601-0800270c66d6" xmi:uuid="7816fc70-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396147_307500_226673"/>
          <bounds x="203" y="154" width="291" height="13"/>
          <text>assemblyShapeConstraint : Assembly_shape_constraint [1]</text>
        </ownedElement>
        <bounds x="259" y="172" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="168" width="232" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_991781_394287" xmi:uuid="3253a920-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393471_997255_226365"/>
      <ownedElement xmi:id="deb42f80-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="deb430a0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393471_997255_226365"/>
        <text>shapeElementRelationship:Assembly_shape_constraint_item_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="deb4fa50-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="deb4fb50-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393471_997255_226365"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="78e0a2a0-6c42-013d-d601-0800270c66d6" xmi:uuid="78e0a340-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7908b9b0-6c42-013d-d601-0800270c66d6" xmi:uuid="7908ba60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_913810_394288" xmi:uuid="dedac660-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint_item_relationship-related"/>
          <ownedElement xmi:id="decdb3a0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="decdb6d0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint_item_relationship-related"/>
            <text>related:Occurrence_shape_feature</text>
          </ownedElement>
          <ownedElement xmi:id="deda7340-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="deda7440-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint_item_relationship-related"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="119" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_453239_394289" xmi:uuid="deffa410-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint_item_relationship-relating"/>
          <ownedElement xmi:id="def2e820-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="def2e930-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint_item_relationship-relating"/>
            <text>relating:Assembly_shape_constraint</text>
          </ownedElement>
          <ownedElement xmi:id="deff41a0-24a1-013c-5bfa-2bb9f4d923a9" xmi:uuid="deff42b0-24a1-013c-5bfa-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembly_shape_constraint_item_relationship-relating"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="161" width="239" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="518" y="77" width="430" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_477909_410804" xmi:uuid="3253be10-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026957_936779_411914"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_991781_394287"/>
      <waypoint x="483" y="81"/>
      <waypoint x="518" y="89"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_788866_410805" xmi:uuid="3253c9e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393403_557859_226359"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_913810_394288"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_768854_394282"/>
      <waypoint x="539" y="130"/>
      <waypoint x="263" y="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_485013_410806" xmi:uuid="3253d310-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393406_590488_226360"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_453239_394289"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_720037_394285"/>
      <waypoint x="539" y="179"/>
      <waypoint x="274" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_499676_410807" xmi:uuid="3253e2d0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393409_859960_226361"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_264026_394279"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_991781_394287"/>
      <waypoint x="986" y="95"/>
      <waypoint x="948" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026957_936779_411914" xmi:uuid="3253f1b0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="3253ee10-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="3253ee50-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from ShapeElementRelationship</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="343" y="42" width="140" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_264026_394279" xmi:uuid="32540610-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393494_457560_226366"/>
      <bounds x="986" y="89" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="989" height="211"/>
    <name>AssemblyShapeConstraintItemRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564394050_545338_226408" xmi:uuid="325418f0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028049_734479_178723"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_80771_394290" xmi:uuid="325a5680-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394163_818925_226432"/>
      <ownedElement xmi:id="325599b0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="32559a90-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394163_818925_226432"/>
        <text>Relating:MatingDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="32560ec0-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="32560fb0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394163_818925_226432"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_240692_394291" xmi:uuid="325a4cb0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569339486876_146159_55185"/>
        <ownedElement xmi:id="800f9680-6c42-013d-d601-0800270c66d6" xmi:uuid="800f97c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569339486876_146159_55185"/>
          <bounds x="224" y="94" width="190" height="13"/>
          <text>^assemblyDef : Assembly_definition [1]</text>
        </ownedElement>
        <bounds x="206" y="103" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="98" width="179" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_917510_394293" xmi:uuid="328440c0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394208_296445_226434"/>
      <ownedElement xmi:id="3264ea70-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="3264eb70-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394208_296445_226434"/>
        <text>mated_part_association:Assembled_part_association</text>
      </ownedElement>
      <ownedElement xmi:id="32655930-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="326559e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394208_296445_226434"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="80ca1f90-6c42-013d-d601-0800270c66d6" xmi:uuid="80ca2040-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="80caa100-6c42-013d-d601-0800270c66d6" xmi:uuid="80caa1b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_379403_394294" xmi:uuid="32842a00-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembled_part_association-relating_view"/>
          <ownedElement xmi:id="3279ca80-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="3279cb80-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembled_part_association-relating_view"/>
            <text>relating_view:Assembly_definition</text>
          </ownedElement>
          <ownedElement xmi:id="32842080-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="32842180-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assembled_part_association-relating_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="483" y="99" width="227" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="469" y="70" width="332" height="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_303549_410808" xmi:uuid="32844990-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566026345_917510_394293"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026957_231354_411915"/>
      <waypoint x="469" y="79"/>
      <waypoint x="436" y="75"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_253841_410809" xmi:uuid="32845c50-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394158_229044_226429"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_954850_394295"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_917510_394293"/>
      <waypoint x="813" y="88"/>
      <waypoint x="801" y="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026941_178287_410810" xmi:uuid="32847160-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394161_938993_226430"/>
      <source xmi:idref="_18_4_1_65b021e_1688566026345_379403_394294"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026345_240692_394291"/>
      <waypoint x="483" y="109"/>
      <waypoint x="221" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026957_231354_411915" xmi:uuid="32847b40-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="32847740-0d30-013c-5e28-5b8e392dc4e5" xmi:uuid="328477e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from Assembly_component_relationship</text>
      </ownedElement>
      <bounds x="196" y="35" width="240" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026345_954850_394295" xmi:uuid="328487e0-0d30-013c-5e28-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394185_878765_226433"/>
      <bounds x="813" y="81" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="816" height="149"/>
    <name>MatedPartAssociation</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446293724_707581_276992" xmi:uuid="44fa3940-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028078_668575_178728"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293749_838781_277024" xmi:uuid="45c485b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395682_203809_226597"/>
      <ownedElement xmi:id="45c35d70-6c42-013d-d601-0800270c66d6" xmi:uuid="45c35e70-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395682_203809_226597"/>
        <text>mating_definition:Assembly_definition</text>
      </ownedElement>
      <ownedElement xmi:id="45c471d0-6c42-013d-d601-0800270c66d6" xmi:uuid="45c47280-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564395682_203809_226597"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="243" height="1270"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293767_953741_277058" xmi:uuid="45c52870-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="909" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293778_325644_277073" xmi:uuid="45c5d450-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="909" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293787_430365_277088" xmi:uuid="45c64d30-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_6b1022a_1570727524445_1920_44551"/>
      <bounds x="909" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293797_794360_277103" xmi:uuid="45c6c7a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../AnnotatedModelPresentation/AnnotatedModelPresentation.xmi#_18_4_1_65b021e_1674590225569_36926_72230"/>
      <bounds x="909" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293812_953459_277118" xmi:uuid="45c73ce0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="909" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293822_230987_277133" xmi:uuid="45c7a510-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396499_54432_226725"/>
      <bounds x="909" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293831_365532_277148" xmi:uuid="460b5510-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564396188_204778_226677"/>
      <bounds x="909" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293842_34289_277163" xmi:uuid="460bc770-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1693389845452_895549_96322"/>
      <bounds x="909" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293851_826288_277178" xmi:uuid="460c2f10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="909" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293860_597098_277193" xmi:uuid="4626ac50-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551689215050_535893_40191"/>
      <bounds x="909" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293869_540982_277208" xmi:uuid="46272240-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1551433642363_802478_36217"/>
      <bounds x="909" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293880_897394_277223" xmi:uuid="462787b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="909" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293896_23191_277238" xmi:uuid="4627f550-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="909" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293908_389716_277253" xmi:uuid="4652bcb0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="909" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293918_389623_277268" xmi:uuid="46533540-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973058873_539759_54381"/>
      <bounds x="909" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293927_989195_277283" xmi:uuid="4653a260-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973091565_761824_54391"/>
      <bounds x="909" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293936_659083_277298" xmi:uuid="46540a90-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564143467_618360_192628"/>
      <bounds x="909" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293951_713768_277313" xmi:uuid="46547db0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="909" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293963_347079_277328" xmi:uuid="4654e680-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="909" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293977_301586_277343" xmi:uuid="46554c00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="909" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293992_558927_277358" xmi:uuid="468e34f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="909" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294007_839642_277373" xmi:uuid="468ed4a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="909" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294017_831521_277388" xmi:uuid="468f7c80-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="909" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294027_37129_277403" xmi:uuid="46ae89a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../GeometricDimensioningAndTolerancing/GeometricDimensioningAndTolerancing.xmi#_18_4_1_65b021e_1674590466911_322671_71545"/>
      <bounds x="909" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294036_747925_277418" xmi:uuid="46aefe90-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_8be0287_1560935213608_295299_43692"/>
      <bounds x="909" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294049_336263_277433" xmi:uuid="46af6820-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="909" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294059_737479_277448" xmi:uuid="46c0e240-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973151145_247037_54405"/>
      <bounds x="909" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294068_78905_277463" xmi:uuid="46c16260-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973215473_235782_54417"/>
      <bounds x="909" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294077_911548_277478" xmi:uuid="46c1d0b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1632389717469_699649_77674"/>
      <bounds x="909" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294087_616263_277493" xmi:uuid="46d99b90-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510320502001_52464_30616"/>
      <bounds x="909" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294097_503032_277508" xmi:uuid="46da4600-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1510325553618_189011_33055"/>
      <bounds x="909" y="655" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294116_659718_277523" xmi:uuid="46dacd30-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="909" y="675" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294134_754436_277538" xmi:uuid="46db39f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="909" y="695" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294146_593997_277553" xmi:uuid="46db9d60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="909" y="715" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294159_510023_277568" xmi:uuid="47100d70-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="909" y="735" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294169_601860_277583" xmi:uuid="4710ad20-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564135540_870467_190875"/>
      <bounds x="909" y="755" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294179_434302_277598" xmi:uuid="472565d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317852_610905_217937"/>
      <bounds x="909" y="775" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294187_646469_277613" xmi:uuid="4725dc30-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564141926_556119_192266"/>
      <bounds x="909" y="795" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294197_620817_277628" xmi:uuid="47264eb0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ElectricalHarness/ElectricalHarness.xmi#_18_4_1_65b021e_1688564137313_718057_191236"/>
      <bounds x="909" y="815" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294207_909724_277643" xmi:uuid="4726b6d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_18_4_1_271a0567_1578048114027_922117_59250"/>
      <bounds x="909" y="835" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294223_337754_277658" xmi:uuid="474a54b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="909" y="855" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294233_650172_277673" xmi:uuid="474b0340-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643268851717_322008_86077"/>
      <bounds x="909" y="875" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294242_42891_277688" xmi:uuid="474baff0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643269416144_30883_86580"/>
      <bounds x="909" y="895" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294251_502491_277703" xmi:uuid="474c2c10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1643270131067_298147_86914"/>
      <bounds x="909" y="915" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294261_399568_277718" xmi:uuid="474c9ee0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688564037651_912713_180830"/>
      <bounds x="909" y="935" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294270_543671_277733" xmi:uuid="478113a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688564037201_795697_180724"/>
      <bounds x="909" y="955" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294286_443932_277748" xmi:uuid="47818dd0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="909" y="975" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294298_472718_277763" xmi:uuid="478201e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="909" y="995" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294309_945223_277778" xmi:uuid="47a921b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570177719994_529188_81455"/>
      <bounds x="909" y="1015" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294319_636217_277793" xmi:uuid="47a9aac0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
      <bounds x="909" y="1035" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294330_315348_277808" xmi:uuid="47aa3d10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
      <bounds x="909" y="1055" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294341_449036_277823" xmi:uuid="47aade80-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="909" y="1075" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294352_658597_277838" xmi:uuid="47d7cdf0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="909" y="1095" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294364_746970_277853" xmi:uuid="47d860e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="909" y="1115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294374_1027_277868" xmi:uuid="47d8f1c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564317927_120586_217958"/>
      <bounds x="909" y="1135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294384_427315_277883" xmi:uuid="47f231b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1632389299841_783300_77269"/>
      <bounds x="909" y="1155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294396_742553_277898" xmi:uuid="48119e00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="909" y="1175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294408_217386_277913" xmi:uuid="48121f60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="909" y="1195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294420_570885_277928" xmi:uuid="4812a070-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="909" y="1215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294433_814523_277943" xmi:uuid="481329d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="909" y="1235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294444_649695_277958" xmi:uuid="4813aab0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="909" y="1255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496363_314802_400844" xmi:uuid="4813b6c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372878_741105_248451"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293767_953741_277058"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="62"/>
      <waypoint x="288" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496363_874721_400847" xmi:uuid="4813bd20-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601372966_249966_248467"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293778_325644_277073"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="82"/>
      <waypoint x="288" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496363_524920_400850" xmi:uuid="4813c360-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373046_103830_248483"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293787_430365_277088"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="102"/>
      <waypoint x="288" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496363_91552_400853" xmi:uuid="4813c8d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373127_817545_248499"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293797_794360_277103"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="122"/>
      <waypoint x="288" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496363_341383_400856" xmi:uuid="4813cf40-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373206_370060_248515"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293812_953459_277118"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="142"/>
      <waypoint x="288" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496363_691925_400859" xmi:uuid="4813d460-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373292_390005_248531"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293822_230987_277133"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="162"/>
      <waypoint x="288" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496363_254881_400862" xmi:uuid="4813dbc0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373371_251422_248547"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293831_365532_277148"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="182"/>
      <waypoint x="288" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_555739_400865" xmi:uuid="4813e220-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373529_667402_248579"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293842_34289_277163"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="202"/>
      <waypoint x="288" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_209818_400868" xmi:uuid="4813e8d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373610_300906_248595"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293851_826288_277178"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="222"/>
      <waypoint x="288" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_792750_400871" xmi:uuid="4813edd0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373692_496324_248611"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293860_597098_277193"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="242"/>
      <waypoint x="288" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_111827_400874" xmi:uuid="4813f420-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373772_646237_248627"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293869_540982_277208"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="262"/>
      <waypoint x="288" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_412989_400877" xmi:uuid="4813fa00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373849_576322_248643"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293880_897394_277223"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="282"/>
      <waypoint x="288" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_320146_400880" xmi:uuid="4813ff40-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601373931_12180_248659"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293896_23191_277238"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="302"/>
      <waypoint x="288" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_360161_400883" xmi:uuid="481405a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374007_956319_248675"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293908_389716_277253"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="322"/>
      <waypoint x="288" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_611890_400886" xmi:uuid="48140aa0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374090_475294_248691"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293918_389623_277268"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="342"/>
      <waypoint x="288" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_465252_400889" xmi:uuid="48141160-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374164_397004_248707"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293927_989195_277283"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="362"/>
      <waypoint x="288" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_953414_400892" xmi:uuid="48141650-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374235_418142_248723"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293936_659083_277298"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="382"/>
      <waypoint x="288" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_323033_400895" xmi:uuid="48141c50-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374309_121806_248739"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293951_713768_277313"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="402"/>
      <waypoint x="288" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_616107_400898" xmi:uuid="48142180-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374392_405265_248755"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293963_347079_277328"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="422"/>
      <waypoint x="288" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_437005_400901" xmi:uuid="481428c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374474_817876_248771"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293977_301586_277343"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="442"/>
      <waypoint x="288" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_469300_400904" xmi:uuid="48142e70-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374558_309164_248787"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293992_558927_277358"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="462"/>
      <waypoint x="288" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_43774_400907" xmi:uuid="48143530-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374640_887056_248803"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294007_839642_277373"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="482"/>
      <waypoint x="288" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_895140_400910" xmi:uuid="48143b40-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374726_686271_248819"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294017_831521_277388"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="502"/>
      <waypoint x="288" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_250450_400913" xmi:uuid="481441f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374807_946862_248835"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294027_37129_277403"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="522"/>
      <waypoint x="288" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_657288_400916" xmi:uuid="48144740-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374886_402927_248851"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294036_747925_277418"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="542"/>
      <waypoint x="288" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_792413_400919" xmi:uuid="48144de0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601374965_581458_248867"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294049_336263_277433"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="562"/>
      <waypoint x="288" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_159545_400922" xmi:uuid="481454b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375047_511363_248883"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294059_737479_277448"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="582"/>
      <waypoint x="288" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_246926_400925" xmi:uuid="48145b80-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375126_342631_248899"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294068_78905_277463"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="602"/>
      <waypoint x="288" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_28723_400928" xmi:uuid="48146200-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375200_375668_248915"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294077_911548_277478"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="622"/>
      <waypoint x="288" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_683357_400931" xmi:uuid="48146b00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375279_772_248931"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294087_616263_277493"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="642"/>
      <waypoint x="288" y="642"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_509414_400934" xmi:uuid="481471c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375360_47776_248947"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294097_503032_277508"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="662"/>
      <waypoint x="288" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_865268_400937" xmi:uuid="481478a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375518_893432_248979"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294116_659718_277523"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="682"/>
      <waypoint x="288" y="682"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_162258_400940" xmi:uuid="48147f40-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375604_438376_248995"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294134_754436_277538"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="702"/>
      <waypoint x="288" y="702"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_474729_400943" xmi:uuid="481486e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375691_468177_249011"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294146_593997_277553"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="722"/>
      <waypoint x="288" y="722"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_191793_400946" xmi:uuid="48148d10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375773_610413_249027"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294159_510023_277568"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="742"/>
      <waypoint x="288" y="742"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_745819_400949" xmi:uuid="48149400-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375859_643319_249043"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294169_601860_277583"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="762"/>
      <waypoint x="288" y="762"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_9160_400952" xmi:uuid="48149bc0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601375937_716519_249059"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294179_434302_277598"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="782"/>
      <waypoint x="288" y="782"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_72506_400955" xmi:uuid="4814aea0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376014_981915_249075"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294187_646469_277613"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="802"/>
      <waypoint x="288" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_457596_400958" xmi:uuid="4814b720-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376094_134736_249091"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294197_620817_277628"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="822"/>
      <waypoint x="288" y="822"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_905570_400961" xmi:uuid="4814bdb0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376173_364739_249107"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294207_909724_277643"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="842"/>
      <waypoint x="288" y="842"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_327639_400964" xmi:uuid="4814c480-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376251_217569_249123"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294223_337754_277658"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="862"/>
      <waypoint x="288" y="862"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_742872_400967" xmi:uuid="4814cbe0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376337_866270_249139"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294233_650172_277673"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="879"/>
      <waypoint x="288" y="879"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_181796_400970" xmi:uuid="4814d3d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376416_292960_249155"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294242_42891_277688"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="903"/>
      <waypoint x="288" y="903"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_525428_400973" xmi:uuid="4814dce0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376495_880658_249171"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294251_502491_277703"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="921"/>
      <waypoint x="288" y="921"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_146791_400976" xmi:uuid="481531f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376577_915264_249187"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294261_399568_277718"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="942"/>
      <waypoint x="288" y="942"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_916038_400979" xmi:uuid="48153be0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376655_497706_249203"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294270_543671_277733"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="963"/>
      <waypoint x="288" y="963"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_751502_400982" xmi:uuid="48154b40-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376730_366228_249219"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294286_443932_277748"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="984"/>
      <waypoint x="288" y="984"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_4842_400985" xmi:uuid="481556c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376812_128847_249235"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294298_472718_277763"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1001"/>
      <waypoint x="288" y="1001"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_360971_400988" xmi:uuid="48156130-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376893_405962_249251"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294309_945223_277778"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1022"/>
      <waypoint x="288" y="1022"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_63440_400991" xmi:uuid="481567c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601376971_383118_249267"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294319_636217_277793"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1043"/>
      <waypoint x="288" y="1043"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_536105_400994" xmi:uuid="48156e10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377049_273925_249283"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294330_315348_277808"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1061"/>
      <waypoint x="288" y="1061"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496364_272036_400997" xmi:uuid="48157490-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377128_193138_249299"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294341_449036_277823"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1082"/>
      <waypoint x="288" y="1082"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496365_224326_401000" xmi:uuid="48157b10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377202_939890_249315"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294352_658597_277838"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1103"/>
      <waypoint x="288" y="1103"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496365_447600_401003" xmi:uuid="48158180-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377280_191083_249331"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294364_746970_277853"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1124"/>
      <waypoint x="288" y="1124"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496365_31991_401006" xmi:uuid="481587c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377358_604931_249347"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294374_1027_277868"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1141"/>
      <waypoint x="288" y="1141"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496365_889870_401009" xmi:uuid="48158e20-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377439_334666_249363"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294384_427315_277883"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1162"/>
      <waypoint x="288" y="1162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496365_652936_401012" xmi:uuid="48159480-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377518_452394_249379"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294396_742553_277898"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1183"/>
      <waypoint x="288" y="1183"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496365_580069_401015" xmi:uuid="48159a00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377597_783111_249395"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294408_217386_277913"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1201"/>
      <waypoint x="288" y="1201"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496365_521383_401018" xmi:uuid="4815a0e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377676_648873_249411"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294420_570885_277928"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1222"/>
      <waypoint x="288" y="1222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496365_267838_401021" xmi:uuid="4815a770-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377755_23128_249427"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294433_814523_277943"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1243"/>
      <waypoint x="288" y="1243"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496365_848451_401024" xmi:uuid="4815ae20-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601377839_595191_249443"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294444_649695_277958"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293749_838781_277024"/>
      <waypoint x="909" y="1264"/>
      <waypoint x="288" y="1264"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="912" height="1340"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446294450_148450_277970" xmi:uuid="766a69b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028109_381287_178740"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294473_944960_278002" xmi:uuid="771458e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397124_468034_226788"/>
      <ownedElement xmi:id="76ff3070-6c42-013d-d601-0800270c66d6" xmi:uuid="76ff3130-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397124_468034_226788"/>
        <text>mated_part_relationship:Mated_assembly_occurrence_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="77144430-6c42-013d-d601-0800270c66d6" xmi:uuid="771444f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397124_468034_226788"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="391" height="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294490_855033_278036" xmi:uuid="7714d340-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="776" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294545_142830_278051" xmi:uuid="77293610-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="776" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294560_14149_278066" xmi:uuid="7729b970-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="776" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294573_735457_278081" xmi:uuid="772a30e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="776" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294587_954215_278096" xmi:uuid="774035c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="776" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294603_909346_278111" xmi:uuid="7740ba10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="776" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294620_998913_278126" xmi:uuid="77412810-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="776" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294636_250521_278141" xmi:uuid="77573600-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="776" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496394_977752_401027" xmi:uuid="775745d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601382082_724249_250510"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294490_855033_278036"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294473_944960_278002"/>
      <waypoint x="776" y="62"/>
      <waypoint x="436" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496394_800716_401030" xmi:uuid="77574d20-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601382172_979433_250526"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294545_142830_278051"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294473_944960_278002"/>
      <waypoint x="776" y="82"/>
      <waypoint x="436" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496394_279972_401033" xmi:uuid="77575430-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601382307_381388_250542"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294560_14149_278066"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294473_944960_278002"/>
      <waypoint x="776" y="102"/>
      <waypoint x="436" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496394_832297_401036" xmi:uuid="77575c00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564397103_905868_226785"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294573_735457_278081"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294473_944960_278002"/>
      <waypoint x="776" y="122"/>
      <waypoint x="436" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496394_281549_401039" xmi:uuid="77576250-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601382410_635765_250573"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294587_954215_278096"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294473_944960_278002"/>
      <waypoint x="776" y="142"/>
      <waypoint x="436" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496394_218483_401042" xmi:uuid="77576820-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601382495_71416_250589"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294603_909346_278111"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294473_944960_278002"/>
      <waypoint x="776" y="162"/>
      <waypoint x="436" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496394_796443_401045" xmi:uuid="77576e20-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601382580_612734_250605"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294620_998913_278126"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294473_944960_278002"/>
      <waypoint x="776" y="182"/>
      <waypoint x="436" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496394_23483_401048" xmi:uuid="775773d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601382667_557400_250621"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294636_250521_278141"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294473_944960_278002"/>
      <waypoint x="776" y="202"/>
      <waypoint x="436" y="202"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="779" height="280"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446294865_281911_278426" xmi:uuid="7d524bb0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028033_86160_178712"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294889_447565_278458" xmi:uuid="7e4492c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393471_997255_226365"/>
      <ownedElement xmi:id="7e4177b0-6c42-013d-d601-0800270c66d6" xmi:uuid="7e417900-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393471_997255_226365"/>
        <text>shapeElementRelationship:Assembly_shape_constraint_item_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="7e427e90-6c42-013d-d601-0800270c66d6" xmi:uuid="7e427f70-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564393471_997255_226365"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="430" height="330"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294907_504102_278492" xmi:uuid="7e451400-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="881" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294915_983215_278507" xmi:uuid="7e8cb920-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../AnnotatedModelPresentation/AnnotatedModelPresentation.xmi#_18_4_1_65b021e_1674590225569_36926_72230"/>
      <bounds x="881" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294931_453877_278522" xmi:uuid="7ea177f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="881" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294940_28049_278537" xmi:uuid="7ea20d90-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1693389845452_895549_96322"/>
      <bounds x="881" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294954_645355_278552" xmi:uuid="7ebcbdf0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="881" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294963_138608_278567" xmi:uuid="7ed96100-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="881" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294978_617251_278582" xmi:uuid="7ed9f280-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="881" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446294992_777113_278597" xmi:uuid="7eda7cb0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="881" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295006_41654_278612" xmi:uuid="7eeeea80-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="881" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295018_190070_278627" xmi:uuid="7eefbea0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="881" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295034_807308_278642" xmi:uuid="7f015580-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="881" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295051_214903_278657" xmi:uuid="7f2111e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="881" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295066_216343_278672" xmi:uuid="7f219ec0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="881" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295081_515546_278687" xmi:uuid="7f222f50-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="881" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_74047_401093" xmi:uuid="7f2240f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379347_813099_249872"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294907_504102_278492"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="62"/>
      <waypoint x="475" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_15786_401096" xmi:uuid="7f224870-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379440_105325_249888"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294915_983215_278507"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="82"/>
      <waypoint x="475" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_991757_401099" xmi:uuid="7f225130-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379517_348808_249904"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294931_453877_278522"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="102"/>
      <waypoint x="475" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_691625_401102" xmi:uuid="7f225ae0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379680_382448_249936"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294940_28049_278537"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="122"/>
      <waypoint x="475" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_925143_401105" xmi:uuid="7f3c6220-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379757_878736_249952"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294954_645355_278552"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="142"/>
      <waypoint x="475" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_852821_401108" xmi:uuid="7f3c6a60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379839_810_249968"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294963_138608_278567"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="162"/>
      <waypoint x="475" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_73802_401111" xmi:uuid="7f3c7290-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379917_698974_249984"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294978_617251_278582"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="182"/>
      <waypoint x="475" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_755402_401114" xmi:uuid="7f3c7aa0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601379999_693395_250000"/>
      <source xmi:idref="_18_4_1_65b021e_1727446294992_777113_278597"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="202"/>
      <waypoint x="475" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_626223_401117" xmi:uuid="7f3c8220-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601380082_900154_250016"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295006_41654_278612"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="222"/>
      <waypoint x="475" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_686449_401120" xmi:uuid="7f3c88b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601380164_798710_250032"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295018_190070_278627"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="242"/>
      <waypoint x="475" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_622039_401123" xmi:uuid="7f3c9030-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601380323_200551_250064"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295034_807308_278642"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="262"/>
      <waypoint x="475" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_805308_401126" xmi:uuid="7f3c96a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601380410_966490_250080"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295051_214903_278657"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="282"/>
      <waypoint x="475" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_514332_401129" xmi:uuid="7f3c9bc0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601380494_274299_250096"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295066_216343_278672"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="302"/>
      <waypoint x="475" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496403_922886_401132" xmi:uuid="7f3ca1b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601380577_881475_250112"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295081_515546_278687"/>
      <target xmi:idref="_18_4_1_65b021e_1727446294889_447565_278458"/>
      <waypoint x="881" y="322"/>
      <waypoint x="475" y="322"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="884" height="400"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446293302_375184_276612" xmi:uuid="8333de80-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564028049_734479_178723"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293326_863336_276644" xmi:uuid="844f4430-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394208_296445_226434"/>
      <ownedElement xmi:id="84285f60-6c42-013d-d601-0800270c66d6" xmi:uuid="84286020-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394208_296445_226434"/>
        <text>mated_part_association:Assembled_part_association</text>
      </ownedElement>
      <ownedElement xmi:id="844f2fc0-6c42-013d-d601-0800270c66d6" xmi:uuid="844f3070-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Mating.xmi#_18_4_1_65b021e_1688564394208_296445_226434"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="320" height="470"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293342_283034_276678" xmi:uuid="844fc3a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="825" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293357_502492_276693" xmi:uuid="846ed640-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="825" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293372_910440_276708" xmi:uuid="846fa160-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="825" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293386_280731_276723" xmi:uuid="847d00b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="825" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293397_873976_276738" xmi:uuid="84995de0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="825" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293466_116085_276754" xmi:uuid="84a2dba0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="825" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293480_638225_276769" xmi:uuid="84bfa820-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="825" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293495_421096_276784" xmi:uuid="84d6bdf0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="825" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293510_667863_276799" xmi:uuid="84eda5a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="825" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293522_817061_276814" xmi:uuid="85073280-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="825" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293538_730171_276829" xmi:uuid="8507ba90-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="825" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293554_795199_276844" xmi:uuid="8520eb10-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="825" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293566_766462_276859" xmi:uuid="85222270-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="825" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293577_11190_276874" xmi:uuid="85558c80-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="825" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293585_306351_276889" xmi:uuid="856a2ec0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569585631648_131692_86657"/>
      <bounds x="825" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293599_406057_276904" xmi:uuid="856ab2c0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="825" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293608_397172_276919" xmi:uuid="856b54b0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ProcessPlan/ProcessPlan.xmi#_18_4_1_65b021e_1688564037651_912713_180830"/>
      <bounds x="825" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293623_678793_276934" xmi:uuid="857d7490-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="825" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293632_359713_276949" xmi:uuid="859f2310-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1570008507179_203957_61908"/>
      <bounds x="825" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293643_895918_276964" xmi:uuid="85ae0860-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="825" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446293715_418770_276980" xmi:uuid="85c4f790-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="825" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_732557_400781" xmi:uuid="85c544f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601382786_163771_250700"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293342_283034_276678"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="62"/>
      <waypoint x="365" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_823651_400784" xmi:uuid="85db3130-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601382875_727833_250716"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293357_502492_276693"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="82"/>
      <waypoint x="365" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_499456_400787" xmi:uuid="85db60f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383032_517131_250748"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293372_910440_276708"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="102"/>
      <waypoint x="365" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_663373_400790" xmi:uuid="85db75a0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383112_831598_250764"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293386_280731_276723"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="122"/>
      <waypoint x="365" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_981103_400793" xmi:uuid="85db86e0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383194_34521_250780"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293397_873976_276738"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="142"/>
      <waypoint x="365" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_346658_400796" xmi:uuid="85db99f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1727446293398_74987_276750"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293466_116085_276754"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="162"/>
      <waypoint x="365" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_570036_400799" xmi:uuid="85dbb330-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383271_182547_250796"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293480_638225_276769"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="182"/>
      <waypoint x="365" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_726089_400802" xmi:uuid="85dbc430-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383360_806186_250812"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293495_421096_276784"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="202"/>
      <waypoint x="365" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_647959_400805" xmi:uuid="85dbd5f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383442_440358_250828"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293510_667863_276799"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="222"/>
      <waypoint x="365" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_159259_400808" xmi:uuid="85dbeb00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383529_471348_250844"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293522_817061_276814"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="242"/>
      <waypoint x="365" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_751871_400811" xmi:uuid="85dc0d80-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383692_822313_250876"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293538_730171_276829"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="262"/>
      <waypoint x="365" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_722280_400814" xmi:uuid="85dc2ef0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383776_223955_250892"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293554_795199_276844"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="282"/>
      <waypoint x="365" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_784545_400817" xmi:uuid="85dc3d60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383865_94502_250908"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293566_766462_276859"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="302"/>
      <waypoint x="365" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_421900_400820" xmi:uuid="85ed2480-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601383962_855595_250924"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293577_11190_276874"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="322"/>
      <waypoint x="365" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_383532_400823" xmi:uuid="85ed2c00-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601384049_506496_250940"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293585_306351_276889"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="342"/>
      <waypoint x="365" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_69547_400826" xmi:uuid="85ed4180-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601384130_685886_250956"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293599_406057_276904"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="362"/>
      <waypoint x="365" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_568510_400829" xmi:uuid="85ed49d0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601384222_50072_250972"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293608_397172_276919"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="382"/>
      <waypoint x="365" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_636096_400832" xmi:uuid="85ed88f0-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601384298_467594_250988"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293623_678793_276934"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="402"/>
      <waypoint x="365" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_331549_400835" xmi:uuid="85ee8b60-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601384381_530245_251004"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293632_359713_276949"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="422"/>
      <waypoint x="365" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_663551_400838" xmi:uuid="86087d80-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1696601384461_880491_251020"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293643_895918_276964"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="442"/>
      <waypoint x="365" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496353_540586_400841" xmi:uuid="86088890-6c42-013d-d601-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Mating.xmi#_18_4_1_65b021e_1727446293644_10703_276976"/>
      <source xmi:idref="_18_4_1_65b021e_1727446293715_418770_276980"/>
      <target xmi:idref="_18_4_1_65b021e_1727446293326_863336_276644"/>
      <waypoint x="825" y="462"/>
      <waypoint x="365" y="462"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="828" height="540"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
