<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_2b2015d_1620309377855_171837_67420" xmi:uuid="5999d5f0-b6e9-0139-174a-45cc4a55db9f">
    <base_UMLClassDiagram xmi:idref="_18_4_1_2b2015d_1620309377841_639396_67409"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_8e001ed_1498551964843_204074_14127"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_2b2015d_1620309399912_125333_67452" xmi:uuid="5c5f5e10-b6e9-0139-174a-45cc4a55db9f">
    <base_UMLClassDiagram xmi:idref="_18_4_1_2b2015d_1620309399904_870113_67441"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_8e001ed_1498551964843_204074_14127"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703185514962_424513_439612" xmi:uuid="912d65e0-915b-013c-715a-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703185514957_831295_439601"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_8e001ed_1498551964843_204074_14127"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446312293_18226_292401" xmi:uuid="2f0ef190-6c42-013d-931f-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446312286_37106_292390"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_29c0149_1619013277232_933760_66215"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446311990_100457_292038" xmi:uuid="345a2900-6c42-013d-931f-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446311981_84968_292027"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_29c0149_1619074571411_695821_69010"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446311920_544446_291945" xmi:uuid="3c6acd30-6c42-013d-931f-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446311913_170113_291934"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_29c0149_1619074630369_511218_69105"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446311598_105789_291581" xmi:uuid="42ee5210-6c42-013d-931f-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446311590_639909_291570"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_29c0149_1619074512048_940092_68961"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1619075037142_798224_69503" xmi:uuid="df927490-8fde-0139-a9d9-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1619075037136_532498_69492"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_29c0149_1619013277232_933760_66215"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1619074840744_726637_69208" xmi:uuid="dff81f00-8fde-0139-a9d9-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1619074840728_237454_69197"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_29c0149_1619074571411_695821_69010"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1619074957083_61626_69311" xmi:uuid="e0068520-8fde-0139-a9d9-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1619074957083_449918_69300"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_29c0149_1619074630369_511218_69105"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1619074976529_662218_69375" xmi:uuid="e006db60-8fde-0139-a9d9-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1619074976529_547724_69364"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_29c0149_1619074512048_940092_68961"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_29c0149_1619075044421_484515_69535" xmi:uuid="e0241c80-8fde-0139-a9d9-78b156d8ad1a">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_29c0149_1619075044421_499634_69524"/>
    <defaultNamespace href="Probability.xmi#_18_4_1_29c0149_1619074464332_875732_68909"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_2b2015d_1620309377841_639396_67409" xmi:uuid="59983be0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Probability.xmi#_18_4_1_8e001ed_1498551964843_204074_14127"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620313756192_578928_67832" xmi:uuid="59e032c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074464332_875732_68909"/>
      <ownedElement xmi:id="599dcaf0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="599dcc50-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074464332_875732_68909"/>
        <text>ProbabilityDistribution</text>
      </ownedElement>
      <ownedElement xmi:id="599fedb0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="599fef60-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="d8bfe2e0-6c41-013d-931f-0800270c66d6" xmi:uuid="d8bfe4d0-6c41-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d8c02650-6c41-013d-931f-0800270c66d6" xmi:uuid="d8c02710-6c41-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="d8c0a6b0-6c41-013d-931f-0800270c66d6" xmi:uuid="d8c0a760-6c41-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1620855079269_709058_73334"/>
          <text>selectId</text>
        </ownedElement>
        <ownedElement xmi:id="d8d1c670-6c41-013d-931f-0800270c66d6" xmi:uuid="d8d1c730-6c41-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766881253_888405_69680"/>
          <text>valueComponentToAnyNumber</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="59ca2340-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="59ca24a0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="59cc3530-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="59cc36d0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="59d02460-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="59d02640-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1620854971984_384414_73300"/>
          <text>Id</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="59d4f7c0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="59d4f8f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="59d68550-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="59d68740-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>values</text>
        </ownedElement>
        <ownedElement xmi:id="59d9dd40-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="59d9df20-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1622065987311_367577_71791"/>
          <text>Mean</text>
        </ownedElement>
        <ownedElement xmi:id="59dd19f0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="59dd2330-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1622108852139_762909_71874"/>
          <text>Variance</text>
        </ownedElement>
        <ownedElement xmi:id="59e02830-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="59e02970-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1622109383157_209347_71923"/>
          <text>IsContinuous</text>
        </ownedElement>
      </ownedElement>
      <bounds x="186" y="147" width="140" height="153"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620313781088_746884_67874" xmi:uuid="5a0db1d0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074512048_940092_68961"/>
      <ownedElement xmi:id="59e37630-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="59e378f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074512048_940092_68961"/>
        <text>ParameterizedDistribution</text>
      </ownedElement>
      <ownedElement xmi:id="59e73720-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="59e738b0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="5a091d30-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a091ed0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5a0a34a0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a0a3670-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="5a0da2c0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a0da3f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1621424174414_386578_181684"/>
          <text>HasParameters</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="10d161e0-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="10d16300-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="10d1a230-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="10d1a360-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLLabel">
          <text>values</text>
        </ownedElement>
        <ownedElement xmi:id="10d28440-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="10d28580-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1622048626375_567176_68783"/>
          <text>ParameterizationName</text>
        </ownedElement>
      </ownedElement>
      <bounds x="49" y="336" width="194" height="103"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620313790784_533260_67916" xmi:uuid="5a260570-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074571411_695821_69010"/>
      <ownedElement xmi:id="5a115fe0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a116180-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074571411_695821_69010"/>
        <text>DistributionByValue</text>
      </ownedElement>
      <ownedElement xmi:id="5a14e310-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a14e4c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="5a2255a0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a225730-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5a2366c0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a2367e0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>values</text>
        </ownedElement>
        <ownedElement xmi:id="5a25fb10-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a260020-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1622053558791_512080_71042"/>
          <text>DistributionFunction</text>
        </ownedElement>
      </ownedElement>
      <bounds x="266" y="336" width="155" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620315065265_448194_68000" xmi:uuid="5a386060-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074630369_511218_69105"/>
      <ownedElement xmi:id="5a288f10-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a2891c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074630369_511218_69105"/>
        <text>FunctionValuePair</text>
      </ownedElement>
      <ownedElement xmi:id="5a2b2850-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a2b2ad0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="5a31ff20-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a320060-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5a32f5e0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a32f6d0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="5a35b800-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a35b9f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1620850823466_182337_72128"/>
          <text>VariableValue</text>
        </ownedElement>
        <ownedElement xmi:id="5a385210-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5a385370-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1622109798886_358300_71974"/>
          <text>FunctionValue</text>
        </ownedElement>
      </ownedElement>
      <bounds x="266" y="441" width="176" height="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620845198598_111579_68122" xmi:uuid="5abbb530-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074484951_736198_68954"/>
      <source xmi:idref="_18_4_1_29c0149_1622643861260_650053_71669"/>
      <target xmi:idref="_18_4_1_2b2015d_1620313756192_578928_67832"/>
      <waypoint x="256" y="131"/>
      <waypoint x="256" y="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620845198598_912442_68123" xmi:uuid="5abec660-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074558674_600287_69006"/>
      <source xmi:idref="_18_4_1_2b2015d_1620313781088_746884_67874"/>
      <target xmi:idref="_18_4_1_2b2015d_1620313756192_578928_67832"/>
      <waypoint x="144" y="336"/>
      <waypoint x="144" y="312"/>
      <waypoint x="256" y="312"/>
      <waypoint x="256" y="300"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620845198599_878973_68124" xmi:uuid="5ac1cac0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074591074_573904_69055"/>
      <source xmi:idref="_18_4_1_2b2015d_1620313790784_533260_67916"/>
      <target xmi:idref="_18_4_1_2b2015d_1620313756192_578928_67832"/>
      <waypoint x="353" y="336"/>
      <waypoint x="353" y="312"/>
      <waypoint x="256" y="312"/>
      <waypoint x="256" y="300"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622643861260_650053_71669" xmi:uuid="5c5b55e0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_ValueWithUnit"/>
      <ownedElement xmi:id="5ae86b90-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5ae86da0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_ValueWithUnit"/>
        <text>ValueWithUnit</text>
      </ownedElement>
      <ownedElement xmi:id="5b1251b0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5b1253d0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="5bfdedc0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5bfdef60-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5bff6920-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5bff6aa0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="df2fbdb0-0d30-013c-5e2e-5b8e392dc4e5" xmi:uuid="df2fbef0-0d30-013c-5e2e-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_2_attr_ValueWithUnit-Unit"/>
          <text>Unit</text>
        </ownedElement>
        <ownedElement xmi:id="df39b280-0d30-013c-5e2e-5b8e392dc4e5" xmi:uuid="df39b380-0d30-013c-5e2e-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_2_attr_PropertyValue-Qualifications"/>
          <text>Qualifications</text>
        </ownedElement>
      </ownedElement>
      <bounds x="154" y="49" width="204" height="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1632400287853_760621_62735" xmi:uuid="1b101830-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1632400287668_493562_62720"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1636738305562_294525_63859" xmi:uuid="21bc6200-3397-013a-17dd-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_2b2015d_1632400287668_249044_62721"/>
        <bounds x="357" y="408" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1632400287690_568315_62725" xmi:uuid="21bd1810-3397-013a-17dd-45cc4a55db9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622643424435_741237_71613"/>
        <bounds x="271" y="425" width="80" height="13"/>
        <text>DefinedFunction</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1632400287706_61669_62727" xmi:uuid="21bdde70-3397-013a-17dd-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622643424435_741237_71613"/>
        <bounds x="357" y="425" width="24" height="13"/>
        <text>1..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1620313790784_533260_67916"/>
      <target xmi:idref="_18_4_1_2b2015d_1620315065265_448194_68000"/>
      <waypoint x="354" y="405"/>
      <waypoint x="354" y="441"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="525" height="538"/>
    <name>ProbabilityDistribution</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_2b2015d_1620309399904_870113_67441" xmi:uuid="5c5d6850-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Probability.xmi#_18_4_1_8e001ed_1498551964843_204074_14127"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620309419210_531463_67478" xmi:uuid="5c687d50-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1620309419202_417106_67476"/>
      <ownedElement xmi:id="5c63b600-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5c63b7c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Probability.xmi#_18_4_1_2b2015d_1620309419202_417106_67476"/>
        <text>ProbabilitySelect</text>
      </ownedElement>
      <ownedElement xmi:id="5c66c280-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5c66c3f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="5c680ed0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5c681240-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="227" y="49" width="107" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620309715260_766578_67607" xmi:uuid="5f3763c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1583494422924_703037_54628"/>
      <ownedElement xmi:id="5c9df3e0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5c9df550-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1583494422924_703037_54628"/>
        <text>ExternalValue</text>
      </ownedElement>
      <ownedElement xmi:id="5cc61fd0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5cc62110-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="02628a30-6c42-013d-931f-0800270c66d6" xmi:uuid="02628b70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="02630290-6c42-013d-931f-0800270c66d6" xmi:uuid="02630410-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="038e8160-6c42-013d-931f-0800270c66d6" xmi:uuid="038e8220-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1584100483796_569264_56301"/>
          <text>selectProxy</text>
        </ownedElement>
        <ownedElement xmi:id="0465b640-6c42-013d-931f-0800270c66d6" xmi:uuid="0465b7c0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1584101143619_304021_56614"/>
          <text>chooseId</text>
        </ownedElement>
        <ownedElement xmi:id="054273d0-6c42-013d-931f-0800270c66d6" xmi:uuid="054274f0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1584101609873_737100_56910"/>
          <text>default</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="5ee6aea0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5ee6b020-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5ee7a540-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5ee7a650-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="dfcead70-0d30-013c-5e2e-5b8e392dc4e5" xmi:uuid="dfceae70-0d30-013c-5e2e-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1583494534169_719692_54687"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="42" y="161" width="152" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620309756393_784041_67655" xmi:uuid="60c6bc60-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_NumericalValue"/>
      <ownedElement xmi:id="5f5e4470-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5f5e45c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_NumericalValue"/>
        <text>NumericalValue</text>
      </ownedElement>
      <ownedElement xmi:id="5f822e20-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="5f822f60-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="0b8d46f0-6c42-013d-931f-0800270c66d6" xmi:uuid="0b8d4790-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0b8d7870-6c42-013d-931f-0800270c66d6" xmi:uuid="0b8d78a0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="0c32a4b0-6c42-013d-931f-0800270c66d6" xmi:uuid="0c32a560-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1539874620634_456809_33297"/>
          <text>valueComponentToAnyNumber</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="60771640-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="607719e0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="607895a0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="607896c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="e03174c0-0d30-013c-5e2e-5b8e392dc4e5" xmi:uuid="e03175c0-0d30-013c-5e2e-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_2_attr_NumericalValue-ValueContext"/>
          <text>ValueContext</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="60a02330-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="60a024d0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="60a1e000-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="60a1e190-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>values</text>
        </ownedElement>
        <ownedElement xmi:id="e03bd810-0d30-013c-5e2e-5b8e392dc4e5" xmi:uuid="e03bd930-0d30-013c-5e2e-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_2_attr_NumericalValue-ValueComponent"/>
          <text>ValueComponent</text>
        </ownedElement>
      </ownedElement>
      <bounds x="364" y="161" width="195" height="103"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620309795209_715476_67700" xmi:uuid="61d09480-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_StringValue"/>
      <ownedElement xmi:id="60f00c20-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="60f00d60-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_StringValue"/>
        <text>StringValue</text>
      </ownedElement>
      <ownedElement xmi:id="61140b70-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="61140ca0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="61a4daa0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="61a4dbd0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="61a62a80-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="61a62ba0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>values</text>
        </ownedElement>
        <ownedElement xmi:id="e081ba60-0d30-013c-5e2e-5b8e392dc4e5" xmi:uuid="e081bb60-0d30-013c-5e2e-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_2_attr_StringValue-ValueComponent"/>
          <text>ValueComponent</text>
        </ownedElement>
      </ownedElement>
      <bounds x="210" y="161" width="142" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1620309861380_73836_67745" xmi:uuid="61e50a00-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619013277232_933760_66215"/>
      <ownedElement xmi:id="61d3a040-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="61d3a1f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619013277232_933760_66215"/>
        <text>ProbabilityDerived</text>
      </ownedElement>
      <ownedElement xmi:id="61d648e0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="61d64a90-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="61deef10-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="61def050-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="61dfd390-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="61dfd490-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="61e27b80-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="61e27ca0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1621424560135_297597_181899"/>
          <text>HasParameter</text>
        </ownedElement>
        <ownedElement xmi:id="61e4fd40-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="61e4fe80-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1621427028349_529274_67409"/>
          <text>DerivesFrom</text>
        </ownedElement>
      </ownedElement>
      <bounds x="364" y="322" width="199" height="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621418354392_721502_143724" xmi:uuid="620aab20-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_29c0149_1621416515956_62503_70006"/>
      <source xmi:idref="_18_4_1_2b2015d_1620309419210_531463_67478"/>
      <target xmi:idref="_18_4_1_2b2015d_1620309715260_766578_67607"/>
      <waypoint x="116" y="130"/>
      <waypoint x="116" y="161"/>
      <waypoint x="280" y="97"/>
      <waypoint x="280" y="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621421960152_94394_181499" xmi:uuid="623070d0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_29c0149_1621418488521_648512_70515"/>
      <source xmi:idref="_18_4_1_2b2015d_1620309419210_531463_67478"/>
      <target xmi:idref="_18_4_1_2b2015d_1620309756393_784041_67655"/>
      <waypoint x="460" y="130"/>
      <waypoint x="460" y="161"/>
      <waypoint x="280" y="97"/>
      <waypoint x="280" y="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621421960153_832420_181500" xmi:uuid="6259e5f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_29c0149_1621418389581_871321_70510"/>
      <source xmi:idref="_18_4_1_2b2015d_1620309419210_531463_67478"/>
      <target xmi:idref="_18_4_1_2b2015d_1620309795209_715476_67700"/>
      <waypoint x="280" y="130"/>
      <waypoint x="280" y="161"/>
      <waypoint x="280" y="97"/>
      <waypoint x="280" y="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620846355664_346664_68276" xmi:uuid="628722a0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620846357509_92575_68277"/>
      <source xmi:idref="_18_4_1_2b2015d_1620309756393_784041_67655"/>
      <target xmi:idref="_18_4_1_2b2015d_1620309861380_73836_67745"/>
      <waypoint x="459" y="264"/>
      <waypoint x="459" y="322"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="578" height="419"/>
    <name>Probability</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703185514957_831295_439601" xmi:uuid="912d1e60-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Probability.xmi#_18_4_1_8e001ed_1498551964843_204074_14127"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185515018_162169_439634" xmi:uuid="9130c0f0-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1620309419202_417106_67476"/>
      <ownedElement xmi:id="912f52c0-915b-013c-715a-0a5172f4a469" xmi:uuid="912f53b0-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Probability.xmi#_18_4_1_2b2015d_1620309419202_417106_67476"/>
        <text>ProbabilitySelect</text>
      </ownedElement>
      <ownedElement xmi:id="912fef20-915b-013c-715a-0a5172f4a469" xmi:uuid="912fefe0-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="91302480-915b-013c-715a-0a5172f4a469" xmi:uuid="91302520-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="868" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185515252_140937_439680" xmi:uuid="91cd1aa0-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1583494422924_703037_54628"/>
      <ownedElement xmi:id="913c35e0-915b-013c-715a-0a5172f4a469" xmi:uuid="913c36f0-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1583494422924_703037_54628"/>
        <text>ExternalValue</text>
      </ownedElement>
      <ownedElement xmi:id="16110d30-6c42-013d-931f-0800270c66d6" xmi:uuid="16110dd0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="1ad87110-6c42-013d-931f-0800270c66d6" xmi:uuid="1ad871b0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="1ad89db0-6c42-013d-931f-0800270c66d6" xmi:uuid="1ad89df0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="1ba76ee0-6c42-013d-931f-0800270c66d6" xmi:uuid="1ba76fb0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1584100483796_569264_56301"/>
          <text>selectProxy</text>
        </ownedElement>
        <ownedElement xmi:id="1c3d24a0-6c42-013d-931f-0800270c66d6" xmi:uuid="1c3d2560-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1584101143619_304021_56614"/>
          <text>chooseId</text>
        </ownedElement>
        <ownedElement xmi:id="1cc8c870-6c42-013d-931f-0800270c66d6" xmi:uuid="1cc8c910-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1584101609873_737100_56910"/>
          <text>default</text>
        </ownedElement>
      </ownedElement>
      <bounds x="65" y="95" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185515646_173070_439725" xmi:uuid="92304eb0-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_NumericalValue"/>
      <ownedElement xmi:id="91d84800-915b-013c-715a-0a5172f4a469" xmi:uuid="91d84910-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_NumericalValue"/>
        <text>NumericalValue</text>
      </ownedElement>
      <ownedElement xmi:id="1deaf990-6c42-013d-931f-0800270c66d6" xmi:uuid="1deafa30-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="214f4870-6c42-013d-931f-0800270c66d6" xmi:uuid="214f4900-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="214f73f0-6c42-013d-931f-0800270c66d6" xmi:uuid="214f7420-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>constraints</text>
        </ownedElement>
        <ownedElement xmi:id="21ece540-6c42-013d-931f-0800270c66d6" xmi:uuid="21ece620-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1539874620634_456809_33297"/>
          <text>valueComponentToAnyNumber</text>
        </ownedElement>
      </ownedElement>
      <bounds x="341" y="95" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185515805_563424_439769" xmi:uuid="92721a90-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_StringValue"/>
      <ownedElement xmi:id="923b7f30-915b-013c-715a-0a5172f4a469" xmi:uuid="923b8030-915b-013c-715a-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_StringValue"/>
        <text>StringValue</text>
      </ownedElement>
      <ownedElement xmi:id="2323d440-6c42-013d-931f-0800270c66d6" xmi:uuid="2323d4e0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="617" y="95" width="256" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="928" height="175"/>
    <name>ProbabilitySelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446312286_37106_292390" xmi:uuid="2f0eb3c0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Probability.xmi#_18_4_1_29c0149_1619013277232_933760_66215"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312311_295302_292422" xmi:uuid="2fcac540-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619077207530_135830_70097"/>
      <ownedElement xmi:id="2fca3d90-6c42-013d-931f-0800270c66d6" xmi:uuid="2fca3e50-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619077207530_135830_70097"/>
        <text>theProbabilityDerived:Probability_derived</text>
      </ownedElement>
      <ownedElement xmi:id="2fcabd80-6c42-013d-931f-0800270c66d6" xmi:uuid="2fcabdf0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619077207530_135830_70097"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="256" height="490"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312327_661949_292456" xmi:uuid="2fcb4ec0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="699" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312342_460295_292471" xmi:uuid="2fcb8380-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="699" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312357_315676_292486" xmi:uuid="2fcbb870-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="699" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312368_695965_292501" xmi:uuid="2fcbfaa0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="699" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312383_92645_292516" xmi:uuid="2fcc3750-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="699" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312393_17968_292531" xmi:uuid="2fcc6bf0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="699" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312407_632401_292546" xmi:uuid="2fcca4f0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="699" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312421_882219_292561" xmi:uuid="2fcce560-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="699" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312435_595966_292576" xmi:uuid="2fcd1850-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="699" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312445_636875_292591" xmi:uuid="30042d70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="699" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312458_175913_292606" xmi:uuid="300484a0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="699" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312474_671959_292621" xmi:uuid="3004bf40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="699" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312490_704124_292636" xmi:uuid="3004f550-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="699" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312502_252433_292651" xmi:uuid="30052d20-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="699" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312514_804349_292666" xmi:uuid="300565f0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="699" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312529_509999_292681" xmi:uuid="3005a2d0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="699" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312601_505848_292712" xmi:uuid="301fca70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1643105834693_158054_66560"/>
      <bounds x="699" y="374" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312610_565812_292727" xmi:uuid="30202c40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="699" y="394" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312620_27913_292742" xmi:uuid="30206d00-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
      <bounds x="699" y="414" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312629_26616_292757" xmi:uuid="3020a6a0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
      <bounds x="699" y="434" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312640_470871_292772" xmi:uuid="3020e010-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="699" y="454" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_479415_403556" xmi:uuid="3020ef50-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422760_765175_265114"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312327_661949_292456"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="62"/>
      <waypoint x="301" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_233453_403559" xmi:uuid="3020f680-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422848_692168_265130"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312342_460295_292471"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="82"/>
      <waypoint x="301" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_980099_403562" xmi:uuid="3020fe60-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422929_51161_265146"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312357_315676_292486"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="102"/>
      <waypoint x="301" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_463337_403565" xmi:uuid="302106b0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423013_620400_265162"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312368_695965_292501"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="122"/>
      <waypoint x="301" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_692544_403568" xmi:uuid="303c85f0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423088_371657_265178"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312383_92645_292516"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="142"/>
      <waypoint x="301" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_735646_403571" xmi:uuid="303c8f60-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423172_535439_265194"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312393_17968_292531"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="162"/>
      <waypoint x="301" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_816277_403574" xmi:uuid="303c96c0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423249_920121_265210"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312407_632401_292546"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="182"/>
      <waypoint x="301" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_533381_403577" xmi:uuid="303c9e40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423332_984963_265226"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312421_882219_292561"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="202"/>
      <waypoint x="301" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_663245_403580" xmi:uuid="303ca9c0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423414_167055_265242"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312435_595966_292576"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="222"/>
      <waypoint x="301" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_460978_403583" xmi:uuid="303cb8b0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423495_962150_265258"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312445_636875_292591"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="242"/>
      <waypoint x="301" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_857294_403586" xmi:uuid="303cc400-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423573_259416_265274"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312458_175913_292606"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="262"/>
      <waypoint x="301" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_660948_403589" xmi:uuid="303cd6a0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423656_430089_265290"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312474_671959_292621"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="282"/>
      <waypoint x="301" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_723209_403592" xmi:uuid="303cdd90-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423741_670032_265306"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312490_704124_292636"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="302"/>
      <waypoint x="301" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_978937_403595" xmi:uuid="303ceb70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423826_96201_265322"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312502_252433_292651"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="322"/>
      <waypoint x="301" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_721093_403598" xmi:uuid="303cf0e0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423905_97016_265338"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312514_804349_292666"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="342"/>
      <waypoint x="301" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_134576_403601" xmi:uuid="303cff40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601423985_436644_265354"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312529_509999_292681"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="362"/>
      <waypoint x="301" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_770653_403607" xmi:uuid="303d0400-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424147_970736_265386"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312601_505848_292712"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="381"/>
      <waypoint x="301" y="381"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_790821_403610" xmi:uuid="303d1230-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424221_65445_265402"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312610_565812_292727"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="401"/>
      <waypoint x="301" y="401"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_910157_403613" xmi:uuid="303d2050-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424298_785361_265418"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312620_27913_292742"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="421"/>
      <waypoint x="301" y="421"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_993598_403616" xmi:uuid="303d2de0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424375_724265_265434"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312629_26616_292757"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="441"/>
      <waypoint x="301" y="441"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499670_812491_403619" xmi:uuid="303d32d0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424454_309389_265450"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312640_470871_292772"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312311_295302_292422"/>
      <waypoint x="699" y="461"/>
      <waypoint x="301" y="461"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="702" height="560"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446311981_84968_292027" xmi:uuid="3459e7a0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074571411_695821_69010"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312011_203549_292059" xmi:uuid="35061f70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074890771_850104_69229"/>
      <ownedElement xmi:id="35057650-6c42-013d-931f-0800270c66d6" xmi:uuid="350577c0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074890771_850104_69229"/>
        <text>theDistributionByValue:Distribution_by_value</text>
      </ownedElement>
      <ownedElement xmi:id="35061030-6c42-013d-931f-0800270c66d6" xmi:uuid="35061140-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074890771_850104_69229"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="279" height="450"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312029_723376_292093" xmi:uuid="35067300-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="713" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312046_880949_292108" xmi:uuid="3519e120-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="713" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312062_479623_292123" xmi:uuid="351a23a0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="713" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312072_749931_292138" xmi:uuid="3529b450-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="713" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312086_529709_292153" xmi:uuid="3529f600-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="713" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312097_765874_292168" xmi:uuid="352a34a0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="713" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312112_469658_292183" xmi:uuid="352a8640-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="713" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312126_69876_292198" xmi:uuid="352ad120-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="713" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312141_25852_292213" xmi:uuid="352b1950-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="713" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312151_951450_292228" xmi:uuid="35484690-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="713" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312165_76905_292243" xmi:uuid="35488dc0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="713" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312182_895953_292258" xmi:uuid="3548cab0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="713" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312200_120430_292273" xmi:uuid="35491a10-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="713" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312212_445227_292288" xmi:uuid="355be380-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="713" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312224_864165_292303" xmi:uuid="355c3290-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="713" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312239_67358_292318" xmi:uuid="355c7300-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="713" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312249_720300_292333" xmi:uuid="355cb220-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="713" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312259_381815_292348" xmi:uuid="355d0120-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
      <bounds x="713" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312268_998790_292363" xmi:uuid="355d4b60-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
      <bounds x="713" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312279_439845_292378" xmi:uuid="35719c40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="713" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_225314_403496" xmi:uuid="3571ac80-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424565_307959_265529"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312029_723376_292093"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="62"/>
      <waypoint x="324" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_345862_403499" xmi:uuid="3571b420-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424652_606261_265545"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312046_880949_292108"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="82"/>
      <waypoint x="324" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_768792_403502" xmi:uuid="3571baa0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424735_23742_265561"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312062_479623_292123"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="102"/>
      <waypoint x="324" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_623407_403505" xmi:uuid="3571c2d0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424817_344229_265577"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312072_749931_292138"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="122"/>
      <waypoint x="324" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_705992_403508" xmi:uuid="3571ea40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424896_73841_265593"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312086_529709_292153"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="142"/>
      <waypoint x="324" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_815259_403511" xmi:uuid="3571f060-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601424978_358502_265609"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312097_765874_292168"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="162"/>
      <waypoint x="324" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_863459_403514" xmi:uuid="3571f5b0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425057_999103_265625"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312112_469658_292183"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="182"/>
      <waypoint x="324" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_527899_403517" xmi:uuid="3571fe40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425139_64332_265641"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312126_69876_292198"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="202"/>
      <waypoint x="324" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_927990_403520" xmi:uuid="35720550-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425220_601150_265657"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312141_25852_292213"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="222"/>
      <waypoint x="324" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_274032_403523" xmi:uuid="35720c30-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425301_942926_265673"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312151_951450_292228"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="242"/>
      <waypoint x="324" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_994329_403526" xmi:uuid="357212e0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425380_115233_265689"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312165_76905_292243"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="262"/>
      <waypoint x="324" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_218904_403529" xmi:uuid="35721900-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425460_839293_265705"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312182_895953_292258"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="282"/>
      <waypoint x="324" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_150614_403532" xmi:uuid="35722060-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425544_633084_265721"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312200_120430_292273"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="302"/>
      <waypoint x="324" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_316968_403535" xmi:uuid="35723380-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425628_510098_265737"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312212_445227_292288"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="322"/>
      <waypoint x="324" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_561848_403538" xmi:uuid="35723a70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425711_775762_265753"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312224_864165_292303"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="342"/>
      <waypoint x="324" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_661344_403541" xmi:uuid="35724070-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425845_421511_265769"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312239_67358_292318"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="362"/>
      <waypoint x="324" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_983300_403544" xmi:uuid="35724690-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601425932_616515_265785"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312249_720300_292333"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="382"/>
      <waypoint x="324" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_700072_403547" xmi:uuid="35724d70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601426010_797065_265801"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312259_381815_292348"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="402"/>
      <waypoint x="324" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_885093_403550" xmi:uuid="35725460-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601426088_853619_265817"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312268_998790_292363"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="422"/>
      <waypoint x="324" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499663_735324_403553" xmi:uuid="35725b60-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601426167_915498_265833"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312279_439845_292378"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312011_203549_292059"/>
      <waypoint x="713" y="442"/>
      <waypoint x="324" y="442"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="716" height="520"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446311913_170113_291934" xmi:uuid="3c6a8e50-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074630369_511218_69105"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311938_554859_291966" xmi:uuid="3cfaa060-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239519687_803092_67101"/>
      <ownedElement xmi:id="3cfa2df0-6c42-013d-931f-0800270c66d6" xmi:uuid="3cfa2e80-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239519687_803092_67101"/>
        <text>theFunctioanValuePair:Function_value_pair</text>
      </ownedElement>
      <ownedElement xmi:id="3cfa9770-6c42-013d-931f-0800270c66d6" xmi:uuid="3cfa97d0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239519687_803092_67101"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="268" height="90"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311957_521547_292000" xmi:uuid="3cfad350-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="587" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311975_190985_292015" xmi:uuid="3d2beb40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="587" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499661_181490_403490" xmi:uuid="3d2c2230-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1662994431117_539137_69630"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311957_521547_292000"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311938_554859_291966"/>
      <waypoint x="587" y="62"/>
      <waypoint x="313" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499662_564494_403493" xmi:uuid="3d2c2f50-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1662994427430_735348_69616"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311975_190985_292015"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311938_554859_291966"/>
      <waypoint x="587" y="82"/>
      <waypoint x="313" y="82"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="590" height="160"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446311590_639909_291570" xmi:uuid="42ee10b0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074512048_940092_68961"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311645_221334_291603" xmi:uuid="43add6c0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619075476990_588868_69884"/>
      <ownedElement xmi:id="4386fd00-6c42-013d-931f-0800270c66d6" xmi:uuid="4386fdb0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619075476990_588868_69884"/>
        <text>theParametizedDistirbution:Parameterized_distribution</text>
      </ownedElement>
      <ownedElement xmi:id="43adca40-6c42-013d-931f-0800270c66d6" xmi:uuid="43adcaf0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619075476990_588868_69884"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="45" y="55" width="328" height="450"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311662_163177_291637" xmi:uuid="43ae0f60-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="797" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311676_598729_291652" xmi:uuid="43ae44c0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="797" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311690_782692_291667" xmi:uuid="43ae7770-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="797" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311701_34148_291682" xmi:uuid="43aeac90-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="797" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311715_388608_291697" xmi:uuid="43bc8f70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="797" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311726_357989_291712" xmi:uuid="43bcce90-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="797" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311740_746417_291727" xmi:uuid="43bd0e40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="797" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311756_343283_291742" xmi:uuid="43bd5110-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="797" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311771_110456_291757" xmi:uuid="43bd9800-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="797" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311781_428738_291772" xmi:uuid="43bdd6b0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="797" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311795_404363_291787" xmi:uuid="43be12a0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="797" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311813_581519_291802" xmi:uuid="43be4d70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="797" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311830_401767_291817" xmi:uuid="43be8b30-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="797" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311842_461373_291832" xmi:uuid="43becb70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="797" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311854_832352_291847" xmi:uuid="43bf0da0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="797" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311869_314900_291862" xmi:uuid="43bf4950-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="797" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311878_596760_291877" xmi:uuid="43f503a0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573662619048_547058_60074"/>
      <bounds x="797" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311887_449329_291892" xmi:uuid="43f54200-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
      <bounds x="797" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311896_469213_291907" xmi:uuid="43f57d30-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
      <bounds x="797" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446311907_497373_291922" xmi:uuid="43f5b630-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="797" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_393763_403430" xmi:uuid="43f5c280-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421019_204559_264638"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311662_163177_291637"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="62"/>
      <waypoint x="373" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_373025_403433" xmi:uuid="43f5c9c0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421106_412249_264654"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311676_598729_291652"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="82"/>
      <waypoint x="373" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_963405_403436" xmi:uuid="43f5cfc0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421188_7403_264670"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311690_782692_291667"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="102"/>
      <waypoint x="373" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_830769_403439" xmi:uuid="43f5d710-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421269_518148_264686"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311701_34148_291682"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="122"/>
      <waypoint x="373" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_719309_403442" xmi:uuid="43f5de40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421348_360352_264702"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311715_388608_291697"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="142"/>
      <waypoint x="373" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_1345_403445" xmi:uuid="43f5e410-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421431_677262_264718"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311726_357989_291712"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="162"/>
      <waypoint x="373" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_722397_403448" xmi:uuid="43f5eab0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421513_558034_264734"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311740_746417_291727"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="182"/>
      <waypoint x="373" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_371159_403451" xmi:uuid="43f5f030-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421601_135180_264750"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311756_343283_291742"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="202"/>
      <waypoint x="373" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_252940_403454" xmi:uuid="43f5f6f0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421686_60913_264766"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311771_110456_291757"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="222"/>
      <waypoint x="373" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_750881_403457" xmi:uuid="43f5fde0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421769_862408_264782"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311781_428738_291772"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="242"/>
      <waypoint x="373" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_593514_403460" xmi:uuid="43f60430-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421846_675956_264798"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311795_404363_291787"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="262"/>
      <waypoint x="373" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_497968_403463" xmi:uuid="43f60a60-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601421927_860037_264814"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311813_581519_291802"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="282"/>
      <waypoint x="373" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_482819_403466" xmi:uuid="43f610c0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422010_987292_264830"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311830_401767_291817"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="302"/>
      <waypoint x="373" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496840_724466_403469" xmi:uuid="43f61750-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422090_715403_264846"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311842_461373_291832"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="322"/>
      <waypoint x="373" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496841_715020_403472" xmi:uuid="43f61d30-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422171_36880_264862"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311854_832352_291847"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="342"/>
      <waypoint x="373" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496841_501179_403475" xmi:uuid="43f623b0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422250_407753_264878"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311869_314900_291862"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="362"/>
      <waypoint x="373" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496841_472610_403478" xmi:uuid="43f62b30-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422334_255171_264894"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311878_596760_291877"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="382"/>
      <waypoint x="373" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496841_283328_403481" xmi:uuid="43f631c0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422413_363907_264910"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311887_449329_291892"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="402"/>
      <waypoint x="373" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496841_427668_403484" xmi:uuid="43f63820-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422490_641772_264926"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311896_469213_291907"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="422"/>
      <waypoint x="373" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496841_37877_403487" xmi:uuid="43f63e30-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_65b021e_1696601422565_763927_264942"/>
      <source xmi:idref="_18_4_1_65b021e_1727446311907_497373_291922"/>
      <target xmi:idref="_18_4_1_65b021e_1727446311645_221334_291603"/>
      <waypoint x="797" y="442"/>
      <waypoint x="373" y="442"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="800" height="520"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1619075037136_532498_69492" xmi:uuid="df9268a0-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Probability.xmi#_18_4_1_29c0149_1619013277232_933760_66215"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1620240118337_738069_68088" xmi:uuid="46d44c40-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620240118326_183105_68084"/>
      <bounds x="874" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621424609502_192568_181935" xmi:uuid="63bd6050-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1621424611270_612427_181936"/>
      <source xmi:idref="_18_4_1_2b2015d_1642769579932_853341_70162"/>
      <target xmi:idref="_18_4_1_29c0149_1621424549047_815079_181865"/>
      <waypoint x="280" y="109"/>
      <waypoint x="546" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621427106420_850541_67443" xmi:uuid="6455db50-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1621427108791_769579_67444"/>
      <source xmi:idref="_18_4_1_2b2015d_1642769611239_221104_70177"/>
      <target xmi:idref="_18_4_1_29c0149_1621427021554_501278_67375"/>
      <waypoint x="280" y="144"/>
      <waypoint x="546" y="144"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1619077207540_713223_70098" xmi:uuid="dfa0b2a0-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619077207530_135830_70097"/>
      <ownedElement xmi:id="dfa037a0-8fde-0139-a9d9-78b156d8ad1a" xmi:uuid="dfa038b0-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619077207530_135830_70097"/>
        <text>theProbabilityDerived:Probability_derived</text>
      </ownedElement>
      <ownedElement xmi:id="dfa0a560-8fde-0139-a9d9-78b156d8ad1a" xmi:uuid="dfa0a5c0-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619077207530_135830_70097"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="29d7f390-6c42-013d-931f-0800270c66d6" xmi:uuid="29d7f420-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="29d820f0-6c42-013d-931f-0800270c66d6" xmi:uuid="29d82130-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1621424549047_815079_181865" xmi:uuid="63bc1f50-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_derived-has_parameter"/>
          <ownedElement xmi:id="638c76a0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="638c7850-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_derived-has_parameter"/>
            <text>has_parameter:Numerical_item_with_unit</text>
          </ownedElement>
          <ownedElement xmi:id="63bae430-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="63bae560-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_derived-has_parameter"/>
            <text>[0..*]</text>
          </ownedElement>
          <bounds x="546" y="98" width="276" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1621427021554_501278_67375" xmi:uuid="64549b20-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_derived-derives_from"/>
          <ownedElement xmi:id="641fcf90-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="641fd150-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_derived-derives_from"/>
            <text>derives_from:Probability_generator</text>
          </ownedElement>
          <ownedElement xmi:id="64539550-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="64539680-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_derived-derives_from"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="546" y="133" width="233" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="539" y="70" width="290" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620240178384_306908_68111" xmi:uuid="46e856f0-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620240180044_796811_68112"/>
      <source xmi:idref="_18_4_1_29c0149_1619077207540_713223_70098"/>
      <target xmi:idref="_18_4_1_29c0149_1620240118337_738069_68088"/>
      <waypoint x="829" y="81"/>
      <waypoint x="874" y="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620849732592_855354_72062" xmi:uuid="645622a0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_75301ad_1539874280531_924571_32755"/>
      <bounds x="322" y="21" width="99" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621424560139_430374_181901" xmi:uuid="648593d0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1621424560135_297597_181899"/>
      <ownedElement xmi:id="64813790-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="64813970-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1621424560135_297597_181899"/>
        <text>HasParameter:NumericalValue</text>
      </ownedElement>
      <ownedElement xmi:id="64856040-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="64856200-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1621424560135_297597_181899"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1642769579932_853341_70162" xmi:uuid="140b1e90-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1601651985235_546200_63375"/>
        <ownedElement xmi:id="2edca5c0-6c42-013d-931f-0800270c66d6" xmi:uuid="2edca640-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1601651985235_546200_63375"/>
          <bounds x="283" y="94" width="216" height="13"/>
          <text>propertyValue : Numerical_item_with_unit [1]</text>
        </ownedElement>
        <bounds x="265" y="103" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="98" width="245" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621427028365_431253_67411" xmi:uuid="648ed510-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1621427028349_529274_67409"/>
      <ownedElement xmi:id="648afa50-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="648afb80-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1621427028349_529274_67409"/>
        <text>DerivesFrom:ProbabilityDistribution</text>
      </ownedElement>
      <ownedElement xmi:id="648eab20-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="648eac50-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1621427028349_529274_67409"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1642769611239_221104_70177" xmi:uuid="140da940-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLShape">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620240276035_49528_68166"/>
        <ownedElement xmi:id="2f0e2360-6c42-013d-931f-0800270c66d6" xmi:uuid="2f0e23f0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1620240276035_49528_68166"/>
          <bounds x="283" y="128" width="236" height="13"/>
          <text>probabilityDistribution : Probability_distribution [1]</text>
        </ownedElement>
        <bounds x="265" y="137" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="133" width="245" height="25"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="877" height="184"/>
    <name>ProbabilityDerived</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1619074840728_237454_69197" xmi:uuid="dff81360-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074571411_695821_69010"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1620239378354_439831_67011" xmi:uuid="4762e170-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239378346_592888_67007"/>
      <bounds x="937" y="82" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621440141661_3008_69157" xmi:uuid="65bde230-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1621440144922_603299_69158"/>
      <source xmi:idref="_18_4_1_29c0149_1622643488258_694090_71646"/>
      <target xmi:idref="_18_4_1_29c0149_1621440059927_218023_69087"/>
      <waypoint x="287" y="119"/>
      <waypoint x="525" y="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1619074890871_933461_69230" xmi:uuid="e0066010-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074890771_850104_69229"/>
      <ownedElement xmi:id="e005e3f0-8fde-0139-a9d9-78b156d8ad1a" xmi:uuid="e005e520-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074890771_850104_69229"/>
        <text>theDistributionByValue:Distribution_by_value</text>
      </ownedElement>
      <ownedElement xmi:id="e0065210-8fde-0139-a9d9-78b156d8ad1a" xmi:uuid="e0065280-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074890771_850104_69229"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="3111c180-6c42-013d-931f-0800270c66d6" xmi:uuid="3111c220-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3111f6e0-6c42-013d-931f-0800270c66d6" xmi:uuid="3111f750-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1621440059927_218023_69087" xmi:uuid="65bb6f40-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Distribution_by_value-defined_function"/>
          <ownedElement xmi:id="65866280-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="65866460-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Distribution_by_value-defined_function"/>
            <text>defined_function:Function_value_pair</text>
          </ownedElement>
          <ownedElement xmi:id="65b94b10-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="65b94cb0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Distribution_by_value-defined_function"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="525" y="105" width="251" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1622053293926_679752_70705" xmi:uuid="662f21c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Distribution_by_value-distribution_function"/>
          <ownedElement xmi:id="66016b40-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="66016ce0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Distribution_by_value-distribution_function"/>
            <text>distribution_function:String</text>
          </ownedElement>
          <ownedElement xmi:id="662d4b60-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="662d4c90-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Distribution_by_value-distribution_function"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="525" y="140" width="187" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="518" y="77" width="279" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620239439883_300921_67034" xmi:uuid="4775ca20-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239441794_628655_67035"/>
      <source xmi:idref="_18_4_1_29c0149_1620239378354_439831_67011"/>
      <target xmi:idref="_18_4_1_29c0149_1619074890871_933461_69230"/>
      <waypoint x="937" y="88"/>
      <waypoint x="797" y="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621439934676_156422_69075" xmi:uuid="662f94f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_29c0149_1619075044421_499634_69524"/>
      <bounds x="329" y="14" width="135" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622053558798_684748_71044" xmi:uuid="66352130-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622053558791_512080_71042"/>
      <ownedElement xmi:id="663210e0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="66321220-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622053558791_512080_71042"/>
        <text>DistributionFunction:String</text>
      </ownedElement>
      <ownedElement xmi:id="6634e1f0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6634e320-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622053558791_512080_71042"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="140" width="252" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622053648840_423749_71078" xmi:uuid="66353a80-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622053652048_804624_71079"/>
      <source xmi:idref="_18_4_1_29c0149_1622053293926_679752_70705"/>
      <target xmi:idref="_18_4_1_29c0149_1622053558798_684748_71044"/>
      <waypoint x="525" y="151"/>
      <waypoint x="280" y="151"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622643424472_57544_71615" xmi:uuid="663e0f70-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622643424435_741237_71613"/>
      <ownedElement xmi:id="66395c80-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="66395dd0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622643424435_741237_71613"/>
        <text>DefinedFunction:FunctionValuePair</text>
      </ownedElement>
      <ownedElement xmi:id="663c62f0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="663c6430-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622643424435_741237_71613"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1622643488258_694090_71646" xmi:uuid="663df7b0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239554723_699232_67147"/>
        <ownedElement xmi:id="34433cb0-6c42-013d-931f-0800270c66d6" xmi:uuid="34433d30-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239554723_699232_67147"/>
          <bounds x="294" y="97" width="207" height="13"/>
          <text>functionValuePair : Function_value_pair [1]</text>
        </ownedElement>
        <bounds x="272" y="110" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="105" width="252" height="25"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="940" height="191"/>
    <name>DistributionByValue</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1619074957083_449918_69300" xmi:uuid="e0067980-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074630369_511218_69105"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1620239519706_904819_67102" xmi:uuid="4791abc0-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239519687_803092_67101"/>
      <ownedElement xmi:id="479096b0-9071-0139-a9e6-78b156d8ad1a" xmi:uuid="479097d0-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239519687_803092_67101"/>
        <text>theFunctioanValuePair:Function_value_pair</text>
      </ownedElement>
      <ownedElement xmi:id="47919a00-9071-0139-a9e6-78b156d8ad1a" xmi:uuid="47919a80-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239519687_803092_67101"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="36231e00-6c42-013d-931f-0800270c66d6" xmi:uuid="36231e70-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="362348e0-6c42-013d-931f-0800270c66d6" xmi:uuid="36234920-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1620850979792_158123_73032" xmi:uuid="677d0930-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Function_value_pair-function_value"/>
          <ownedElement xmi:id="674999c0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="67499b50-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Function_value_pair-function_value"/>
            <text>function_value:Numerical_item_with_unit</text>
          </ownedElement>
          <ownedElement xmi:id="677b0040-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="677b0240-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Function_value_pair-function_value"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="497" y="98" width="263" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1620850979807_881533_73063" xmi:uuid="682baf80-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Function_value_pair-variable_value"/>
          <ownedElement xmi:id="67ec7e50-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="67ec7ff0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Function_value_pair-variable_value"/>
            <text>variable_value:Numerical_item_with_unit</text>
          </ownedElement>
          <ownedElement xmi:id="6829c880-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6829ca30-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Function_value_pair-variable_value"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="497" y="133" width="260" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="490" y="70" width="277" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620239636988_388478_67174" xmi:uuid="4791ba10-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239637984_878592_67175"/>
      <source xmi:idref="_18_4_1_29c0149_1620239554733_773048_67151"/>
      <target xmi:idref="_18_4_1_29c0149_1620239519706_904819_67102"/>
      <waypoint x="811" y="81"/>
      <waypoint x="767" y="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620850823471_361437_72130" xmi:uuid="686ed3c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620850823466_182337_72128"/>
      <ownedElement xmi:id="686a56d0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="686a5880-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620850823466_182337_72128"/>
        <text>VariableValue:NumericalValue</text>
      </ownedElement>
      <ownedElement xmi:id="686e9fb0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="686ea160-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620850823466_182337_72128"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1642769476023_199146_70084" xmi:uuid="151a4270-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1601651985235_546200_63375"/>
        <ownedElement xmi:id="3b0d9b50-6c42-013d-931f-0800270c66d6" xmi:uuid="3b0d9be0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1601651985235_546200_63375"/>
          <bounds x="248" y="128" width="216" height="13"/>
          <text>propertyValue : Numerical_item_with_unit [1]</text>
        </ownedElement>
        <bounds x="230" y="137" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="133" width="217" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620239554733_773048_67151" xmi:uuid="4776f270-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239554723_699232_67147"/>
      <bounds x="811" y="76" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621423622670_306094_181629" xmi:uuid="68711090-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1621423624231_401399_181630"/>
      <source xmi:idref="_18_4_1_29c0149_1620850979807_881533_73063"/>
      <target xmi:idref="_18_4_1_2b2015d_1642769476023_199146_70084"/>
      <waypoint x="497" y="144"/>
      <waypoint x="245" y="144"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622109798886_906675_71976" xmi:uuid="68a7f8a0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622109798886_358300_71974"/>
      <ownedElement xmi:id="68a5b010-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="68a5b170-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622109798886_358300_71974"/>
        <text>FunctionValue:NumericalValue</text>
      </ownedElement>
      <ownedElement xmi:id="2884ce60-3397-013a-17dd-45cc4a55db9f" xmi:uuid="2884cf30-3397-013a-17dd-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622109798886_358300_71974"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1642769446916_802308_70069" xmi:uuid="1528e6a0-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1601651985235_546200_63375"/>
        <ownedElement xmi:id="3c483de0-6c42-013d-931f-0800270c66d6" xmi:uuid="3c483e60-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1601651985235_546200_63375"/>
          <bounds x="248" y="92" width="216" height="13"/>
          <text>propertyValue : Numerical_item_with_unit [1]</text>
        </ownedElement>
        <bounds x="230" y="101" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="98" width="217" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622109840147_598142_72008" xmi:uuid="68a819e0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622109841230_295044_72009"/>
      <source xmi:idref="_18_4_1_29c0149_1620850979792_158123_73032"/>
      <target xmi:idref="_18_4_1_2b2015d_1642769446916_802308_70069"/>
      <waypoint x="497" y="109"/>
      <waypoint x="245" y="109"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="814" height="183"/>
    <name>FunctionValuePair</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1619074976529_547724_69364" xmi:uuid="e006b510-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074512048_940092_68961"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1620239664603_209210_67233" xmi:uuid="47932430-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239664595_490059_67229"/>
      <bounds x="867" y="74" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1619075477012_668277_69885" xmi:uuid="e01559d0-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619075476990_588868_69884"/>
      <ownedElement xmi:id="e014d210-8fde-0139-a9d9-78b156d8ad1a" xmi:uuid="e014d310-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619075476990_588868_69884"/>
        <text>theParametizedDistirbution:Parameterized_distribution</text>
      </ownedElement>
      <ownedElement xmi:id="e0154cb0-8fde-0139-a9d9-78b156d8ad1a" xmi:uuid="e0154d10-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619075476990_588868_69884"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="3dee8ea0-6c42-013d-931f-0800270c66d6" xmi:uuid="3dee8f40-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3deedf50-6c42-013d-931f-0800270c66d6" xmi:uuid="3deee520-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1621424312161_170108_181736" xmi:uuid="69d11ef0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Parameterized_distribution-has_parameters"/>
          <ownedElement xmi:id="69a14e00-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="69a14fc0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Parameterized_distribution-has_parameters"/>
            <text>has_parameters:Numerical_item_with_unit</text>
          </ownedElement>
          <ownedElement xmi:id="69cf7570-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="69cf77c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Parameterized_distribution-has_parameters"/>
            <text>[0..*]</text>
          </ownedElement>
          <bounds x="511" y="98" width="283" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1621424312199_371724_181767" xmi:uuid="6a378430-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Parameterized_distribution-parameterization_name"/>
          <ownedElement xmi:id="6a036600-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6a036740-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Parameterized_distribution-parameterization_name"/>
            <text>parameterization_name:String</text>
          </ownedElement>
          <ownedElement xmi:id="6a363180-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6a363470-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Parameterized_distribution-parameterization_name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="511" y="147" width="203" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="504" y="70" width="341" height="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620239727390_811976_67256" xmi:uuid="47a2adc0-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620239728693_583516_67257"/>
      <source xmi:idref="_18_4_1_29c0149_1619075477012_668277_69885"/>
      <target xmi:idref="_18_4_1_29c0149_1620239664603_209210_67233"/>
      <waypoint x="845" y="84"/>
      <waypoint x="867" y="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621424174443_783195_181686" xmi:uuid="6a5df930-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1621424174414_386578_181684"/>
      <ownedElement xmi:id="6a5add70-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6a5ae400-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1621424174414_386578_181684"/>
        <text>HasParameters:NumericalValue</text>
      </ownedElement>
      <ownedElement xmi:id="6a5dd9b0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6a5ddae0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1621424174414_386578_181684"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1642769534109_62236_70099" xmi:uuid="158fc9b0-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1601651985235_546200_63375"/>
        <ownedElement xmi:id="42d570a0-6c42-013d-931f-0800270c66d6" xmi:uuid="42d57130-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1601651985235_546200_63375"/>
          <bounds x="283" y="92" width="216" height="13"/>
          <text>propertyValue : Numerical_item_with_unit [1]</text>
        </ownedElement>
        <bounds x="265" y="101" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="98" width="238" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1621424267922_637584_181729" xmi:uuid="6a5e07e0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1621424269453_166565_181730"/>
      <source xmi:idref="_18_4_1_29c0149_1621424312161_170108_181736"/>
      <target xmi:idref="_18_4_1_2b2015d_1642769534109_62236_70099"/>
      <waypoint x="511" y="109"/>
      <waypoint x="280" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622048626413_307528_68785" xmi:uuid="6a8647f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622048626375_567176_68783"/>
      <ownedElement xmi:id="6a81f170-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6a81f440-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622048626375_567176_68783"/>
        <text>ParameterizationName:String</text>
      </ownedElement>
      <ownedElement xmi:id="6a860a90-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6a860c20-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622048626375_567176_68783"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="35" y="147" width="197" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622048946276_91051_69824" xmi:uuid="6abf5900-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622048948266_101616_69825"/>
      <source xmi:idref="_18_4_1_29c0149_1621424312199_371724_181767"/>
      <target xmi:idref="_18_4_1_29c0149_1622048626413_307528_68785"/>
      <waypoint x="511" y="158"/>
      <waypoint x="232" y="158"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622050146372_275489_70488" xmi:uuid="6d76e210-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_29c0149_1619075044421_499634_69524"/>
      <bounds x="301" y="28" width="135" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="870" height="197"/>
    <name>ParameterizedDistribution</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_29c0149_1619075044421_499634_69524" xmi:uuid="e0240f40-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Probability.xmi#_18_4_1_29c0149_1619074464332_875732_68909"/>
    <ownedElement xmi:id="_18_4_1_29c0149_1619085836926_301341_70143" xmi:uuid="e039c330-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1619085836872_506966_70142"/>
      <ownedElement xmi:id="e038fed0-8fde-0139-a9d9-78b156d8ad1a" xmi:uuid="e038ffd0-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619085836872_506966_70142"/>
        <text>theProbabilityDistribution:Probability_distribution</text>
      </ownedElement>
      <ownedElement xmi:id="e0399540-8fde-0139-a9d9-78b156d8ad1a" xmi:uuid="e03995c0-8fde-0139-a9d9-78b156d8ad1a" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1619085836872_506966_70142"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="44d38230-6c42-013d-931f-0800270c66d6" xmi:uuid="44d382f0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="44e7c940-6c42-013d-931f-0800270c66d6" xmi:uuid="44e7ca30-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1621427470168_266056_68964" xmi:uuid="6ef37590-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_distribution-is_continuous"/>
          <ownedElement xmi:id="6ec1f760-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6ec1f8c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_distribution-is_continuous"/>
            <text>is_continuous:Boolean</text>
          </ownedElement>
          <ownedElement xmi:id="6ef19200-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6ef193b0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_distribution-is_continuous"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="861" y="525" width="161" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1621457786728_164547_72607" xmi:uuid="6faa5810-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_distribution-mean"/>
          <ownedElement xmi:id="6f7b4600-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6f7b4740-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_distribution-mean"/>
            <text>mean:Numerical_item_with_unit</text>
          </ownedElement>
          <ownedElement xmi:id="6fa8deb0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6fa8dff0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_distribution-mean"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="868" y="343" width="213" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1621457786742_715476_72638" xmi:uuid="6fff5cf0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_distribution-variance"/>
          <ownedElement xmi:id="6fd2c420-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6fd2c560-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_distribution-variance"/>
            <text>variance:Real</text>
          </ownedElement>
          <ownedElement xmi:id="6ffe33a0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="6ffe3500-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Probability_distribution-variance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="861" y="476" width="108" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="854" y="84" width="307" height="476"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620240368641_113015_68193" xmi:uuid="47c38960-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620240370495_120755_68194"/>
      <source xmi:idref="_18_4_1_29c0149_1619085836926_301341_70143"/>
      <target xmi:idref="_18_4_1_29c0149_1620240276046_297842_68170"/>
      <waypoint x="1161" y="98"/>
      <waypoint x="1238" y="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620854971999_616621_73302" xmi:uuid="7027b280-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620854971984_384414_73300"/>
      <ownedElement xmi:id="7024a190-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="7024a2b0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620854971984_384414_73300"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="70278ff0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="70279120-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620854971984_384414_73300"/>
        <text>[0..*]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="154" width="139" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620855079269_731848_73336" xmi:uuid="705c5720-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620855079269_709058_73334"/>
      <ownedElement xmi:id="70548520-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="70548660-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620855079269_709058_73334"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1620855196492_224388_73354" xmi:uuid="70584e20-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="4adb6e80-6c42-013d-931f-0800270c66d6" xmi:uuid="4adb6f10-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="184" y="150" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="238" y="159" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1620855196507_960603_73364" xmi:uuid="705a49f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="4b871890-6c42-013d-931f-0800270c66d6" xmi:uuid="4b871950-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="427" y="174" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="405" y="161" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1620855196539_472293_73374" xmi:uuid="705c3f70-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="4c2e4700-6c42-013d-931f-0800270c66d6" xmi:uuid="4c2e4790-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="338" y="206" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="328" y="188" width="15" height="15"/>
      </ownedElement>
      <bounds x="238" y="147" width="182" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620855233880_94315_73404" xmi:uuid="705c6a40-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620855234635_43629_73405"/>
      <source xmi:idref="_18_4_1_29c0149_1620854971999_616621_73302"/>
      <target xmi:idref="_18_4_1_29c0149_1620855196492_224388_73354"/>
      <waypoint x="167" y="165"/>
      <waypoint x="238" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620855363572_483151_73459" xmi:uuid="705c7d60-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620855365075_246516_73460"/>
      <source xmi:idref="_18_4_1_2b2015d_1642766164855_52026_68980"/>
      <target xmi:idref="_18_4_1_29c0149_1620855196507_960603_73364"/>
      <waypoint x="525" y="168"/>
      <waypoint x="420" y="168"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620919708169_462078_73543" xmi:uuid="70b68f70-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620919708084_531394_73541"/>
      <ownedElement xmi:id="70b189f0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="70b18b30-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620919708084_531394_73541"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="70b535a0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="70b536e0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620919708084_531394_73541"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_29c0149_1620920022005_796498_74668" xmi:uuid="70b67a50-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="4d800af0-6c42-013d-931f-0800270c66d6" xmi:uuid="4d800b80-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="336" y="265" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="402" y="243" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="238" width="165" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620919867289_788333_74514" xmi:uuid="70b6a0b0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620919868614_998481_74515"/>
      <source xmi:idref="_18_4_1_29c0149_1620919708169_462078_73543"/>
      <target xmi:idref="_18_4_1_29c0149_1620855196539_472293_73374"/>
      <waypoint x="336" y="238"/>
      <waypoint x="336" y="203"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620919996645_744865_74658" xmi:uuid="716b0fa0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620919998246_295121_74659"/>
      <source xmi:idref="_18_4_1_29c0149_1619085836926_301341_70143"/>
      <target xmi:idref="_18_4_1_29c0149_1620919971599_357319_74589"/>
      <waypoint x="854" y="277"/>
      <waypoint x="708" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620919887920_297129_74529" xmi:uuid="716b2990-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620919887917_848406_74527"/>
      <ownedElement xmi:id="70e10ab0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="70e10c40-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620919887917_848406_74527"/>
        <text>idAsign:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="70e412d0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="70e413f0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1620919887917_848406_74527"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4dffd9f0-6c42-013d-931f-0800270c66d6" xmi:uuid="4dffda80-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4e1b77e0-6c42-013d-931f-0800270c66d6" xmi:uuid="4e1b7890-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_29c0149_1620919971599_357319_74589" xmi:uuid="71697ae0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="713bd1d0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="713bd310-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="716848e0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="71684a50-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="525" y="266" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <bounds x="518" y="238" width="266" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620920042486_920592_74687" xmi:uuid="716b3a50-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620920045281_64020_74688"/>
      <source xmi:idref="_18_4_1_29c0149_1620919887920_297129_74529"/>
      <target xmi:idref="_18_4_1_29c0149_1620920022005_796498_74668"/>
      <waypoint x="518" y="249"/>
      <waypoint x="417" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622065987311_745023_71793" xmi:uuid="74d45480-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622065987311_367577_71791"/>
      <ownedElement xmi:id="74d0b1b0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="74d0b300-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622065987311_367577_71791"/>
        <text>Mean:Real</text>
      </ownedElement>
      <ownedElement xmi:id="74d423c0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="74d42540-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622065987311_367577_71791"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="28" y="385" width="92" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622066052582_16843_71827" xmi:uuid="74d472c0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622066054143_129422_71828"/>
      <source xmi:idref="_18_4_1_2b2015d_1642766881266_463737_69688"/>
      <target xmi:idref="_18_4_1_29c0149_1622065987311_745023_71793"/>
      <waypoint x="207" y="420"/>
      <waypoint x="207" y="396"/>
      <waypoint x="120" y="396"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622108852139_764382_71876" xmi:uuid="74db5760-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622108852139_762909_71874"/>
      <ownedElement xmi:id="74d77660-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="74d77780-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622108852139_762909_71874"/>
        <text>Variance:Real</text>
      </ownedElement>
      <ownedElement xmi:id="74db30c0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="74db3200-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622108852139_762909_71874"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="28" y="476" width="110" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622108906273_706931_71910" xmi:uuid="74db6c80-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622108907398_847464_71911"/>
      <source xmi:idref="_18_4_1_29c0149_1621457786742_715476_72638"/>
      <target xmi:idref="_18_4_1_29c0149_1622108852139_764382_71876"/>
      <waypoint x="861" y="490"/>
      <waypoint x="138" y="490"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622109383162_711780_71925" xmi:uuid="74e28c70-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622109383157_209347_71923"/>
      <ownedElement xmi:id="74def140-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="74def290-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622109383157_209347_71923"/>
        <text>IsContinuous:Boolean</text>
      </ownedElement>
      <ownedElement xmi:id="74e25bd0-b6e9-0139-174a-45cc4a55db9f" xmi:uuid="74e25fb0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_29c0149_1622109383157_209347_71923"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="28" y="525" width="157" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622109420926_994958_71959" xmi:uuid="74e29ee0-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1622109423324_226551_71960"/>
      <source xmi:idref="_18_4_1_29c0149_1621427470168_266056_68964"/>
      <target xmi:idref="_18_4_1_29c0149_1622109383162_711780_71925"/>
      <waypoint x="861" y="536"/>
      <waypoint x="185" y="536"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1622644086822_914132_71755" xmi:uuid="74e2a940-b6e9-0139-174a-45cc4a55db9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_75301ad_1539786214227_393170_36030"/>
      <bounds x="595" y="42" width="89" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_29c0149_1620240276046_297842_68170" xmi:uuid="47b47300-9071-0139-a9e6-78b156d8ad1a" xmi:type="umldi:UMLShape">
      <modelElement href="Probability.xmi#_18_4_1_29c0149_1620240276035_49528_68166"/>
      <bounds x="1238" y="90" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1642766147649_575739_68949" xmi:uuid="1f13b470-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766126223_434183_68941"/>
      <ownedElement xmi:id="167c1a10-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="167c1bd0-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766126223_434183_68941"/>
        <text>smplIdAsign:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="167d1770-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="167d1b70-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766126223_434183_68941"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="50d4b6b0-6c42-013d-931f-0800270c66d6" xmi:uuid="50d4b750-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="50f09a20-6c42-013d-931f-0800270c66d6" xmi:uuid="50f09ae0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1642766164855_52026_68980" xmi:uuid="1696fd00-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="168af200-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="168af360-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="1696b0d0-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="1696b310-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="525" y="154" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1642766164881_693216_69011" xmi:uuid="16bc46d0-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="16aef140-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="16aef280-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="16bbe450-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="16bbe5e0-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <bounds x="525" y="189" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1642766164897_673140_69042" xmi:uuid="16d53b60-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="16c88a70-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="16c88bc0-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="16d4d640-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="16d4d780-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="525" y="119" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="518" y="91" width="264" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1642766265634_879196_69080" xmi:uuid="1f13bd10-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766266771_124252_69081"/>
      <source xmi:idref="_18_4_1_2b2015d_1642766164881_693216_69011"/>
      <target xmi:idref="_18_4_1_29c0149_1619085836926_301341_70143"/>
      <waypoint x="708" y="200"/>
      <waypoint x="854" y="200"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1642766342004_557102_69095" xmi:uuid="1f150d80-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766341999_225062_69093"/>
      <ownedElement xmi:id="16d65970-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="16d65b40-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766341999_225062_69093"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="16d749d0-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="16d74c00-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766341999_225062_69093"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="238" y="98" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1642766508811_267988_69432" xmi:uuid="1f1515f0-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766511129_91350_69433"/>
      <source xmi:idref="_18_4_1_2b2015d_1642766164897_673140_69042"/>
      <target xmi:idref="_18_4_1_2b2015d_1642766342004_557102_69095"/>
      <waypoint x="525" y="130"/>
      <waypoint x="469" y="130"/>
      <waypoint x="469" y="109"/>
      <waypoint x="372" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1642766881266_551280_69686" xmi:uuid="1f201410-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766881253_888405_69680"/>
      <ownedElement xmi:id="16e32c60-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="16e32d80-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766881253_888405_69680"/>
        <text>valueComponentToAnyNumber:RealToAnyNumber</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1642766881266_463737_69688" xmi:uuid="16e42a50-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1539872775186_110208_31747"/>
        <ownedElement xmi:id="56925f10-6c42-013d-931f-0800270c66d6" xmi:uuid="56925fb0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1539872775186_110208_31747"/>
          <bounds x="211" y="404" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="201" y="420" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1642766881266_792046_69690" xmi:uuid="16e46af0-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1539872775186_915820_31748"/>
        <ownedElement xmi:id="5721ad80-6c42-013d-931f-0800270c66d6" xmi:uuid="5721ae00-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1539872775186_915820_31748"/>
          <bounds x="343" y="405" width="85" height="13"/>
          <text>anyNumber [0..1]</text>
        </ownedElement>
        <bounds x="419" y="420" width="15" height="15"/>
      </ownedElement>
      <bounds x="168" y="420" width="297" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1642766881266_680986_69687" xmi:uuid="1f6b8090-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766881256_410672_69681"/>
      <ownedElement xmi:id="16eff060-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="16eff1b0-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766881256_410672_69681"/>
        <text>mean_value:Numerical_item_with_unit</text>
      </ownedElement>
      <ownedElement xmi:id="16f0dc80-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="16f0dd90-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642766881256_410672_69681"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="57ab19a0-6c42-013d-931f-0800270c66d6" xmi:uuid="57ab1a50-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="57ab50c0-6c42-013d-931f-0800270c66d6" xmi:uuid="57ab5140-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1642766881266_360575_69692" xmi:uuid="17161590-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-unit"/>
          <ownedElement xmi:id="17091f30-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="17092050-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-unit"/>
            <text>unit:Unit</text>
          </ownedElement>
          <ownedElement xmi:id="17159e80-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="1715a030-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-unit"/>
            <text>[1]</text>
          </ownedElement>
          <bounds x="532" y="343" width="89" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1642766881266_712384_69693" xmi:uuid="173ca090-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-value_component"/>
          <ownedElement xmi:id="172ee0d0-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="172ee200-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-value_component"/>
            <text>value_component:measure_value</text>
          </ownedElement>
          <ownedElement xmi:id="173c4f20-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="173c5040-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-value_component"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="532" y="378" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="518" y="315" width="266" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1642767128184_125113_69830" xmi:uuid="1f8a6bc0-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_2_attr_ValueWithUnit-Unit"/>
      <ownedElement xmi:id="17523020-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="175233d0-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_2_attr_ValueWithUnit-Unit"/>
        <text>Unit:UnitSelect</text>
      </ownedElement>
      <ownedElement xmi:id="175de250-6aee-013a-da25-3770a1b6a6fd" xmi:uuid="175de420-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_2_attr_ValueWithUnit-Unit"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1642767163076_498069_69862" xmi:uuid="175e3e60-6aee-013a-da25-3770a1b6a6fd" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1519829271945_504983_65626"/>
        <ownedElement xmi:id="5d8a6400-6c42-013d-931f-0800270c66d6" xmi:uuid="5d8a64a0-6c42-013d-931f-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1519829271945_504983_65626"/>
          <bounds x="178" y="338" width="91" height="13"/>
          <text>unitSelect : Unit [1]</text>
        </ownedElement>
        <bounds x="160" y="347" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="343" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1642767173275_685412_69881" xmi:uuid="1f8a79e0-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642767174948_864745_69882"/>
      <source xmi:idref="_18_4_1_2b2015d_1642766881266_360575_69692"/>
      <target xmi:idref="_18_4_1_2b2015d_1642767163076_498069_69862"/>
      <waypoint x="532" y="354"/>
      <waypoint x="175" y="354"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1642767240725_319567_69901" xmi:uuid="1f8a95a0-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642767243506_958323_69902"/>
      <source xmi:idref="_18_4_1_2b2015d_1642766881266_712384_69693"/>
      <target xmi:idref="_18_4_1_2b2015d_1642766881266_792046_69690"/>
      <waypoint x="532" y="389"/>
      <waypoint x="427" y="389"/>
      <waypoint x="427" y="420"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1642767312874_222252_69921" xmi:uuid="1f8aa180-76cb-013a-5c00-3bf0377d8acd" xmi:type="umldi:UMLEdge">
      <modelElement href="Probability.xmi#_18_4_1_2b2015d_1642767315430_286699_69922"/>
      <source xmi:idref="_18_4_1_29c0149_1621457786728_164547_72607"/>
      <target xmi:idref="_18_4_1_2b2015d_1642766881266_680986_69687"/>
      <waypoint x="868" y="354"/>
      <waypoint x="784" y="354"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1241" height="575"/>
    <name>ProbabilityDistribution</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
