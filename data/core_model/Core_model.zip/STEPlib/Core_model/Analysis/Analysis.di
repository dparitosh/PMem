<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703182111551_584616_132767" xmi:uuid="416349a0-9149-013c-7140-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703182111546_338499_132756"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1498551980700_305378_14144"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703182119252_845736_136826" xmi:uuid="526b97b0-9149-013c-7140-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703182119247_302371_136815"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1498551980700_305378_14144"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_6b1022a_1570541486160_536384_40773" xmi:uuid="da1a8a90-3aa4-0138-3ecf-418b172fba9f">
    <base_UMLClassDiagram xmi:idref="_18_4_1_6b1022a_1570541486114_761677_40761"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1498551980700_305378_14144"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446167102_158323_137740" xmi:uuid="3b6e4f80-6c44-013d-931d-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446167096_706610_137729"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121230940_899251_13786"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446167169_79320_137845" xmi:uuid="55855d10-6c43-013d-931d-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446167163_579510_137834"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446166837_899683_137362" xmi:uuid="732b3390-6c44-013d-931d-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446166830_86654_137351"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446166417_179318_136795" xmi:uuid="89e77d30-6c43-013d-931d-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446166410_365677_136784"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121169584_987103_13774"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446166664_671164_137131" xmi:uuid="be32a0d0-6c44-013d-931d-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446166659_96664_137120"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121248010_947033_13790"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446166025_175482_136332" xmi:uuid="c239ec20-6c44-013d-931d-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446166020_391894_136321"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121257177_404073_13792"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1607083399322_138224_66544" xmi:uuid="cfa22610-6ae6-013a-da16-3770a1b6a6fd">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1607083399322_195880_66533"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121223171_313016_13784"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_6b1022a_1570565773875_312421_41112" xmi:uuid="dbdc1490-3aa4-0138-3ecf-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_6b1022a_1570565773841_398603_41100"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_6b1022a_1570725566029_782763_43236" xmi:uuid="dbf03dd0-3aa4-0138-3ecf-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_6b1022a_1570725566020_457987_43225"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121169584_987103_13774"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_6b1022a_1570738312101_50465_47287" xmi:uuid="dbf90ee0-3aa4-0138-3ecf-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_6b1022a_1570738312094_266847_47276"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_6b1022a_1570739384857_720005_47731" xmi:uuid="dc073880-3aa4-0138-3ecf-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_6b1022a_1570739384851_924062_47720"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121202797_964567_13780"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_6b1022a_1570740634037_790234_48022" xmi:uuid="dc0c3000-3aa4-0138-3ecf-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_6b1022a_1570740634030_694655_48011"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121223171_313016_13784"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_6b1022a_1570744740711_965011_51045" xmi:uuid="dc18cc20-3aa4-0138-3ecf-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_6b1022a_1570744740704_131841_51034"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121230940_899251_13786"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_6b1022a_1570728737164_483017_45008" xmi:uuid="dc26c5e0-3aa4-0138-3ecf-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_6b1022a_1570728737157_287875_44997"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_6b1022a_1570894907998_560789_69310" xmi:uuid="dc34d6c0-3aa4-0138-3ecf-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_6b1022a_1570894907991_795254_69299"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121248010_947033_13790"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_6b1022a_1570880045279_466594_62027" xmi:uuid="dc3b7430-3aa4-0138-3ecf-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_6b1022a_1570880045273_125307_62016"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121257177_404073_13792"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446166201_714479_136522" xmi:uuid="e80c9630-6c43-013d-931d-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446166195_512608_136511"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446167455_44272_138223" xmi:uuid="f3622190-6c43-013d-931d-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446167450_497106_138212"/>
    <defaultNamespace href="Analysis.xmi#_18_4_1_8e001ed_1559121202797_964567_13780"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703182111546_338499_132756" xmi:uuid="41625e70-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1498551980700_305378_14144"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182111595_346719_132789" xmi:uuid="416af870-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121183510_978283_13776"/>
      <ownedElement xmi:id="4166e7e0-9149-013c-7140-0a5172f4a469" xmi:uuid="4166e900-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121183510_978283_13776"/>
        <text>AnalysisAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="4168d770-9149-013c-7140-0a5172f4a469" xmi:uuid="4168d8c0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="4169afa0-9149-013c-7140-0a5172f4a469" xmi:uuid="4169b0e0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1251" height="755"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182111781_131312_132860" xmi:uuid="41a47560-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="4171ee10-9149-013c-7140-0a5172f4a469" xmi:uuid="4171ef30-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="f8b875e0-6c41-013d-931d-0800270c66d6" xmi:uuid="f8b87680-6c41-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182111953_244173_132954" xmi:uuid="41e30be0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
      <ownedElement xmi:id="41a6e620-9149-013c-7140-0a5172f4a469" xmi:uuid="41a6e740-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
        <text>ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="fb9b4dd0-6c41-013d-931d-0800270c66d6" xmi:uuid="fb9b4e70-6c41-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="278" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182112049_452611_133026" xmi:uuid="41f960f0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethodRelationship"/>
      <ownedElement xmi:id="41e57de0-9149-013c-7140-0a5172f4a469" xmi:uuid="41e58000-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethodRelationship"/>
        <text>ActivityMethodRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="00426060-6c42-013d-931d-0800270c66d6" xmi:uuid="00426230-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="491" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182112160_924600_133098" xmi:uuid="42112e20-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityRelationship"/>
      <ownedElement xmi:id="41fbeb80-9149-013c-7140-0a5172f4a469" xmi:uuid="41fbecb0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityRelationship"/>
        <text>ActivityRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="026487e0-6c42-013d-931d-0800270c66d6" xmi:uuid="02648880-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="704" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182112245_177521_133147" xmi:uuid="423ea260-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyViewRelationshipSubstitution"/>
      <ownedElement xmi:id="421686b0-9149-013c-7140-0a5172f4a469" xmi:uuid="42168840-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyViewRelationshipSubstitution"/>
        <text>AssemblyViewRelationshipSubstitution</text>
      </ownedElement>
      <ownedElement xmi:id="0500c280-6c42-013d-931d-0800270c66d6" xmi:uuid="0500c380-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="917" y="95" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182112436_472287_133216" xmi:uuid="426ef870-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581927879268_726070_55882"/>
      <ownedElement xmi:id="42451ae0-9149-013c-7140-0a5172f4a469" xmi:uuid="42451c10-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581927879268_726070_55882"/>
        <text>Collection</text>
      </ownedElement>
      <ownedElement xmi:id="0bf184c0-6c42-013d-931d-0800270c66d6" xmi:uuid="0bf18560-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="145" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182112530_349825_133283" xmi:uuid="427bd670-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928317278_767608_56082"/>
      <ownedElement xmi:id="42715ab0-9149-013c-7140-0a5172f4a469" xmi:uuid="42715dd0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928317278_767608_56082"/>
        <text>CollectionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="0ea41750-6c42-013d-931d-0800270c66d6" xmi:uuid="0ea41810-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="290" y="145" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182112701_85259_133358" xmi:uuid="429e1d30-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
      <ownedElement xmi:id="427e2f00-9149-013c-7140-0a5172f4a469" xmi:uuid="427e3020-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
        <text>CollectionVersion</text>
      </ownedElement>
      <ownedElement xmi:id="0f93a2e0-6c42-013d-931d-0800270c66d6" xmi:uuid="0f93a370-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="515" y="145" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182112794_155216_133425" xmi:uuid="42ab1770-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928364129_454450_56183"/>
      <ownedElement xmi:id="42a07520-9149-013c-7140-0a5172f4a469" xmi:uuid="42a07660-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928364129_454450_56183"/>
        <text>CollectionVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="117b4030-6c42-013d-931d-0800270c66d6" xmi:uuid="117b40d0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="740" y="145" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182112963_267745_133498" xmi:uuid="42c9dd40-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
      <ownedElement xmi:id="42ad6e90-9149-013c-7140-0a5172f4a469" xmi:uuid="42ad6fa0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
        <text>CollectionView</text>
      </ownedElement>
      <ownedElement xmi:id="123ab3a0-6c42-013d-931d-0800270c66d6" xmi:uuid="123ab440-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="965" y="145" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182113037_473276_133563" xmi:uuid="42d3ed80-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582642454437_633211_62145"/>
      <ownedElement xmi:id="42cc1830-9149-013c-7140-0a5172f4a469" xmi:uuid="42cc1950-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582642454437_633211_62145"/>
        <text>CollectionViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="13c73c70-6c42-013d-931d-0800270c66d6" xmi:uuid="13c73d00-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="195" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182113214_764269_133641" xmi:uuid="44957cc0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Condition"/>
      <ownedElement xmi:id="42f9c5c0-9149-013c-7140-0a5172f4a469" xmi:uuid="42f9c6d0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Condition"/>
        <text>Condition</text>
      </ownedElement>
      <ownedElement xmi:id="1c285da0-6c42-013d-931d-0800270c66d6" xmi:uuid="1c285e60-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="290" y="195" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182113340_189750_133719" xmi:uuid="45627470-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_ConditionRelationship"/>
      <ownedElement xmi:id="44a196d0-9149-013c-7140-0a5172f4a469" xmi:uuid="44a197e0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_ConditionRelationship"/>
        <text>ConditionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="323a2dd0-6c42-013d-931d-0800270c66d6" xmi:uuid="323a2e60-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="566" y="195" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182113458_764507_133782" xmi:uuid="45a2d0e0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504193343893_860532_25972"/>
      <ownedElement xmi:id="456b9730-9149-013c-7140-0a5172f4a469" xmi:uuid="456b9850-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504193343893_860532_25972"/>
        <text>Evidence</text>
      </ownedElement>
      <ownedElement xmi:id="3ca28920-6c42-013d-931d-0800270c66d6" xmi:uuid="3ca289c0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="842" y="195" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182113576_698960_133847" xmi:uuid="46000fb0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133691013_484756_38870"/>
      <ownedElement xmi:id="45af50c0-9149-013c-7140-0a5172f4a469" xmi:uuid="45af52d0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133691013_484756_38870"/>
        <text>InterfaceConnection</text>
      </ownedElement>
      <ownedElement xmi:id="41f95a40-6c42-013d-931d-0800270c66d6" xmi:uuid="41f95ae0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="245" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182113755_373531_133915" xmi:uuid="465b6a80-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133997057_424483_38872"/>
      <ownedElement xmi:id="4603d450-9149-013c-7140-0a5172f4a469" xmi:uuid="4603d570-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133997057_424483_38872"/>
        <text>InterfaceConnector</text>
      </ownedElement>
      <ownedElement xmi:id="45b0b640-6c42-013d-931d-0800270c66d6" xmi:uuid="45b0b6e0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="245" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182113898_785663_133976" xmi:uuid="469eea60-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134009996_168675_38876"/>
      <ownedElement xmi:id="465f3400-9149-013c-7140-0a5172f4a469" xmi:uuid="465f3510-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134009996_168675_38876"/>
        <text>InterfaceConnectorOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="4a4d6340-6c42-013d-931d-0800270c66d6" xmi:uuid="4a4d63d0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="507" y="245" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182113977_931943_134043" xmi:uuid="46baab40-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1588154755027_637191_58929"/>
      <ownedElement xmi:id="46a2b9c0-9149-013c-7140-0a5172f4a469" xmi:uuid="46a2bc10-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1588154755027_637191_58929"/>
        <text>InterfaceConnectorOccurrenceRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="4da8ef10-6c42-013d-931d-0800270c66d6" xmi:uuid="4da8efd0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="728" y="245" width="237" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182114064_712317_134110" xmi:uuid="46d61570-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586343386063_282733_74872"/>
      <ownedElement xmi:id="46be75a0-9149-013c-7140-0a5172f4a469" xmi:uuid="46be76d0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586343386063_282733_74872"/>
        <text>InterfaceConnectorRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="4ef6cab0-6c42-013d-931d-0800270c66d6" xmi:uuid="4ef6cc90-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="985" y="245" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182114251_180786_134183" xmi:uuid="47198330-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134019779_950347_38878"/>
      <ownedElement xmi:id="46d9e5b0-9149-013c-7140-0a5172f4a469" xmi:uuid="46d9e6e0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134019779_950347_38878"/>
        <text>InterfaceConnectorVersion</text>
      </ownedElement>
      <ownedElement xmi:id="508696c0-6c42-013d-931d-0800270c66d6" xmi:uuid="50869750-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="295" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182114352_942304_134249" xmi:uuid="47329630-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586343616734_789877_76490"/>
      <ownedElement xmi:id="471d7080-9149-013c-7140-0a5172f4a469" xmi:uuid="471d71b0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586343616734_789877_76490"/>
        <text>InterfaceConnectorVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="53b7ade0-6c42-013d-931d-0800270c66d6" xmi:uuid="53b7ae80-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="295" width="216" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182114532_149223_134330" xmi:uuid="477605d0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
      <ownedElement xmi:id="47368770-9149-013c-7140-0a5172f4a469" xmi:uuid="47368880-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
        <text>InterfaceConnectorView</text>
      </ownedElement>
      <ownedElement xmi:id="54d1b4d0-6c42-013d-931d-0800270c66d6" xmi:uuid="54d1b5a0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="522" y="295" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182114613_389273_134394" xmi:uuid="4789b500-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586343911301_668423_78254"/>
      <ownedElement xmi:id="4779e3a0-9149-013c-7140-0a5172f4a469" xmi:uuid="4779e4c0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586343911301_668423_78254"/>
        <text>InterfaceConnectorViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="58725b30-6c42-013d-931d-0800270c66d6" xmi:uuid="58725bd0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="743" y="295" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182114736_772458_134459" xmi:uuid="47d89c20-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134027947_222114_38880"/>
      <ownedElement xmi:id="478d9640-9149-013c-7140-0a5172f4a469" xmi:uuid="478d9770-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134027947_222114_38880"/>
        <text>InterfaceDefinitionConnection</text>
      </ownedElement>
      <ownedElement xmi:id="598c3750-6c42-013d-931d-0800270c66d6" xmi:uuid="598c3850-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="964" y="295" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182114800_753606_134507" xmi:uuid="47f70c30-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134046216_951339_38884"/>
      <ownedElement xmi:id="47dca880-9149-013c-7140-0a5172f4a469" xmi:uuid="47dca9c0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134046216_951339_38884"/>
        <text>InterfaceDefinitionFor</text>
      </ownedElement>
      <ownedElement xmi:id="5da148e0-6c42-013d-931d-0800270c66d6" xmi:uuid="5da14980-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182114987_486664_134575" xmi:uuid="484e6f60-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134059448_942822_38888"/>
      <ownedElement xmi:id="47faf3a0-9149-013c-7140-0a5172f4a469" xmi:uuid="47faf4d0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134059448_942822_38888"/>
        <text>InterfaceSpecification</text>
      </ownedElement>
      <ownedElement xmi:id="5f2472b0-6c42-013d-931d-0800270c66d6" xmi:uuid="5f247390-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182115080_457068_134642" xmi:uuid="486a1de0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586340101268_859874_66932"/>
      <ownedElement xmi:id="485244c0-9149-013c-7140-0a5172f4a469" xmi:uuid="485245e0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586340101268_859874_66932"/>
        <text>InterfaceSpecificationRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="63a02e30-6c42-013d-931d-0800270c66d6" xmi:uuid="63a02ed0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="507" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182115260_922735_134715" xmi:uuid="48ad5bc0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134081745_171261_38892"/>
      <ownedElement xmi:id="486dfa70-9149-013c-7140-0a5172f4a469" xmi:uuid="486dfc90-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134081745_171261_38892"/>
        <text>InterfaceSpecificationVersion</text>
      </ownedElement>
      <ownedElement xmi:id="652dcfa0-6c42-013d-931d-0800270c66d6" xmi:uuid="652dd040-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="728" y="345" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182115355_668879_134781" xmi:uuid="48c60ed0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586340493333_25507_67476"/>
      <ownedElement xmi:id="48b13c30-9149-013c-7140-0a5172f4a469" xmi:uuid="48b13d50-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586340493333_25507_67476"/>
        <text>InterfaceSpecificationVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="6852a780-6c42-013d-931d-0800270c66d6" xmi:uuid="6852a820-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="949" y="345" width="229" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182115536_538859_134861" xmi:uuid="49061df0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
      <ownedElement xmi:id="48ca59d0-9149-013c-7140-0a5172f4a469" xmi:uuid="48ca5b70-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
        <text>InterfaceSpecificationView</text>
      </ownedElement>
      <ownedElement xmi:id="698ac1e0-6c42-013d-931d-0800270c66d6" xmi:uuid="698ac280-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="395" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182115616_935005_134925" xmi:uuid="4919f5d0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586340770059_699987_67672"/>
      <ownedElement xmi:id="490a0250-9149-013c-7140-0a5172f4a469" xmi:uuid="490a0360-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_13110319_1586340770059_699987_67672"/>
        <text>InterfaceSpecificationViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="6c8f6070-6c42-013d-931d-0800270c66d6" xmi:uuid="6c8f6100-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="286" y="395" width="214" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182115693_340347_134974" xmi:uuid="4936ced0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583833642515_51219_56883"/>
      <ownedElement xmi:id="4922a540-9149-013c-7140-0a5172f4a469" xmi:uuid="4922a660-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583833642515_51219_56883"/>
        <text>ManagedResourceRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="71737ab0-6c42-013d-931d-0800270c66d6" xmi:uuid="71737b50-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="520" y="395" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182115848_710742_135041" xmi:uuid="49f96020-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
      <ownedElement xmi:id="494c6550-9149-013c-7140-0a5172f4a469" xmi:uuid="494c6680-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
        <text>Organization</text>
      </ownedElement>
      <ownedElement xmi:id="7c5ebda0-6c42-013d-931d-0800270c66d6" xmi:uuid="7c5ebe70-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="752" y="395" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182115937_111232_135110" xmi:uuid="4a3976d0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_OrganizationRelationship"/>
      <ownedElement xmi:id="4a00ddf0-9149-013c-7140-0a5172f4a469" xmi:uuid="4a00df10-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_OrganizationRelationship"/>
        <text>OrganizationRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="89595cf0-6c42-013d-931d-0800270c66d6" xmi:uuid="89595da0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="445" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182116149_546739_135185" xmi:uuid="4ad785d0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
      <ownedElement xmi:id="4a3ed7b0-9149-013c-7140-0a5172f4a469" xmi:uuid="4a3ed8c0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
        <text>Part</text>
      </ownedElement>
      <ownedElement xmi:id="8cd65ff0-6c42-013d-931d-0800270c66d6" xmi:uuid="8cd66090-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="360" y="445" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182116253_345986_135254" xmi:uuid="4b044e40-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartRelationship"/>
      <ownedElement xmi:id="4adcec70-9149-013c-7140-0a5172f4a469" xmi:uuid="4adced90-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartRelationship"/>
        <text>PartRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="94ecdf30-6c42-013d-931d-0800270c66d6" xmi:uuid="94ece000-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="662" y="445" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182116375_663320_135319" xmi:uuid="4b2a11b0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_PartToIndividualPartAssociation"/>
      <ownedElement xmi:id="4b0bff70-9149-013c-7140-0a5172f4a469" xmi:uuid="4b0c0310-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_PartToIndividualPartAssociation"/>
        <text>PartToIndividualPartAssociation</text>
      </ownedElement>
      <ownedElement xmi:id="97beede0-6c42-013d-931d-0800270c66d6" xmi:uuid="97beeea0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="964" y="445" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182116592_605734_135394" xmi:uuid="4b96ef80-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
      <ownedElement xmi:id="4b2f8b60-9149-013c-7140-0a5172f4a469" xmi:uuid="4b2f8c70-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
        <text>PartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="9a09e1a0-6c42-013d-931d-0800270c66d6" xmi:uuid="9a09e240-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182116699_294542_135462" xmi:uuid="4bc21f60-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersionRelationship"/>
      <ownedElement xmi:id="4b9c2560-9149-013c-7140-0a5172f4a469" xmi:uuid="4b9c2670-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersionRelationship"/>
        <text>PartVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="9f941260-6c42-013d-931d-0800270c66d6" xmi:uuid="9f9412f0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="367" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182116790_883698_135516" xmi:uuid="4be63370-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_PartVersionToIndividualPartVersionAssociation"/>
      <ownedElement xmi:id="4bc58f10-9149-013c-7140-0a5172f4a469" xmi:uuid="4bc59050-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_PartVersionToIndividualPartVersionAssociation"/>
        <text>PartVersionToIndividualPartVersionAssociation</text>
      </ownedElement>
      <ownedElement xmi:id="a12a7590-6c42-013d-931d-0800270c66d6" xmi:uuid="a12a7630-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="669" y="495" width="258" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117007_327949_135593" xmi:uuid="4c5b3060-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="4bebf880-9149-013c-7140-0a5172f4a469" xmi:uuid="4bebfea0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="a34c95d0-6c42-013d-931d-0800270c66d6" xmi:uuid="a34c9670-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="947" y="495" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117099_303315_135659" xmi:uuid="4c7cd830-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
      <ownedElement xmi:id="4c60a960-9149-013c-7140-0a5172f4a469" xmi:uuid="4c60ad90-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
        <text>PartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="a98d08f0-6c42-013d-931d-0800270c66d6" xmi:uuid="a98d0980-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="545" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117268_865463_135726" xmi:uuid="4cbfb330-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConcept"/>
      <ownedElement xmi:id="4c8560f0-9149-013c-7140-0a5172f4a469" xmi:uuid="4c856210-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConcept"/>
        <text>ProductConcept</text>
      </ownedElement>
      <ownedElement xmi:id="b0fd2220-6c42-013d-931d-0800270c66d6" xmi:uuid="b0fd22b0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="367" y="545" width="340" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117348_289927_135773" xmi:uuid="4ce4f800-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639073129411_739302_66486"/>
      <ownedElement xmi:id="4cc53580-9149-013c-7140-0a5172f4a469" xmi:uuid="4cc536b0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639073129411_739302_66486"/>
        <text>ProductGroupRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="b4800060-6c42-013d-931d-0800270c66d6" xmi:uuid="b4800110-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="727" y="545" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117421_805217_135824" xmi:uuid="4cff5010-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_ProductPlannedToRealized"/>
      <ownedElement xmi:id="4ce7ce00-9149-013c-7140-0a5172f4a469" xmi:uuid="4ce7cf30-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_ProductPlannedToRealized"/>
        <text>ProductPlannedToRealized</text>
      </ownedElement>
      <ownedElement xmi:id="b60a2e40-6c42-013d-931d-0800270c66d6" xmi:uuid="b60a2ed0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="595" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117503_170061_135873" xmi:uuid="4d3f1930-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_ProjectRelationship"/>
      <ownedElement xmi:id="4d0677e0-9149-013c-7140-0a5172f4a469" xmi:uuid="4d0678f0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_ProjectRelationship"/>
        <text>ProjectRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="b8994980-6c42-013d-931d-0800270c66d6" xmi:uuid="b8994a30-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="308" y="595" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117582_402502_135924" xmi:uuid="4dc23590-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionAssignment"/>
      <ownedElement xmi:id="4d4b2ba0-9149-013c-7140-0a5172f4a469" xmi:uuid="4d4b2cd0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinitionAssignment"/>
        <text>PropertyDefinitionAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="bd5b7f10-6c42-013d-931d-0800270c66d6" xmi:uuid="bd5b8010-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="603" y="595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117678_360273_135987" xmi:uuid="4e6514b0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueAssignment"/>
      <ownedElement xmi:id="4dce0b20-9149-013c-7140-0a5172f4a469" xmi:uuid="4dce0c40-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValueAssignment"/>
        <text>PropertyValueAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="c3c16ca0-6c42-013d-931d-0800270c66d6" xmi:uuid="c3c16d40-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="879" y="595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117784_285651_136043" xmi:uuid="4e8dc960-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementAssignment"/>
      <ownedElement xmi:id="4e685b50-9149-013c-7140-0a5172f4a469" xmi:uuid="4e685c80-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementAssignment"/>
        <text>RequirementAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="caad2530-6c42-013d-931d-0800270c66d6" xmi:uuid="caad25c0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="645" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117874_371863_136093" xmi:uuid="4ea7d7b0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583833385213_492775_56734"/>
      <ownedElement xmi:id="4e90f810-9149-013c-7140-0a5172f4a469" xmi:uuid="4e90f9c0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583833385213_492775_56734"/>
        <text>ResourceEventRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="ccb77f10-6c42-013d-931d-0800270c66d6" xmi:uuid="ccb77f80-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="368" y="645" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182117972_553553_136143" xmi:uuid="4ec0fd50-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583844896220_320249_57955"/>
      <ownedElement xmi:id="4eab0280-9149-013c-7140-0a5172f4a469" xmi:uuid="4eab03b0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583844896220_320249_57955"/>
        <text>ResourceItemRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="cdfc86d0-6c42-013d-931d-0800270c66d6" xmi:uuid="cdfc8770-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="600" y="645" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182118035_587724_136188" xmi:uuid="4ecfa7c0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617985594452_714034_71103"/>
      <ownedElement xmi:id="4ec77ad0-9149-013c-7140-0a5172f4a469" xmi:uuid="4ec77e80-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617985594452_714034_71103"/>
        <text>RiskPerceptionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d0125800-6c42-013d-931d-0800270c66d6" xmi:uuid="d01258a0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="832" y="645" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182118132_36793_136237" xmi:uuid="4edfc750-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_807376_62431"/>
      <ownedElement xmi:id="4ed1f7e0-9149-013c-7140-0a5172f4a469" xmi:uuid="4ed1f8f0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_807376_62431"/>
        <text>RiskRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="d092d400-6c42-013d-931d-0800270c66d6" xmi:uuid="d092d4d0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="695" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182118263_879884_136297" xmi:uuid="4fd36770-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878022123_684236_27287"/>
      <ownedElement xmi:id="4eebf400-9149-013c-7140-0a5172f4a469" xmi:uuid="4eebf7c0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878022123_684236_27287"/>
        <text>State</text>
      </ownedElement>
      <ownedElement xmi:id="d2772cd0-6c42-013d-931d-0800270c66d6" xmi:uuid="d2772d80-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="265" y="695" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182118339_663841_136357" xmi:uuid="505be530-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878933294_877087_27407"/>
      <ownedElement xmi:id="4fe14c20-9149-013c-7140-0a5172f4a469" xmi:uuid="4fe14d80-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878933294_877087_27407"/>
        <text>StateAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="de870580-6c42-013d-931d-0800270c66d6" xmi:uuid="de870620-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="541" y="695" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182118485_32485_136421" xmi:uuid="516d45f0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504881104148_230182_28614"/>
      <ownedElement xmi:id="5067e9f0-9149-013c-7140-0a5172f4a469" xmi:uuid="5067eb40-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504881104148_230182_28614"/>
        <text>StateDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="e5b84760-6c42-013d-931d-0800270c66d6" xmi:uuid="e5b848b0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="817" y="695" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182118657_880724_136496" xmi:uuid="51a50540-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504194061252_379638_26123"/>
      <ownedElement xmi:id="517096f0-9149-013c-7140-0a5172f4a469" xmi:uuid="51709830-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504194061252_379638_26123"/>
        <text>Validation</text>
      </ownedElement>
      <ownedElement xmi:id="f2cef020-6c42-013d-931d-0800270c66d6" xmi:uuid="f2cef0c0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="745" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182118849_17950_136571" xmi:uuid="51dc32e0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504191936214_536008_25660"/>
      <ownedElement xmi:id="51a81fa0-9149-013c-7140-0a5172f4a469" xmi:uuid="51a820c0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504191936214_536008_25660"/>
        <text>Verification</text>
      </ownedElement>
      <ownedElement xmi:id="f57462c0-6c42-013d-931d-0800270c66d6" xmi:uuid="f5746350-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="368" y="745" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182119080_964038_136643" xmi:uuid="51fd0ed0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504192660346_980157_25822"/>
      <ownedElement xmi:id="51df5580-9149-013c-7140-0a5172f4a469" xmi:uuid="51df56c0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504192660346_980157_25822"/>
        <text>VerificationRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="f82de020-6c42-013d-931d-0800270c66d6" xmi:uuid="f82de0c0-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="671" y="745" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182119229_655470_136774" xmi:uuid="5269b210-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ViewContext"/>
      <ownedElement xmi:id="5202f970-9149-013c-7140-0a5172f4a469" xmi:uuid="5202fd30-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ViewContext"/>
        <text>ViewContext</text>
      </ownedElement>
      <ownedElement xmi:id="f9dda2e0-6c42-013d-931d-0800270c66d6" xmi:uuid="f9dda380-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="974" y="745" width="282" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1311" height="825"/>
    <name>AnalysisAssignmentSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703182119247_302371_136815" xmi:uuid="526aaa30-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1498551980700_305378_14144"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182119271_823763_136847" xmi:uuid="527169c0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121214220_699464_13782"/>
      <ownedElement xmi:id="526dec70-9149-013c-7140-0a5172f4a469" xmi:uuid="526ded80-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121214220_699464_13782"/>
        <text>AnalysisModelItemsSelect</text>
      </ownedElement>
      <ownedElement xmi:id="526f9810-9149-013c-7140-0a5172f4a469" xmi:uuid="526f9940-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="52705310-9149-013c-7140-0a5172f4a469" xmi:uuid="527053e0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1104" height="155"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182119459_585318_136910" xmi:uuid="5293e130-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
      <ownedElement xmi:id="5273d6a0-9149-013c-7140-0a5172f4a469" xmi:uuid="5273d7a0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
        <text>CollectionVersion</text>
      </ownedElement>
      <ownedElement xmi:id="ff3a6f70-6c42-013d-931d-0800270c66d6" xmi:uuid="ff3a7020-6c42-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="95" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182119660_188371_136971" xmi:uuid="52c4b560-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
      <ownedElement xmi:id="529c39e0-9149-013c-7140-0a5172f4a469" xmi:uuid="529c3ce0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
        <text>DocumentVersion</text>
      </ownedElement>
      <ownedElement xmi:id="020e35b0-6c43-013d-931d-0800270c66d6" xmi:uuid="020e3650-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="290" y="95" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182119826_394761_137038" xmi:uuid="52ef69d0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
      <ownedElement xmi:id="52cab8a0-9149-013c-7140-0a5172f4a469" xmi:uuid="52cab9b0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
        <text>SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="06915070-6c43-013d-931d-0800270c66d6" xmi:uuid="06915110-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="581" y="95" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182119967_921176_137102" xmi:uuid="5404fd40-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504881104148_230182_28614"/>
      <ownedElement xmi:id="52fbb360-9149-013c-7140-0a5172f4a469" xmi:uuid="52fbb490-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504881104148_230182_28614"/>
        <text>StateDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="0a9e49b0-6c43-013d-931d-0800270c66d6" xmi:uuid="0a9e4a60-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="853" y="95" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703182120046_652699_137166" xmi:uuid="544a86e0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1505219427776_325827_29921"/>
      <ownedElement xmi:id="541107b0-9149-013c-7140-0a5172f4a469" xmi:uuid="541108d0-9149-013c-7140-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1505219427776_325827_29921"/>
        <text>StateDefinitionTransition</text>
      </ownedElement>
      <ownedElement xmi:id="1819b480-6c43-013d-931d-0800270c66d6" xmi:uuid="1819b600-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="65" y="145" width="256" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1164" height="225"/>
    <name>AnalysisModelItemsSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_6b1022a_1570541486114_761677_40761" xmi:uuid="b28c24c9-bbe4-4132-8cf3-f21b9b47071e" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1498551980700_305378_14144"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563721104_203337_42036" xmi:uuid="da3f7af0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
      <ownedElement xmi:id="da1cd070-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da1cd0f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
        <text>Analysis</text>
      </ownedElement>
      <ownedElement xmi:id="d8a1bcf0-6c41-013d-931d-0800270c66d6" xmi:uuid="d8a1bdd0-6c41-013d-931d-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="da3d7730-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da3d77b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="da3dcfd0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da3dd010-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="da3e2560-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da3e2590-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121916854_195975_13808"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="da3e7f20-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da3e7f50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122232748_720258_38565"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="da3ed2c0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da3ed2f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122265317_316213_38573"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="83aa85a0-d861-013a-5681-737cd8fe39c9" xmi:uuid="83aa86e0-d861-013a-5681-737cd8fe39c9" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122303496_724866_38580"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="da3f2620-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da3f2650-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122328369_727665_38584"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="343" y="21" width="179" height="117"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563733421_244252_42083" xmi:uuid="da5cbec0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
      <ownedElement xmi:id="da40f420-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da40f470-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
        <text>AnalysisVersion</text>
      </ownedElement>
      <ownedElement xmi:id="da439c90-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da439cd0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="da5af9b0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da5afa40-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="da5b4fb0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da5b4ff0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="da5c1c90-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da5c1cd0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205081_515686_38734"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="83c72770-d861-013a-5681-737cd8fe39c9" xmi:uuid="83c73030-d861-013a-5681-737cd8fe39c9" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205084_450904_38736"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="da5c6b50-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da5c6b80-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205083_888764_38735"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="da5cb9c0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da5cb9f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205084_428717_38737"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="343" y="168" width="179" height="120"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563738651_618782_42136" xmi:uuid="da61ba30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122362284_865120_38590"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1580908424747_465414_56853" xmi:uuid="da609a50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122362284_76240_38591"/>
        <bounds x="372" y="141" width="50" height="13"/>
        <text>VersionOf</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1580908426783_633985_56861" xmi:uuid="da60f7b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122362284_76240_38591"/>
        <bounds x="434" y="141" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563738643_494043_42126" xmi:uuid="da615130-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122351937_533382_38588"/>
        <bounds x="384" y="152" width="44" height="13"/>
        <text>Versions</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563738644_248747_42128" xmi:uuid="da61b300-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122351937_533382_38588"/>
        <bounds x="434" y="152" width="24" height="13"/>
        <text>1..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570563721104_203337_42036"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563733421_244252_42083"/>
      <waypoint x="431" y="138"/>
      <waypoint x="431" y="168"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563782849_526768_42174" xmi:uuid="da88b1b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
      <ownedElement xmi:id="da63bc00-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da63bc70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
        <text>AnalysisDisciplineDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="da670c50-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da670ca0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="da86f4a0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da86f550-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="da876660-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da8766a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="da87d020-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da87d0b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577509_691731_38629"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="da883d10-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da883d50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577510_349500_38630"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="83eab450-d861-013a-5681-737cd8fe39c9" xmi:uuid="83eab570-d861-013a-5681-737cd8fe39c9" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577511_313503_38631"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="da88ab80-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da88abc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577512_909891_38632"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="343" y="322" width="179" height="120"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563790391_489761_42227" xmi:uuid="da8de0e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123225697_725205_38766"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1580908541949_370756_56930" xmi:uuid="da8c72b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123225697_483464_38767"/>
        <bounds x="388" y="295" width="36" height="13"/>
        <text>ViewOf</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1580908553101_106335_56940" xmi:uuid="da8d02a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123225697_483464_38767"/>
        <bounds x="434" y="295" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563790383_22973_42217" xmi:uuid="da8d7dd0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123225655_322108_38762"/>
        <bounds x="398" y="306" width="30" height="13"/>
        <text>Views</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563790384_187779_42219" xmi:uuid="da8ddab0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123225655_322108_38762"/>
        <bounds x="434" y="306" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570563733421_244252_42083"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563782849_526768_42174"/>
      <waypoint x="431" y="288"/>
      <waypoint x="431" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563835828_457132_42360" xmi:uuid="daa17190-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121248010_947033_13790"/>
      <ownedElement xmi:id="da8ff340-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da8ff3d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121248010_947033_13790"/>
        <text>AnalysisVersionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="da9335f0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da933660-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="da9fb3d0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="da9fb450-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="daa026e0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daa02720-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="daa092c0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daa09300-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123696176_916612_39316"/>
          <text>RelationType</text>
        </ownedElement>
      </ownedElement>
      <bounds x="21" y="196" width="273" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563842007_451348_42413" xmi:uuid="daa55a00-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570550661874_674092_41627"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640613403427_563114_67062" xmi:uuid="c2260e30-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570550661874_340921_41628"/>
        <bounds x="297" y="252" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563841997_987586_42403" xmi:uuid="daa4d0a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123718489_199855_39320"/>
        <bounds x="300" y="233" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563841998_695922_42405" xmi:uuid="daa54cc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123718489_199855_39320"/>
        <bounds x="330" y="252" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570563835828_457132_42360"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563733421_244252_42083"/>
      <waypoint x="294" y="249"/>
      <waypoint x="343" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563843807_442468_42436" xmi:uuid="daa98ec0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570550665783_151870_41653"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640613421680_13652_67072" xmi:uuid="c22a2d80-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570550665783_552582_41654"/>
        <bounds x="297" y="217" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563843800_91391_42426" xmi:uuid="daa90a60-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123742222_827187_39324"/>
        <bounds x="302" y="198" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563843800_349894_42428" xmi:uuid="daa98070-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123742222_827187_39324"/>
        <bounds x="329" y="214" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570563835828_457132_42360"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563733421_244252_42083"/>
      <waypoint x="294" y="214"/>
      <waypoint x="343" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563853947_470196_42450" xmi:uuid="dabcd200-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121169584_987103_13774"/>
      <ownedElement xmi:id="daab8ad0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daab8b20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121169584_987103_13774"/>
        <text>AnalysisAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="daaebd10-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daaebd60-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="630" y="175" width="122" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563862578_588405_42503" xmi:uuid="dac06700-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570550785255_926919_41701"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640859694838_500496_67409" xmi:uuid="c239da60-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570550785255_751394_41702"/>
        <bounds x="603" y="203" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563862570_513057_42493" xmi:uuid="dac004b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122501608_416494_38621"/>
        <bounds x="525" y="184" width="87" height="13"/>
        <text>AssignedAnalysis</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563862570_39339_42495" xmi:uuid="dac06090-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122501608_416494_38621"/>
        <bounds x="525" y="203" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570563853947_470196_42450"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563733421_244252_42083"/>
      <waypoint x="630" y="200"/>
      <waypoint x="522" y="200"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563891322_588390_42514" xmi:uuid="dac882f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121183510_978283_13776"/>
      <ownedElement xmi:id="dac21ff0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dac22040-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121183510_978283_13776"/>
        <text>AnalysisAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="dac53d80-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dac53e90-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="dac592d0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dac59310-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="833" y="168" width="153" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563897322_308720_42567" xmi:uuid="dacc87a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570550800830_842933_41727"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640859705095_921244_67415" xmi:uuid="c2459160-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570550800830_128548_41728"/>
        <bounds x="755" y="196" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563897312_168581_42557" xmi:uuid="dacc08d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122527429_917656_38625"/>
        <bounds x="771" y="177" width="59" height="13"/>
        <text>AssignedTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563897313_824120_42559" xmi:uuid="dacc80a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122527429_917656_38625"/>
        <bounds x="806" y="196" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570563853947_470196_42450"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563891322_588390_42514"/>
      <waypoint x="752" y="193"/>
      <waypoint x="833" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563908676_289182_42583" xmi:uuid="daefc3f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121223171_313016_13784"/>
      <ownedElement xmi:id="dace8040-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dace8090-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121223171_313016_13784"/>
        <text>AnalysisModelObject</text>
      </ownedElement>
      <ownedElement xmi:id="dad1bde0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dad1be30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="daee00c0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daee01b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="daee73a0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daee73e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="daeedf20-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daeedf50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132198_861267_38680"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="daef4900-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daef4930-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132199_764598_38681"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="843a5bf0-d861-013a-5681-737cd8fe39c9" xmi:uuid="843a5d00-d861-013a-5681-737cd8fe39c9" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132200_681002_38682"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="daefbde0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daefbe30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132201_217371_38683"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="665" y="273" width="179" height="120"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563918130_725875_42636" xmi:uuid="daf3cea0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570551012725_458415_41795"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640859735924_12257_67421" xmi:uuid="c264a190-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570551012725_588998_41796"/>
        <bounds x="525" y="346" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563918122_190115_42626" xmi:uuid="daf35100-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122811959_523127_38654"/>
        <bounds x="529" y="327" width="133" height="13"/>
        <text>DefinitionalRepresentations</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563918123_86735_42628" xmi:uuid="daf3c780-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122811959_523127_38654"/>
        <bounds x="638" y="346" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570563782849_526768_42174"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563908676_289182_42583"/>
      <waypoint x="522" y="343"/>
      <waypoint x="665" y="343"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563926673_178127_42651" xmi:uuid="db191b90-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121230940_899251_13786"/>
      <ownedElement xmi:id="daf5cc90-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daf5ccf0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121230940_899251_13786"/>
        <text>AnalysisRepresentationContext</text>
      </ownedElement>
      <ownedElement xmi:id="daf91f00-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="daf91f60-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="db174fa0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="db175030-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="db17c890-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="db17c8e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="db183b10-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="db183b50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182615_259851_38709"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="db18aaa0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="db18aae0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182615_350590_38710"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="84598990-d861-013a-5681-737cd8fe39c9" xmi:uuid="84598a80-d861-013a-5681-737cd8fe39c9" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182616_492161_38711"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="db191680-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="db1916c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182616_150686_38712"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <bounds x="931" y="273" width="182" height="120"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563934154_945095_42704" xmi:uuid="db1d2d70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570551061504_529721_41821"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640859755292_183681_67427" xmi:uuid="c282ff50-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570551061504_810321_41822"/>
        <bounds x="847" y="322" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563934145_381466_42694" xmi:uuid="db1caed0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123146489_313658_38705"/>
        <bounds x="850" y="303" width="78" height="13"/>
        <text>ContextOfItems</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563934146_701112_42696" xmi:uuid="db1d2680-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123146489_313658_38705"/>
        <bounds x="904" y="322" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570563908676_289182_42583"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563926673_178127_42651"/>
      <waypoint x="844" y="319"/>
      <waypoint x="931" y="319"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563963064_112479_42740" xmi:uuid="dbad6900-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ViewContext"/>
      <ownedElement xmi:id="0ded3eb0-9d7a-013a-5557-0d73bd894d70" xmi:uuid="0ded3fe0-9d7a-013a-5557-0d73bd894d70" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ViewContext"/>
        <text>ViewContext</text>
      </ownedElement>
      <ownedElement xmi:id="0df18610-9d7a-013a-5557-0d73bd894d70" xmi:uuid="0df18730-9d7a-013a-5557-0d73bd894d70" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="343" y="504" width="175" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563968193_384106_42808" xmi:uuid="dbb609e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570563064902_387953_42004"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640860946801_462759_67512" xmi:uuid="c2f524c0-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570563064902_471000_42005"/>
        <bounds x="490" y="445" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563968180_960346_42798" xmi:uuid="dbb59a90-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122839684_835310_38658"/>
        <bounds x="421" y="488" width="63" height="13"/>
        <text>InitialContext</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563968180_661730_42800" xmi:uuid="dbb5fda0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122839684_835310_38658"/>
        <bounds x="490" y="488" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570563782849_526768_42174"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563963064_112479_42740"/>
      <waypoint x="487" y="442"/>
      <waypoint x="487" y="504"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570564124159_528130_42820" xmi:uuid="dbc4dfb0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121202797_964567_13780"/>
      <ownedElement xmi:id="dbb7b4a0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dbb7b4f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121202797_964567_13780"/>
        <text>AnalysisModel</text>
      </ownedElement>
      <ownedElement xmi:id="dbba3bd0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dbba3c30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <bounds x="623" y="434" width="88" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570564145821_43186_42862" xmi:uuid="dbcd1b10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121257177_404073_13792"/>
      <ownedElement xmi:id="dbc65ae0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dbc65b80-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121257177_404073_13792"/>
        <text>ExternalAnalysisModel</text>
      </ownedElement>
      <ownedElement xmi:id="dbc8bcf0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dbc8bd40-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="c39ae530-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="c39ae610-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c39c1700-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="c39c1850-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="c39ee9a0-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="c39eea40-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123332831_450503_38790"/>
          <text>ExternalFile</text>
        </ownedElement>
      </ownedElement>
      <bounds x="791" y="427" width="134" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570564215146_666293_42904" xmi:uuid="dbcf5ab0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570551122500_688131_41852"/>
      <source xmi:idref="_18_4_1_6b1022a_1570564124159_528130_42820"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563908676_289182_42583"/>
      <waypoint x="669" y="434"/>
      <waypoint x="669" y="403"/>
      <waypoint x="767" y="403"/>
      <waypoint x="767" y="393"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570564220186_750889_42906" xmi:uuid="dbd1ab40-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570551110019_646855_41849"/>
      <source xmi:idref="_18_4_1_6b1022a_1570564145821_43186_42862"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563908676_289182_42583"/>
      <waypoint x="819" y="427"/>
      <waypoint x="819" y="403"/>
      <waypoint x="767" y="403"/>
      <waypoint x="767" y="393"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1582540006612_337008_54010" xmi:uuid="dbd7cec0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121214220_699464_13782"/>
      <ownedElement xmi:id="dbd37900-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dbd37970-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121214220_699464_13782"/>
        <text>AnalysisModelItemsSelect</text>
      </ownedElement>
      <ownedElement xmi:id="dbd619b0-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dbd61a30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="dbd67000-3aa4-0138-3ecf-418b172fba9f" xmi:uuid="dbd67040-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="595" y="518" width="153" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1582540006628_225782_54055" xmi:uuid="dbdb1ab0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570551294926_545538_41894"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640860973684_492885_67518" xmi:uuid="c31116e0-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570551294926_145399_41895"/>
        <bounds x="672" y="472" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1582540006612_225095_54004" xmi:uuid="dbdaa2a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123021071_164888_38676"/>
        <bounds x="638" y="502" width="28" height="13"/>
        <text>Items</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1582540006612_57172_54006" xmi:uuid="dbdb0e50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123021071_164888_38676"/>
        <bounds x="672" y="502" width="24" height="13"/>
        <text>1..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570564124159_528130_42820"/>
      <target xmi:idref="_18_4_1_6b1022a_1582540006612_337008_54010"/>
      <waypoint x="669" y="469"/>
      <waypoint x="669" y="518"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570563963077_576443_42785" xmi:uuid="dbb0bcc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570563056921_538483_41920"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640860935296_608175_67506" xmi:uuid="c3151490-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570563056921_113904_41921"/>
        <bounds x="388" y="445" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563963062_594892_42734" xmi:uuid="dbb02fb0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122867578_351750_38662"/>
        <bounds x="291" y="488" width="91" height="13"/>
        <text>AdditionalContexts</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570563963063_783454_42736" xmi:uuid="dbb0abe0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122867578_351750_38662"/>
        <bounds x="388" y="488" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_6b1022a_1570563782849_526768_42174"/>
      <target xmi:idref="_18_4_1_6b1022a_1570563963064_112479_42740"/>
      <waypoint x="385" y="442"/>
      <waypoint x="385" y="504"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1128" height="582"/>
    <name>Analysis</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_6b1022a_1570744740704_131841_51034" xmi:uuid="183b3fed-dbd6-4ed8-af22-5ac5f70519d2" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121230940_899251_13786"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570798456100_722051_56830" xmi:uuid="dc1ab4d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570798456065_659070_56826"/>
      <bounds x="1504" y="61" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570744747341_85528_51070" xmi:uuid="dc1b9b70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182616_492161_38711"/>
      <ownedElement xmi:id="eef14f10-7cad-0138-40ff-418b172fba9f" xmi:uuid="eef14f90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182616_492161_38711"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="eef31a30-7cad-0138-40ff-418b172fba9f" xmi:uuid="eef31a80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182616_492161_38711"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796383171_417034_54781" xmi:uuid="dc1b4520-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="18ff9790-6c44-013d-931d-0800270c66d6" xmi:uuid="18ff9860-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="248" y="66" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="230" y="75" width="15" height="15"/>
      </ownedElement>
      <bounds x="35" y="70" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570744747350_248462_51101" xmi:uuid="dc1bae20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182615_350590_38710"/>
      <ownedElement xmi:id="ef031830-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef0318b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182615_350590_38710"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ef04f2a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef04f2f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182615_350590_38710"/>
        <text>[0..1]</text>
      </ownedElement>
      <bounds x="35" y="133" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570744747358_923711_51132" xmi:uuid="dc1bba00-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182615_259851_38709"/>
      <ownedElement xmi:id="ef141810-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef141890-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182615_259851_38709"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ef15e580-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef15e5d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182615_259851_38709"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="42" y="427" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570744747368_680622_51163" xmi:uuid="dc1c5810-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182616_150686_38712"/>
      <ownedElement xmi:id="ef24c6b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef24c740-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182616_150686_38712"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="ef268d30-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef268d90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123182616_150686_38712"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796392810_416885_54807" xmi:uuid="dc1c2100-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="1b99c1f0-6c44-013d-931d-0800270c66d6" xmi:uuid="1b99c2a0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="192" y="533" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="174" y="542" width="15" height="15"/>
      </ownedElement>
      <bounds x="42" y="539" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570796436529_262925_54840" xmi:uuid="dc1d97d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796436512_813338_54839"/>
      <ownedElement xmi:id="ef371a00-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef371a80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796436512_813338_54839"/>
        <text>defStr:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796519642_366378_55021" xmi:uuid="dc1cd180-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="1cce7ee0-6c44-013d-931d-0800270c66d6" xmi:uuid="1cce7f70-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="525" y="111" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="574" y="138" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796519650_394311_55031" xmi:uuid="dc1d7c60-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="1d6a0c90-6c44-013d-931d-0800270c66d6" xmi:uuid="1d6a0d30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="745" y="132" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="727" y="141" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="574" y="126" width="168" height="38"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570796445701_87453_54864" xmi:uuid="dc1faee0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796445680_54887_54863"/>
      <ownedElement xmi:id="ef4975d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef497720-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796445680_54887_54863"/>
        <text>descSel:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796511413_328107_54933" xmi:uuid="dc1e09b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="1ea79810-6c44-013d-931d-0800270c66d6" xmi:uuid="1ea798b0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="247" y="129" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="301" y="138" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796511423_372219_54943" xmi:uuid="dc1e8230-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="1f446090-6c44-013d-931d-0800270c66d6" xmi:uuid="1f446130-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="495" y="129" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="477" y="138" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796511429_265522_54953" xmi:uuid="dc1f0410-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="1ff55590-6c44-013d-931d-0800270c66d6" xmi:uuid="1ff55630-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="495" y="173" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="477" y="182" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796511438_179462_54963" xmi:uuid="dc1f8c30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="207bc1f0-6c44-013d-931d-0800270c66d6" xmi:uuid="207bc340-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="385" y="210" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="370" y="188" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="126" width="191" height="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570796457329_534270_54888" xmi:uuid="dc2139f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796457312_365074_54887"/>
      <ownedElement xmi:id="ef5cefb0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef5cf040-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796457312_365074_54887"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796515524_203005_54983" xmi:uuid="dc202b70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="2193d350-6c44-013d-931d-0800270c66d6" xmi:uuid="2193d400-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="212" y="424" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="266" y="433" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796515535_577878_54993" xmi:uuid="dc20a740-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="2243f410-6c44-013d-931d-0800270c66d6" xmi:uuid="2243f4e0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="421" y="398" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="403" y="407" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796515544_865249_55003" xmi:uuid="dc212030-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="22ca7fa0-6c44-013d-931d-0800270c66d6" xmi:uuid="22ca8060-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="421" y="446" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="403" y="455" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="266" y="392" width="152" height="85"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570796593480_363955_55073" xmi:uuid="dc227fc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796593467_89154_55071"/>
      <ownedElement xmi:id="ef7022f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef702400-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796593467_89154_55071"/>
        <text>defStr1:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796593480_335478_55074" xmi:uuid="dc21d530-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="241d63c0-6c44-013d-931d-0800270c66d6" xmi:uuid="241d65b0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="506" y="395" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="560" y="404" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570796593480_324438_55076" xmi:uuid="dc2262d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="24a82c00-6c44-013d-931d-0800270c66d6" xmi:uuid="24a82ca0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="731" y="398" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="713" y="407" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="560" y="392" width="168" height="38"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797040384_391336_55549" xmi:uuid="d81995f0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797041659_698203_55550"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796664232_988233_55158"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796902079_886545_55294"/>
      <waypoint x="1176" y="81"/>
      <waypoint x="1010" y="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570796624093_395852_55120" xmi:uuid="dc2294b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796624069_44346_55119"/>
      <ownedElement xmi:id="ef83c9c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef83ca40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796624069_44346_55119"/>
        <text>clasAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ef8591a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ef8591f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796624069_44346_55119"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="25764a70-6c44-013d-931d-0800270c66d6" xmi:uuid="25764b10-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="257700f0-6c44-013d-931d-0800270c66d6" xmi:uuid="257701b0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570796902079_886545_55294" xmi:uuid="efb7b450-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="efa67100-7cad-0138-40ff-418b172fba9f" xmi:uuid="efa67170-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="efb73800-7cad-0138-40ff-418b172fba9f" xmi:uuid="efb73880-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="826" y="77" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="819" y="49" width="294" height="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570796664232_988233_55158" xmi:uuid="dc22a4d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796664218_745659_55157"/>
      <ownedElement xmi:id="efca1770-7cad-0138-40ff-418b172fba9f" xmi:uuid="efca17f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796664218_745659_55157"/>
        <text>analRepCont:Analysis_representation_context</text>
      </ownedElement>
      <ownedElement xmi:id="efcbea20-7cad-0138-40ff-418b172fba9f" xmi:uuid="efcbea70-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796664218_745659_55157"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="27d79f30-6c44-013d-931d-0800270c66d6" xmi:uuid="27d79fd0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="27f0c370-6c44-013d-931d-0800270c66d6" xmi:uuid="27f0c440-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570796879945_928351_55201" xmi:uuid="effdf8d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_context-id"/>
          <ownedElement xmi:id="efecaec0-7cad-0138-40ff-418b172fba9f" xmi:uuid="efecaf30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_context-id"/>
            <text>id:identifier</text>
          </ownedElement>
          <ownedElement xmi:id="effd7ca0-7cad-0138-40ff-418b172fba9f" xmi:uuid="effd7d10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_context-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1197" y="399" width="105" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570796879947_501692_55232" xmi:uuid="f02f2bd0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_context-kind"/>
          <ownedElement xmi:id="f01e0d90-7cad-0138-40ff-418b172fba9f" xmi:uuid="f01e0e10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_context-kind"/>
            <text>kind:text</text>
          </ownedElement>
          <ownedElement xmi:id="f02eacf0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f02ead70-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_context-kind"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1190" y="133" width="90" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570796879948_146458_55263" xmi:uuid="f060cd70-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_context-representations_in_context"/>
          <ownedElement xmi:id="f04f1b80-7cad-0138-40ff-418b172fba9f" xmi:uuid="f04f1c00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_context-representations_in_context"/>
            <text>representations_in_context:Representation</text>
          </ownedElement>
          <ownedElement xmi:id="f0605160-7cad-0138-40ff-418b172fba9f" xmi:uuid="f06051e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_context-representations_in_context"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1190" y="623" width="293" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1176" y="49" width="314" height="609"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797412633_871012_55855" xmi:uuid="d907eca0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797413737_235536_55856"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796664232_988233_55158"/>
      <target xmi:idref="_18_4_1_6b1022a_1570797392759_550275_55788"/>
      <waypoint x="1176" y="214"/>
      <waypoint x="1008" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570796938353_435800_55328" xmi:uuid="dc22b120-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796938337_848738_55327"/>
      <ownedElement xmi:id="f0725140-7cad-0138-40ff-418b172fba9f" xmi:uuid="f07251c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796938337_848738_55327"/>
        <text>descTextAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f0741660-7cad-0138-40ff-418b172fba9f" xmi:uuid="f07416b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796938337_848738_55327"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="2ba62c20-6c44-013d-931d-0800270c66d6" xmi:uuid="2ba62cd0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2bb02ef0-6c44-013d-931d-0800270c66d6" xmi:uuid="2bb02fc0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570797392759_550275_55788" xmi:uuid="f0a63330-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="f094ef20-7cad-0138-40ff-418b172fba9f" xmi:uuid="f094ef90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="f0a5b770-7cad-0138-40ff-418b172fba9f" xmi:uuid="f0a5b7e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="210" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="826" y="182" width="291" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570798098095_202075_56607" xmi:uuid="d99dae70-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570798099514_995457_56608"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796664232_988233_55158"/>
      <target xmi:idref="_18_4_1_6b1022a_1570797437357_722179_55898"/>
      <waypoint x="1176" y="340"/>
      <waypoint x="1061" y="340"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570796957137_982145_55366" xmi:uuid="dc22bfb0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796957123_295513_55365"/>
      <ownedElement xmi:id="f0b84470-7cad-0138-40ff-418b172fba9f" xmi:uuid="f0b845a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796957123_295513_55365"/>
        <text>langIndic:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="f0ba3e50-7cad-0138-40ff-418b172fba9f" xmi:uuid="f0ba3ec0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796957123_295513_55365"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="2e10ec00-6c44-013d-931d-0800270c66d6" xmi:uuid="2e10ecc0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2e1192d0-6c44-013d-931d-0800270c66d6" xmi:uuid="2e119370-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570797437356_150374_55867" xmi:uuid="f0dd85b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="f0cc3550-7cad-0138-40ff-418b172fba9f" xmi:uuid="f0cc35d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="f0dd0760-7cad-0138-40ff-418b172fba9f" xmi:uuid="f0dd07e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="833" y="364" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570797437357_722179_55898" xmi:uuid="f10f4b60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="f0fd6a70-7cad-0138-40ff-418b172fba9f" xmi:uuid="f0fd6af0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="f10ed050-7cad-0138-40ff-418b172fba9f" xmi:uuid="f10ed0d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="329" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570797437359_483604_55929" xmi:uuid="f13ff830-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="f12ee3a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f12ee410-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="f13f7c30-7cad-0138-40ff-418b172fba9f" xmi:uuid="f13f7ca0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="294" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="826" y="266" width="287" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797863986_601744_56409" xmi:uuid="d9f8c4c0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797866418_319480_56410"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796664232_988233_55158"/>
      <target xmi:idref="_18_4_1_6b1022a_1570797839423_893289_56348"/>
      <waypoint x="1176" y="480"/>
      <waypoint x="1016" y="480"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570796975089_639884_55404" xmi:uuid="dc22cb50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796975075_712777_55403"/>
      <ownedElement xmi:id="f1520a00-7cad-0138-40ff-418b172fba9f" xmi:uuid="f1520a80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796975075_712777_55403"/>
        <text>identAssgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f153cc30-7cad-0138-40ff-418b172fba9f" xmi:uuid="f153cc90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796975075_712777_55403"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="3300a160-6c44-013d-931d-0800270c66d6" xmi:uuid="3300a210-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="331d2be0-6c44-013d-931d-0800270c66d6" xmi:uuid="331d2d00-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570797839423_893289_56348" xmi:uuid="f185c240-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="f174abc0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f174ac40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f1854630-7cad-0138-40ff-418b172fba9f" xmi:uuid="f18546a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="476" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="826" y="448" width="287" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797938132_405631_56492" xmi:uuid="da40ce00-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797939443_180276_56493"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796664232_988233_55158"/>
      <target xmi:idref="_18_4_1_6b1022a_1570797889956_608362_56421"/>
      <waypoint x="1176" y="564"/>
      <waypoint x="1049" y="564"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570796993768_61177_55442" xmi:uuid="dc22d750-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796993753_900177_55441"/>
      <ownedElement xmi:id="f197e410-7cad-0138-40ff-418b172fba9f" xmi:uuid="f197e480-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796993753_900177_55441"/>
        <text>extItAssgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="f199b2b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f199b300-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796993753_900177_55441"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="35844630-6c44-013d-931d-0800270c66d6" xmi:uuid="35844700-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3584e9d0-6c44-013d-931d-0800270c66d6" xmi:uuid="3584ea50-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570797889956_608362_56421" xmi:uuid="f1cbec10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="f1ba9de0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f1ba9e60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f1cb6870-7cad-0138-40ff-418b172fba9f" xmi:uuid="f1cb68f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="826" y="560" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="819" y="532" width="294" height="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797034291_265397_55524" xmi:uuid="dc22ebc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797037187_139431_55525"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796624093_395852_55120"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796383171_417034_54781"/>
      <waypoint x="819" y="81"/>
      <waypoint x="245" y="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797052090_591387_55568" xmi:uuid="dc22f3b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797053106_978679_55569"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796511413_328107_54933"/>
      <target xmi:idref="_18_4_1_6b1022a_1570744747350_248462_51101"/>
      <waypoint x="301" y="144"/>
      <waypoint x="241" y="144"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797067226_65950_55589" xmi:uuid="dc22fc20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797069627_884755_55590"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796519642_366378_55021"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796511423_372219_54943"/>
      <waypoint x="574" y="144"/>
      <waypoint x="492" y="144"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797082721_791198_55613" xmi:uuid="dc2303f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797085339_584039_55614"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796879947_501692_55232"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796519650_394311_55031"/>
      <waypoint x="1190" y="147"/>
      <waypoint x="742" y="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797244488_215236_55653" xmi:uuid="dc23ae90-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797244466_287839_55648"/>
      <ownedElement xmi:id="f2527200-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2527270-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797244466_287839_55648"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="f2544060-7cad-0138-40ff-418b172fba9f" xmi:uuid="f25440b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797244466_287839_55648"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570797304542_718494_55696" xmi:uuid="dc2372f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="38444640-6c44-013d-931d-0800270c66d6" xmi:uuid="384447b0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="717" y="167" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="748" y="186" width="15" height="15"/>
      </ownedElement>
      <bounds x="574" y="182" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797317344_715094_55731" xmi:uuid="dc23bae0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797318146_500591_55732"/>
      <source xmi:idref="_18_4_1_6b1022a_1570797244488_215236_55653"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796511429_265522_54953"/>
      <waypoint x="574" y="189"/>
      <waypoint x="492" y="189"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797407811_442212_55830" xmi:uuid="dc23dfe0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797408898_900886_55831"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796938353_435800_55328"/>
      <target xmi:idref="_18_4_1_6b1022a_1570797304542_718494_55696"/>
      <waypoint x="826" y="193"/>
      <waypoint x="763" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797495225_45777_55979" xmi:uuid="dc24b060-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797495212_386826_55978"/>
      <ownedElement xmi:id="f263e5a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f263e620-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797495212_386826_55978"/>
        <text>lang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="f265b1a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f265b1f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797495212_386826_55978"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570797567664_560489_56055" xmi:uuid="dc2453e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="39904090-6c44-013d-931d-0800270c66d6" xmi:uuid="39904140-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="640" y="287" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="622" y="296" width="15" height="15"/>
      </ownedElement>
      <bounds x="455" y="291" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797576730_348688_56090" xmi:uuid="dc24c0f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797579249_237037_56091"/>
      <source xmi:idref="_18_4_1_6b1022a_1570797437359_483604_55929"/>
      <target xmi:idref="_18_4_1_6b1022a_1570797567664_560489_56055"/>
      <waypoint x="833" y="305"/>
      <waypoint x="637" y="305"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797606858_49635_56142" xmi:uuid="dc24c8b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797609122_579731_56143"/>
      <source xmi:idref="_18_4_1_6b1022a_1570797495225_45777_55979"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796511438_179462_54963"/>
      <waypoint x="455" y="301"/>
      <waypoint x="378" y="301"/>
      <waypoint x="378" y="203"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797719540_513199_56205" xmi:uuid="dc24d080-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797721154_566627_56206"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796515524_203005_54983"/>
      <target xmi:idref="_18_4_1_6b1022a_1570744747358_923711_51132"/>
      <waypoint x="266" y="441"/>
      <waypoint x="175" y="441"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797727108_147819_56224" xmi:uuid="dc24d890-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797728513_51050_56225"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796593480_335478_55074"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796515535_577878_54993"/>
      <waypoint x="560" y="413"/>
      <waypoint x="418" y="413"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797732827_565323_56246" xmi:uuid="dc24e060-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797735698_97269_56247"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796879945_928351_55201"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796593480_324438_55076"/>
      <waypoint x="1197" y="413"/>
      <waypoint x="728" y="413"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797754483_380291_56265" xmi:uuid="dc258e10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797754462_308071_56261"/>
      <ownedElement xmi:id="f2755a90-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2755ba0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797754462_308071_56261"/>
        <text>id:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="f27727c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2772810-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797754462_308071_56261"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570797800920_270741_56309" xmi:uuid="dc255280-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="3af7f790-6c44-013d-931d-0800270c66d6" xmi:uuid="3af7f830-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="633" y="450" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="615" y="459" width="15" height="15"/>
      </ownedElement>
      <bounds x="497" y="455" width="126" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797821126_902948_56336" xmi:uuid="dc259a10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797823002_747831_56337"/>
      <source xmi:idref="_18_4_1_6b1022a_1570797754483_380291_56265"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796515544_865249_55003"/>
      <waypoint x="497" y="462"/>
      <waypoint x="418" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797855160_103909_56390" xmi:uuid="dc25a180-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797857010_728305_56391"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796975089_639884_55404"/>
      <target xmi:idref="_18_4_1_6b1022a_1570797800920_270741_56309"/>
      <waypoint x="826" y="466"/>
      <waypoint x="630" y="466"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570797900051_215881_56463" xmi:uuid="dc25a8f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570797901707_669662_56464"/>
      <source xmi:idref="_18_4_1_6b1022a_1570796993768_61177_55442"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796392810_416885_54807"/>
      <waypoint x="819" y="550"/>
      <waypoint x="189" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570798538926_153753_56857" xmi:uuid="dc25c940-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570798540513_512119_56858"/>
      <source xmi:idref="_18_4_1_6b1022a_1570798456100_722051_56830"/>
      <target xmi:idref="_18_4_1_6b1022a_1570796664232_988233_55158"/>
      <waypoint x="1504" y="67"/>
      <waypoint x="1490" y="67"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571732413699_106585_49834" xmi:uuid="dc25d3f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571732413684_123070_49833"/>
      <ownedElement xmi:id="f28c4b60-7cad-0138-40ff-418b172fba9f" xmi:uuid="f28c4bb0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571732413684_123070_49833"/>
        <text>descAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="f28e07c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f28e0810-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571732413684_123070_49833"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="434" y="364" width="184" height="22"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571732598199_723132_49903" xmi:uuid="dc25dc10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571732600714_199261_49904"/>
      <source xmi:idref="_18_4_1_6b1022a_1570797437356_150374_55867"/>
      <target xmi:idref="_18_4_1_6b1022a_1571732413699_106585_49834"/>
      <waypoint x="833" y="375"/>
      <waypoint x="618" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1608715503204_885849_73253" xmi:uuid="c7243760-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="444a7000-0d28-013c-5e16-5b8e392dc4e5" xmi:uuid="444a7410-0d28-013c-5e16-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Rationale</text>
      </ownedElement>
      <ownedElement xmi:id="444b66e0-0d28-013c-5e16-5b8e392dc4e5" xmi:uuid="444b67f0-0d28-013c-5e16-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608715503189_741107_73251"/>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="840" y="623" width="207" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1608715528823_572400_73271" xmi:uuid="c7243de0-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_6b1022a_1570796879948_146458_55263"/>
      <target xmi:idref="_18_4_1_2b2015d_1608715503204_885849_73253"/>
      <waypoint x="1190" y="642"/>
      <waypoint x="1047" y="649"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1507" height="701"/>
    <name>AnalysisRepresentationContext</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_6b1022a_1570565773841_398603_41100" xmi:uuid="27643367-37cc-4712-9766-ca3af6c8c783" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570701020943_881704_43427" xmi:uuid="dbde4f30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570701020916_723421_43423"/>
      <bounds x="1441" y="118" width="15" height="21"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570565868959_197328_41135" xmi:uuid="dbdeea00-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122303496_724866_38580"/>
      <ownedElement xmi:id="dbad1720-7cad-0138-40ff-418b172fba9f" xmi:uuid="dbad1860-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122303496_724866_38580"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="dbaee260-7cad-0138-40ff-418b172fba9f" xmi:uuid="dbaee2b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122303496_724866_38580"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570641313147_305390_44539" xmi:uuid="dbdeb2d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="1ac89d90-6c43-013d-931d-0800270c66d6" xmi:uuid="1ac89e30-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="241" y="723" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="223" y="732" width="15" height="15"/>
      </ownedElement>
      <bounds x="28" y="728" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570565868972_653021_41166" xmi:uuid="dbdef7f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122265317_316213_38573"/>
      <ownedElement xmi:id="dbbe4c90-7cad-0138-40ff-418b172fba9f" xmi:uuid="dbbe4d10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122265317_316213_38573"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="dbc04440-7cad-0138-40ff-418b172fba9f" xmi:uuid="dbc044d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122265317_316213_38573"/>
        <text>[0..1]</text>
      </ownedElement>
      <bounds x="28" y="322" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570565868977_587434_41197" xmi:uuid="dbdf0640-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121916854_195975_13808"/>
      <ownedElement xmi:id="dbd3b340-7cad-0138-40ff-418b172fba9f" xmi:uuid="dbd3b3c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121916854_195975_13808"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="dbd62680-7cad-0138-40ff-418b172fba9f" xmi:uuid="dbd626f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121916854_195975_13808"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="28" y="581" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570565868986_892258_41228" xmi:uuid="dbdf12e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122232748_720258_38565"/>
      <ownedElement xmi:id="dbe9cd80-7cad-0138-40ff-418b172fba9f" xmi:uuid="dbe9ce00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122232748_720258_38565"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="dbec1a20-7cad-0138-40ff-418b172fba9f" xmi:uuid="dbec1a90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122232748_720258_38565"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="35" y="49" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570565868993_991085_41259" xmi:uuid="dbdfd350-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122328369_727665_38584"/>
      <ownedElement xmi:id="dbff3950-7cad-0138-40ff-418b172fba9f" xmi:uuid="dbff39c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122328369_727665_38584"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="dc016da0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc016df0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122328369_727665_38584"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570641945473_468140_44828" xmi:uuid="dbdfa230-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="1e9058f0-6c43-013d-931d-0800270c66d6" xmi:uuid="1e905990-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="206" y="843" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="188" y="852" width="15" height="15"/>
      </ownedElement>
      <bounds x="28" y="847" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570565869001_91372_41290" xmi:uuid="dbe06e20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122351937_533382_38588"/>
      <ownedElement xmi:id="dc0698c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc069940-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122351937_533382_38588"/>
        <text>Versions:AnalysisVersion</text>
      </ownedElement>
      <ownedElement xmi:id="dc08cd40-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc08cd90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122351937_533382_38588"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570744840798_300160_51218" xmi:uuid="dbe041c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727531350_445591_44578"/>
        <ownedElement xmi:id="1ee9b420-6c43-013d-931d-0800270c66d6" xmi:uuid="1ee9b4f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727531350_445591_44578"/>
          <bounds x="248" y="920" width="185" height="13"/>
          <text>analysisVersion : Analysis_version [1]</text>
        </ownedElement>
        <bounds x="230" y="929" width="15" height="15"/>
      </ownedElement>
      <bounds x="28" y="924" width="210" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570566793210_444714_41362" xmi:uuid="dbe27870-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570566793192_910012_41361"/>
      <ownedElement xmi:id="dc1d7340-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc1d73d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570566793192_910012_41361"/>
        <text>selectName:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570568307607_388336_41651" xmi:uuid="dbe0dbd0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="20113eb0-6c43-013d-931d-0800270c66d6" xmi:uuid="20113f40-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="577" y="43" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="559" y="52" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570568307613_746766_41661" xmi:uuid="dbe14d60-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="20bed580-6c43-013d-931d-0800270c66d6" xmi:uuid="20bed620-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="545" y="82" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="535" y="64" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570568307597_630904_41641" xmi:uuid="dbe1bf30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="21426e20-6c43-013d-931d-0800270c66d6" xmi:uuid="21426ec0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="282" y="41" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="336" y="50" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570568307620_439125_41671" xmi:uuid="dbe26320-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="221f99a0-6c43-013d-931d-0800270c66d6" xmi:uuid="221f9a50-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="429" y="82" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="419" y="64" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="336" y="14" width="238" height="65"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570567989479_591653_41562" xmi:uuid="dbe374b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570567989465_799376_41561"/>
      <ownedElement xmi:id="dc3646a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc364710-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570567989465_799376_41561"/>
        <text>defaultName:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570568354275_755763_41699" xmi:uuid="dbe2e8d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="23439900-6c43-013d-931d-0800270c66d6" xmi:uuid="23439990-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="716" y="45" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="770" y="54" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570568354281_790774_41709" xmi:uuid="dbe35d20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="242c2ce0-6c43-013d-931d-0800270c66d6" xmi:uuid="242c2dc0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="1046" y="53" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="1028" y="62" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="770" y="42" width="273" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570568794791_574005_41840" xmi:uuid="dbe40c10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570568794763_959142_41836"/>
      <ownedElement xmi:id="dc4c9a90-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc4c9b10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570568794763_959142_41836"/>
        <text>names:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="dc4ec130-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc4ec180-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570568794763_959142_41836"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570607036086_713549_43627" xmi:uuid="dbe3de50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="257f3eb0-6c43-013d-931d-0800270c66d6" xmi:uuid="257f3f60-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="553" y="118" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="643" y="138" width="15" height="15"/>
      </ownedElement>
      <bounds x="469" y="133" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570568851571_512539_41905" xmi:uuid="dbe4aaf0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570568851559_293932_41904"/>
      <ownedElement xmi:id="dc647330-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc6473b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570568851559_293932_41904"/>
        <text>nameLanguage:Language</text>
      </ownedElement>
      <ownedElement xmi:id="dc6670c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc667140-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570568851559_293932_41904"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570607432280_570331_43885" xmi:uuid="dbe479f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="26f3b220-6c43-013d-931d-0800270c66d6" xmi:uuid="26f3b2e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="563" y="233" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="545" y="242" width="15" height="15"/>
      </ownedElement>
      <bounds x="350" y="238" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570608671452_213412_44038" xmi:uuid="c4d7fcf0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570608674486_597172_44039"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569390599_271599_42670"/>
      <target xmi:idref="_18_4_1_6b1022a_1570607156976_320992_43682"/>
      <waypoint x="1134" y="137"/>
      <waypoint x="959" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570569107228_587930_41989" xmi:uuid="dbe4bed0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570569107214_154343_41988"/>
      <ownedElement xmi:id="dc959a40-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc959ac0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570569107214_154343_41988"/>
        <text>nameAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="dc9765b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dc976600-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570569107214_154343_41988"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="2b20f500-6c43-013d-931d-0800270c66d6" xmi:uuid="2b20f5c0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2b3cf640-6c43-013d-931d-0800270c66d6" xmi:uuid="2b3cf730-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570607156976_320992_43682" xmi:uuid="dcca9590-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="dcb8cf40-7cad-0138-40ff-418b172fba9f" xmi:uuid="dcb8cfc0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="dcca1730-7cad-0138-40ff-418b172fba9f" xmi:uuid="dcca17c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="784" y="126" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="770" y="98" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570569390599_271599_42670" xmi:uuid="dbe4ccb0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570569390588_371651_42669"/>
      <ownedElement xmi:id="dcdc9f10-7cad-0138-40ff-418b172fba9f" xmi:uuid="dcdc9fa0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570569390588_371651_42669"/>
        <text>analysis:Analysis</text>
      </ownedElement>
      <ownedElement xmi:id="dcde6870-7cad-0138-40ff-418b172fba9f" xmi:uuid="dcde68c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570569390588_371651_42669"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="2dc81f50-6c43-013d-931d-0800270c66d6" xmi:uuid="2dc82010-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="2dc91750-6c43-013d-931d-0800270c66d6" xmi:uuid="2dc91800-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570569477354_55266_42706" xmi:uuid="dd0159a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-description"/>
          <ownedElement xmi:id="dcf05370-7cad-0138-40ff-418b172fba9f" xmi:uuid="dcf053e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="dd00d0b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dd00d130-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1155" y="329" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570569477364_317755_42737" xmi:uuid="dd237af0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-id"/>
          <ownedElement xmi:id="dd11f010-7cad-0138-40ff-418b172fba9f" xmi:uuid="dd11f090-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="dd22f3f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dd22f470-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1148" y="588" width="88" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570569477373_531710_42768" xmi:uuid="dd44f800-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-name"/>
          <ownedElement xmi:id="dd340820-7cad-0138-40ff-418b172fba9f" xmi:uuid="dd3408a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="dd4478c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dd447930-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1176" y="56" width="109" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1134" y="28" width="196" height="945"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570569632516_15433_42833" xmi:uuid="dbe4d600-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570569633668_808156_42834"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569477373_531710_42768"/>
      <target xmi:idref="_18_4_1_6b1022a_1570568354281_790774_41709"/>
      <waypoint x="1176" y="67"/>
      <waypoint x="1043" y="67"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570568370358_327971_41736" xmi:uuid="dbe4de00-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570568374430_534334_41737"/>
      <source xmi:idref="_18_4_1_6b1022a_1570568354275_755763_41699"/>
      <target xmi:idref="_18_4_1_6b1022a_1570568307607_388336_41651"/>
      <waypoint x="770" y="60"/>
      <waypoint x="574" y="60"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570568829049_192006_41890" xmi:uuid="dbe4e5f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570568830456_45525_41891"/>
      <source xmi:idref="_18_4_1_6b1022a_1570568794791_574005_41840"/>
      <target xmi:idref="_18_4_1_6b1022a_1570568307613_746766_41661"/>
      <waypoint x="543" y="133"/>
      <waypoint x="543" y="79"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570568866065_881834_41950" xmi:uuid="dbe4f700-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570568868768_700132_41951"/>
      <source xmi:idref="_18_4_1_6b1022a_1570568851571_512539_41905"/>
      <target xmi:idref="_18_4_1_6b1022a_1570568307620_439125_41671"/>
      <waypoint x="424" y="238"/>
      <waypoint x="424" y="79"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570607058653_212272_43662" xmi:uuid="dbe50ad0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570607059663_433306_43663"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569107228_587930_41989"/>
      <target xmi:idref="_18_4_1_6b1022a_1570607036086_713549_43627"/>
      <waypoint x="770" y="144"/>
      <waypoint x="658" y="144"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570608696164_507060_44057" xmi:uuid="c5f7c360-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570608698486_525939_44058"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569390599_271599_42670"/>
      <target xmi:idref="_18_4_1_6b1022a_1570607340151_370858_43803"/>
      <waypoint x="1134" y="214"/>
      <waypoint x="1019" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570607228404_502885_43730" xmi:uuid="dbe51f60-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570607228389_297254_43729"/>
      <ownedElement xmi:id="dd565860-7cad-0138-40ff-418b172fba9f" xmi:uuid="dd565e20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570607228389_297254_43729"/>
        <text>nameLangIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="dd5852c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dd585330-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570607228389_297254_43729"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="3249c2c0-6c43-013d-931d-0800270c66d6" xmi:uuid="3249c390-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="324d7d90-6c43-013d-931d-0800270c66d6" xmi:uuid="324d7e70-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570607340137_677013_43772" xmi:uuid="dd7c4110-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="dd6a6960-7cad-0138-40ff-418b172fba9f" xmi:uuid="dd6a69e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="dd7bc1a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dd7bc220-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="791" y="273" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570607340151_370858_43803" xmi:uuid="ddad9d40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="dd9c2420-7cad-0138-40ff-418b172fba9f" xmi:uuid="dd9c24a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="ddad19c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ddad1a30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="791" y="203" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570607340162_571201_43834" xmi:uuid="dddf8e20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="ddce2f00-7cad-0138-40ff-418b172fba9f" xmi:uuid="ddce2f80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="dddf0cb0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dddf0d30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="791" y="238" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="770" y="175" width="275" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570607518965_492245_43930" xmi:uuid="dbe52690-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570607522719_293867_43931"/>
      <source xmi:idref="_18_4_1_6b1022a_1570607340162_571201_43834"/>
      <target xmi:idref="_18_4_1_6b1022a_1570607432280_570331_43885"/>
      <waypoint x="791" y="249"/>
      <waypoint x="560" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570608256613_292118_43972" xmi:uuid="dbe532b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570608256565_487947_43970"/>
      <ownedElement xmi:id="dde1cfa0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dde1d020-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570608256565_487947_43970"/>
        <text>nameAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="dde3ba80-7cad-0138-40ff-418b172fba9f" xmi:uuid="dde3bb00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570608256565_487947_43970"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="343" y="273" width="207" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570609543628_145257_44130" xmi:uuid="dbe72040-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570609543613_320683_44129"/>
      <ownedElement xmi:id="ddf4a450-7cad-0138-40ff-418b172fba9f" xmi:uuid="ddf4a5a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570609543613_320683_44129"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570609568627_219880_44152" xmi:uuid="dbe59ff0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="38659930-6c43-013d-931d-0800270c66d6" xmi:uuid="386599c0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="289" y="318" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="343" y="327" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570609568636_385646_44162" xmi:uuid="dbe61870-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="3912d400-6c43-013d-931d-0800270c66d6" xmi:uuid="3912d490-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="591" y="325" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="573" y="334" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570609568642_969587_44172" xmi:uuid="dbe68e10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="39892300-6c43-013d-931d-0800270c66d6" xmi:uuid="398923a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="455" y="373" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="515" y="353" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570609568649_746282_44182" xmi:uuid="dbe70410-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="3a312030-6c43-013d-931d-0800270c66d6" xmi:uuid="3a3120c0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="315" y="373" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="387" y="353" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="343" y="315" width="245" height="53"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570609627968_665116_44231" xmi:uuid="dbe72d20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570609631007_876820_44232"/>
      <source xmi:idref="_18_4_1_6b1022a_1570609568627_219880_44152"/>
      <target xmi:idref="_18_4_1_6b1022a_1570565868972_653021_41166"/>
      <waypoint x="343" y="333"/>
      <waypoint x="234" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570609658342_305360_44252" xmi:uuid="dbe73620-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570609660094_627157_44253"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569477354_55266_42706"/>
      <target xmi:idref="_18_4_1_6b1022a_1570609568636_385646_44162"/>
      <waypoint x="1155" y="340"/>
      <waypoint x="588" y="340"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570640877181_713397_44282" xmi:uuid="dbeab280-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570640877166_852665_44281"/>
      <ownedElement xmi:id="de088260-7cad-0138-40ff-418b172fba9f" xmi:uuid="de0882d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570640877166_852665_44281"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570640907626_181298_44310" xmi:uuid="dbe7b1a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="3bc49e30-6c43-013d-931d-0800270c66d6" xmi:uuid="3bc49f40-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="282" y="577" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="336" y="586" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570640907634_796104_44320" xmi:uuid="dbe83220-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="3c765330-6c43-013d-931d-0800270c66d6" xmi:uuid="3c7653d0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="521" y="586" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="503" y="595" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570640907642_235604_44330" xmi:uuid="dbea97f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="3cec5610-6c43-013d-931d-0800270c66d6" xmi:uuid="3cec56b0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="336" y="632" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="406" y="612" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="336" y="574" width="182" height="53"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570640933602_679618_44363" xmi:uuid="dbeabe30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570640934831_953684_44364"/>
      <source xmi:idref="_18_4_1_6b1022a_1570640907626_181298_44310"/>
      <target xmi:idref="_18_4_1_6b1022a_1570565868977_587434_41197"/>
      <waypoint x="336" y="592"/>
      <waypoint x="161" y="592"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570640948979_886237_44376" xmi:uuid="dbebb940-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570640948970_248530_44375"/>
      <ownedElement xmi:id="de1b6dd0-7cad-0138-40ff-418b172fba9f" xmi:uuid="de1b6e50-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570640948970_248530_44375"/>
        <text>default:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570640965486_965036_44400" xmi:uuid="dbeb29b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="3e6db080-6c43-013d-931d-0800270c66d6" xmi:uuid="3e6db130-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="625" y="584" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="679" y="593" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570640965494_903732_44410" xmi:uuid="dbeba120-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="3f2a66a0-6c43-013d-931d-0800270c66d6" xmi:uuid="3f2a6750-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="843" y="584" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="825" y="593" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="679" y="581" width="161" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570641000263_662693_44447" xmi:uuid="dbebc5a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641003886_674963_44448"/>
      <source xmi:idref="_18_4_1_6b1022a_1570640965486_965036_44400"/>
      <target xmi:idref="_18_4_1_6b1022a_1570640907634_796104_44320"/>
      <waypoint x="679" y="602"/>
      <waypoint x="518" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570641021977_236873_44469" xmi:uuid="dbebcd70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641023784_276512_44470"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569477364_317755_42737"/>
      <target xmi:idref="_18_4_1_6b1022a_1570640965494_903732_44410"/>
      <waypoint x="1148" y="602"/>
      <waypoint x="840" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570641514891_631236_44634" xmi:uuid="c67af040-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641516992_653417_44635"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569390599_271599_42670"/>
      <target xmi:idref="_18_4_1_6b1022a_1570641489172_396900_44592"/>
      <waypoint x="1134" y="767"/>
      <waypoint x="968" y="767"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570641205969_412217_44491" xmi:uuid="dbebdae0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641205954_357957_44490"/>
      <ownedElement xmi:id="de2eff30-7cad-0138-40ff-418b172fba9f" xmi:uuid="de2effb0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641205954_357957_44490"/>
        <text>classifiesAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="de30e3e0-7cad-0138-40ff-418b172fba9f" xmi:uuid="de30e440-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641205954_357957_44490"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="400b1d50-6c43-013d-931d-0800270c66d6" xmi:uuid="400b1de0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="400bcdc0-6c43-013d-931d-0800270c66d6" xmi:uuid="400bce80-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570641489172_396900_44592" xmi:uuid="de665670-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="de5155d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="de515650-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="de65be20-7cad-0138-40ff-418b172fba9f" xmi:uuid="de65bea0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="784" y="749" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="763" y="714" width="294" height="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570641343767_754210_44574" xmi:uuid="dbebe2e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641346287_52366_44575"/>
      <source xmi:idref="_18_4_1_6b1022a_1570641205969_412217_44491"/>
      <target xmi:idref="_18_4_1_6b1022a_1570641313147_305390_44539"/>
      <waypoint x="763" y="739"/>
      <waypoint x="238" y="739"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570700836236_340349_43264" xmi:uuid="c6cb02f0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570700838115_278161_43265"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569390599_271599_42670"/>
      <target xmi:idref="_18_4_1_6b1022a_1570700807344_302295_43146"/>
      <waypoint x="1134" y="858"/>
      <waypoint x="1014" y="858"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570641550798_378570_44647" xmi:uuid="dbebeea0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641550788_809722_44646"/>
      <ownedElement xmi:id="de780740-7cad-0138-40ff-418b172fba9f" xmi:uuid="de7807c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641550788_809722_44646"/>
        <text>sameAsAsgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="de79db90-7cad-0138-40ff-418b172fba9f" xmi:uuid="de79ddf0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641550788_809722_44646"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="428c25f0-6c43-013d-931d-0800270c66d6" xmi:uuid="428c2820-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="42bdad90-6c43-013d-931d-0800270c66d6" xmi:uuid="42bdae60-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570700807344_302295_43146" xmi:uuid="deab55a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="de9a2bd0-7cad-0138-40ff-418b172fba9f" xmi:uuid="de9a2c50-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="deaad840-7cad-0138-40ff-418b172fba9f" xmi:uuid="deaad8c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="791" y="847" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="770" y="819" width="276" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570641984880_467224_44871" xmi:uuid="dbebf610-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570641986311_898046_44872"/>
      <source xmi:idref="_18_4_1_6b1022a_1570641550798_378570_44647"/>
      <target xmi:idref="_18_4_1_6b1022a_1570641945473_468140_44828"/>
      <waypoint x="770" y="858"/>
      <waypoint x="203" y="858"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570700698124_131527_43085" xmi:uuid="c7138260-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570700699843_590460_43086"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569390599_271599_42670"/>
      <target xmi:idref="_18_4_1_6b1022a_1570644093837_713480_46157"/>
      <waypoint x="1134" y="949"/>
      <waypoint x="944" y="949"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570643909705_370083_46076" xmi:uuid="dbec23c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570643909694_475508_46075"/>
      <ownedElement xmi:id="debddc80-7cad-0138-40ff-418b172fba9f" xmi:uuid="debddd00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570643909694_475508_46075"/>
        <text>analysisVersion:Analysis_version</text>
      </ownedElement>
      <ownedElement xmi:id="debfb4d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="debfb530-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570643909694_475508_46075"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4556ee90-6c43-013d-931d-0800270c66d6" xmi:uuid="4556ef20-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="45579a10-6c43-013d-931d-0800270c66d6" xmi:uuid="45579ac0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570644093837_713480_46157" xmi:uuid="def1c3c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version-of_product"/>
          <ownedElement xmi:id="dee07040-7cad-0138-40ff-418b172fba9f" xmi:uuid="dee070c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version-of_product"/>
            <text>of_product:Analysis</text>
          </ownedElement>
          <ownedElement xmi:id="def14130-7cad-0138-40ff-418b172fba9f" xmi:uuid="def141b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version-of_product"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="798" y="938" width="146" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="777" y="903" width="266" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570568398500_430282_41751" xmi:uuid="dbec38b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570567415684_932415_41522"/>
      <source xmi:idref="_18_4_1_6b1022a_1570568307597_630904_41641"/>
      <target xmi:idref="_18_4_1_6b1022a_1570565868986_892258_41228"/>
      <waypoint x="336" y="60"/>
      <waypoint x="197" y="60"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570699850269_373176_42600" xmi:uuid="dbec4300-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570699852314_64562_42601"/>
      <source xmi:idref="_18_4_1_6b1022a_1570607340137_677013_43772"/>
      <target xmi:idref="_18_4_1_6b1022a_1570608256613_292118_43972"/>
      <waypoint x="791" y="287"/>
      <waypoint x="550" y="287"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570725355833_511263_43165" xmi:uuid="dbec4a90-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570725357560_564706_43166"/>
      <source xmi:idref="_18_4_1_6b1022a_1570701020943_881704_43427"/>
      <target xmi:idref="_18_4_1_6b1022a_1570569390599_271599_42670"/>
      <waypoint x="1441" y="130"/>
      <waypoint x="1330" y="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570744858656_833019_51241" xmi:uuid="dbec51e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570744861035_892254_51242"/>
      <source xmi:idref="_18_4_1_6b1022a_1570643909705_370083_46076"/>
      <target xmi:idref="_18_4_1_6b1022a_1570744840798_300160_51218"/>
      <waypoint x="777" y="935"/>
      <waypoint x="245" y="935"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677602440_452396_45106" xmi:uuid="dbed0890-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677602416_914578_45102"/>
      <ownedElement xmi:id="df01d130-7cad-0138-40ff-418b172fba9f" xmi:uuid="df01d1a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677602416_914578_45102"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="df03ada0-7cad-0138-40ff-418b172fba9f" xmi:uuid="df03ade0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677602416_914578_45102"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1571677602440_753264_45107" xmi:uuid="dbecc7e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="47b3a7b0-6c43-013d-931d-0800270c66d6" xmi:uuid="47b3a8e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="551" y="378" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="643" y="394" width="15" height="15"/>
      </ownedElement>
      <bounds x="469" y="392" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677625779_925196_45185" xmi:uuid="dbedb8b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677625765_868152_45181"/>
      <ownedElement xmi:id="df136440-7cad-0138-40ff-418b172fba9f" xmi:uuid="df1364c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677625765_868152_45181"/>
        <text>descLanguage1:Language</text>
      </ownedElement>
      <ownedElement xmi:id="df153580-7cad-0138-40ff-418b172fba9f" xmi:uuid="df1535d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677625765_868152_45181"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1571677625779_948643_45186" xmi:uuid="dbed7d40-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="4909c660-6c43-013d-931d-0800270c66d6" xmi:uuid="4909c700-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="577" y="485" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="559" y="494" width="15" height="15"/>
      </ownedElement>
      <bounds x="364" y="490" width="203" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677670926_163604_45269" xmi:uuid="dbedc490-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677672010_266711_45270"/>
      <source xmi:idref="_18_4_1_6b1022a_1571677625779_925196_45185"/>
      <target xmi:idref="_18_4_1_6b1022a_1570609568649_746282_44182"/>
      <waypoint x="396" y="490"/>
      <waypoint x="396" y="368"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677676272_902876_45294" xmi:uuid="dbedcc70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677677859_303071_45295"/>
      <source xmi:idref="_18_4_1_6b1022a_1571677602440_452396_45106"/>
      <target xmi:idref="_18_4_1_6b1022a_1570609568642_969587_44172"/>
      <waypoint x="525" y="392"/>
      <waypoint x="525" y="368"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677959763_64052_45681" xmi:uuid="c7922430-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677960830_327400_45682"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569390599_271599_42670"/>
      <target xmi:idref="_18_4_1_6b1022a_1571677701058_236964_45326"/>
      <waypoint x="1134" y="389"/>
      <waypoint x="959" y="389"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677701058_777826_45325" xmi:uuid="dbedf520-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677697490_845918_45314"/>
      <ownedElement xmi:id="df270b60-7cad-0138-40ff-418b172fba9f" xmi:uuid="df270be0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677697490_845918_45314"/>
        <text>descAsgn1:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="df28d5c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="df28d620-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677697490_845918_45314"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4a1b4c20-6c43-013d-931d-0800270c66d6" xmi:uuid="4a1b4cc0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4a1bf2c0-6c43-013d-931d-0800270c66d6" xmi:uuid="4a1bf340-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1571677701058_236964_45326" xmi:uuid="df5b6f60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="df4a11d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="df4a1250-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="df5aea80-7cad-0138-40ff-418b172fba9f" xmi:uuid="df5aeb00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="784" y="378" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="770" y="350" width="277" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677971086_310171_45700" xmi:uuid="c84b0120-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677973314_216795_45701"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569390599_271599_42670"/>
      <target xmi:idref="_18_4_1_6b1022a_1571677714811_904568_45406"/>
      <waypoint x="1134" y="466"/>
      <waypoint x="1019" y="466"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677714811_906034_45404" xmi:uuid="dbee02e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677712652_540766_45393"/>
      <ownedElement xmi:id="df6d6160-7cad-0138-40ff-418b172fba9f" xmi:uuid="df6d61e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677712652_540766_45393"/>
        <text>descLangIndication1:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="df6f2fe0-7cad-0138-40ff-418b172fba9f" xmi:uuid="df6f3030-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677712652_540766_45393"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="4c8fe750-6c43-013d-931d-0800270c66d6" xmi:uuid="4c8fe820-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4c90b8e0-6c43-013d-931d-0800270c66d6" xmi:uuid="4c90b9c0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1571677714811_477195_45405" xmi:uuid="df92b2c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="df8113c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="df811450-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="df923980-7cad-0138-40ff-418b172fba9f" xmi:uuid="df923a00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="791" y="525" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1571677714811_904568_45406" xmi:uuid="dfc45820-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="dfb2f140-7cad-0138-40ff-418b172fba9f" xmi:uuid="dfb2f1c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="dfc3d120-7cad-0138-40ff-418b172fba9f" xmi:uuid="dfc3d190-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="791" y="455" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1571677714811_535877_45407" xmi:uuid="dff63160-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="dfe47ae0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dfe47b60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="dff5b270-7cad-0138-40ff-418b172fba9f" xmi:uuid="dff5b300-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="791" y="490" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="770" y="427" width="281" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677754545_693075_45545" xmi:uuid="dbee0a80-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677756675_931710_45546"/>
      <source xmi:idref="_18_4_1_6b1022a_1571677701058_777826_45325"/>
      <target xmi:idref="_18_4_1_6b1022a_1571677602440_753264_45107"/>
      <waypoint x="770" y="401"/>
      <waypoint x="658" y="401"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677777788_747912_45568" xmi:uuid="dbee1670-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677777779_60972_45563"/>
      <ownedElement xmi:id="dff853a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="dff85420-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677777779_60972_45563"/>
        <text>descAttribute1:String</text>
      </ownedElement>
      <ownedElement xmi:id="dffa3b40-7cad-0138-40ff-418b172fba9f" xmi:uuid="dffa3bc0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677777779_60972_45563"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="434" y="525" width="241" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677930933_477757_45634" xmi:uuid="dbee1dc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677932135_112356_45635"/>
      <source xmi:idref="_18_4_1_6b1022a_1571677714811_535877_45407"/>
      <target xmi:idref="_18_4_1_6b1022a_1571677625779_948643_45186"/>
      <waypoint x="791" y="501"/>
      <waypoint x="574" y="501"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571677939584_106940_45662" xmi:uuid="dbee2520-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571677944456_632140_45663"/>
      <source xmi:idref="_18_4_1_6b1022a_1571677714811_477195_45405"/>
      <target xmi:idref="_18_4_1_6b1022a_1571677777788_747912_45568"/>
      <waypoint x="791" y="536"/>
      <waypoint x="675" y="536"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571678521179_969925_45827" xmi:uuid="dbef1fb0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571678521154_839234_45824"/>
      <ownedElement xmi:id="e009c450-7cad-0138-40ff-418b172fba9f" xmi:uuid="e009c4d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571678521154_839234_45824"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="e00b9360-7cad-0138-40ff-418b172fba9f" xmi:uuid="e00b93b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571678521154_839234_45824"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1574084752064_400560_64805" xmi:uuid="dbee90c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="53189610-6c43-013d-931d-0800270c66d6" xmi:uuid="531896d0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="584" y="648" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="566" y="657" width="15" height="15"/>
      </ownedElement>
      <bounds x="448" y="651" width="126" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571678893231_334459_46058" xmi:uuid="c8ac73d0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571678895350_273585_46059"/>
      <source xmi:idref="_18_4_1_6b1022a_1570569390599_271599_42670"/>
      <target xmi:idref="_18_4_1_6b1022a_1571678728089_790947_45951"/>
      <waypoint x="1134" y="676"/>
      <waypoint x="967" y="676"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571678643782_390104_45876" xmi:uuid="dbef33d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571678643768_3699_45875"/>
      <ownedElement xmi:id="e01db290-7cad-0138-40ff-418b172fba9f" xmi:uuid="e01db310-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571678643768_3699_45875"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e01f7590-7cad-0138-40ff-418b172fba9f" xmi:uuid="e01f75d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571678643768_3699_45875"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="53bf2980-6c43-013d-931d-0800270c66d6" xmi:uuid="53bf2a20-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="53e8b430-6c43-013d-931d-0800270c66d6" xmi:uuid="53e8b4f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1571678728089_790947_45951" xmi:uuid="e051db30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="e0407f00-7cad-0138-40ff-418b172fba9f" xmi:uuid="e0407f80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e0515ec0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e0515f40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="784" y="665" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="770" y="637" width="280" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571678880942_590636_46023" xmi:uuid="dbef3c50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571678885513_850765_46024"/>
      <source xmi:idref="_18_4_1_6b1022a_1571678521179_969925_45827"/>
      <target xmi:idref="_18_4_1_6b1022a_1570640907642_235604_44330"/>
      <waypoint x="448" y="662"/>
      <waypoint x="413" y="662"/>
      <waypoint x="413" y="627"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571678889279_894359_46042" xmi:uuid="dbef4470-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571678890378_745214_46043"/>
      <source xmi:idref="_18_4_1_6b1022a_1571678643782_390104_45876"/>
      <target xmi:idref="_18_4_1_271a0567_1574084752064_400560_64805"/>
      <waypoint x="770" y="665"/>
      <waypoint x="581" y="665"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1444" height="995"/>
    <name>Analysis</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_6b1022a_1570739384851_924062_47720" xmi:uuid="3541ea70-b556-4823-8da0-9270ddfb231a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121202797_964567_13780"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570739388518_412250_47756" xmi:uuid="dc0898c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123021071_164888_38676"/>
      <ownedElement xmi:id="ea33e680-7cad-0138-40ff-418b172fba9f" xmi:uuid="ea33e6f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123021071_164888_38676"/>
        <text>Items:AnalysisModelItemsSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ea359ed0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ea359f20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123021071_164888_38676"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1607082706573_305207_65360" xmi:uuid="d2c4b540-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLShape">
        <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607082471860_88433_65272"/>
        <ownedElement xmi:id="ee566350-6c43-013d-931d-0800270c66d6" xmi:uuid="ee5663f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607082471860_88433_65272"/>
          <bounds x="157" y="84" width="248" height="13"/>
          <text>rrps : requirement_representation_proxy_select [1]</text>
        </ownedElement>
        <bounds x="255" y="109" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="105" width="235" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570878530965_1335_61340" xmi:uuid="dc0af1d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_6b1022a_1570740634030_694655_48011"/>
      <bounds x="448" y="21" width="135" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607082604114_139108_65287" xmi:uuid="bebeacb0-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607082604114_485995_65285"/>
      <ownedElement xmi:id="d2d80590-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="d2d80660-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607082604114_485995_65285"/>
        <text>rpi:Representation_proxy_item</text>
      </ownedElement>
      <ownedElement xmi:id="d2da3590-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="d2da3640-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607082604114_485995_65285"/>
        <text>[1..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ef1f96d0-6c43-013d-931d-0800270c66d6" xmi:uuid="ef1f9760-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ef35b880-6c43-013d-931d-0800270c66d6" xmi:uuid="ef35b920-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1607082691585_884628_65323" xmi:uuid="d30eaaa0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_proxy_item-item"/>
          <ownedElement xmi:id="d2fc9fc0-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="d2fca0e0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_proxy_item-item"/>
            <text>item:requirement_representation_proxy_select</text>
          </ownedElement>
          <ownedElement xmi:id="d30ddaf0-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="d30dddb0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_proxy_item-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="434" y="105" width="300" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="420" y="77" width="321" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607082737659_760458_65401" xmi:uuid="bebeb5e0-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607082738993_381377_65402"/>
      <source xmi:idref="_18_4_1_2b2015d_1607082691585_884628_65323"/>
      <target xmi:idref="_18_4_1_2b2015d_1607082706573_305207_65360"/>
      <waypoint x="434" y="116"/>
      <waypoint x="270" y="116"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607082990753_102079_66020" xmi:uuid="bf0e3670-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
      <ownedElement xmi:id="d322a850-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="d322a910-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
        <text>analMod:Analysis_model</text>
      </ownedElement>
      <ownedElement xmi:id="d3268a80-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="d3268b70-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="f1b0fb90-6c43-013d-931d-0800270c66d6" xmi:uuid="f1b0fc30-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f1b1a910-6c43-013d-931d-0800270c66d6" xmi:uuid="f1b1aab0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1607083018644_361508_66057" xmi:uuid="d35e5230-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation-items"/>
          <ownedElement xmi:id="d34d4ca0-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="d34d4d40-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation-items"/>
            <text>items:Representation_item</text>
          </ownedElement>
          <ownedElement xmi:id="d35d4890-3276-0139-a8ba-34a9fcdfa563" xmi:uuid="d35d4940-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="798" y="105" width="203" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="784" y="77" width="224" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607083038570_879042_66101" xmi:uuid="bf0e3f10-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607083039765_833358_66104"/>
      <source xmi:idref="_18_4_1_2b2015d_1607083018644_361508_66057"/>
      <target xmi:idref="_18_4_1_2b2015d_1607082604114_139108_65287"/>
      <waypoint x="798" y="116"/>
      <waypoint x="741" y="116"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1023" height="155"/>
    <name>AnalysisModel</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446167096_706610_137729" xmi:uuid="3b6d6ec0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121230940_899251_13786"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167115_619857_137761" xmi:uuid="3bf30110-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796664218_745659_55157"/>
      <ownedElement xmi:id="3bf17a50-6c44-013d-931d-0800270c66d6" xmi:uuid="3bf17b30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796664218_745659_55157"/>
        <text>analRepCont:Analysis_representation_context</text>
      </ownedElement>
      <ownedElement xmi:id="3bf2edb0-6c44-013d-931d-0800270c66d6" xmi:uuid="3bf2ee60-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570796664218_745659_55157"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="283" height="90"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167132_904366_137795" xmi:uuid="3bf3b050-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="629" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167152_597766_137816" xmi:uuid="3c287790-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="629" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480563_278292_378695" xmi:uuid="3c288ba0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662626854918_131672_68867"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167132_904366_137795"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167115_619857_137761"/>
      <waypoint x="629" y="62"/>
      <waypoint x="328" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480563_567504_378698" xmi:uuid="3c289340-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662626858694_215710_68887"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167152_597766_137816"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167115_619857_137761"/>
      <waypoint x="629" y="82"/>
      <waypoint x="328" y="82"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="632" height="160"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_6b1022a_1570738312094_266847_47276" xmi:uuid="5160207d-d14b-4a26-9803-9dac570be138" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570789450100_659111_54503" xmi:uuid="dbfb2f10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570789450071_757264_54499"/>
      <bounds x="1557" y="32" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570738320528_609083_47310" xmi:uuid="dbfc1510-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122867578_351750_38662"/>
      <ownedElement xmi:id="e55aa960-7cad-0138-40ff-418b172fba9f" xmi:uuid="e55aa9d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122867578_351750_38662"/>
        <text>AdditionalContexts:ViewContext</text>
      </ownedElement>
      <ownedElement xmi:id="e55c7040-7cad-0138-40ff-418b172fba9f" xmi:uuid="e55c7090-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122867578_351750_38662"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570786244385_80105_51687" xmi:uuid="dbfbcc60-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516290047903_693170_38626"/>
        <ownedElement xmi:id="8ca46420-6c43-013d-931d-0800270c66d6" xmi:uuid="8ca464e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516290047903_693170_38626"/>
          <bounds x="290" y="52" width="269" height="13"/>
          <text>additionalView : Additional_view_definition_context [0..1]</text>
        </ownedElement>
        <bounds x="272" y="61" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="56" width="245" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570738320538_762814_47341" xmi:uuid="dbfcc240-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577511_313503_38631"/>
      <ownedElement xmi:id="e56b8300-7cad-0138-40ff-418b172fba9f" xmi:uuid="e56b83a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577511_313503_38631"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="e56d5af0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e56d5b60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577511_313503_38631"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570787050242_82885_52938" xmi:uuid="dbfc8d00-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="8dd399f0-6c43-013d-931d-0800270c66d6" xmi:uuid="8dd39a80-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="255" y="130" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="237" y="139" width="15" height="15"/>
      </ownedElement>
      <bounds x="35" y="133" width="210" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570738320556_733007_47403" xmi:uuid="dbfcd510-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577510_349500_38630"/>
      <ownedElement xmi:id="e57cbb60-7cad-0138-40ff-418b172fba9f" xmi:uuid="e57cbbd0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577510_349500_38630"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e57e9c90-7cad-0138-40ff-418b172fba9f" xmi:uuid="e57e9ce0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577510_349500_38630"/>
        <text>[0..1]</text>
      </ownedElement>
      <bounds x="35" y="280" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570738320564_570997_47434" xmi:uuid="dbfce2d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577509_691731_38629"/>
      <ownedElement xmi:id="e58d43b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e58d4430-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577509_691731_38629"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e58f3310-7cad-0138-40ff-418b172fba9f" xmi:uuid="e58f3390-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577509_691731_38629"/>
        <text>[0..1]</text>
      </ownedElement>
      <bounds x="28" y="602" width="145" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570738320573_877353_47465" xmi:uuid="dbfd78f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122839684_835310_38658"/>
      <ownedElement xmi:id="e595eef0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e595ef60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122839684_835310_38658"/>
        <text>InitialContext:ViewContext</text>
      </ownedElement>
      <ownedElement xmi:id="e597b720-7cad-0138-40ff-418b172fba9f" xmi:uuid="e597b770-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122839684_835310_38658"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570788456093_323526_53907" xmi:uuid="dbfd4160-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516289943404_493045_38585"/>
        <ownedElement xmi:id="8fe2c370-6c43-013d-931d-0800270c66d6" xmi:uuid="8fe2c420-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_2b2015d_1516289943404_493045_38585"/>
          <bounds x="234" y="521" width="225" height="13"/>
          <text>initialView : Initial_view_definition_context [0..1]</text>
        </ownedElement>
        <bounds x="216" y="530" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="28" y="525" width="196" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570738320581_924675_47496" xmi:uuid="dbfe53c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577512_909891_38632"/>
      <ownedElement xmi:id="e5a72910-7cad-0138-40ff-418b172fba9f" xmi:uuid="e5a729a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577512_909891_38632"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="e5a8f950-7cad-0138-40ff-418b172fba9f" xmi:uuid="e5a8f9b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122577512_909891_38632"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570789275351_266597_54409" xmi:uuid="dbfdea20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="9133dfe0-6c43-013d-931d-0800270c66d6" xmi:uuid="9133e0a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="185" y="751" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="167" y="760" width="15" height="15"/>
      </ownedElement>
      <bounds x="35" y="756" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1618823006598_653816_106226" xmi:uuid="3ac4e990-0d28-013c-5e16-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_6b1022a_1570738645855_167185_47624"/>
      <target xmi:idref="_18_4_1_6b1022a_1571734833126_282079_50594"/>
      <waypoint x="1370" y="137"/>
      <waypoint x="1365" y="175"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570738635756_499692_47589" xmi:uuid="dbfe6e70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570738635733_824260_47588"/>
      <ownedElement xmi:id="e5baf320-7cad-0138-40ff-418b172fba9f" xmi:uuid="e5baf3a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570738635733_824260_47588"/>
        <text>analysisDisDef:Analysis_discipline_definition</text>
      </ownedElement>
      <ownedElement xmi:id="e5bcc990-7cad-0138-40ff-418b172fba9f" xmi:uuid="e5bcc9f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570738635733_824260_47588"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="91f38930-6c43-013d-931d-0800270c66d6" xmi:uuid="91f38a10-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="920cb360-6c43-013d-931d-0800270c66d6" xmi:uuid="920cb430-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570738645855_167185_47624" xmi:uuid="e5ef9490-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_discipline_definition-defined_version"/>
          <ownedElement xmi:id="e5dde2a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e5dde310-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_discipline_definition-defined_version"/>
            <text>defined_version:Analysis_version</text>
          </ownedElement>
          <ownedElement xmi:id="e5ef0db0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e5ef0e50-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_discipline_definition-defined_version"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1260" y="112" width="224" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570786363607_331256_51719" xmi:uuid="e6228a80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_contexts"/>
          <ownedElement xmi:id="e6110db0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e6110e20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_contexts"/>
            <text>additional_contexts:Additional_view_definition_context</text>
          </ownedElement>
          <ownedElement xmi:id="e62203a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e6220420-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_contexts"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1184" y="64" width="354" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570786363608_801787_51750" xmi:uuid="e645e710-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_characterization"/>
          <ownedElement xmi:id="e633e160-7cad-0138-40ff-418b172fba9f" xmi:uuid="e633e1e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_characterization"/>
            <text>additional_characterization:String</text>
          </ownedElement>
          <ownedElement xmi:id="e6455fb0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e6456050-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-additional_characterization"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1183" y="287" width="237" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570786363612_379263_51843" xmi:uuid="e6e26780-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
          <ownedElement xmi:id="e6cc2790-7cad-0138-40ff-418b172fba9f" xmi:uuid="e6cc2800-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
            <text>initial_context:Initial_view_definition_context</text>
          </ownedElement>
          <ownedElement xmi:id="e6e1e7e0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e6e1e870-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-initial_context"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1197" y="532" width="287" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570786363613_969367_51874" xmi:uuid="e708fec0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-id"/>
          <ownedElement xmi:id="e6f65720-7cad-0138-40ff-418b172fba9f" xmi:uuid="e6f657a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="e7087fc0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e70880b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_view_definition-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1197" y="602" width="100" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1571734833126_282079_50594" xmi:uuid="3ac3f940-0d28-013c-5e16-5b8e392dc4e5" xmi:type="umldi:UMLShape">
          <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571734833111_697366_50593"/>
          <ownedElement xmi:id="3ac241e0-0d28-013c-5e16-5b8e392dc4e5" xmi:uuid="3ac24300-0d28-013c-5e16-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
            <text>Rationale</text>
          </ownedElement>
          <ownedElement xmi:id="3ac31cd0-0d28-013c-5e16-5b8e392dc4e5" xmi:uuid="3ac31f30-0d28-013c-5e16-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
            <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571734833111_697366_50593"/>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="255"/>
          </localStyle>
          <bounds x="1218" y="175" width="287" height="63"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1176" y="28" width="369" height="777"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570785218618_105986_51281" xmi:uuid="dc006740-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570785218585_343534_51280"/>
      <ownedElement xmi:id="e76f3050-7cad-0138-40ff-418b172fba9f" xmi:uuid="e76f30e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570785218585_343534_51280"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570785247298_412808_51326" xmi:uuid="dbfedde0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="9e361620-6c43-013d-931d-0800270c66d6" xmi:uuid="9e361900-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="254" y="276" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="308" y="285" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570785247308_446051_51336" xmi:uuid="dbff52c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="9eaa5d40-6c43-013d-931d-0800270c66d6" xmi:uuid="9eaa5dd0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="556" y="282" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="538" y="291" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570785247317_784680_51346" xmi:uuid="dbffc810-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="9f508690-6c43-013d-931d-0800270c66d6" xmi:uuid="9f508730-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="518" y="342" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="538" y="325" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570785247323_517816_51356" xmi:uuid="dc004d80-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="9fde65f0-6c43-013d-931d-0800270c66d6" xmi:uuid="9fde6690-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="380" y="346" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="370" y="328" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="308" y="266" width="245" height="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570785231007_231716_51305" xmi:uuid="dc024c70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570785230989_605052_51304"/>
      <ownedElement xmi:id="e7831840-7cad-0138-40ff-418b172fba9f" xmi:uuid="e78319b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570785230989_605052_51304"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570785252283_893489_51376" xmi:uuid="dc0105c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="a12ba4c0-6c43-013d-931d-0800270c66d6" xmi:uuid="a12ba570-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="226" y="598" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="280" y="607" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570785252291_410140_51386" xmi:uuid="dc0189f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="a1cd51f0-6c43-013d-931d-0800270c66d6" xmi:uuid="a1cd52a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="435" y="595" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="417" y="604" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570785252299_667369_51396" xmi:uuid="dc023290-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="a25a41a0-6c43-013d-931d-0800270c66d6" xmi:uuid="a25a4250-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="337" y="651" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="327" y="633" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="280" y="595" width="152" height="53"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570786181767_971045_51538" xmi:uuid="dc030280-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786181736_494337_51533"/>
      <ownedElement xmi:id="e794d920-7cad-0138-40ff-418b172fba9f" xmi:uuid="e794d9a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786181736_494337_51533"/>
        <text>desc:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="e796ba00-7cad-0138-40ff-418b172fba9f" xmi:uuid="e796ba60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786181736_494337_51533"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570787654196_745507_53388" xmi:uuid="dc02c9b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="a3f93f20-6c43-013d-931d-0800270c66d6" xmi:uuid="a3f93fd0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="601" y="310" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="727" y="333" width="15" height="15"/>
      </ownedElement>
      <bounds x="588" y="329" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570786199899_236414_51583" xmi:uuid="dc03bf90-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786199880_218380_51579"/>
      <ownedElement xmi:id="e7a652b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e7a65330-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786199880_218380_51579"/>
        <text>id:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="e7a828a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e7a828e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786199880_218380_51579"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570788275638_641193_53791" xmi:uuid="dc0380b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="a57c81e0-6c43-013d-931d-0800270c66d6" xmi:uuid="a57c8350-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="602" y="654" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="650" y="684" width="15" height="15"/>
      </ownedElement>
      <bounds x="532" y="679" width="126" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570786209617_504400_51624" xmi:uuid="dc047340-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786209604_26055_51623"/>
      <ownedElement xmi:id="e7b7a9a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e7b7aa30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786209604_26055_51623"/>
        <text>lang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="e7b97ba0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e7b97bf0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786209604_26055_51623"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570788258391_579843_53763" xmi:uuid="dc043720-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="a6cb9e30-6c43-013d-931d-0800270c66d6" xmi:uuid="a6cba960-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="647" y="418" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="629" y="427" width="15" height="15"/>
      </ownedElement>
      <bounds x="497" y="420" width="140" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570786830241_846242_52723" xmi:uuid="dc047f40-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786831480_348390_52724"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786363607_331256_51719"/>
      <target xmi:idref="_18_4_1_6b1022a_1570786244385_80105_51687"/>
      <waypoint x="1184" y="70"/>
      <waypoint x="287" y="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570787140428_195057_53052" xmi:uuid="d0643fb0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787143440_947698_53053"/>
      <source xmi:idref="_18_4_1_6b1022a_1570738635756_499692_47589"/>
      <target xmi:idref="_18_4_1_6b1022a_1570787079435_264867_52964"/>
      <waypoint x="1176" y="144"/>
      <waypoint x="1045" y="144"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570786883650_299237_52741" xmi:uuid="dc048cd0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786883633_135006_52740"/>
      <ownedElement xmi:id="e7cb6c60-7cad-0138-40ff-418b172fba9f" xmi:uuid="e7cb6cd0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786883633_135006_52740"/>
        <text>clasAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e7cd3050-7cad-0138-40ff-418b172fba9f" xmi:uuid="e7cd3090-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786883633_135006_52740"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a75047a0-6c43-013d-931d-0800270c66d6" xmi:uuid="a7504ab0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a7702be0-6c43-013d-931d-0800270c66d6" xmi:uuid="a7702d60-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570787079435_264867_52964" xmi:uuid="e8001c20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="e7eec770-7cad-0138-40ff-418b172fba9f" xmi:uuid="e7eec7f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e7ffa100-7cad-0138-40ff-418b172fba9f" xmi:uuid="e7ffa180-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="133" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="819" y="105" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570788398927_305380_53889" xmi:uuid="d0bd5f60-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570788401158_106690_53890"/>
      <source xmi:idref="_18_4_1_6b1022a_1570738635756_499692_47589"/>
      <target xmi:idref="_18_4_1_6b1022a_1570787715805_422976_53418"/>
      <waypoint x="1176" y="354"/>
      <waypoint x="1001" y="354"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570786908580_6598_52779" xmi:uuid="dc0498c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786908565_176909_52778"/>
      <ownedElement xmi:id="e8127920-7cad-0138-40ff-418b172fba9f" xmi:uuid="e81279b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786908565_176909_52778"/>
        <text>descrpTextAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e8143d70-7cad-0138-40ff-418b172fba9f" xmi:uuid="e8143dc0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786908565_176909_52778"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="aa404c70-6c43-013d-931d-0800270c66d6" xmi:uuid="aa404d20-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="aa700290-6c43-013d-931d-0800270c66d6" xmi:uuid="aa700370-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570787715805_422976_53418" xmi:uuid="e8473dc0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="e835daf0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e835db90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="e846c0e0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e846c180-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="826" y="343" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="812" y="315" width="315" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570876072491_882605_60895" xmi:uuid="d10eeec0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570876073631_101300_60896"/>
      <source xmi:idref="_18_4_1_6b1022a_1570738635756_499692_47589"/>
      <target xmi:idref="_18_4_1_6b1022a_1570876056988_474343_60851"/>
      <waypoint x="1176" y="774"/>
      <waypoint x="1049" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570786937211_992889_52817" xmi:uuid="dc04a530-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786937197_984320_52816"/>
      <ownedElement xmi:id="e859ba20-7cad-0138-40ff-418b172fba9f" xmi:uuid="e859ba90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786937197_984320_52816"/>
        <text>extItemIdent:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="e85b84f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e85b8540-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786937197_984320_52816"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ad1e7190-6c43-013d-931d-0800270c66d6" xmi:uuid="ad1e7230-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ad1f1c30-6c43-013d-931d-0800270c66d6" xmi:uuid="ad1f1cb0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570876056988_474343_60851" xmi:uuid="e8b15c70-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="e89fcd80-7cad-0138-40ff-418b172fba9f" xmi:uuid="e89fce00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e8b0dec0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e8b0e020-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="826" y="763" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="812" y="735" width="271" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570788761912_284723_54260" xmi:uuid="d159aaa0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570788764846_546933_54261"/>
      <source xmi:idref="_18_4_1_6b1022a_1570738635756_499692_47589"/>
      <target xmi:idref="_18_4_1_6b1022a_1570788725289_958140_54180"/>
      <waypoint x="1176" y="683"/>
      <waypoint x="1009" y="683"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570786991409_15926_52857" xmi:uuid="dc04b0b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786991394_360998_52856"/>
      <ownedElement xmi:id="e8c37f40-7cad-0138-40ff-418b172fba9f" xmi:uuid="e8c37fc0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786991394_360998_52856"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e8c55b00-7cad-0138-40ff-418b172fba9f" xmi:uuid="e8c55b60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570786991394_360998_52856"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="afa7b070-6c43-013d-931d-0800270c66d6" xmi:uuid="afa7b200-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="afa86d40-6c43-013d-931d-0800270c66d6" xmi:uuid="afa86e30-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570788725289_958140_54180" xmi:uuid="e8f850b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="e8e6d370-7cad-0138-40ff-418b172fba9f" xmi:uuid="e8e6d3f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e8f7d500-7cad-0138-40ff-418b172fba9f" xmi:uuid="e8f7d620-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="826" y="672" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="812" y="644" width="301" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570788306807_429172_53846" xmi:uuid="d2060e80-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570788310215_207233_53847"/>
      <source xmi:idref="_18_4_1_6b1022a_1570738635756_499692_47589"/>
      <target xmi:idref="_18_4_1_6b1022a_1570787934528_795745_53579"/>
      <waypoint x="1176" y="466"/>
      <waypoint x="1054" y="466"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570787020234_59413_52897" xmi:uuid="dc04bd90-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787020220_89745_52896"/>
      <ownedElement xmi:id="e90b33b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e90b3430-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787020220_89745_52896"/>
        <text>langIndic:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="e90d0530-7cad-0138-40ff-418b172fba9f" xmi:uuid="e90d0590-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787020220_89745_52896"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b22468e0-6c43-013d-931d-0800270c66d6" xmi:uuid="b22469a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b23c1e30-6c43-013d-931d-0800270c66d6" xmi:uuid="b23c1f00-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570787934526_170817_53548" xmi:uuid="e9309150-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="e91f2d50-7cad-0138-40ff-418b172fba9f" xmi:uuid="e91f2dd0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="e9301370-7cad-0138-40ff-418b172fba9f" xmi:uuid="e93013e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="819" y="490" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570787934528_795745_53579" xmi:uuid="e96294d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="e950e290-7cad-0138-40ff-418b172fba9f" xmi:uuid="e950e310-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="e96214c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e9621550-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="826" y="455" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570787934529_209031_53610" xmi:uuid="e9947ed0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="e9831d60-7cad-0138-40ff-418b172fba9f" xmi:uuid="e9831de0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="e9940180-7cad-0138-40ff-418b172fba9f" xmi:uuid="e99401f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="826" y="420" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="812" y="392" width="315" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570787095510_747437_53006" xmi:uuid="dc04c570-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787096944_868349_53007"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786883650_299237_52741"/>
      <target xmi:idref="_18_4_1_6b1022a_1570787050242_82885_52938"/>
      <waypoint x="819" y="147"/>
      <waypoint x="252" y="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571680986990_559203_49280" xmi:uuid="d29114b0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571680988997_459800_49302"/>
      <source xmi:idref="_18_4_1_6b1022a_1570738635756_499692_47589"/>
      <target xmi:idref="_18_4_1_6b1022a_1570787250106_898432_53166"/>
      <waypoint x="1176" y="249"/>
      <waypoint x="1052" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570787196218_822444_53065" xmi:uuid="dc04d200-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787196203_725234_53064"/>
      <ownedElement xmi:id="e9a6fef0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e9a6ff70-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787196203_725234_53064"/>
        <text>propDefRep:Property_definition_representation</text>
      </ownedElement>
      <ownedElement xmi:id="e9a8caa0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e9a8cb80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787196203_725234_53064"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b7d309b0-6c43-013d-931d-0800270c66d6" xmi:uuid="b7d30a80-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b7f3d5c0-6c43-013d-931d-0800270c66d6" xmi:uuid="b7f3d6a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570787250106_898432_53166" xmi:uuid="e9e66450-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-definition"/>
          <ownedElement xmi:id="e9d0b070-7cad-0138-40ff-418b172fba9f" xmi:uuid="e9d0b0f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-definition"/>
            <text>definition:represented_definition</text>
          </ownedElement>
          <ownedElement xmi:id="e9e5ba90-7cad-0138-40ff-418b172fba9f" xmi:uuid="e9e5bb10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="833" y="238" width="219" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570787250116_118109_53197" xmi:uuid="ea24e2f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-used_representation"/>
          <ownedElement xmi:id="ea0ea340-7cad-0138-40ff-418b172fba9f" xmi:uuid="ea0ea3c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-used_representation"/>
            <text>used_representation:Representation</text>
          </ownedElement>
          <ownedElement xmi:id="ea2423a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ea242430-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-used_representation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="840" y="203" width="241" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="819" y="175" width="309" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570738320547_838538_47372" xmi:uuid="dc0574a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122811959_523127_38654"/>
      <ownedElement xmi:id="ea283e60-7cad-0138-40ff-418b172fba9f" xmi:uuid="ea283ee0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122811959_523127_38654"/>
        <text>DefinitionalRepresentations:AnalysisModelObject</text>
      </ownedElement>
      <ownedElement xmi:id="ea2a0720-7cad-0138-40ff-418b172fba9f" xmi:uuid="ea2a0770-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122811959_523127_38654"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570787353856_453261_53261" xmi:uuid="dc053bb0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570743691846_709103_50799"/>
        <ownedElement xmi:id="e6c83100-6c43-013d-931d-0800270c66d6" xmi:uuid="e6c83300-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570743691846_709103_50799"/>
          <bounds x="381" y="191" width="202" height="13"/>
          <text>analysisModelObject : Analysis_model [1]</text>
        </ownedElement>
        <bounds x="363" y="200" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="196" width="336" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570787370792_175524_53288" xmi:uuid="dc0583b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787376096_366152_53289"/>
      <source xmi:idref="_18_4_1_6b1022a_1570787250116_118109_53197"/>
      <target xmi:idref="_18_4_1_6b1022a_1570787353856_453261_53261"/>
      <waypoint x="840" y="210"/>
      <waypoint x="378" y="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570787427182_416870_53322" xmi:uuid="dc058c20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787428976_971670_53323"/>
      <source xmi:idref="_18_4_1_6b1022a_1570785247298_412808_51326"/>
      <target xmi:idref="_18_4_1_6b1022a_1570738320556_733007_47403"/>
      <waypoint x="308" y="291"/>
      <waypoint x="241" y="291"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570787534975_118139_53351" xmi:uuid="dc059590-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787536250_808572_53352"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786363608_801787_51750"/>
      <target xmi:idref="_18_4_1_6b1022a_1570785247308_446051_51336"/>
      <waypoint x="1183" y="298"/>
      <waypoint x="553" y="298"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570787779272_839579_53468" xmi:uuid="dc059e20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787780366_292589_53469"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786181767_971045_51538"/>
      <target xmi:idref="_18_4_1_6b1022a_1570785247317_784680_51346"/>
      <waypoint x="588" y="333"/>
      <waypoint x="553" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570787789662_519181_53493" xmi:uuid="dc05a5f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570787791031_727491_53494"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786908580_6598_52779"/>
      <target xmi:idref="_18_4_1_6b1022a_1570787654196_745507_53388"/>
      <waypoint x="812" y="340"/>
      <waypoint x="742" y="340"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570788216696_871223_53728" xmi:uuid="dc05ae10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570788218032_146888_53729"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786209617_504400_51624"/>
      <target xmi:idref="_18_4_1_6b1022a_1570785247323_517816_51356"/>
      <waypoint x="497" y="431"/>
      <waypoint x="378" y="431"/>
      <waypoint x="378" y="343"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570788297367_873058_53818" xmi:uuid="dc05b590-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570788299376_638851_53819"/>
      <source xmi:idref="_18_4_1_6b1022a_1570787934529_209031_53610"/>
      <target xmi:idref="_18_4_1_6b1022a_1570788258391_579843_53763"/>
      <waypoint x="826" y="434"/>
      <waypoint x="644" y="434"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570788506389_725807_53956" xmi:uuid="dc05be20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570788509967_918635_53957"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786363612_379263_51843"/>
      <target xmi:idref="_18_4_1_6b1022a_1570788456093_323526_53907"/>
      <waypoint x="1197" y="536"/>
      <waypoint x="231" y="536"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570788585479_361242_54019" xmi:uuid="dc05c590-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570788587511_390315_54020"/>
      <source xmi:idref="_18_4_1_6b1022a_1570785252283_893489_51376"/>
      <target xmi:idref="_18_4_1_6b1022a_1570738320564_570997_47434"/>
      <waypoint x="280" y="616"/>
      <waypoint x="173" y="616"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570788617097_287552_54046" xmi:uuid="dc05cd20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570788620766_562375_54047"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786363613_969367_51874"/>
      <target xmi:idref="_18_4_1_6b1022a_1570785252291_410140_51386"/>
      <waypoint x="1197" y="613"/>
      <waypoint x="432" y="613"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570788744272_496013_54222" xmi:uuid="dc05d5e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570788747630_799906_54223"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786199899_236414_51583"/>
      <target xmi:idref="_18_4_1_6b1022a_1570785252299_667369_51396"/>
      <waypoint x="532" y="690"/>
      <waypoint x="333" y="690"/>
      <waypoint x="333" y="648"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570788753439_239398_54241" xmi:uuid="dc05dd50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570788754686_172821_54242"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786991409_15926_52857"/>
      <target xmi:idref="_18_4_1_6b1022a_1570788275638_641193_53791"/>
      <waypoint x="812" y="690"/>
      <waypoint x="665" y="690"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570789295277_867250_54448" xmi:uuid="dc05e690-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570789297383_494274_54449"/>
      <source xmi:idref="_18_4_1_6b1022a_1570786937211_992889_52817"/>
      <target xmi:idref="_18_4_1_6b1022a_1570789275351_266597_54409"/>
      <waypoint x="812" y="767"/>
      <waypoint x="182" y="767"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570789562878_164983_54534" xmi:uuid="dc05f730-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570789564806_296572_54535"/>
      <source xmi:idref="_18_4_1_6b1022a_1570789450100_659111_54503"/>
      <target xmi:idref="_18_4_1_6b1022a_1570738635756_499692_47589"/>
      <waypoint x="1557" y="39"/>
      <waypoint x="1545" y="39"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571681131019_412024_49370" xmi:uuid="dc060570-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571681131004_524815_49365"/>
      <ownedElement xmi:id="ea2cf1d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ea2cf250-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571681131004_524815_49365"/>
        <text>descAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="ea2ec790-7cad-0138-40ff-418b172fba9f" xmi:uuid="ea2ec800-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571681131004_524815_49365"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="441" y="490" width="319" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571681165137_592627_49412" xmi:uuid="dc061140-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571681166621_865534_49413"/>
      <source xmi:idref="_18_4_1_6b1022a_1570787934526_170817_53548"/>
      <target xmi:idref="_18_4_1_6b1022a_1571681131019_412024_49370"/>
      <waypoint x="819" y="501"/>
      <waypoint x="760" y="501"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1560" height="820"/>
    <name>AnalysisDisciplineDefinition</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446167163_579510_137834" xmi:uuid="556d7040-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167180_339600_137866" xmi:uuid="563abc90-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570569390588_371651_42669"/>
      <ownedElement xmi:id="56283ce0-6c43-013d-931d-0800270c66d6" xmi:uuid="56283dc0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570569390588_371651_42669"/>
        <text>analysis:Analysis</text>
      </ownedElement>
      <ownedElement xmi:id="56392f70-6c43-013d-931d-0800270c66d6" xmi:uuid="56393040-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570569390588_371651_42669"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="128" height="350"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167192_517747_137900" xmi:uuid="563b9620-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="482" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167206_591424_137921" xmi:uuid="564d6e30-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="482" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167220_823025_137942" xmi:uuid="564e1e90-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="482" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167235_861956_137963" xmi:uuid="565fa7b0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="482" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167254_13870_137984" xmi:uuid="56605ce0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="482" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167273_878074_138005" xmi:uuid="568406a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="482" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167292_818046_138026" xmi:uuid="5684c110-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="482" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167307_408397_138047" xmi:uuid="5692d000-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="482" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167324_297580_138068" xmi:uuid="56939e10-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="482" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167348_639956_138089" xmi:uuid="56945260-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="482" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167370_357431_138110" xmi:uuid="56abf7f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="482" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167392_235787_138131" xmi:uuid="56acbdb0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="482" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167410_621164_138152" xmi:uuid="56ca8e00-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="482" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167424_411518_138173" xmi:uuid="56cb4830-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="482" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167439_175583_138194" xmi:uuid="56dfe060-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="482" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_38757_378713" xmi:uuid="56dff150-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035051647_748296_67263"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167192_517747_137900"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="62"/>
      <waypoint x="173" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_223388_378716" xmi:uuid="56dff850-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608714603557_825038_68696"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167206_591424_137921"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="82"/>
      <waypoint x="173" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_172499_378719" xmi:uuid="56dffe00-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608714610576_626467_68718"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167220_823025_137942"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="102"/>
      <waypoint x="173" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_353565_378722" xmi:uuid="56e004f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608714625427_800770_68806"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167235_861956_137963"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="122"/>
      <waypoint x="173" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_655429_378725" xmi:uuid="56e00b10-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608714621712_757672_68784"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167254_13870_137984"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="142"/>
      <waypoint x="173" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_864819_378728" xmi:uuid="56e01220-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487180854_649140_65597"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167273_878074_138005"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="162"/>
      <waypoint x="173" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_390454_378731" xmi:uuid="56e01840-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487189222_255209_65629"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167292_818046_138026"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="182"/>
      <waypoint x="173" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_591332_378734" xmi:uuid="56e05b80-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608714617956_819222_68762"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167307_408397_138047"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="202"/>
      <waypoint x="173" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_745558_378737" xmi:uuid="56e06370-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608714614501_967286_68740"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167324_297580_138068"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="222"/>
      <waypoint x="173" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_826911_378740" xmi:uuid="56e06930-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035057870_808805_67283"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167348_639956_138089"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="242"/>
      <waypoint x="173" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_927132_378743" xmi:uuid="56e06fd0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035061845_482034_67303"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167370_357431_138110"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="262"/>
      <waypoint x="173" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_673530_378746" xmi:uuid="56e075e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487184687_578132_65613"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167392_235787_138131"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="282"/>
      <waypoint x="173" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_771715_378749" xmi:uuid="56e07ca0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035066003_741927_67323"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167410_621164_138152"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="302"/>
      <waypoint x="173" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_124693_378752" xmi:uuid="56e082b0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035070488_876605_67343"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167424_411518_138173"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="322"/>
      <waypoint x="173" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480569_61222_378755" xmi:uuid="56e08940-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487193194_577568_65645"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167439_175583_138194"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167180_339600_137866"/>
      <waypoint x="482" y="342"/>
      <waypoint x="173" y="342"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="485" height="420"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_6b1022a_1570880045273_125307_62016" xmi:uuid="6fd17bd9-51d0-4310-8a11-6e968c85bbec" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121257177_404073_13792"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570882666145_973501_64494" xmi:uuid="dc3c1bb0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570882666090_822699_64490"/>
      <bounds x="636" y="83" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570880067772_431720_62129" xmi:uuid="dc3c55f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_6b1022a_1570740634030_694655_48011"/>
      <bounds x="308" y="21" width="135" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570880052292_997649_62050" xmi:uuid="dc3cf3e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123332831_450503_38790"/>
      <ownedElement xmi:id="f9c16750-7cad-0138-40ff-418b172fba9f" xmi:uuid="f9c16810-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123332831_450503_38790"/>
        <text>ExternalFile:DigitalFile</text>
      </ownedElement>
      <ownedElement xmi:id="f9c450f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f9c451c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123332831_450503_38790"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570882286632_51961_64296" xmi:uuid="dc3cbbb0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525877884568_333414_40328"/>
        <ownedElement xmi:id="bfa3c840-6c44-013d-931d-0800270c66d6" xmi:uuid="bfa3c8f0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525877884568_333414_40328"/>
          <bounds x="214" y="108" width="86" height="13"/>
          <text>file : Digital_file [1]</text>
        </ownedElement>
        <bounds x="196" y="117" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="112" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571753883672_57054_48479" xmi:uuid="dc3d0370-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571753902960_295276_48510"/>
      <ownedElement xmi:id="f9d68810-7cad-0138-40ff-418b172fba9f" xmi:uuid="f9d68890-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571753902960_295276_48510"/>
        <text>analMod:External_analysis_model</text>
      </ownedElement>
      <ownedElement xmi:id="f9d85690-7cad-0138-40ff-418b172fba9f" xmi:uuid="f9d856e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571753902960_295276_48510"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="c08c90d0-6c44-013d-931d-0800270c66d6" xmi:uuid="c08c9180-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c08d4fa0-6c44-013d-931d-0800270c66d6" xmi:uuid="c08d5070-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1571753951308_150554_48523" xmi:uuid="fa0ae6f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_analysis_model-external_file"/>
          <ownedElement xmi:id="f9f98a50-7cad-0138-40ff-418b172fba9f" xmi:uuid="f9f98ac0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_analysis_model-external_file"/>
            <text>external_file:Digital_file</text>
          </ownedElement>
          <ownedElement xmi:id="fa0a6210-7cad-0138-40ff-418b172fba9f" xmi:uuid="fa0a6290-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_analysis_model-external_file"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="399" y="112" width="163" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="385" y="84" width="221" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571754077196_382898_48872" xmi:uuid="dc3d0b90-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571754078624_783732_48873"/>
      <source xmi:idref="_18_4_1_6b1022a_1571753951308_150554_48523"/>
      <target xmi:idref="_18_4_1_6b1022a_1570882286632_51961_64296"/>
      <waypoint x="399" y="126"/>
      <waypoint x="211" y="126"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571754280343_800082_48918" xmi:uuid="dc3d15c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571754281808_513921_48919"/>
      <source xmi:idref="_18_4_1_6b1022a_1570882666145_973501_64494"/>
      <target xmi:idref="_18_4_1_6b1022a_1571753883672_57054_48479"/>
      <waypoint x="636" y="91"/>
      <waypoint x="606" y="91"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="639" height="162"/>
    <name>ExternalAnalysisModel</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446166830_86654_137351" xmi:uuid="7302e240-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166851_927440_137383" xmi:uuid="74893a90-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570890967663_246162_65214"/>
      <ownedElement xmi:id="7487cc90-6c44-013d-931d-0800270c66d6" xmi:uuid="7487cde0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570890967663_246162_65214"/>
        <text>analVer:Analysis_version</text>
      </ownedElement>
      <ownedElement xmi:id="74892870-6c44-013d-931d-0800270c66d6" xmi:uuid="74892930-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570890967663_246162_65214"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="169" height="350"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166863_528316_137417" xmi:uuid="748af5a0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="552" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166877_640795_137438" xmi:uuid="748bacb0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582618469075_658775_57904"/>
      <bounds x="552" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166891_184680_137459" xmi:uuid="748c5c50-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582547061181_163327_74059"/>
      <bounds x="552" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166904_198596_137480" xmi:uuid="754f2310-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582016208472_742447_67749"/>
      <bounds x="552" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166921_731363_137501" xmi:uuid="75a92450-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="552" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166939_564878_137522" xmi:uuid="761223c0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="552" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166957_186760_137543" xmi:uuid="767a4a60-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="552" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166972_159987_137564" xmi:uuid="76942bf0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="552" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166987_317329_137585" xmi:uuid="76dcd130-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="552" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167006_233913_137606" xmi:uuid="7736dd60-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="552" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167025_666497_137627" xmi:uuid="774fe1a0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="552" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167043_108977_137648" xmi:uuid="7778e400-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="552" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167057_251600_137669" xmi:uuid="77b2e510-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="552" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167070_586506_137690" xmi:uuid="78198d60-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="552" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167085_459318_137711" xmi:uuid="7836cce0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="552" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480523_980215_378560" xmi:uuid="78754750-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035412628_23003_67786"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166863_528316_137417"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="62"/>
      <waypoint x="214" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480523_657302_378563" xmi:uuid="787552b0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608715732365_189405_74097"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166877_640795_137438"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="82"/>
      <waypoint x="214" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480523_56070_378566" xmi:uuid="7875ba10-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608715735839_905443_74119"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166891_184680_137459"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="102"/>
      <waypoint x="214" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480523_270041_378569" xmi:uuid="78775e90-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608715750650_987238_74207"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166904_198596_137480"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="122"/>
      <waypoint x="214" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480523_328261_378572" xmi:uuid="78777630-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608715746786_384835_74185"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166921_731363_137501"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="142"/>
      <waypoint x="214" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480523_368763_378575" xmi:uuid="78777e10-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606496974951_55897_70373"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166939_564878_137522"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="162"/>
      <waypoint x="214" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480523_484135_378578" xmi:uuid="7877ae10-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606496983008_794200_70417"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166957_186760_137543"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="182"/>
      <waypoint x="214" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480523_97894_378581" xmi:uuid="7877c150-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608715743191_821449_74163"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166972_159987_137564"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="202"/>
      <waypoint x="214" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480523_12841_378584" xmi:uuid="7877c900-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608715739240_729304_74141"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166987_317329_137585"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="222"/>
      <waypoint x="214" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480524_789098_378587" xmi:uuid="7877ce30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035417185_304577_67806"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167006_233913_137606"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="242"/>
      <waypoint x="214" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480524_350362_378590" xmi:uuid="7877d3c0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035420934_104616_67826"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167025_666497_137627"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="262"/>
      <waypoint x="214" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480524_846752_378593" xmi:uuid="78780230-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606496978978_779293_70395"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167043_108977_137648"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="282"/>
      <waypoint x="214" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480524_497849_378596" xmi:uuid="78780b70-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035424820_613049_67846"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167057_251600_137669"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="302"/>
      <waypoint x="214" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480524_855636_378599" xmi:uuid="78781af0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035428426_101672_67866"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167070_586506_137690"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="322"/>
      <waypoint x="214" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480524_148832_378602" xmi:uuid="78782260-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606496986978_669426_70439"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167085_459318_137711"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166851_927440_137383"/>
      <waypoint x="552" y="342"/>
      <waypoint x="214" y="342"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="555" height="420"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446166410_365677_136784" xmi:uuid="89e68f20-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121169584_987103_13774"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166432_7079_136816" xmi:uuid="8acfd820-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570726720319_878378_43649"/>
      <ownedElement xmi:id="8abbd170-6c43-013d-931d-0800270c66d6" xmi:uuid="8abbd250-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570726720319_878378_43649"/>
        <text>analysisAsng:Analysis_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="8acfc210-6c43-013d-931d-0800270c66d6" xmi:uuid="8acfc2e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570726720319_878378_43649"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="224" height="310"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166448_24891_136850" xmi:uuid="8ad09100-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="559" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166467_339265_136871" xmi:uuid="8af60680-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="559" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166484_669667_136892" xmi:uuid="8af6b7e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="559" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166501_430561_136913" xmi:uuid="8b10b060-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="559" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166519_440374_136934" xmi:uuid="8b11d8f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="559" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166536_415813_136955" xmi:uuid="8b3bbe30-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="559" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166549_483721_136976" xmi:uuid="8b3c82a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="559" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166562_71717_136997" xmi:uuid="8b4ae570-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="559" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166582_17912_137018" xmi:uuid="8b4ba090-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="559" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166601_700584_137039" xmi:uuid="8b4c5280-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="559" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166616_799831_137060" xmi:uuid="8b627fe0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="559" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166633_773411_137081" xmi:uuid="8b7d8a60-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="559" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166649_730504_137102" xmi:uuid="8b7e41a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="559" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_425143_378371" xmi:uuid="8b7e5070-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487691244_699528_66725"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166448_24891_136850"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="62"/>
      <waypoint x="269" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_412746_378374" xmi:uuid="8b7e58d0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487683803_832361_66681"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166467_339265_136871"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="82"/>
      <waypoint x="269" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_634403_378377" xmi:uuid="8b7e5f80-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608714737529_564553_69617"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166484_669667_136892"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="102"/>
      <waypoint x="269" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_20369_378380" xmi:uuid="8b7e6570-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487679650_399281_66659"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166501_430561_136913"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="122"/>
      <waypoint x="269" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_921378_378383" xmi:uuid="8b7e6c60-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487675878_594176_66637"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166519_440374_136934"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="142"/>
      <waypoint x="269" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_245050_378386" xmi:uuid="8b7e8ae0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487694905_802656_66747"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166536_415813_136955"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="162"/>
      <waypoint x="269" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_917062_378389" xmi:uuid="8b7e9550-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608714732854_720639_69595"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166549_483721_136976"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="182"/>
      <waypoint x="269" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_428596_378392" xmi:uuid="8b7e9c10-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1608714729561_354403_69573"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166562_71717_136997"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="202"/>
      <waypoint x="269" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_509824_378395" xmi:uuid="8b7ea1f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662626375034_898174_67950"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166582_17912_137018"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="222"/>
      <waypoint x="269" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_81458_378398" xmi:uuid="8b7ea7f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662626378328_661272_67970"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166601_700584_137039"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="242"/>
      <waypoint x="269" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_244091_378401" xmi:uuid="8b7eaf90-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662626385727_387844_68010"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166616_799831_137060"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="262"/>
      <waypoint x="269" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480470_368443_378404" xmi:uuid="8b8e1040-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487687540_111217_66703"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166633_773411_137081"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="282"/>
      <waypoint x="269" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480471_136726_378407" xmi:uuid="8b8e18d0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606487699224_645906_66769"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166649_730504_137102"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166432_7079_136816"/>
      <waypoint x="559" y="302"/>
      <waypoint x="269" y="302"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="562" height="380"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_6b1022a_1570728737157_287875_44997" xmi:uuid="8b1a0541-0548-42c9-b05f-9f9e70ac24ac" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570728775145_288337_45218" xmi:uuid="dc28c130-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727531350_445591_44578"/>
      <bounds x="1280" y="68" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570728775099_134_45031" xmi:uuid="dc29c2f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205084_450904_38736"/>
      <ownedElement xmi:id="f2a04410-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2a04490-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205084_450904_38736"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="f2a21370-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2a21460-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205084_450904_38736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570892853242_278761_66784" xmi:uuid="dc292b10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="3d97a160-6c44-013d-931d-0800270c66d6" xmi:uuid="3d97a240-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="255" y="568" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="237" y="577" width="15" height="15"/>
      </ownedElement>
      <bounds x="35" y="574" width="210" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570728775109_479135_45062" xmi:uuid="dc29d9a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205083_888764_38735"/>
      <ownedElement xmi:id="f2b18c40-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2b18cb0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205083_888764_38735"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="f2b37f30-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2b37f80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205083_888764_38735"/>
        <text>[0..1]</text>
      </ownedElement>
      <bounds x="28" y="98" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570728775114_174906_45093" xmi:uuid="dc29e460-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205081_515686_38734"/>
      <ownedElement xmi:id="f2c28d70-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2c28df0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205081_515686_38734"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="f2c45e30-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2c45e80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205081_515686_38734"/>
        <text>[0..1]</text>
      </ownedElement>
      <bounds x="35" y="420" width="145" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570728775122_477695_45124" xmi:uuid="dc2a9480-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205084_428717_38737"/>
      <ownedElement xmi:id="f2d360e0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2d36160-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205084_428717_38737"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="f2d55160-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2d551e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123205084_428717_38737"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570893011071_809076_66983" xmi:uuid="dc2a5190-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="3ff2c210-6c44-013d-931d-0800270c66d6" xmi:uuid="3ff2c2b0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="192" y="645" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="174" y="654" width="15" height="15"/>
      </ownedElement>
      <bounds x="42" y="651" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570728775141_400986_45187" xmi:uuid="dc2b40e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123225655_322108_38762"/>
      <ownedElement xmi:id="f2d8c580-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2d8c5f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123225655_322108_38762"/>
        <text>Views:AnalysisDisciplineDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="f2da7100-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2da7140-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123225655_322108_38762"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570893144198_296334_67044" xmi:uuid="dc2b04d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570789450071_757264_54499"/>
        <ownedElement xmi:id="40425800-6c44-013d-931d-0800270c66d6" xmi:uuid="40425a40-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570789450071_757264_54499"/>
          <bounds x="304" y="722" width="229" height="13"/>
          <text>analysDisDef : Analysis_discipline_definition [1]</text>
        </ownedElement>
        <bounds x="286" y="731" width="15" height="15"/>
      </ownedElement>
      <bounds x="42" y="728" width="252" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1608715605032_66722_73861" xmi:uuid="4529e820-0d28-013c-5e16-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_6b1022a_1570890982740_631725_65313"/>
      <target xmi:idref="_18_4_1_6b1022a_1571733503116_421239_50532"/>
      <waypoint x="1108" y="277"/>
      <waypoint x="1114" y="308"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570890967699_713848_65215" xmi:uuid="dc2b5570-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570890967663_246162_65214"/>
      <ownedElement xmi:id="f2ec29b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2ec2a20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570890967663_246162_65214"/>
        <text>analVer:Analysis_version</text>
      </ownedElement>
      <ownedElement xmi:id="f2ee03c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2ee0410-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570890967663_246162_65214"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="40f95ac0-6c44-013d-931d-0800270c66d6" xmi:uuid="40f95cc0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="410f81f0-6c44-013d-931d-0800270c66d6" xmi:uuid="410f82e0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570890982737_980051_65251" xmi:uuid="f310b440-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-description"/>
          <ownedElement xmi:id="f2ff99b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f2ff9a30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="f31039a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f3103a20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="999" y="113" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570890982739_446535_65282" xmi:uuid="f3328b90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-id"/>
          <ownedElement xmi:id="f3213fe0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f3214060-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="f331fca0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f331fd20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="998" y="420" width="88" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570890982740_631725_65313" xmi:uuid="f3642600-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version-of_product"/>
          <ownedElement xmi:id="f352fd70-7cad-0138-40ff-418b172fba9f" xmi:uuid="f352fdf0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version-of_product"/>
            <text>of_product:Analysis</text>
          </ownedElement>
          <ownedElement xmi:id="f363a810-7cad-0138-40ff-418b172fba9f" xmi:uuid="f363a8f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version-of_product"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1033" y="252" width="146" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1571733503116_421239_50532" xmi:uuid="45291e80-0d28-013c-5e16-5b8e392dc4e5" xmi:type="umldi:UMLShape">
          <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571733503085_151174_50531"/>
          <ownedElement xmi:id="45276fd0-0d28-013c-5e16-5b8e392dc4e5" xmi:uuid="45277600-0d28-013c-5e16-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
            <text>Rationale</text>
          </ownedElement>
          <ownedElement xmi:id="452869b0-0d28-013c-5e16-5b8e392dc4e5" xmi:uuid="45286ae0-0d28-013c-5e16-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
            <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571733503085_151174_50531"/>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="255"/>
          </localStyle>
          <bounds x="1008" y="308" width="224" height="63"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="987" y="70" width="264" height="700"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891008229_114460_65392" xmi:uuid="dc2b6000-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891009462_157717_65393"/>
      <source xmi:idref="_18_4_1_6b1022a_1570728775145_288337_45218"/>
      <target xmi:idref="_18_4_1_6b1022a_1570890967699_713848_65215"/>
      <waypoint x="1280" y="74"/>
      <waypoint x="1251" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891219116_95410_65420" xmi:uuid="dc2d7870-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891219087_583596_65419"/>
      <ownedElement xmi:id="f3751560-7cad-0138-40ff-418b172fba9f" xmi:uuid="f37516c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891219087_583596_65419"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570891243385_947531_65446" xmi:uuid="dc2bd930-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="45fbeb20-6c44-013d-931d-0800270c66d6" xmi:uuid="45fbebd0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="247" y="101" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="301" y="110" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570891243394_347294_65456" xmi:uuid="dc2c5f10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="46ad2360-6c44-013d-931d-0800270c66d6" xmi:uuid="46ad2400-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="549" y="104" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="531" y="113" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570891243403_146933_65466" xmi:uuid="dc2ce530-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="472be6e0-6c44-013d-931d-0800270c66d6" xmi:uuid="472be780-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="445" y="164" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="435" y="146" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570891243410_624825_65476" xmi:uuid="dc2d5ec0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="47cd70f0-6c44-013d-931d-0800270c66d6" xmi:uuid="47cd71a0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="340" y="164" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="330" y="146" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="98" width="245" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891273018_205624_65513" xmi:uuid="dc2d8490-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891274326_257557_65514"/>
      <source xmi:idref="_18_4_1_6b1022a_1570891243385_947531_65446"/>
      <target xmi:idref="_18_4_1_6b1022a_1570728775109_479135_45062"/>
      <waypoint x="301" y="116"/>
      <waypoint x="234" y="116"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891293045_406913_65536" xmi:uuid="dc2d8cc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891294469_941119_65537"/>
      <source xmi:idref="_18_4_1_6b1022a_1570890982737_980051_65251"/>
      <target xmi:idref="_18_4_1_6b1022a_1570891243394_347294_65456"/>
      <waypoint x="999" y="119"/>
      <waypoint x="546" y="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891327095_103928_65558" xmi:uuid="dc2e4a50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891327057_604847_65553"/>
      <ownedElement xmi:id="f3878fb0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f3879020-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891327057_604847_65553"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="f3898fc0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f38990f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891327057_604847_65553"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570891656454_451345_65911" xmi:uuid="dc2df340-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="48da1020-6c44-013d-931d-0800270c66d6" xmi:uuid="48da10c0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="463" y="178" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="629" y="202" width="15" height="15"/>
      </ownedElement>
      <bounds x="455" y="196" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891402888_549196_65617" xmi:uuid="dc2e5930-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891403813_89968_65618"/>
      <source xmi:idref="_18_4_1_6b1022a_1570891327095_103928_65558"/>
      <target xmi:idref="_18_4_1_6b1022a_1570891243403_146933_65466"/>
      <waypoint x="455" y="210"/>
      <waypoint x="441" y="210"/>
      <waypoint x="441" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891698741_810667_65981" xmi:uuid="dbb8f530-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891700214_168977_65982"/>
      <source xmi:idref="_18_4_1_6b1022a_1570890967699_713848_65215"/>
      <target xmi:idref="_18_4_1_6b1022a_1570891498898_939420_65709"/>
      <waypoint x="987" y="214"/>
      <waypoint x="875" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891449980_807597_65634" xmi:uuid="dc2e6750-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891449965_736808_65633"/>
      <ownedElement xmi:id="f39b1670-7cad-0138-40ff-418b172fba9f" xmi:uuid="f39b16f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891449965_736808_65633"/>
        <text>descAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f39cd780-7cad-0138-40ff-418b172fba9f" xmi:uuid="f39cd8c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891449965_736808_65633"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="49c7c9a0-6c44-013d-931d-0800270c66d6" xmi:uuid="49c7ca50-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="49ddd940-6c44-013d-931d-0800270c66d6" xmi:uuid="49ddda30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570891498898_939420_65709" xmi:uuid="f3cf2940-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="f3bdc350-7cad-0138-40ff-418b172fba9f" xmi:uuid="f3bdc470-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="f3cead10-7cad-0138-40ff-418b172fba9f" xmi:uuid="f3cead80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="700" y="203" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="679" y="175" width="267" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570894485065_316479_69164" xmi:uuid="dc51dcf0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570894486715_960278_69165"/>
      <source xmi:idref="_18_4_1_6b1022a_1570890967699_713848_65215"/>
      <target xmi:idref="_18_4_1_6b1022a_1570891517206_525678_65740"/>
      <waypoint x="987" y="291"/>
      <waypoint x="914" y="291"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891467781_626364_65673" xmi:uuid="dc2e7570-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891467766_901321_65672"/>
      <ownedElement xmi:id="f3e167a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f3e16820-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891467766_901321_65672"/>
        <text>descLangIndic:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="f3e33930-7cad-0138-40ff-418b172fba9f" xmi:uuid="f3e33980-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891467766_901321_65672"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="4c078c20-6c44-013d-931d-0800270c66d6" xmi:uuid="4c078cd0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4c2b5ed0-6c44-013d-931d-0800270c66d6" xmi:uuid="4c2b5f80-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570891517206_525678_65740" xmi:uuid="f4159a40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="f4043db0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f4043e20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="f4151a40-7cad-0138-40ff-418b172fba9f" xmi:uuid="f4151ac0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="686" y="280" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570891517207_684980_65771" xmi:uuid="f44727b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="f435cae0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f435cb60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="f446add0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f446ae40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="686" y="315" width="177" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570891517208_702259_65802" xmi:uuid="f4699e40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="f4580ba0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f4580c10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="f468fbb0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f468fc30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="686" y="350" width="188" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="679" y="252" width="266" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891688034_683411_65952" xmi:uuid="dc2e7f60-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891689222_592616_65953"/>
      <source xmi:idref="_18_4_1_6b1022a_1570891449980_807597_65634"/>
      <target xmi:idref="_18_4_1_6b1022a_1570891656454_451345_65911"/>
      <waypoint x="679" y="210"/>
      <waypoint x="644" y="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891824332_786933_66047" xmi:uuid="dc2f5bd0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891824315_564777_66046"/>
      <ownedElement xmi:id="f47c23e0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f47c2460-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891824315_564777_66046"/>
        <text>descripLang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="f47e6810-7cad-0138-40ff-418b172fba9f" xmi:uuid="f47e6870-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891824315_564777_66046"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570891858857_269268_66089" xmi:uuid="dc2ef310-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="53369c20-6c44-013d-931d-0800270c66d6" xmi:uuid="53369d20-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="514" y="312" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="496" y="321" width="15" height="15"/>
      </ownedElement>
      <bounds x="315" y="315" width="189" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891891647_226615_66134" xmi:uuid="dc2f69d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891892622_169200_66135"/>
      <source xmi:idref="_18_4_1_6b1022a_1570891824332_786933_66047"/>
      <target xmi:idref="_18_4_1_6b1022a_1570891243410_624825_65476"/>
      <waypoint x="336" y="315"/>
      <waypoint x="336" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891897158_88842_66159" xmi:uuid="dc2f7290-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891901406_244744_66160"/>
      <source xmi:idref="_18_4_1_6b1022a_1570891517207_684980_65771"/>
      <target xmi:idref="_18_4_1_6b1022a_1570891858857_269268_66089"/>
      <waypoint x="686" y="326"/>
      <waypoint x="511" y="326"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570891972872_573618_66189" xmi:uuid="dc2f7f60-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891972820_284387_66187"/>
      <ownedElement xmi:id="f4815bf0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f4815c60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891972820_284387_66187"/>
        <text>descAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="f4839460-7cad-0138-40ff-418b172fba9f" xmi:uuid="f48394c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570891972820_284387_66187"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="371" y="350" width="223" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892077893_640860_66229" xmi:uuid="dc2f87a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892078981_105675_66230"/>
      <source xmi:idref="_18_4_1_6b1022a_1570891517208_702259_65802"/>
      <target xmi:idref="_18_4_1_6b1022a_1570891972872_573618_66189"/>
      <waypoint x="686" y="361"/>
      <waypoint x="594" y="361"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892178836_601090_66278" xmi:uuid="dc30af20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892178819_185641_66277"/>
      <ownedElement xmi:id="f497ead0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f497eb50-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892178819_185641_66277"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570892217192_423476_66365" xmi:uuid="dc2ff530-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="56370c70-6c44-013d-931d-0800270c66d6" xmi:uuid="56370db0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="434" y="440" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="490" y="425" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570892217201_635266_66375" xmi:uuid="dc309470-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="56ff9be0-6c44-013d-931d-0800270c66d6" xmi:uuid="56ff9cd0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="664" y="421" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="646" y="430" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="490" y="413" width="171" height="61"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892188365_989535_66303" xmi:uuid="dc3267f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892188346_34538_66302"/>
      <ownedElement xmi:id="f4af0e50-7cad-0138-40ff-418b172fba9f" xmi:uuid="f4af0ed0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892188346_34538_66302"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570892211993_852808_66327" xmi:uuid="dc312630-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="586e4400-6c44-013d-931d-0800270c66d6" xmi:uuid="586e4570-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="212" y="416" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="266" y="425" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570892212001_554709_66337" xmi:uuid="dc31cc50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="590652e0-6c44-013d-931d-0800270c66d6" xmi:uuid="5909b470-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="421" y="417" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="403" y="426" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570892212008_324116_66347" xmi:uuid="dc324d90-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="599c5d20-6c44-013d-931d-0800270c66d6" xmi:uuid="599c5e70-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="320" y="472" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="310" y="454" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="266" y="413" width="152" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892285543_250332_66414" xmi:uuid="dc327500-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892288789_834207_66415"/>
      <source xmi:idref="_18_4_1_6b1022a_1570892211993_852808_66327"/>
      <target xmi:idref="_18_4_1_6b1022a_1570728775114_174906_45093"/>
      <waypoint x="266" y="431"/>
      <waypoint x="180" y="431"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892292350_282164_66433" xmi:uuid="dc3280b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892293788_553529_66434"/>
      <source xmi:idref="_18_4_1_6b1022a_1570892217192_423476_66365"/>
      <target xmi:idref="_18_4_1_6b1022a_1570892212001_554709_66337"/>
      <waypoint x="490" y="434"/>
      <waypoint x="418" y="434"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892312294_269501_66459" xmi:uuid="dc3289e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892313981_218599_66460"/>
      <source xmi:idref="_18_4_1_6b1022a_1570890982739_446535_65282"/>
      <target xmi:idref="_18_4_1_6b1022a_1570892217201_635266_66375"/>
      <waypoint x="998" y="438"/>
      <waypoint x="661" y="438"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892341068_388590_66480" xmi:uuid="dc332a40-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892341046_232052_66476"/>
      <ownedElement xmi:id="f4c5ec50-7cad-0138-40ff-418b172fba9f" xmi:uuid="f4c5ecd0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892341046_232052_66476"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="f4c843e0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f4c84430-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892341046_232052_66476"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570892392826_485104_66529" xmi:uuid="dc32f090-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="5b9923b0-6c44-013d-931d-0800270c66d6" xmi:uuid="5b992650-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="437" y="493" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="419" y="502" width="15" height="15"/>
      </ownedElement>
      <bounds x="294" y="497" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892530443_477467_66657" xmi:uuid="dcf635b0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892531980_155871_66658"/>
      <source xmi:idref="_18_4_1_6b1022a_1570890967699_713848_65215"/>
      <target xmi:idref="_18_4_1_6b1022a_1570892496408_919684_66592"/>
      <waypoint x="987" y="515"/>
      <waypoint x="869" y="515"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892450998_76339_66550" xmi:uuid="dc333980-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892450982_87940_66549"/>
      <ownedElement xmi:id="f4de6040-7cad-0138-40ff-418b172fba9f" xmi:uuid="f4de60c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892450982_87940_66549"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f4e09890-7cad-0138-40ff-418b172fba9f" xmi:uuid="f4e098e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892450982_87940_66549"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="5c8bfd50-6c44-013d-931d-0800270c66d6" xmi:uuid="5c8bfe30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5c8cac60-6c44-013d-931d-0800270c66d6" xmi:uuid="5c8cad30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570892496408_919684_66592" xmi:uuid="f51f4ff0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="f509b140-7cad-0138-40ff-418b172fba9f" xmi:uuid="f509b1e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f51eb5b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f51eb7c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="686" y="504" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="679" y="476" width="259" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892521610_879077_66638" xmi:uuid="dc3366f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892525212_448920_66639"/>
      <source xmi:idref="_18_4_1_6b1022a_1570892450998_76339_66550"/>
      <target xmi:idref="_18_4_1_6b1022a_1570892392826_485104_66529"/>
      <waypoint x="679" y="511"/>
      <waypoint x="434" y="511"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892870708_961044_66844" xmi:uuid="dd4379f0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892872284_212887_66845"/>
      <source xmi:idref="_18_4_1_6b1022a_1570890967699_713848_65215"/>
      <target xmi:idref="_18_4_1_6b1022a_1570892817151_608951_66740"/>
      <waypoint x="987" y="592"/>
      <waypoint x="870" y="592"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892766261_827927_66698" xmi:uuid="dc337430-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892766245_885038_66697"/>
      <ownedElement xmi:id="f5316e50-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5316ed0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892766245_885038_66697"/>
        <text>classiAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f5333fc0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5334020-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892766245_885038_66697"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="619712c0-6c44-013d-931d-0800270c66d6" xmi:uuid="61975270-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="61dd2eb0-6c44-013d-931d-0800270c66d6" xmi:uuid="61de1f10-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570892817151_608951_66740" xmi:uuid="f5653ec0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="f5540dd0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5540e60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f564c2c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f564c3f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="686" y="581" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="679" y="553" width="271" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892864733_419018_66819" xmi:uuid="dc33a860-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892867309_662646_66820"/>
      <source xmi:idref="_18_4_1_6b1022a_1570892766261_827927_66698"/>
      <target xmi:idref="_18_4_1_6b1022a_1570892853242_278761_66784"/>
      <waypoint x="679" y="585"/>
      <waypoint x="252" y="585"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892988314_579077_66967" xmi:uuid="dd8f2460-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892989581_277495_66968"/>
      <source xmi:idref="_18_4_1_6b1022a_1570890967699_713848_65215"/>
      <target xmi:idref="_18_4_1_6b1022a_1570892966308_388241_66909"/>
      <waypoint x="987" y="669"/>
      <waypoint x="909" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570892919248_991714_66867" xmi:uuid="dc33be30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892919231_739583_66866"/>
      <ownedElement xmi:id="f5778da0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5778e10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892919231_739583_66866"/>
        <text>sameAsAsgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="f5795a40-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5795a90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570892919231_739583_66866"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="66202ce0-6c44-013d-931d-0800270c66d6" xmi:uuid="66202e10-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="665704b0-6c44-013d-931d-0800270c66d6" xmi:uuid="66570620-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570892966308_388241_66909" xmi:uuid="f5ace830-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="f59b1d50-7cad-0138-40ff-418b172fba9f" xmi:uuid="f59b1df0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f5ac6a90-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5ac6b10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="686" y="658" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="679" y="630" width="276" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570893027773_229405_67018" xmi:uuid="dc33c7a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570893030157_232365_67019"/>
      <source xmi:idref="_18_4_1_6b1022a_1570892919248_991714_66867"/>
      <target xmi:idref="_18_4_1_6b1022a_1570893011071_809076_66983"/>
      <waypoint x="679" y="662"/>
      <waypoint x="189" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570894606690_748013_69232" xmi:uuid="ddd8ffe0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570894607403_258502_69233"/>
      <source xmi:idref="_18_4_1_6b1022a_1570890967699_713848_65215"/>
      <target xmi:idref="_18_4_1_6b1022a_1570894594984_866262_69190"/>
      <waypoint x="987" y="739"/>
      <waypoint x="910" y="739"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570894307668_961749_69069" xmi:uuid="dc33d770-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570894307647_818299_69068"/>
      <ownedElement xmi:id="f5befaa0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5befb20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570894307647_818299_69068"/>
        <text>viewsAsgn:Analysis_discipline_definition</text>
      </ownedElement>
      <ownedElement xmi:id="f5c0cc40-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5c0cc90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570894307647_818299_69068"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="6cab39b0-6c44-013d-931d-0800270c66d6" xmi:uuid="6cab3a80-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="6cf837c0-6c44-013d-931d-0800270c66d6" xmi:uuid="6d06b300-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570894594984_866262_69190" xmi:uuid="f5f39110-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_discipline_definition-defined_version"/>
          <ownedElement xmi:id="f5e21580-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5e21600-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_discipline_definition-defined_version"/>
            <text>defined_version:Analysis_version</text>
          </ownedElement>
          <ownedElement xmi:id="f5f31100-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5f31170-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_discipline_definition-defined_version"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="686" y="728" width="224" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="679" y="700" width="294" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570894614755_238808_69251" xmi:uuid="dc33dfe0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570894617004_233971_69252"/>
      <source xmi:idref="_18_4_1_6b1022a_1570894307668_961749_69069"/>
      <target xmi:idref="_18_4_1_6b1022a_1570893144198_296334_67044"/>
      <waypoint x="679" y="739"/>
      <waypoint x="301" y="739"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571733170924_284458_50518" xmi:uuid="dc33e9f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571733171987_123481_50519"/>
      <source xmi:idref="_18_4_1_6b1022a_1570892341068_388590_66480"/>
      <target xmi:idref="_18_4_1_6b1022a_1570892212008_324116_66347"/>
      <waypoint x="319" y="497"/>
      <waypoint x="319" y="469"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1283" height="785"/>
    <name>AnalysisVersion</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_6b1022a_1570894907991_795254_69299" xmi:uuid="90cca15f-1aa7-4885-ac7a-76119c86739a" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121248010_947033_13790"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570897459200_952026_71856" xmi:uuid="dc364430-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570897459162_285726_71852"/>
      <bounds x="1119" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570894913413_228079_69335" xmi:uuid="dc3721f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123742222_827187_39324"/>
      <ownedElement xmi:id="f5f9a550-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5f9a7b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123742222_827187_39324"/>
        <text>Related:AnalysisVersion</text>
      </ownedElement>
      <ownedElement xmi:id="f5fb9370-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5fb9500-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123742222_827187_39324"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570896430886_228665_71176" xmi:uuid="dc36e110-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727531350_445591_44578"/>
        <ownedElement xmi:id="7ad1b860-6c44-013d-931d-0800270c66d6" xmi:uuid="7ad1b9a0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727531350_445591_44578"/>
          <bounds x="255" y="633" width="185" height="13"/>
          <text>analysisVersion : Analysis_version [1]</text>
        </ownedElement>
        <bounds x="237" y="642" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="56" y="637" width="189" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570894913423_171734_69366" xmi:uuid="dc37c780-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123718489_199855_39320"/>
      <ownedElement xmi:id="f5ff45e0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f5ff46e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123718489_199855_39320"/>
        <text>Relating:AnalysisVersion</text>
      </ownedElement>
      <ownedElement xmi:id="f600fde0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f600fe30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123718489_199855_39320"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570896441412_433879_71190" xmi:uuid="dc378fe0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727531350_445591_44578"/>
        <ownedElement xmi:id="7c144030-6c44-013d-931d-0800270c66d6" xmi:uuid="7c144200-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727531350_445591_44578"/>
          <bounds x="255" y="675" width="185" height="13"/>
          <text>analysisVersion : Analysis_version [1]</text>
        </ownedElement>
        <bounds x="237" y="684" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="56" y="679" width="189" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895117761_310682_69492" xmi:uuid="dc37cd80-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="511" y="28" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895200335_722984_70028" xmi:uuid="dc384ef0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="f61e9100-7cad-0138-40ff-418b172fba9f" xmi:uuid="f61e9170-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570896843603_987729_71327" xmi:uuid="dc383ab0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="82cb2f80-6c44-013d-931d-0800270c66d6" xmi:uuid="82cb3050-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="384" y="740" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="366" y="749" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="203" y="735" width="178" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895210755_20339_70050" xmi:uuid="dc38f1e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="f64a3dd0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f64a3e60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570895882747_559678_70829" xmi:uuid="dc38d790-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="88fe9360-6c44-013d-931d-0800270c66d6" xmi:uuid="89075ca0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="434" y="568" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="416" y="577" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="196" y="560" width="235" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895216361_455506_70072" xmi:uuid="dc3990d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="f676fed0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f676ff50-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570895825736_741389_70777" xmi:uuid="dc3978e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="96017f40-6c44-013d-931d-0800270c66d6" xmi:uuid="9618b750-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="395" y="119" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="377" y="128" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="231" y="112" width="161" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570896084051_400633_71048" xmi:uuid="def48330-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896088403_831615_71049"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895427677_787321_70235"/>
      <target xmi:idref="_18_4_1_6b1022a_1570895699002_715369_70619"/>
      <waypoint x="872" y="532"/>
      <waypoint x="872" y="284"/>
      <waypoint x="645" y="284"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895293541_607804_70102" xmi:uuid="dc39a9a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="f6a45760-7cad-0138-40ff-418b172fba9f" xmi:uuid="f6a457e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f6b36740-7cad-0138-40ff-418b172fba9f" xmi:uuid="f6b367c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a4185100-6c44-013d-931d-0800270c66d6" xmi:uuid="a41852a0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a41c8390-6c44-013d-931d-0800270c66d6" xmi:uuid="a41c84d0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895699002_715369_70619" xmi:uuid="f6e61a00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="f6d4a0d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f6d4a250-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f6e59f30-7cad-0138-40ff-418b172fba9f" xmi:uuid="f6e59fb0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="273" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="455" y="245" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570896063842_970967_71008" xmi:uuid="df5e4db0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896069307_420966_71009"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895427677_787321_70235"/>
      <target xmi:idref="_18_4_1_6b1022a_1570895732683_354580_70660"/>
      <waypoint x="872" y="532"/>
      <waypoint x="872" y="357"/>
      <waypoint x="646" y="357"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895309665_23179_70135" xmi:uuid="dc39bc70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="f7050e10-7cad-0138-40ff-418b172fba9f" xmi:uuid="f7050e90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f713df80-7cad-0138-40ff-418b172fba9f" xmi:uuid="f713e000-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a753f630-6c44-013d-931d-0800270c66d6" xmi:uuid="a753f6d0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a7658d90-6c44-013d-931d-0800270c66d6" xmi:uuid="a7658e70-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895732683_354580_70660" xmi:uuid="f7461d40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="f7352650-7cad-0138-40ff-418b172fba9f" xmi:uuid="f73526e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f745a540-7cad-0138-40ff-418b172fba9f" xmi:uuid="f745a5c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="350" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="455" y="322" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570896077059_143403_71029" xmi:uuid="dfc876e0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896080210_379488_71030"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895427677_787321_70235"/>
      <target xmi:idref="_18_4_1_6b1022a_1570895754850_736977_70695"/>
      <waypoint x="872" y="532"/>
      <waypoint x="872" y="438"/>
      <waypoint x="637" y="438"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895320516_965517_70168" xmi:uuid="dc39ccc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="f7652310-7cad-0138-40ff-418b172fba9f" xmi:uuid="f7652380-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f7742f80-7cad-0138-40ff-418b172fba9f" xmi:uuid="f7743000-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="aaa4e680-6c44-013d-931d-0800270c66d6" xmi:uuid="aaa4e730-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="aabc3d80-6c44-013d-931d-0800270c66d6" xmi:uuid="aabc3e60-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895754850_736977_70695" xmi:uuid="f7ab9a80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="f7960280-7cad-0138-40ff-418b172fba9f" xmi:uuid="f7960310-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="f7aafbc0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f7aafc40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="427" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="455" y="399" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570896036536_498700_70973" xmi:uuid="e0349500-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896040130_948114_70974"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895427677_787321_70235"/>
      <target xmi:idref="_18_4_1_6b1022a_1570895784875_78684_70732"/>
      <waypoint x="872" y="532"/>
      <waypoint x="872" y="515"/>
      <waypoint x="690" y="515"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895335415_735556_70201" xmi:uuid="dc39ddd0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="f7ca7ce0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f7ca7d60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="f7d96060-7cad-0138-40ff-418b172fba9f" xmi:uuid="f7d960d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ae09b750-6c44-013d-931d-0800270c66d6" xmi:uuid="ae09b800-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ae0a5b40-6c44-013d-931d-0800270c66d6" xmi:uuid="ae0a5bb0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895784875_78684_70732" xmi:uuid="f80c3e30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="f7fabb30-7cad-0138-40ff-418b172fba9f" xmi:uuid="f7fabbb0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="f80bbf00-7cad-0138-40ff-418b172fba9f" xmi:uuid="f80bbf80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="504" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="455" y="476" width="308" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895427677_787321_70235" xmi:uuid="dc39ea70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570895427654_905170_70234"/>
      <ownedElement xmi:id="f81ee460-7cad-0138-40ff-418b172fba9f" xmi:uuid="f81ee4e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570895427654_905170_70234"/>
        <text>relation:Analysis_version_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="f820b770-7cad-0138-40ff-418b172fba9f" xmi:uuid="f820b7c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570895427654_905170_70234"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="b0731ac0-6c44-013d-931d-0800270c66d6" xmi:uuid="b0731b60-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b0862ee0-6c44-013d-931d-0800270c66d6" xmi:uuid="b0862fd0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895461177_936456_70271" xmi:uuid="f8444bc0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version_relationship-description"/>
          <ownedElement xmi:id="f832ec50-7cad-0138-40ff-418b172fba9f" xmi:uuid="f832ecc0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="f843d070-7cad-0138-40ff-418b172fba9f" xmi:uuid="f843d0f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="806" y="575" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895461178_420129_70302" xmi:uuid="f8745000-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version_relationship-related_version"/>
          <ownedElement xmi:id="f86373d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f8637460-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version_relationship-related_version"/>
            <text>related_version:Analysis_version</text>
          </ownedElement>
          <ownedElement xmi:id="f873d4f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f873d570-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version_relationship-related_version"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="637" width="221" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895461180_235425_70364" xmi:uuid="f8a520f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version_relationship-relating_version"/>
          <ownedElement xmi:id="f893c4f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f893c570-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version_relationship-relating_version"/>
            <text>relating_version:Analysis_version</text>
          </ownedElement>
          <ownedElement xmi:id="f8a4ac60-7cad-0138-40ff-418b172fba9f" xmi:uuid="f8a4ace0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_version_relationship-relating_version"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="679" width="224" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895461181_128009_70426" xmi:uuid="f8c78f40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version_relationship-relation_type"/>
          <ownedElement xmi:id="f8b5c740-7cad-0138-40ff-418b172fba9f" xmi:uuid="f8b5c7c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="f8c70f60-7cad-0138-40ff-418b172fba9f" xmi:uuid="f8c70fd0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_version_relationship-relation_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="805" y="742" width="162" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="798" y="532" width="248" height="301"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570896097429_543431_71067" xmi:uuid="e1ae3650-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896101116_758772_71068"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895427677_787321_70235"/>
      <target xmi:idref="_18_4_1_6b1022a_1570895643187_842658_70539"/>
      <waypoint x="872" y="532"/>
      <waypoint x="872" y="172"/>
      <waypoint x="645" y="172"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895579684_432712_70466" xmi:uuid="dc39fb20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570895579635_989778_70465"/>
      <ownedElement xmi:id="f8d8b590-7cad-0138-40ff-418b172fba9f" xmi:uuid="f8d8b610-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570895579635_989778_70465"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f8da8610-7cad-0138-40ff-418b172fba9f" xmi:uuid="f8da8670-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570895579635_989778_70465"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b6b972f0-6c44-013d-931d-0800270c66d6" xmi:uuid="b6b97390-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b6ba1780-6c44-013d-931d-0800270c66d6" xmi:uuid="b6ba1810-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895643186_691513_70508" xmi:uuid="f8fe13c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="f8ecb2e0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f8ecb360-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="f8fd9670-7cad-0138-40ff-418b172fba9f" xmi:uuid="f8fd9700-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="462" y="126" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895643187_842658_70539" xmi:uuid="f92f7f90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="f91dfb60-7cad-0138-40ff-418b172fba9f" xmi:uuid="f91dfc80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f92f02c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f92f0330-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="161" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570895643188_972770_70570" xmi:uuid="f95256f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="f940a800-7cad-0138-40ff-418b172fba9f" xmi:uuid="f940a8b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="f951d860-7cad-0138-40ff-418b172fba9f" xmi:uuid="f951d8e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="462" y="196" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="455" y="98" width="308" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570895962796_27561_70904" xmi:uuid="dc3a0920-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570895964786_383651_70905"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895461177_936456_70271"/>
      <target xmi:idref="_18_4_1_6b1022a_1570895882747_559678_70829"/>
      <waypoint x="806" y="585"/>
      <waypoint x="431" y="585"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570896119303_384086_71084" xmi:uuid="dc3a1800-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896119259_894320_71082"/>
      <ownedElement xmi:id="f95484b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f9548530-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896119259_894320_71082"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="f9566160-7cad-0138-40ff-418b172fba9f" xmi:uuid="f95661f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896119259_894320_71082"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="238" y="196" width="154" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570896209372_113051_71124" xmi:uuid="dc3a24e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896210234_799819_71125"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895643188_972770_70570"/>
      <target xmi:idref="_18_4_1_6b1022a_1570896119303_384086_71084"/>
      <waypoint x="462" y="210"/>
      <waypoint x="392" y="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570896372210_124929_71159" xmi:uuid="dc3a2bc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896373074_927168_71160"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895643186_691513_70508"/>
      <target xmi:idref="_18_4_1_6b1022a_1570895825736_741389_70777"/>
      <waypoint x="462" y="137"/>
      <waypoint x="392" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570896488652_793765_71217" xmi:uuid="dc3a3980-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896490529_272778_71218"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895461178_420129_70302"/>
      <target xmi:idref="_18_4_1_6b1022a_1570896430886_228665_71176"/>
      <waypoint x="805" y="651"/>
      <waypoint x="252" y="651"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570896494039_744896_71239" xmi:uuid="dc3a4090-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570896495331_482520_71240"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895461180_235425_70364"/>
      <target xmi:idref="_18_4_1_6b1022a_1570896441412_433879_71190"/>
      <waypoint x="805" y="693"/>
      <waypoint x="252" y="693"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570897399818_324063_71827" xmi:uuid="e2289e20-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570897403098_37013_71828"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895427677_787321_70235"/>
      <target xmi:idref="_18_4_1_6b1022a_1570897384331_590415_71785"/>
      <waypoint x="798" y="816"/>
      <waypoint x="646" y="816"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570897354390_964444_71754" xmi:uuid="dc3a54f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="f97554d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="f9755550-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f9842090-7cad-0138-40ff-418b172fba9f" xmi:uuid="f9842110-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="bc68d240-6c44-013d-931d-0800270c66d6" xmi:uuid="bc68d300-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bc83bb20-6c44-013d-931d-0800270c66d6" xmi:uuid="bc83bc10-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570897384331_590415_71785" xmi:uuid="f9b604f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="f9a4e850-7cad-0138-40ff-418b172fba9f" xmi:uuid="f9a4e9b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f9b58910-7cad-0138-40ff-418b172fba9f" xmi:uuid="f9b58990-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="805" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="455" y="777" width="287" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570897545834_116217_71883" xmi:uuid="dc3a6420-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570897551714_983906_71884"/>
      <source xmi:idref="_18_4_1_6b1022a_1570897459200_952026_71856"/>
      <target xmi:idref="_18_4_1_6b1022a_1570895427677_787321_70235"/>
      <waypoint x="1119" y="543"/>
      <waypoint x="1046" y="543"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571735383729_391231_51742" xmi:uuid="dc3a6b10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571735385698_415869_51743"/>
      <source xmi:idref="_18_4_1_6b1022a_1570895461181_128009_70426"/>
      <target xmi:idref="_18_4_1_6b1022a_1570896843603_987729_71327"/>
      <waypoint x="805" y="756"/>
      <waypoint x="381" y="756"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1122" height="855"/>
    <name>AnalysisVersionRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_6b1022a_1570740634030_694655_48011" xmi:uuid="9a2381c8-32e6-4c3c-8ae0-46feacba71f8" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121223171_313016_13784"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570743691895_89636_50803" xmi:uuid="dc0dff70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570743691846_709103_50799"/>
      <bounds x="1651" y="216" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570740640437_229085_48045" xmi:uuid="dc0eac30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132200_681002_38682"/>
      <ownedElement xmi:id="eb7da0b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="eb7da130-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132200_681002_38682"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="eb7f8cd0-7cad-0138-40ff-418b172fba9f" xmi:uuid="eb7f8d40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132200_681002_38682"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570741107474_309535_48547" xmi:uuid="dc0e6ab0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="f5a31640-6c43-013d-931d-0800270c66d6" xmi:uuid="f5a316e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="262" y="44" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="244" y="53" width="15" height="15"/>
      </ownedElement>
      <bounds x="42" y="49" width="210" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570740640449_231281_48076" xmi:uuid="dc0f55c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123146489_313658_38705"/>
      <ownedElement xmi:id="eb8318d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="eb831940-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123146489_313658_38705"/>
        <text>ContextOfItems:AnalysisRepresentationContext</text>
      </ownedElement>
      <ownedElement xmi:id="eb84ce00-7cad-0138-40ff-418b172fba9f" xmi:uuid="eb84ce50-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123146489_313658_38705"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1571730976549_54779_49080" xmi:uuid="dc0f1ab0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570798456065_659070_56826"/>
        <ownedElement xmi:id="f627a010-6c43-013d-931d-0800270c66d6" xmi:uuid="f627a0c0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570798456065_659070_56826"/>
          <bounds x="367" y="134" width="256" height="13"/>
          <text>analRepContxt : Analysis_representation_context [1]</text>
        </ownedElement>
        <bounds x="349" y="143" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="42" y="140" width="315" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570740640456_658299_48107" xmi:uuid="dc0f6460-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132199_764598_38681"/>
      <ownedElement xmi:id="eb9483d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="eb948450-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132199_764598_38681"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="eb9655d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="eb965630-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132199_764598_38681"/>
        <text>[0..1]</text>
      </ownedElement>
      <bounds x="42" y="210" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570740640467_397010_48138" xmi:uuid="dc0f7140-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132198_861267_38680"/>
      <ownedElement xmi:id="eba5a660-7cad-0138-40ff-418b172fba9f" xmi:uuid="eba5a6e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132198_861267_38680"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="eba77c90-7cad-0138-40ff-418b172fba9f" xmi:uuid="eba77ce0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132198_861267_38680"/>
        <text>[1]</text>
      </ownedElement>
      <bounds x="42" y="525" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570740640475_482947_48169" xmi:uuid="dc102f70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132201_217371_38683"/>
      <ownedElement xmi:id="ebb68790-7cad-0138-40ff-418b172fba9f" xmi:uuid="ebb68810-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132201_217371_38683"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="ebb853a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ebb853f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559123132201_217371_38683"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570743653730_158452_50720" xmi:uuid="dc0fe170-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="f882a950-6c43-013d-931d-0800270c66d6" xmi:uuid="f882a9f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="192" y="731" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="174" y="740" width="15" height="15"/>
      </ownedElement>
      <bounds x="42" y="735" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570740799274_226161_48219" xmi:uuid="dc104320-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
      <ownedElement xmi:id="ebc9b5b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ebc9b630-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
        <text>analMod:Analysis_model</text>
      </ownedElement>
      <ownedElement xmi:id="ebcb7a80-7cad-0138-40ff-418b172fba9f" xmi:uuid="ebcb7ac0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="f945dc60-6c43-013d-931d-0800270c66d6" xmi:uuid="f945dd10-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f946a7a0-6c43-013d-931d-0800270c66d6" xmi:uuid="f946a880-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570740805828_777880_48254" xmi:uuid="ebfedb20-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_model-context_of_items"/>
          <ownedElement xmi:id="ebecff40-7cad-0138-40ff-418b172fba9f" xmi:uuid="ebecffc0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_model-context_of_items"/>
            <text>context_of_items:Analysis_representation_context</text>
          </ownedElement>
          <ownedElement xmi:id="ebfe5100-7cad-0138-40ff-418b172fba9f" xmi:uuid="ebfe5170-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_model-context_of_items"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1106" y="140" width="318" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570740920952_75219_48291" xmi:uuid="ec30aa80-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation-description"/>
          <ownedElement xmi:id="ec1f3cd0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ec1f3d40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation-description"/>
            <text>description:text</text>
          </ownedElement>
          <ownedElement xmi:id="ec302d50-7cad-0138-40ff-418b172fba9f" xmi:uuid="ec302dd0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1113" y="210" width="141" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570740920953_332713_48322" xmi:uuid="ec629130-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation-id"/>
          <ownedElement xmi:id="ec50fae0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ec50fb60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation-id"/>
            <text>id:identifier</text>
          </ownedElement>
          <ownedElement xmi:id="ec6215f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ec621740-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1113" y="525" width="117" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1092" y="14" width="339" height="784"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570741220928_146102_48707" xmi:uuid="d4ee7690-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741223341_787257_48708"/>
      <source xmi:idref="_18_4_1_6b1022a_1570740799274_226161_48219"/>
      <target xmi:idref="_18_4_1_6b1022a_1570741164307_220904_48635"/>
      <waypoint x="1092" y="88"/>
      <waypoint x="723" y="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570741055490_845151_48477" xmi:uuid="dc105030-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741055476_869180_48476"/>
      <ownedElement xmi:id="ecb2d920-7cad-0138-40ff-418b172fba9f" xmi:uuid="ecb2d9a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741055476_869180_48476"/>
        <text>classAs:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ecb51ae0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ecb51b30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741055476_869180_48476"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="fea91860-6c43-013d-931d-0800270c66d6" xmi:uuid="fea918f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="fea9cb70-6c43-013d-931d-0800270c66d6" xmi:uuid="fea9cc40-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570741164307_220904_48635" xmi:uuid="ecf48820-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="ecde7550-7cad-0138-40ff-418b172fba9f" xmi:uuid="ecde77b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ecf3f900-7cad-0138-40ff-418b172fba9f" xmi:uuid="ecf3f970-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="70" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="518" y="35" width="239" height="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570741128637_262200_48582" xmi:uuid="dc1058a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741130127_958096_48583"/>
      <source xmi:idref="_18_4_1_6b1022a_1570741055490_845151_48477"/>
      <target xmi:idref="_18_4_1_6b1022a_1570741107474_309535_48547"/>
      <waypoint x="518" y="60"/>
      <waypoint x="259" y="60"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570741369704_416782_48765" xmi:uuid="dc1278f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741369685_920048_48764"/>
      <ownedElement xmi:id="ed058e80-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed058f00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741369685_920048_48764"/>
        <text>selectDes:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570741384511_709301_48786" xmi:uuid="dc10cbf0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="01d94060-6c44-013d-931d-0800270c66d6" xmi:uuid="01d94100-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="275" y="206" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="329" y="215" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570741384520_772264_48796" xmi:uuid="dc114860-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="024b21e0-6c44-013d-931d-0800270c66d6" xmi:uuid="024b2280-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="535" y="208" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="517" y="217" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570741384529_348507_48806" xmi:uuid="dc11c060-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="0312d8e0-6c44-013d-931d-0800270c66d6" xmi:uuid="0312d990-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="483" y="259" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="475" y="241" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570741384537_692349_48816" xmi:uuid="dc1239a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="03a2c1a0-6c44-013d-931d-0800270c66d6" xmi:uuid="03a2c240-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="352" y="259" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="342" y="241" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="329" y="203" width="203" height="53"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570741439985_727876_48857" xmi:uuid="dc128840-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741442077_923636_48858"/>
      <source xmi:idref="_18_4_1_6b1022a_1570741384511_709301_48786"/>
      <target xmi:idref="_18_4_1_6b1022a_1570740640456_658299_48107"/>
      <waypoint x="329" y="221"/>
      <waypoint x="248" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570741465061_113844_48886" xmi:uuid="dc129100-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741466390_566651_48887"/>
      <source xmi:idref="_18_4_1_6b1022a_1570740920952_75219_48291"/>
      <target xmi:idref="_18_4_1_6b1022a_1570741384520_772264_48796"/>
      <waypoint x="1113" y="224"/>
      <waypoint x="532" y="224"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570741542101_143339_49007" xmi:uuid="dc147660-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741542082_366128_49006"/>
      <ownedElement xmi:id="ed191c20-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed191cb0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570741542082_366128_49006"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570741553355_369786_49028" xmi:uuid="dc132cc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="04b691e0-6c44-013d-931d-0800270c66d6" xmi:uuid="04b69290-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="254" y="521" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="308" y="530" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570741553369_957702_49038" xmi:uuid="dc13ca00-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="05a0e990-6c44-013d-931d-0800270c66d6" xmi:uuid="05a0ea30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="500" y="524" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="482" y="533" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570741553379_656872_49048" xmi:uuid="dc146190-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="061b7ab0-6c44-013d-931d-0800270c66d6" xmi:uuid="061b7b60-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="398" y="574" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="388" y="556" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="308" y="518" width="189" height="53"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742034182_807441_49155" xmi:uuid="dc151cf0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742034160_28003_49150"/>
      <ownedElement xmi:id="ed2b44f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed2b4560-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742034160_28003_49150"/>
        <text>descriptor:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="ed2d07f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed2d08b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742034160_28003_49150"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570742081787_83870_49234" xmi:uuid="dc14e940-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="0751c2c0-6c44-013d-931d-0800270c66d6" xmi:uuid="0751c440-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="572" y="287" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="580" y="306" width="15" height="15"/>
      </ownedElement>
      <bounds x="413" y="301" width="175" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742047479_321467_49197" xmi:uuid="dc15fa00-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742047466_886212_49196"/>
      <ownedElement xmi:id="ed3cd140-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed3cd1d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742047466_886212_49196"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="ed3e95e0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed3e9630-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742047466_886212_49196"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570742109001_253091_49262" xmi:uuid="dc15bb20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="089ec5f0-6c44-013d-931d-0800270c66d6" xmi:uuid="089ec690-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="486" y="426" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="468" y="435" width="15" height="15"/>
      </ownedElement>
      <bounds x="308" y="427" width="168" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742261927_205286_49456" xmi:uuid="d58d4960-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742263628_529684_49457"/>
      <source xmi:idref="_18_4_1_6b1022a_1570740799274_226161_48219"/>
      <target xmi:idref="_18_4_1_6b1022a_1570742219881_390375_49383"/>
      <waypoint x="1092" y="319"/>
      <waypoint x="987" y="319"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742160383_28733_49301" xmi:uuid="dc160c00-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742160365_840659_49300"/>
      <ownedElement xmi:id="ed5050c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed505140-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742160365_840659_49300"/>
        <text>descTextAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ed522530-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed522590-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742160365_840659_49300"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="0974d300-6c44-013d-931d-0800270c66d6" xmi:uuid="0974d3b0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="097571c0-6c44-013d-931d-0800270c66d6" xmi:uuid="09757220-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570742219881_390375_49383" xmi:uuid="ed850130-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="ed737950-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed7379c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="ed847cc0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed847d40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="812" y="308" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="784" y="280" width="291" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742249256_851252_49431" xmi:uuid="dc1614f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742254493_211506_49432"/>
      <source xmi:idref="_18_4_1_6b1022a_1570742160383_28733_49301"/>
      <target xmi:idref="_18_4_1_6b1022a_1570742081787_83870_49234"/>
      <waypoint x="784" y="313"/>
      <waypoint x="595" y="313"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570744159049_824743_50951" xmi:uuid="d6423f30-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570744160251_723101_50952"/>
      <source xmi:idref="_18_4_1_6b1022a_1570740799274_226161_48219"/>
      <target xmi:idref="_18_4_1_6b1022a_1570742325638_108331_49537"/>
      <waypoint x="1092" y="403"/>
      <waypoint x="1040" y="403"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742284874_56876_49469" xmi:uuid="dc162210-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742284859_379698_49468"/>
      <ownedElement xmi:id="ed96fa40-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed96fac0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742284859_379698_49468"/>
        <text>langIndic:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="ed98e080-7cad-0138-40ff-418b172fba9f" xmi:uuid="ed98e0e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742284859_379698_49468"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="0bcf2010-6c44-013d-931d-0800270c66d6" xmi:uuid="0bcf20e0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0bcff290-6c44-013d-931d-0800270c66d6" xmi:uuid="0bcff440-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570742298969_721465_49504" xmi:uuid="edbcb900-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="edaaf450-7cad-0138-40ff-418b172fba9f" xmi:uuid="edaaf4d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="edbc3c80-7cad-0138-40ff-418b172fba9f" xmi:uuid="edbc3cf0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="812" y="462" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570742325638_108331_49537" xmi:uuid="edee8360-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="eddd0760-7cad-0138-40ff-418b172fba9f" xmi:uuid="eddd07e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="ededd880-7cad-0138-40ff-418b172fba9f" xmi:uuid="ededd900-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="812" y="392" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570742325652_220404_49568" xmi:uuid="ee1feb10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="ee0e6070-7cad-0138-40ff-418b172fba9f" xmi:uuid="ee0e60f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="ee1f7070-7cad-0138-40ff-418b172fba9f" xmi:uuid="ee1f7100-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="812" y="427" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="364" width="280" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742423491_573688_49641" xmi:uuid="dc162950-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742424580_706901_49642"/>
      <source xmi:idref="_18_4_1_6b1022a_1570742047479_321467_49197"/>
      <target xmi:idref="_18_4_1_6b1022a_1570741384537_692349_48816"/>
      <waypoint x="350" y="427"/>
      <waypoint x="350" y="256"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742430155_886923_49666" xmi:uuid="dc1631c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742431724_468706_49667"/>
      <source xmi:idref="_18_4_1_6b1022a_1570742325652_220404_49568"/>
      <target xmi:idref="_18_4_1_6b1022a_1570742109001_253091_49262"/>
      <waypoint x="812" y="442"/>
      <waypoint x="483" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742556412_569241_49730" xmi:uuid="dc163ae0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742557835_230022_49731"/>
      <source xmi:idref="_18_4_1_6b1022a_1570741553355_369786_49028"/>
      <target xmi:idref="_18_4_1_6b1022a_1570740640467_397010_48138"/>
      <waypoint x="308" y="536"/>
      <waypoint x="175" y="536"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742601505_926377_49759" xmi:uuid="dc1687b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742603597_148558_49760"/>
      <source xmi:idref="_18_4_1_6b1022a_1570740920953_332713_48322"/>
      <target xmi:idref="_18_4_1_6b1022a_1570741553369_957702_49038"/>
      <waypoint x="1113" y="539"/>
      <waypoint x="497" y="539"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742662356_663130_49780" xmi:uuid="dc172f00-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742662337_416282_49776"/>
      <ownedElement xmi:id="ee2ff410-7cad-0138-40ff-418b172fba9f" xmi:uuid="ee2ff6e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742662337_416282_49776"/>
        <text>id:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="ee31da10-7cad-0138-40ff-418b172fba9f" xmi:uuid="ee31da70-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742662337_416282_49776"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570742818063_769312_50431" xmi:uuid="dc16f4e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="117f4bf0-6c44-013d-931d-0800270c66d6" xmi:uuid="117f4ca0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="591" y="584" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="573" y="593" width="15" height="15"/>
      </ownedElement>
      <bounds x="462" y="588" width="119" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742876664_758800_50485" xmi:uuid="d6a02200-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742878747_306185_50486"/>
      <source xmi:idref="_18_4_1_6b1022a_1570740799274_226161_48219"/>
      <target xmi:idref="_18_4_1_6b1022a_1570742725576_739430_49918"/>
      <waypoint x="1092" y="606"/>
      <waypoint x="988" y="606"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742703777_242830_49821" xmi:uuid="dc173f30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742703764_879505_49820"/>
      <ownedElement xmi:id="ee439060-7cad-0138-40ff-418b172fba9f" xmi:uuid="ee4390e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742703764_879505_49820"/>
        <text>identAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ee4559f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="ee455a30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742703764_879505_49820"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="124c3ac0-6c44-013d-931d-0800270c66d6" xmi:uuid="124c3b50-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="124cead0-6c44-013d-931d-0800270c66d6" xmi:uuid="124cec30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570742725576_739430_49918" xmi:uuid="ee7f8f70-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="ee6bc740-7cad-0138-40ff-418b172fba9f" xmi:uuid="ee6bc7c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ee7f0750-7cad-0138-40ff-418b172fba9f" xmi:uuid="ee7f07d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="595" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="784" y="560" width="266" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742760950_596685_50005" xmi:uuid="dc1746d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742762036_231639_50006"/>
      <source xmi:idref="_18_4_1_6b1022a_1570742662356_663130_49780"/>
      <target xmi:idref="_18_4_1_6b1022a_1570741553379_656872_49048"/>
      <waypoint x="462" y="606"/>
      <waypoint x="396" y="606"/>
      <waypoint x="396" y="571"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570742854844_991531_50462" xmi:uuid="dc175390-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570742857532_595703_50463"/>
      <source xmi:idref="_18_4_1_6b1022a_1570742703777_242830_49821"/>
      <target xmi:idref="_18_4_1_6b1022a_1570742818063_769312_50431"/>
      <waypoint x="784" y="599"/>
      <waypoint x="588" y="599"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570743673273_641761_50780" xmi:uuid="d6f75c50-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570743674027_147699_50781"/>
      <source xmi:idref="_18_4_1_6b1022a_1570740799274_226161_48219"/>
      <target xmi:idref="_18_4_1_6b1022a_1570743608872_544112_50661"/>
      <waypoint x="1092" y="774"/>
      <waypoint x="1021" y="774"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570743492770_246562_50589" xmi:uuid="dc177810-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570743492754_925986_50588"/>
      <ownedElement xmi:id="eea52490-7cad-0138-40ff-418b172fba9f" xmi:uuid="eea52500-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570743492754_925986_50588"/>
        <text>extItemIdent:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="eea6faf0-7cad-0138-40ff-418b172fba9f" xmi:uuid="eea6fb40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570743492754_925986_50588"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="14c31d90-6c44-013d-931d-0800270c66d6" xmi:uuid="14c31e30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="14c3cde0-6c44-013d-931d-0800270c66d6" xmi:uuid="14c3ced0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570743608872_544112_50661" xmi:uuid="eed9abc0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="eec85360-7cad-0138-40ff-418b172fba9f" xmi:uuid="eec853d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="eed924c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="eed92540-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="798" y="763" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="735" width="271" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570743665953_514699_50755" xmi:uuid="dc177fc0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570743668835_979024_50756"/>
      <source xmi:idref="_18_4_1_6b1022a_1570743492770_246562_50589"/>
      <target xmi:idref="_18_4_1_6b1022a_1570743653730_158452_50720"/>
      <waypoint x="791" y="746"/>
      <waypoint x="189" y="746"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570743770120_498633_50826" xmi:uuid="dc1787a0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570743771379_512595_50827"/>
      <source xmi:idref="_18_4_1_6b1022a_1570743691895_89636_50803"/>
      <target xmi:idref="_18_4_1_6b1022a_1570740799274_226161_48219"/>
      <waypoint x="1651" y="224"/>
      <waypoint x="1431" y="224"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570744051643_320433_50904" xmi:uuid="dc179a90-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570744053187_46914_50905"/>
      <source xmi:idref="_18_4_1_6b1022a_1570742034182_807441_49155"/>
      <target xmi:idref="_18_4_1_6b1022a_1570741384529_348507_48806"/>
      <waypoint x="483" y="301"/>
      <waypoint x="483" y="256"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570744569164_834022_50989" xmi:uuid="dc17ad00-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570744569140_315729_50987"/>
      <ownedElement xmi:id="eedc16d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="eedc1760-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570744569140_315729_50987"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="eede1ee0-7cad-0138-40ff-418b172fba9f" xmi:uuid="eede1f50-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570744569140_315729_50987"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="546" y="462" width="226" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570744652899_264993_51022" xmi:uuid="dc17b6f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570744654483_263271_51023"/>
      <source xmi:idref="_18_4_1_6b1022a_1570742298969_721465_49504"/>
      <target xmi:idref="_18_4_1_6b1022a_1570744569164_834022_50989"/>
      <waypoint x="812" y="476"/>
      <waypoint x="772" y="476"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571731012666_549286_49124" xmi:uuid="dc17c000-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571731016181_601405_49125"/>
      <source xmi:idref="_18_4_1_6b1022a_1570740805828_777880_48254"/>
      <target xmi:idref="_18_4_1_6b1022a_1571730976549_54779_49080"/>
      <waypoint x="1106" y="151"/>
      <waypoint x="364" y="151"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1654" height="847"/>
    <name>AnalysisModelObject</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446166659_96664_137120" xmi:uuid="be31b300-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121248010_947033_13790"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166674_94097_137152" xmi:uuid="bec910e0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570895427654_905170_70234"/>
      <ownedElement xmi:id="bea17ba0-6c44-013d-931d-0800270c66d6" xmi:uuid="bea17c60-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570895427654_905170_70234"/>
        <text>relation:Analysis_version_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="bec8ffd0-6c44-013d-931d-0800270c66d6" xmi:uuid="bec900a0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570895427654_905170_70234"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="239" height="210"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166688_808852_137186" xmi:uuid="bec9c780-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="601" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166705_775658_137207" xmi:uuid="beca95a0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="601" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166723_53162_137228" xmi:uuid="becb5520-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="601" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166740_633833_137249" xmi:uuid="bef51c20-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="601" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166757_542188_137270" xmi:uuid="bef5e420-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="601" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166775_125716_137291" xmi:uuid="bf0acb00-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="601" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166794_751678_137312" xmi:uuid="bf0b7820-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="601" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166815_835118_137333" xmi:uuid="bf0c35f0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="601" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480502_508914_378488" xmi:uuid="bf0c4370-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606497233852_150529_71166"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166688_808852_137186"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166674_94097_137152"/>
      <waypoint x="601" y="62"/>
      <waypoint x="284" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480502_423777_378491" xmi:uuid="bf0c4a50-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606497223455_392079_71142"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166705_775658_137207"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166674_94097_137152"/>
      <waypoint x="601" y="82"/>
      <waypoint x="284" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480502_39413_378494" xmi:uuid="bf0c5070-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606497237868_658582_71188"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166723_53162_137228"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166674_94097_137152"/>
      <waypoint x="601" y="102"/>
      <waypoint x="284" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480502_826222_378497" xmi:uuid="bf0c57a0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606497218099_760854_71120"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166740_633833_137249"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166674_94097_137152"/>
      <waypoint x="601" y="122"/>
      <waypoint x="284" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480502_640887_378500" xmi:uuid="bf0c5dc0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606497247288_966376_71232"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166757_542188_137270"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166674_94097_137152"/>
      <waypoint x="601" y="142"/>
      <waypoint x="284" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480502_644406_378503" xmi:uuid="bf0c63c0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662626941092_480786_69116"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166775_125716_137291"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166674_94097_137152"/>
      <waypoint x="601" y="162"/>
      <waypoint x="284" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480502_766055_378506" xmi:uuid="bf0c69f0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662626944515_108868_69136"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166794_751678_137312"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166674_94097_137152"/>
      <waypoint x="601" y="182"/>
      <waypoint x="284" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480502_852767_378509" xmi:uuid="bf0c7030-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606497242248_319404_71210"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166815_835118_137333"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166674_94097_137152"/>
      <waypoint x="601" y="202"/>
      <waypoint x="284" y="202"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="604" height="280"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446166020_391894_136321" xmi:uuid="c2264fd0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121257177_404073_13792"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166063_890113_136354" xmi:uuid="c2e269d0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571753902960_295276_48510"/>
      <ownedElement xmi:id="c2d33d70-6c44-013d-931d-0800270c66d6" xmi:uuid="c2d33e30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571753902960_295276_48510"/>
        <text>analMod:External_analysis_model</text>
      </ownedElement>
      <ownedElement xmi:id="c2e25700-6c44-013d-931d-0800270c66d6" xmi:uuid="c2e257d0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571753902960_295276_48510"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="216" height="170"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166079_495435_136388" xmi:uuid="c2f417b0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="573" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166100_498742_136409" xmi:uuid="c2f4d030-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="573" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166122_163256_136430" xmi:uuid="c30b2100-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="573" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166143_107366_136451" xmi:uuid="c30bea30-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="573" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166164_384999_136472" xmi:uuid="c30cbcb0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="573" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166180_545126_136493" xmi:uuid="c32db670-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="573" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480429_196610_378227" xmi:uuid="c32dc820-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600937961_969033_105500"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166079_495435_136388"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166063_890113_136354"/>
      <waypoint x="573" y="62"/>
      <waypoint x="261" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480429_903131_378230" xmi:uuid="c32dd1e0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600938072_982106_105522"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166100_498742_136409"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166063_890113_136354"/>
      <waypoint x="573" y="82"/>
      <waypoint x="261" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480429_796219_378233" xmi:uuid="c32df100-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600938172_742800_105544"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166122_163256_136430"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166063_890113_136354"/>
      <waypoint x="573" y="102"/>
      <waypoint x="261" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480429_343434_378236" xmi:uuid="c32df7a0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600938272_323841_105566"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166143_107366_136451"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166063_890113_136354"/>
      <waypoint x="573" y="122"/>
      <waypoint x="261" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480429_201849_378239" xmi:uuid="c32dffe0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600938380_473376_105588"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166164_384999_136472"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166063_890113_136354"/>
      <waypoint x="573" y="142"/>
      <waypoint x="261" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480429_985863_378242" xmi:uuid="c32e05b0-6c44-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600938488_553550_105610"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166180_545126_136493"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166063_890113_136354"/>
      <waypoint x="573" y="162"/>
      <waypoint x="261" y="162"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="576" height="240"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1607083399322_195880_66533" xmi:uuid="cfa14910-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121223171_313016_13784"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607083418382_372807_66598" xmi:uuid="cfa37130-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="587" y="45" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607083418397_146228_66608" xmi:uuid="cfa41c90-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="587" y="69" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607083418408_254134_66618" xmi:uuid="cfa4cbf0-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="587" y="93" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607083418415_264062_66628" xmi:uuid="cfa57020-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="587" y="117" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1662626977427_87912_69202" xmi:uuid="9fd6a1a0-18d6-013b-2594-316dbea2a0c2" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="587" y="136" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1662626977450_213122_69212" xmi:uuid="9fd75930-18d6-013b-2594-316dbea2a0c2" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="587" y="160" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607083418364_601213_66567" xmi:uuid="c32cf420-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
      <ownedElement xmi:id="cfb205e0-6ae6-013a-da16-3770a1b6a6fd" xmi:uuid="cfb20710-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
        <text>analMod:Analysis_model</text>
      </ownedElement>
      <ownedElement xmi:id="cfb3a5d0-6ae6-013a-da16-3770a1b6a6fd" xmi:uuid="cfb3a6d0-6ae6-013a-da16-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="35" width="173" height="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607083465802_977028_66712" xmi:uuid="c32cfd10-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607083467089_90440_66715"/>
      <source xmi:idref="_18_4_1_2b2015d_1607083418382_372807_66598"/>
      <target xmi:idref="_18_4_1_2b2015d_1607083418364_601213_66567"/>
      <waypoint x="587" y="52"/>
      <waypoint x="208" y="52"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607083469261_76922_66734" xmi:uuid="c32d04c0-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607083470359_791156_66737"/>
      <source xmi:idref="_18_4_1_2b2015d_1607083418397_146228_66608"/>
      <target xmi:idref="_18_4_1_2b2015d_1607083418364_601213_66567"/>
      <waypoint x="587" y="76"/>
      <waypoint x="208" y="76"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607083472601_227438_66756" xmi:uuid="c32d0db0-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607083474198_994278_66759"/>
      <source xmi:idref="_18_4_1_2b2015d_1607083418408_254134_66618"/>
      <target xmi:idref="_18_4_1_2b2015d_1607083418364_601213_66567"/>
      <waypoint x="587" y="100"/>
      <waypoint x="208" y="100"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1607083476673_313420_66778" xmi:uuid="c32d1560-3359-0139-44f6-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1607083479171_879706_66781"/>
      <source xmi:idref="_18_4_1_2b2015d_1607083418415_264062_66628"/>
      <target xmi:idref="_18_4_1_2b2015d_1607083418364_601213_66567"/>
      <waypoint x="587" y="124"/>
      <waypoint x="208" y="124"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1662626987869_954640_69245" xmi:uuid="b0500080-8483-013b-735a-29e527a7a3ad" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662626988872_207787_69246"/>
      <source xmi:idref="_18_4_1_2b2015d_1662626977427_87912_69202"/>
      <target xmi:idref="_18_4_1_2b2015d_1607083418364_601213_66567"/>
      <waypoint x="587" y="143"/>
      <waypoint x="208" y="143"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1662626991001_13801_69265" xmi:uuid="b05015d0-8483-013b-735a-29e527a7a3ad" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662626992166_394178_69266"/>
      <source xmi:idref="_18_4_1_2b2015d_1662626977450_213122_69212"/>
      <target xmi:idref="_18_4_1_2b2015d_1607083418364_601213_66567"/>
      <waypoint x="587" y="167"/>
      <waypoint x="208" y="167"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="590" height="197"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_6b1022a_1570725566020_457987_43225" xmi:uuid="d24c14e6-a72d-40cb-8b23-814f5d74dbcf" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121169584_987103_13774"/>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570737929903_486420_47193" xmi:uuid="dbf1f990-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570737929878_195997_47189"/>
      <bounds x="1105" y="746" width="16" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570725641071_195738_43259" xmi:uuid="dbf2ab70-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122501608_416494_38621"/>
      <ownedElement xmi:id="e0585100-7cad-0138-40ff-418b172fba9f" xmi:uuid="e05851f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122501608_416494_38621"/>
        <text>AssignedAnalysis:AnalysisVersion</text>
      </ownedElement>
      <ownedElement xmi:id="e05a4060-7cad-0138-40ff-418b172fba9f" xmi:uuid="e05a4140-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122501608_416494_38621"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570727531363_202943_44582" xmi:uuid="dbf26cd0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727531350_445591_44578"/>
        <ownedElement xmi:id="57a0c050-6c43-013d-931d-0800270c66d6" xmi:uuid="57a0c0f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727531350_445591_44578"/>
          <bounds x="288" y="781" width="185" height="13"/>
          <text>analysisVersion : Analysis_version [1]</text>
        </ownedElement>
        <bounds x="270" y="790" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="784" width="243" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570725641089_201301_43290" xmi:uuid="dbf34f20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122527429_917656_38625"/>
      <ownedElement xmi:id="e05df500-7cad-0138-40ff-418b172fba9f" xmi:uuid="e05df580-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122527429_917656_38625"/>
        <text>AssignedTo:AnalysisAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e05fabf0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e05fac40-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559122527429_917656_38625"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570727524456_630023_44555" xmi:uuid="dbf317e0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727524445_1920_44551"/>
        <ownedElement xmi:id="580e10f0-6c43-013d-931d-0800270c66d6" xmi:uuid="580e1190-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727524445_1920_44551"/>
          <bounds x="312" y="829" width="222" height="13"/>
          <text>analysisAssignmentSelect : analysed_item [1]</text>
        </ownedElement>
        <bounds x="293" y="838" width="16" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="833" width="266" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570725641177_377725_43476" xmi:uuid="dbf3eff0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
      <ownedElement xmi:id="e07d9be0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e07d9c50-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
        <text>roleSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570737736286_570917_47093" xmi:uuid="dbf3d270-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="5a2845f0-6c43-013d-931d-0800270c66d6" xmi:uuid="5a284690-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="311" y="657" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="293" y="666" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="119" y="644" width="189" height="51"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570725641193_316906_43496" xmi:uuid="dbf49840-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
      <ownedElement xmi:id="e0a99e80-7cad-0138-40ff-418b172fba9f" xmi:uuid="e0a99f00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570873591923_760471_60038" xmi:uuid="dbf47680-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="5cb32490-6c43-013d-931d-0800270c66d6" xmi:uuid="5cb32530-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="239" y="406" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="229" y="388" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="56" y="350" width="245" height="53"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570725641206_908905_43516" xmi:uuid="dbf52b50-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
      <ownedElement xmi:id="e0d64fb0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e0d65040-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_6b1022a_1570736509444_138167_46501" xmi:uuid="dbf51290-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="5ed2ab10-6c43-013d-931d-0800270c66d6" xmi:uuid="5ed2abb0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="381" y="66" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="363" y="75" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="217" y="56" width="161" height="51"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570726720345_396600_43650" xmi:uuid="dbf53c80-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570726720319_878378_43649"/>
      <ownedElement xmi:id="e0f6f5f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e0f6f7b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570726720319_878378_43649"/>
        <text>analysisAsng:Analysis_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e0f8c2b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e0f8c300-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570726720319_878378_43649"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="5faa26b0-6c43-013d-931d-0800270c66d6" xmi:uuid="5faa2750-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="5faac690-6c43-013d-931d-0800270c66d6" xmi:uuid="5faac700-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570726737555_175265_43685" xmi:uuid="e12ad930-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_assignment-analysis"/>
          <ownedElement xmi:id="e11990c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e1199140-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_assignment-analysis"/>
            <text>analysis:Analysis_version</text>
          </ownedElement>
          <ownedElement xmi:id="e12a54c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e12a5540-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_assignment-analysis"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="784" width="179" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570726737565_638985_43716" xmi:uuid="e15c90e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_assignment-applied_to"/>
          <ownedElement xmi:id="e14b3570-7cad-0138-40ff-418b172fba9f" xmi:uuid="e14b35e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_assignment-applied_to"/>
            <text>applied_to:analysed_item</text>
          </ownedElement>
          <ownedElement xmi:id="e15c13c0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e15c1430-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Analysis_assignment-applied_to"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="861" y="833" width="176" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="840" y="749" width="232" height="121"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570727618375_678047_44614" xmi:uuid="dbf54560-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727620054_939359_44615"/>
      <source xmi:idref="_18_4_1_6b1022a_1570726737555_175265_43685"/>
      <target xmi:idref="_18_4_1_6b1022a_1570727531363_202943_44582"/>
      <waypoint x="861" y="795"/>
      <waypoint x="285" y="795"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570727627100_56839_44636" xmi:uuid="dbf54e80-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570727628645_724814_44637"/>
      <source xmi:idref="_18_4_1_6b1022a_1570726737565_638985_43716"/>
      <target xmi:idref="_18_4_1_6b1022a_1570727524456_630023_44555"/>
      <waypoint x="861" y="847"/>
      <waypoint x="309" y="847"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570729082428_383025_45394" xmi:uuid="ca4cf350-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570729086638_587091_45395"/>
      <source xmi:idref="_18_4_1_6b1022a_1570726720345_396600_43650"/>
      <target xmi:idref="_18_4_1_6b1022a_1570729012349_236971_45324"/>
      <waypoint x="921" y="749"/>
      <waypoint x="921" y="389"/>
      <waypoint x="812" y="389"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570729002594_328329_45258" xmi:uuid="dbf55b20-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570729002583_89122_45257"/>
      <ownedElement xmi:id="e16dcf20-7cad-0138-40ff-418b172fba9f" xmi:uuid="e16dcfa0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570729002583_89122_45257"/>
        <text>desc:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e16f9b50-7cad-0138-40ff-418b172fba9f" xmi:uuid="e16f9b90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570729002583_89122_45257"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="63cdc670-6c43-013d-931d-0800270c66d6" xmi:uuid="63cdc710-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="63dfee20-6c43-013d-931d-0800270c66d6" xmi:uuid="63dfef20-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570729012333_677738_45293" xmi:uuid="e1a2dc50-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="e19159a0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e1915a10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="e1a25e70-7cad-0138-40ff-418b172fba9f" xmi:uuid="e1a25ee0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="630" y="413" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570729012349_236971_45324" xmi:uuid="e1d47aa0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="e1c2cc70-7cad-0138-40ff-418b172fba9f" xmi:uuid="e1c2ccf0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="e1d3ff70-7cad-0138-40ff-418b172fba9f" xmi:uuid="e1d3fff0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="637" y="378" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="609" y="350" width="266" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570729164636_284033_45423" xmi:uuid="dbf566c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570729164626_324134_45422"/>
      <ownedElement xmi:id="e1e63850-7cad-0138-40ff-418b172fba9f" xmi:uuid="e1e63970-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570729164626_324134_45422"/>
        <text>descripText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="e1e80580-7cad-0138-40ff-418b172fba9f" xmi:uuid="e1e805d0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570729164626_324134_45422"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="6807d830-6c43-013d-931d-0800270c66d6" xmi:uuid="6807d8c0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="680879e0-6c43-013d-931d-0800270c66d6" xmi:uuid="68087a50-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570729178517_932770_45458" xmi:uuid="e20b4b30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="e1f9f200-7cad-0138-40ff-418b172fba9f" xmi:uuid="e1f9f270-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="e20ace70-7cad-0138-40ff-418b172fba9f" xmi:uuid="e20acef0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="343" y="434" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="322" y="399" width="207" height="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570729222106_709190_45528" xmi:uuid="dbf56e30-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570729223118_260972_45529"/>
      <source xmi:idref="_18_4_1_6b1022a_1570729012333_677738_45293"/>
      <target xmi:idref="_18_4_1_6b1022a_1570729164636_284033_45423"/>
      <waypoint x="630" y="424"/>
      <waypoint x="529" y="424"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570737440177_317369_46896" xmi:uuid="cb0f1410-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570737445911_523518_46897"/>
      <source xmi:idref="_18_4_1_6b1022a_1570726720345_396600_43650"/>
      <target xmi:idref="_18_4_1_6b1022a_1570737304353_510626_46848"/>
      <waypoint x="921" y="749"/>
      <waypoint x="921" y="158"/>
      <waypoint x="799" y="158"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570736552352_283329_46540" xmi:uuid="dbf58690-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570736552340_199266_46539"/>
      <ownedElement xmi:id="e21cc170-7cad-0138-40ff-418b172fba9f" xmi:uuid="e21cc1f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570736552340_199266_46539"/>
        <text>ident:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e21e93e0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e21e9490-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570736552340_199266_46539"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="6a2f2b70-6c43-013d-931d-0800270c66d6" xmi:uuid="6a2f2c10-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="6a576820-6c43-013d-931d-0800270c66d6" xmi:uuid="6a5768e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570736559258_166393_46606" xmi:uuid="e2424080-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="e230c1f0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e230c270-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="e241c220-7cad-0138-40ff-418b172fba9f" xmi:uuid="e241c2a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="616" y="70" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570736559268_345033_46637" xmi:uuid="e2645a60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="e2531aa0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e2531b10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="e263dd20-7cad-0138-40ff-418b172fba9f" xmi:uuid="e263dd90-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="616" y="105" width="94" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570737304353_510626_46848" xmi:uuid="e2969ff0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="e2852bd0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e2852c60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e2961400-7cad-0138-40ff-418b172fba9f" xmi:uuid="e2961470-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="616" y="140" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="42" width="266" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570736633857_691143_46697" xmi:uuid="dbf58eb0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570736635303_414262_46698"/>
      <source xmi:idref="_18_4_1_6b1022a_1570736559258_166393_46606"/>
      <target xmi:idref="_18_4_1_6b1022a_1570736509444_138167_46501"/>
      <waypoint x="616" y="81"/>
      <waypoint x="378" y="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570737174422_248046_46787" xmi:uuid="dbf59980-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570737174411_669869_46786"/>
      <ownedElement xmi:id="e298e460-7cad-0138-40ff-418b172fba9f" xmi:uuid="e298e4e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570737174411_669869_46786"/>
        <text>identif:String</text>
      </ownedElement>
      <ownedElement xmi:id="e29ac780-7cad-0138-40ff-418b172fba9f" xmi:uuid="e29ac7f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570737174411_669869_46786"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="420" y="105" width="129" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570737204565_51883_46828" xmi:uuid="dbf5a0d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570737206191_815154_46829"/>
      <source xmi:idref="_18_4_1_6b1022a_1570736559268_345033_46637"/>
      <target xmi:idref="_18_4_1_6b1022a_1570737174422_248046_46787"/>
      <waypoint x="616" y="116"/>
      <waypoint x="549" y="116"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570738037108_200579_47216" xmi:uuid="dbf5a7d0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570738038560_780067_47217"/>
      <source xmi:idref="_18_4_1_6b1022a_1570737929903_486420_47193"/>
      <target xmi:idref="_18_4_1_6b1022a_1570726720345_396600_43650"/>
      <waypoint x="1105" y="753"/>
      <waypoint x="1072" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571679086623_528023_46637" xmi:uuid="cb773f40-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571679090779_637979_46638"/>
      <source xmi:idref="_18_4_1_6b1022a_1570726720345_396600_43650"/>
      <target xmi:idref="_18_4_1_6b1022a_1570873299689_232198_59900"/>
      <waypoint x="921" y="749"/>
      <waypoint x="921" y="228"/>
      <waypoint x="785" y="228"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570873247231_370880_59869" xmi:uuid="dbf5b4c0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
      <ownedElement xmi:id="e2b9c510-7cad-0138-40ff-418b172fba9f" xmi:uuid="e2b9c590-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e2c89210-7cad-0138-40ff-418b172fba9f" xmi:uuid="e2c89290-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="70acf010-6c43-013d-931d-0800270c66d6" xmi:uuid="70acf0b0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="70cda510-6c43-013d-931d-0800270c66d6" xmi:uuid="70cda5e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570873299689_232198_59900" xmi:uuid="e2fadf60-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="e2e98df0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e2e98e70-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e2fa6320-7cad-0138-40ff-418b172fba9f" xmi:uuid="e2fa63a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="602" y="217" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="189" width="266" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571679096374_324419_46656" xmi:uuid="cbd2d3f0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571679104038_362905_46657"/>
      <source xmi:idref="_18_4_1_6b1022a_1570726720345_396600_43650"/>
      <target xmi:idref="_18_4_1_6b1022a_1570873391721_236083_59966"/>
      <waypoint x="921" y="749"/>
      <waypoint x="921" y="305"/>
      <waypoint x="779" y="305"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570873356556_339586_59935" xmi:uuid="dbf5c110-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
      <ownedElement xmi:id="e31ae940-7cad-0138-40ff-418b172fba9f" xmi:uuid="e31ae9c0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e32a0080-7cad-0138-40ff-418b172fba9f" xmi:uuid="e32a0100-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="75220660-6c43-013d-931d-0800270c66d6" xmi:uuid="75220710-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="75350150-6c43-013d-931d-0800270c66d6" xmi:uuid="753503a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570873391721_236083_59966" xmi:uuid="e35cebe0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="e34b5f60-7cad-0138-40ff-418b172fba9f" xmi:uuid="e34b6080-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e35c6370-7cad-0138-40ff-418b172fba9f" xmi:uuid="e35c63f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="595" y="294" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="581" y="266" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570873591922_212778_60035" xmi:uuid="dbf5c870-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570729210686_136141_45507"/>
      <source xmi:idref="_18_4_1_6b1022a_1570729178517_932770_45458"/>
      <target xmi:idref="_18_4_1_6b1022a_1570873591923_760471_60038"/>
      <waypoint x="343" y="448"/>
      <waypoint x="235" y="448"/>
      <waypoint x="235" y="403"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570873857480_908376_60215" xmi:uuid="cc30eee0-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570873858798_918526_60216"/>
      <source xmi:idref="_18_4_1_6b1022a_1570729164636_284033_45423"/>
      <target xmi:idref="_18_4_1_6b1022a_1570873744221_425732_60141"/>
      <waypoint x="431" y="399"/>
      <waypoint x="431" y="319"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570873705728_861580_60110" xmi:uuid="dbf5d4f0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
      <ownedElement xmi:id="e37c4a10-7cad-0138-40ff-418b172fba9f" xmi:uuid="e37c4aa0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="e38b3b60-7cad-0138-40ff-418b172fba9f" xmi:uuid="e38b3bd0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="789a0ab0-6c43-013d-931d-0800270c66d6" xmi:uuid="789a0b80-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="78bc7580-6c43-013d-931d-0800270c66d6" xmi:uuid="78bc7650-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570873744221_425732_60141" xmi:uuid="e3be1a10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="e3ac4770-7cad-0138-40ff-418b172fba9f" xmi:uuid="e3ac47f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="e3bd9990-7cad-0138-40ff-418b172fba9f" xmi:uuid="e3bd9a10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="259" y="294" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="252" y="266" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570874291544_607494_60435" xmi:uuid="cc9a8950-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570874294383_39025_60436"/>
      <source xmi:idref="_18_4_1_6b1022a_1570726720345_396600_43650"/>
      <target xmi:idref="_18_4_1_6b1022a_1570873914627_691515_60260"/>
      <waypoint x="921" y="749"/>
      <waypoint x="921" y="522"/>
      <waypoint x="770" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570873888734_828355_60227" xmi:uuid="dbf5e060-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
      <ownedElement xmi:id="e3dd6610-7cad-0138-40ff-418b172fba9f" xmi:uuid="e3dd6690-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e3ec5f20-7cad-0138-40ff-418b172fba9f" xmi:uuid="e3ec6040-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="7c1c9b30-6c43-013d-931d-0800270c66d6" xmi:uuid="7c1c9bd0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7c4e25c0-6c43-013d-931d-0800270c66d6" xmi:uuid="7c4e2680-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570873914627_691515_60260" xmi:uuid="e41f4170-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="e40dc1b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e40dc230-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="e41ec740-7cad-0138-40ff-418b172fba9f" xmi:uuid="e41ec7b0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="595" y="504" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="581" y="476" width="315" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570874283150_341519_60416" xmi:uuid="cd0ebd60-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570874285191_517852_60417"/>
      <source xmi:idref="_18_4_1_6b1022a_1570726720345_396600_43650"/>
      <target xmi:idref="_18_4_1_6b1022a_1570874148138_890624_60360"/>
      <waypoint x="921" y="749"/>
      <waypoint x="921" y="599"/>
      <waypoint x="786" y="599"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570874125025_204174_60329" xmi:uuid="dbf5ece0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
      <ownedElement xmi:id="e43e4e40-7cad-0138-40ff-418b172fba9f" xmi:uuid="e43e4ec0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e44d6220-7cad-0138-40ff-418b172fba9f" xmi:uuid="e44d63f0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="7fd2d550-6c43-013d-931d-0800270c66d6" xmi:uuid="7fd2d610-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="7fd37ac0-6c43-013d-931d-0800270c66d6" xmi:uuid="7fd37b60-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570874148138_890624_60360" xmi:uuid="e4802380-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="e46e6bc0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e46e6c30-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e47fa0b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e47fa130-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="602" y="588" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="560" width="254" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570875676224_671421_60570" xmi:uuid="dbf5f170-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509987065721_230294_25388"/>
      <bounds x="420" y="14" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570875774435_360399_60636" xmi:uuid="dbf5fdb0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570875774409_298016_60635"/>
      <ownedElement xmi:id="e4922970-7cad-0138-40ff-418b172fba9f" xmi:uuid="e49229e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570875774409_298016_60635"/>
        <text>role:Class</text>
      </ownedElement>
      <ownedElement xmi:id="e49402b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e4940310-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570875774409_298016_60635"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="821be6a0-6c43-013d-931d-0800270c66d6" xmi:uuid="821be730-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="822a7eb0-6c43-013d-931d-0800270c66d6" xmi:uuid="822a7f70-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570875811621_802029_60672" xmi:uuid="e4b70360-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-description"/>
          <ownedElement xmi:id="e4a5dc90-7cad-0138-40ff-418b172fba9f" xmi:uuid="e4a5dd10-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="e4b67c40-7cad-0138-40ff-418b172fba9f" xmi:uuid="e4b67cc0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="392" y="665" width="147" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1570875811622_246911_60703" xmi:uuid="e4d8bd70-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="e4c7aa40-7cad-0138-40ff-418b172fba9f" xmi:uuid="e4c7aab0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="e4d83f90-7cad-0138-40ff-418b172fba9f" xmi:uuid="e4d84000-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="392" y="700" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="385" y="637" width="168" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570875850238_173144_60778" xmi:uuid="dbf60570-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570875851414_274471_60779"/>
      <source xmi:idref="_18_4_1_6b1022a_1570875811621_802029_60672"/>
      <target xmi:idref="_18_4_1_6b1022a_1570737736286_570917_47093"/>
      <waypoint x="392" y="672"/>
      <waypoint x="308" y="672"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1570875858128_516079_60800" xmi:uuid="dbf7fad0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570875860454_559323_60801"/>
      <source xmi:idref="_18_4_1_6b1022a_1570875811622_246911_60703"/>
      <target xmi:idref="_18_4_1_6b1022a_1570737736286_570917_47093"/>
      <waypoint x="392" y="711"/>
      <waypoint x="347" y="711"/>
      <waypoint x="347" y="672"/>
      <waypoint x="308" y="672"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571680522847_637651_48540" xmi:uuid="ce02d680-3276-0139-a8ba-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571680528674_485080_48541"/>
      <source xmi:idref="_18_4_1_6b1022a_1570726720345_396600_43650"/>
      <target xmi:idref="_18_4_1_6b1022a_1571680368111_233419_48413"/>
      <waypoint x="921" y="749"/>
      <waypoint x="921" y="711"/>
      <waypoint x="786" y="711"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571680304032_159348_48343" xmi:uuid="dbf80c10-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571680304015_645171_48342"/>
      <ownedElement xmi:id="e4ea42d0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e4ea4350-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571680304015_645171_48342"/>
        <text>roleAsgn2:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="e4ec0df0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e4ec0e50-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571680304015_645171_48342"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="85d7fdb0-6c43-013d-931d-0800270c66d6" xmi:uuid="85d7fe60-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="85fac300-6c43-013d-931d-0800270c66d6" xmi:uuid="85fac480-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1571680368110_696468_48382" xmi:uuid="e51f3ff0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="e50d8d90-7cad-0138-40ff-418b172fba9f" xmi:uuid="e50d8e00-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="e51eb680-7cad-0138-40ff-418b172fba9f" xmi:uuid="e51eb7e0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="602" y="665" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_6b1022a_1571680368111_233419_48413" xmi:uuid="e5508660-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="e53f27b0-7cad-0138-40ff-418b172fba9f" xmi:uuid="e53f2830-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="e5500930-7cad-0138-40ff-418b172fba9f" xmi:uuid="e55009a0-7cad-0138-40ff-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="602" y="700" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="637" width="254" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_6b1022a_1571680515224_571217_48521" xmi:uuid="dbf814b0-3aa4-0138-3ecf-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1571680516942_880470_48522"/>
      <source xmi:idref="_18_4_1_6b1022a_1571680368110_696468_48382"/>
      <target xmi:idref="_18_4_1_6b1022a_1570875774435_360399_60636"/>
      <waypoint x="602" y="676"/>
      <waypoint x="553" y="676"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1108" height="885"/>
    <name>AnalysisAssignment</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446166195_512608_136511" xmi:uuid="e7af8ec0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166213_692395_136543" xmi:uuid="ed5e1410-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570738635733_824260_47588"/>
      <ownedElement xmi:id="ed2e0160-6c43-013d-931d-0800270c66d6" xmi:uuid="ed2e0290-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570738635733_824260_47588"/>
        <text>analysisDisDef:Analysis_discipline_definition</text>
      </ownedElement>
      <ownedElement xmi:id="ed5dfaf0-6c43-013d-931d-0800270c66d6" xmi:uuid="ed5dfbe0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570738635733_824260_47588"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="277" height="250"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166226_138331_136577" xmi:uuid="ed5ed5e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="650" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166245_409880_136598" xmi:uuid="ed5fac00-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="650" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166262_404421_136619" xmi:uuid="ed609ed0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="650" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166280_346313_136640" xmi:uuid="ed920310-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="650" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166302_966682_136661" xmi:uuid="ed92c6c0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="650" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166335_145239_136682" xmi:uuid="ed939a40-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="650" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166353_11345_136703" xmi:uuid="ed9459e0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="650" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166369_31157_136724" xmi:uuid="edc7ba80-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617827640985_278383_78681"/>
      <bounds x="650" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166382_692940_136745" xmi:uuid="edc878f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617828135267_554790_78798"/>
      <bounds x="650" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446166397_145559_136766" xmi:uuid="edd8c5a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="650" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480446_964239_378281" xmi:uuid="edd8d7c0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035212349_569676_67532"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166226_138331_136577"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166213_692395_136543"/>
      <waypoint x="650" y="62"/>
      <waypoint x="322" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480446_342996_378284" xmi:uuid="edd8e1f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606489185480_438586_67811"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166245_409880_136598"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166213_692395_136543"/>
      <waypoint x="650" y="82"/>
      <waypoint x="322" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480446_491634_378287" xmi:uuid="edd8e960-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606489193611_674744_67855"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166262_404421_136619"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166213_692395_136543"/>
      <waypoint x="650" y="102"/>
      <waypoint x="322" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480446_805_378290" xmi:uuid="edd8f0c0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035208264_933230_67512"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166280_346313_136640"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166213_692395_136543"/>
      <waypoint x="650" y="122"/>
      <waypoint x="322" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480446_520430_378293" xmi:uuid="edd8faf0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035216276_980568_67552"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166302_966682_136661"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166213_692395_136543"/>
      <waypoint x="650" y="142"/>
      <waypoint x="322" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480446_323872_378296" xmi:uuid="edd901d0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606489189490_453743_67833"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166335_145239_136682"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166213_692395_136543"/>
      <waypoint x="650" y="162"/>
      <waypoint x="322" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480446_971817_378299" xmi:uuid="edd90a40-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606489181486_452766_67789"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166353_11345_136703"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166213_692395_136543"/>
      <waypoint x="650" y="182"/>
      <waypoint x="322" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480446_547558_378302" xmi:uuid="edd911f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035220190_802453_67572"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166369_31157_136724"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166213_692395_136543"/>
      <waypoint x="650" y="202"/>
      <waypoint x="322" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480446_363576_378305" xmi:uuid="edf047f0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1662035223766_166635_67592"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166382_692940_136745"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166213_692395_136543"/>
      <waypoint x="650" y="222"/>
      <waypoint x="322" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480446_575957_378308" xmi:uuid="edf064c0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_2b2015d_1606489197493_822182_67877"/>
      <source xmi:idref="_18_4_1_65b021e_1727446166397_145559_136766"/>
      <target xmi:idref="_18_4_1_65b021e_1727446166213_692395_136543"/>
      <waypoint x="650" y="242"/>
      <waypoint x="322" y="242"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="653" height="320"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446167450_497106_138212" xmi:uuid="f34d9ff0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Analysis.xmi#_18_4_1_8e001ed_1559121202797_964567_13780"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167468_687321_138244" xmi:uuid="f3dc5d70-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
      <ownedElement xmi:id="f3dae750-6c43-013d-931d-0800270c66d6" xmi:uuid="f3dae830-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
        <text>analMod:Analysis_model</text>
      </ownedElement>
      <ownedElement xmi:id="f3dc4d50-6c43-013d-931d-0800270c66d6" xmi:uuid="f3dc4e60-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Analysis.xmi#_18_4_1_6b1022a_1570740799251_465262_48218"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="175" height="170"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167486_32665_138280" xmi:uuid="f3dd05d0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="545" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167508_131882_138303" xmi:uuid="f3ddb790-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="545" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167531_900262_138326" xmi:uuid="f41bc690-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="545" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167554_857062_138349" xmi:uuid="f42b35a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="545" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167575_567777_138372" xmi:uuid="f43eae90-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="545" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446167592_10388_138395" xmi:uuid="f43f74a0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="545" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480607_525836_378851" xmi:uuid="f43f8610-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600938608_617471_105695"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167486_32665_138280"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167468_687321_138244"/>
      <waypoint x="545" y="62"/>
      <waypoint x="220" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480607_395701_378854" xmi:uuid="f43f8ea0-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600938727_795419_105719"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167508_131882_138303"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167468_687321_138244"/>
      <waypoint x="545" y="82"/>
      <waypoint x="220" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480607_748637_378863" xmi:uuid="f43f9690-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600938832_506780_105743"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167531_900262_138326"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167468_687321_138244"/>
      <waypoint x="545" y="102"/>
      <waypoint x="220" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480607_603176_378866" xmi:uuid="f4522b90-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600938938_85939_105767"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167554_857062_138349"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167468_687321_138244"/>
      <waypoint x="545" y="122"/>
      <waypoint x="220" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480607_460974_378875" xmi:uuid="f4523920-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600939044_996135_105791"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167575_567777_138372"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167468_687321_138244"/>
      <waypoint x="545" y="142"/>
      <waypoint x="220" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446480607_325691_378878" xmi:uuid="f4524020-6c43-013d-931d-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Analysis.xmi#_18_4_1_65b021e_1696600939153_455612_105815"/>
      <source xmi:idref="_18_4_1_65b021e_1727446167592_10388_138395"/>
      <target xmi:idref="_18_4_1_65b021e_1727446167468_687321_138244"/>
      <waypoint x="545" y="162"/>
      <waypoint x="220" y="162"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="548" height="240"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
