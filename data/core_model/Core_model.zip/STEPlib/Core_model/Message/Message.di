<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_2b2015d_1539766324837_461434_14465" xmi:uuid="460c67f0-3aa6-0138-3edd-418b172fba9f">
    <base_UMLClassDiagram xmi:idref="_18_4_1_2b2015d_1539766324792_920805_14453"/>
    <defaultNamespace href="Message.xmi#_18_4_1_8e001ed_1498551967680_699600_14130"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703184404078_925369_371589" xmi:uuid="832d1db0-9159-013c-7154-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703184404073_521892_371578"/>
    <defaultNamespace href="Message.xmi#_18_4_1_8e001ed_1498551967680_699600_14130"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703184598699_658977_388126" xmi:uuid="c874fc00-9159-013c-7154-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703184598694_636168_388115"/>
    <defaultNamespace href="Message.xmi#_18_4_1_8e001ed_1498551967680_699600_14130"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446295702_853850_279467" xmi:uuid="00d57fd0-6c46-013d-d602-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446295695_950799_279456"/>
    <defaultNamespace href="Message.xmi#_18_4_1_2b2015d_1539766477342_290236_14489"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446295230_625453_278858" xmi:uuid="1ef8a750-6c46-013d-d602-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446295223_640180_278847"/>
    <defaultNamespace href="Message.xmi#_18_4_1_2b2015d_1539767899339_172189_31799"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446295096_842866_278710" xmi:uuid="40f88c70-6c46-013d-d602-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446295089_711822_278699"/>
    <defaultNamespace href="Message.xmi#_ExchangeContext"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1539793524208_628622_46898" xmi:uuid="46766670-3aa6-0138-3edd-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1539793524204_169634_46887"/>
    <defaultNamespace href="Message.xmi#_18_4_1_2b2015d_1539768315078_454856_32209"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1539787860752_685046_40303" xmi:uuid="467d18a0-3aa6-0138-3edd-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1539787860748_232271_40292"/>
    <defaultNamespace href="Message.xmi#_18_4_1_2b2015d_1539767618244_553303_31517"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1539771646870_128955_32545" xmi:uuid="4686df10-3aa6-0138-3edd-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1539771646867_616142_32534"/>
    <defaultNamespace href="Message.xmi#_18_4_1_2b2015d_1539766477342_290236_14489"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1539789584911_778521_42510" xmi:uuid="4694b720-3aa6-0138-3edd-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1539789584907_213547_42499"/>
    <defaultNamespace href="Message.xmi#_18_4_1_2b2015d_1539767899339_172189_31799"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_2b2015d_1539947610159_5036_32651" xmi:uuid="469b9b50-3aa6-0138-3edd-418b172fba9f">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_2b2015d_1539947610153_137013_32640"/>
    <defaultNamespace href="Message.xmi#_ExchangeContext"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446295441_457554_279110" xmi:uuid="472e36e0-6c46-013d-d602-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446295433_115362_279099"/>
    <defaultNamespace href="Message.xmi#_18_4_1_2b2015d_1583496521130_514720_53768"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_271a0567_1607333943739_359406_74314" xmi:uuid="762c73f0-327f-0139-a8c9-34a9fcdfa563">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_271a0567_1607333943724_332533_74303"/>
    <defaultNamespace href="Message.xmi#_18_4_1_2b2015d_1583496521130_514720_53768"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446295509_948671_279215" xmi:uuid="bf3db4d0-6c45-013d-d602-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446295503_615551_279204"/>
    <defaultNamespace href="Message.xmi#_18_4_1_2b2015d_1539768315078_454856_32209"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446296144_553348_279930" xmi:uuid="e17c26f0-6c45-013d-d602-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446296137_343936_279919"/>
    <defaultNamespace href="Message.xmi#_18_4_1_2b2015d_1539767618244_553303_31517"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703184404073_521892_371578" xmi:uuid="832c5250-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Message.xmi#_18_4_1_8e001ed_1498551967680_699600_14130"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184404124_380440_371611" xmi:uuid="8336dbb0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767819677_98372_31714"/>
      <ownedElement xmi:id="83341b10-9159-013c-7154-0a5172f4a469" xmi:uuid="83341c30-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767819677_98372_31714"/>
        <text>MessageContentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="83353560-9159-013c-7154-0a5172f4a469" xmi:uuid="83353640-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="8335f220-9159-013c-7154-0a5172f4a469" xmi:uuid="8335f380-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1283" height="2055"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184404260_615460_371657" xmi:uuid="833da3d0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1583496521130_514720_53768"/>
      <ownedElement xmi:id="83385940-9159-013c-7154-0a5172f4a469" xmi:uuid="83385aa0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1583496521130_514720_53768"/>
        <text>Acknowledgement</text>
      </ownedElement>
      <ownedElement xmi:id="e1ea7b30-6c41-013d-d602-0800270c66d6" xmi:uuid="e1ea7c40-6c41-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="203" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184406034_183982_371728" xmi:uuid="83807ee0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_Activity"/>
      <ownedElement xmi:id="8344f460-9159-013c-7154-0a5172f4a469" xmi:uuid="8344fb10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_Activity"/>
        <text>Activity</text>
      </ownedElement>
      <ownedElement xmi:id="e7347550-6c41-013d-d602-0800270c66d6" xmi:uuid="e7347690-6c41-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="288" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184407498_987336_371822" xmi:uuid="83bfda20-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
      <ownedElement xmi:id="8382bcb0-9159-013c-7154-0a5172f4a469" xmi:uuid="8382bdb0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Activity/Activity.xmi#_ActivityMethod"/>
        <text>ActivityMethod</text>
      </ownedElement>
      <ownedElement xmi:id="eab110d0-6c41-013d-d602-0800270c66d6" xmi:uuid="eab11170-6c41-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="501" y="95" width="193" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184408653_852748_371892" xmi:uuid="84a912a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1506065878812_287574_26453"/>
      <ownedElement xmi:id="83d74fe0-9159-013c-7154-0a5172f4a469" xmi:uuid="83d75110-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1506065878812_287574_26453"/>
        <text>AddressComponent</text>
      </ownedElement>
      <ownedElement xmi:id="fa968c70-6c41-013d-d602-0800270c66d6" xmi:uuid="fa968d10-6c41-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="714" y="95" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184409058_952790_371936" xmi:uuid="84c54240-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584026209542_799048_66427"/>
      <ownedElement xmi:id="84b4d5a0-9159-013c-7154-0a5172f4a469" xmi:uuid="84b4d8f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584026209542_799048_66427"/>
        <text>AdvisoryNote</text>
      </ownedElement>
      <ownedElement xmi:id="0e484730-6c42-013d-d602-0800270c66d6" xmi:uuid="0e4847d0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="145" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184410615_536645_372004" xmi:uuid="84e5cb10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
      <ownedElement xmi:id="84c9caa0-9159-013c-7154-0a5172f4a469" xmi:uuid="84c9cbb0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121131880_105613_13772"/>
        <text>Analysis</text>
      </ownedElement>
      <ownedElement xmi:id="0f835f00-6c42-013d-d602-0800270c66d6" xmi:uuid="0f835f90-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="323" y="145" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184412326_112643_372066" xmi:uuid="85026400-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
      <ownedElement xmi:id="84e7fc90-9159-013c-7154-0a5172f4a469" xmi:uuid="84e7fe50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121193212_276677_13778"/>
        <text>AnalysisDisciplineDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="10df6c00-6c42-013d-d602-0800270c66d6" xmi:uuid="10df6c70-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="542" y="145" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184413442_476662_372134" xmi:uuid="8517c550-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121223171_313016_13784"/>
      <ownedElement xmi:id="850422a0-9159-013c-7154-0a5172f4a469" xmi:uuid="850423c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121223171_313016_13784"/>
        <text>AnalysisModelObject</text>
      </ownedElement>
      <ownedElement xmi:id="123297c0-6c42-013d-d602-0800270c66d6" xmi:uuid="12329870-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="761" y="145" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184414354_960789_372203" xmi:uuid="852e5320-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121230940_899251_13786"/>
      <ownedElement xmi:id="8519a230-9159-013c-7154-0a5172f4a469" xmi:uuid="8519a380-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121230940_899251_13786"/>
        <text>AnalysisRepresentationContext</text>
      </ownedElement>
      <ownedElement xmi:id="134af430-6c42-013d-d602-0800270c66d6" xmi:uuid="134af4c0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="980" y="145" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184415876_795028_372288" xmi:uuid="8545d8f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
      <ownedElement xmi:id="85300f60-9159-013c-7154-0a5172f4a469" xmi:uuid="853010a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Analysis/Analysis.xmi#_18_4_1_8e001ed_1559121240506_273076_13788"/>
        <text>AnalysisVersion</text>
      </ownedElement>
      <ownedElement xmi:id="142f23c0-6c42-013d-d602-0800270c66d6" xmi:uuid="142f2450-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="195" width="199" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184416061_740462_372335" xmi:uuid="857aaf10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ApplicationDomain"/>
      <ownedElement xmi:id="8556cb60-9159-013c-7154-0a5172f4a469" xmi:uuid="8556ccb0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ApplicationDomain"/>
        <text>ApplicationDomain</text>
      </ownedElement>
      <ownedElement xmi:id="19ad54d0-6c42-013d-d602-0800270c66d6" xmi:uuid="19ad5580-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="284" y="195" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184417130_841837_372400" xmi:uuid="86357600-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Approval"/>
      <ownedElement xmi:id="85835390-9159-013c-7154-0a5172f4a469" xmi:uuid="858354d0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Approval"/>
        <text>Approval</text>
      </ownedElement>
      <ownedElement xmi:id="1bd95510-6c42-013d-d602-0800270c66d6" xmi:uuid="1bd955b0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="586" y="195" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184418022_593941_372458" xmi:uuid="87404e60-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_AssignmentObject"/>
      <ownedElement xmi:id="86600880-9159-013c-7154-0a5172f4a469" xmi:uuid="86600990-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_AssignmentObject"/>
        <text>AssignmentObject</text>
      </ownedElement>
      <ownedElement xmi:id="2984daa0-6c42-013d-d602-0800270c66d6" xmi:uuid="2984db40-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="881" y="195" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184418772_916447_372511" xmi:uuid="87e01f50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_AssociationObject"/>
      <ownedElement xmi:id="874d1a50-9159-013c-7154-0a5172f4a469" xmi:uuid="874d1b80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_AssociationObject"/>
        <text>AssociationObject</text>
      </ownedElement>
      <ownedElement xmi:id="342ae330-6c42-013d-d602-0800270c66d6" xmi:uuid="342ae3c0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="245" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184419703_197840_372570" xmi:uuid="8867dc40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582537070783_531551_57175"/>
      <ownedElement xmi:id="87e75540-9159-013c-7154-0a5172f4a469" xmi:uuid="87e75640-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582537070783_531551_57175"/>
        <text>Assumption</text>
      </ownedElement>
      <ownedElement xmi:id="3b3ff670-6c42-013d-d602-0800270c66d6" xmi:uuid="3b3ff700-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="341" y="245" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184421509_176662_372644" xmi:uuid="88d2a450-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_Breakdown"/>
      <ownedElement xmi:id="88737e50-9159-013c-7154-0a5172f4a469" xmi:uuid="88737f60-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_Breakdown"/>
        <text>Breakdown</text>
      </ownedElement>
      <ownedElement xmi:id="43eeb440-6c42-013d-d602-0800270c66d6" xmi:uuid="43eeb4e0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="636" y="245" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184423376_384143_372718" xmi:uuid="894898f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
      <ownedElement xmi:id="88d65440-9159-013c-7154-0a5172f4a469" xmi:uuid="88d65580-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
        <text>BreakdownElement</text>
      </ownedElement>
      <ownedElement xmi:id="48dd5a40-6c42-013d-d602-0800270c66d6" xmi:uuid="48dd5ad0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="869" y="245" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184424987_901390_372791" xmi:uuid="89876ee0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersion"/>
      <ownedElement xmi:id="894c2bb0-9159-013c-7154-0a5172f4a469" xmi:uuid="894c2cc0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementVersion"/>
        <text>BreakdownElementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="4dc32600-6c42-013d-d602-0800270c66d6" xmi:uuid="4dc326a0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="295" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184427097_171551_372874" xmi:uuid="89e3edf0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
      <ownedElement xmi:id="898b3470-9159-013c-7154-0a5172f4a469" xmi:uuid="898b3580-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElementView"/>
        <text>BreakdownElementView</text>
      </ownedElement>
      <ownedElement xmi:id="50c69550-6c42-013d-d602-0800270c66d6" xmi:uuid="50c695f0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="298" y="295" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184428385_242560_372945" xmi:uuid="8a1f03d0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersion"/>
      <ownedElement xmi:id="89e780c0-9159-013c-7154-0a5172f4a469" xmi:uuid="89e781d0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownVersion"/>
        <text>BreakdownVersion</text>
      </ownedElement>
      <ownedElement xmi:id="54efa1d0-6c42-013d-d602-0800270c66d6" xmi:uuid="54efa270-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="531" y="295" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184428692_440261_373001" xmi:uuid="8a482d30-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_CartesianTransformation"/>
      <ownedElement xmi:id="8a293cc0-9159-013c-7154-0a5172f4a469" xmi:uuid="8a293dd0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_CartesianTransformation"/>
        <text>CartesianTransformation</text>
      </ownedElement>
      <ownedElement xmi:id="586870d0-6c42-013d-d602-0800270c66d6" xmi:uuid="586871a0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="764" y="295" width="381" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184430108_304315_373073" xmi:uuid="8b4df8b0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Certification"/>
      <ownedElement xmi:id="8a51d530-9159-013c-7154-0a5172f4a469" xmi:uuid="8a51d6b0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Certification"/>
        <text>Certification</text>
      </ownedElement>
      <ownedElement xmi:id="5a67b050-6c42-013d-d602-0800270c66d6" xmi:uuid="5a67b0f0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="345" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184430972_915351_373132" xmi:uuid="8c3eb660-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Class"/>
      <ownedElement xmi:id="8b5d5320-9159-013c-7154-0a5172f4a469" xmi:uuid="8b5d5480-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Class"/>
        <text>Class</text>
      </ownedElement>
      <ownedElement xmi:id="65711b00-6c42-013d-d602-0800270c66d6" xmi:uuid="65711b90-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="360" y="345" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184432626_891713_373206" xmi:uuid="8d66b260-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_ClassAttribute"/>
      <ownedElement xmi:id="8c4c0270-9159-013c-7154-0a5172f4a469" xmi:uuid="8c4c03c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_ClassAttribute"/>
        <text>ClassAttribute</text>
      </ownedElement>
      <ownedElement xmi:id="70675410-6c42-013d-d602-0800270c66d6" xmi:uuid="706754a0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="636" y="345" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184433009_739974_373424" xmi:uuid="8df995e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Classification"/>
      <ownedElement xmi:id="8d731e30-9159-013c-7154-0a5172f4a469" xmi:uuid="8d732090-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Classification"/>
        <text>Classification</text>
      </ownedElement>
      <ownedElement xmi:id="7eebc900-6c42-013d-d602-0800270c66d6" xmi:uuid="7eebc9f0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="912" y="345" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184434625_767070_373501" xmi:uuid="8e27c520-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581927879268_726070_55882"/>
      <ownedElement xmi:id="8e0001b0-9159-013c-7154-0a5172f4a469" xmi:uuid="8e0002f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581927879268_726070_55882"/>
        <text>Collection</text>
      </ownedElement>
      <ownedElement xmi:id="8a516a10-6c42-013d-d602-0800270c66d6" xmi:uuid="8a516b90-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="395" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184436144_527725_373584" xmi:uuid="8e48e690-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
      <ownedElement xmi:id="8e29b4e0-9159-013c-7154-0a5172f4a469" xmi:uuid="8e29b5e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581928052738_473680_55970"/>
        <text>CollectionVersion</text>
      </ownedElement>
      <ownedElement xmi:id="8cb1e320-6c42-013d-d602-0800270c66d6" xmi:uuid="8cb1e3d0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="290" y="395" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184437631_731840_373665" xmi:uuid="8e67ae00-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
      <ownedElement xmi:id="8e4b0780-9159-013c-7154-0a5172f4a469" xmi:uuid="8e4b0890-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1581930529117_204097_56497"/>
        <text>CollectionView</text>
      </ownedElement>
      <ownedElement xmi:id="8e9ae840-6c42-013d-d602-0800270c66d6" xmi:uuid="8e9ae8e0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="515" y="395" width="205" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184438831_557255_373738" xmi:uuid="8e95d8a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_271a0567_1582708908241_345422_60207"/>
      <ownedElement xmi:id="8e6aecf0-9159-013c-7154-0a5172f4a469" xmi:uuid="8e6aee00-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_18_4_1_271a0567_1582708908241_345422_60207"/>
        <text>ComponentPlacement</text>
      </ownedElement>
      <ownedElement xmi:id="906c3230-6c42-013d-d602-0800270c66d6" xmi:uuid="906c32f0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="740" y="395" width="213" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184440506_858453_373826" xmi:uuid="9069fef0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Condition"/>
      <ownedElement xmi:id="8ea13f60-9159-013c-7154-0a5172f4a469" xmi:uuid="8ea14070-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Condition"/>
        <text>Condition</text>
      </ownedElement>
      <ownedElement xmi:id="93b12340-6c42-013d-d602-0800270c66d6" xmi:uuid="93b12410-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="973" y="395" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184442242_103320_373922" xmi:uuid="922ba080-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1525773433982_675004_29552"/>
      <ownedElement xmi:id="90787050-9159-013c-7154-0a5172f4a469" xmi:uuid="90787190-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1525773433982_675004_29552"/>
        <text>ConditionEvaluation</text>
      </ownedElement>
      <ownedElement xmi:id="a9d1a6d0-6c42-013d-d602-0800270c66d6" xmi:uuid="a9d1a770-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="445" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184443643_701151_374004" xmi:uuid="93aab870-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1529755756913_494204_31033"/>
      <ownedElement xmi:id="923a33e0-9159-013c-7154-0a5172f4a469" xmi:uuid="923a3520-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1529755756913_494204_31033"/>
        <text>ConditionEvaluationParameter</text>
      </ownedElement>
      <ownedElement xmi:id="bf98f490-6c42-013d-d602-0800270c66d6" xmi:uuid="bf98f530-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="341" y="445" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184444966_977452_374082" xmi:uuid="94f8e9f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_ConditionParameter"/>
      <ownedElement xmi:id="93b624d0-9159-013c-7154-0a5172f4a469" xmi:uuid="93b625e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_ConditionParameter"/>
        <text>ConditionParameter</text>
      </ownedElement>
      <ownedElement xmi:id="d0ac5e90-6c42-013d-d602-0800270c66d6" xmi:uuid="d0ac5f20-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="617" y="445" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184446847_599329_374167" xmi:uuid="95531e80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ConfiguredAssemblyEffectivity"/>
      <ownedElement xmi:id="95017c00-9159-013c-7154-0a5172f4a469" xmi:uuid="95017d30-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ConfiguredAssemblyEffectivity"/>
        <text>ConfiguredAssemblyEffectivity</text>
      </ownedElement>
      <ownedElement xmi:id="e2d3d410-6c42-013d-d602-0800270c66d6" xmi:uuid="e2d3d4c0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="893" y="445" width="340" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184447917_625074_374241" xmi:uuid="9603dcd0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Contract"/>
      <ownedElement xmi:id="955b99d0-9159-013c-7154-0a5172f4a469" xmi:uuid="955b9b20-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Contract"/>
        <text>Contract</text>
      </ownedElement>
      <ownedElement xmi:id="e8020140-6c42-013d-d602-0800270c66d6" xmi:uuid="e8020230-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="495" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184448906_710472_374685" xmi:uuid="970c7530-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Descriptor"/>
      <ownedElement xmi:id="9611f8d0-9159-013c-7154-0a5172f4a469" xmi:uuid="9611fa10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Descriptor"/>
        <text>Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="efe29350-6c42-013d-d602-0800270c66d6" xmi:uuid="efe293f0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="360" y="495" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184450754_379159_374785" xmi:uuid="9751f4e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_Document"/>
      <ownedElement xmi:id="971418e0-9159-013c-7154-0a5172f4a469" xmi:uuid="971419f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_Document"/>
        <text>Document</text>
      </ownedElement>
      <ownedElement xmi:id="fd206a60-6c42-013d-d602-0800270c66d6" xmi:uuid="fd206af0-6c42-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="636" y="495" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184452445_727522_374877" xmi:uuid="9785cb60-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
      <ownedElement xmi:id="97546ca0-9159-013c-7154-0a5172f4a469" xmi:uuid="97546da0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentDefinition"/>
        <text>DocumentDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="001e0da0-6c43-013d-d602-0800270c66d6" xmi:uuid="001e0e40-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="927" y="495" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184454093_706859_374980" xmi:uuid="97b00b90-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
      <ownedElement xmi:id="97886840-9159-013c-7154-0a5172f4a469" xmi:uuid="97886950-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_DocumentVersion"/>
        <text>DocumentVersion</text>
      </ownedElement>
      <ownedElement xmi:id="028ffb40-6c43-013d-d602-0800270c66d6" xmi:uuid="028ffbe0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="545" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184455397_679924_375075" xmi:uuid="98cee1c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Effectivity"/>
      <ownedElement xmi:id="97bb9830-9159-013c-7154-0a5172f4a469" xmi:uuid="97bb9960-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Effectivity"/>
        <text>Effectivity</text>
      </ownedElement>
      <ownedElement xmi:id="05413a80-6c43-013d-d602-0800270c66d6" xmi:uuid="05413b20-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="356" y="545" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184456265_903297_375144" xmi:uuid="98d89cb0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767618244_553303_31517"/>
      <ownedElement xmi:id="98d02db0-9159-013c-7154-0a5172f4a469" xmi:uuid="98d02eb0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767618244_553303_31517"/>
        <text>Envelope</text>
      </ownedElement>
      <ownedElement xmi:id="13633820-6c43-013d-d602-0800270c66d6" xmi:uuid="136338d0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="632" y="545" width="203" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184457656_823407_375238" xmi:uuid="99e27800-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8f301ed_1516977263264_577994_33260"/>
      <ownedElement xmi:id="98e49200-9159-013c-7154-0a5172f4a469" xmi:uuid="98e49320-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8f301ed_1516977263264_577994_33260"/>
        <text>Environment</text>
      </ownedElement>
      <ownedElement xmi:id="14fee290-6c43-013d-d602-0800270c66d6" xmi:uuid="14fee330-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="855" y="545" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184458919_30307_375328" xmi:uuid="9aaf6300-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517519025218_303969_34416"/>
      <ownedElement xmi:id="99ee2260-9159-013c-7154-0a5172f4a469" xmi:uuid="99ee2380-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517519025218_303969_34416"/>
        <text>EnvironmentVersion</text>
      </ownedElement>
      <ownedElement xmi:id="20c9f8f0-6c43-013d-d602-0800270c66d6" xmi:uuid="20c9f990-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184460419_832667_375423" xmi:uuid="9bbd5b50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517521939298_384729_35335"/>
      <ownedElement xmi:id="9abb8b50-9159-013c-7154-0a5172f4a469" xmi:uuid="9abb8c80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1517521939298_384729_35335"/>
        <text>EnvironmentView</text>
      </ownedElement>
      <ownedElement xmi:id="29e76e50-6c43-013d-d602-0800270c66d6" xmi:uuid="29e76f20-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="341" y="595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184461483_268718_375508" xmi:uuid="9cd9d270-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Event"/>
      <ownedElement xmi:id="9bc8f500-9159-013c-7154-0a5172f4a469" xmi:uuid="9bc8f610-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Event"/>
        <text>Event</text>
      </ownedElement>
      <ownedElement xmi:id="356d10b0-6c43-013d-d602-0800270c66d6" xmi:uuid="356d1190-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="617" y="595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184462555_784170_375589" xmi:uuid="9d15e230-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504193343893_860532_25972"/>
      <ownedElement xmi:id="9ce200a0-9159-013c-7154-0a5172f4a469" xmi:uuid="9ce20370-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504193343893_860532_25972"/>
        <text>Evidence</text>
      </ownedElement>
      <ownedElement xmi:id="41e803e0-6c43-013d-d602-0800270c66d6" xmi:uuid="41e80480-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="893" y="595" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184463428_59123_375661" xmi:uuid="9d254ae0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_ExchangeContext"/>
      <ownedElement xmi:id="9d172a90-9159-013c-7154-0a5172f4a469" xmi:uuid="9d172b90-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_ExchangeContext"/>
        <text>ExchangeContext</text>
      </ownedElement>
      <ownedElement xmi:id="43cb9d70-6c43-013d-d602-0800270c66d6" xmi:uuid="43cb9e10-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="645" width="203" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184463978_388357_375717" xmi:uuid="9d44e020-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642500047573_10466_68142"/>
      <ownedElement xmi:id="9d2ef470-9159-013c-7154-0a5172f4a469" xmi:uuid="9d2ef580-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642500047573_10466_68142"/>
        <text>ExperienceGained</text>
      </ownedElement>
      <ownedElement xmi:id="463626e0-6c43-013d-d602-0800270c66d6" xmi:uuid="46362780-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="288" y="645" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184465143_296144_375805" xmi:uuid="9d7daf90-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642499994215_697859_68050"/>
      <ownedElement xmi:id="9d47f810-9159-013c-7154-0a5172f4a469" xmi:uuid="9d47f930-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642499994215_697859_68050"/>
        <text>ExperienceInstance</text>
      </ownedElement>
      <ownedElement xmi:id="4793e5f0-6c43-013d-d602-0800270c66d6" xmi:uuid="4793e690-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="554" y="645" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184465954_52188_375883" xmi:uuid="9db1e450-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642457258753_210978_70609"/>
      <ownedElement xmi:id="9d80cba0-9159-013c-7154-0a5172f4a469" xmi:uuid="9d80ccc0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642457258753_210978_70609"/>
        <text>ExperienceType</text>
      </ownedElement>
      <ownedElement xmi:id="4a34fb90-6c43-013d-d602-0800270c66d6" xmi:uuid="4a34fd50-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="820" y="645" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184466632_987274_375952" xmi:uuid="9e87f680-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_ExternalItem"/>
      <ownedElement xmi:id="9dbdfa70-9159-013c-7154-0a5172f4a469" xmi:uuid="9dbdfb80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_ExternalItem"/>
        <text>ExternalItem</text>
      </ownedElement>
      <ownedElement xmi:id="4d7feff0-6c43-013d-d602-0800270c66d6" xmi:uuid="4d7ff090-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="695" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184467316_425639_376031" xmi:uuid="9f6cfc70-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1549639210536_923330_36639"/>
      <ownedElement xmi:id="9e943480-9159-013c-7154-0a5172f4a469" xmi:uuid="9e943590-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1549639210536_923330_36639"/>
        <text>ExternalLibrary</text>
      </ownedElement>
      <ownedElement xmi:id="55ec8be0-6c43-013d-d602-0800270c66d6" xmi:uuid="55ec8cb0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="341" y="695" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184467407_310878_376076" xmi:uuid="9fb17310-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_ExternalOwlClass"/>
      <ownedElement xmi:id="9f788e70-9159-013c-7154-0a5172f4a469" xmi:uuid="9f788f80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_ExternalOwlClass"/>
        <text>ExternalOwlClass</text>
      </ownedElement>
      <ownedElement xmi:id="5d67f350-6c43-013d-d602-0800270c66d6" xmi:uuid="5d67f3e0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="617" y="695" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184467494_617996_376122" xmi:uuid="9ffe2350-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_ExternalOwlObject"/>
      <ownedElement xmi:id="9fbcd7c0-9159-013c-7154-0a5172f4a469" xmi:uuid="9fbcd9e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_ExternalOwlObject"/>
        <text>ExternalOwlObject</text>
      </ownedElement>
      <ownedElement xmi:id="60191a70-6c43-013d-d602-0800270c66d6" xmi:uuid="60191b10-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="893" y="695" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184467951_643299_376187" xmi:uuid="a0ac2b50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_ExternalUnit"/>
      <ownedElement xmi:id="a00988c0-9159-013c-7154-0a5172f4a469" xmi:uuid="a00989f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_ExternalUnit"/>
        <text>ExternalUnit</text>
      </ownedElement>
      <ownedElement xmi:id="63b60320-6c43-013d-d602-0800270c66d6" xmi:uuid="63b603c0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="745" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184469135_491776_376280" xmi:uuid="a0deaab0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_File"/>
      <ownedElement xmi:id="a0aee680-9159-013c-7154-0a5172f4a469" xmi:uuid="a0aee7a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../DocumentManagement/DocumentManagement.xmi#_File"/>
        <text>File</text>
      </ownedElement>
      <ownedElement xmi:id="6a9545b0-6c43-013d-d602-0800270c66d6" xmi:uuid="6a954660-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="341" y="745" width="271" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184469397_651953_376324" xmi:uuid="a0e3dcb0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Probability/Probability.xmi#_18_4_1_29c0149_1619074630369_511218_69105"/>
      <ownedElement xmi:id="a0e1e180-9159-013c-7154-0a5172f4a469" xmi:uuid="a0e1e2b0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Probability/Probability.xmi#_18_4_1_29c0149_1619074630369_511218_69105"/>
        <text>FunctionValuePair</text>
      </ownedElement>
      <ownedElement xmi:id="6d554f90-6c43-013d-d602-0800270c66d6" xmi:uuid="6d555030-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="632" y="745" width="208" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184470134_99633_376799" xmi:uuid="a19a3500-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Identifier"/>
      <ownedElement xmi:id="a0ef8dd0-9159-013c-7154-0a5172f4a469" xmi:uuid="a0ef9200-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Identifier"/>
        <text>Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="6e43f410-6c43-013d-d602-0800270c66d6" xmi:uuid="6e43f6a0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="860" y="745" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184471800_71956_376902" xmi:uuid="a1d89ee0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
      <ownedElement xmi:id="a1a18c10-9159-013c-7154-0a5172f4a469" xmi:uuid="a1a18d10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPart"/>
        <text>IndividualPart</text>
      </ownedElement>
      <ownedElement xmi:id="76d37250-6c43-013d-d602-0800270c66d6" xmi:uuid="76ed86a0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="795" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184473423_687055_377002" xmi:uuid="a207ed10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
      <ownedElement xmi:id="a1db1ac0-9159-013c-7154-0a5172f4a469" xmi:uuid="a1db1be0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartVersion"/>
        <text>IndividualPartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="79866ac0-6c43-013d-d602-0800270c66d6" xmi:uuid="79866b60-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="308" y="795" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184475081_735089_377103" xmi:uuid="a23a8a90-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="a20a8840-9159-013c-7154-0a5172f4a469" xmi:uuid="a20a8960-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="7bb7e7c0-6c43-013d-d602-0800270c66d6" xmi:uuid="7bb7e870-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="551" y="795" width="223" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184476309_956984_377212" xmi:uuid="a2fcf940-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_InformationRight"/>
      <ownedElement xmi:id="a241c960-9159-013c-7154-0a5172f4a469" xmi:uuid="a241ca70-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_InformationRight"/>
        <text>InformationRight</text>
      </ownedElement>
      <ownedElement xmi:id="7e1b6090-6c43-013d-d602-0800270c66d6" xmi:uuid="7e1b6140-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="794" y="795" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184477661_867200_377327" xmi:uuid="a3a4fa30-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_InformationUsageRight"/>
      <ownedElement xmi:id="a303e9b0-9159-013c-7154-0a5172f4a469" xmi:uuid="a303eac0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_InformationUsageRight"/>
        <text>InformationUsageRight</text>
      </ownedElement>
      <ownedElement xmi:id="87e91c50-6c43-013d-d602-0800270c66d6" xmi:uuid="87e91cf0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="845" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184478754_143559_377416" xmi:uuid="a3f9b610-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133691013_484756_38870"/>
      <ownedElement xmi:id="a3afd550-9159-013c-7154-0a5172f4a469" xmi:uuid="a3afd690-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133691013_484756_38870"/>
        <text>InterfaceConnection</text>
      </ownedElement>
      <ownedElement xmi:id="91537e30-6c43-013d-d602-0800270c66d6" xmi:uuid="91537ef0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="360" y="845" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184480407_348014_377516" xmi:uuid="a4510f40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133997057_424483_38872"/>
      <ownedElement xmi:id="a3fd89c0-9159-013c-7154-0a5172f4a469" xmi:uuid="a3fd8ab0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559133997057_424483_38872"/>
        <text>InterfaceConnector</text>
      </ownedElement>
      <ownedElement xmi:id="98e60b50-6c43-013d-d602-0800270c66d6" xmi:uuid="98e60c00-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="581" y="845" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184481636_4055_377601" xmi:uuid="a493b4a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134009996_168675_38876"/>
      <ownedElement xmi:id="a454a430-9159-013c-7154-0a5172f4a469" xmi:uuid="a454a540-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134009996_168675_38876"/>
        <text>InterfaceConnectorOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="9ce96dd0-6c43-013d-d602-0800270c66d6" xmi:uuid="9ce96e70-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="802" y="845" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184483222_719812_377698" xmi:uuid="a4d0e410-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134019779_950347_38878"/>
      <ownedElement xmi:id="a497eb10-9159-013c-7154-0a5172f4a469" xmi:uuid="a497ec40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134019779_950347_38878"/>
        <text>InterfaceConnectorVersion</text>
      </ownedElement>
      <ownedElement xmi:id="9f6c9ad0-6c43-013d-d602-0800270c66d6" xmi:uuid="9f6c9b80-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="895" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184484772_114214_377803" xmi:uuid="a5159000-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
      <ownedElement xmi:id="a4d49620-9159-013c-7154-0a5172f4a469" xmi:uuid="a4d49730-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134003381_840465_38874"/>
        <text>InterfaceConnectorView</text>
      </ownedElement>
      <ownedElement xmi:id="a27c11a0-6c43-013d-d602-0800270c66d6" xmi:uuid="a27c1230-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="286" y="895" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184485872_807227_377892" xmi:uuid="a56565a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134027947_222114_38880"/>
      <ownedElement xmi:id="a5192500-9159-013c-7154-0a5172f4a469" xmi:uuid="a5192610-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134027947_222114_38880"/>
        <text>InterfaceDefinitionConnection</text>
      </ownedElement>
      <ownedElement xmi:id="a6932500-6c43-013d-d602-0800270c66d6" xmi:uuid="a69325e0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="507" y="895" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184487542_816994_377992" xmi:uuid="a5ba6050-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134059448_942822_38888"/>
      <ownedElement xmi:id="a568f0a0-9159-013c-7154-0a5172f4a469" xmi:uuid="a568f1b0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134059448_942822_38888"/>
        <text>InterfaceSpecification</text>
      </ownedElement>
      <ownedElement xmi:id="aa8c22c0-6c43-013d-d602-0800270c66d6" xmi:uuid="aa8c27a0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="728" y="895" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184489136_847389_378089" xmi:uuid="a5fd3460-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134081745_171261_38892"/>
      <ownedElement xmi:id="a5be2b90-9159-013c-7154-0a5172f4a469" xmi:uuid="a5be2ca0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134081745_171261_38892"/>
        <text>InterfaceSpecificationVersion</text>
      </ownedElement>
      <ownedElement xmi:id="aeb5a730-6c43-013d-d602-0800270c66d6" xmi:uuid="aeb5a7c0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="949" y="895" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184490673_664640_378185" xmi:uuid="a63c9500-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
      <ownedElement xmi:id="a600e1a0-9159-013c-7154-0a5172f4a469" xmi:uuid="a600e2a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Interface/Interface.xmi#_18_4_1_8e001ed_1559134065519_648560_38890"/>
        <text>InterfaceSpecificationView</text>
      </ownedElement>
      <ownedElement xmi:id="b1861c60-6c43-013d-d602-0800270c66d6" xmi:uuid="b1861d10-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="945" width="201" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184491693_823033_378274" xmi:uuid="a6e5b820-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582535779826_461173_55822"/>
      <ownedElement xmi:id="a643d300-9159-013c-7154-0a5172f4a469" xmi:uuid="a643d410-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582535779826_461173_55822"/>
        <text>Justification</text>
      </ownedElement>
      <ownedElement xmi:id="b4d03b60-6c43-013d-d602-0800270c66d6" xmi:uuid="b4d03c20-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="286" y="945" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184491939_492258_378660" xmi:uuid="a728e0d0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Language"/>
      <ownedElement xmi:id="a6f166e0-9159-013c-7154-0a5172f4a469" xmi:uuid="a6f16900-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Language"/>
        <text>Language</text>
      </ownedElement>
      <ownedElement xmi:id="da97cf30-6c43-013d-d602-0800270c66d6" xmi:uuid="dae92b60-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="581" y="945" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184492187_181349_378709" xmi:uuid="a754b2a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_LifeCycleStage"/>
      <ownedElement xmi:id="a72ddb80-9159-013c-7154-0a5172f4a469" xmi:uuid="a72ddca0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_LifeCycleStage"/>
        <text>LifeCycleStage</text>
      </ownedElement>
      <ownedElement xmi:id="e8ab1270-6c43-013d-d602-0800270c66d6" xmi:uuid="e8ab1460-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="857" y="945" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184492302_762220_378820" xmi:uuid="a7829500-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_LocalizedString"/>
      <ownedElement xmi:id="a7600610-9159-013c-7154-0a5172f4a469" xmi:uuid="a7600720-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_LocalizedString"/>
        <text>LocalizedString</text>
      </ownedElement>
      <ownedElement xmi:id="ef480600-6c43-013d-d602-0800270c66d6" xmi:uuid="ef480800-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="995" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184493847_692554_378938" xmi:uuid="a8412680-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1506005124993_361009_24731"/>
      <ownedElement xmi:id="a789af90-9159-013c-7154-0a5172f4a469" xmi:uuid="a789b0a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1506005124993_361009_24731"/>
        <text>Location</text>
      </ownedElement>
      <ownedElement xmi:id="f0e8b3b0-6c43-013d-d602-0800270c66d6" xmi:uuid="f0e8b460-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="341" y="995" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184495125_84905_379052" xmi:uuid="a8da35b0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1506009738312_550285_25925"/>
      <ownedElement xmi:id="a848e120-9159-013c-7154-0a5172f4a469" xmi:uuid="a848e260-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1506009738312_550285_25925"/>
        <text>Locator</text>
      </ownedElement>
      <ownedElement xmi:id="f8adf2f0-6c43-013d-d602-0800270c66d6" xmi:uuid="f8adf3d0-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="636" y="995" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184496502_991581_379148" xmi:uuid="a9188de0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832794448_726739_56316"/>
      <ownedElement xmi:id="a8e29d60-9159-013c-7154-0a5172f4a469" xmi:uuid="a8e29e90-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832794448_726739_56316"/>
        <text>ManagedResource</text>
      </ownedElement>
      <ownedElement xmi:id="ff042a50-6c43-013d-d602-0800270c66d6" xmi:uuid="ff042b00-6c43-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="931" y="995" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184497617_108367_379238" xmi:uuid="a94eb500-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_Market"/>
      <ownedElement xmi:id="a91b7b00-9159-013c-7154-0a5172f4a469" xmi:uuid="a91b7c00-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_Market"/>
        <text>Market</text>
      </ownedElement>
      <ownedElement xmi:id="0220d080-6c44-013d-d602-0800270c66d6" xmi:uuid="0220d130-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1045" width="340" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184498213_540863_379312" xmi:uuid="a9fa9380-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_MeasureQualification"/>
      <ownedElement xmi:id="a95a34a0-9159-013c-7154-0a5172f4a469" xmi:uuid="a95a35a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_MeasureQualification"/>
        <text>MeasureQualification</text>
      </ownedElement>
      <ownedElement xmi:id="053fa2f0-6c44-013d-d602-0800270c66d6" xmi:uuid="053fa3a0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="425" y="1045" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184499407_665152_379423" xmi:uuid="aa0a0800-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539766477342_290236_14489"/>
      <ownedElement xmi:id="a9fbe7f0-9159-013c-7154-0a5172f4a469" xmi:uuid="a9fbe900-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539766477342_290236_14489"/>
        <text>Message</text>
      </ownedElement>
      <ownedElement xmi:id="0b9468c0-6c44-013d-d602-0800270c66d6" xmi:uuid="0b946960-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="701" y="1045" width="203" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184500219_726497_379515" xmi:uuid="ab098a30-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_NumericalContext"/>
      <ownedElement xmi:id="aa159700-9159-013c-7154-0a5172f4a469" xmi:uuid="aa159930-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_NumericalContext"/>
        <text>NumericalContext</text>
      </ownedElement>
      <ownedElement xmi:id="0d63dbb0-6c44-013d-d602-0800270c66d6" xmi:uuid="0d63dc50-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="924" y="1045" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184501780_846887_379633" xmi:uuid="ab216c10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625040869976_263353_69561"/>
      <ownedElement xmi:id="ab0d34a0-9159-013c-7154-0a5172f4a469" xmi:uuid="ab0d35c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625040869976_263353_69561"/>
        <text>Observation</text>
      </ownedElement>
      <ownedElement xmi:id="17437d50-6c44-013d-d602-0800270c66d6" xmi:uuid="17437e00-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1095" width="218" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184502991_206819_379729" xmi:uuid="ab8940c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Occurrence"/>
      <ownedElement xmi:id="ab269440-9159-013c-7154-0a5172f4a469" xmi:uuid="ab269560-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Occurrence"/>
        <text>Occurrence</text>
      </ownedElement>
      <ownedElement xmi:id="18b100f0-6c44-013d-d602-0800270c66d6" xmi:uuid="18b10190-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="303" y="1095" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184503885_934154_379783" xmi:uuid="abca96c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_271a0567_1582708908249_124940_60208"/>
      <ownedElement xmi:id="ab8e6a40-9159-013c-7154-0a5172f4a469" xmi:uuid="ab8e6b40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_271a0567_1582708908249_124940_60208"/>
        <text>OccurrencePlacement</text>
      </ownedElement>
      <ownedElement xmi:id="1cc58d90-6c44-013d-d602-0800270c66d6" xmi:uuid="1cc58e60-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="605" y="1095" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184505281_890005_379910" xmi:uuid="ac7f1170-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
      <ownedElement xmi:id="abd180b0-9159-013c-7154-0a5172f4a469" xmi:uuid="abd181b0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
        <text>Organization</text>
      </ownedElement>
      <ownedElement xmi:id="1f8f3390-6c44-013d-d602-0800270c66d6" xmi:uuid="1f8f3450-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="907" y="1095" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184506459_838508_380025" xmi:uuid="ad277e80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505750163257_414856_24072"/>
      <ownedElement xmi:id="ac8616c0-9159-013c-7154-0a5172f4a469" xmi:uuid="ac861980-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505750163257_414856_24072"/>
        <text>OrganizationType</text>
      </ownedElement>
      <ownedElement xmi:id="26f80740-6c44-013d-d602-0800270c66d6" xmi:uuid="26f807f0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1145" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184508402_200641_380142" xmi:uuid="adc4d7f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
      <ownedElement xmi:id="ad2caa40-9159-013c-7154-0a5172f4a469" xmi:uuid="ad2cab40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Part"/>
        <text>Part</text>
      </ownedElement>
      <ownedElement xmi:id="2e005b40-6c44-013d-d602-0800270c66d6" xmi:uuid="2e005c10-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="360" y="1145" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184510245_984139_380251" xmi:uuid="ae316100-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
      <ownedElement xmi:id="adc9abc0-9159-013c-7154-0a5172f4a469" xmi:uuid="adc9ace0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartVersion"/>
        <text>PartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="346bbaf0-6c44-013d-d602-0800270c66d6" xmi:uuid="346bbb90-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="662" y="1145" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184512051_183452_380362" xmi:uuid="aea4f480-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="ae36bfe0-9159-013c-7154-0a5172f4a469" xmi:uuid="ae36c100-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="38a7b8b0-6c44-013d-d602-0800270c66d6" xmi:uuid="38a7bac0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="964" y="1145" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184513413_292567_380455" xmi:uuid="af403040-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
      <ownedElement xmi:id="aeac0370-9159-013c-7154-0a5172f4a469" xmi:uuid="aeac0480-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
        <text>Person</text>
      </ownedElement>
      <ownedElement xmi:id="3d8e8cc0-6c44-013d-d602-0800270c66d6" xmi:uuid="3d8e8da0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1195" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184515104_299764_380575" xmi:uuid="affc50d0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
      <ownedElement xmi:id="af475a00-9159-013c-7154-0a5172f4a469" xmi:uuid="af475b30-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
        <text>PersonInOrganization</text>
      </ownedElement>
      <ownedElement xmi:id="43fe7880-6c44-013d-d602-0800270c66d6" xmi:uuid="43fe7930-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="360" y="1195" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184515379_112016_380623" xmi:uuid="b03c8f60-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505825877571_346888_26292"/>
      <ownedElement xmi:id="b003b240-9159-013c-7154-0a5172f4a469" xmi:uuid="b003b350-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505825877571_346888_26292"/>
        <text>PersonName</text>
      </ownedElement>
      <ownedElement xmi:id="4bde18f0-6c44-013d-d602-0800270c66d6" xmi:uuid="4bde1990-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="655" y="1195" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184515642_560729_380696" xmi:uuid="b09d6f50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505826019116_652292_26335"/>
      <ownedElement xmi:id="b043a280-9159-013c-7154-0a5172f4a469" xmi:uuid="b043a380-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505826019116_652292_26335"/>
        <text>PersonNameComponent</text>
      </ownedElement>
      <ownedElement xmi:id="4e82c7d0-6c44-013d-d602-0800270c66d6" xmi:uuid="4e82d780-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="950" y="1195" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184515837_798732_380751" xmi:uuid="b0c5aa40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505824910952_139495_26196"/>
      <ownedElement xmi:id="b0a4c980-9159-013c-7154-0a5172f4a469" xmi:uuid="b0a4ce50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505824910952_139495_26196"/>
        <text>PersonNameSet</text>
      </ownedElement>
      <ownedElement xmi:id="544f8ac0-6c44-013d-d602-0800270c66d6" xmi:uuid="544f8c00-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1245" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184517065_972046_380846" xmi:uuid="b104a6a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642452623238_766735_69124"/>
      <ownedElement xmi:id="b0c8d7e0-9159-013c-7154-0a5172f4a469" xmi:uuid="b0c8d8f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642452623238_766735_69124"/>
        <text>PersonOrganizationInPosition</text>
      </ownedElement>
      <ownedElement xmi:id="573840a0-6c44-013d-d602-0800270c66d6" xmi:uuid="573a90a0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="360" y="1245" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184518089_492783_380940" xmi:uuid="b13edd00-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642443886020_132400_67489"/>
      <ownedElement xmi:id="b107c260-9159-013c-7154-0a5172f4a469" xmi:uuid="b107c360-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642443886020_132400_67489"/>
        <text>PositionGroup</text>
      </ownedElement>
      <ownedElement xmi:id="5a56a8f0-6c44-013d-d602-0800270c66d6" xmi:uuid="5a690ae0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="626" y="1245" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184519113_19420_381025" xmi:uuid="b1761170-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642453956473_345243_69465"/>
      <ownedElement xmi:id="b141f230-9159-013c-7154-0a5172f4a469" xmi:uuid="b141f340-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642453956473_345243_69465"/>
        <text>PositionType</text>
      </ownedElement>
      <ownedElement xmi:id="5f9b3760-6c44-013d-d602-0800270c66d6" xmi:uuid="5f9b3810-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="892" y="1245" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184519293_99463_381070" xmi:uuid="b1c396a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PrecisionQualifier"/>
      <ownedElement xmi:id="b181d9c0-9159-013c-7154-0a5172f4a469" xmi:uuid="b181dac0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PrecisionQualifier"/>
        <text>PrecisionQualifier</text>
      </ownedElement>
      <ownedElement xmi:id="646aa5c0-6c44-013d-d602-0800270c66d6" xmi:uuid="646aa670-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1295" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184520818_904703_381181" xmi:uuid="b20032e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConcept"/>
      <ownedElement xmi:id="b1c6a730-9159-013c-7154-0a5172f4a469" xmi:uuid="b1c6a7e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConcept"/>
        <text>ProductConcept</text>
      </ownedElement>
      <ownedElement xmi:id="6ad1b360-6c44-013d-d602-0800270c66d6" xmi:uuid="6ad1b450-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="341" y="1295" width="340" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184522721_172709_381294" xmi:uuid="b2428470-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConfiguration"/>
      <ownedElement xmi:id="b2030ce0-9159-013c-7154-0a5172f4a469" xmi:uuid="b2030eb0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_ProductConfiguration"/>
        <text>ProductConfiguration</text>
      </ownedElement>
      <ownedElement xmi:id="72286330-6c44-013d-d602-0800270c66d6" xmi:uuid="722863d0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="701" y="1295" width="340" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184523974_487058_381441" xmi:uuid="b2e3ec30-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639072510862_608091_65724"/>
      <ownedElement xmi:id="b247b5e0-9159-013c-7154-0a5172f4a469" xmi:uuid="b247b6f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_6b1022a_1639072510862_608091_65724"/>
        <text>ProductGroup</text>
      </ownedElement>
      <ownedElement xmi:id="7b4d3570-6c44-013d-d602-0800270c66d6" xmi:uuid="7b5e4350-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1345" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184525374_780341_381551" xmi:uuid="b3abeae0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Project"/>
      <ownedElement xmi:id="b2eb0dc0-9159-013c-7154-0a5172f4a469" xmi:uuid="b2eb0ed0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Project"/>
        <text>Project</text>
      </ownedElement>
      <ownedElement xmi:id="910d57d0-6c44-013d-d602-0800270c66d6" xmi:uuid="91aebf60-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="367" y="1345" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184527374_170999_381681" xmi:uuid="b5b4a9e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinition"/>
      <ownedElement xmi:id="b3b77f80-9159-013c-7154-0a5172f4a469" xmi:uuid="b3b78090-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyDefinition"/>
        <text>PropertyDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="a98c06f0-6c44-013d-d602-0800270c66d6" xmi:uuid="a98c07c0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="662" y="1345" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184528530_114949_381776" xmi:uuid="b67f70e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValue"/>
      <ownedElement xmi:id="b5c04180-9159-013c-7154-0a5172f4a469" xmi:uuid="b5c042c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PropertyValue"/>
        <text>PropertyValue</text>
      </ownedElement>
      <ownedElement xmi:id="bf177400-6c44-013d-d602-0800270c66d6" xmi:uuid="bf1774a0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="938" y="1345" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184529221_98159_382500" xmi:uuid="b6d2d260-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Proxy"/>
      <ownedElement xmi:id="b68b0720-9159-013c-7154-0a5172f4a469" xmi:uuid="b68b0830-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Proxy"/>
        <text>Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="c8599dc0-6c44-013d-d602-0800270c66d6" xmi:uuid="c8599e40-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1395" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184530083_540863_382592" xmi:uuid="b7071530-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642457246056_579404_70563"/>
      <ownedElement xmi:id="b6d62800-9159-013c-7154-0a5172f4a469" xmi:uuid="b6d62900-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642457246056_579404_70563"/>
        <text>QualificationType</text>
      </ownedElement>
      <ownedElement xmi:id="cb4ae020-6c44-013d-d602-0800270c66d6" xmi:uuid="cb4ae0c0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="341" y="1395" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184531134_700833_382680" xmi:uuid="b7d28e00-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_RelationshipObject"/>
      <ownedElement xmi:id="b712bc90-9159-013c-7154-0a5172f4a469" xmi:uuid="b712bd90-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_RelationshipObject"/>
        <text>RelationshipObject</text>
      </ownedElement>
      <ownedElement xmi:id="ce527f30-6c44-013d-d602-0800270c66d6" xmi:uuid="ce527fd0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="607" y="1395" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184532875_6430_382785" xmi:uuid="b80dbb10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_Representation"/>
      <ownedElement xmi:id="b7d50ba0-9159-013c-7154-0a5172f4a469" xmi:uuid="b7d50ca0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_Representation"/>
        <text>Representation</text>
      </ownedElement>
      <ownedElement xmi:id="d5b38850-6c44-013d-d602-0800270c66d6" xmi:uuid="d5b38910-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="883" y="1395" width="381" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184534220_672924_382885" xmi:uuid="b83b7410-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_RepresentationContext"/>
      <ownedElement xmi:id="b8105900-9159-013c-7154-0a5172f4a469" xmi:uuid="b8105a00-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_RepresentationContext"/>
        <text>RepresentationContext</text>
      </ownedElement>
      <ownedElement xmi:id="d81e9ba0-6c44-013d-d602-0800270c66d6" xmi:uuid="d81e9c30-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1445" width="381" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184534888_633293_382974" xmi:uuid="b8542910-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_RepresentationItem"/>
      <ownedElement xmi:id="b83df400-9159-013c-7154-0a5172f4a469" xmi:uuid="b83df510-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_RepresentationItem"/>
        <text>RepresentationItem</text>
      </ownedElement>
      <ownedElement xmi:id="da0dc150-6c44-013d-d602-0800270c66d6" xmi:uuid="da0dc200-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="466" y="1445" width="381" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184536179_773130_383079" xmi:uuid="b88ed6f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583829364095_153317_54200"/>
      <ownedElement xmi:id="b85748d0-9159-013c-7154-0a5172f4a469" xmi:uuid="b85749e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583829364095_153317_54200"/>
        <text>RequiredResource</text>
      </ownedElement>
      <ownedElement xmi:id="db0f3130-6c44-013d-d602-0800270c66d6" xmi:uuid="db0f31e0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="867" y="1445" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184537951_439228_383200" xmi:uuid="b8d3b090-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
      <ownedElement xmi:id="b891d2f0-9159-013c-7154-0a5172f4a469" xmi:uuid="b891d400-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_Requirement"/>
        <text>Requirement</text>
      </ownedElement>
      <ownedElement xmi:id="dd806a10-6c44-013d-d602-0800270c66d6" xmi:uuid="dd806ae0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1495" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184539324_314038_383293" xmi:uuid="b903ad60-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementSatisfactionAssertion"/>
      <ownedElement xmi:id="b8d69090-9159-013c-7154-0a5172f4a469" xmi:uuid="b8d69190-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementSatisfactionAssertion"/>
        <text>RequirementSatisfactionAssertion</text>
      </ownedElement>
      <ownedElement xmi:id="e0691470-6c44-013d-d602-0800270c66d6" xmi:uuid="e0691520-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="368" y="1495" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184540662_544475_383397" xmi:uuid="b934bc70-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementSource"/>
      <ownedElement xmi:id="b9069940-9159-013c-7154-0a5172f4a469" xmi:uuid="b9069a50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementSource"/>
        <text>RequirementSource</text>
      </ownedElement>
      <ownedElement xmi:id="e24b9420-6c44-013d-d602-0800270c66d6" xmi:uuid="e24b9770-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="671" y="1495" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184542433_588643_383515" xmi:uuid="b96b5c70-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
      <ownedElement xmi:id="b937c950-9159-013c-7154-0a5172f4a469" xmi:uuid="b937ca60-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementVersion"/>
        <text>RequirementVersion</text>
      </ownedElement>
      <ownedElement xmi:id="e438d750-6c44-013d-d602-0800270c66d6" xmi:uuid="e438d810-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="974" y="1495" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184544486_820310_383668" xmi:uuid="b9ad6620-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
      <ownedElement xmi:id="b96e4350-9159-013c-7154-0a5172f4a469" xmi:uuid="b96e4450-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
        <text>RequirementView</text>
      </ownedElement>
      <ownedElement xmi:id="e6618e30-6c44-013d-d602-0800270c66d6" xmi:uuid="e6618ee0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1545" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184545844_561926_383773" xmi:uuid="b9eb7450-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583841957854_241881_57156"/>
      <ownedElement xmi:id="b9b0c500-9159-013c-7154-0a5172f4a469" xmi:uuid="b9b0c640-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583841957854_241881_57156"/>
        <text>ResourceAsRealized</text>
      </ownedElement>
      <ownedElement xmi:id="e8c3fe30-6c44-013d-d602-0800270c66d6" xmi:uuid="e8c3fef0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="368" y="1545" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184547280_834141_383885" xmi:uuid="ba20bb10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832142352_199733_56200"/>
      <ownedElement xmi:id="b9ee7cd0-9159-013c-7154-0a5172f4a469" xmi:uuid="b9ee7de0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583832142352_199733_56200"/>
        <text>ResourceEvent</text>
      </ownedElement>
      <ownedElement xmi:id="eb628a90-6c44-013d-d602-0800270c66d6" xmi:uuid="eb628b30-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="600" y="1545" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184548541_967875_383985" xmi:uuid="ba51e5a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
      <ownedElement xmi:id="ba23c070-9159-013c-7154-0a5172f4a469" xmi:uuid="ba23c180-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Resources/Resources.xmi#_18_4_1_1b310459_1583843920367_808068_57586"/>
        <text>ResourceItem</text>
      </ownedElement>
      <ownedElement xmi:id="ed68bef0-6c44-013d-d602-0800270c66d6" xmi:uuid="ed68bfa0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="832" y="1545" width="212" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184549467_137476_384076" xmi:uuid="bb45b700-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_RetentionPeriod"/>
      <ownedElement xmi:id="ba5d50e0-9159-013c-7154-0a5172f4a469" xmi:uuid="ba5d51f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_RetentionPeriod"/>
        <text>RetentionPeriod</text>
      </ownedElement>
      <ownedElement xmi:id="eff35b20-6c44-013d-d602-0800270c66d6" xmi:uuid="eff35d30-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1595" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184551209_698450_384193" xmi:uuid="bb771a30-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
      <ownedElement xmi:id="bb4bf4f0-9159-013c-7154-0a5172f4a469" xmi:uuid="bb4bf750-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879617_390904_62428"/>
        <text>Risk</text>
      </ownedElement>
      <ownedElement xmi:id="f8d6ea10-6c44-013d-d602-0800270c66d6" xmi:uuid="f8d6eab0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="341" y="1595" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184552923_622493_384307" xmi:uuid="bb99cbc0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
      <ownedElement xmi:id="bb794120-9159-013c-7154-0a5172f4a469" xmi:uuid="bb794230-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_178850_62429"/>
        <text>RiskVersion</text>
      </ownedElement>
      <ownedElement xmi:id="fa687670-6c44-013d-d602-0800270c66d6" xmi:uuid="fa687720-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="541" y="1595" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184554588_387637_384420" xmi:uuid="bbbb3230-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_912952_62430"/>
      <ownedElement xmi:id="bb9c17e0-9159-013c-7154-0a5172f4a469" xmi:uuid="bb9c1900-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1617888879632_912952_62430"/>
        <text>RiskView</text>
      </ownedElement>
      <ownedElement xmi:id="fbce1d30-6c44-013d-d602-0800270c66d6" xmi:uuid="fbce1ea0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="741" y="1595" width="180" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184556341_528018_384529" xmi:uuid="bbe99940-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
      <ownedElement xmi:id="bbc14dd0-9159-013c-7154-0a5172f4a469" xmi:uuid="bbc14ee0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190686043_714827_14922"/>
        <text>Scheme</text>
      </ownedElement>
      <ownedElement xmi:id="fdab8ed0-6c44-013d-d602-0800270c66d6" xmi:uuid="fdab8f80-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="941" y="1595" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184557814_824472_384636" xmi:uuid="bc120620-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
      <ownedElement xmi:id="bbeb9380-9159-013c-7154-0a5172f4a469" xmi:uuid="bbeb94b0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617192496959_34134_15071"/>
        <text>SchemeEntry</text>
      </ownedElement>
      <ownedElement xmi:id="ff611f20-6c44-013d-d602-0800270c66d6" xmi:uuid="ff6121b0-6c44-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1645" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184559610_638810_384761" xmi:uuid="bc3c6c10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
      <ownedElement xmi:id="bc144c80-9159-013c-7154-0a5172f4a469" xmi:uuid="bc144de0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PlanningScheduling/PlanningScheduling.xmi#_18_4_1_29c0149_1617190723007_778199_14968"/>
        <text>SchemeVersion</text>
      </ownedElement>
      <ownedElement xmi:id="0161f700-6c45-013d-d602-0800270c66d6" xmi:uuid="0161f7a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="337" y="1645" width="252" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184560869_414580_384866" xmi:uuid="bd5e41e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_SecurityClassification"/>
      <ownedElement xmi:id="bc480b60-9159-013c-7154-0a5172f4a469" xmi:uuid="bc480c70-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_SecurityClassification"/>
        <text>SecurityClassification</text>
      </ownedElement>
      <ownedElement xmi:id="0423c670-6c45-013d-d602-0800270c66d6" xmi:uuid="0423c720-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="609" y="1645" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184561268_627798_384918" xmi:uuid="bdf6b060-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_SetMembership"/>
      <ownedElement xmi:id="bd69ebe0-9159-013c-7154-0a5172f4a469" xmi:uuid="bd69ed00-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_SetMembership"/>
        <text>SetMembership</text>
      </ownedElement>
      <ownedElement xmi:id="0e64d820-6c45-013d-d602-0800270c66d6" xmi:uuid="0e64d8b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="885" y="1645" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184561363_765724_384965" xmi:uuid="be2af900-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505824956038_95621_26239"/>
      <ownedElement xmi:id="bdfe2b50-9159-013c-7154-0a5172f4a469" xmi:uuid="bdfe2c80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_8be0287_1505824956038_95621_26239"/>
        <text>SimplePersonName</text>
      </ownedElement>
      <ownedElement xmi:id="14bda370-6c45-013d-d602-0800270c66d6" xmi:uuid="14bda440-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1695" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184563144_28798_385089" xmi:uuid="be5fd370-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
      <ownedElement xmi:id="be31aa90-9159-013c-7154-0a5172f4a469" xmi:uuid="be31abb0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622213674764_739742_68060"/>
        <text>Slot</text>
      </ownedElement>
      <ownedElement xmi:id="17452d10-6c45-013d-d602-0800270c66d6" xmi:uuid="17452df0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="360" y="1695" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184565220_108681_385213" xmi:uuid="be9065f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
      <ownedElement xmi:id="be621380-9159-013c-7154-0a5172f4a469" xmi:uuid="be621490-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214133153_171619_69234"/>
        <text>SlotDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="19d4a6b0-6c45-013d-d602-0800270c66d6" xmi:uuid="19d4a790-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="556" y="1695" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184566966_14572_385338" xmi:uuid="beb662f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
      <ownedElement xmi:id="be92b1d0-9159-013c-7154-0a5172f4a469" xmi:uuid="be92b2e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Slot/Slot.xmi#_18_4_1_8be0287_1622214109131_669431_69191"/>
        <text>SlotVersion</text>
      </ownedElement>
      <ownedElement xmi:id="1bf89490-6c45-013d-d602-0800270c66d6" xmi:uuid="1bf895a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="752" y="1695" width="176" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184568427_766572_385448" xmi:uuid="bef1ce80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_Specification"/>
      <ownedElement xmi:id="beb93b60-9159-013c-7154-0a5172f4a469" xmi:uuid="beb93c80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_Specification"/>
        <text>Specification</text>
      </ownedElement>
      <ownedElement xmi:id="1db6d7c0-6c45-013d-d602-0800270c66d6" xmi:uuid="1db6d8a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="948" y="1695" width="340" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184569338_522827_385542" xmi:uuid="bf1bc9c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationCategory"/>
      <ownedElement xmi:id="bef48a80-9159-013c-7154-0a5172f4a469" xmi:uuid="bef48b90-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationCategory"/>
        <text>SpecificationCategory</text>
      </ownedElement>
      <ownedElement xmi:id="20354800-6c45-013d-d602-0800270c66d6" xmi:uuid="20354a80-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1745" width="340" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184570408_138627_385635" xmi:uuid="bf406c90-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationCategoryHierarchy"/>
      <ownedElement xmi:id="bf1e8d30-9159-013c-7154-0a5172f4a469" xmi:uuid="bf1e8e40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationCategoryHierarchy"/>
        <text>SpecificationCategoryHierarchy</text>
      </ownedElement>
      <ownedElement xmi:id="221ceb90-6c45-013d-d602-0800270c66d6" xmi:uuid="221ced70-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="425" y="1745" width="340" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184571327_926485_385720" xmi:uuid="bf6ca000-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationInclusion"/>
      <ownedElement xmi:id="bf433970-9159-013c-7154-0a5172f4a469" xmi:uuid="bf433a80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductSpecificationAndConfiguration/ProductSpecificationAndConfiguration.xmi#_SpecificationInclusion"/>
        <text>SpecificationInclusion</text>
      </ownedElement>
      <ownedElement xmi:id="23e31fe0-6c45-013d-d602-0800270c66d6" xmi:uuid="23e320c0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="785" y="1745" width="340" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184572423_745025_385830" xmi:uuid="c05647a0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878022123_684236_27287"/>
      <ownedElement xmi:id="bf784230-9159-013c-7154-0a5172f4a469" xmi:uuid="bf784330-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504878022123_684236_27287"/>
        <text>State</text>
      </ownedElement>
      <ownedElement xmi:id="26a09070-6c45-013d-d602-0800270c66d6" xmi:uuid="26a091f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1795" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184573674_175081_385934" xmi:uuid="c16bad40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504881104148_230182_28614"/>
      <ownedElement xmi:id="c06216d0-9159-013c-7154-0a5172f4a469" xmi:uuid="c06217e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8e001ed_1504881104148_230182_28614"/>
        <text>StateDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="31377500-6c45-013d-d602-0800270c66d6" xmi:uuid="31377740-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="341" y="1795" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184574017_807375_385984" xmi:uuid="c1ef0910-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_SubsetMember"/>
      <ownedElement xmi:id="c176e3f0-9159-013c-7154-0a5172f4a469" xmi:uuid="c176e500-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_SubsetMember"/>
        <text>SubsetMember</text>
      </ownedElement>
      <ownedElement xmi:id="3d058800-6c45-013d-d602-0800270c66d6" xmi:uuid="3d0588e0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="617" y="1795" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184575821_559065_386108" xmi:uuid="c2098a50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_392073_63003"/>
      <ownedElement xmi:id="c1f31b40-9159-013c-7154-0a5172f4a469" xmi:uuid="c1f31c50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_392073_63003"/>
        <text>System</text>
      </ownedElement>
      <ownedElement xmi:id="42432f10-6c45-013d-d602-0800270c66d6" xmi:uuid="42433020-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="893" y="1795" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184577572_406817_386221" xmi:uuid="c21c9750-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_348435_63004"/>
      <ownedElement xmi:id="c20af560-9159-013c-7154-0a5172f4a469" xmi:uuid="c20af670-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199043_348435_63004"/>
        <text>SystemVersion</text>
      </ownedElement>
      <ownedElement xmi:id="43655ea0-6c45-013d-d602-0800270c66d6" xmi:uuid="43655f80-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1845" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184579679_834348_386358" xmi:uuid="c234bcf0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199044_378163_63005"/>
      <ownedElement xmi:id="c21e0680-9159-013c-7154-0a5172f4a469" xmi:uuid="c21e0790-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../System/System.xmi#_18_4_1_2b2015d_1633962199044_378163_63005"/>
        <text>SystemView</text>
      </ownedElement>
      <ownedElement xmi:id="44726500-6c45-013d-d602-0800270c66d6" xmi:uuid="447265d0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="280" y="1845" width="195" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184581231_417749_386475" xmi:uuid="c285e430-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
      <ownedElement xmi:id="c23871d0-9159-013c-7154-0a5172f4a469" xmi:uuid="c2387350-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584019296903_594538_60780"/>
        <text>TaskElement</text>
      </ownedElement>
      <ownedElement xmi:id="45c05c30-6c45-013d-d602-0800270c66d6" xmi:uuid="45c05d10-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="495" y="1845" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184583310_263289_386585" xmi:uuid="c2e32750-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
      <ownedElement xmi:id="c2897c00-9159-013c-7154-0a5172f4a469" xmi:uuid="c2897d20-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584012430995_84482_59290"/>
        <text>TaskMethod</text>
      </ownedElement>
      <ownedElement xmi:id="4a288010-6c45-013d-d602-0800270c66d6" xmi:uuid="4a2880c0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="753" y="1845" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184585381_697453_386716" xmi:uuid="c3414df0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
      <ownedElement xmi:id="c2e72060-9159-013c-7154-0a5172f4a469" xmi:uuid="c2e721b0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584018942856_88925_60661"/>
        <text>TaskMethodVersion</text>
      </ownedElement>
      <ownedElement xmi:id="4eae2d40-6c45-013d-d602-0800270c66d6" xmi:uuid="4eae2e00-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1895" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184586510_106653_386827" xmi:uuid="c3842890-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584016875616_918689_60167"/>
      <ownedElement xmi:id="c344ebd0-9159-013c-7154-0a5172f4a469" xmi:uuid="c344ece0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../TaskDescription/TaskDescription.xmi#_18_4_1_1b310459_1584016875616_918689_60167"/>
        <text>TaskObjective</text>
      </ownedElement>
      <ownedElement xmi:id="532b7530-6c45-013d-d602-0800270c66d6" xmi:uuid="532b7600-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="323" y="1895" width="238" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184587344_552151_386914" xmi:uuid="c45017e0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_TimeInterval"/>
      <ownedElement xmi:id="c39006b0-9159-013c-7154-0a5172f4a469" xmi:uuid="c39007c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_TimeInterval"/>
        <text>TimeInterval</text>
      </ownedElement>
      <ownedElement xmi:id="575c2ea0-6c45-013d-d602-0800270c66d6" xmi:uuid="575c2f50-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="581" y="1895" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184588442_30245_387017" xmi:uuid="c487c0c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642455582242_622357_69835"/>
      <ownedElement xmi:id="c4533580-9159-013c-7154-0a5172f4a469" xmi:uuid="c4533680-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642455582242_622357_69835"/>
        <text>TypeOfPerson</text>
      </ownedElement>
      <ownedElement xmi:id="5f523170-6c45-013d-d602-0800270c66d6" xmi:uuid="5f523230-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="857" y="1895" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184589407_820337_387119" xmi:uuid="c4bd1980-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642456106177_836909_70167"/>
      <ownedElement xmi:id="c48afcb0-9159-013c-7154-0a5172f4a469" xmi:uuid="c48afec0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../PositionsAndSkills/PositionsAndSkills.xmi#_18_4_1_6b1022a_1642456106177_836909_70167"/>
        <text>TypeOfPersonDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="619e2730-6c45-013d-d602-0800270c66d6" xmi:uuid="619e2880-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1945" width="246" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184589576_845835_387164" xmi:uuid="c50c0cd0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_PreDefinedTypeQualifier"/>
      <ownedElement xmi:id="c4c8a7e0-9159-013c-7154-0a5172f4a469" xmi:uuid="c4c8aa80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_PreDefinedTypeQualifier"/>
        <text>TypeQualifier</text>
      </ownedElement>
      <ownedElement xmi:id="64991e80-6c45-013d-d602-0800270c66d6" xmi:uuid="64991f40-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="331" y="1945" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184590229_604486_387252" xmi:uuid="c5e1ba40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_UncertaintyQualifier"/>
      <ownedElement xmi:id="c5176b80-9159-013c-7154-0a5172f4a469" xmi:uuid="c5176c80-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_UncertaintyQualifier"/>
        <text>UncertaintyQualifier</text>
      </ownedElement>
      <ownedElement xmi:id="67cf5b40-6c45-013d-d602-0800270c66d6" xmi:uuid="67cf5bd0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="607" y="1945" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184590986_150038_387328" xmi:uuid="c70c1f20-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_Unit"/>
      <ownedElement xmi:id="c5ed4650-9159-013c-7154-0a5172f4a469" xmi:uuid="c5ed4af0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_Unit"/>
        <text>Unit</text>
      </ownedElement>
      <ownedElement xmi:id="6faea1f0-6c45-013d-d602-0800270c66d6" xmi:uuid="6faea2c0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="883" y="1945" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184592442_537802_387445" xmi:uuid="c7442c50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504194061252_379638_26123"/>
      <ownedElement xmi:id="c70f1c30-9159-013c-7154-0a5172f4a469" xmi:uuid="c70f1d40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504194061252_379638_26123"/>
        <text>Validation</text>
      </ownedElement>
      <ownedElement xmi:id="7ae6b260-6c45-013d-d602-0800270c66d6" xmi:uuid="7ae6b390-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="1995" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184592612_151890_387491" xmi:uuid="c79dc8c0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_6b1022a_1579187271168_230633_51858"/>
      <ownedElement xmi:id="c7506f70-9159-013c-7154-0a5172f4a469" xmi:uuid="c7507080-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_6b1022a_1579187271168_230633_51858"/>
        <text>ValueFormatTypeQualifier</text>
      </ownedElement>
      <ownedElement xmi:id="7d804990-6c45-013d-d602-0800270c66d6" xmi:uuid="7d804a40-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="368" y="1995" width="256" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184594252_634449_387618" xmi:uuid="c7d6b010-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504191936214_536008_25660"/>
      <ownedElement xmi:id="c7a0db30-9159-013c-7154-0a5172f4a469" xmi:uuid="c7a0dc40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_8e001ed_1504191936214_536008_25660"/>
        <text>Verification</text>
      </ownedElement>
      <ownedElement xmi:id="8011a520-6c45-013d-d602-0800270c66d6" xmi:uuid="8011a5c0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="644" y="1995" width="283" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184595545_36087_387857" xmi:uuid="c8437820-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ViewContext"/>
      <ownedElement xmi:id="c7dbbe20-9159-013c-7154-0a5172f4a469" xmi:uuid="c7dbbf40-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_ViewContext"/>
        <text>ViewContext</text>
      </ownedElement>
      <ownedElement xmi:id="820986f0-6c45-013d-d602-0800270c66d6" xmi:uuid="82098780-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="947" y="1995" width="282" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184597152_651776_387958" xmi:uuid="c85da3f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkOrder"/>
      <ownedElement xmi:id="c847fe40-9159-013c-7154-0a5172f4a469" xmi:uuid="c847ff50-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkOrder"/>
        <text>WorkOrder</text>
      </ownedElement>
      <ownedElement xmi:id="86293de0-6c45-013d-d602-0800270c66d6" xmi:uuid="86293ec0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="2045" width="247" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184598660_494805_388074" xmi:uuid="c8737be0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkRequest"/>
      <ownedElement xmi:id="c85f1980-9159-013c-7154-0a5172f4a469" xmi:uuid="c85f1a90-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../WorkManagement/WorkManagement.xmi#_WorkRequest"/>
        <text>WorkRequest</text>
      </ownedElement>
      <ownedElement xmi:id="86fb13f0-6c45-013d-d602-0800270c66d6" xmi:uuid="86fb14a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="332" y="2045" width="247" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1343" height="2125"/>
    <name>MessageContentSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703184598694_636168_388115" xmi:uuid="c8745a30-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Message.xmi#_18_4_1_8e001ed_1498551967680_699600_14130"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184598725_772510_388147" xmi:uuid="c8790da0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768253826_673517_32117"/>
      <ownedElement xmi:id="c876b780-9159-013c-7154-0a5172f4a469" xmi:uuid="c876b880-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768253826_673517_32117"/>
        <text>MessageDefinerSelect</text>
      </ownedElement>
      <ownedElement xmi:id="c877cf20-9159-013c-7154-0a5172f4a469" xmi:uuid="c877d000-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="c8784890-9159-013c-7154-0a5172f4a469" xmi:uuid="c8784950-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="925" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184600148_497563_388214" xmi:uuid="c92ec900-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
      <ownedElement xmi:id="c87ff6a0-9159-013c-7154-0a5172f4a469" xmi:uuid="c87ff7b0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Organization"/>
        <text>Organization</text>
      </ownedElement>
      <ownedElement xmi:id="88e35bc0-6c45-013d-d602-0800270c66d6" xmi:uuid="88e35c70-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184601524_105189_388277" xmi:uuid="c9cf54f0-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
      <ownedElement xmi:id="c9360b00-9159-013c-7154-0a5172f4a469" xmi:uuid="c9360c20-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_Person"/>
        <text>Person</text>
      </ownedElement>
      <ownedElement xmi:id="8f279b90-6c45-013d-d602-0800270c66d6" xmi:uuid="8f279c80-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="360" y="95" width="275" height="35"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703184603229_603522_388367" xmi:uuid="ca89fc10-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
      <ownedElement xmi:id="c9d64070-9159-013c-7154-0a5172f4a469" xmi:uuid="c9d64180-9159-013c-7154-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ManagementResources/ManagementResources.xmi#_PersonInOrganization"/>
        <text>PersonInOrganization</text>
      </ownedElement>
      <ownedElement xmi:id="94b92e80-6c45-013d-d602-0800270c66d6" xmi:uuid="94b92f30-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="655" y="95" width="275" height="35"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="985" height="175"/>
    <name>MessageDefinerSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_2b2015d_1539766324792_920805_14453" xmi:uuid="ca70a8ee-505c-439e-b567-d5de324cede3" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="Message.xmi#_18_4_1_8e001ed_1498551967680_699600_14130"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539766477349_925637_14491" xmi:uuid="462135e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539766477342_290236_14489"/>
      <ownedElement xmi:id="460e06b0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="460e0710-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539766477342_290236_14489"/>
        <text>Message</text>
      </ownedElement>
      <ownedElement xmi:id="460f9b60-3aa6-0138-3edd-418b172fba9f" xmi:uuid="460f9bb0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="461fdb10-3aa6-0138-3edd-418b172fba9f" xmi:uuid="461fdb70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="462018c0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="462018f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="46205860-3aa6-0138-3edd-418b172fba9f" xmi:uuid="462058b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767187917_535910_31246"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="4620a650-3aa6-0138-3edd-418b172fba9f" xmi:uuid="4620a690-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767266778_110128_31306"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="4620f3b0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="4620f3f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767301194_187647_31316"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="46213130-3aa6-0138-3edd-418b172fba9f" xmi:uuid="46213160-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767340834_944448_31326"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="224" y="224" width="179" height="108"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539767618248_620468_31519" xmi:uuid="4630e2b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767618244_553303_31517"/>
      <ownedElement xmi:id="462254e0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="46225520-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767618244_553303_31517"/>
        <text>Envelope</text>
      </ownedElement>
      <ownedElement xmi:id="4623f640-3aa6-0138-3edd-418b172fba9f" xmi:uuid="4623f690-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="462fb400-3aa6-0138-3edd-418b172fba9f" xmi:uuid="462fb460-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="462ff1d0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="462ff210-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="46306650-3aa6-0138-3edd-418b172fba9f" xmi:uuid="46306680-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767651915_229162_31570"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="db307680-6c41-013d-d602-0800270c66d6" xmi:uuid="db307750-6c41-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_65b021e_1715863757345_254287_125738"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="46302ca0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="46302cd0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767633550_234866_31562"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="4630a1c0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="4630a200-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767676695_757149_31578"/>
          <text>SameAs</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="497" y="224" width="179" height="108"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539767768929_82961_31692" xmi:uuid="4632ed30-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767768895_438270_31677"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539767768901_762959_31682" xmi:uuid="4632a2d0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767713754_743693_31588"/>
        <bounds x="406" y="254" width="47" height="13"/>
        <text>Wrapping</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539767768902_551351_31684" xmi:uuid="4632e6b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767713754_743693_31588"/>
        <bounds x="406" y="273" width="24" height="13"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1539767618248_620468_31519"/>
      <target xmi:idref="_18_4_1_2b2015d_1539766477349_925637_14491"/>
      <waypoint x="497" y="270"/>
      <waypoint x="403" y="270"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539767829106_919881_31731" xmi:uuid="463723b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767819677_98372_31714"/>
      <ownedElement xmi:id="4633dfe0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="4633e030-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767819677_98372_31714"/>
        <text>MessageContentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="463573b0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="46357430-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="4635c190-3aa6-0138-3edd-418b172fba9f" xmi:uuid="4635c1e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="336" y="378" width="136" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539767829123_111380_31776" xmi:uuid="46393490-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767829072_334502_31720"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539767829103_595154_31725" xmi:uuid="4638e540-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767797977_547828_31711"/>
        <bounds x="328" y="362" width="44" height="13"/>
        <text>Contains</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539767829104_790047_31727" xmi:uuid="46392d60-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767797977_547828_31711"/>
        <bounds x="378" y="362" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1539766477349_925637_14491"/>
      <target xmi:idref="_18_4_1_2b2015d_1539767829106_919881_31731"/>
      <waypoint x="375" y="332"/>
      <waypoint x="375" y="378"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539767899343_626832_31801" xmi:uuid="46434a50-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767899339_172189_31799"/>
      <ownedElement xmi:id="463a36c0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="463a3830-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767899339_172189_31799"/>
        <text>MessageRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="463bde20-3aa6-0138-3edd-418b172fba9f" xmi:uuid="463bde70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="21" y="224" width="126" height="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539768178692_692465_32049" xmi:uuid="464553f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768178676_79130_32034"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640627880713_307255_67169" xmi:uuid="8c1d6220-6aed-013a-da21-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768178676_27573_32035"/>
        <bounds x="150" y="252" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539768178682_692396_32039" xmi:uuid="46450800-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768128341_706152_32020"/>
        <bounds x="169" y="233" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539768178683_255943_32041" xmi:uuid="46454df0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768128341_706152_32020"/>
        <bounds x="185" y="252" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1539767899343_626832_31801"/>
      <target xmi:idref="_18_4_1_2b2015d_1539766477349_925637_14491"/>
      <waypoint x="147" y="249"/>
      <waypoint x="224" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539768180788_633986_32079" xmi:uuid="46474cd0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768180769_946855_32064"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640627891698_916620_67175" xmi:uuid="8c20ecf0-6aed-013a-da21-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768180769_250353_32065"/>
        <bounds x="150" y="290" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539768180776_194559_32069" xmi:uuid="46470360-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768163699_454892_32027"/>
        <bounds x="183" y="271" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539768180777_593343_32071" xmi:uuid="464746a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768163699_454892_32027"/>
        <bounds x="197" y="290" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1539767899343_626832_31801"/>
      <target xmi:idref="_18_4_1_2b2015d_1539766477349_925637_14491"/>
      <waypoint x="147" y="287"/>
      <waypoint x="224" y="287"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539768257707_172748_32134" xmi:uuid="464c63e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768253826_673517_32117"/>
      <ownedElement xmi:id="46487fa0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="464880f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768253826_673517_32117"/>
        <text>MessageDefinerSelect</text>
      </ownedElement>
      <ownedElement xmi:id="464aa8e0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="464aa970-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="464aeb70-3aa6-0138-3edd-418b172fba9f" xmi:uuid="464aebb0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="168" y="378" width="132" height="48"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539768257718_9490_32179" xmi:uuid="464e9970-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768257673_133310_32123"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539768257705_702376_32128" xmi:uuid="464e4510-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768229461_709932_32114"/>
        <bounds x="209" y="362" width="51" height="13"/>
        <text>DefinedBy</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539768257706_574777_32130" xmi:uuid="464e9210-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768229461_709932_32114"/>
        <bounds x="266" y="362" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1539766477349_925637_14491"/>
      <target xmi:idref="_18_4_1_2b2015d_1539768257707_172748_32134"/>
      <waypoint x="263" y="332"/>
      <waypoint x="263" y="378"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539768315082_997369_32211" xmi:uuid="46589880-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768315078_454856_32209"/>
      <ownedElement xmi:id="464f8e30-3aa6-0138-3edd-418b172fba9f" xmi:uuid="464f8e70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768315078_454856_32209"/>
        <text>EnvelopeRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="465114a0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="465114e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="749" y="224" width="126" height="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539768578995_236928_32404" xmi:uuid="465abf30-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768578979_189105_32389"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640627842596_817669_67157" xmi:uuid="8c360590-6aed-013a-da21-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768578979_750820_32390"/>
        <bounds x="722" y="252" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539768578985_253521_32394" xmi:uuid="465a5a80-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768552022_367749_32382"/>
        <bounds x="691" y="233" width="40" height="13"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539768578986_122544_32396" xmi:uuid="465ab9d0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768552022_367749_32382"/>
        <bounds x="691" y="252" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1539768315082_997369_32211"/>
      <target xmi:idref="_18_4_1_2b2015d_1539767618248_620468_31519"/>
      <waypoint x="749" y="249"/>
      <waypoint x="676" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539768599854_350360_32441" xmi:uuid="465ccb30-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768599834_819553_32426"/>
      <ownedElement xmi:id="_18_4_1_6b1022a_1640627858441_10332_67163" xmi:uuid="8c397c90-6aed-013a-da21-3770a1b6a6fd" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768599834_262255_32427"/>
        <bounds x="722" y="294" width="24" height="13"/>
        <text>0..*</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539768599843_800459_32431" xmi:uuid="465c7ea0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768583591_733343_32419"/>
        <bounds x="679" y="275" width="38" height="13"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539768599844_479410_32433" xmi:uuid="465cc620-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768583591_733343_32419"/>
        <bounds x="679" y="294" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1539768315082_997369_32211"/>
      <target xmi:idref="_18_4_1_2b2015d_1539767618248_620468_31519"/>
      <waypoint x="749" y="291"/>
      <waypoint x="676" y="291"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539939183156_903812_31585" xmi:uuid="4673e190-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_ExchangeContext"/>
      <ownedElement xmi:id="465dcb70-3aa6-0138-3edd-418b172fba9f" xmi:uuid="465dcbc0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_ExchangeContext"/>
        <text>ExchangeContext</text>
      </ownedElement>
      <ownedElement xmi:id="465f3dd0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="465f3e10-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="4670bc20-3aa6-0138-3edd-418b172fba9f" xmi:uuid="4670bc90-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4670f990-3aa6-0138-3edd-418b172fba9f" xmi:uuid="4670f9c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="46716f70-3aa6-0138-3edd-418b172fba9f" xmi:uuid="46716fb0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_2_attr_ExchangeContext-Description"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="467134f0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="46713520-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947780216_549454_33014"/>
          <text>Id</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="467215b0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="46721600-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="46725540-3aa6-0138-3edd-418b172fba9f" xmi:uuid="46725570-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="46730370-3aa6-0138-3edd-418b172fba9f" xmi:uuid="467303a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_2_attr_ExchangeContext-IdentificationContext"/>
          <text>DefaultIdentificationContext</text>
        </ownedElement>
        <ownedElement xmi:id="46728f00-3aa6-0138-3edd-418b172fba9f" xmi:uuid="46728f30-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_2_attr_ExchangeContext-DefaultLanguage"/>
          <text>DefaultLanguage</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="467366b0-3aa6-0138-3edd-418b172fba9f" xmi:uuid="467366e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="4673a490-3aa6-0138-3edd-418b172fba9f" xmi:uuid="4673a4c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>values</text>
        </ownedElement>
        <ownedElement xmi:id="4673df40-3aa6-0138-3edd-418b172fba9f" xmi:uuid="4673df70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539939429461_545710_31632"/>
          <text>ClassLibrary</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="203" y="14" width="530" height="163"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539939531634_52981_31648" xmi:uuid="4675d510-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539939533519_336106_31651"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539939533609_137688_31661" xmi:uuid="467589c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539939533519_997165_31652"/>
        <bounds x="228" y="180" width="88" height="13"/>
        <text>ExchangeContext</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539939575871_488239_31697" xmi:uuid="4675cce0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539939533519_997165_31652"/>
        <bounds x="322" y="180" width="24" height="13"/>
        <text>1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1539766477349_925637_14491"/>
      <target xmi:idref="_18_4_1_2b2015d_1539939183156_903812_31585"/>
      <waypoint x="319" y="224"/>
      <waypoint x="319" y="177"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1583496635810_845171_53777" xmi:uuid="91c17570-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1583496521130_514720_53768"/>
      <ownedElement xmi:id="91be1160-7cb3-0138-410d-418b172fba9f" xmi:uuid="91be1230-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLNameLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1583496521130_514720_53768"/>
        <text>Acknowledgement</text>
      </ownedElement>
      <ownedElement xmi:id="91bf03f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="91bf0430-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="91c01b80-7cb3-0138-410d-418b172fba9f" xmi:uuid="91c01bc0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="91c06c60-7cb3-0138-410d-418b172fba9f" xmi:uuid="91c06d00-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="91c171c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="91c17210-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1583496571355_837641_53770"/>
          <text>Definition</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="504" y="371" width="155" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1583496772319_671405_53838" xmi:uuid="91c3be70-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539771118495_575825_32525"/>
      <ownedElement xmi:id="_18_4_1_2b2015d_1583496772156_847129_53828" xmi:uuid="91c35010-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539771086464_38173_32518"/>
        <bounds x="502" y="355" width="66" height="13"/>
        <text>Acknowledge</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1583496772158_972316_53830" xmi:uuid="91c3ba40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539771086464_38173_32518"/>
        <bounds x="574" y="355" width="24" height="13"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_2b2015d_1539767618248_620468_31519"/>
      <target xmi:idref="_18_4_1_2b2015d_1583496635810_845171_53777"/>
      <waypoint x="571" y="332"/>
      <waypoint x="571" y="371"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="890" height="455"/>
    <name>Message</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446295695_950799_279456" xmi:uuid="00c85d90-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_18_4_1_2b2015d_1539766477342_290236_14489"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295723_590917_279488" xmi:uuid="013cec30-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539773059420_335939_32772"/>
      <ownedElement xmi:id="013bb830-6c46-013d-d602-0800270c66d6" xmi:uuid="013bb910-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539773059420_335939_32772"/>
        <text>message:Message</text>
      </ownedElement>
      <ownedElement xmi:id="013cd930-6c46-013d-d602-0800270c66d6" xmi:uuid="013cd9f0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539773059420_335939_32772"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="133" height="430"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295741_166362_279522" xmi:uuid="013d76e0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="468" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295758_153540_279543" xmi:uuid="013e0710-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="468" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295779_49553_279564" xmi:uuid="0164bf90-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="468" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295806_673820_279585" xmi:uuid="01656880-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="468" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295823_735648_279606" xmi:uuid="01742d70-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="468" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295847_318228_279627" xmi:uuid="0174ed30-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="468" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295870_156847_279648" xmi:uuid="017ef680-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="468" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295889_603329_279669" xmi:uuid="017f8920-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="468" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295904_919276_279690" xmi:uuid="018f8230-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="468" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295917_538028_279711" xmi:uuid="01901670-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582544492124_146135_67014"/>
      <bounds x="468" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295930_541758_279732" xmi:uuid="0199e730-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_1b310459_1582545634443_36053_70703"/>
      <bounds x="468" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295948_532515_279753" xmi:uuid="019a7740-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="468" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295967_700322_279774" xmi:uuid="019b41f0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="468" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295982_47513_279795" xmi:uuid="01a6d4b0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="468" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295997_697144_279816" xmi:uuid="01b25e90-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="468" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296086_111722_279838" xmi:uuid="01b35e90-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="468" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296101_905512_279859" xmi:uuid="01c088e0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="468" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296115_832944_279880" xmi:uuid="01c14cd0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="468" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296128_151547_279901" xmi:uuid="01ccc900-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="468" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_68635_401351" xmi:uuid="01cd3a20-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601385601_772597_251654"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295741_166362_279522"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="62"/>
      <waypoint x="178" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_535650_401354" xmi:uuid="01cd4140-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601385695_871187_251676"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295758_153540_279543"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="82"/>
      <waypoint x="178" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_846104_401357" xmi:uuid="01cd4940-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601385779_450152_251698"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295779_49553_279564"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="102"/>
      <waypoint x="178" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_120465_401360" xmi:uuid="01cd50e0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736557405_683156_69512"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295806_673820_279585"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="122"/>
      <waypoint x="178" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_731180_401363" xmi:uuid="01cd5840-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601385886_308392_251741"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295823_735648_279606"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="142"/>
      <waypoint x="178" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_97804_401366" xmi:uuid="01cd5f70-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601385968_973705_251763"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295847_318228_279627"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="162"/>
      <waypoint x="178" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_835080_401369" xmi:uuid="01cd6720-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601386057_500783_251785"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295870_156847_279648"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="182"/>
      <waypoint x="178" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_136850_401372" xmi:uuid="01cd6d60-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601386147_537252_251807"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295889_603329_279669"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="202"/>
      <waypoint x="178" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_966883_401375" xmi:uuid="01cd7550-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601386234_268634_251829"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295904_919276_279690"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="222"/>
      <waypoint x="178" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_574118_401378" xmi:uuid="01cd7cb0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736554573_890786_69492"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295917_538028_279711"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="242"/>
      <waypoint x="178" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_689845_401381" xmi:uuid="01cd83e0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736551596_580464_69472"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295930_541758_279732"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="262"/>
      <waypoint x="178" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_942519_401384" xmi:uuid="01cd8b60-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736560099_459815_69532"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295948_532515_279753"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="282"/>
      <waypoint x="178" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_182669_401387" xmi:uuid="01cd9200-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736563343_158068_69552"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295967_700322_279774"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="302"/>
      <waypoint x="178" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_798356_401390" xmi:uuid="01cd99c0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601386392_96540_251935"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295982_47513_279795"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="322"/>
      <waypoint x="178" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_799160_401393" xmi:uuid="01cda130-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601386475_683840_251957"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295997_697144_279816"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="342"/>
      <waypoint x="178" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_984335_401396" xmi:uuid="01cda710-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1727446296001_869085_279834"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296086_111722_279838"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="362"/>
      <waypoint x="178" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_615112_401399" xmi:uuid="01cdae50-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601386558_382814_251979"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296101_905512_279859"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="382"/>
      <waypoint x="178" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_519152_401402" xmi:uuid="01cdb440-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601386646_635054_252001"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296115_832944_279880"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="402"/>
      <waypoint x="178" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496476_141709_401405" xmi:uuid="01cdbb80-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601386728_163701_252023"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296128_151547_279901"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295723_590917_279488"/>
      <waypoint x="468" y="422"/>
      <waypoint x="178" y="422"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="471" height="500"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446295223_640180_278847" xmi:uuid="1ef7dfd0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767899339_172189_31799"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295250_605484_278879" xmi:uuid="1f84e5e0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789667612_326294_42900"/>
      <ownedElement xmi:id="1f6f04c0-6c46-013d-d602-0800270c66d6" xmi:uuid="1f6f05d0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789667612_326294_42900"/>
        <text>relation:Message_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="1f704eb0-6c46-013d-d602-0800270c66d6" xmi:uuid="1f704f80-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789667612_326294_42900"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="195" height="230"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295266_141371_278913" xmi:uuid="1f928a30-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="559" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295284_734050_278934" xmi:uuid="1f9b2e70-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="559" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295303_600235_278955" xmi:uuid="1f9c30a0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="559" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295323_987767_278976" xmi:uuid="1fac5c60-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="559" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295342_192882_278997" xmi:uuid="1fad0240-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="559" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295360_376813_279018" xmi:uuid="1fada8e0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="559" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295381_628133_279039" xmi:uuid="1fae4540-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="559" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295403_929987_279060" xmi:uuid="1fc43ef0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="559" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295424_432727_279081" xmi:uuid="1fc51680-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="559" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496421_868181_401171" xmi:uuid="1fc52690-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736672125_414576_69857"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295266_141371_278913"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295250_605484_278879"/>
      <waypoint x="559" y="62"/>
      <waypoint x="240" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496421_600534_401174" xmi:uuid="1fc52e20-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736675132_517296_69877"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295284_734050_278934"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295250_605484_278879"/>
      <waypoint x="559" y="82"/>
      <waypoint x="240" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496421_60228_401177" xmi:uuid="1fc53440-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736690664_519610_69957"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295303_600235_278955"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295250_605484_278879"/>
      <waypoint x="559" y="102"/>
      <waypoint x="240" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496421_160679_401180" xmi:uuid="1fc53cd0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736669064_667873_69837"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295323_987767_278976"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295250_605484_278879"/>
      <waypoint x="559" y="122"/>
      <waypoint x="240" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496421_421773_401183" xmi:uuid="1fc54320-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736665800_179003_69817"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295342_192882_278997"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295250_605484_278879"/>
      <waypoint x="559" y="142"/>
      <waypoint x="240" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496421_874854_401186" xmi:uuid="1fc54a40-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736678762_863075_69897"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295360_376813_279018"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295250_605484_278879"/>
      <waypoint x="559" y="162"/>
      <waypoint x="240" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496422_257829_401189" xmi:uuid="1fc551c0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736686863_778039_69937"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295381_628133_279039"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295250_605484_278879"/>
      <waypoint x="559" y="182"/>
      <waypoint x="240" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496422_298887_401192" xmi:uuid="1fc55730-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736682540_962388_69917"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295403_929987_279060"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295250_605484_278879"/>
      <waypoint x="559" y="202"/>
      <waypoint x="240" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496422_416162_401195" xmi:uuid="1fc55e60-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736662307_839876_69797"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295424_432727_279081"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295250_605484_278879"/>
      <waypoint x="559" y="222"/>
      <waypoint x="240" y="222"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="562" height="300"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1539771646867_616142_32534" xmi:uuid="3830133d-c057-4f43-ad43-758518e53578" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_18_4_1_2b2015d_1539766477342_290236_14489"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539786017189_70942_40196" xmi:uuid="46894d60-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539786017179_4107_40192"/>
      <bounds x="1182" y="113" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539771652475_33918_32570" xmi:uuid="4689e140-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767301194_187647_31316"/>
      <ownedElement xmi:id="983eda40-7cb3-0138-410d-418b172fba9f" xmi:uuid="983edac0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767301194_187647_31316"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="983ffaa0-7cb3-0138-410d-418b172fba9f" xmi:uuid="983ffae0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767301194_187647_31316"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539775562848_599226_36026" xmi:uuid="4689a370-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="e3809110-6c45-013d-d602-0800270c66d6" xmi:uuid="e38091b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="262" y="52" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="244" y="61" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="56" width="217" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539771652488_643229_32601" xmi:uuid="468a7860-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767797977_547828_31711"/>
      <ownedElement xmi:id="98422690-7cb3-0138-410d-418b172fba9f" xmi:uuid="984226e0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767797977_547828_31711"/>
        <text>Contains:MessageContentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="98434760-7cb3-0138-410d-418b172fba9f" xmi:uuid="984347a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767797977_547828_31711"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539780698721_301610_37481" xmi:uuid="468a3fa0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
        <ownedElement xmi:id="e3b62080-6c45-013d-d602-0800270c66d6" xmi:uuid="e3b62130-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
          <bounds x="290" y="136" width="155" height="13"/>
          <text>mci : message_content_item [1]</text>
        </ownedElement>
        <bounds x="272" y="145" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="140" width="245" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539771652496_747961_32632" xmi:uuid="468b8360-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768229461_709932_32114"/>
      <ownedElement xmi:id="98457560-7cb3-0138-410d-418b172fba9f" xmi:uuid="984575a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768229461_709932_32114"/>
        <text>DefinedBy:MessageDefinerSelect</text>
      </ownedElement>
      <ownedElement xmi:id="98468380-7cb3-0138-410d-418b172fba9f" xmi:uuid="984683c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768229461_709932_32114"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539784119312_362492_37739" xmi:uuid="468ad830-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784076502_467167_37727"/>
        <ownedElement xmi:id="e3ee2700-6c45-013d-d602-0800270c66d6" xmi:uuid="e3ee27b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784076502_467167_37727"/>
          <bounds x="290" y="170" width="165" height="13"/>
          <text>mds : message_definer_select [1]</text>
        </ownedElement>
        <bounds x="272" y="179" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="175" width="245" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539771652505_759073_32663" xmi:uuid="468b98d0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767266778_110128_31306"/>
      <ownedElement xmi:id="985558a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="985559b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767266778_110128_31306"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="98567400-7cb3-0138-410d-418b172fba9f" xmi:uuid="98567440-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767266778_110128_31306"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="420" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539771652514_671763_32694" xmi:uuid="468ba680-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767187917_535910_31246"/>
      <ownedElement xmi:id="9864ebf0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9864ec80-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767187917_535910_31246"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="98660b10-7cb3-0138-410d-418b172fba9f" xmi:uuid="98660b60-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767187917_535910_31246"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="210" width="145" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539771652523_973144_32725" xmi:uuid="468c49e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767340834_944448_31326"/>
      <ownedElement xmi:id="98748710-7cb3-0138-410d-418b172fba9f" xmi:uuid="98748790-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767340834_944448_31326"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="9875aac0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9875aaf0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767340834_944448_31326"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539785745416_449167_39908" xmi:uuid="468c0600-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="e5b7cd50-6c45-013d-d602-0800270c66d6" xmi:uuid="e5b7cdf0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="185" y="772" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="167" y="781" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="777" width="140" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539773059427_303682_32774" xmi:uuid="468c6a30-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539773059420_335939_32772"/>
      <ownedElement xmi:id="988623f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="98862470-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539773059420_335939_32772"/>
        <text>message:Message</text>
      </ownedElement>
      <ownedElement xmi:id="98874550-7cb3-0138-410d-418b172fba9f" xmi:uuid="98874590-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539773059420_335939_32772"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="e6506660-6c45-013d-d602-0800270c66d6" xmi:uuid="e6506700-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e650e760-6c45-013d-d602-0800270c66d6" xmi:uuid="e650e7b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539773132251_953263_32803" xmi:uuid="98b8e0b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-contains"/>
          <ownedElement xmi:id="98a80820-7cb3-0138-410d-418b172fba9f" xmi:uuid="98a808a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-contains"/>
            <text>contains:content_item_or_referenced_content_item</text>
          </ownedElement>
          <ownedElement xmi:id="98b87940-7cb3-0138-410d-418b172fba9f" xmi:uuid="98b879c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-contains"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="140" width="334" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539773132259_142096_32834" xmi:uuid="98e9cb40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-defined_by"/>
          <ownedElement xmi:id="98d8d6f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="98d8d770-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-defined_by"/>
            <text>defined_by:message_definer_select</text>
          </ownedElement>
          <ownedElement xmi:id="98e96b60-7cb3-0138-410d-418b172fba9f" xmi:uuid="98e96c60-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-defined_by"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="805" y="175" width="248" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539773132269_198117_32865" xmi:uuid="990ab2d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-id"/>
          <ownedElement xmi:id="98fa1df0-7cb3-0138-410d-418b172fba9f" xmi:uuid="98fa1e60-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="990a5740-7cb3-0138-410d-418b172fba9f" xmi:uuid="990a57b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="805" y="210" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539773132278_498469_32896" xmi:uuid="992c1560-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-message_type"/>
          <ownedElement xmi:id="991b4780-7cb3-0138-410d-418b172fba9f" xmi:uuid="991b47f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-message_type"/>
            <text>message_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="992bb930-7cb3-0138-410d-418b172fba9f" xmi:uuid="992bb9a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-message_type"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="805" y="294" width="154" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539773132287_327962_32927" xmi:uuid="994d20c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-purpose"/>
          <ownedElement xmi:id="993c4f80-7cb3-0138-410d-418b172fba9f" xmi:uuid="993c4ff0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-purpose"/>
            <text>purpose:String</text>
          </ownedElement>
          <ownedElement xmi:id="994caf90-7cb3-0138-410d-418b172fba9f" xmi:uuid="994cb010-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message-purpose"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="805" y="420" width="131" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="791" y="112" width="355" height="343"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539780461072_426610_37306" xmi:uuid="468c7f30-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780461065_198314_37304"/>
      <ownedElement xmi:id="995ddca0-7cb3-0138-410d-418b172fba9f" xmi:uuid="995ddd20-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780461065_198314_37304"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="995efbe0-7cb3-0138-410d-418b172fba9f" xmi:uuid="995efc20-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780461065_198314_37304"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ebfa6eb0-6c45-013d-d602-0800270c66d6" xmi:uuid="ebfa6f50-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ebfb3c50-6c45-013d-d602-0800270c66d6" xmi:uuid="ebfb3d30-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539780498531_658430_37366" xmi:uuid="99906aa0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="997f6fd0-7cb3-0138-410d-418b172fba9f" xmi:uuid="997f7110-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="998ffe80-7cb3-0138-410d-418b172fba9f" xmi:uuid="998fff00-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="476" y="70" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="469" y="42" width="282" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539780521462_894602_37416" xmi:uuid="468c85e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780523049_464506_37419"/>
      <source xmi:idref="_18_4_1_2b2015d_1539775562848_599226_36026"/>
      <target xmi:idref="_18_4_1_2b2015d_1539780461072_426610_37306"/>
      <waypoint x="259" y="68"/>
      <waypoint x="469" y="68"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539780561922_181748_37449" xmi:uuid="468c9910-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780563761_653706_37452"/>
      <source xmi:idref="_18_4_1_2b2015d_1539780498531_658430_37366"/>
      <target xmi:idref="_18_4_1_2b2015d_1539773059427_303682_32774"/>
      <waypoint x="660" y="81"/>
      <waypoint x="910" y="81"/>
      <waypoint x="910" y="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539783882772_921888_37592" xmi:uuid="468cad10-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539783882765_60558_37590"/>
      <ownedElement xmi:id="99a0fd90-7cb3-0138-410d-418b172fba9f" xmi:uuid="99a0fe20-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539783882765_60558_37590"/>
        <text>referenceItem:Referenced_content_item</text>
      </ownedElement>
      <ownedElement xmi:id="99a22860-7cb3-0138-410d-418b172fba9f" xmi:uuid="99a228b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539783882765_60558_37590"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="edc4a400-6c45-013d-d602-0800270c66d6" xmi:uuid="edc4a4b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="edd1e2b0-6c45-013d-d602-0800270c66d6" xmi:uuid="edd1e3a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539783950829_668268_37633" xmi:uuid="99d3f8c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Referenced_content_item-contents"/>
          <ownedElement xmi:id="99c2ea20-7cb3-0138-410d-418b172fba9f" xmi:uuid="99c2eab0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Referenced_content_item-contents"/>
            <text>contents:message_content_item</text>
          </ownedElement>
          <ownedElement xmi:id="99d39d00-7cb3-0138-410d-418b172fba9f" xmi:uuid="99d39d70-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Referenced_content_item-contents"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="483" y="140" width="219" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="469" y="112" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539783963538_641455_37679" xmi:uuid="468cbda0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539783965254_664063_37680"/>
      <source xmi:idref="_18_4_1_2b2015d_1539783950829_668268_37633"/>
      <target xmi:idref="_18_4_1_2b2015d_1539780698721_301610_37481"/>
      <waypoint x="483" y="152"/>
      <waypoint x="287" y="152"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539783980104_890563_37709" xmi:uuid="468cd040-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539783981430_903098_37710"/>
      <source xmi:idref="_18_4_1_2b2015d_1539773132251_953263_32803"/>
      <target xmi:idref="_18_4_1_2b2015d_1539783882772_921888_37592"/>
      <waypoint x="805" y="151"/>
      <waypoint x="763" y="151"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784160940_888841_37784" xmi:uuid="468cd6c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784163060_85385_37785"/>
      <source xmi:idref="_18_4_1_2b2015d_1539773132259_142096_32834"/>
      <target xmi:idref="_18_4_1_2b2015d_1539784119312_362492_37739"/>
      <waypoint x="805" y="186"/>
      <waypoint x="287" y="186"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784215785_20891_37820" xmi:uuid="468f2350-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784215778_818221_37818"/>
      <ownedElement xmi:id="99e3cb80-7cb3-0138-410d-418b172fba9f" xmi:uuid="99e3cbe0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784215778_818221_37818"/>
        <text>descSelect:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539784301466_24279_37884" xmi:uuid="468d2d70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="f0452d60-6c45-013d-d602-0800270c66d6" xmi:uuid="f0452e80-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="303" y="415" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="357" y="424" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539784301473_497677_37894" xmi:uuid="468dc800-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="f0b54660-6c45-013d-d602-0800270c66d6" xmi:uuid="f0b54700-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="568" y="416" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="550" y="425" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539784301479_504399_37904" xmi:uuid="468e7ef0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="f11ad140-6c45-013d-d602-0800270c66d6" xmi:uuid="f11ad480-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="493" y="465" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="483" y="447" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539784301484_900996_37914" xmi:uuid="468f08e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="f19a0430-6c45-013d-d602-0800270c66d6" xmi:uuid="f19a04d0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="388" y="465" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="378" y="447" width="15" height="15"/>
      </ownedElement>
      <bounds x="357" y="413" width="208" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784393888_626691_37963" xmi:uuid="468f2eb0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784394887_108429_37966"/>
      <source xmi:idref="_18_4_1_2b2015d_1539784301466_24279_37884"/>
      <target xmi:idref="_18_4_1_2b2015d_1539771652505_759073_32663"/>
      <waypoint x="357" y="431"/>
      <waypoint x="241" y="431"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784416392_526461_37990" xmi:uuid="468f3710-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784418748_397578_37991"/>
      <source xmi:idref="_18_4_1_2b2015d_1539773132287_327962_32927"/>
      <target xmi:idref="_18_4_1_2b2015d_1539784301473_497677_37894"/>
      <waypoint x="805" y="431"/>
      <waypoint x="565" y="431"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784432793_258709_38012" xmi:uuid="468fbfc0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784432786_685090_38010"/>
      <ownedElement xmi:id="99f4efe0-7cb3-0138-410d-418b172fba9f" xmi:uuid="99f4f100-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784432786_685090_38010"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="99f61850-7cb3-0138-410d-418b172fba9f" xmi:uuid="99f618d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784432786_685090_38010"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539784483488_370603_38111" xmi:uuid="468f8610-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="f2709180-6c45-013d-d602-0800270c66d6" xmi:uuid="f2709230-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="493" y="525" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="483" y="507" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="420" y="490" width="165" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784526211_215942_38228" xmi:uuid="468fd250-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784527841_202253_38231"/>
      <source xmi:idref="_18_4_1_2b2015d_1539784301479_504399_37904"/>
      <target xmi:idref="_18_4_1_2b2015d_1539784432793_258709_38012"/>
      <waypoint x="490" y="462"/>
      <waypoint x="490" y="490"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784539933_295284_38257" xmi:uuid="468fe830-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784539926_986430_38255"/>
      <ownedElement xmi:id="9a0765f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9a076670-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784539926_986430_38255"/>
        <text>descAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9a088b70-7cb3-0138-410d-418b172fba9f" xmi:uuid="9a088bb0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784539926_986430_38255"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="f304b9e0-6c45-013d-d602-0800270c66d6" xmi:uuid="f304ba70-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f3054640-6c45-013d-d602-0800270c66d6" xmi:uuid="f30546e0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539784575828_372404_38290" xmi:uuid="9a39d420-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="9a28d8d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9a28d950-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="9a3976d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9a397750-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="427" y="567" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="413" y="539" width="258" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784591326_913625_38334" xmi:uuid="468ff000-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784592846_609512_38337"/>
      <source xmi:idref="_18_4_1_2b2015d_1539784483488_370603_38111"/>
      <target xmi:idref="_18_4_1_2b2015d_1539784539933_295284_38257"/>
      <waypoint x="490" y="522"/>
      <waypoint x="490" y="539"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784597788_808766_38361" xmi:uuid="468ff8a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784599729_992293_38364"/>
      <source xmi:idref="_18_4_1_2b2015d_1539784575828_372404_38290"/>
      <target xmi:idref="_18_4_1_2b2015d_1539773059427_303682_32774"/>
      <waypoint x="602" y="578"/>
      <waypoint x="910" y="578"/>
      <waypoint x="910" y="455"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784703813_79546_38384" xmi:uuid="46900720-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784703805_359623_38382"/>
      <ownedElement xmi:id="9a4a4640-7cb3-0138-410d-418b172fba9f" xmi:uuid="9a4a46b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784703805_359623_38382"/>
        <text>descLangInd:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="9a4b65f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9a4b6640-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784703805_359623_38382"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f4d88bf0-6c45-013d-d602-0800270c66d6" xmi:uuid="f4d88ce0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f4e76000-6c45-013d-d602-0800270c66d6" xmi:uuid="f4e76100-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539784750547_181427_38421" xmi:uuid="9a6e6b20-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="9a5d6340-7cb3-0138-410d-418b172fba9f" xmi:uuid="9a5d6440-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="9a6e0d20-7cb3-0138-410d-418b172fba9f" xmi:uuid="9a6e0d90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="560" y="714" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539784750557_807573_38452" xmi:uuid="9a9f48c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="9a8e39b0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9a8e3a30-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="9a9eeec0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9a9eef40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="560" y="679" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539784750568_768511_38483" xmi:uuid="9acfa160-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="9abec3e0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9abec460-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="9acf4690-7cb3-0138-410d-418b172fba9f" xmi:uuid="9acf4720-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="560" y="644" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="546" y="616" width="246" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784773194_988241_38527" xmi:uuid="4690a560-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784773186_323549_38525"/>
      <ownedElement xmi:id="9ade0740-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ade07d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784773186_323549_38525"/>
        <text>descLang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="9adf2740-7cb3-0138-410d-418b172fba9f" xmi:uuid="9adf2790-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784773186_323549_38525"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539784791998_253507_38555" xmi:uuid="469063f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="f8e90bc0-6c45-013d-d602-0800270c66d6" xmi:uuid="f8e91b70-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="442" y="633" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="424" y="642" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="252" y="637" width="180" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784840380_518321_38642" xmi:uuid="4690b160-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784841738_630289_38643"/>
      <source xmi:idref="_18_4_1_2b2015d_1539784301484_900996_37914"/>
      <target xmi:idref="_18_4_1_2b2015d_1539784773194_988241_38527"/>
      <waypoint x="385" y="462"/>
      <waypoint x="385" y="637"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784876954_548615_38675" xmi:uuid="4690b9b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784879049_499070_38678"/>
      <source xmi:idref="_18_4_1_2b2015d_1539784750557_807573_38452"/>
      <target xmi:idref="_18_4_1_2b2015d_1539773059427_303682_32774"/>
      <waypoint x="788" y="690"/>
      <waypoint x="910" y="690"/>
      <waypoint x="910" y="455"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784892642_331703_38694" xmi:uuid="4690c660-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784892635_711575_38692"/>
      <ownedElement xmi:id="9ae0bb40-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ae0bb90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784892635_711575_38692"/>
        <text>purpose:String</text>
      </ownedElement>
      <ownedElement xmi:id="9ae1cab0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ae1caf0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784892635_711575_38692"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="294" y="714" width="190" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539784951125_901450_38744" xmi:uuid="4690cf20-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539784952451_112559_38747"/>
      <source xmi:idref="_18_4_1_2b2015d_1539784750547_181427_38421"/>
      <target xmi:idref="_18_4_1_2b2015d_1539784892642_331703_38694"/>
      <waypoint x="560" y="728"/>
      <waypoint x="484" y="728"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785005208_807913_38769" xmi:uuid="469202c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785005201_684841_38767"/>
      <ownedElement xmi:id="9af14f10-7cb3-0138-410d-418b172fba9f" xmi:uuid="9af14f90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785005201_684841_38767"/>
        <text>idSelect:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539785034111_654436_38789" xmi:uuid="46912300-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="f9c66ef0-6c45-013d-d602-0800270c66d6" xmi:uuid="f9c66f80-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="254" y="206" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="308" y="215" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539785034118_778631_38799" xmi:uuid="469184e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="fa333ad0-6c45-013d-d602-0800270c66d6" xmi:uuid="fa333d30-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="472" y="205" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="454" y="214" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539785034124_385360_38809" xmi:uuid="4691e7f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="fa86e690-6c45-013d-d602-0800270c66d6" xmi:uuid="fa86e730-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="366" y="255" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="356" y="237" width="15" height="15"/>
      </ownedElement>
      <bounds x="308" y="203" width="161" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785066118_812557_38846" xmi:uuid="46920ed0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785067467_535762_38849"/>
      <source xmi:idref="_18_4_1_2b2015d_1539785034111_654436_38789"/>
      <target xmi:idref="_18_4_1_2b2015d_1539771652514_671763_32694"/>
      <waypoint x="308" y="221"/>
      <waypoint x="180" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785096110_956362_38873" xmi:uuid="4692e9e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785096103_2133_38871"/>
      <ownedElement xmi:id="9b02b280-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b02b300-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785096103_2133_38871"/>
        <text>idDefault:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539785120052_28733_38897" xmi:uuid="46926290-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="fb72c1d0-6c45-013d-d602-0800270c66d6" xmi:uuid="fb72c280-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="504" y="230" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="560" y="215" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539785120058_939182_38907" xmi:uuid="4692cc10-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="fbd91570-6c45-013d-d602-0800270c66d6" xmi:uuid="fbd915f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="745" y="205" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="727" y="214" width="15" height="15"/>
      </ownedElement>
      <bounds x="560" y="203" width="182" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785138496_823756_38940" xmi:uuid="4692f310-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785140092_777905_38941"/>
      <source xmi:idref="_18_4_1_2b2015d_1539785120052_28733_38897"/>
      <target xmi:idref="_18_4_1_2b2015d_1539785034118_778631_38799"/>
      <waypoint x="560" y="221"/>
      <waypoint x="469" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785224122_282166_38978" xmi:uuid="4692fc50-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785225671_623723_38979"/>
      <source xmi:idref="_18_4_1_2b2015d_1539773132269_198117_32865"/>
      <target xmi:idref="_18_4_1_2b2015d_1539785120058_939182_38907"/>
      <waypoint x="805" y="221"/>
      <waypoint x="742" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785234447_944148_38998" xmi:uuid="46938040-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785234439_969699_38996"/>
      <ownedElement xmi:id="9b1291e0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b129260-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785234439_969699_38996"/>
        <text>identifiers:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="9b13ba40-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b13bbc0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785234439_969699_38996"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539785316544_369492_39093" xmi:uuid="469352b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="fce128f0-6c45-013d-d602-0800270c66d6" xmi:uuid="fce129c0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="350" y="315" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="340" y="297" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="308" y="280" width="150" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785339528_306158_39188" xmi:uuid="46938a90-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785340491_692167_39191"/>
      <source xmi:idref="_18_4_1_2b2015d_1539785034124_385360_38809"/>
      <target xmi:idref="_18_4_1_2b2015d_1539785234447_944148_38998"/>
      <waypoint x="364" y="252"/>
      <waypoint x="364" y="280"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785346494_320676_39213" xmi:uuid="4693a1c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785346487_904079_39211"/>
      <ownedElement xmi:id="9b24a1e0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b24a260-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785346487_904079_39211"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9b25bba0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b25bbf0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785346487_904079_39211"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="fd71f380-6c45-013d-d602-0800270c66d6" xmi:uuid="fd71f480-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="fd728a20-6c45-013d-d602-0800270c66d6" xmi:uuid="fd728c00-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539785399919_440598_39246" xmi:uuid="9b579e60-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="9b4696b0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b469730-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9b574540-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b5745c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="294" y="364" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="280" y="336" width="226" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785413480_773012_39290" xmi:uuid="4693bd40-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785414846_65570_39293"/>
      <source xmi:idref="_18_4_1_2b2015d_1539785399919_440598_39246"/>
      <target xmi:idref="_18_4_1_2b2015d_1539773059427_303682_32774"/>
      <waypoint x="477" y="375"/>
      <waypoint x="791" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785479538_933883_39319" xmi:uuid="4693c950-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785479531_226699_39317"/>
      <ownedElement xmi:id="9b58c970-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b58c9b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785479531_226699_39317"/>
        <text>msgType:String</text>
      </ownedElement>
      <ownedElement xmi:id="9b59dcf0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b59dd40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785479531_226699_39317"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="560" y="294" width="183" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785547697_918736_39363" xmi:uuid="4693d0a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785548451_141336_39366"/>
      <source xmi:idref="_18_4_1_2b2015d_1539773132278_498469_32896"/>
      <target xmi:idref="_18_4_1_2b2015d_1539785479538_933883_39319"/>
      <waypoint x="805" y="305"/>
      <waypoint x="743" y="305"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785644674_912933_39436" xmi:uuid="4693dcf0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785644667_731613_39434"/>
      <ownedElement xmi:id="9b6a60a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b6a6120-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785644667_731613_39434"/>
        <text>sameAsAsgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="9b6b7b80-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b6b7bc0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785644667_731613_39434"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ff564740-6c45-013d-d602-0800270c66d6" xmi:uuid="ff5647e0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ff690fe0-6c45-013d-d602-0800270c66d6" xmi:uuid="ff6910f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539785799034_199952_40003" xmi:uuid="9b9d5860-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="9b8c3db0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b8c3e20-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9b9cfd50-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b9cfdd0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="434" y="791" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="420" y="763" width="268" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785812648_263190_40049" xmi:uuid="4693e580-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785814316_940496_40052"/>
      <source xmi:idref="_18_4_1_2b2015d_1539785745416_449167_39908"/>
      <target xmi:idref="_18_4_1_2b2015d_1539785644674_912933_39436"/>
      <waypoint x="182" y="788"/>
      <waypoint x="420" y="788"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785842397_967619_40084" xmi:uuid="4693ed00-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785844598_31528_40087"/>
      <source xmi:idref="_18_4_1_2b2015d_1539785799034_199952_40003"/>
      <target xmi:idref="_18_4_1_2b2015d_1539773059427_303682_32774"/>
      <waypoint x="657" y="802"/>
      <waypoint x="910" y="802"/>
      <waypoint x="910" y="455"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539785879967_814277_40115" xmi:uuid="4693f420-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539785881078_643086_40118"/>
      <source xmi:idref="_18_4_1_2b2015d_1539785316544_369492_39093"/>
      <target xmi:idref="_18_4_1_2b2015d_1539785346494_320676_39213"/>
      <waypoint x="347" y="312"/>
      <waypoint x="347" y="336"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539786036669_800849_40225" xmi:uuid="4693fbe0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539786037856_939279_40228"/>
      <source xmi:idref="_18_4_1_2b2015d_1539786017189_70942_40196"/>
      <target xmi:idref="_18_4_1_2b2015d_1539773059427_303682_32774"/>
      <waypoint x="1182" y="120"/>
      <waypoint x="1146" y="120"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948301504_736801_35280" xmi:uuid="469402f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948302236_518998_35281"/>
      <source xmi:idref="_18_4_1_2b2015d_1539784750568_768511_38483"/>
      <target xmi:idref="_18_4_1_2b2015d_1539784791998_253507_38555"/>
      <waypoint x="560" y="648"/>
      <waypoint x="439" y="648"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539964800530_68466_36487" xmi:uuid="46940df0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539939533519_997165_31652"/>
      <ownedElement xmi:id="9b9f4450-7cb3-0138-410d-418b172fba9f" xmi:uuid="9b9f44a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539939533519_997165_31652"/>
        <text>ExchangeContext:ExchangeContext</text>
      </ownedElement>
      <ownedElement xmi:id="9ba05510-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ba05560-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539939533519_997165_31652"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="854" width="229" height="25"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1185" height="900"/>
    <name>Message</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446295089_711822_278699" xmi:uuid="40e3d630-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_ExchangeContext"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295138_674885_278732" xmi:uuid="415d53a0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552043211001_997565_35613"/>
      <ownedElement xmi:id="414e7ec0-6c46-013d-d602-0800270c66d6" xmi:uuid="414e7f70-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552043211001_997565_35613"/>
        <text>exchange_context:Product_definition_exchange_context</text>
      </ownedElement>
      <ownedElement xmi:id="415d4270-6c46-013d-d602-0800270c66d6" xmi:uuid="415d4320-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552043211001_997565_35613"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="339" height="130"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295153_805873_278766" xmi:uuid="415de110-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1573647641157_30773_55254"/>
      <bounds x="643" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295174_71176_278787" xmi:uuid="415e7ce0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="643" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295194_742340_278808" xmi:uuid="416b5450-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="643" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295213_273717_278829" xmi:uuid="416be460-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="643" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496408_609015_401135" xmi:uuid="416bf4e0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1580742709417_512956_75793"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295153_805873_278766"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295138_674885_278732"/>
      <waypoint x="643" y="62"/>
      <waypoint x="384" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496408_848440_401138" xmi:uuid="416bfbb0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736467175_933010_69279"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295174_71176_278787"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295138_674885_278732"/>
      <waypoint x="643" y="82"/>
      <waypoint x="384" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496408_894838_401141" xmi:uuid="416c0260-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736470893_298660_69299"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295194_742340_278808"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295138_674885_278732"/>
      <waypoint x="643" y="102"/>
      <waypoint x="384" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496408_273036_401144" xmi:uuid="416c08d0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601385479_584926_251569"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295213_273717_278829"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295138_674885_278732"/>
      <waypoint x="643" y="122"/>
      <waypoint x="384" y="122"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="646" height="200"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446295433_115362_279099" xmi:uuid="472d7d70-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_18_4_1_2b2015d_1583496521130_514720_53768"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295459_786117_279131" xmi:uuid="479a9760-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607333989989_794307_74385"/>
      <ownedElement xmi:id="478cf720-6c46-013d-d602-0800270c66d6" xmi:uuid="478cf7c0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_271a0567_1607333989989_794307_74385"/>
        <text>acknowledgement_:Acknowledgement</text>
      </ownedElement>
      <ownedElement xmi:id="479a7c50-6c46-013d-d602-0800270c66d6" xmi:uuid="479a7d30-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_271a0567_1607333989989_794307_74385"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="242" height="90"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295476_599362_279165" xmi:uuid="479b2b40-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="559" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295494_211432_279186" xmi:uuid="479bc970-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="559" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496446_968123_401252" xmi:uuid="479bdb40-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736140397_899712_68544"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295476_599362_279165"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295459_786117_279131"/>
      <waypoint x="559" y="62"/>
      <waypoint x="287" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496446_226241_401255" xmi:uuid="479be3b0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736143289_521077_68564"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295494_211432_279186"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295459_786117_279131"/>
      <waypoint x="559" y="82"/>
      <waypoint x="287" y="82"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="562" height="160"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1539789584907_213547_42499" xmi:uuid="743f64f4-4a94-4915-855e-2bd1bcd71b13" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767899339_172189_31799"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552058933783_538235_39695" xmi:uuid="46961a70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058933773_277384_39691"/>
      <bounds x="1007" y="696" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539789667619_162951_42902" xmi:uuid="46962c70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789667612_326294_42900"/>
      <ownedElement xmi:id="9bb2fd00-7cb3-0138-410d-418b172fba9f" xmi:uuid="9bb2fe10-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789667612_326294_42900"/>
        <text>relation:Message_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="9bb419f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9bb41a40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789667612_326294_42900"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="025de5e0-6c46-013d-d602-0800270c66d6" xmi:uuid="025de690-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="025e6c00-6c46-013d-d602-0800270c66d6" xmi:uuid="025e6d40-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539789736530_864399_42933" xmi:uuid="9be594d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message_relationship-related"/>
          <ownedElement xmi:id="9bd45f20-7cb3-0138-410d-418b172fba9f" xmi:uuid="9bd45fb0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message_relationship-related"/>
            <text>related:Message</text>
          </ownedElement>
          <ownedElement xmi:id="9be535c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9be53640-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message_relationship-related"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="714" y="714" width="129" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539789736539_312272_42964" xmi:uuid="9c15e6c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message_relationship-relating"/>
          <ownedElement xmi:id="9c051860-7cb3-0138-410d-418b172fba9f" xmi:uuid="9c0518d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message_relationship-relating"/>
            <text>relating:Message</text>
          </ownedElement>
          <ownedElement xmi:id="9c158c10-7cb3-0138-410d-418b172fba9f" xmi:uuid="9c158c90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message_relationship-relating"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="714" y="749" width="132" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539789736547_156685_42995" xmi:uuid="9c37ba80-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message_relationship-relation_type"/>
          <ownedElement xmi:id="9c2695b0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9c269630-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="9c375e70-7cb3-0138-410d-418b172fba9f" xmi:uuid="9c375ee0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Message_relationship-relation_type"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="714" y="784" width="144" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="700" y="686" width="195" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790247012_463903_44292" xmi:uuid="46963800-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="9c55d5a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9c55d610-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9c648c60-7cb3-0138-410d-418b172fba9f" xmi:uuid="9c648ce0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="06911cc0-6c46-013d-d602-0800270c66d6" xmi:uuid="06911d60-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="069fb8a0-6c46-013d-d602-0800270c66d6" xmi:uuid="069fb9c0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539790502009_833146_44703" xmi:uuid="9c9672d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="9c857240-7cb3-0138-410d-418b172fba9f" xmi:uuid="9c8572d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9c9615f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9c961670-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="259" y="336" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="308" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790247020_468329_44323" xmi:uuid="469643d0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="9cb4c7e0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9cb4c870-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9cc37440-7cb3-0138-410d-418b172fba9f" xmi:uuid="9cc374c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="08f069a0-6c46-013d-d602-0800270c66d6" xmi:uuid="08f06a50-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="08f11cd0-6c46-013d-d602-0800270c66d6" xmi:uuid="08f11e00-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539790433937_350202_44652" xmi:uuid="9cf57830-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="9ce41360-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ce41470-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="9cf51cd0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9cf51d60-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="259" y="637" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="609" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790247026_964701_44354" xmi:uuid="46964f40-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="9d138fc0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9d1390c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9d224160-7cb3-0138-410d-418b172fba9f" xmi:uuid="9d2241e0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="0b23abd0-6c46-013d-d602-0800270c66d6" xmi:uuid="0b23ac70-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0b243bd0-6c46-013d-d602-0800270c66d6" xmi:uuid="0b243c90-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539790294490_66752_44525" xmi:uuid="9d53c380-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="9d42e090-7cb3-0138-410d-418b172fba9f" xmi:uuid="9d42e110-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9d536850-7cb3-0138-410d-418b172fba9f" xmi:uuid="9d5368c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="259" y="259" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="231" width="259" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790247032_180624_44385" xmi:uuid="46965ac0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="9d71a830-7cb3-0138-410d-418b172fba9f" xmi:uuid="9d71a8b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="9d80cfc0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9d80d040-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="0d6ed280-6c46-013d-d602-0800270c66d6" xmi:uuid="0d6ed320-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="0d7d1220-6c46-013d-d602-0800270c66d6" xmi:uuid="0d7d1300-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539790389599_785858_44611" xmi:uuid="9db29dc0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="9da16520-7cb3-0138-410d-418b172fba9f" xmi:uuid="9da165a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="9db24160-7cb3-0138-410d-418b172fba9f" xmi:uuid="9db241e0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="119" y="413" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="105" y="385" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790247045_859330_44416" xmi:uuid="4696bbc0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="9dcfa550-7cb3-0138-410d-418b172fba9f" xmi:uuid="9dcfa620-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539790867474_808695_45133" xmi:uuid="4696a2e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="100cf950-6c46-013d-d602-0800270c66d6" xmi:uuid="100cfa10-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="178" y="514" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="168" y="496" width="15" height="15"/>
      </ownedElement>
      <bounds x="105" y="462" width="238" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790247055_355836_44436" xmi:uuid="46973740-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="9dfb3320-7cb3-0138-410d-418b172fba9f" xmi:uuid="9dfb33a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539792786830_861053_46500" xmi:uuid="469709b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="1175a2f0-6c46-013d-d602-0800270c66d6" xmi:uuid="1175a390-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="391" y="123" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="373" y="132" width="15" height="15"/>
      </ownedElement>
      <bounds x="217" y="119" width="171" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790247061_743142_44456" xmi:uuid="46974830-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="9e27e5b0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9e27e620-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9e367910-7cb3-0138-410d-418b172fba9f" xmi:uuid="9e367980-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="12b5a3c0-6c46-013d-d602-0800270c66d6" xmi:uuid="12b5a460-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="12cbae60-6c46-013d-d602-0800270c66d6" xmi:uuid="12cbaf30-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539790338392_943265_44568" xmi:uuid="9e6e81a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="9e5b2f10-7cb3-0138-410d-418b172fba9f" xmi:uuid="9e5b2fa0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9e6e0080-7cb3-0138-410d-418b172fba9f" xmi:uuid="9e6e0320-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="259" y="868" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="840" width="256" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790247070_614364_44487" xmi:uuid="4697f750-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="9e8b5fc0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9e8b6030-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539790634154_714767_44906" xmi:uuid="4697db40-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="157b3700-6c46-013d-d602-0800270c66d6" xmi:uuid="157b37f0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="389" y="781" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <bounds x="371" y="790" width="15" height="15"/>
      </ownedElement>
      <bounds x="189" y="777" width="197" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790568731_659926_44750" xmi:uuid="46989020-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768163699_454892_32027"/>
      <ownedElement xmi:id="9e9bceb0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9e9bcf20-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768163699_454892_32027"/>
        <text>Related:Message</text>
      </ownedElement>
      <ownedElement xmi:id="9e9cea80-7cb3-0138-410d-418b172fba9f" xmi:uuid="9e9cead0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768163699_454892_32027"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539790580366_574897_44816" xmi:uuid="46984e30-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539786017179_4107_40192"/>
        <ownedElement xmi:id="15c84e80-6c46-013d-d602-0800270c66d6" xmi:uuid="15c84f60-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539786017179_4107_40192"/>
          <bounds x="199" y="710" width="91" height="13"/>
          <text>msg : Message [1]</text>
        </ownedElement>
        <bounds x="181" y="719" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="714" width="154" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790568739_830551_44781" xmi:uuid="46992580-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768128341_706152_32020"/>
      <ownedElement xmi:id="9e9f1100-7cb3-0138-410d-418b172fba9f" xmi:uuid="9e9f1270-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768128341_706152_32020"/>
        <text>Relating:Message</text>
      </ownedElement>
      <ownedElement xmi:id="9ea01f20-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ea01f70-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768128341_706152_32020"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539790591074_570368_44834" xmi:uuid="4698ea50-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539786017179_4107_40192"/>
        <ownedElement xmi:id="15f19f80-6c46-013d-d602-0800270c66d6" xmi:uuid="15f1a070-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539786017179_4107_40192"/>
          <bounds x="199" y="743" width="91" height="13"/>
          <text>msg : Message [1]</text>
        </ownedElement>
        <bounds x="181" y="752" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="749" width="154" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790611041_892734_44865" xmi:uuid="46993140-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539790612461_217555_44866"/>
      <source xmi:idref="_18_4_1_2b2015d_1539789736539_312272_42964"/>
      <target xmi:idref="_18_4_1_2b2015d_1539790591074_570368_44834"/>
      <waypoint x="714" y="759"/>
      <waypoint x="196" y="759"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790616946_96695_44887" xmi:uuid="46993890-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539790618565_797002_44888"/>
      <source xmi:idref="_18_4_1_2b2015d_1539789736530_864399_42933"/>
      <target xmi:idref="_18_4_1_2b2015d_1539790580366_574897_44816"/>
      <waypoint x="714" y="726"/>
      <waypoint x="196" y="726"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790691874_204407_44967" xmi:uuid="469a1920-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539790691868_239973_44965"/>
      <ownedElement xmi:id="9eaffb80-7cb3-0138-410d-418b172fba9f" xmi:uuid="9eaffbf0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539790691868_239973_44965"/>
        <text>defaultType:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539790723376_830870_44991" xmi:uuid="469984a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="16d71e20-6c46-013d-d602-0800270c66d6" xmi:uuid="16d71f20-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="399" y="804" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="455" y="789" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539790723381_487062_45001" xmi:uuid="4699fbb0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="17638f70-6c46-013d-d602-0800270c66d6" xmi:uuid="17639050-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="654" y="779" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="636" y="788" width="15" height="15"/>
      </ownedElement>
      <bounds x="455" y="777" width="196" height="42"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790788749_947961_45070" xmi:uuid="469a2540-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539790791212_457059_45073"/>
      <source xmi:idref="_18_4_1_2b2015d_1539789736547_156685_42995"/>
      <target xmi:idref="_18_4_1_2b2015d_1539790723381_487062_45001"/>
      <waypoint x="714" y="795"/>
      <waypoint x="651" y="795"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790812796_500890_45096" xmi:uuid="469a2e50-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539790814596_499027_45099"/>
      <source xmi:idref="_18_4_1_2b2015d_1539790338392_943265_44568"/>
      <target xmi:idref="_18_4_1_2b2015d_1539789667619_162951_42902"/>
      <waypoint x="443" y="879"/>
      <waypoint x="770" y="879"/>
      <waypoint x="770" y="819"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539790839610_682071_45119" xmi:uuid="469a35d0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539790841199_679666_45122"/>
      <source xmi:idref="_18_4_1_2b2015d_1539790433937_350202_44652"/>
      <target xmi:idref="_18_4_1_2b2015d_1539789667619_162951_42902"/>
      <waypoint x="434" y="648"/>
      <waypoint x="805" y="648"/>
      <waypoint x="805" y="686"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539792020667_354167_45170" xmi:uuid="469a42a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792020660_139233_45168"/>
      <ownedElement xmi:id="9ec26f10-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ec26f80-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792020660_139233_45168"/>
        <text>smplDescAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9ec386c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ec386f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792020660_139233_45168"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="17cdb3d0-6c46-013d-d602-0800270c66d6" xmi:uuid="17cdb4b0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="17cea090-6c46-013d-d602-0800270c66d6" xmi:uuid="17cea1c0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539792088266_34201_45203" xmi:uuid="9ef53d30-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="9ee421a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ee42220-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="9ef4d9d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ef4dae0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="490" y="553" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539792088278_816998_45234" xmi:uuid="9f25edb0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="9f14e620-7cb3-0138-410d-418b172fba9f" xmi:uuid="9f14e720-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="9f258d80-7cb3-0138-410d-418b172fba9f" xmi:uuid="9f258ec0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="490" y="518" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="476" y="490" width="287" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539792376451_414465_45332" xmi:uuid="469a5470-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792376444_119872_45330"/>
      <ownedElement xmi:id="9f365320-7cb3-0138-410d-418b172fba9f" xmi:uuid="9f3655d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792376444_119872_45330"/>
        <text>descText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="9f377830-7cb3-0138-410d-418b172fba9f" xmi:uuid="9f377880-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792376444_119872_45330"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="1ab6eb20-6c46-013d-d602-0800270c66d6" xmi:uuid="1ab6eb90-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="1ab7a820-6c46-013d-d602-0800270c66d6" xmi:uuid="1ab7a910-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539792444020_661761_45365" xmi:uuid="9f596b40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="9f488840-7cb3-0138-410d-418b172fba9f" xmi:uuid="9f4888c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="9f590d10-7cb3-0138-410d-418b172fba9f" xmi:uuid="9f590d90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="259" y="553" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="525" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539792500303_301043_45423" xmi:uuid="469a5c50-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792503335_168148_45426"/>
      <source xmi:idref="_18_4_1_2b2015d_1539790389599_785858_44611"/>
      <target xmi:idref="_18_4_1_2b2015d_1539792376451_414465_45332"/>
      <waypoint x="347" y="424"/>
      <waypoint x="399" y="424"/>
      <waypoint x="399" y="525"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539792516912_233065_45468" xmi:uuid="469a7580-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792518140_85514_45471"/>
      <source xmi:idref="_18_4_1_2b2015d_1539792088266_34201_45203"/>
      <target xmi:idref="_18_4_1_2b2015d_1539792376451_414465_45332"/>
      <waypoint x="490" y="564"/>
      <waypoint x="432" y="564"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539792522135_649976_45489" xmi:uuid="469a7d60-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792524315_641490_45492"/>
      <source xmi:idref="_18_4_1_2b2015d_1539792088278_816998_45234"/>
      <target xmi:idref="_18_4_1_2b2015d_1539789667619_162951_42902"/>
      <waypoint x="665" y="529"/>
      <waypoint x="805" y="529"/>
      <waypoint x="805" y="686"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539792626021_170078_45526" xmi:uuid="469a8610-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792630010_641128_45529"/>
      <source xmi:idref="_18_4_1_2b2015d_1539790502009_833146_44703"/>
      <target xmi:idref="_18_4_1_2b2015d_1539789667619_162951_42902"/>
      <waypoint x="443" y="347"/>
      <waypoint x="805" y="347"/>
      <waypoint x="805" y="686"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539792651764_737504_45553" xmi:uuid="469a8d90-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792654216_230290_45556"/>
      <source xmi:idref="_18_4_1_2b2015d_1539790294490_66752_44525"/>
      <target xmi:idref="_18_4_1_2b2015d_1539789667619_162951_42902"/>
      <waypoint x="442" y="270"/>
      <waypoint x="805" y="270"/>
      <waypoint x="805" y="686"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539792824954_931884_46549" xmi:uuid="469a9c00-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792824946_79114_46547"/>
      <ownedElement xmi:id="9f6a3710-7cb3-0138-410d-418b172fba9f" xmi:uuid="9f6a3780-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792824946_79114_46547"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9f6b5b00-7cb3-0138-410d-418b172fba9f" xmi:uuid="9f6b5b40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792824946_79114_46547"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="1c0272e0-6c46-013d-d602-0800270c66d6" xmi:uuid="1c0275e0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="1c030880-6c46-013d-d602-0800270c66d6" xmi:uuid="1c030950-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539792876298_647839_46584" xmi:uuid="9f8dc1d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="9f7cb3e0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9f7cb5d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="9f8d5de0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9f8d5e50-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="539" y="126" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539792876311_228564_46615" xmi:uuid="9fbebb10-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="9fada840-7cb3-0138-410d-418b172fba9f" xmi:uuid="9fada8c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="9fbe5a80-7cb3-0138-410d-418b172fba9f" xmi:uuid="9fbe5b00-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="161" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539792876320_802737_46646" xmi:uuid="9fdfea10-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="9fcf27b0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9fcf2820-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="9fdf8fc0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9fdf9030-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="539" y="196" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="98" width="254" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539792919035_951531_46700" xmi:uuid="469aa4d0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792921469_821574_46703"/>
      <source xmi:idref="_18_4_1_2b2015d_1539792876311_228564_46615"/>
      <target xmi:idref="_18_4_1_2b2015d_1539789667619_162951_42902"/>
      <waypoint x="722" y="172"/>
      <waypoint x="805" y="172"/>
      <waypoint x="805" y="686"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539792946122_120807_46747" xmi:uuid="469ab2e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792946115_911133_46745"/>
      <ownedElement xmi:id="9fe14250-7cb3-0138-410d-418b172fba9f" xmi:uuid="9fe142c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792946115_911133_46745"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="9fe2a7e0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9fe2a840-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539792946115_911133_46745"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="350" y="196" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793006676_908459_46789" xmi:uuid="469abdc0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793007553_330341_46792"/>
      <source xmi:idref="_18_4_1_2b2015d_1539792876320_802737_46646"/>
      <target xmi:idref="_18_4_1_2b2015d_1539792946122_120807_46747"/>
      <waypoint x="539" y="207"/>
      <waypoint x="484" y="207"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793358670_349823_46859" xmi:uuid="469ac300-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="385" y="35" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793657187_526109_47872" xmi:uuid="469acaf0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793658118_469780_47875"/>
      <source xmi:idref="_18_4_1_2b2015d_1539792876298_647839_46584"/>
      <target xmi:idref="_18_4_1_2b2015d_1539792786830_861053_46500"/>
      <waypoint x="539" y="140"/>
      <waypoint x="388" y="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793661501_928154_47894" xmi:uuid="469ad360-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793663991_277706_47897"/>
      <source xmi:idref="_18_4_1_2b2015d_1539792444020_661761_45365"/>
      <target xmi:idref="_18_4_1_2b2015d_1539790867474_808695_45133"/>
      <waypoint x="259" y="564"/>
      <waypoint x="175" y="564"/>
      <waypoint x="175" y="511"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793675535_906191_47922" xmi:uuid="469adc20-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793677116_446529_47925"/>
      <source xmi:idref="_18_4_1_2b2015d_1539790723376_830870_44991"/>
      <target xmi:idref="_18_4_1_2b2015d_1539790634154_714767_44906"/>
      <waypoint x="455" y="798"/>
      <waypoint x="386" y="798"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552058995351_401326_39734" xmi:uuid="469af7b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058996473_647287_39737"/>
      <source xmi:idref="_18_4_1_2b2015d_1552058933783_538235_39695"/>
      <target xmi:idref="_18_4_1_2b2015d_1539789667619_162951_42902"/>
      <waypoint x="1007" y="703"/>
      <waypoint x="895" y="703"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1010" height="918"/>
    <name>MessageRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_271a0567_1607333943724_332533_74303" xmi:uuid="762b38d0-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_18_4_1_2b2015d_1583496521130_514720_53768"/>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334063379_100665_74482" xmi:uuid="762da1a0-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334063349_656101_74478"/>
      <bounds x="1070" y="34" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607333949229_910618_74340" xmi:uuid="661eed20-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1583496571355_837641_53770"/>
      <ownedElement xmi:id="763cd560-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="763cd6b0-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1583496571355_837641_53770"/>
        <text>Definition:ProxyItemSelect</text>
      </ownedElement>
      <ownedElement xmi:id="763f2300-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="763f2370-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1583496571355_837641_53770"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="84" width="181" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607333990029_540256_74386" xmi:uuid="664760c0-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607333989989_794307_74385"/>
      <ownedElement xmi:id="764f1d80-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="764f1e00-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_271a0567_1607333989989_794307_74385"/>
        <text>acknowledgement_:Acknowledgement</text>
      </ownedElement>
      <ownedElement xmi:id="76506330-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="765063a0-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_271a0567_1607333989989_794307_74385"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="425fb220-6c46-013d-d602-0800270c66d6" xmi:uuid="425fb520-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="42604c20-6c46-013d-d602-0800270c66d6" xmi:uuid="42604d00-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1607333995619_221351_74420" xmi:uuid="76723070-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Acknowledgement-name"/>
          <ownedElement xmi:id="7661b000-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="7661b090-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Acknowledgement-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="7671a6b0-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="7671a730-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Acknowledgement-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="819" y="91" width="103" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="798" y="63" width="253" height="69"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334113899_876737_74511" xmi:uuid="66476970-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334115959_929948_74512"/>
      <source xmi:idref="_18_4_1_271a0567_1607334063379_100665_74482"/>
      <target xmi:idref="_18_4_1_271a0567_1607333990029_540256_74386"/>
      <waypoint x="1070" y="42"/>
      <waypoint x="917" y="42"/>
      <waypoint x="917" y="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_644600_75519" xmi:uuid="66572500-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334205799_345113_75487"/>
      <ownedElement xmi:id="7680e8d0-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="7680e980-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_271a0567_1607334205799_345113_75487"/>
        <text>levelSelect:ProxySelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_274452_75522" xmi:uuid="76823540-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502709744187_225576_26301"/>
        <ownedElement xmi:id="43c78dc0-6c46-013d-d602-0800270c66d6" xmi:uuid="43c78e60-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502709744187_225576_26301"/>
          <bounds x="493" y="77" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <bounds x="475" y="86" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_243700_75524" xmi:uuid="7682b840-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502709744187_538361_26302"/>
        <ownedElement xmi:id="441dd6e0-6c46-013d-d602-0800270c66d6" xmi:uuid="441ddac0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502709744187_538361_26302"/>
          <bounds x="247" y="81" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="301" y="90" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_360502_75526" xmi:uuid="76833c20-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502709744187_323034_26303"/>
        <ownedElement xmi:id="447c1f10-6c46-013d-d602-0800270c66d6" xmi:uuid="447c2020-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502709744187_323034_26303"/>
          <bounds x="458" y="134" width="56" height="13"/>
          <text>proxy [0..1]</text>
        </ownedElement>
        <bounds x="448" y="116" width="15" height="15"/>
      </ownedElement>
      <bounds x="301" y="77" width="189" height="54"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334261899_338247_75754" xmi:uuid="76c80b40-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334264269_788138_75755"/>
      <source xmi:idref="_18_4_1_271a0567_1607333990029_540256_74386"/>
      <target xmi:idref="_18_4_1_271a0567_1607334209489_714820_75528"/>
      <waypoint x="851" y="132"/>
      <waypoint x="851" y="193"/>
      <waypoint x="797" y="193"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_360524_75520" xmi:uuid="668c4380-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334205809_533061_75488"/>
      <ownedElement xmi:id="7693d8b0-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="7693d940-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_271a0567_1607334205809_533061_75488"/>
        <text>eii:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="76952050-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="769520c0-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_271a0567_1607334205809_533061_75488"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="4505d030-6c46-013d-d602-0800270c66d6" xmi:uuid="4505d0d0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="45065380-6c46-013d-d602-0800270c66d6" xmi:uuid="45065670-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_714820_75528" xmi:uuid="76c786a0-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="76b82800-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="76b82900-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="76c6fec0-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="76c6ff40-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="182" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="560" y="154" width="241" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_587686_75521" xmi:uuid="66999e30-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334205814_442857_75489"/>
      <ownedElement xmi:id="76d59020-327f-0139-a8c9-34a9fcdfa563" xmi:uuid="76d590b0-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_271a0567_1607334205814_442857_75489"/>
        <text>default:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_608215_75529" xmi:uuid="76d6da90-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="46bb5c90-6c46-013d-d602-0800270c66d6" xmi:uuid="46bb5d40-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="518" y="104" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="574" y="89" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_258170_75531" xmi:uuid="76d75f40-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="47105890-6c46-013d-d602-0800270c66d6" xmi:uuid="47105940-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="745" y="85" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="727" y="94" width="15" height="15"/>
      </ownedElement>
      <bounds x="574" y="77" width="168" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_458780_75533" xmi:uuid="6699a870-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334205819_369495_75490"/>
      <source xmi:idref="_18_4_1_271a0567_1607334209489_360524_75520"/>
      <target xmi:idref="_18_4_1_271a0567_1607334209489_360502_75526"/>
      <waypoint x="560" y="182"/>
      <waypoint x="455" y="182"/>
      <waypoint x="455" y="131"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334209489_476700_75534" xmi:uuid="6699b0e0-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334205819_617766_75491"/>
      <source xmi:idref="_18_4_1_271a0567_1607334209489_608215_75529"/>
      <target xmi:idref="_18_4_1_271a0567_1607334209489_274452_75522"/>
      <waypoint x="574" y="95"/>
      <waypoint x="490" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334249964_799860_75709" xmi:uuid="6699b7c0-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334254979_644644_75710"/>
      <source xmi:idref="_18_4_1_271a0567_1607333995619_221351_74420"/>
      <target xmi:idref="_18_4_1_271a0567_1607334209489_258170_75531"/>
      <waypoint x="819" y="102"/>
      <waypoint x="742" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334257649_649583_75733" xmi:uuid="6699bf10-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334259449_235262_75734"/>
      <source xmi:idref="_18_4_1_271a0567_1607334209489_243700_75524"/>
      <target xmi:idref="_18_4_1_271a0567_1607333949229_910618_74340"/>
      <waypoint x="301" y="95"/>
      <waypoint x="216" y="95"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1073" height="232"/>
    <name>Acknowledgement</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1539793524204_169634_46887" xmi:uuid="974e9081-07c5-4a64-a0bf-b11127c90764" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768315078_454856_32209"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1551109321615_273091_36356" xmi:uuid="4677a390-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1551109321606_963551_36352"/>
      <bounds x="1000" y="632" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793534065_510625_46921" xmi:uuid="467841c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768583591_733343_32419"/>
      <ownedElement xmi:id="91c7e750-7cb3-0138-410d-418b172fba9f" xmi:uuid="91c7e860-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768583591_733343_32419"/>
        <text>Related:Envelope</text>
      </ownedElement>
      <ownedElement xmi:id="91c93530-7cb3-0138-410d-418b172fba9f" xmi:uuid="91c93660-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768583591_733343_32419"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539793877902_510417_48250" xmi:uuid="4677f5b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789259299_591770_42385"/>
        <ownedElement xmi:id="9b20edc0-6c45-013d-d602-0800270c66d6" xmi:uuid="9b20ee80-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789259299_591770_42385"/>
          <bounds x="199" y="682" width="88" height="13"/>
          <text>env : Envelope [1]</text>
        </ownedElement>
        <bounds x="181" y="691" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="686" width="154" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793534072_865134_46952" xmi:uuid="4678d1b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768552022_367749_32382"/>
      <ownedElement xmi:id="91cb6a50-7cb3-0138-410d-418b172fba9f" xmi:uuid="91cb6aa0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768552022_367749_32382"/>
        <text>Relating:Envelope</text>
      </ownedElement>
      <ownedElement xmi:id="91cc76d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="91cc7710-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768552022_367749_32382"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539793835521_241643_48168" xmi:uuid="46789520-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789259299_591770_42385"/>
        <ownedElement xmi:id="9b66e730-6c45-013d-d602-0800270c66d6" xmi:uuid="9b66e810-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789259299_591770_42385"/>
          <bounds x="199" y="716" width="88" height="13"/>
          <text>env : Envelope [1]</text>
        </ownedElement>
        <bounds x="181" y="725" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="721" width="154" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597555_285867_47029" xmi:uuid="4678e4e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="92222980-7cb3-0138-410d-418b172fba9f" xmi:uuid="922229f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9230eca0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9230ed10-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="9e959900-6c45-013d-d602-0800270c66d6" xmi:uuid="9e9599b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="9e962050-6c45-013d-d602-0800270c66d6" xmi:uuid="9e9620e0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_228671_47043" xmi:uuid="92626ad0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="92518310-7cb3-0138-410d-418b172fba9f" xmi:uuid="92518390-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="92621270-7cb3-0138-410d-418b172fba9f" xmi:uuid="926212e0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="259" y="308" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="280" width="298" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597555_89664_47030" xmi:uuid="4678f670-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="92809900-7cb3-0138-410d-418b172fba9f" xmi:uuid="92809970-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="928f6390-7cb3-0138-410d-418b172fba9f" xmi:uuid="928f6410-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a132d440-6c45-013d-d602-0800270c66d6" xmi:uuid="a132d4f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a1443be0-6c45-013d-d602-0800270c66d6" xmi:uuid="a1443ca0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_63605_47044" xmi:uuid="92c168a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="92b030b0-7cb3-0138-410d-418b172fba9f" xmi:uuid="92b03130-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="92c10500-7cb3-0138-410d-418b172fba9f" xmi:uuid="92c10570-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="245" y="609" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="231" y="581" width="309" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597555_718826_47031" xmi:uuid="46790680-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="92df78d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="92df7950-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="92ee5eb0-7cb3-0138-410d-418b172fba9f" xmi:uuid="92ee5f30-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="a3db8670-6c45-013d-d602-0800270c66d6" xmi:uuid="a3db8710-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a3ee8510-6c45-013d-d602-0800270c66d6" xmi:uuid="a3ee8620-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_517689_47045" xmi:uuid="93202e70-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="930f4130-7cb3-0138-410d-418b172fba9f" xmi:uuid="930f41a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="931fc500-7cb3-0138-410d-418b172fba9f" xmi:uuid="931fc580-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="259" y="231" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="203" width="237" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597555_96733_47032" xmi:uuid="46791400-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="933e6720-7cb3-0138-410d-418b172fba9f" xmi:uuid="933e6790-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="934d2030-7cb3-0138-410d-418b172fba9f" xmi:uuid="934d20a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="a67ab130-6c45-013d-d602-0800270c66d6" xmi:uuid="a67ab1e0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="a67b5550-6c45-013d-d602-0800270c66d6" xmi:uuid="a67b5640-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_170817_47046" xmi:uuid="937f1ca0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="936de270-7cb3-0138-410d-418b172fba9f" xmi:uuid="936de2f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="937ec010-7cb3-0138-410d-418b172fba9f" xmi:uuid="937ec080-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="105" y="385" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="91" y="357" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597555_188092_47033" xmi:uuid="46799570-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="939c21d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="939c2260-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_111290_47047" xmi:uuid="46797ef0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="a9684080-6c45-013d-d602-0800270c66d6" xmi:uuid="a9684130-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="164" y="486" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="154" y="468" width="15" height="15"/>
      </ownedElement>
      <bounds x="91" y="434" width="238" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597555_687854_47034" xmi:uuid="4679f700-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="93c7f900-7cb3-0138-410d-418b172fba9f" xmi:uuid="93c7f970-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_689426_47049" xmi:uuid="4679e180-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="ab093100-6c45-013d-d602-0800270c66d6" xmi:uuid="ab0931a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="370" y="95" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="352" y="104" width="15" height="15"/>
      </ownedElement>
      <bounds x="203" y="91" width="164" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597555_902504_47035" xmi:uuid="467a06d0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="93f52120-7cb3-0138-410d-418b172fba9f" xmi:uuid="93f52280-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="940403e0-7cb3-0138-410d-418b172fba9f" xmi:uuid="94040520-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ac8b37e0-6c45-013d-d602-0800270c66d6" xmi:uuid="ac8b3890-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ac8bf100-6c45-013d-d602-0800270c66d6" xmi:uuid="ac8bf210-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_571856_47051" xmi:uuid="94359650-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="9424a2f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9424a370-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="94353560-7cb3-0138-410d-418b172fba9f" xmi:uuid="94353660-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="259" y="840" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="812" width="256" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597555_717180_47036" xmi:uuid="467a6a50-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="9452c400-7cb3-0138-410d-418b172fba9f" xmi:uuid="9452c480-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_774494_47052" xmi:uuid="467a5330-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="afc04860-6c45-013d-d602-0800270c66d6" xmi:uuid="afc04a50-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="389" y="753" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <bounds x="371" y="762" width="15" height="15"/>
      </ownedElement>
      <bounds x="196" y="749" width="190" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_427202_47037" xmi:uuid="467b98d0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597492_481817_46989"/>
      <ownedElement xmi:id="9470ce60-7cb3-0138-410d-418b172fba9f" xmi:uuid="9470cef0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597492_481817_46989"/>
        <text>defaultType:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_823329_47054" xmi:uuid="467abad0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="b0e2d4b0-6c45-013d-d602-0800270c66d6" xmi:uuid="b0e2de50-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="399" y="776" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="455" y="761" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_44444_47056" xmi:uuid="467b7960-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="b167a0b0-6c45-013d-d602-0800270c66d6" xmi:uuid="b167a150-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="646" y="751" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="628" y="760" width="15" height="15"/>
      </ownedElement>
      <bounds x="455" y="749" width="188" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_722764_47038" xmi:uuid="467babc0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597496_475935_46990"/>
      <ownedElement xmi:id="9482f800-7cb3-0138-410d-418b172fba9f" xmi:uuid="9482f880-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597496_475935_46990"/>
        <text>smplDescAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="94841da0-7cb3-0138-410d-418b172fba9f" xmi:uuid="94841df0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597496_475935_46990"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b209a7e0-6c45-013d-d602-0800270c66d6" xmi:uuid="b209a8c0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b2171e30-6c45-013d-d602-0800270c66d6" xmi:uuid="b2172300-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597557_363349_47058" xmi:uuid="94b63000-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="94a51c50-7cb3-0138-410d-418b172fba9f" xmi:uuid="94a51cf0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="94b5d370-7cb3-0138-410d-418b172fba9f" xmi:uuid="94b5d3f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="476" y="525" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597557_805890_47059" xmi:uuid="94ea1ac0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="94d64b60-7cb3-0138-410d-418b172fba9f" xmi:uuid="94d64be0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="94e9a4c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="94e9a540-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="476" y="490" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="462" y="462" width="287" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_40434_47039" xmi:uuid="467bb920-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597497_545164_46991"/>
      <ownedElement xmi:id="94fe9660-7cb3-0138-410d-418b172fba9f" xmi:uuid="94fe96e0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597497_545164_46991"/>
        <text>descText:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="95000de0-7cb3-0138-410d-418b172fba9f" xmi:uuid="95000e30-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597497_545164_46991"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b585f2d0-6c45-013d-d602-0800270c66d6" xmi:uuid="b585f380-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b59d8fc0-6c45-013d-d602-0800270c66d6" xmi:uuid="b59d90b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597557_881479_47060" xmi:uuid="952b0110-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="95162d80-7cb3-0138-410d-418b172fba9f" xmi:uuid="95162df0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="952a8d20-7cb3-0138-410d-418b172fba9f" xmi:uuid="952a8db0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="245" y="525" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="231" y="497" width="187" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_376339_47040" xmi:uuid="467bc750-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597499_316333_46992"/>
      <ownedElement xmi:id="953f5620-7cb3-0138-410d-418b172fba9f" xmi:uuid="953f5690-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597499_316333_46992"/>
        <text>smplIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9540ed50-7cb3-0138-410d-418b172fba9f" xmi:uuid="9540edc0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597499_316333_46992"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b753f860-6c45-013d-d602-0800270c66d6" xmi:uuid="b753f920-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b754a720-6c45-013d-d602-0800270c66d6" xmi:uuid="b754a7e0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597557_138037_47061" xmi:uuid="956c0ca0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="9556bd30-7cb3-0138-410d-418b172fba9f" xmi:uuid="9556bdb0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="956b9360-7cb3-0138-410d-418b172fba9f" xmi:uuid="956b93e0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="518" y="98" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597557_107783_47062" xmi:uuid="95a84ec0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="95936130-7cb3-0138-410d-418b172fba9f" xmi:uuid="959361b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="95a7d480-7cb3-0138-410d-418b172fba9f" xmi:uuid="95a7d4f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="518" y="133" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793597557_224904_47063" xmi:uuid="95d1bf10-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="95bcb040-7cb3-0138-410d-418b172fba9f" xmi:uuid="95bcb0c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="95d149f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="95d14a60-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="518" y="168" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="504" y="70" width="254" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_92055_47041" xmi:uuid="467bd2b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597501_497103_46993"/>
      <ownedElement xmi:id="95d33350-7cb3-0138-410d-418b172fba9f" xmi:uuid="95d33390-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597501_497103_46993"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="95d48580-7cb3-0138-410d-418b172fba9f" xmi:uuid="95d485c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597501_497103_46993"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="329" y="168" width="134" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597556_45128_47042" xmi:uuid="467bd760-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="336" y="21" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597557_186469_47065" xmi:uuid="467bdea0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597503_803703_46994"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597556_170817_47046"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793597556_40434_47039"/>
      <waypoint x="333" y="396"/>
      <waypoint x="385" y="396"/>
      <waypoint x="385" y="497"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597557_468701_47067" xmi:uuid="467be5e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597503_192054_46995"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597557_363349_47058"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793597556_40434_47039"/>
      <waypoint x="476" y="536"/>
      <waypoint x="418" y="536"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793597557_422040_47069" xmi:uuid="467bed20-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793597503_48251_46996"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597557_224904_47063"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793597556_92055_47041"/>
      <waypoint x="518" y="179"/>
      <waypoint x="463" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793709932_252252_47954" xmi:uuid="467bf510-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793711164_428935_47957"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597557_138037_47061"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793597556_689426_47049"/>
      <waypoint x="518" y="112"/>
      <waypoint x="367" y="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793736226_774452_47982" xmi:uuid="467c0360-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793736219_497486_47980"/>
      <ownedElement xmi:id="95e924f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="95e92570-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793736219_497486_47980"/>
        <text>relation:Envelope_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="95eabd30-7cb3-0138-410d-418b172fba9f" xmi:uuid="95eabd90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793736219_497486_47980"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="bb4bcc20-6c45-013d-d602-0800270c66d6" xmi:uuid="bb4bcd40-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bb544180-6c45-013d-d602-0800270c66d6" xmi:uuid="bb5442a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793791166_225354_48017" xmi:uuid="96219090-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope_relationship-related"/>
          <ownedElement xmi:id="9610a910-7cb3-0138-410d-418b172fba9f" xmi:uuid="9610a980-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope_relationship-related"/>
            <text>related:Envelope</text>
          </ownedElement>
          <ownedElement xmi:id="962135d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="96213650-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope_relationship-related"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="686" width="128" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793791173_428036_48048" xmi:uuid="9652dc50-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope_relationship-relating"/>
          <ownedElement xmi:id="9641a1b0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9641a230-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope_relationship-relating"/>
            <text>relating:Envelope</text>
          </ownedElement>
          <ownedElement xmi:id="96528020-7cb3-0138-410d-418b172fba9f" xmi:uuid="965280a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope_relationship-relating"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="721" y="721" width="131" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539793791181_778023_48079" xmi:uuid="9674b7a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope_relationship-relation_type"/>
          <ownedElement xmi:id="9663a7d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9663a850-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="96745e20-7cb3-0138-410d-418b172fba9f" xmi:uuid="96745e90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope_relationship-relation_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="721" y="756" width="156" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="707" y="658" width="198" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793818155_979233_48127" xmi:uuid="467c0ab0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793819498_311150_48130"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597556_823329_47054"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793597556_774494_47052"/>
      <waypoint x="455" y="770"/>
      <waypoint x="386" y="770"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793822663_391448_48149" xmi:uuid="467c11e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793824733_915577_48152"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793791181_778023_48079"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793597556_44444_47056"/>
      <waypoint x="721" y="767"/>
      <waypoint x="643" y="767"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793870847_532428_48235" xmi:uuid="467c1910-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793873570_243896_48236"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793791173_428036_48048"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793835521_241643_48168"/>
      <waypoint x="721" y="732"/>
      <waypoint x="196" y="732"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793889063_712529_48277" xmi:uuid="467c2000-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793890841_865317_48278"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793791166_225354_48017"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793877902_510417_48250"/>
      <waypoint x="721" y="698"/>
      <waypoint x="196" y="698"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793930859_689579_48341" xmi:uuid="467c3870-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793932255_530898_48344"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597557_881479_47060"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793597556_111290_47047"/>
      <waypoint x="245" y="536"/>
      <waypoint x="161" y="536"/>
      <waypoint x="161" y="483"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793941432_381889_48365" xmi:uuid="467c40f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793943926_859822_48368"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597556_571856_47051"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793736226_774452_47982"/>
      <waypoint x="443" y="851"/>
      <waypoint x="812" y="851"/>
      <waypoint x="812" y="791"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793964296_545428_48390" xmi:uuid="467c48e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793966598_404495_48393"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597556_63605_47044"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793736226_774452_47982"/>
      <waypoint x="420" y="620"/>
      <waypoint x="812" y="620"/>
      <waypoint x="812" y="658"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793975174_453764_48411" xmi:uuid="467c5310-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793977109_765305_48414"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597557_805890_47059"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793736226_774452_47982"/>
      <waypoint x="651" y="501"/>
      <waypoint x="812" y="501"/>
      <waypoint x="812" y="658"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793984575_672516_48430" xmi:uuid="467c5aa0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793987973_405931_48433"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597556_228671_47043"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793736226_774452_47982"/>
      <waypoint x="443" y="319"/>
      <waypoint x="812" y="319"/>
      <waypoint x="812" y="658"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539793998071_604873_48449" xmi:uuid="467c6340-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539794000219_433573_48452"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597556_517689_47045"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793736226_774452_47982"/>
      <waypoint x="442" y="242"/>
      <waypoint x="812" y="242"/>
      <waypoint x="812" y="658"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539794006354_320692_48470" xmi:uuid="467c6b60-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539794010876_48583_48473"/>
      <source xmi:idref="_18_4_1_2b2015d_1539793597557_107783_47062"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793736226_774452_47982"/>
      <waypoint x="701" y="144"/>
      <waypoint x="812" y="144"/>
      <waypoint x="812" y="658"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1551109379322_237157_36395" xmi:uuid="467c73a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1551109380765_285219_36398"/>
      <source xmi:idref="_18_4_1_2b2015d_1551109321615_273091_36356"/>
      <target xmi:idref="_18_4_1_2b2015d_1539793736226_774452_47982"/>
      <waypoint x="1000" y="639"/>
      <waypoint x="861" y="639"/>
      <waypoint x="861" y="658"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1003" height="890"/>
    <name>EnvelopeRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1539947610153_137013_32640" xmi:uuid="ae06ddad-5c95-46c5-b8cb-c9fc13b2028e" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_ExchangeContext"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552058233626_218709_37056" xmi:uuid="469d9170-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058233616_634642_37052"/>
      <bounds x="1294" y="445" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947616865_835469_32672" xmi:uuid="469da280-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539939429461_545710_31632"/>
      <ownedElement xmi:id="9ff42130-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ff421b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539939429461_545710_31632"/>
        <text>ClassLibrary:Uri</text>
      </ownedElement>
      <ownedElement xmi:id="9ff54340-7cb3-0138-410d-418b172fba9f" xmi:uuid="9ff54380-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539939429461_545710_31632"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="847" width="494" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947616879_391137_32703" xmi:uuid="469dae00-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_2_attr_ExchangeContext-IdentificationContext"/>
      <ownedElement xmi:id="a003d3e0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a003d460-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_2_attr_ExchangeContext-IdentificationContext"/>
        <text>DefaultIdentificationContext:IdentificationContextSelect</text>
      </ownedElement>
      <ownedElement xmi:id="a004ed20-7cb3-0138-410d-418b172fba9f" xmi:uuid="a004ed60-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_2_attr_ExchangeContext-IdentificationContext"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1583160806211_207970_56334" xmi:uuid="a00560d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1583160756833_35257_56291"/>
        <ownedElement xmi:id="2130aff0-6c46-013d-d602-0800270c66d6" xmi:uuid="2130b0b0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_271a0567_1583160756833_35257_56291"/>
          <bounds x="416" y="654" width="229" height="13"/>
          <text>ics : exchange_identification_context_select [1]</text>
        </ownedElement>
        <bounds x="398" y="663" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="658" width="371" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947616886_751281_32734" xmi:uuid="469e37b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_2_attr_ExchangeContext-DefaultLanguage"/>
      <ownedElement xmi:id="a013da90-7cb3-0138-410d-418b172fba9f" xmi:uuid="a013db10-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_2_attr_ExchangeContext-DefaultLanguage"/>
        <text>DefaultLanguage:Language</text>
      </ownedElement>
      <ownedElement xmi:id="a014fd60-7cb3-0138-410d-418b172fba9f" xmi:uuid="a014fdb0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_2_attr_ExchangeContext-DefaultLanguage"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539953335753_467057_35490" xmi:uuid="469dfac0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="21f47990-6c46-013d-d602-0800270c66d6" xmi:uuid="21f47a30-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="276" y="618" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="258" y="627" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="623" width="231" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947616905_697153_32796" xmi:uuid="469eebd0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_2_attr_ExchangeContext-Description"/>
      <ownedElement xmi:id="a02398a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0239910-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_2_attr_ExchangeContext-Description"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="a024b250-7cb3-0138-410d-418b172fba9f" xmi:uuid="a024b2a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_2_attr_ExchangeContext-Description"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="588" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947842116_20645_33022" xmi:uuid="469ef820-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947780216_549454_33014"/>
      <ownedElement xmi:id="a0330820-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0330890-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947780216_549454_33014"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="a0342580-7cb3-0138-410d-418b172fba9f" xmi:uuid="a03425d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947780216_549454_33014"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="154" width="145" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947939869_254996_33742" xmi:uuid="469f0430-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947935597_860587_33716"/>
      <ownedElement xmi:id="a0446070-7cb3-0138-410d-418b172fba9f" xmi:uuid="a04460f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947935597_860587_33716"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a0458e60-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0458eb0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947935597_860587_33716"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="23859910-6c46-013d-d602-0800270c66d6" xmi:uuid="238599b0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="238be0b0-6c46-013d-d602-0800270c66d6" xmi:uuid="238be180-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539947939870_52238_33746" xmi:uuid="a076e170-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="a0661490-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0661510-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="a0768600-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0768670-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="98" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="70" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947939870_152015_33744" xmi:uuid="469fe2b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947935600_729525_33718"/>
      <ownedElement xmi:id="a0853710-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0853780-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947935600_729525_33718"/>
        <text>identifiers:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="a0865430-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0865480-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947935600_729525_33718"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539947939870_904784_33751" xmi:uuid="469f5cf0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="257cffa0-6c46-013d-d602-0800270c66d6" xmi:uuid="257d0040-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="327" y="86" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="309" y="95" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="147" y="91" width="170" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947939870_909277_33745" xmi:uuid="46a113f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947935602_231672_33719"/>
      <ownedElement xmi:id="a0960480-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0960680-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947935602_231672_33719"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539947939870_408642_33753" xmi:uuid="46a05040-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="2647aa50-6c46-013d-d602-0800270c66d6" xmi:uuid="2647ab20-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="184" y="150" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="238" y="159" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539947939870_890245_33755" xmi:uuid="46a0a6b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="26b00270-6c46-013d-d602-0800270c66d6" xmi:uuid="26b00310-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="402" y="162" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="384" y="171" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539947939870_877623_33757" xmi:uuid="46a10090-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="27081b90-6c46-013d-d602-0800270c66d6" xmi:uuid="27081c00-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="287" y="132" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="266" y="147" width="15" height="15"/>
      </ownedElement>
      <bounds x="238" y="147" width="161" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947939871_34923_33760" xmi:uuid="46a11c40-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947935603_204245_33720"/>
      <source xmi:idref="_18_4_1_2b2015d_1539947939869_254996_33742"/>
      <target xmi:idref="_18_4_1_2b2015d_1539947939870_904784_33751"/>
      <waypoint x="525" y="102"/>
      <waypoint x="324" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947939871_103192_33762" xmi:uuid="46a126d0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947935604_367939_33721"/>
      <source xmi:idref="_18_4_1_2b2015d_1539947939870_152015_33744"/>
      <target xmi:idref="_18_4_1_2b2015d_1539947939870_877623_33757"/>
      <waypoint x="277" y="116"/>
      <waypoint x="277" y="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948123921_874759_34031" xmi:uuid="46a12ea0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948125137_831871_34032"/>
      <source xmi:idref="_18_4_1_2b2015d_1539947939870_408642_33753"/>
      <target xmi:idref="_18_4_1_2b2015d_1539947842116_20645_33022"/>
      <waypoint x="238" y="165"/>
      <waypoint x="180" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_875746_34802" xmi:uuid="46a13bd0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259840_327994_34751"/>
      <ownedElement xmi:id="a0a8a4f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0a8a650-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259840_327994_34751"/>
        <text>descAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a0a9d7a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0a9d7e0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259840_327994_34751"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="279bd870-6c46-013d-d602-0800270c66d6" xmi:uuid="279bd920-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="279c6fa0-6c46-013d-d602-0800270c66d6" xmi:uuid="279c7070-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_523183_34808" xmi:uuid="a0db0910-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="a0ca33a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0ca3410-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="a0daa620-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0daa690-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="308" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="280" width="273" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_748018_34803" xmi:uuid="46a14960-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259842_274302_34752"/>
      <ownedElement xmi:id="a0eb4b20-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0eb4c50-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259842_274302_34752"/>
        <text>descLangInd:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="a0ec69e0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0ec6a20-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259842_274302_34752"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="293e66d0-6c46-013d-d602-0800270c66d6" xmi:uuid="293e6770-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="293ee940-6c46-013d-d602-0800270c66d6" xmi:uuid="293ee9f0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_169223_34809" xmi:uuid="a10f30a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="a0fe23c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a0fe2440-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="a10ed540-7cb3-0138-410d-418b172fba9f" xmi:uuid="a10ed5c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="539" y="448" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_995863_34810" xmi:uuid="a13f99f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="a12e9060-7cb3-0138-410d-418b172fba9f" xmi:uuid="a12e9190-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="a13f3ac0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a13f3b30-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="413" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_118099_34811" xmi:uuid="a1702850-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="a15f4c60-7cb3-0138-410d-418b172fba9f" xmi:uuid="a15f4ce0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="a16fcb40-7cb3-0138-410d-418b172fba9f" xmi:uuid="a16fcbb0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="378" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="350" width="273" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_782490_34804" xmi:uuid="46a2e2e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259843_564465_34753"/>
      <ownedElement xmi:id="a17f5d40-7cb3-0138-410d-418b172fba9f" xmi:uuid="a17f5db0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259843_564465_34753"/>
        <text>descSelect:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_312431_34812" xmi:uuid="46a19940-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="2cfa9220-6c46-013d-d602-0800270c66d6" xmi:uuid="2cfa92c0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="214" y="563" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="204" y="545" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539948262552_784103_34814" xmi:uuid="46a20890-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="2d5983a0-6c46-013d-d602-0800270c66d6" xmi:uuid="2d598440-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="336" y="500" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="318" y="509" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539948262552_377220_34816" xmi:uuid="46a26b80-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="2dd7cea0-6c46-013d-d602-0800270c66d6" xmi:uuid="2dd7d030-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="105" y="482" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="168" y="497" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539948262552_616528_34818" xmi:uuid="46a2cca0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="2e284000-6c46-013d-d602-0800270c66d6" xmi:uuid="2e2840a0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="216" y="481" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="206" y="497" width="15" height="15"/>
      </ownedElement>
      <bounds x="140" y="497" width="193" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_82355_34805" xmi:uuid="46a30db0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259843_121830_34754"/>
      <ownedElement xmi:id="a182ad80-7cb3-0138-410d-418b172fba9f" xmi:uuid="a182adf0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259843_121830_34754"/>
        <text>attribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="a183ba00-7cb3-0138-410d-418b172fba9f" xmi:uuid="a183ba40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259843_121830_34754"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="280" y="448" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_701878_34806" xmi:uuid="46a392b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259844_796113_34755"/>
      <ownedElement xmi:id="a191ea40-7cb3-0138-410d-418b172fba9f" xmi:uuid="a191eac0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259844_796113_34755"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="a1932600-7cb3-0138-410d-418b172fba9f" xmi:uuid="a1932670-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259844_796113_34755"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539948262552_434683_34820" xmi:uuid="46a360b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="2f1acee0-6c46-013d-d602-0800270c66d6" xmi:uuid="2f1acfd0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="297" y="296" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="279" y="305" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="98" y="301" width="189" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948262551_552579_34807" xmi:uuid="46a43590-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259845_815461_34756"/>
      <ownedElement xmi:id="a1a1e1a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a1a1e240-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259845_815461_34756"/>
        <text>descLang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="a1a33770-7cb3-0138-410d-418b172fba9f" xmi:uuid="a1a337c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259845_815461_34756"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539948262552_992114_34822" xmi:uuid="46a3f7a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="2ff044c0-6c46-013d-d602-0800270c66d6" xmi:uuid="2ff04590-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="421" y="369" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="403" y="378" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="238" y="371" width="173" height="28"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948262553_311271_34826" xmi:uuid="46a44160-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259846_952166_34757"/>
      <source xmi:idref="_18_4_1_2b2015d_1539948262552_616528_34818"/>
      <target xmi:idref="_18_4_1_2b2015d_1539948262551_552579_34807"/>
      <waypoint x="214" y="497"/>
      <waypoint x="214" y="382"/>
      <waypoint x="238" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948262553_65022_34827" xmi:uuid="46a44b30-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259846_852208_34758"/>
      <source xmi:idref="_18_4_1_2b2015d_1539948262551_169223_34809"/>
      <target xmi:idref="_18_4_1_2b2015d_1539948262551_82355_34805"/>
      <waypoint x="539" y="462"/>
      <waypoint x="486" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948262553_43520_34828" xmi:uuid="46a45a00-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259846_385670_34759"/>
      <source xmi:idref="_18_4_1_2b2015d_1539948262552_377220_34816"/>
      <target xmi:idref="_18_4_1_2b2015d_1539948262551_701878_34806"/>
      <waypoint x="175" y="497"/>
      <waypoint x="175" y="326"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948262553_283973_34829" xmi:uuid="46a463a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948259846_374618_34760"/>
      <source xmi:idref="_18_4_1_2b2015d_1539948262552_434683_34820"/>
      <target xmi:idref="_18_4_1_2b2015d_1539948262551_875746_34802"/>
      <waypoint x="294" y="312"/>
      <waypoint x="525" y="312"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948309619_905602_35306" xmi:uuid="46a46cb0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948310383_228479_35307"/>
      <source xmi:idref="_18_4_1_2b2015d_1539948262551_118099_34811"/>
      <target xmi:idref="_18_4_1_2b2015d_1539948262552_992114_34822"/>
      <waypoint x="539" y="385"/>
      <waypoint x="418" y="385"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539948336675_693404_35332" xmi:uuid="46a47550-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539948337506_134026_35333"/>
      <source xmi:idref="_18_4_1_2b2015d_1539948262551_312431_34812"/>
      <target xmi:idref="_18_4_1_2b2015d_1539947616905_697153_32796"/>
      <waypoint x="210" y="560"/>
      <waypoint x="210" y="588"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539952983317_62025_35416" xmi:uuid="46a48460-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539952983312_369450_35414"/>
      <ownedElement xmi:id="a1b401a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a1b40210-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539952983312_369450_35414"/>
        <text>library:External_class_library</text>
      </ownedElement>
      <ownedElement xmi:id="a1b51ce0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a1b51d20-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539952983312_369450_35414"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="30726730-6c46-013d-d602-0800270c66d6" xmi:uuid="30726810-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="30732a30-6c46-013d-d602-0800270c66d6" xmi:uuid="30732b00-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552057070316_884565_36302" xmi:uuid="a1d6b9e0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source-id"/>
          <ownedElement xmi:id="a1c61780-7cb3-0138-410d-418b172fba9f" xmi:uuid="a1c617f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="a1d658f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a1d65970-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="154" y="735" width="88" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="140" y="707" width="194" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552043211011_211199_35615" xmi:uuid="46a49520-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552043211001_997565_35613"/>
      <ownedElement xmi:id="a1e79400-7cb3-0138-410d-418b172fba9f" xmi:uuid="a1e79480-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552043211001_997565_35613"/>
        <text>exchange_context:Product_definition_exchange_context</text>
      </ownedElement>
      <ownedElement xmi:id="a1e8c1b0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a1e8c1f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552043211001_997565_35613"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="31bd1f20-6c46-013d-d602-0800270c66d6" xmi:uuid="31bd2010-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="31c8f8d0-6c46-013d-d602-0800270c66d6" xmi:uuid="31c8f9f0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552043323413_933269_35653" xmi:uuid="a21ad050-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Additional_view_definition_context-application_domain"/>
          <ownedElement xmi:id="a209c310-7cb3-0138-410d-418b172fba9f" xmi:uuid="a209c380-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Additional_view_definition_context-application_domain"/>
            <text>application_domain:additional_application_domain_select</text>
          </ownedElement>
          <ownedElement xmi:id="a21a6ec0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a21a6f30-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Additional_view_definition_context-application_domain"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="889" y="539" width="356" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552043323489_612048_35684" xmi:uuid="a24bf0a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_definition_exchange_context-default_language"/>
          <ownedElement xmi:id="a23ab440-7cb3-0138-410d-418b172fba9f" xmi:uuid="a23ab4d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_definition_exchange_context-default_language"/>
            <text>default_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="a24b94a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a24b9510-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_definition_exchange_context-default_language"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="889" y="609" width="199" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552043323519_511904_35746" xmi:uuid="a26db080-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_context-description"/>
          <ownedElement xmi:id="a25ca200-7cb3-0138-410d-418b172fba9f" xmi:uuid="a25ca270-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_context-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="a26d55d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a26d5640-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_context-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="889" y="504" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552043323530_690790_35777" xmi:uuid="a29f9710-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_definition_exchange_context-identification_context"/>
          <ownedElement xmi:id="a28e7320-7cb3-0138-410d-418b172fba9f" xmi:uuid="a28e73a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_definition_exchange_context-identification_context"/>
            <text>identification_context:exchange_identification_context_select</text>
          </ownedElement>
          <ownedElement xmi:id="a29f30a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a29f3120-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Product_definition_exchange_context-identification_context"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="889" y="644" width="386" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552043323544_838084_35808" xmi:uuid="a2d072c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_context-life_cycle_stage"/>
          <ownedElement xmi:id="a2bf64c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a2bf6540-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_context-life_cycle_stage"/>
            <text>life_cycle_stage:life_cycle_stage_select</text>
          </ownedElement>
          <ownedElement xmi:id="a2d015f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a2d01670-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_context-life_cycle_stage"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="889" y="574" width="261" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="875" y="476" width="404" height="203"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552043377584_309006_35856" xmi:uuid="46a49e60-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552043379825_333048_35859"/>
      <source xmi:idref="_18_4_1_2b2015d_1539947939870_52238_33746"/>
      <target xmi:idref="_18_4_1_2b2015d_1552043211011_211199_35615"/>
      <waypoint x="722" y="109"/>
      <waypoint x="945" y="109"/>
      <waypoint x="945" y="476"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552043785796_112556_35887" xmi:uuid="46a4c310-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552043785789_155827_35885"/>
      <ownedElement xmi:id="a2e188f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a2e18970-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552043785789_155827_35885"/>
        <text>simpleIdAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a2e2a9f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a2e2aa40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552043785789_155827_35885"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="375e6800-6c46-013d-d602-0800270c66d6" xmi:uuid="375e68a0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="376fcca0-6c46-013d-d602-0800270c66d6" xmi:uuid="376fcd60-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552043826665_355509_35919" xmi:uuid="a3050d50-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="a2f438c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a2f43940-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="a304b540-7cb3-0138-410d-418b172fba9f" xmi:uuid="a304b5c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="539" y="168" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552043826736_781488_35952" xmi:uuid="a3359fb0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="a3248ed0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3248f50-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="a3353f40-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3353fc0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="539" y="203" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552043826750_991494_35983" xmi:uuid="a356cb30-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="a3460750-7cb3-0138-410d-418b172fba9f" xmi:uuid="a34607d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="a35669a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3566a20-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="539" y="238" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="525" y="140" width="263" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552052002017_274416_36160" xmi:uuid="46a4d3a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552052003968_488188_36163"/>
      <source xmi:idref="_18_4_1_2b2015d_1552043323489_612048_35684"/>
      <target xmi:idref="_18_4_1_2b2015d_1539953335753_467057_35490"/>
      <waypoint x="889" y="620"/>
      <waypoint x="385" y="620"/>
      <waypoint x="385" y="634"/>
      <waypoint x="273" y="634"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552052009751_102329_36188" xmi:uuid="46a4da90-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552052011734_389499_36191"/>
      <source xmi:idref="_18_4_1_2b2015d_1552043323519_511904_35746"/>
      <target xmi:idref="_18_4_1_2b2015d_1539948262552_784103_34814"/>
      <waypoint x="889" y="515"/>
      <waypoint x="333" y="515"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552054092194_72369_36214" xmi:uuid="46a4e2b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552054093933_867842_36217"/>
      <source xmi:idref="_18_4_1_2b2015d_1552043826665_355509_35919"/>
      <target xmi:idref="_18_4_1_2b2015d_1539947939870_890245_33755"/>
      <waypoint x="539" y="179"/>
      <waypoint x="399" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552054112338_6715_36236" xmi:uuid="46a4ea70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552054114134_749782_36239"/>
      <source xmi:idref="_18_4_1_2b2015d_1539948262551_995863_34810"/>
      <target xmi:idref="_18_4_1_2b2015d_1552043211011_211199_35615"/>
      <waypoint x="767" y="424"/>
      <waypoint x="945" y="424"/>
      <waypoint x="945" y="476"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552054117427_67601_36255" xmi:uuid="46a4f290-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552054120315_10628_36258"/>
      <source xmi:idref="_18_4_1_2b2015d_1539948262551_523183_34808"/>
      <target xmi:idref="_18_4_1_2b2015d_1552043211011_211199_35615"/>
      <waypoint x="714" y="319"/>
      <waypoint x="945" y="319"/>
      <waypoint x="945" y="476"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552054125630_42761_36274" xmi:uuid="46a4f9e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552054126968_834935_36277"/>
      <source xmi:idref="_18_4_1_2b2015d_1552043826736_781488_35952"/>
      <target xmi:idref="_18_4_1_2b2015d_1552043211011_211199_35615"/>
      <waypoint x="722" y="214"/>
      <waypoint x="945" y="214"/>
      <waypoint x="945" y="476"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552057144634_636825_36348" xmi:uuid="46a50210-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057146010_265116_36351"/>
      <source xmi:idref="_18_4_1_2b2015d_1552057070316_884565_36302"/>
      <target xmi:idref="_18_4_1_2b2015d_1539947616865_835469_32672"/>
      <waypoint x="165" y="760"/>
      <waypoint x="165" y="847"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552057154533_331444_36369" xmi:uuid="46a510a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057154527_705039_36367"/>
      <ownedElement xmi:id="a3674e50-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3674ed0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057154527_705039_36367"/>
        <text>contextUsingLib:External_class</text>
      </ownedElement>
      <ownedElement xmi:id="a3687480-7cb3-0138-410d-418b172fba9f" xmi:uuid="a36874c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057154527_705039_36367"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="3a8410f0-6c46-013d-d602-0800270c66d6" xmi:uuid="3a8411e0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3a938a60-6c46-013d-d602-0800270c66d6" xmi:uuid="3a938bf0-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552057229035_627943_36401" xmi:uuid="a399b000-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_class-external_source"/>
          <ownedElement xmi:id="a388e3f0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a388e460-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_class-external_source"/>
            <text>external_source:External_class_library</text>
          </ownedElement>
          <ownedElement xmi:id="a3995190-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3995210-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_class-external_source"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="434" y="735" width="249" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552057229086_492183_36432" xmi:uuid="a3ba4590-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="a3a9bf10-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3a9bf90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="a3b9ead0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3b9eb40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="434" y="770" width="88" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552057229099_171490_36463" xmi:uuid="a3db55f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="a3cacb10-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3cacbb0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="a3dafd10-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3dafd80-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="434" y="805" width="109" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="420" y="707" width="270" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552057266210_965390_36519" xmi:uuid="46a518a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057267524_656526_36520"/>
      <source xmi:idref="_18_4_1_2b2015d_1552057229035_627943_36401"/>
      <target xmi:idref="_18_4_1_2b2015d_1539952983317_62025_35416"/>
      <waypoint x="434" y="746"/>
      <waypoint x="334" y="746"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552057427306_936691_36543" xmi:uuid="46a52580-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057427300_320478_36541"/>
      <ownedElement xmi:id="a3ebce20-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3ebcea0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057427300_320478_36541"/>
        <text>contextClassification:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="a3ecf1c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a3ecf200-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057427300_320478_36541"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="3da9b290-6c46-013d-d602-0800270c66d6" xmi:uuid="3da9b330-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="3daa3c10-6c46-013d-d602-0800270c66d6" xmi:uuid="3daa3c90-6c46-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552057495894_417446_36577" xmi:uuid="a41e4dd0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="a40d2b50-7cb3-0138-410d-418b172fba9f" xmi:uuid="a40d2bc0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="a41df300-7cb3-0138-410d-418b172fba9f" xmi:uuid="a41df3f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="889" y="805" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1552057495975_827665_36610" xmi:uuid="a44ebc90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="a43dfc40-7cb3-0138-410d-418b172fba9f" xmi:uuid="a43dfcc0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="a44e6220-7cb3-0138-410d-418b172fba9f" xmi:uuid="a44e6290-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="889" y="770" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="875" y="742" width="292" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552057565054_279936_36703" xmi:uuid="46a52dd0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057567167_941037_36706"/>
      <source xmi:idref="_18_4_1_2b2015d_1552057495975_827665_36610"/>
      <target xmi:idref="_18_4_1_2b2015d_1552043211011_211199_35615"/>
      <waypoint x="1073" y="781"/>
      <waypoint x="1225" y="781"/>
      <waypoint x="1225" y="679"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552057664824_505221_36758" xmi:uuid="46a53550-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057666180_918730_36759"/>
      <source xmi:idref="_18_4_1_2b2015d_1552057495894_417446_36577"/>
      <target xmi:idref="_18_4_1_2b2015d_1552057154533_331444_36369"/>
      <waypoint x="889" y="816"/>
      <waypoint x="690" y="816"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552057698183_971081_36777" xmi:uuid="46a540b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057698177_366971_36775"/>
      <ownedElement xmi:id="a44ffef0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a44fff30-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057698177_366971_36775"/>
        <text>clu:String</text>
      </ownedElement>
      <ownedElement xmi:id="a4510ef0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a4510f40-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057698177_366971_36775"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="182" y="791" width="202" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552057741542_730428_36818" xmi:uuid="46a548c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057743043_690672_36821"/>
      <source xmi:idref="_18_4_1_2b2015d_1552057229086_492183_36432"/>
      <target xmi:idref="_18_4_1_2b2015d_1552057698183_971081_36777"/>
      <waypoint x="434" y="781"/>
      <waypoint x="396" y="781"/>
      <waypoint x="396" y="802"/>
      <waypoint x="384" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552057745972_24090_36837" xmi:uuid="46a550a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057748814_175708_36840"/>
      <source xmi:idref="_18_4_1_2b2015d_1552057229099_171490_36463"/>
      <target xmi:idref="_18_4_1_2b2015d_1552057698183_971081_36777"/>
      <waypoint x="434" y="816"/>
      <waypoint x="396" y="816"/>
      <waypoint x="396" y="802"/>
      <waypoint x="384" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552057925653_331774_36866" xmi:uuid="46a55b60-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057925648_683499_36864"/>
      <ownedElement xmi:id="a4616110-7cb3-0138-410d-418b172fba9f" xmi:uuid="a4616190-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057925648_683499_36864"/>
        <text>dummyLCS:life_cycle_stage_string</text>
      </ownedElement>
      <ownedElement xmi:id="a4628770-7cb3-0138-410d-418b172fba9f" xmi:uuid="a46287a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552057925648_683499_36864"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="574" width="294" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552058136662_698406_36967" xmi:uuid="46a562c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058138365_666995_36970"/>
      <source xmi:idref="_18_4_1_2b2015d_1552043323544_838084_35808"/>
      <target xmi:idref="_18_4_1_2b2015d_1552057925653_331774_36866"/>
      <waypoint x="889" y="585"/>
      <waypoint x="791" y="585"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552058146239_803916_36988" xmi:uuid="46a56da0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058146233_95481_36986"/>
      <ownedElement xmi:id="a4732a20-7cb3-0138-410d-418b172fba9f" xmi:uuid="a4732a90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058146233_95481_36986"/>
        <text>dummyAD:application_domain_string</text>
      </ownedElement>
      <ownedElement xmi:id="a47454c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a4745630-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058146233_95481_36986"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="497" y="539" width="295" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552058213861_640052_37029" xmi:uuid="46a574f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058214951_510375_37032"/>
      <source xmi:idref="_18_4_1_2b2015d_1552043323413_933269_35653"/>
      <target xmi:idref="_18_4_1_2b2015d_1552058146239_803916_36988"/>
      <waypoint x="889" y="550"/>
      <waypoint x="792" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552058288289_744274_37083" xmi:uuid="46a57cc0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058289815_235577_37086"/>
      <source xmi:idref="_18_4_1_2b2015d_1552058233626_218709_37056"/>
      <target xmi:idref="_18_4_1_2b2015d_1552043211011_211199_35615"/>
      <waypoint x="1294" y="452"/>
      <waypoint x="1117" y="452"/>
      <waypoint x="1117" y="476"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552058520039_370036_38153" xmi:uuid="46a587c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058520032_364069_38151"/>
      <ownedElement xmi:id="a47580c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="a4758100-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058520032_364069_38151"/>
        <text>role:String</text>
      </ownedElement>
      <ownedElement xmi:id="a4769790-7cb3-0138-410d-418b172fba9f" xmi:uuid="a47697d0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058520032_364069_38151"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="350" y="238" width="128" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1552058593374_145625_38198" xmi:uuid="46a58f90-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1552058594407_649736_38201"/>
      <source xmi:idref="_18_4_1_2b2015d_1552043826750_991494_35983"/>
      <target xmi:idref="_18_4_1_2b2015d_1552058520039_370036_38153"/>
      <waypoint x="539" y="249"/>
      <waypoint x="478" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1583160891429_931855_56363" xmi:uuid="a476b490-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1583160894025_776033_56364"/>
      <source xmi:idref="_18_4_1_2b2015d_1552043323530_690790_35777"/>
      <target xmi:idref="_18_4_1_271a0567_1583160806211_207970_56334"/>
      <waypoint x="889" y="655"/>
      <waypoint x="707" y="655"/>
      <waypoint x="707" y="669"/>
      <waypoint x="413" y="669"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1297" height="887"/>
    <name>ExchangeContext</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_2b2015d_1539787860748_232271_40292" xmi:uuid="b2655991-3785-41de-a54b-43e75fcc498c" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767618244_553303_31517"/>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539789259308_242557_42389" xmi:uuid="467e9f70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789259299_591770_42385"/>
      <bounds x="1159" y="47" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539787866065_906527_40328" xmi:uuid="467eb130-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539771086464_38173_32518"/>
      <ownedElement xmi:id="9678e9b0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9678ea20-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539771086464_38173_32518"/>
        <text>Acknowledge:Acknowledgement</text>
      </ownedElement>
      <ownedElement xmi:id="9679ff50-7cb3-0138-410d-418b172fba9f" xmi:uuid="9679ff90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539771086464_38173_32518"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_271a0567_1607334320709_623350_75789" xmi:uuid="6842ee70-327f-0139-a8c9-34a9fcdfa563" xmi:type="umldi:UMLShape">
        <modelElement href="Message.xmi#_18_4_1_271a0567_1607334063349_656101_74478"/>
        <ownedElement xmi:id="c08a7400-6c45-013d-d602-0800270c66d6" xmi:uuid="c08a74a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_271a0567_1607334063349_656101_74478"/>
          <bounds x="297" y="72" width="202" height="13"/>
          <text>acknowledgement : Acknowledgement [1]</text>
        </ownedElement>
        <bounds x="279" y="81" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="77" width="252" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539787866073_782953_40359" xmi:uuid="467f3ae0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767651915_229162_31570"/>
      <ownedElement xmi:id="9688a6a0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9688a710-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767651915_229162_31570"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="9689c6c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9689c700-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767651915_229162_31570"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539788898082_116980_41868" xmi:uuid="467efc80-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="c160f180-6c45-013d-d602-0800270c66d6" xmi:uuid="c160f210-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="262" y="289" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="244" y="298" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="294" width="217" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539787866080_792626_40390" xmi:uuid="467f4b80-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767633550_234866_31562"/>
      <ownedElement xmi:id="96989cd0-7cb3-0138-410d-418b172fba9f" xmi:uuid="96989d50-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767633550_234866_31562"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="9699be40-7cb3-0138-410d-418b172fba9f" xmi:uuid="9699be90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767633550_234866_31562"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="147" width="161" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539787866086_321744_40421" xmi:uuid="467febb0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767676695_757149_31578"/>
      <ownedElement xmi:id="96a80d80-7cb3-0138-410d-418b172fba9f" xmi:uuid="96a80e00-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767676695_757149_31578"/>
        <text>SameAs:Proxy</text>
      </ownedElement>
      <ownedElement xmi:id="96a92a50-7cb3-0138-410d-418b172fba9f" xmi:uuid="96a92a90-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767676695_757149_31578"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539789091516_196841_42157" xmi:uuid="467face0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
        <ownedElement xmi:id="c2fc6a10-6c45-013d-d602-0800270c66d6" xmi:uuid="c2fc6b00-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1503573537189_778968_26025"/>
          <bounds x="192" y="380" width="184" height="13"/>
          <text>proxy : External_item_identification [1]</text>
        </ownedElement>
        <bounds x="174" y="389" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="385" width="147" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539787866093_305298_40452" xmi:uuid="468078b0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767713754_743693_31588"/>
      <ownedElement xmi:id="96ab5460-7cb3-0138-410d-418b172fba9f" xmi:uuid="96ab54b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767713754_743693_31588"/>
        <text>Wrapping:Message</text>
      </ownedElement>
      <ownedElement xmi:id="96ac67e0-7cb3-0138-410d-418b172fba9f" xmi:uuid="96ac6830-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767713754_743693_31588"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539788120733_271855_40741" xmi:uuid="46803f30-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539786017179_4107_40192"/>
        <ownedElement xmi:id="c32968d0-6c45-013d-d602-0800270c66d6" xmi:uuid="c3296980-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="Message.xmi#_18_4_1_2b2015d_1539786017179_4107_40192"/>
          <bounds x="234" y="107" width="91" height="13"/>
          <text>msg : Message [1]</text>
        </ownedElement>
        <bounds x="216" y="116" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="112" width="189" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539787881079_508490_40496" xmi:uuid="46808c70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539787881072_615697_40494"/>
      <ownedElement xmi:id="96bcd6c0-7cb3-0138-410d-418b172fba9f" xmi:uuid="96bcd740-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539787881072_615697_40494"/>
        <text>envelope:Envelope</text>
      </ownedElement>
      <ownedElement xmi:id="96be0e70-7cb3-0138-410d-418b172fba9f" xmi:uuid="96be0ec0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539787881072_615697_40494"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="c3eb9240-6c45-013d-d602-0800270c66d6" xmi:uuid="c3eb92f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c404e340-6c45-013d-d602-0800270c66d6" xmi:uuid="c404e450-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539787949112_899183_40533" xmi:uuid="96e054b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope-acknowledge"/>
          <ownedElement xmi:id="96cf6420-7cb3-0138-410d-418b172fba9f" xmi:uuid="96cf6490-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope-acknowledge"/>
            <text>acknowledge:Acknowledgement</text>
          </ownedElement>
          <ownedElement xmi:id="96dffa30-7cb3-0138-410d-418b172fba9f" xmi:uuid="96dffaa0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope-acknowledge"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="910" y="77" width="230" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539787949121_764526_40564" xmi:uuid="970183a0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope-id"/>
          <ownedElement xmi:id="96f0f160-7cb3-0138-410d-418b172fba9f" xmi:uuid="96f0f1e0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="97012530-7cb3-0138-410d-418b172fba9f" xmi:uuid="970125b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="910" y="147" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539787949129_127516_40595" xmi:uuid="973170c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope-wrapping"/>
          <ownedElement xmi:id="97209750-7cb3-0138-410d-418b172fba9f" xmi:uuid="972097c0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope-wrapping"/>
            <text>wrapping:Message</text>
          </ownedElement>
          <ownedElement xmi:id="97311530-7cb3-0138-410d-418b172fba9f" xmi:uuid="973115b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Envelope-wrapping"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="910" y="112" width="154" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="896" y="49" width="251" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788150043_927651_40774" xmi:uuid="4681f8d0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788152496_414686_40775"/>
      <source xmi:idref="_18_4_1_2b2015d_1539787949129_127516_40595"/>
      <target xmi:idref="_18_4_1_2b2015d_1539788120733_271855_40741"/>
      <waypoint x="910" y="123"/>
      <waypoint x="231" y="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788560263_507915_41242" xmi:uuid="46843260-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788560256_386740_41240"/>
      <ownedElement xmi:id="9740e080-7cb3-0138-410d-418b172fba9f" xmi:uuid="9740e100-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788560256_386740_41240"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539788583806_798136_41266" xmi:uuid="468348a0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="c8a34d30-6c45-013d-d602-0800270c66d6" xmi:uuid="c8a34dd0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="261" y="143" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="315" y="152" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539788583812_553575_41276" xmi:uuid="4683ab70-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="c9210c80-6c45-013d-d602-0800270c66d6" xmi:uuid="c9210d30-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="472" y="142" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="454" y="151" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539788583819_291408_41286" xmi:uuid="46840f10-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="c9ad0d30-6c45-013d-d602-0800270c66d6" xmi:uuid="c9ad0dd0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="338" y="199" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="328" y="181" width="15" height="15"/>
      </ownedElement>
      <bounds x="315" y="140" width="154" height="56"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788615888_619979_41323" xmi:uuid="46843d50-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788617494_455615_41326"/>
      <source xmi:idref="_18_4_1_2b2015d_1539788583806_798136_41266"/>
      <target xmi:idref="_18_4_1_2b2015d_1539787866080_792626_40390"/>
      <waypoint x="315" y="161"/>
      <waypoint x="196" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788638388_288238_41346" xmi:uuid="46851ee0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788638381_599778_41344"/>
      <ownedElement xmi:id="97520800-7cb3-0138-410d-418b172fba9f" xmi:uuid="97520880-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788638381_599778_41344"/>
        <text>default:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539788661425_102015_41370" xmi:uuid="4684a450-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="ca9d29e0-6c45-013d-d602-0800270c66d6" xmi:uuid="ca9d2a90-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="497" y="167" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="553" y="152" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539788661431_581063_41380" xmi:uuid="46850530-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="caf25220-6c45-013d-d602-0800270c66d6" xmi:uuid="caf254b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="724" y="144" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <bounds x="706" y="153" width="15" height="15"/>
      </ownedElement>
      <bounds x="553" y="140" width="168" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788687601_768544_41431" xmi:uuid="46852be0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788688649_928607_41434"/>
      <source xmi:idref="_18_4_1_2b2015d_1539787949121_764526_40564"/>
      <target xmi:idref="_18_4_1_2b2015d_1539788661431_581063_41380"/>
      <waypoint x="910" y="161"/>
      <waypoint x="721" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788703124_300116_41457" xmi:uuid="4685c380-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788703117_707847_41455"/>
      <ownedElement xmi:id="9761a180-7cb3-0138-410d-418b172fba9f" xmi:uuid="9761a1f0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788703117_707847_41455"/>
        <text>identifiers:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="9762c7d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="9762c810-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788703117_707847_41455"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_2b2015d_1539788727628_244273_41550" xmi:uuid="46857c80-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="cc055cd0-6c45-013d-d602-0800270c66d6" xmi:uuid="cc055db0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="371" y="223" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="405" y="242" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="245" y="238" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788764692_857590_41651" xmi:uuid="4685d0e0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788765971_966127_41654"/>
      <source xmi:idref="_18_4_1_2b2015d_1539788703124_300116_41457"/>
      <target xmi:idref="_18_4_1_2b2015d_1539788583819_291408_41286"/>
      <waypoint x="336" y="238"/>
      <waypoint x="336" y="196"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788783954_414825_41676" xmi:uuid="4685dea0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788783946_729966_41674"/>
      <ownedElement xmi:id="9773ae90-7cb3-0138-410d-418b172fba9f" xmi:uuid="9773af10-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788783946_729966_41674"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="9774d520-7cb3-0138-410d-418b172fba9f" xmi:uuid="9774d570-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788783946_729966_41674"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ccae9480-6c45-013d-d602-0800270c66d6" xmi:uuid="ccae94f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ccaf7920-6c45-013d-d602-0800270c66d6" xmi:uuid="ccaf7b00-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539788843712_169019_41727" xmi:uuid="97a6b300-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="9795d290-7cb3-0138-410d-418b172fba9f" xmi:uuid="9795d310-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="97a656d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="97a65840-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="658" y="231" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="203" width="287" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788862280_937429_41773" xmi:uuid="4685e6f0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788864903_990938_41776"/>
      <source xmi:idref="_18_4_1_2b2015d_1539788843712_169019_41727"/>
      <target xmi:idref="_18_4_1_2b2015d_1539787881079_508490_40496"/>
      <waypoint x="841" y="242"/>
      <waypoint x="1015" y="242"/>
      <waypoint x="1015" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788886306_951987_41798" xmi:uuid="4685efb0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788887309_435020_41801"/>
      <source xmi:idref="_18_4_1_2b2015d_1539788783954_414825_41676"/>
      <target xmi:idref="_18_4_1_2b2015d_1539788727628_244273_41550"/>
      <waypoint x="644" y="249"/>
      <waypoint x="420" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539788964567_367229_41965" xmi:uuid="4685fbc0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788964559_772147_41963"/>
      <ownedElement xmi:id="97b74260-7cb3-0138-410d-418b172fba9f" xmi:uuid="97b742e0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788964559_772147_41963"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="97b85e30-7cb3-0138-410d-418b172fba9f" xmi:uuid="97b85e70-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539788964559_772147_41963"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ce995070-6c45-013d-d602-0800270c66d6" xmi:uuid="ce995110-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ce99d140-6c45-013d-d602-0800270c66d6" xmi:uuid="ce99d1c0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539789022971_483020_42004" xmi:uuid="97e9e320-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="97d90240-7cb3-0138-410d-418b172fba9f" xmi:uuid="97d90370-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="97e98640-7cb3-0138-410d-418b172fba9f" xmi:uuid="97e986b0-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="658" y="308" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="280" width="282" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539789029455_892706_42048" xmi:uuid="468604c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789031680_266142_42051"/>
      <source xmi:idref="_18_4_1_2b2015d_1539789022971_483020_42004"/>
      <target xmi:idref="_18_4_1_2b2015d_1539787881079_508490_40496"/>
      <waypoint x="842" y="319"/>
      <waypoint x="1015" y="319"/>
      <waypoint x="1015" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539789051375_16771_42071" xmi:uuid="46860c90-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789053020_527006_42074"/>
      <source xmi:idref="_18_4_1_2b2015d_1539788964567_367229_41965"/>
      <target xmi:idref="_18_4_1_2b2015d_1539788898082_116980_41868"/>
      <waypoint x="644" y="305"/>
      <waypoint x="259" y="305"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539789119156_729182_42250" xmi:uuid="468619c0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789119149_331050_42248"/>
      <ownedElement xmi:id="97fa74d0-7cb3-0138-410d-418b172fba9f" xmi:uuid="97fa7560-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789119149_331050_42248"/>
        <text>sameAsAsgn:External_item_identification</text>
      </ownedElement>
      <ownedElement xmi:id="97fbb500-7cb3-0138-410d-418b172fba9f" xmi:uuid="97fbb550-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789119149_331050_42248"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="d0659500-6c45-013d-d602-0800270c66d6" xmi:uuid="d06595d0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d0716490-6c45-013d-d602-0800270c66d6" xmi:uuid="d0716c80-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_2b2015d_1539789197521_390981_42287" xmi:uuid="982db720-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
          <ownedElement xmi:id="981cb850-7cb3-0138-410d-418b172fba9f" xmi:uuid="981cba50-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>item:external_identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="982d5b80-7cb3-0138-410d-418b172fba9f" xmi:uuid="982d5c00-7cb3-0138-410d-418b172fba9f" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-External_source_identification-item"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="658" y="385" width="223" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="357" width="287" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539789215056_317228_42335" xmi:uuid="46862280-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789217298_74830_42338"/>
      <source xmi:idref="_18_4_1_2b2015d_1539789119156_729182_42250"/>
      <target xmi:idref="_18_4_1_2b2015d_1539789091516_196841_42157"/>
      <waypoint x="644" y="396"/>
      <waypoint x="189" y="396"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539789220580_557983_42362" xmi:uuid="46862aa0-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789224297_816388_42365"/>
      <source xmi:idref="_18_4_1_2b2015d_1539789197521_390981_42287"/>
      <target xmi:idref="_18_4_1_2b2015d_1539787881079_508490_40496"/>
      <waypoint x="881" y="396"/>
      <waypoint x="1015" y="396"/>
      <waypoint x="1015" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539789325725_884200_42428" xmi:uuid="46863300-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539789327538_851273_42431"/>
      <source xmi:idref="_18_4_1_2b2015d_1539789259308_242557_42389"/>
      <target xmi:idref="_18_4_1_2b2015d_1539787881079_508490_40496"/>
      <waypoint x="1159" y="54"/>
      <waypoint x="1147" y="54"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_2b2015d_1539947959905_958098_34011" xmi:uuid="46863a40-3aa6-0138-3edd-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539947961297_294444_34012"/>
      <source xmi:idref="_18_4_1_2b2015d_1539788661425_102015_41370"/>
      <target xmi:idref="_18_4_1_2b2015d_1539788583812_553575_41276"/>
      <waypoint x="553" y="161"/>
      <waypoint x="469" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_271a0567_1607334345024_630837_75838" xmi:uuid="5c27c890-3820-0139-4564-418b172fba9f" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_271a0567_1607334347577_802269_75839"/>
      <source xmi:idref="_18_4_1_2b2015d_1539787949112_899183_40533"/>
      <target xmi:idref="_18_4_1_271a0567_1607334320709_623350_75789"/>
      <waypoint x="910" y="88"/>
      <waypoint x="294" y="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267558_31303_136993" xmi:uuid="d43f4e70-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262891_282456_136886"/>
      <ownedElement xmi:id="d26bd310-6c45-013d-d602-0800270c66d6" xmi:uuid="d26bd420-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262891_282456_136886"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_360861_137001" xmi:uuid="d2d2d290-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="d2d23130-6c45-013d-d602-0800270c66d6" xmi:uuid="d2d23200-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="261" y="486" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <bounds x="315" y="495" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_313582_137003" xmi:uuid="d35b3b30-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="d34cbbe0-6c45-013d-d602-0800270c66d6" xmi:uuid="d34cbc90-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="362" y="554" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <bounds x="345" y="536" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_615627_137005" xmi:uuid="d3d2b200-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="d3d08d90-6c45-013d-d602-0800270c66d6" xmi:uuid="d3d08e60-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="385" y="468" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <bounds x="450" y="483" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_836586_137007" xmi:uuid="d43f33d0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="d43e2790-6c45-013d-d602-0800270c66d6" xmi:uuid="d43e28b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="462" y="555" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <bounds x="442" y="536" width="15" height="15"/>
      </ownedElement>
      <bounds x="315" y="483" width="229" height="68"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267558_847764_136994" xmi:uuid="d54e7530-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262894_619463_136887"/>
      <ownedElement xmi:id="d4c8f7b0-6c45-013d-d602-0800270c66d6" xmi:uuid="d4c8f930-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262894_619463_136887"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="d4d9a310-6c45-013d-d602-0800270c66d6" xmi:uuid="d4d9a390-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262894_619463_136887"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_627172_137009" xmi:uuid="d54e6650-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="d54dba60-6c45-013d-d602-0800270c66d6" xmi:uuid="d54dbb50-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="700" y="437" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="682" y="446" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="504" y="441" width="186" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864471864_748686_138683" xmi:uuid="d73f5ac0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864474579_843902_138684"/>
      <source xmi:idref="_18_4_1_2b2015d_1539787881079_508490_40496"/>
      <target xmi:idref="_18_4_1_65b021e_1715864267559_813083_137011"/>
      <waypoint x="1015" y="182"/>
      <waypoint x="1015" y="522"/>
      <waypoint x="854" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267558_807144_136995" xmi:uuid="d7404060-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262896_968378_136888"/>
      <ownedElement xmi:id="d5d857b0-6c45-013d-d602-0800270c66d6" xmi:uuid="d5d858d0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262896_968378_136888"/>
        <text>descrAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d5e36780-6c45-013d-d602-0800270c66d6" xmi:uuid="d5e36840-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262896_968378_136888"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="d5e3f7e0-6c45-013d-d602-0800270c66d6" xmi:uuid="d5e3f870-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d5edcd00-6c45-013d-d602-0800270c66d6" xmi:uuid="d5edcd90-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_813083_137011" xmi:uuid="d736a120-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="d6a59f90-6c45-013d-d602-0800270c66d6" xmi:uuid="d6a5a0a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="d7289ac0-6c45-013d-d602-0800270c66d6" xmi:uuid="d7289be0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="679" y="511" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="658" y="483" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_269306_136996" xmi:uuid="d84d9a20-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262899_190209_136889"/>
      <ownedElement xmi:id="d7c515d0-6c45-013d-d602-0800270c66d6" xmi:uuid="d7c51840-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262899_190209_136889"/>
        <text>descrLang:Language</text>
      </ownedElement>
      <ownedElement xmi:id="d7c63d60-6c45-013d-d602-0800270c66d6" xmi:uuid="d7c63e00-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262899_190209_136889"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_956814_137012" xmi:uuid="d84d8dd0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="d84ce1d0-6c45-013d-d602-0800270c66d6" xmi:uuid="d84ce2b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="570" y="584" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="552" y="593" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="378" y="588" width="182" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_228020_136997" xmi:uuid="d874d6f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262900_79785_136890"/>
      <ownedElement xmi:id="d84eb5d0-6c45-013d-d602-0800270c66d6" xmi:uuid="d84eb680-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262900_79785_136890"/>
        <text>descrAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="d8745470-6c45-013d-d602-0800270c66d6" xmi:uuid="d8745580-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262900_79785_136890"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="378" y="623" width="228" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_517603_137022" xmi:uuid="dc59a5e0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262907_739245_136895"/>
      <source xmi:idref="_18_4_1_65b021e_1715864267559_521346_136999"/>
      <target xmi:idref="_18_4_1_65b021e_1715864267559_915398_137015"/>
      <waypoint x="529" y="721"/>
      <waypoint x="529" y="669"/>
      <waypoint x="693" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_569866_136998" xmi:uuid="dc5a0b20-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262901_588168_136891"/>
      <ownedElement xmi:id="d8d9f680-6c45-013d-d602-0800270c66d6" xmi:uuid="d8d9f780-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262901_588168_136891"/>
        <text>descrLangInd:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="d8e7aec0-6c45-013d-d602-0800270c66d6" xmi:uuid="d8e7af80-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262901_588168_136891"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d8e841b0-6c45-013d-d602-0800270c66d6" xmi:uuid="d8e84240-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d8f9d4d0-6c45-013d-d602-0800270c66d6" xmi:uuid="d8f9d5f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_383556_137014" xmi:uuid="d9d58500-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="d9675030-6c45-013d-d602-0800270c66d6" xmi:uuid="d9675110-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="d9c57f70-6c45-013d-d602-0800270c66d6" xmi:uuid="d9c58170-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="693" y="623" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_915398_137015" xmi:uuid="db0050f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="da9a6920-6c45-013d-d602-0800270c66d6" xmi:uuid="da9a6a50-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="daff5a30-6c45-013d-d602-0800270c66d6" xmi:uuid="daff5b70-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="693" y="658" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_334364_137016" xmi:uuid="dc591520-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="dbe3cee0-6c45-013d-d602-0800270c66d6" xmi:uuid="dbe3cfd0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="dc4aa430-6c45-013d-d602-0800270c66d6" xmi:uuid="dc4aa500-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="693" y="588" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="679" y="560" width="249" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_521346_136999" xmi:uuid="ddb9dd60-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262903_234588_136892"/>
      <ownedElement xmi:id="dce37f00-6c45-013d-d602-0800270c66d6" xmi:uuid="dce37fd0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262903_234588_136892"/>
        <text>descriptor:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="dce4c330-6c45-013d-d602-0800270c66d6" xmi:uuid="dce4c410-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262903_234588_136892"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="dcf49b60-6c45-013d-d602-0800270c66d6" xmi:uuid="dcf49c50-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dcf53450-6c45-013d-d602-0800270c66d6" xmi:uuid="dcf534f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_229140_137017" xmi:uuid="ddb9d3b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="dd5b2970-6c45-013d-d602-0800270c66d6" xmi:uuid="dd5b2ad0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="ddb94380-6c45-013d-d602-0800270c66d6" xmi:uuid="ddb94460-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="413" y="749" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="399" y="721" width="199" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864481101_499122_138702" xmi:uuid="e0ddf4a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864484385_434504_138703"/>
      <source xmi:idref="_18_4_1_2b2015d_1539787881079_508490_40496"/>
      <target xmi:idref="_18_4_1_65b021e_1715864267559_760641_137019"/>
      <waypoint x="1015" y="182"/>
      <waypoint x="1015" y="788"/>
      <waypoint x="812" y="788"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_958347_137000" xmi:uuid="e0f8d590-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262904_868166_136893"/>
      <ownedElement xmi:id="de24c980-6c45-013d-d602-0800270c66d6" xmi:uuid="de24ca70-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262904_868166_136893"/>
        <text>simpleDescrAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="de355020-6c45-013d-d602-0800270c66d6" xmi:uuid="de3550e0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262904_868166_136893"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="de35ebb0-6c45-013d-d602-0800270c66d6" xmi:uuid="de35ec70-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="de45bc70-6c45-013d-d602-0800270c66d6" xmi:uuid="de45bd30-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_64008_137018" xmi:uuid="df871620-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="df065ec0-6c45-013d-d602-0800270c66d6" xmi:uuid="df065ff0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="df864b20-6c45-013d-d602-0800270c66d6" xmi:uuid="df864c00-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="637" y="742" width="192" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_760641_137019" xmi:uuid="e0dd5b90-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="e0562d90-6c45-013d-d602-0800270c66d6" xmi:uuid="e0562ea0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="e0d22c30-6c45-013d-d602-0800270c66d6" xmi:uuid="e0d22d00-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="637" y="777" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="616" y="714" width="312" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_45916_137023" xmi:uuid="e0f8dfa0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262907_415271_136901"/>
      <source xmi:idref="_18_4_1_65b021e_1715864267558_847764_136994"/>
      <target xmi:idref="_18_4_1_65b021e_1715864267559_615627_137005"/>
      <waypoint x="504" y="455"/>
      <waypoint x="459" y="455"/>
      <waypoint x="459" y="483"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_164987_137024" xmi:uuid="e0f8e700-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262908_657083_136905"/>
      <source xmi:idref="_18_4_1_65b021e_1715864267558_807144_136995"/>
      <target xmi:idref="_18_4_1_65b021e_1715864267559_627172_137009"/>
      <waypoint x="791" y="483"/>
      <waypoint x="791" y="455"/>
      <waypoint x="697" y="455"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_475220_137025" xmi:uuid="e0f8ee30-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262908_834857_136909"/>
      <source xmi:idref="_18_4_1_65b021e_1715864267559_269306_136996"/>
      <target xmi:idref="_18_4_1_65b021e_1715864267559_836586_137007"/>
      <waypoint x="452" y="588"/>
      <waypoint x="452" y="551"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_48452_137026" xmi:uuid="e0f8f4a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262909_773789_136914"/>
      <source xmi:idref="_18_4_1_65b021e_1715864267559_383556_137014"/>
      <target xmi:idref="_18_4_1_65b021e_1715864267559_228020_136997"/>
      <waypoint x="693" y="634"/>
      <waypoint x="606" y="634"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_622416_137027" xmi:uuid="e0f8fc10-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262909_993674_136921"/>
      <source xmi:idref="_18_4_1_65b021e_1715864267559_64008_137018"/>
      <target xmi:idref="_18_4_1_65b021e_1715864267559_521346_136999"/>
      <waypoint x="637" y="753"/>
      <waypoint x="598" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_110631_137028" xmi:uuid="e0f90270-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262910_6148_136925"/>
      <source xmi:idref="_18_4_1_65b021e_1715864267559_229140_137017"/>
      <target xmi:idref="_18_4_1_65b021e_1715864267559_313582_137003"/>
      <waypoint x="413" y="760"/>
      <waypoint x="354" y="760"/>
      <waypoint x="354" y="551"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864267559_50850_137029" xmi:uuid="e0f90920-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864262910_981521_136926"/>
      <source xmi:idref="_18_4_1_65b021e_1715864267559_334364_137016"/>
      <target xmi:idref="_18_4_1_65b021e_1715864267559_956814_137012"/>
      <waypoint x="693" y="600"/>
      <waypoint x="567" y="600"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864313361_882071_137568" xmi:uuid="e1681070-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715863757345_254287_125738"/>
      <ownedElement xmi:id="e147cc20-6c45-013d-d602-0800270c66d6" xmi:uuid="e147ce70-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715863757345_254287_125738"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e15d2900-6c45-013d-d602-0800270c66d6" xmi:uuid="e15d2a30-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_65b021e_1715863757345_254287_125738"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="490" width="200" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1715864344171_510538_137614" xmi:uuid="e1681d30-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1715864345239_521643_137615"/>
      <source xmi:idref="_18_4_1_65b021e_1715864267559_360861_137001"/>
      <target xmi:idref="_18_4_1_65b021e_1715864313361_882071_137568"/>
      <waypoint x="315" y="501"/>
      <waypoint x="235" y="501"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1162" height="827"/>
    <name>Envelope</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446295503_615551_279204" xmi:uuid="bf2a4c60-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_18_4_1_2b2015d_1539768315078_454856_32209"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295526_895853_279236" xmi:uuid="bfd586a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793736219_497486_47980"/>
      <ownedElement xmi:id="bfc1d7d0-6c45-013d-d602-0800270c66d6" xmi:uuid="bfc1d920-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793736219_497486_47980"/>
        <text>relation:Envelope_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="bfd575d0-6c45-013d-d602-0800270c66d6" xmi:uuid="bfd57680-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539793736219_497486_47980"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="198" height="230"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295543_179400_279270" xmi:uuid="bfd60e20-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="545" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295561_517669_279291" xmi:uuid="bfeaf180-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="545" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295578_702381_279312" xmi:uuid="bff3bf30-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="545" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295595_347188_279333" xmi:uuid="bffc63f0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="545" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295613_651856_279354" xmi:uuid="bffd04c0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="545" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295629_445212_279375" xmi:uuid="c00f3c80-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="545" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295649_371411_279396" xmi:uuid="c00fddb0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="545" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295668_642887_279417" xmi:uuid="c010a7d0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="545" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446295685_993189_279438" xmi:uuid="c0118280-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="545" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496452_672901_401270" xmi:uuid="c0257b00-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736382561_420538_69084"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295543_179400_279270"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295526_895853_279236"/>
      <waypoint x="545" y="62"/>
      <waypoint x="243" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496452_10185_401273" xmi:uuid="c0258b10-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736385569_52130_69104"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295561_517669_279291"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295526_895853_279236"/>
      <waypoint x="545" y="82"/>
      <waypoint x="243" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496452_565147_401276" xmi:uuid="c02599e0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736400194_329748_69184"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295578_702381_279312"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295526_895853_279236"/>
      <waypoint x="545" y="102"/>
      <waypoint x="243" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496452_468305_401279" xmi:uuid="c025a920-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736379317_978886_69064"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295595_347188_279333"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295526_895853_279236"/>
      <waypoint x="545" y="122"/>
      <waypoint x="243" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496452_564538_401282" xmi:uuid="c025b5d0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736376110_997375_69044"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295613_651856_279354"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295526_895853_279236"/>
      <waypoint x="545" y="142"/>
      <waypoint x="243" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496452_488800_401285" xmi:uuid="c025caa0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736388782_773505_69124"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295629_445212_279375"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295526_895853_279236"/>
      <waypoint x="545" y="162"/>
      <waypoint x="243" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496452_94742_401288" xmi:uuid="c025d4b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736392150_987857_69144"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295649_371411_279396"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295526_895853_279236"/>
      <waypoint x="545" y="182"/>
      <waypoint x="243" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496452_257195_401291" xmi:uuid="c025dcd0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736396244_837647_69164"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295668_642887_279417"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295526_895853_279236"/>
      <waypoint x="545" y="202"/>
      <waypoint x="243" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496452_793540_401294" xmi:uuid="c025e3b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736365540_35089_69024"/>
      <source xmi:idref="_18_4_1_65b021e_1727446295685_993189_279438"/>
      <target xmi:idref="_18_4_1_65b021e_1727446295526_895853_279236"/>
      <waypoint x="545" y="222"/>
      <waypoint x="243" y="222"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="548" height="300"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446296137_343936_279919" xmi:uuid="e16bd300-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="Message.xmi#_18_4_1_2b2015d_1539767618244_553303_31517"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296165_42693_279951" xmi:uuid="e20384c0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539787881072_615697_40494"/>
      <ownedElement xmi:id="e1e7e190-6c45-013d-d602-0800270c66d6" xmi:uuid="e1e7e230-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539787881072_615697_40494"/>
        <text>envelope:Envelope</text>
      </ownedElement>
      <ownedElement xmi:id="e2036e90-6c45-013d-d602-0800270c66d6" xmi:uuid="e2037170-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="Message.xmi#_18_4_1_2b2015d_1539787881072_615697_40494"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="137" height="290"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296182_469585_279985" xmi:uuid="e2081ec0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="524" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296198_102201_280006" xmi:uuid="e2092db0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="524" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296220_664001_280027" xmi:uuid="e2242680-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="524" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296239_479654_280048" xmi:uuid="e224b640-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Collection/Collection.xmi#_18_4_1_1b310459_1582018833164_475847_74277"/>
      <bounds x="524" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296259_367591_280069" xmi:uuid="e2331750-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="524" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296280_291391_280090" xmi:uuid="e233c620-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="524" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296301_350993_280111" xmi:uuid="e2345990-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="524" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296317_417066_280132" xmi:uuid="e243a500-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="524" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296333_313610_280153" xmi:uuid="e2460c00-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="524" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296417_231559_280175" xmi:uuid="e2581000-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="524" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296437_777443_280196" xmi:uuid="e258b1a0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="524" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446296452_419946_280217" xmi:uuid="e265c400-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="524" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_458677_401522" xmi:uuid="e265e240-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601384683_662100_251205"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296182_469585_279985"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="62"/>
      <waypoint x="182" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_871604_401525" xmi:uuid="e265eb90-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601384775_807860_251227"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296198_102201_280006"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="82"/>
      <waypoint x="182" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_67729_401528" xmi:uuid="e265f600-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601384861_195220_251249"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296220_664001_280027"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="102"/>
      <waypoint x="182" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_220761_401531" xmi:uuid="e265fea0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736238838_524890_68739"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296239_479654_280048"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="122"/>
      <waypoint x="182" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_719071_401534" xmi:uuid="e26606e0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601384971_658175_251292"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296259_367591_280069"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="142"/>
      <waypoint x="182" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_629419_401537" xmi:uuid="e2660db0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736242136_703420_68759"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296280_291391_280090"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="162"/>
      <waypoint x="182" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_154810_401540" xmi:uuid="e2661500-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736245560_681965_68779"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296301_350993_280111"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="182"/>
      <waypoint x="182" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_65711_401543" xmi:uuid="e2661bf0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601385105_148315_251356"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296317_417066_280132"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="202"/>
      <waypoint x="182" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_31380_401546" xmi:uuid="e2662200-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601385191_757351_251378"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296333_313610_280153"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="222"/>
      <waypoint x="182" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_979674_401549" xmi:uuid="e2662960-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1727446296337_794475_280171"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296417_231559_280175"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="242"/>
      <waypoint x="182" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_676631_401552" xmi:uuid="e26632b0-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_2b2015d_1662736235575_560525_68719"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296437_777443_280196"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="262"/>
      <waypoint x="182" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446496527_768331_401555" xmi:uuid="e2663f40-6c45-013d-d602-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="Message.xmi#_18_4_1_65b021e_1696601385296_687779_251421"/>
      <source xmi:idref="_18_4_1_65b021e_1727446296452_419946_280217"/>
      <target xmi:idref="_18_4_1_65b021e_1727446296165_42693_279951"/>
      <waypoint x="524" y="282"/>
      <waypoint x="182" y="282"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="527" height="360"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
