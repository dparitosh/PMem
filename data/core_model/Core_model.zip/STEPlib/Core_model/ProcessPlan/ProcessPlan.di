<?xml version="1.0" encoding="UTF-8"?>
<xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001" xmlns:sysml="http://www.omg.org/spec/SysML/20150709/SysML" xmlns:umldi="http://www.omg.org/spec/UML/20131001/UMLDI" xmlns:sysmldi="http://www.omg.org/spec/SysML/20161101/SysMLDI">
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703185515847_851896_439821" xmi:uuid="9a6c8ce0-915b-013c-715b-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703185515842_441016_439810"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1690208374657_743490_84512"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1703185521496_704290_440137" xmi:uuid="9c040a70-915b-013c-715b-0a5172f4a469">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1703185521491_888186_440126"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1690208374657_743490_84512"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1692800396036_375894_97406" xmi:uuid="dd098e40-24a2-013c-5c01-2bb9f4d923a9">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1692800395936_779254_97381"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1692800386825_521644_97378"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLBlockDefinitionDiagram xmi:id="_18_4_1_65b021e_1688564039982_681602_181484" xmi:uuid="e4c04390-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLClassDiagram xmi:idref="_18_4_1_65b021e_1688563977438_251410_164457"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1690208374657_743490_84512"/>
  </sysmldi:SysMLBlockDefinitionDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446314644_993443_293252" xmi:uuid="01f82b00-6c43-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446314637_361764_293241"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977037_997300_164264"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446318205_676010_294920" xmi:uuid="1fb103b0-6c44-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446318198_356156_294909"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977046_532260_164273"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446318701_718782_295574" xmi:uuid="275deb10-6c45-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446318694_3570_295563"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977062_967795_164287"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446319451_722493_296422" xmi:uuid="4aaa1880-6c43-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446319444_846143_296411"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977013_677082_164248"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446318475_603309_295253" xmi:uuid="7adeec40-6c43-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446318468_455336_295242"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977020_902017_164253"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446318512_341071_295331" xmi:uuid="821172a0-6c44-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446318505_358080_295320"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977023_906034_164255"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446314480_586085_293054" xmi:uuid="9e844900-6c42-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446314473_307833_293043"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977057_168128_164282"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446315838_388992_294405" xmi:uuid="a35e3100-6c44-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446315829_259770_294394"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977045_839711_164272"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446312656_35598_292795" xmi:uuid="ad4b2990-6c43-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446312649_503240_292784"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446318957_110129_295907" xmi:uuid="d030df40-6c44-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446318951_944091_295896"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977072_427965_164314"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446314922_671264_293585" xmi:uuid="d17e5900-6c42-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446314915_485536_293574"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977032_543000_164261"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564431261_947337_231963" xmi:uuid="e73aa000-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564038992_32996_181088"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977057_168128_164282"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564430656_93551_231287" xmi:uuid="ec4c08b0-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564037079_165873_180659"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977032_543000_164261"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564430783_752863_231410" xmi:uuid="ef3dc850-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564037480_513486_180751"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977037_997300_164264"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564429918_997242_230523" xmi:uuid="ef4cb710-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564034781_200657_180154"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977013_677082_164248"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564430139_887571_230756" xmi:uuid="ef5939a0-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564035441_598001_180298"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977020_902017_164253"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564430495_639151_231118" xmi:uuid="ef6468c0-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564036520_660277_180537"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564430955_960549_231612" xmi:uuid="ef6e51f0-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564038068_233215_180904"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977046_532260_164273"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564430267_866432_230895" xmi:uuid="f3658060-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564035912_103059_180386"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977023_906034_164255"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564430938_618532_231594" xmi:uuid="f373efe0-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564037722_109457_180852"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977045_839711_164272"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564431637_442894_232384" xmi:uuid="f37605c0-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564039850_399129_181317"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977072_427965_164314"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564431141_378150_231838" xmi:uuid="f37ca6b0-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564038511_416881_181013"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977054_525558_164279"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1688564431467_135349_232182" xmi:uuid="f73684a0-0d30-013c-5e2f-5b8e392dc4e5">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1688564039499_940186_181206"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977062_967795_164287"/>
  </sysmldi:SysMLParametricDiagram>
  <sysmldi:SysMLParametricDiagram xmi:id="_18_4_1_65b021e_1727446315435_646701_294100" xmi:uuid="fd811d50-6c44-013d-d608-0800270c66d6">
    <base_UMLCompositeStructureDiagram xmi:idref="_18_4_1_65b021e_1727446315427_529160_294089"/>
    <defaultNamespace href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977054_525558_164279"/>
  </sysmldi:SysMLParametricDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703185515842_441016_439810" xmi:uuid="9a6ac820-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1690208374657_743490_84512"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185515898_537000_439843" xmi:uuid="9a775c20-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977041_439008_164265"/>
      <ownedElement xmi:id="9a70ec40-915b-013c-715b-0a5172f4a469" xmi:uuid="9a70eda0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977041_439008_164265"/>
        <text>ProcessOperationInputOrOutputSelect</text>
      </ownedElement>
      <ownedElement xmi:id="9a740e10-915b-013c-715b-0a5172f4a469" xmi:uuid="9a740ff0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="9a7572a0-915b-013c-715b-0a5172f4a469" xmi:uuid="9a7573c0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1068" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185516863_13388_439902" xmi:uuid="9ad2c970-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyOccurrenceRelationship"/>
      <ownedElement xmi:id="9a7d5670-915b-013c-715b-0a5172f4a469" xmi:uuid="9a7d57a0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyOccurrenceRelationship"/>
        <text>AssemblyOccurrenceRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="9a830ba0-915b-013c-715b-0a5172f4a469" xmi:uuid="9a830e00-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185517899_326612_439958" xmi:uuid="9b22f480-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyViewRelationship"/>
      <ownedElement xmi:id="9ad8cbd0-915b-013c-715b-0a5172f4a469" xmi:uuid="9ad8cd00-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_AssemblyViewRelationship"/>
        <text>AssemblyViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="9ade8410-915b-013c-715b-0a5172f4a469" xmi:uuid="9ade8550-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="322" y="95" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185519321_26351_440020" xmi:uuid="9b8d9c00-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Occurrence"/>
      <ownedElement xmi:id="9b28e6d0-915b-013c-715b-0a5172f4a469" xmi:uuid="9b28e810-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Occurrence"/>
        <text>Occurrence</text>
      </ownedElement>
      <ownedElement xmi:id="9b2e9850-915b-013c-715b-0a5172f4a469" xmi:uuid="9b2e9990-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="579" y="95" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185521458_739997_440085" xmi:uuid="9c008f60-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="9b93d3b0-915b-013c-715b-0a5172f4a469" xmi:uuid="9b93d670-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="9b999480-915b-013c-715b-0a5172f4a469" xmi:uuid="9b9995c0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="836" y="95" width="237" height="33"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1128" height="175"/>
    <name>ProcessOperationInputOrOutputSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1703185521491_888186_440126" xmi:uuid="9c023360-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1690208374657_743490_84512"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185521524_635280_440158" xmi:uuid="9c0e3650-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977035_363837_164262"/>
      <ownedElement xmi:id="9c07aaa0-915b-013c-715b-0a5172f4a469" xmi:uuid="9c07abd0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977035_363837_164262"/>
        <text>ProcessOperationResourceAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="9c0ac4a0-915b-013c-715b-0a5172f4a469" xmi:uuid="9c0ac5d0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="9c0c3500-915b-013c-715b-0a5172f4a469" xmi:uuid="9c0c3890-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle>
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="45" y="55" width="1229" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185523842_181719_440232" xmi:uuid="9c726250-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
      <ownedElement xmi:id="9c190ab0-915b-013c-715b-0a5172f4a469" xmi:uuid="9c190d10-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../Breakdown/Breakdown.xmi#_BreakdownElement"/>
        <text>BreakdownElement</text>
      </ownedElement>
      <ownedElement xmi:id="9c1d01f0-915b-013c-715b-0a5172f4a469" xmi:uuid="9c1d0330-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="65" y="95" width="182" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185525897_389117_440295" xmi:uuid="9cac56e0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
      <ownedElement xmi:id="9c7b5500-915b-013c-715b-0a5172f4a469" xmi:uuid="9c7b5660-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../IndividualPart/IndividualPart.xmi#_IndividualPartView"/>
        <text>IndividualPartView</text>
      </ownedElement>
      <ownedElement xmi:id="9c7f0c90-915b-013c-715b-0a5172f4a469" xmi:uuid="9c7f0dd0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="267" y="95" width="194" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185527339_222705_440357" xmi:uuid="9d16a3e0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Occurrence"/>
      <ownedElement xmi:id="9cb253d0-915b-013c-715b-0a5172f4a469" xmi:uuid="9cb25510-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_Occurrence"/>
        <text>Occurrence</text>
      </ownedElement>
      <ownedElement xmi:id="9cb824f0-915b-013c-715b-0a5172f4a469" xmi:uuid="9cb82630-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="481" y="95" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185529524_850779_440422" xmi:uuid="9d89c060-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
      <ownedElement xmi:id="9d1c5800-915b-013c-715b-0a5172f4a469" xmi:uuid="9d1c5920-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartView"/>
        <text>PartView</text>
      </ownedElement>
      <ownedElement xmi:id="9d21e3b0-915b-013c-715b-0a5172f4a469" xmi:uuid="9d21e4f0-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="738" y="95" width="237" height="33"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1703185531842_569610_440489" xmi:uuid="9dd41850-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
      <ownedElement xmi:id="9d938440-915b-013c-715b-0a5172f4a469" xmi:uuid="9d938570-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RequirementManagement/RequirementManagement.xmi#_RequirementView"/>
        <text>RequirementView</text>
      </ownedElement>
      <ownedElement xmi:id="9d973ff0-915b-013c-715b-0a5172f4a469" xmi:uuid="9d974120-915b-013c-715b-0a5172f4a469" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="995" y="95" width="239" height="33"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1289" height="175"/>
    <name>ProcessOperationResourceAssignmentSelect</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1692800395936_779254_97381" xmi:uuid="dd083aa0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692800386825_521644_97378"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1692800396063_403959_97431" xmi:uuid="dd19b4f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692800396031_900229_97402"/>
      <ownedElement xmi:id="dd199f10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dd19a040-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692800396031_900229_97402"/>
        <text>makeFromRelationshipClass:ExternalOwlClass</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize=""/>
      <bounds x="84" y="77" width="642" height="61"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692800396063_532795_97432" xmi:uuid="dd29a4f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692800396033_540989_97403"/>
      <ownedElement xmi:id="dd296a60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dd296f50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692800396033_540989_97403"/>
        <text>processStateRelationshipClass:ExternalOwlClass</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize=""/>
      <bounds x="84" y="189" width="640" height="61"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692800396063_385691_97433" xmi:uuid="dd392930-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692800396034_40840_97404"/>
      <ownedElement xmi:id="dd390b90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dd390cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692800396034_40840_97404"/>
        <text>sameTimeMachiningRelationshipClass:ExternalOwlClass</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize=""/>
      <bounds x="84" y="301" width="637" height="61"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692800396063_755602_97434" xmi:uuid="dd486400-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692800396035_715745_97405"/>
      <ownedElement xmi:id="dd484360-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dd4844d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692800396035_715745_97405"/>
        <text>toolPartRelationshipClass:ExternalOwlClass</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize=""/>
      <bounds x="84" y="413" width="633" height="61"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692802485810_353878_99184" xmi:uuid="dd578c70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692802277076_518636_99060"/>
      <ownedElement xmi:id="dd576ef0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dd577160-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692802277076_518636_99060"/>
        <text>dummyProductOccurrence:Product_occurrence</text>
      </ownedElement>
      <bounds x="84" y="532" width="233" height="93"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692802485814_8305_99198" xmi:uuid="dd678730-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692802277073_489499_99057"/>
      <ownedElement xmi:id="dd677210-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dd677350-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692802277073_489499_99057"/>
        <text>dummyInitialViewDefinitionContext:Initial_view_definition_context</text>
      </ownedElement>
      <bounds x="294" y="658" width="371" height="93"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692802485818_135420_99212" xmi:uuid="dd829c80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692802277075_669017_99059"/>
      <ownedElement xmi:id="dd828480-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dd828620-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692802277075_669017_99059"/>
        <text>dummyPartVersion:Part_version</text>
      </ownedElement>
      <bounds x="84" y="658" width="161" height="81"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692802485822_220984_99226" xmi:uuid="dd925f60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692802277074_990597_99058"/>
      <ownedElement xmi:id="dd924760-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dd9249e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692802277074_990597_99058"/>
        <text>dummyPart:Part</text>
      </ownedElement>
      <bounds x="84" y="777" width="100" height="93"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="741" height="885"/>
    <name>ProcessPlan_Instances</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLClassDiagram xmi:id="_18_4_1_65b021e_1688563977438_251410_164457" xmi:uuid="e4bff040-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1690208374657_743490_84512"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_245269_364931" xmi:uuid="e4f6b380-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977013_677082_164248"/>
      <ownedElement xmi:id="e4c2fcd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4c2fe10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977013_677082_164248"/>
        <text>ProcessPlan</text>
      </ownedElement>
      <ownedElement xmi:id="e4c466e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4c467d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e4ec3c50-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4ec3d50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e4ec5140-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4ec51e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="e4ee0350-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4ee0450-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035065_846766_180251"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="e4efa770-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4efa860-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035071_399709_180252"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="e4f18de0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4f18ed0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035075_231139_180253"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="e4f31050-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4f31160-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035078_687650_180254"/>
          <text>VersionId</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="e4f356b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4f35760-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e4f36850-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4f368f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="e4f52930-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4f52a20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035082_680606_180255"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="e4f6a570-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4f6a9d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035086_189889_180256"/>
          <text>ProducedOutputs</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="28" y="231" width="185" height="124"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_226552_364932" xmi:uuid="e5207080-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977037_997300_164264"/>
      <ownedElement xmi:id="e4f85190-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4f85670-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977037_997300_164264"/>
        <text>ProcessPlanRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="e4f9cbb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e4f9cca0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e51d4b00-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e51d4bc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e51d5ce0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e51d5d80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="e5206a60-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5206b60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037570_535873_180804"/>
          <text>RelationType</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="28" y="56" width="220" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_834897_364939" xmi:uuid="e53cf7f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977032_543000_164261"/>
      <ownedElement xmi:id="e5220120-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5220210-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977032_543000_164261"/>
        <text>MakeFromRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="e5236430-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5236520-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e5380cf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5380df0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e53821e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5382280-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="e5399ab0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5399bb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037146_193767_180704"/>
          <text>Quantity</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="e539cff0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e539d090-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e539e170-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e539e210-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>values</text>
        </ownedElement>
        <ownedElement xmi:id="e53b6c50-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e53b6d50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037142_5694_180703"/>
          <text>Priority</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="595" y="770" width="128" height="80"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_638952_364940" xmi:uuid="e57535e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977023_906034_164255"/>
      <ownedElement xmi:id="e53eb550-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e53eb630-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977023_906034_164255"/>
        <text>ProcessOperationDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="e5400d90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5400f60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e56bb820-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e56bb920-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e56bca70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e56bcb10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="e56d56b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e56d57b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035174_854216_180281"/>
          <text>Name</text>
        </ownedElement>
        <ownedElement xmi:id="e56ed630-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e56ed720-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035183_39700_180286"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="e5704c10-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5704d00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036163_761762_180484"/>
          <text>Description</text>
        </ownedElement>
        <ownedElement xmi:id="e571cd80-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e571ce70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036168_93961_180485"/>
          <text>VersionId</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="e571fca0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e571fd40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e5720de0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5720e80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="e5738660-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5738760-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036172_160591_180486"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="e5752f20-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5753020-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036175_894541_180487"/>
          <text>ProcessType</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="567" y="231" width="185" height="124"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_126113_364941" xmi:uuid="e5a454f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977062_967795_164287"/>
      <ownedElement xmi:id="e5773420-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5773550-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977062_967795_164287"/>
        <text>ProcessOperationDefinitionRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="e578e8e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e578ea10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e5a110a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5a11150-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e5a126d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5a12770-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="e5a2ada0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5a2ae90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037661_744878_180836"/>
          <text>RelationType</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="560" y="56" width="220" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_106977_364948" xmi:uuid="e5c98050-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977020_902017_164253"/>
      <ownedElement xmi:id="e5a5fd40-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5a5fe40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977020_902017_164253"/>
        <text>ProcessOperationInputOrOutput</text>
      </ownedElement>
      <ownedElement xmi:id="e5a774e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5a775e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e5c2e3a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5c2e4a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e5c2f890-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5c2f970-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="e5c47bd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5c47f60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035504_51042_180343"/>
          <text>Description</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="e5c4c630-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5c4c6e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e5c4dad0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5c4db70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="e5c667d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5c668c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035508_943519_180344"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="e5c7edc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5c7eeb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035511_163399_180345"/>
          <text>Role</text>
        </ownedElement>
        <ownedElement xmi:id="e5c978c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5c97a30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035515_514140_180346"/>
          <text>ConcernedShapes</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="154" y="378" width="185" height="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_794817_364949" xmi:uuid="e5efcf00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
      <ownedElement xmi:id="e5cb1480-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5cb15e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
        <text>ProcessOperationOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="e5cc7b60-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5cc7c50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e5e93400-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5e93500-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e5e948f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5e94990-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="e5ead290-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5ead350-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036731_602394_180622"/>
          <text>Id</text>
        </ownedElement>
        <ownedElement xmi:id="e5ec65c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5ec66d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036735_974126_180623"/>
          <text>Description</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="e5eca6b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5eca760-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e5ecb810-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5ecb8b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="e5ee3b80-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5ee3c80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564034414_631087_180130"/>
          <text>ClassifiedAs</text>
        </ownedElement>
        <ownedElement xmi:id="e5efc470-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5efc570-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036739_399581_180624"/>
          <text>DefinedIn</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="280" y="231" width="185" height="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_813578_364953" xmi:uuid="e5f4af70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977041_439008_164265"/>
      <ownedElement xmi:id="e5f17cb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5f17db0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977041_439008_164265"/>
        <text>ProcessOperationInputOrOutputSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e5f2e7c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5f2e8a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e5f2fb30-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5f2fbd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="49" y="532" width="169" height="22"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_29832_364963" xmi:uuid="e6248900-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977046_532260_164273"/>
      <ownedElement xmi:id="e5f64c10-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5f64d00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977046_532260_164273"/>
        <text>ProcessOperationResourceAssignment</text>
      </ownedElement>
      <ownedElement xmi:id="e5f7b9e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e5f7bae0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e61e20a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e61e23d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e61e3840-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e61e38e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="e6229ab0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6229d00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038169_663785_180971"/>
          <text>Reason</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="e622d7b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e622da20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e622f660-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e622f6f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>values</text>
        </ownedElement>
        <ownedElement xmi:id="e62481b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6248290-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038173_696164_180972"/>
          <text>ReferenceTool</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="385" y="378" width="170" height="80"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_69639_364967" xmi:uuid="e6296400-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977035_363837_164262"/>
      <ownedElement xmi:id="e6262ec0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6262fa0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977035_363837_164262"/>
        <text>ProcessOperationResourceAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e6278c90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6278d70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e627a020-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e627a0c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="504" y="532" width="192" height="22"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_40054_364971" xmi:uuid="e66191b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977057_168128_164282"/>
      <ownedElement xmi:id="e62aee10-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e62aef80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977057_168128_164282"/>
        <text>ProcessOperationOccurrenceRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="e62c63c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e62c64c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e657ca90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e657cba0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e657dc50-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e657dd00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>parts</text>
        </ownedElement>
        <ownedElement xmi:id="e6596090-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6596190-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035579_430572_180365"/>
          <text>WaitingTime</text>
        </ownedElement>
        <ownedElement xmi:id="e65e1bc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e65e1cc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039104_382219_181152"/>
          <text>CycleTime</text>
        </ownedElement>
      </ownedElement>
      <ownedElement xmi:id="e65e6230-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e65e62e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e65e7660-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e65e7700-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>references</text>
        </ownedElement>
        <ownedElement xmi:id="e6618b70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6618c60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039092_78934_181149"/>
          <text>RelationType</text>
        </ownedElement>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="280" y="42" width="220" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_577660_364978" xmi:uuid="e66a53f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977045_839711_164272"/>
      <ownedElement xmi:id="e6631920-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6631a10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977045_839711_164272"/>
        <text>ProcessStateRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="e6647220-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6647320-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="98" y="770" width="114" height="22"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_651627_364979" xmi:uuid="e68184e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977072_427965_164314"/>
      <ownedElement xmi:id="e66bd8a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e66bd990-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977072_427965_164314"/>
        <text>ToolPartRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="e66d3de0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e66d3ee0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="385" y="770" width="100" height="22"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_956486_364980" xmi:uuid="e69bd3a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977054_525558_164279"/>
      <ownedElement xmi:id="e6832060-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6832150-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977054_525558_164279"/>
        <text>SameTimeMachiningRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="e6849760-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6849ae0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="133" y="987" width="217" height="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_661724_364981" xmi:uuid="e6bddb80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
      <ownedElement xmi:id="e6a948e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6a949d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_PartViewRelationship"/>
        <text>PartViewRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="e6ac9020-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6ac9130-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="343" y="671" width="152" height="65"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_353642_364984" xmi:uuid="e6ca4560-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_GeometricRepresentationRelationshipWithPlacementTransformation"/>
      <ownedElement xmi:id="c5e20f50-4103-013c-1d92-21143cc57b19" xmi:uuid="c5e21090-4103-013c-1d92-21143cc57b19" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_GeometricRepresentationRelationshipWithPlacementTransformation"/>
        <text>GeometricRepresentationRelationshipWithPlacementTransformation</text>
      </ownedElement>
      <ownedElement xmi:id="c5e49300-4103-013c-1d92-21143cc57b19" xmi:uuid="c5e49540-4103-013c-1d92-21143cc57b19" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="252" y="581" width="303" height="50"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_814213_364991" xmi:uuid="e6e294a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_OccurrenceRelationship"/>
      <ownedElement xmi:id="e6cdeae0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6cdebd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_OccurrenceRelationship"/>
        <text>OccurrenceRelationship</text>
      </ownedElement>
      <ownedElement xmi:id="e6d13db0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6d13ea0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <localStyle>
        <fillColor red="221" green="205" blue="158"/>
      </localStyle>
      <bounds x="112" y="869" width="110" height="22"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_485302_364993" xmi:uuid="e6ea5de0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLClassifierShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_TransformationSelect"/>
      <ownedElement xmi:id="e6e63310-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6e63410-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLNameLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_TransformationSelect"/>
        <text>TransformationSelect</text>
      </ownedElement>
      <ownedElement xmi:id="e6e97ce0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6e97df0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Block</text>
      </ownedElement>
      <ownedElement xmi:id="e6e992c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e6e99360-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLKeywordLabel">
        <text>Auxiliary</text>
      </ownedElement>
      <localStyle fontName="Times New Roman" fontSize="">
        <fillColor red="231" green="255" blue="255"/>
      </localStyle>
      <bounds x="315" y="882" width="98" height="22"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_548715_400570" xmi:uuid="e6efaeb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977068_136430_164292"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_826363_364933" xmi:uuid="e6ef74b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037574_88897_180805"/>
        <bounds x="116" y="206" width="35" height="12"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_386035_364934" xmi:uuid="e6ef91f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037574_88897_180805"/>
        <bounds x="157" y="206" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_23984_364935" xmi:uuid="e6efab00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039665_365910_181283"/>
        <bounds x="157" y="108" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_226552_364932"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_245269_364931"/>
      <waypoint x="154" y="105"/>
      <waypoint x="154" y="231"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_437920_400571" xmi:uuid="e6f2f870-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977070_627773_164306"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_682461_364936" xmi:uuid="e6f2bab0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037578_296517_180806"/>
        <bounds x="26" y="216" width="31" height="12"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_243949_364937" xmi:uuid="e6f2d870-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037578_296517_180806"/>
        <bounds x="63" y="216" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_999714_364938" xmi:uuid="e6f2f4d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039673_569798_181297"/>
        <bounds x="63" y="108" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_226552_364932"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_245269_364931"/>
      <waypoint x="60" y="105"/>
      <waypoint x="60" y="231"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_274023_400572" xmi:uuid="e6f63730-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977068_369294_164293"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_831552_364942" xmi:uuid="e6f5f9e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039580_836240_181258"/>
        <bounds x="582" y="216" width="31" height="12"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_669635_364943" xmi:uuid="e6f61680-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039580_836240_181258"/>
        <bounds x="619" y="216" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_633909_364944" xmi:uuid="e6f63360-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039666_260680_181284"/>
        <bounds x="619" y="108" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_126113_364941"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_638952_364940"/>
      <waypoint x="616" y="105"/>
      <waypoint x="616" y="231"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_331884_400573" xmi:uuid="e6f97550-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_285946_164256"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_885251_364945" xmi:uuid="e6f93bb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036276_909988_180516"/>
        <bounds x="659" y="206" width="35" height="12"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_19014_364946" xmi:uuid="e6f95790-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036276_909988_180516"/>
        <bounds x="700" y="206" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_293194_364947" xmi:uuid="e6f97190-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036276_610892_180515"/>
        <bounds x="700" y="108" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_126113_364941"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_638952_364940"/>
      <waypoint x="697" y="105"/>
      <waypoint x="697" y="231"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_524576_400574" xmi:uuid="e6fcb240-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977068_571809_164295"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_768881_364950" xmi:uuid="e6fc5df0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035523_690966_180348"/>
        <bounds x="265" y="346" width="40" height="12"/>
        <text>Operation</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_78235_364951" xmi:uuid="e6fc7940-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035523_690966_180348"/>
        <bounds x="311" y="346" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_229912_364952" xmi:uuid="e6fc9570-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039667_385204_181286"/>
        <bounds x="311" y="363" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_106977_364948"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_794817_364949"/>
      <waypoint x="308" y="378"/>
      <waypoint x="308" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_806144_400575" xmi:uuid="e6ffef20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977067_309496_164290"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_426427_364954" xmi:uuid="e6ff9210-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035519_573277_180347"/>
        <bounds x="177" y="517" width="34" height="12"/>
        <text>Element</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_319145_364955" xmi:uuid="e6ffc2f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035519_573277_180347"/>
        <bounds x="217" y="517" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_328285_364956" xmi:uuid="e6ffea70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039664_83976_181281"/>
        <bounds x="217" y="483" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_106977_364948"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_813578_364953"/>
      <waypoint x="214" y="480"/>
      <waypoint x="214" y="532"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_664850_400576" xmi:uuid="e70322c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977069_851922_164299"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_361640_364957" xmi:uuid="e702e6e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036742_388749_180625"/>
        <bounds x="522" y="262" width="42" height="12"/>
        <text>Definition</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_16290_364958" xmi:uuid="e7030210-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036742_388749_180625"/>
        <bounds x="542" y="280" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_564848_364959" xmi:uuid="e7031d30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039670_612117_181290"/>
        <bounds x="468" y="280" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_794817_364949"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_638952_364940"/>
      <waypoint x="465" y="277"/>
      <waypoint x="567" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_749140_400577" xmi:uuid="e7067790-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977057_272409_164280"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_252113_364960" xmi:uuid="e70631b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036746_63991_180626"/>
        <bounds x="226" y="262" width="22" height="12"/>
        <text>Plan</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_984182_364961" xmi:uuid="e70652a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036746_63991_180626"/>
        <bounds x="226" y="280" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_544703_364962" xmi:uuid="e7067150-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038646_569908_181073"/>
        <bounds x="255" y="280" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_794817_364949"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_245269_364931"/>
      <waypoint x="280" y="277"/>
      <waypoint x="213" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_749516_400578" xmi:uuid="e70a2d10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977032_402474_164260"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_206303_364964" xmi:uuid="e709e980-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036811_661036_180647"/>
        <bounds x="400" y="346" width="49" height="12"/>
        <text>AssignedTo</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_437493_364965" xmi:uuid="e70a08c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036811_661036_180647"/>
        <bounds x="455" y="346" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_709272_364966" xmi:uuid="e70a28b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036810_957696_180646"/>
        <bounds x="455" y="363" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_29832_364963"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_794817_364949"/>
      <waypoint x="452" y="378"/>
      <waypoint x="452" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_496811_400579" xmi:uuid="e70da350-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977061_162991_164284"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_361393_364968" xmi:uuid="e70d5fc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038160_241569_180969"/>
        <bounds x="473" y="517" width="74" height="12"/>
        <text>AssignedResource</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_236748_364969" xmi:uuid="e70d7e80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038160_241569_180969"/>
        <bounds x="553" y="517" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_175117_364970" xmi:uuid="e70d9a80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039204_545155_181178"/>
        <bounds x="553" y="461" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_29832_364963"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_69639_364967"/>
      <waypoint x="550" y="458"/>
      <waypoint x="550" y="532"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_717717_400580" xmi:uuid="e710ff90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977061_999353_164285"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_30857_364972" xmi:uuid="e710bdb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039100_527018_181151"/>
        <bounds x="299" y="216" width="31" height="12"/>
        <text>Related</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_116137_364973" xmi:uuid="e710d850-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039100_527018_181151"/>
        <bounds x="336" y="216" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_245176_364974" xmi:uuid="e710f740-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039205_856374_181179"/>
        <bounds x="336" y="136" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_40054_364971"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_794817_364949"/>
      <waypoint x="333" y="133"/>
      <waypoint x="333" y="231"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_764026_400581" xmi:uuid="e7146ff0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977072_620108_164313"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_598495_364975" xmi:uuid="e71427a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039096_687117_181150"/>
        <bounds x="375" y="206" width="35" height="12"/>
        <text>Relating</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_323339_364976" xmi:uuid="e7144510-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039096_687117_181150"/>
        <bounds x="416" y="206" width="22" height="12"/>
        <text>1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_169306_364977" xmi:uuid="e7146710-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039677_836655_181304"/>
        <bounds x="416" y="136" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_40054_364971"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_794817_364949"/>
      <waypoint x="413" y="133"/>
      <waypoint x="413" y="231"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_500864_400582" xmi:uuid="e7196fe0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036814_799888_180648"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_661724_364981"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_834897_364939"/>
      <waypoint x="697" y="753"/>
      <waypoint x="697" y="770"/>
      <waypoint x="399" y="736"/>
      <waypoint x="399" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_306648_400583" xmi:uuid="e71e8c80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037672_264463_180841"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_661724_364981"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_577660_364978"/>
      <waypoint x="155" y="753"/>
      <waypoint x="155" y="770"/>
      <waypoint x="399" y="736"/>
      <waypoint x="399" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_227484_400584" xmi:uuid="e7238e10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039677_199414_181305"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_661724_364981"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_651627_364979"/>
      <waypoint x="459" y="753"/>
      <waypoint x="459" y="770"/>
      <waypoint x="399" y="736"/>
      <waypoint x="399" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_947333_400585" xmi:uuid="e726bd00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977057_291700_164281"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_636471_364985" xmi:uuid="e7267be0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035527_664209_180349"/>
        <bounds x="267" y="566" width="42" height="12"/>
        <text>Placement</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_286972_364986" xmi:uuid="e7269d60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035527_664209_180349"/>
        <bounds x="315" y="566" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_328142_364987" xmi:uuid="e726b9a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038647_389588_181074"/>
        <bounds x="315" y="483" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_106977_364948"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_353642_364984"/>
      <waypoint x="312" y="480"/>
      <waypoint x="312" y="581"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_266572_400586" xmi:uuid="e729fc80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977070_359331_164307"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_235443_364988" xmi:uuid="e729bd40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038164_360264_180970"/>
        <bounds x="379" y="566" width="42" height="12"/>
        <text>Placement</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_471059_364989" xmi:uuid="e729deb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038164_360264_180970"/>
        <bounds x="427" y="566" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025803_682418_364990" xmi:uuid="e729f920-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039674_684917_181298"/>
        <bounds x="427" y="461" width="22" height="12"/>
        <text>0..*</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_29832_364963"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_353642_364984"/>
      <waypoint x="424" y="458"/>
      <waypoint x="424" y="581"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_430788_400587" xmi:uuid="e72f07c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038277_151180_181001"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_814213_364991"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025803_956486_364980"/>
      <waypoint x="172" y="891"/>
      <waypoint x="172" y="987"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_728933_400588" xmi:uuid="e734bab0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977070_237571_164305"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_158567_364994" xmi:uuid="e7347050-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038574_530482_181055"/>
        <bounds x="295" y="907" width="42" height="12"/>
        <text>Placement</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_880965_364995" xmi:uuid="e7349580-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038574_530482_181055"/>
        <bounds x="343" y="907" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_912436_364996" xmi:uuid="e734b610-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039673_123149_181296"/>
        <bounds x="343" y="972" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_956486_364980"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_485302_364993"/>
      <waypoint x="340" y="987"/>
      <waypoint x="340" y="904"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026805_551620_400589" xmi:uuid="e73a1470-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977053_400103_164278"/>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_548867_364997" xmi:uuid="e739d660-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLAssociationEndLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038273_405548_181000"/>
        <bounds x="361" y="867" width="42" height="12"/>
        <text>Placement</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_57940_364998" xmi:uuid="e739f370-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038273_405548_181000"/>
        <bounds x="409" y="867" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025804_440099_364999" xmi:uuid="e73a10e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038273_139250_180999"/>
        <bounds x="416" y="800" width="22" height="12"/>
        <text>0..1</text>
      </ownedElement>
      <source xmi:idref="_18_4_1_65b021e_1688566025803_651627_364979"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025804_485302_364993"/>
      <waypoint x="406" y="792"/>
      <waypoint x="406" y="882"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="796" height="1051"/>
    <name>ProcessPlan</name>
    <resolution>60</resolution>
  </umldi:UMLClassDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446314637_361764_293241" xmi:uuid="01f6cef0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977037_997300_164264"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314663_718659_293273" xmi:uuid="02fde3f0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037631_700570_180820"/>
      <ownedElement xmi:id="02dec350-6c43-013d-d608-0800270c66d6" xmi:uuid="02dec440-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037631_700570_180820"/>
        <text>process_plan_relationship:Process_plan_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="02fdd000-6c43-013d-d608-0800270c66d6" xmi:uuid="02fdd0b0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037631_700570_180820"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="320" height="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314680_285773_293307" xmi:uuid="0310a350-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="713" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314691_600659_293322" xmi:uuid="0311d0f0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="713" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314707_87640_293337" xmi:uuid="0343ff20-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="713" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314718_797126_293352" xmi:uuid="035475d0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="713" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314732_490218_293367" xmi:uuid="035586b0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="713" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314742_817304_293382" xmi:uuid="036db9b0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="713" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314758_836493_293397" xmi:uuid="0382ced0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="713" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314773_134425_293412" xmi:uuid="039f1510-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="713" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314788_161261_293427" xmi:uuid="03a00920-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="713" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314798_996463_293442" xmi:uuid="03b7e0b0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="713" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314811_717836_293457" xmi:uuid="03d2e710-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="713" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314827_654949_293472" xmi:uuid="03d3de50-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="713" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314843_697618_293487" xmi:uuid="03f1b0c0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="713" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314855_641465_293502" xmi:uuid="03f29f90-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="713" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314867_242558_293517" xmi:uuid="040dbe90-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="713" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314882_433613_293532" xmi:uuid="0422cf70-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="713" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314897_306042_293547" xmi:uuid="0423e460-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="713" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314908_730278_293562" xmi:uuid="0424d440-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="713" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_715485_403688" xmi:uuid="0424ef40-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439647_517778_269084"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314680_285773_293307"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="62"/>
      <waypoint x="365" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_550662_403691" xmi:uuid="0424f820-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439737_571044_269100"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314691_600659_293322"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="82"/>
      <waypoint x="365" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_892881_403694" xmi:uuid="0424ff00-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439817_493446_269116"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314707_87640_293337"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="102"/>
      <waypoint x="365" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_982563_403697" xmi:uuid="042508d0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439901_816026_269132"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314718_797126_293352"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="122"/>
      <waypoint x="365" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_281572_403700" xmi:uuid="042512c0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439980_946337_269148"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314732_490218_293367"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="142"/>
      <waypoint x="365" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_131325_403703" xmi:uuid="042520e0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037558_598706_180799"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314742_817304_293382"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="162"/>
      <waypoint x="365" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_93197_403706" xmi:uuid="04252930-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440071_444536_269179"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314758_836493_293397"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="182"/>
      <waypoint x="365" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_141818_403709" xmi:uuid="04253060-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037557_67166_180798"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314773_134425_293412"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="202"/>
      <waypoint x="365" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_584083_403712" xmi:uuid="042537d0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440165_851316_269210"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314788_161261_293427"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="222"/>
      <waypoint x="365" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_336280_403715" xmi:uuid="04253f50-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440247_878044_269226"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314798_996463_293442"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="242"/>
      <waypoint x="365" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_460153_403718" xmi:uuid="04255620-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440325_828110_269242"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314811_717836_293457"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="262"/>
      <waypoint x="365" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_695478_403721" xmi:uuid="04256230-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440408_674156_269258"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314827_654949_293472"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="282"/>
      <waypoint x="365" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_170962_403724" xmi:uuid="04256b30-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440491_777663_269274"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314843_697618_293487"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="302"/>
      <waypoint x="365" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_67501_403727" xmi:uuid="042574d0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440577_954162_269290"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314855_641465_293502"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="322"/>
      <waypoint x="365" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_262721_403730" xmi:uuid="04257db0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440656_792360_269306"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314867_242558_293517"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="342"/>
      <waypoint x="365" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_209453_403733" xmi:uuid="04258620-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440736_727166_269322"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314882_433613_293532"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="362"/>
      <waypoint x="365" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499685_992356_403736" xmi:uuid="04258ec0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440821_366627_269338"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314897_306042_293547"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="382"/>
      <waypoint x="365" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499686_675055_403739" xmi:uuid="04259690-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601440905_572771_269354"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314908_730278_293562"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314663_718659_293273"/>
      <waypoint x="713" y="402"/>
      <waypoint x="365" y="402"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="716" height="480"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446318198_356156_294909" xmi:uuid="1f957d90-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977046_532260_164273"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318226_791429_294941" xmi:uuid="205ce060-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038176_420768_180973"/>
      <ownedElement xmi:id="205665e0-6c44-013d-d608-0800270c66d6" xmi:uuid="20566690-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038176_420768_180973"/>
        <text>process_operation_resource_assignment:Process_operation_resource_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="205cce50-6c44-013d-d608-0800270c66d6" xmi:uuid="205ccf20-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038176_420768_180973"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="478" height="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318242_425846_294975" xmi:uuid="205dcd20-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="923" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318253_946450_294990" xmi:uuid="208c7620-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="923" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318267_168809_295005" xmi:uuid="20aab1d0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="923" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318277_182144_295020" xmi:uuid="20ab9550-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="923" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318287_522043_295035" xmi:uuid="20bda640-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="923" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318301_949666_295050" xmi:uuid="20d8d810-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="923" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318312_582109_295065" xmi:uuid="20d9de10-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="923" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318326_606818_295080" xmi:uuid="20dade60-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="923" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318340_686194_295095" xmi:uuid="210368c0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="923" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318354_507945_295110" xmi:uuid="211b5e30-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="923" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318367_325183_295125" xmi:uuid="211c5490-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="923" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318383_145929_295140" xmi:uuid="2130d820-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="923" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318400_895600_295155" xmi:uuid="2131e660-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="923" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318411_351523_295170" xmi:uuid="21518380-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="923" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318423_925061_295185" xmi:uuid="21666770-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="923" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318438_66103_295200" xmi:uuid="21756a00-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="923" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318452_28894_295215" xmi:uuid="21765d70-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="923" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318462_436081_295230" xmi:uuid="218fc9b0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="923" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_485901_403970" xmi:uuid="218fd790-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427415_959414_266184"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318242_425846_294975"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="62"/>
      <waypoint x="523" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_365054_403973" xmi:uuid="218fdf60-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427503_242490_266200"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318253_946450_294990"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="82"/>
      <waypoint x="523" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_368150_403976" xmi:uuid="218fe4c0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427578_97830_266216"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318267_168809_295005"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="102"/>
      <waypoint x="523" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_592859_403979" xmi:uuid="218fe970-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427662_136870_266232"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318277_182144_295020"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="122"/>
      <waypoint x="523" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_600058_403982" xmi:uuid="218fef30-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427741_878710_266248"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318287_522043_295035"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="142"/>
      <waypoint x="523" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_613641_403985" xmi:uuid="218ff450-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427820_361712_266264"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318301_949666_295050"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="162"/>
      <waypoint x="523" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_758893_403988" xmi:uuid="218ffa10-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427902_446514_266280"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318312_582109_295065"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="182"/>
      <waypoint x="523" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_670225_403991" xmi:uuid="218ffe40-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427980_310440_266296"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318326_606818_295080"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="202"/>
      <waypoint x="523" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_902473_403994" xmi:uuid="219004a0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428062_633326_266312"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318340_686194_295095"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="222"/>
      <waypoint x="523" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_943953_403997" xmi:uuid="219008d0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428144_974745_266328"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318354_507945_295110"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="242"/>
      <waypoint x="523" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_778718_404000" xmi:uuid="21900e50-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428225_842645_266344"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318367_325183_295125"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="262"/>
      <waypoint x="523" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_833734_404003" xmi:uuid="219013e0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428307_953382_266360"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318383_145929_295140"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="282"/>
      <waypoint x="523" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_709292_404006" xmi:uuid="21901870-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428395_183175_266376"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318400_895600_295155"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="302"/>
      <waypoint x="523" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_501672_404009" xmi:uuid="21901de0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428481_710952_266392"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318411_351523_295170"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="322"/>
      <waypoint x="523" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_523690_404012" xmi:uuid="219021f0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428569_852613_266408"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318423_925061_295185"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="342"/>
      <waypoint x="523" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_962291_404015" xmi:uuid="21902830-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428656_86693_266424"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318438_66103_295200"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="362"/>
      <waypoint x="523" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_223359_404018" xmi:uuid="21902c80-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428742_771437_266440"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318452_28894_295215"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="382"/>
      <waypoint x="523" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499719_627691_404021" xmi:uuid="21903200-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428823_53272_266456"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318462_436081_295230"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318226_791429_294941"/>
      <waypoint x="923" y="402"/>
      <waypoint x="523" y="402"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="926" height="480"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446318694_3570_295563" xmi:uuid="274d6680-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977062_967795_164287"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318718_267665_295595" xmi:uuid="281cb080-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039584_82067_181259"/>
      <ownedElement xmi:id="27ed74c0-6c45-013d-d608-0800270c66d6" xmi:uuid="27ed76b0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039584_82067_181259"/>
        <text>process_operation_definition_relationship:Process_operation_definition_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="280f3480-6c45-013d-d608-0800270c66d6" xmi:uuid="280f3580-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039584_82067_181259"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="490" height="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318734_783362_295629" xmi:uuid="2828aa40-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="916" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318743_116494_295644" xmi:uuid="283ac850-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="916" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318758_898406_295659" xmi:uuid="283bc640-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="916" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318768_3504_295674" xmi:uuid="284c4130-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="916" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318782_436757_295689" xmi:uuid="28721710-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="916" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318790_81326_295704" xmi:uuid="28847e70-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="916" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318804_566870_295719" xmi:uuid="28a53d00-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="916" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318818_798512_295734" xmi:uuid="28bc4b40-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="916" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318831_18637_295749" xmi:uuid="28bd6890-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="916" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318840_703270_295764" xmi:uuid="28d04720-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="916" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318852_115676_295779" xmi:uuid="28d14ef0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="916" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318868_441876_295794" xmi:uuid="28d253f0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="916" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318883_47314_295809" xmi:uuid="28d34980-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="916" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318894_522854_295824" xmi:uuid="28d43af0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="916" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318905_578529_295839" xmi:uuid="291d2d90-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="916" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318919_41371_295854" xmi:uuid="291e50d0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="916" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318933_546703_295869" xmi:uuid="29200fe0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="916" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318944_21585_295884" xmi:uuid="296e4e40-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="916" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_299994_404063" xmi:uuid="296e76b0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438211_38204_268734"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318734_783362_295629"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="62"/>
      <waypoint x="535" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_529381_404066" xmi:uuid="29729c60-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438299_405463_268750"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318743_116494_295644"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="82"/>
      <waypoint x="535" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_821403_404069" xmi:uuid="2972bbd0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438381_760059_268766"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318758_898406_295659"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="102"/>
      <waypoint x="535" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_225671_404072" xmi:uuid="2972df00-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438465_420219_268782"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318768_3504_295674"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="122"/>
      <waypoint x="535" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_156205_404075" xmi:uuid="2972e690-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438545_37224_268798"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318782_436757_295689"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="142"/>
      <waypoint x="535" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_207912_404078" xmi:uuid="2972f710-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438626_435045_268814"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318790_81326_295704"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="162"/>
      <waypoint x="535" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_756550_404081" xmi:uuid="297307e0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438702_828877_268830"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318804_566870_295719"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="182"/>
      <waypoint x="535" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_228106_404084" xmi:uuid="2976a630-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039574_752326_181253"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318818_798512_295734"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="202"/>
      <waypoint x="535" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_946058_404087" xmi:uuid="2976bba0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438800_230690_268861"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318831_18637_295749"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="222"/>
      <waypoint x="535" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_701696_404090" xmi:uuid="2976c8b0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438882_511878_268877"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318840_703270_295764"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="242"/>
      <waypoint x="535" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_584910_404093" xmi:uuid="2976d350-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438959_64644_268893"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318852_115676_295779"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="262"/>
      <waypoint x="535" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_837546_404096" xmi:uuid="2976e0b0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439041_325037_268909"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318868_441876_295794"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="282"/>
      <waypoint x="535" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_937616_404099" xmi:uuid="2976ee30-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439125_463127_268925"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318883_47314_295809"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="302"/>
      <waypoint x="535" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_178434_404102" xmi:uuid="2976fde0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439207_340551_268941"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318894_522854_295824"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="322"/>
      <waypoint x="535" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_175873_404105" xmi:uuid="29770cb0-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439287_690723_268957"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318905_578529_295839"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="342"/>
      <waypoint x="535" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_948236_404108" xmi:uuid="29771a00-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439367_21691_268973"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318919_41371_295854"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="362"/>
      <waypoint x="535" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_779708_404111" xmi:uuid="29772760-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439452_741662_268989"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318933_546703_295869"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="382"/>
      <waypoint x="535" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499730_107392_404114" xmi:uuid="29773560-6c45-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601439535_7174_269005"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318944_21585_295884"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318718_267665_295595"/>
      <waypoint x="916" y="402"/>
      <waypoint x="535" y="402"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="919" height="480"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446319444_846143_296411" xmi:uuid="4a91f2b0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977013_677082_164248"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319468_266717_296443" xmi:uuid="4b8211e0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035090_810082_180257"/>
      <ownedElement xmi:id="4b4f0500-6c43-013d-d608-0800270c66d6" xmi:uuid="4b4f0650-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035090_810082_180257"/>
        <text>process_plan:Process_plan</text>
      </ownedElement>
      <ownedElement xmi:id="4b6e92b0-6c43-013d-d608-0800270c66d6" xmi:uuid="4b6e9380-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035090_810082_180257"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="182" height="350"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319484_615233_296477" xmi:uuid="4b84a500-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="629" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319498_356741_296492" xmi:uuid="4b859cc0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="629" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319514_102416_296507" xmi:uuid="4b882960-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="629" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319524_765165_296522" xmi:uuid="4b8b0cf0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="629" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319538_79672_296537" xmi:uuid="4b8dd220-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="629" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319553_304956_296552" xmi:uuid="4b8ecbd0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="629" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319567_296846_296567" xmi:uuid="4b9c5c40-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="629" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319580_848170_296582" xmi:uuid="4bb62e60-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="629" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319591_978625_296597" xmi:uuid="4bccbde0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="629" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319602_206877_296612" xmi:uuid="4beb7650-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="629" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319617_270735_296627" xmi:uuid="4beea9b0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="629" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319630_964644_296642" xmi:uuid="4bf78b20-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="629" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319641_423528_296657" xmi:uuid="4c0fd260-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="629" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319650_182977_296672" xmi:uuid="4c234a30-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="629" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319660_203642_296687" xmi:uuid="4c243f40-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="629" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_610911_404207" xmi:uuid="4c245410-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442032_155721_269688"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319484_615233_296477"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="62"/>
      <waypoint x="227" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_356575_404210" xmi:uuid="4c245af0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442126_512020_269704"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319498_356741_296492"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="82"/>
      <waypoint x="227" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_230467_404213" xmi:uuid="4c246270-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442216_570411_269720"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319514_102416_296507"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="102"/>
      <waypoint x="227" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_565939_404216" xmi:uuid="4c246a80-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442296_28556_269736"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319524_765165_296522"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="122"/>
      <waypoint x="227" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_940575_404219" xmi:uuid="4c247240-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442374_491384_269752"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319538_79672_296537"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="142"/>
      <waypoint x="227" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_877804_404222" xmi:uuid="4c2479c0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442457_660_269768"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319553_304956_296552"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="162"/>
      <waypoint x="227" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_386691_404225" xmi:uuid="4c2480e0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442539_755961_269784"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319567_296846_296567"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="182"/>
      <waypoint x="227" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_498846_404228" xmi:uuid="4c2488b0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442622_527067_269800"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319580_848170_296582"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="202"/>
      <waypoint x="227" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_740665_404231" xmi:uuid="4c248fc0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442702_257741_269816"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319591_978625_296597"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="222"/>
      <waypoint x="227" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_891583_404234" xmi:uuid="4c249660-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442782_360935_269832"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319602_206877_296612"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="242"/>
      <waypoint x="227" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_232044_404237" xmi:uuid="4c249d50-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442862_205388_269848"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319617_270735_296627"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="262"/>
      <waypoint x="227" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_644397_404240" xmi:uuid="4c24a550-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601442945_293635_269864"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319630_964644_296642"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="282"/>
      <waypoint x="227" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_711345_404243" xmi:uuid="4c24ac50-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601443029_631425_269880"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319641_423528_296657"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="302"/>
      <waypoint x="227" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_513293_404246" xmi:uuid="4c39df00-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601443107_788539_269896"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319650_182977_296672"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="322"/>
      <waypoint x="227" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499746_554915_404249" xmi:uuid="4c39eaa0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601443183_151019_269912"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319660_203642_296687"/>
      <target xmi:idref="_18_4_1_65b021e_1727446319468_266717_296443"/>
      <waypoint x="629" y="342"/>
      <waypoint x="227" y="342"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="632" height="420"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446318468_455336_295242" xmi:uuid="7acb4180-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977020_902017_164253"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318491_196529_295274" xmi:uuid="7bcab670-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035530_835013_180350"/>
      <ownedElement xmi:id="7ba32770-6c43-013d-d608-0800270c66d6" xmi:uuid="7ba32950-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035530_835013_180350"/>
        <text>process_operation_input_or_output:Process_operation_input_or_output</text>
      </ownedElement>
      <ownedElement xmi:id="7bc6bc10-6c43-013d-d608-0800270c66d6" xmi:uuid="7bc6beb0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035530_835013_180350"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="424" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318500_925076_295308" xmi:uuid="7bdf1960-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569585631648_131692_86657"/>
      <bounds x="853" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499725_303425_404024" xmi:uuid="7bdf33c0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035503_805466_180340"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318500_925076_295308"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318491_196529_295274"/>
      <waypoint x="853" y="62"/>
      <waypoint x="469" y="62"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="856" height="140"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446318505_358080_295320" xmi:uuid="818c0670-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977023_906034_164255"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318532_2409_295352" xmi:uuid="848c1da0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036179_6515_180488"/>
      <ownedElement xmi:id="83fa3160-6c44-013d-d608-0800270c66d6" xmi:uuid="8401da60-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036179_6515_180488"/>
        <text>process_operation_definition:Process_operation_definition</text>
      </ownedElement>
      <ownedElement xmi:id="848c0220-6c44-013d-d608-0800270c66d6" xmi:uuid="848c0360-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036179_6515_180488"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="352" height="290"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318549_576267_295386" xmi:uuid="84a3bdd0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="769" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318563_692797_295401" xmi:uuid="84fb0c70-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="769" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318574_957992_295416" xmi:uuid="863cdd70-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="769" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318588_675168_295431" xmi:uuid="873f9940-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="769" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318602_97292_295446" xmi:uuid="8832cea0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="769" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318614_170483_295461" xmi:uuid="88a55920-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="769" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318626_967010_295476" xmi:uuid="893f9d20-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="769" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318638_471373_295491" xmi:uuid="89f9a8d0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="769" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318653_989038_295506" xmi:uuid="8a1d8940-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="769" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318667_277432_295521" xmi:uuid="8adcf020-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="769" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318677_959591_295536" xmi:uuid="8b25b200-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1585941513390_815975_87089"/>
      <bounds x="769" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318688_792207_295551" xmi:uuid="8b91cd10-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="769" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_617985_404027" xmi:uuid="8b9d5970-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441016_455568_269433"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318549_576267_295386"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="62"/>
      <waypoint x="397" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_950934_404030" xmi:uuid="8b9d6200-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441105_552311_269449"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318563_692797_295401"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="82"/>
      <waypoint x="397" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_614557_404033" xmi:uuid="8b9d6a20-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441191_290162_269465"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318574_957992_295416"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="102"/>
      <waypoint x="397" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_506324_404036" xmi:uuid="8b9d7650-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441273_176067_269481"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318588_675168_295431"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="122"/>
      <waypoint x="397" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_742091_404039" xmi:uuid="8b9d81e0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441355_429133_269497"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318602_97292_295446"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="142"/>
      <waypoint x="397" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_436391_404042" xmi:uuid="8b9d8a00-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441435_726262_269513"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318614_170483_295461"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="162"/>
      <waypoint x="397" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_192224_404045" xmi:uuid="8b9d9530-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441516_45446_269529"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318626_967010_295476"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="182"/>
      <waypoint x="397" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_674113_404048" xmi:uuid="8b9d9be0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441597_106713_269545"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318638_471373_295491"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="202"/>
      <waypoint x="397" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_684710_404051" xmi:uuid="8b9da700-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441675_910732_269561"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318653_989038_295506"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="222"/>
      <waypoint x="397" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_69487_404054" xmi:uuid="8b9db9c0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441754_875078_269577"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318667_277432_295521"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="242"/>
      <waypoint x="397" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_648352_404057" xmi:uuid="8b9dcaa0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441836_68143_269593"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318677_959591_295536"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="262"/>
      <waypoint x="397" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499726_136499_404060" xmi:uuid="8b9ddc20-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601441915_40713_269609"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318688_792207_295551"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318532_2409_295352"/>
      <waypoint x="769" y="282"/>
      <waypoint x="397" y="282"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="772" height="360"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446314473_307833_293043" xmi:uuid="9e689a40-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977057_168128_164282"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314498_661482_293075" xmi:uuid="9fa427c0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039109_1034_181153"/>
      <ownedElement xmi:id="9f4c4fe0-6c42-013d-d608-0800270c66d6" xmi:uuid="9f4c5090-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039109_1034_181153"/>
        <text>process_operation_occurrence_relationship:Process_operation_occurrence_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="9fa41470-6c42-013d-d608-0800270c66d6" xmi:uuid="9fa41530-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039109_1034_181153"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="506" height="230"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314515_592305_293109" xmi:uuid="9fa50fe0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="965" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314530_267607_293124" xmi:uuid="9fc92a50-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="965" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314544_300909_293139" xmi:uuid="9fca5b50-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="965" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314552_58030_293154" xmi:uuid="9fcb5130-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="965" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314566_499842_293169" xmi:uuid="a008e990-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="965" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314581_56873_293184" xmi:uuid="a00ba800-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="965" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314597_722701_293199" xmi:uuid="a032f980-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="965" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314614_883870_293214" xmi:uuid="a04c4b60-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="965" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314629_236414_293229" xmi:uuid="a04d6550-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="965" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499682_218247_403661" xmi:uuid="a04d7730-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431423_53089_267156"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314515_592305_293109"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314498_661482_293075"/>
      <waypoint x="965" y="62"/>
      <waypoint x="551" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499682_73740_403664" xmi:uuid="a04d7f70-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431512_331157_267172"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314530_267607_293124"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314498_661482_293075"/>
      <waypoint x="965" y="82"/>
      <waypoint x="551" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499682_268430_403667" xmi:uuid="a04d8910-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431595_865636_267188"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314544_300909_293139"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314498_661482_293075"/>
      <waypoint x="965" y="102"/>
      <waypoint x="551" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499682_554432_403670" xmi:uuid="a04d90a0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039082_3125_181144"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314552_58030_293154"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314498_661482_293075"/>
      <waypoint x="965" y="122"/>
      <waypoint x="551" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499682_687226_403673" xmi:uuid="a04d96f0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039081_652670_181143"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314566_499842_293169"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314498_661482_293075"/>
      <waypoint x="965" y="142"/>
      <waypoint x="551" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499682_106510_403676" xmi:uuid="a04d9e10-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431703_913984_267234"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314581_56873_293184"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314498_661482_293075"/>
      <waypoint x="965" y="162"/>
      <waypoint x="551" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499682_855929_403679" xmi:uuid="a04da4f0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431787_743094_267250"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314597_722701_293199"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314498_661482_293075"/>
      <waypoint x="965" y="182"/>
      <waypoint x="551" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499682_93518_403682" xmi:uuid="a04dab30-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431880_265713_267266"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314614_883870_293214"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314498_661482_293075"/>
      <waypoint x="965" y="202"/>
      <waypoint x="551" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499682_389750_403685" xmi:uuid="a04db250-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431968_609151_267282"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314629_236414_293229"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314498_661482_293075"/>
      <waypoint x="965" y="222"/>
      <waypoint x="551" y="222"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="968" height="300"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446315829_259770_294394" xmi:uuid="a35ce2f0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977045_839711_164272"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315864_223269_294426" xmi:uuid="a461cfe0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037760_973193_180877"/>
      <ownedElement xmi:id="a429e770-6c44-013d-d608-0800270c66d6" xmi:uuid="a429e850-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037760_973193_180877"/>
        <text>process_state_relationship:Process_state_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="a461a840-6c44-013d-d608-0800270c66d6" xmi:uuid="a461a900-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037760_973193_180877"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="326" height="650"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315886_571899_294460" xmi:uuid="a462d970-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="776" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315901_275911_294475" xmi:uuid="a474c9b0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="776" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315913_477876_294490" xmi:uuid="a48ce0b0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_6b1022a_1570727524445_1920_44551"/>
      <bounds x="776" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315932_52098_294505" xmi:uuid="a49ebfc0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="776" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315943_628818_294520" xmi:uuid="a4a01be0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="776" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315955_479810_294535" xmi:uuid="a4bd5760-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="776" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315968_975042_294550" xmi:uuid="a4d8ee60-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="776" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315978_697025_294565" xmi:uuid="a4e40960-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973058873_539759_54381"/>
      <bounds x="776" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315990_13249_294580" xmi:uuid="a4e88e60-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973091565_761824_54391"/>
      <bounds x="776" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316010_414162_294595" xmi:uuid="a4ff45c0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="776" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316024_854858_294610" xmi:uuid="a51976f0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="776" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316117_43535_294626" xmi:uuid="a5271330-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="776" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316138_826904_294641" xmi:uuid="a538d370-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="776" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316159_690735_294656" xmi:uuid="a539d400-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="776" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316177_150534_294671" xmi:uuid="a554f290-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="776" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316189_256467_294686" xmi:uuid="a56415f0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="776" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316205_677542_294701" xmi:uuid="a579f330-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="776" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316225_559596_294716" xmi:uuid="a5844880-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="776" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316244_863169_294731" xmi:uuid="a5a6fef0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="776" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316257_29286_294746" xmi:uuid="a5b46990-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="776" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316271_415474_294761" xmi:uuid="a5b56810-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="776" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316287_895857_294776" xmi:uuid="a5c423b0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="776" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316305_276032_294791" xmi:uuid="a5dc0480-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="776" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446316318_285413_294806" xmi:uuid="a5dd05c0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
      <bounds x="776" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318088_857818_294821" xmi:uuid="a5de09b0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
      <bounds x="776" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318098_980939_294836" xmi:uuid="a603e390-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="776" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318108_80546_294851" xmi:uuid="a604e380-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="776" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318117_298987_294866" xmi:uuid="a61ce1a0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="776" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318182_840841_294882" xmi:uuid="a63c5790-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="776" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318191_853601_294897" xmi:uuid="a63d4650-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="776" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499707_962225_403880" xmi:uuid="a63d5480-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435730_906910_268191"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315886_571899_294460"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="62"/>
      <waypoint x="371" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_363716_403883" xmi:uuid="a63d5bf0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435817_843300_268207"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315901_275911_294475"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="82"/>
      <waypoint x="371" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_520339_403886" xmi:uuid="a65761a0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435893_408968_268223"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315913_477876_294490"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="102"/>
      <waypoint x="371" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_854421_403889" xmi:uuid="a6576a00-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436023_162270_268239"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315932_52098_294505"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="122"/>
      <waypoint x="371" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_464463_403892" xmi:uuid="a6577160-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436183_788094_268271"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315943_628818_294520"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="142"/>
      <waypoint x="371" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_671307_403895" xmi:uuid="a6577850-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436258_142299_268287"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315955_479810_294535"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="162"/>
      <waypoint x="371" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_489481_403898" xmi:uuid="a6577e30-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436338_340926_268303"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315968_975042_294550"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="182"/>
      <waypoint x="371" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_35187_403901" xmi:uuid="a6578600-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436417_387560_268319"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315978_697025_294565"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="202"/>
      <waypoint x="371" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_86127_403904" xmi:uuid="a6578dd0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436492_613010_268335"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315990_13249_294580"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="222"/>
      <waypoint x="371" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_429543_403907" xmi:uuid="a6579570-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436569_20066_268351"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316010_414162_294595"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="242"/>
      <waypoint x="371" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_68490_403910" xmi:uuid="a6579d30-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436650_913411_268367"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316024_854858_294610"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="262"/>
      <waypoint x="371" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_458875_403913" xmi:uuid="a657a510-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1727446316026_629240_294622"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316117_43535_294626"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="282"/>
      <waypoint x="371" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_580299_403916" xmi:uuid="a657ac10-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436729_314691_268383"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316138_826904_294641"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="302"/>
      <waypoint x="371" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_603982_403919" xmi:uuid="a657b360-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436812_662739_268399"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316159_690735_294656"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="322"/>
      <waypoint x="371" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_896938_403922" xmi:uuid="a657ba20-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436895_298963_268415"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316177_150534_294671"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="342"/>
      <waypoint x="371" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_199785_403925" xmi:uuid="a657c130-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601436982_237876_268431"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316189_256467_294686"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="362"/>
      <waypoint x="371" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_932897_403928" xmi:uuid="a657c840-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437060_722797_268447"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316205_677542_294701"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="382"/>
      <waypoint x="371" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_945204_403931" xmi:uuid="a657cea0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437215_278222_268479"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316225_559596_294716"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="402"/>
      <waypoint x="371" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_547278_403934" xmi:uuid="a657d550-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437299_972821_268495"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316244_863169_294731"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="422"/>
      <waypoint x="371" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_481635_403937" xmi:uuid="a657dd30-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437386_69103_268511"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316257_29286_294746"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="442"/>
      <waypoint x="371" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_596275_403940" xmi:uuid="a657e560-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437465_770294_268527"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316271_415474_294761"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="462"/>
      <waypoint x="371" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_465585_403943" xmi:uuid="a657ec90-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437544_330871_268543"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316287_895857_294776"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="482"/>
      <waypoint x="371" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_278424_403946" xmi:uuid="a657f3a0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437626_108355_268559"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316305_276032_294791"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="502"/>
      <waypoint x="371" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_640504_403949" xmi:uuid="a657fa60-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437707_400249_268575"/>
      <source xmi:idref="_18_4_1_65b021e_1727446316318_285413_294806"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="522"/>
      <waypoint x="371" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_957773_403952" xmi:uuid="a6580220-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437783_566145_268591"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318088_857818_294821"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="542"/>
      <waypoint x="371" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_570289_403955" xmi:uuid="a6580910-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437861_934977_268607"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318098_980939_294836"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="562"/>
      <waypoint x="371" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_118001_403958" xmi:uuid="a65812d0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601437941_997437_268623"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318108_80546_294851"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="582"/>
      <waypoint x="371" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_429602_403961" xmi:uuid="a65819f0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438019_383542_268639"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318117_298987_294866"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="602"/>
      <waypoint x="371" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_917444_403964" xmi:uuid="a6582090-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1727446318118_953124_294878"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318182_840841_294882"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="622"/>
      <waypoint x="371" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499708_910321_403967" xmi:uuid="a6582740-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601438097_125361_268655"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318191_853601_294897"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315864_223269_294426"/>
      <waypoint x="776" y="642"/>
      <waypoint x="371" y="642"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="779" height="720"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446312649_503240_292784" xmi:uuid="ad3a10c0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312700_92639_292817" xmi:uuid="ae1cc320-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036750_982795_180627"/>
      <ownedElement xmi:id="adef2af0-6c43-013d-d608-0800270c66d6" xmi:uuid="adef2c20-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036750_982795_180627"/>
        <text>process_operation_occurrence:Process_operation_occurrence</text>
      </ownedElement>
      <ownedElement xmi:id="ae188350-6c43-013d-d608-0800270c66d6" xmi:uuid="ae188400-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036750_982795_180627"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="368" height="310"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312718_589299_292851" xmi:uuid="ae1df260-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="839" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312732_54990_292866" xmi:uuid="ae377d60-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="839" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312744_883324_292881" xmi:uuid="ae387690-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="839" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312758_647320_292896" xmi:uuid="ae397160-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="839" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312772_260096_292911" xmi:uuid="ae60b590-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="839" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312786_419914_292926" xmi:uuid="ae7d5ba0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="839" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312800_483393_292941" xmi:uuid="ae93d450-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="839" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446312810_241445_292956" xmi:uuid="ae94ca30-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../PlannedAndEvaluatedCharacteristics/PlannedAndEvaluatedCharacteristics.xmi#_18_4_1_65b021e_1688564400875_767745_227108"/>
      <bounds x="839" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314415_195977_292971" xmi:uuid="aeafa2b0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="839" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314427_819480_292986" xmi:uuid="aec31750-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="839" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314441_560871_293001" xmi:uuid="aec444b0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="839" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314456_289075_293016" xmi:uuid="aec54800-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="839" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314467_966589_293031" xmi:uuid="aeee13c0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="839" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_574231_403622" xmi:uuid="aeee30e0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601426313_931233_265913"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312718_589299_292851"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="62"/>
      <waypoint x="413" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_858477_403625" xmi:uuid="aeee40d0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601426403_598518_265929"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312732_54990_292866"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="82"/>
      <waypoint x="413" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_460562_403628" xmi:uuid="aeee4860-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601426486_287027_265945"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312744_883324_292881"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="102"/>
      <waypoint x="413" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_140359_403631" xmi:uuid="aeee5110-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601426565_4882_265961"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312758_647320_292896"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="122"/>
      <waypoint x="413" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_543713_403634" xmi:uuid="aeee5920-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601426651_455887_265977"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312772_260096_292911"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="142"/>
      <waypoint x="413" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_228450_403637" xmi:uuid="aeee5fb0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601426734_300786_265993"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312786_419914_292926"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="162"/>
      <waypoint x="413" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_556784_403640" xmi:uuid="aeee6930-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601426816_516182_266009"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312800_483393_292941"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="182"/>
      <waypoint x="413" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_830758_403643" xmi:uuid="aeee7000-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601426898_351111_266025"/>
      <source xmi:idref="_18_4_1_65b021e_1727446312810_241445_292956"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="202"/>
      <waypoint x="413" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_92419_403646" xmi:uuid="aeee7820-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601426974_381274_266041"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314415_195977_292971"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="222"/>
      <waypoint x="413" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_65275_403649" xmi:uuid="aeee7e40-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427051_160915_266057"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314427_819480_292986"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="242"/>
      <waypoint x="413" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_50981_403652" xmi:uuid="aeee8650-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427130_972372_266073"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314441_560871_293001"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="262"/>
      <waypoint x="413" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_995683_403655" xmi:uuid="aeee8e60-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427215_173273_266089"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314456_289075_293016"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="282"/>
      <waypoint x="413" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499678_114016_403658" xmi:uuid="aeee94b0-6c43-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601427296_641386_266105"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314467_966589_293031"/>
      <target xmi:idref="_18_4_1_65b021e_1727446312700_92639_292817"/>
      <waypoint x="839" y="302"/>
      <waypoint x="413" y="302"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="842" height="380"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446318951_944091_295896" xmi:uuid="d0187110-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977072_427965_164314"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318975_957422_295928" xmi:uuid="d10b6e00-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039916_739998_181358"/>
      <ownedElement xmi:id="d0e01880-6c44-013d-d608-0800270c66d6" xmi:uuid="d0e01970-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039916_739998_181358"/>
        <text>tool_part_relationship:Part_definition_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d0f7a580-6c44-013d-d608-0800270c66d6" xmi:uuid="d0f7a650-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039916_739998_181358"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="304" height="650"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446318993_667354_295962" xmi:uuid="d10cbc80-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="776" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319006_753720_295977" xmi:uuid="d12a5540-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="776" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319015_218795_295992" xmi:uuid="d12b3e30-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_6b1022a_1570727524445_1920_44551"/>
      <bounds x="776" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319030_746910_296007" xmi:uuid="d141af50-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="776" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319040_378643_296022" xmi:uuid="d154ecc0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="776" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319051_321303_296037" xmi:uuid="d155dde0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="776" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319062_313367_296052" xmi:uuid="d1724a10-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="776" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319070_179734_296067" xmi:uuid="d18593f0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973058873_539759_54381"/>
      <bounds x="776" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319079_778555_296082" xmi:uuid="d186a4c0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973091565_761824_54391"/>
      <bounds x="776" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319093_397541_296097" xmi:uuid="d187eba0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="776" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319103_717296_296112" xmi:uuid="d1af5fa0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="776" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319168_994377_296128" xmi:uuid="d1c2bdf0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="776" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319181_529459_296143" xmi:uuid="d1c3a5c0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="776" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319195_852151_296158" xmi:uuid="d1d9cad0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="776" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319208_254926_296173" xmi:uuid="d1dac410-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="776" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319218_586787_296188" xmi:uuid="d1f8c990-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="776" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319230_200097_296203" xmi:uuid="d21271a0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="776" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319245_374671_296218" xmi:uuid="d22a9f50-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="776" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319261_248623_296233" xmi:uuid="d22b92d0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="776" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319272_433724_296248" xmi:uuid="d23d8c40-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="776" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319284_50311_296263" xmi:uuid="d24dd610-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="776" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319299_641175_296278" xmi:uuid="d24eca40-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="776" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319313_102656_296293" xmi:uuid="d26cc410-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="776" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319323_187472_296308" xmi:uuid="d26db850-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
      <bounds x="776" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319333_813991_296323" xmi:uuid="d2841500-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
      <bounds x="776" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319343_115443_296338" xmi:uuid="d298c9f0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="776" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319353_261831_296353" xmi:uuid="d299bc10-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="776" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319363_552860_296368" xmi:uuid="d2aee490-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="776" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319429_126832_296384" xmi:uuid="d2c6e360-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="776" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446319439_255212_296399" xmi:uuid="d2dd8b30-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="776" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_320316_404117" xmi:uuid="d2dd9c70-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601428982_228173_266613"/>
      <source xmi:idref="_18_4_1_65b021e_1727446318993_667354_295962"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="62"/>
      <waypoint x="349" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_171458_404120" xmi:uuid="d2dda3a0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429068_769411_266629"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319006_753720_295977"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="82"/>
      <waypoint x="349" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_168157_404123" xmi:uuid="d2ddaa50-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429145_276912_266645"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319015_218795_295992"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="102"/>
      <waypoint x="349" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_497334_404126" xmi:uuid="d2ddb250-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429224_798402_266661"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319030_746910_296007"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="122"/>
      <waypoint x="349" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_629236_404129" xmi:uuid="d2ddb960-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429385_954134_266693"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319040_378643_296022"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="142"/>
      <waypoint x="349" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_471059_404132" xmi:uuid="d2ddc010-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429461_621911_266709"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319051_321303_296037"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="162"/>
      <waypoint x="349" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_790283_404135" xmi:uuid="d2ddc730-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429539_512407_266725"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319062_313367_296052"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="182"/>
      <waypoint x="349" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_407249_404138" xmi:uuid="d2ddcec0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429617_36419_266741"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319070_179734_296067"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="202"/>
      <waypoint x="349" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_977848_404141" xmi:uuid="d2ddd870-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429694_844147_266757"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319079_778555_296082"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="222"/>
      <waypoint x="349" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_795166_404144" xmi:uuid="d2ddddf0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429770_50326_266773"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319093_397541_296097"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="242"/>
      <waypoint x="349" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_595011_404147" xmi:uuid="d2dde4d0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429852_932008_266789"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319103_717296_296112"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="262"/>
      <waypoint x="349" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_86060_404150" xmi:uuid="d2ddebc0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1727446319104_127762_296124"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319168_994377_296128"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="282"/>
      <waypoint x="349" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_189462_404153" xmi:uuid="d2ddf2a0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601429933_599003_266805"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319181_529459_296143"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="302"/>
      <waypoint x="349" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_531431_404156" xmi:uuid="d2ddf980-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430016_136975_266821"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319195_852151_296158"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="322"/>
      <waypoint x="349" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_784548_404159" xmi:uuid="d2de0030-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430099_723199_266837"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319208_254926_296173"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="342"/>
      <waypoint x="349" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_657039_404162" xmi:uuid="d2de0800-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430183_214965_266853"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319218_586787_296188"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="362"/>
      <waypoint x="349" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_736447_404165" xmi:uuid="d2de0ee0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430261_710648_266869"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319230_200097_296203"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="382"/>
      <waypoint x="349" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_32121_404168" xmi:uuid="d2de1550-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430421_487667_266901"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319245_374671_296218"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="402"/>
      <waypoint x="349" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_990979_404171" xmi:uuid="d2de1c20-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430505_837948_266917"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319261_248623_296233"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="422"/>
      <waypoint x="349" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_790998_404174" xmi:uuid="d2de22a0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430587_260760_266933"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319272_433724_296248"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="442"/>
      <waypoint x="349" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_537347_404177" xmi:uuid="d2de2960-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430667_518847_266949"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319284_50311_296263"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="462"/>
      <waypoint x="349" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_343058_404180" xmi:uuid="d2de3000-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430748_408215_266965"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319299_641175_296278"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="482"/>
      <waypoint x="349" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_887263_404183" xmi:uuid="d2de36b0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430831_127785_266981"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319313_102656_296293"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="502"/>
      <waypoint x="349" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_309389_404186" xmi:uuid="d2de3d50-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430916_621712_266997"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319323_187472_296308"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="522"/>
      <waypoint x="349" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_449737_404189" xmi:uuid="d2de44a0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601430994_394359_267013"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319333_813991_296323"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="542"/>
      <waypoint x="349" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_626852_404192" xmi:uuid="d2de4b20-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431073_297921_267029"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319343_115443_296338"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="562"/>
      <waypoint x="349" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_986993_404195" xmi:uuid="d2de5260-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431155_792712_267045"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319353_261831_296353"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="582"/>
      <waypoint x="349" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_124257_404198" xmi:uuid="d2de58d0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431233_180103_267061"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319363_552860_296368"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="602"/>
      <waypoint x="349" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_797660_404201" xmi:uuid="d2de5ed0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1727446319364_207510_296380"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319429_126832_296384"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="622"/>
      <waypoint x="349" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499736_596071_404204" xmi:uuid="d2de6650-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601431311_308124_267077"/>
      <source xmi:idref="_18_4_1_65b021e_1727446319439_255212_296399"/>
      <target xmi:idref="_18_4_1_65b021e_1727446318975_957422_295928"/>
      <waypoint x="776" y="642"/>
      <waypoint x="349" y="642"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="779" height="720"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446314915_485536_293574" xmi:uuid="d17cf150-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977032_543000_164261"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314940_390631_293606" xmi:uuid="d268f340-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037159_755240_180707"/>
      <ownedElement xmi:id="d23fefc0-6c42-013d-d608-0800270c66d6" xmi:uuid="d23ff090-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037159_755240_180707"/>
        <text>make_from_relationship:Make_from_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d268ddd0-6c42-013d-d608-0800270c66d6" xmi:uuid="d268dea0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037159_755240_180707"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="295" height="650"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314957_251254_293640" xmi:uuid="d27f25c0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="797" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314968_839508_293655" xmi:uuid="d29955e0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517600591119_427209_42629"/>
      <bounds x="797" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314979_283664_293670" xmi:uuid="d2a86c40-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Analysis/Analysis.xmi#_18_4_1_6b1022a_1570727524445_1920_44551"/>
      <bounds x="797" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446314995_515878_293685" xmi:uuid="d2ba36b0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="797" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315004_437248_293700" xmi:uuid="d2bb45a0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543930057794_56632_71301"/>
      <bounds x="797" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315015_823672_293715" xmi:uuid="d2d01ae0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527249136172_233600_36780"/>
      <bounds x="797" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315027_930228_293730" xmi:uuid="d2e38340-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_8be0287_1527511812009_562326_37652"/>
      <bounds x="797" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315035_901406_293745" xmi:uuid="d2e49060-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973058873_539759_54381"/>
      <bounds x="797" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315043_40657_293760" xmi:uuid="d31e96f0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Interface/Interface.xmi#_18_4_1_271a0567_1577973091565_761824_54391"/>
      <bounds x="797" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315058_590864_293775" xmi:uuid="d31fc2c0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="797" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315069_675024_293790" xmi:uuid="d33f2a00-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="797" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315136_597324_293806" xmi:uuid="d3404f00-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="797" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315150_506944_293821" xmi:uuid="d386d5c0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="797" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315164_65605_293836" xmi:uuid="d39d9260-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="797" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315178_179650_293851" xmi:uuid="d3bb8bc0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="797" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315189_213474_293866" xmi:uuid="d3e19710-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../RequirementManagement/RequirementManagement.xmi#_18_4_1_aec0217_1569998957581_267624_44698"/>
      <bounds x="797" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315201_91603_293881" xmi:uuid="d3e29230-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="797" y="375" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315218_729195_293896" xmi:uuid="d3f44ea0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="797" y="395" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315235_825565_293911" xmi:uuid="d3f546f0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="797" y="415" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315247_670261_293926" xmi:uuid="d416b170-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="797" y="435" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315260_735323_293941" xmi:uuid="d4184d50-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="797" y="455" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315275_329006_293956" xmi:uuid="d4198220-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="797" y="475" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315290_251524_293971" xmi:uuid="d460a6b0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="797" y="495" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315300_294624_293986" xmi:uuid="d4759d10-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618414214099_522198_70264"/>
      <bounds x="797" y="515" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315310_891290_294001" xmi:uuid="d489ad00-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Risk/Risk.xmi#_18_4_1_2b2015d_1618413026319_618977_66268"/>
      <bounds x="797" y="535" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315321_546580_294016" xmi:uuid="d4a1dd10-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1570724047991_233833_85077"/>
      <bounds x="797" y="555" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315331_455914_294031" xmi:uuid="d4a31cd0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570180437128_516847_84533"/>
      <bounds x="797" y="575" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315341_590895_294046" xmi:uuid="d4bb1eb0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_aec0217_1570182191215_683521_88368"/>
      <bounds x="797" y="595" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315410_244883_294062" xmi:uuid="d4d4dd60-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="797" y="615" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315421_496751_294077" xmi:uuid="d4eb6650-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../WorkManagement/WorkManagement.xmi#_18_4_1_271a0567_1577963048539_84613_51644"/>
      <bounds x="797" y="635" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_120806_403742" xmi:uuid="d4eb76e0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432088_75370_267361"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314957_251254_293640"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="62"/>
      <waypoint x="340" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_55757_403745" xmi:uuid="d4eb8000-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432172_474714_267377"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314968_839508_293655"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="82"/>
      <waypoint x="340" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_786970_403748" xmi:uuid="d4eb87c0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432251_530967_267393"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314979_283664_293670"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="102"/>
      <waypoint x="340" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_83340_403751" xmi:uuid="d4eb9390-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432328_699035_267409"/>
      <source xmi:idref="_18_4_1_65b021e_1727446314995_515878_293685"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="122"/>
      <waypoint x="340" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_181344_403754" xmi:uuid="d4eba300-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432491_560177_267441"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315004_437248_293700"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="142"/>
      <waypoint x="340" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_636490_403757" xmi:uuid="d4ebb1d0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432570_490603_267457"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315015_823672_293715"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="162"/>
      <waypoint x="340" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_192140_403760" xmi:uuid="d4ebbeb0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432644_623824_267473"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315027_930228_293730"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="182"/>
      <waypoint x="340" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_150153_403763" xmi:uuid="d4ebc860-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432724_591104_267489"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315035_901406_293745"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="202"/>
      <waypoint x="340" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_572804_403766" xmi:uuid="d4ebd250-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432802_550181_267505"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315043_40657_293760"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="222"/>
      <waypoint x="340" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_301683_403769" xmi:uuid="d4ebda20-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432878_460205_267521"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315058_590864_293775"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="242"/>
      <waypoint x="340" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_498731_403772" xmi:uuid="d4ebe7d0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601432962_204320_267537"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315069_675024_293790"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="262"/>
      <waypoint x="340" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_998299_403775" xmi:uuid="d4ebf050-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1727446315070_513000_293802"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315136_597324_293806"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="282"/>
      <waypoint x="340" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_647550_403778" xmi:uuid="d4ebf970-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433041_59918_267553"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315150_506944_293821"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="302"/>
      <waypoint x="340" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_582097_403781" xmi:uuid="d4ec01d0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433122_16532_267569"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315164_65605_293836"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="322"/>
      <waypoint x="340" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_390924_403784" xmi:uuid="d4ec0bc0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433206_441402_267585"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315178_179650_293851"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="342"/>
      <waypoint x="340" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_126848_403787" xmi:uuid="d4ec14a0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433289_592681_267601"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315189_213474_293866"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="362"/>
      <waypoint x="340" y="362"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_49905_403790" xmi:uuid="d4ec1e10-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433372_480312_267617"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315201_91603_293881"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="382"/>
      <waypoint x="340" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_659771_403793" xmi:uuid="d4ec26e0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433535_862153_267649"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315218_729195_293896"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="402"/>
      <waypoint x="340" y="402"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_898628_403796" xmi:uuid="d4ec3180-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433619_750206_267665"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315235_825565_293911"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="422"/>
      <waypoint x="340" y="422"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499691_895277_403799" xmi:uuid="d4ec3a70-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433707_317630_267681"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315247_670261_293926"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="442"/>
      <waypoint x="340" y="442"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499692_144779_403802" xmi:uuid="d4ec4670-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433786_414329_267697"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315260_735323_293941"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="462"/>
      <waypoint x="340" y="462"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499692_519661_403805" xmi:uuid="d4ec55f0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433867_107999_267713"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315275_329006_293956"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="482"/>
      <waypoint x="340" y="482"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499692_146739_403808" xmi:uuid="d4ec60a0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601433951_978588_267729"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315290_251524_293971"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="502"/>
      <waypoint x="340" y="502"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499692_478582_403811" xmi:uuid="d4ec69c0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434034_760421_267745"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315300_294624_293986"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="522"/>
      <waypoint x="340" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499692_807564_403814" xmi:uuid="d4ec72c0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434113_831974_267761"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315310_891290_294001"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="542"/>
      <waypoint x="340" y="542"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499692_964958_403817" xmi:uuid="d4ec7d40-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434188_53310_267777"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315321_546580_294016"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="562"/>
      <waypoint x="340" y="562"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499692_310613_403820" xmi:uuid="d4ec8550-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434265_451163_267793"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315331_455914_294031"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="582"/>
      <waypoint x="340" y="582"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499692_615151_403823" xmi:uuid="d4ec8cd0-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434346_251689_267809"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315341_590895_294046"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="602"/>
      <waypoint x="340" y="602"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499692_10585_403826" xmi:uuid="d4ec9530-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1727446315342_961861_294058"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315410_244883_294062"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="622"/>
      <waypoint x="340" y="622"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499692_636668_403829" xmi:uuid="d4ec9c90-6c42-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434423_760862_267825"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315421_496751_294077"/>
      <target xmi:idref="_18_4_1_65b021e_1727446314940_390631_293606"/>
      <waypoint x="797" y="642"/>
      <waypoint x="340" y="642"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="800" height="720"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564038992_32996_181088" xmi:uuid="e73a4590-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977057_168128_164282"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_165878_372539" xmi:uuid="e7827ee0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039104_382219_181152"/>
      <ownedElement xmi:id="e77645f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7764720-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039104_382219_181152"/>
        <text>CycleTime:Duration</text>
      </ownedElement>
      <ownedElement xmi:id="e777f280-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e777f380-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039104_382219_181152"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_282911_372540" xmi:uuid="e78278e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513242959833_179220_31050"/>
        <ownedElement xmi:id="e7826010-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7826110-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513242959833_179220_31050"/>
          <bounds x="205" y="752" width="82" height="13"/>
          <text>dur : Duration [1]</text>
        </ownedElement>
        <bounds x="187" y="761" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="749" width="160" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_912071_372544" xmi:uuid="e7a29620-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039100_527018_181151"/>
      <ownedElement xmi:id="e79edaf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e79edbf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039100_527018_181151"/>
        <text>Related:ProcessOperationOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="e7a06690-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7a06780-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039100_527018_181151"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_16998_372545" xmi:uuid="e7a28810-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036755_642051_180628"/>
        <ownedElement xmi:id="e7a263a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7a26480-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036755_642051_180628"/>
          <bounds x="289" y="869" width="326" height="13"/>
          <text>processOperationOccurrence : Process_operation_occurrence [1]</text>
        </ownedElement>
        <bounds x="271" y="878" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="875" width="244" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_125507_372547" xmi:uuid="e7a91230-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039096_687117_181150"/>
      <ownedElement xmi:id="e7a58e00-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7a58f00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039096_687117_181150"/>
        <text>Relating:ProcessOperationOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="e7a71e70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7a721f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039096_687117_181150"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_749635_372548" xmi:uuid="e7a90560-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036755_642051_180628"/>
        <ownedElement xmi:id="e7a8ded0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7a8dfd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036755_642051_180628"/>
          <bounds x="292" y="926" width="326" height="13"/>
          <text>processOperationOccurrence : Process_operation_occurrence [1]</text>
        </ownedElement>
        <bounds x="274" y="935" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="931" width="247" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_288831_372551" xmi:uuid="e7cd5d20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035579_430572_180365"/>
      <ownedElement xmi:id="e7c18c40-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7c18d30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035579_430572_180365"/>
        <text>WaitingTime:PropertyValue</text>
      </ownedElement>
      <ownedElement xmi:id="e7c32a80-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7c32b70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035579_430572_180365"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692799048553_810694_97275" xmi:uuid="ab99aa50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1537543498103_674157_32102"/>
        <ownedElement xmi:id="ab98d4d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ab98d600-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1537543498103_674157_32102"/>
          <bounds x="244" y="1009" width="193" height="13"/>
          <text>propertyValue : Representation_item [1]</text>
        </ownedElement>
        <bounds x="226" y="1018" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="1001" width="199" height="47"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_33005_402609" xmi:uuid="e8a8cde0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039076_124475_181136"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_361418_372617"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_89879_372555"/>
      <waypoint x="1050" y="745"/>
      <waypoint x="1295" y="745"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_969959_402610" xmi:uuid="e8a9c0e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039078_144355_181139"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_892822_372614"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_732133_372560"/>
      <waypoint x="1050" y="1012"/>
      <waypoint x="1295" y="1012"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_925250_372554" xmi:uuid="e8aa8dc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039109_1034_181153"/>
      <ownedElement xmi:id="e7f2c100-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7f2c200-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039109_1034_181153"/>
        <text>process_operation_occurrence_relationship:Process_operation_occurrence_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="e7f46520-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7f46610-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039109_1034_181153"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="e7f488a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7f48950-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="e7f499f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e7f49a90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_89879_372555" xmi:uuid="e813dff0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-cycle_time"/>
          <ownedElement xmi:id="e80922f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e80923e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-cycle_time"/>
            <text>cycle_time:Time_interval_with_bounds</text>
          </ownedElement>
          <ownedElement xmi:id="e813c780-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e813c880-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-cycle_time"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1295" y="735" width="263" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_593949_372556" xmi:uuid="e8338fd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-description"/>
          <ownedElement xmi:id="e828f300-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e828f410-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-description"/>
            <text>description:text</text>
          </ownedElement>
          <ownedElement xmi:id="e8337160-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e8337260-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1295" y="623" width="135" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_429758_372557" xmi:uuid="e852a9a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-related"/>
          <ownedElement xmi:id="e8480c60-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e8480d60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-related"/>
            <text>related:Process_operation_occurrence</text>
          </ownedElement>
          <ownedElement xmi:id="e8528760-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e8528860-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-related"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1295" y="875" width="252" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_882315_372558" xmi:uuid="e8725150-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-relating"/>
          <ownedElement xmi:id="e8677930-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e8677a30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-relating"/>
            <text>relating:Process_operation_occurrence</text>
          </ownedElement>
          <ownedElement xmi:id="e8723570-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e8723680-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-relating"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1295" y="931" width="255" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_108139_372559" xmi:uuid="e88921e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-relation_type"/>
          <ownedElement xmi:id="e87e1c70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e87e1d60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="e888faa0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e888fbc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-relation_type"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1295" y="679" width="144" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_732133_372560" xmi:uuid="e8a8a970-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-waiting_time"/>
          <ownedElement xmi:id="e89dc030-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e89dc130-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-waiting_time"/>
            <text>waiting_time:Duration</text>
          </ownedElement>
          <ownedElement xmi:id="e8a89100-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="e8a891f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence_relationship-waiting_time"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1295" y="994" width="168" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1274" y="588" width="506" height="441"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_444603_402619" xmi:uuid="eb2ec4d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039068_652844_181128"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_925250_372554"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_291941_372610"/>
      <waypoint x="1313" y="588"/>
      <waypoint x="1313" y="322"/>
      <waypoint x="953" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_82731_372609" xmi:uuid="eb2f8e60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039172_710529_181168"/>
      <ownedElement xmi:id="eae4ae30-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eae4af40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039172_710529_181168"/>
        <text>ia1:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="eae65900-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eae65a00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039172_710529_181168"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="eae68070-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eae68120-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="eae69720-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eae697b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_291941_372610" xmi:uuid="eb051c20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="eafac6f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eafac7f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="eb04ff50-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb050040-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="770" y="308" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_262207_372611" xmi:uuid="eb19b170-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="eb0f4af0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb0f4be0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="eb199040-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb199140-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="770" y="280" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_108615_372612" xmi:uuid="eb2eaa60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="eb2425f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb242810-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="eb2e85e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb2e86e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="768" y="336" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="756" y="252" width="287" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_818398_372613" xmi:uuid="eb32e0e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039175_198552_181169"/>
      <ownedElement xmi:id="eb313890-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb313980-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039175_198552_181169"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="eb32c6a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb32c7a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039175_198552_181169"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="553" y="336" width="176" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_892822_372614" xmi:uuid="eb7cded0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039179_881187_181170"/>
      <ownedElement xmi:id="eb3e6050-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb3e6150-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039179_881187_181170"/>
        <text>d:Duration</text>
      </ownedElement>
      <ownedElement xmi:id="eb4007a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb400890-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039179_881187_181170"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="eb402aa0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb402b50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="eb403d20-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb403dc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_601815_372615" xmi:uuid="eb5f8e10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-unit"/>
          <ownedElement xmi:id="eb549820-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb5499b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-unit"/>
            <text>unit:Unit</text>
          </ownedElement>
          <ownedElement xmi:id="eb5f73c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb5f74b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-unit"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="777" y="994" width="89" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_874882_372616" xmi:uuid="eb7cd320-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-value_component"/>
          <ownedElement xmi:id="eb72bee0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb72bfe0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-value_component"/>
            <text>value_component:measure_value</text>
          </ownedElement>
          <ownedElement xmi:id="eb7cb620-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb7cb710-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-value_component"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="777" y="1022" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="763" y="966" width="287" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_361418_372617" xmi:uuid="ebd3b440-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039183_649957_181171"/>
      <ownedElement xmi:id="eb881b40-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb881c40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039183_649957_181171"/>
        <text>tiwb:Time_interval_with_bounds</text>
      </ownedElement>
      <ownedElement xmi:id="eb89ccc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb89d040-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039183_649957_181171"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="eb89f610-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb89f6c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="eb8a0a90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb8a0b40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_696107_372618" xmi:uuid="eba9d7b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Time_interval_with_bounds-duration_from_primary_bound"/>
          <ownedElement xmi:id="eb9ea460-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eb9ea5a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Time_interval_with_bounds-duration_from_primary_bound"/>
            <text>duration_from_primary_bound:Duration</text>
          </ownedElement>
          <ownedElement xmi:id="eba98de0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eba993e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Time_interval_with_bounds-duration_from_primary_bound"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="777" y="757" width="266" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_521698_372619" xmi:uuid="ebbed400-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Time_interval-id"/>
          <ownedElement xmi:id="ebb45010-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebb45100-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Time_interval-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="ebbeb500-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebbeb5f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Time_interval-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="777" y="792" width="88" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_583750_372620" xmi:uuid="ebd3a7c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Time_interval-name"/>
          <ownedElement xmi:id="ebc93440-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebc93690-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Time_interval-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="ebd38600-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebd38a10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Time_interval-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="777" y="827" width="109" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="763" y="721" width="287" height="141"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_481742_372621" xmi:uuid="ebd6f930-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039188_609454_181172"/>
      <ownedElement xmi:id="ebd55410-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebd55540-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039188_609454_181172"/>
        <text>theName:String</text>
      </ownedElement>
      <ownedElement xmi:id="ebd6e910-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebd6ea10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039188_609454_181172"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="549" y="826" width="189" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_73641_372622" xmi:uuid="ebda26d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039192_773114_181173"/>
      <ownedElement xmi:id="ebd894a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebd896d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039192_773114_181173"/>
        <text>theId:String</text>
      </ownedElement>
      <ownedElement xmi:id="ebda1430-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebda1520-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039192_773114_181173"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="583" y="791" width="161" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_996007_402640" xmi:uuid="ec255f90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039079_1760_181140"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_874882_372616"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_309952_372625"/>
      <waypoint x="777" y="1034"/>
      <waypoint x="704" y="1034"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_908280_402641" xmi:uuid="ec2646c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039080_38995_181141"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_601815_372615"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_318493_372624"/>
      <waypoint x="777" y="1006"/>
      <waypoint x="565" y="1006"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_701772_372623" xmi:uuid="ec270360-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039196_352550_181174"/>
      <ownedElement xmi:id="ebe52a60-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebe52b60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039196_352550_181174"/>
        <text>niwu:Numerical_item_with_unit</text>
      </ownedElement>
      <ownedElement xmi:id="ebe6cfa0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebe6d080-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039196_352550_181174"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ebe6f690-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebe6f790-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ebe71670-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebe71860-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_318493_372624" xmi:uuid="ec060560-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-unit"/>
          <ownedElement xmi:id="ebfb3f30-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ebfb4040-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-unit"/>
            <text>unit:Unit</text>
          </ownedElement>
          <ownedElement xmi:id="ec05ea60-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec05eb60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-unit"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="476" y="994" width="89" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_309952_372625" xmi:uuid="ec254420-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-value_component"/>
          <ownedElement xmi:id="ec1a40e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec1a4180-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-value_component"/>
            <text>value_component:measure_value</text>
          </ownedElement>
          <ownedElement xmi:id="ec251ee0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec251ff0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Value_with_unit-value_component"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="476" y="1022" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="455" y="966" width="256" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_747053_372628" xmi:uuid="ec4a6db0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039199_809387_181175"/>
      <ownedElement xmi:id="ec32da20-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec32db30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039199_809387_181175"/>
        <text>defaultType:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_774959_372629" xmi:uuid="ec3f9250-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="ec3f7480-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec3f7580-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="735" y="693" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="791" y="684" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_137573_372631" xmi:uuid="ec4a6360-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="ec4a4a80-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec4a4b80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="986" y="673" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="968" y="682" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="791" y="672" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_178592_402611" xmi:uuid="ec4a7640-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039051_23257_181109"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_925250_372554"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_385625_372626"/>
      <waypoint x="1642" y="588"/>
      <waypoint x="1642" y="550"/>
      <waypoint x="1792" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_132415_402612" xmi:uuid="ec4a7df0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039053_49546_181110"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_696107_372618"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_282911_372540"/>
      <waypoint x="777" y="768"/>
      <waypoint x="202" y="768"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_864197_402621" xmi:uuid="ec4a9140-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039056_322523_181113"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_108615_372612"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_818398_372613"/>
      <waypoint x="768" y="347"/>
      <waypoint x="729" y="347"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_831136_402633" xmi:uuid="ec4b19e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039070_62765_181130"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_429758_372557"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_16998_372545"/>
      <waypoint x="1295" y="885"/>
      <waypoint x="286" y="885"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_590504_402634" xmi:uuid="ec4b2130-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039071_320619_181131"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_882315_372558"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_749635_372548"/>
      <waypoint x="1295" y="941"/>
      <waypoint x="289" y="941"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_210942_402638" xmi:uuid="ec4b44e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039077_534590_181137"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_583750_372620"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_481742_372621"/>
      <waypoint x="777" y="837"/>
      <waypoint x="738" y="837"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_728524_402639" xmi:uuid="ec4b4bd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039077_170809_181138"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_521698_372619"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_73641_372622"/>
      <waypoint x="777" y="802"/>
      <waypoint x="744" y="802"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_450225_402643" xmi:uuid="ec4b6210-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039083_588510_181145"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_108139_372559"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_137573_372631"/>
      <waypoint x="1295" y="690"/>
      <waypoint x="983" y="690"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_385625_372626" xmi:uuid="ec4b7c50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039115_812562_181154"/>
      <bounds x="1792" y="541" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692799106907_526963_97304" xmi:uuid="ae83afd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692799108242_520167_97305"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_701772_372623"/>
      <target xmi:idref="_18_4_1_65b021e_1692799048553_810694_97275"/>
      <waypoint x="455" y="1026"/>
      <waypoint x="241" y="1026"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805463788_153810_95828" xmi:uuid="ae83b6d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="749" y="35" width="115" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805667278_378290_96439" xmi:uuid="aed370a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805669471_989881_96440"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_925250_372554"/>
      <target xmi:idref="_18_4_1_65b021e_1692805463789_241218_95837"/>
      <waypoint x="1313" y="588"/>
      <waypoint x="1313" y="137"/>
      <waypoint x="954" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_6917_95829" xmi:uuid="aed41860-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="ae9c84c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ae9c8a00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="aea9a370-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="aea9a4a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="aeaaaa50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="aeaaac60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="aeab7ee0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="aeab81e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_241218_95837" xmi:uuid="aed2b740-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="aec4c960-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="aec4caa0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="aed1e720-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="aed1e8e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="770" y="126" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="756" y="98" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_535477_95830" xmi:uuid="af02a210-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="aeea4b30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="aeea4c50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_515940_95838" xmi:uuid="af0295c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="af01b900-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af01ba30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="680" y="270" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="662" y="279" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="539" y="266" width="138" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805661564_482076_96420" xmi:uuid="af501f50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805663813_959992_96421"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_925250_372554"/>
      <target xmi:idref="_18_4_1_65b021e_1692805463789_112954_95840"/>
      <waypoint x="1313" y="588"/>
      <waypoint x="1313" y="214"/>
      <waypoint x="953" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_732037_95831" xmi:uuid="af50dca0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="af1b0b20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af1b0c20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="af276da0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af276ed0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="af282eb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af282fc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="af2908f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af290a30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_112954_95840" xmi:uuid="af4f53b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="af40d3c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af40d500-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="af4e6e50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af4e70d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="770" y="203" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="756" y="175" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805642319_884698_96363" xmi:uuid="af9e97e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805644069_633825_96364"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_925250_372554"/>
      <target xmi:idref="_18_4_1_65b021e_1692805463789_929408_95841"/>
      <waypoint x="1313" y="588"/>
      <waypoint x="1313" y="424"/>
      <waypoint x="945" y="424"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_819442_95832" xmi:uuid="af9f6a70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="af688bd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af688d00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="af7444f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af744620-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="af751140-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af751270-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="af75e940-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af75ea80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_929408_95841" xmi:uuid="af9daa80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="af8f1fd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af8f2100-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="af9cd430-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="af9cd570-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="770" y="413" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="756" y="385" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805647606_450792_96382" xmi:uuid="afed7340-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805650224_64242_96383"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_925250_372554"/>
      <target xmi:idref="_18_4_1_65b021e_1692805463789_73014_95842"/>
      <waypoint x="1313" y="588"/>
      <waypoint x="1313" y="501"/>
      <waypoint x="998" y="501"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_275487_95833" xmi:uuid="afee3280-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="afb7b980-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="afb7bab0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="afc45460-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="afc456b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="afc54820-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="afc54ad0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="afc629d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="afc62c90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_73014_95842" xmi:uuid="afec99c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="afdf4800-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="afdf4920-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="afebaca0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="afebade0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="770" y="490" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="756" y="462" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_275228_95834" xmi:uuid="b01f3550-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="b0062490-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b0062650-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_498410_95843" xmi:uuid="b01f2a40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b01e4bc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b01e4d10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="767" y="620" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="749" y="629" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="539" y="616" width="225" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_596276_95835" xmi:uuid="b0506c10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="b0375780-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b03758b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_488982_95845" xmi:uuid="b0505300-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="b04f8a30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b04f8b60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="713" y="673" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="695" y="682" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="539" y="672" width="171" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805654727_182257_96401" xmi:uuid="b09ecb50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805657312_573379_96402"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_925250_372554"/>
      <target xmi:idref="_18_4_1_65b021e_1692805463789_140307_95847"/>
      <waypoint x="1313" y="588"/>
      <waypoint x="1313" y="578"/>
      <waypoint x="954" y="578"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_78460_95836" xmi:uuid="b09f9c70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="b0690040-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b06902d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b075bf30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b075c050-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b076cbe0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b076cd10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b0777dd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b0777f00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805463789_140307_95847" xmi:uuid="b09e20d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b0909a70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b0909bb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b09d60c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b09d61f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="770" y="567" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="756" y="539" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805514730_767527_96271" xmi:uuid="b09fa860-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805516830_119397_96272"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_262207_372611"/>
      <target xmi:idref="_18_4_1_65b021e_1692805463789_515940_95838"/>
      <waypoint x="770" y="291"/>
      <waypoint x="677" y="291"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805554156_680844_96299" xmi:uuid="b09fb080-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805555420_659833_96300"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_774959_372629"/>
      <target xmi:idref="_18_4_1_65b021e_1692805463789_488982_95845"/>
      <waypoint x="791" y="690"/>
      <waypoint x="710" y="690"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805558088_270981_96321" xmi:uuid="b09fba30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805560672_972420_96322"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_593949_372556"/>
      <target xmi:idref="_18_4_1_65b021e_1692805463789_498410_95843"/>
      <waypoint x="1295" y="637"/>
      <waypoint x="764" y="637"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1795" height="1079"/>
    <name>ProcessOperationOccurrenceRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564037079_165873_180659" xmi:uuid="ec4bb2c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977032_543000_164261"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_724904_372252" xmi:uuid="ec507860-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037142_5694_180703"/>
      <ownedElement xmi:id="ec4ee160-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec4ee240-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037142_5694_180703"/>
        <text>Priority:Integer</text>
      </ownedElement>
      <ownedElement xmi:id="ec506690-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec506780-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037142_5694_180703"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="35" y="707" width="131" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_195497_372253" xmi:uuid="ec6790d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037146_193767_180704"/>
      <ownedElement xmi:id="ec5b6c90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec5b6d90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037146_193767_180704"/>
        <text>Quantity:ValueWithUnit</text>
      </ownedElement>
      <ownedElement xmi:id="ec5d0e00-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec5d0ee0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037146_193767_180704"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_860992_372254" xmi:uuid="ec6786d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1539788138453_688623_38168"/>
        <ownedElement xmi:id="ec676870-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec676a60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1539788138453_688623_38168"/>
          <bounds x="225" y="751" width="162" height="13"/>
          <text>propertyValue : Measure_item [1]</text>
        </ownedElement>
        <bounds x="207" y="760" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="749" width="180" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_224363_372264" xmi:uuid="ed8ac3c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037159_755240_180707"/>
      <ownedElement xmi:id="ec796e10-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec797030-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037159_755240_180707"/>
        <text>make_from_relationship:Make_from_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="ec7b05a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec7b06a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037159_755240_180707"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="ec7b5a70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec7b5b70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ec7b6f70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ec7b7010-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_822122_372266" xmi:uuid="ecaf62b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
          <ownedElement xmi:id="eca4e3e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eca4e4e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="ecaf3df0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ecaf4530-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="854" y="546" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_643583_372267" xmi:uuid="ecc4deb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
          <ownedElement xmi:id="ecba2a90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ecba2b90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="ecc4bf20-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ecc4c020-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="854" y="602" width="100" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_949496_372269" xmi:uuid="ecf9ad00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-priority"/>
          <ownedElement xmi:id="ecef36a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ecef37a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-priority"/>
            <text>priority:Integer</text>
          </ownedElement>
          <ownedElement xmi:id="ecf98d70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ecf99150-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-priority"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="854" y="707" width="131" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_871542_372270" xmi:uuid="ed18f470-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-quantity"/>
          <ownedElement xmi:id="ed0e7160-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ed0e7550-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-quantity"/>
            <text>quantity:Value_with_unit</text>
          </ownedElement>
          <ownedElement xmi:id="ed18d630-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ed18d740-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-quantity"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="854" y="756" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_462643_372271" xmi:uuid="ed37a230-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-related_view"/>
          <ownedElement xmi:id="ed2d27f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ed2d29c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-related_view"/>
            <text>related_view:Part_view_definition</text>
          </ownedElement>
          <ownedElement xmi:id="ed378b10-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ed378bf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-related_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="854" y="840" width="222" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_574435_372272" xmi:uuid="ed569e00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-relating_view"/>
          <ownedElement xmi:id="ed4c2870-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ed4c29c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-relating_view"/>
            <text>relating_view:Part_view_definition</text>
          </ownedElement>
          <ownedElement xmi:id="ed567b40-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ed567c40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Make_from_relationship-relating_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="854" y="882" width="225" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692798690553_649480_96010" xmi:uuid="b1b66ea0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
          <ownedElement xmi:id="b1a8c530-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b1a8c690-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="b1b5bb60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b1b5bc90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-relation_type"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="854" y="658" width="136" height="24"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="840" y="511" width="295" height="406"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_820920_372280" xmi:uuid="ed992a70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037150_628959_180705"/>
      <ownedElement xmi:id="ed96e8e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ed96e9d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037150_628959_180705"/>
        <text>RelationType:ExternalOwlClass</text>
      </ownedElement>
      <ownedElement xmi:id="ed991970-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ed991a60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037150_628959_180705"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="924" width="600" height="60"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_399279_402506" xmi:uuid="ef3ca550-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037127_389007_180680"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_279706_372262"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025963_224363_372264"/>
      <waypoint x="1147" y="459"/>
      <waypoint x="987" y="459"/>
      <waypoint x="987" y="511"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_44162_402507" xmi:uuid="ef3cad60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037128_954854_180681"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_949496_372269"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025963_724904_372252"/>
      <waypoint x="854" y="717"/>
      <waypoint x="166" y="717"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_776644_402508" xmi:uuid="ef3cb600-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037128_220671_180682"/>
      <source xmi:idref="_18_4_1_65b021e_1697206711800_633557_130250"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025963_860992_372254"/>
      <waypoint x="336" y="795"/>
      <waypoint x="273" y="795"/>
      <waypoint x="273" y="767"/>
      <waypoint x="222" y="767"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025963_279706_372262" xmi:uuid="ef3d4480-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037155_718606_180706"/>
      <bounds x="1147" y="452" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692797378472_771106_153117" xmi:uuid="b1dbcd90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_2_attr_PartViewRelationship-Related"/>
      <ownedElement xmi:id="b1d0aac0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b1d0abf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_2_attr_PartViewRelationship-Related"/>
        <text>Related:PartView</text>
      </ownedElement>
      <ownedElement xmi:id="b1d59100-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b1d59230-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_2_attr_PartViewRelationship-Related"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692798301615_388880_94464" xmi:uuid="b1dbb7e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569312553831_792974_41177"/>
        <ownedElement xmi:id="b1dac640-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b1dac750-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569312553831_792974_41177"/>
          <bounds x="184" y="837" width="163" height="13"/>
          <text>partView : Part_view_definition [1]</text>
        </ownedElement>
        <bounds x="166" y="846" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="840" width="139" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692797412704_397424_153172" xmi:uuid="b1f04b10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_2_attr_PartViewRelationship-Relating"/>
      <ownedElement xmi:id="b1e4d9b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b1e4dae0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_2_attr_PartViewRelationship-Relating"/>
        <text>Relating:PartView</text>
      </ownedElement>
      <ownedElement xmi:id="b1ea10a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b1ea11b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_2_attr_PartViewRelationship-Relating"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692798320460_527561_94483" xmi:uuid="b1f036f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569312553831_792974_41177"/>
        <ownedElement xmi:id="b1ef29a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b1ef2ad0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569312553831_792974_41177"/>
          <bounds x="188" y="879" width="163" height="13"/>
          <text>partView : Part_view_definition [1]</text>
        </ownedElement>
        <bounds x="170" y="888" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="882" width="143" height="26"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798301613_378263_94461" xmi:uuid="b1f05480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037129_282360_180683"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_462643_372271"/>
      <target xmi:idref="_18_4_1_65b021e_1692798301615_388880_94464"/>
      <waypoint x="854" y="851"/>
      <waypoint x="181" y="851"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798320460_396749_94480" xmi:uuid="b1f05fc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037130_379900_180684"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_574435_372272"/>
      <target xmi:idref="_18_4_1_65b021e_1692798320460_527561_94483"/>
      <waypoint x="854" y="896"/>
      <waypoint x="185" y="896"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798571320_799738_95164" xmi:uuid="b1f064d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="560" y="28" width="115" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798809615_896131_96149" xmi:uuid="b23ec590-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692798812104_138259_96150"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_224363_372264"/>
      <target xmi:idref="_18_4_1_65b021e_1692798571321_217889_95171"/>
      <waypoint x="875" y="511"/>
      <waypoint x="875" y="123"/>
      <waypoint x="758" y="123"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798571320_196228_95165" xmi:uuid="b23f4250-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="b208bea0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b208bfc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b215b150-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b215b290-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b216bc10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b216bd50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b2177f80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b2178070-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_217889_95171" xmi:uuid="b23ddf00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b22fed40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b22fef60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b23cff70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b23d0100-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="112" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="560" y="84" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_234045_95166" xmi:uuid="b271a0f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="b257c9e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b257cfc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_372449_95172" xmi:uuid="b2718fe0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b270b860-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b270b980-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="501" y="543" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="483" y="552" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="273" y="539" width="225" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798802931_868334_96130" xmi:uuid="b2b93900-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692798805532_20827_96131"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_224363_372264"/>
      <target xmi:idref="_18_4_1_65b021e_1692798571321_60803_95174"/>
      <waypoint x="875" y="511"/>
      <waypoint x="875" y="207"/>
      <waypoint x="749" y="207"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_448525_95167" xmi:uuid="b2b9c130-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="b28a6a80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b28a6bc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b2970140-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b2970270-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b297d1f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b297d410-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b2987fc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b2988370-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_60803_95174" xmi:uuid="b2b86060-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="b2b0a820-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b2b0a940-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="b2b77730-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b2b77850-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="196" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="560" y="168" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798815874_159224_96168" xmi:uuid="b3082c80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692798818106_347328_96169"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_224363_372264"/>
      <target xmi:idref="_18_4_1_65b021e_1692798571321_42624_95175"/>
      <waypoint x="875" y="511"/>
      <waypoint x="875" y="284"/>
      <waypoint x="802" y="284"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_63113_95168" xmi:uuid="b3089ae0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="b2d25860-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b2d259a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="b2df1bb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b2df1cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b2dff1e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b2dff440-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b2e0b660-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b2e0b790-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_42624_95175" xmi:uuid="b3074c90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="b2f9f980-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b2f9fab0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="b30690b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b30691e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="273" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="560" y="245" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_640848_95169" xmi:uuid="b33b1ed0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="b3214fe0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b3215640-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_13637_95176" xmi:uuid="b33b0db0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="b33a2a00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b33a2b30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="498" y="599" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="480" y="608" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="357" y="595" width="138" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798821544_161836_96187" xmi:uuid="b3888260-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692798823945_932486_96188"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_224363_372264"/>
      <target xmi:idref="_18_4_1_65b021e_1692798571321_809406_95178"/>
      <waypoint x="875" y="511"/>
      <waypoint x="875" y="368"/>
      <waypoint x="757" y="368"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_590890_95170" xmi:uuid="b388f490-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="b3529830-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b3529960-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b35f4960-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b35f4a70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b3601840-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b3601980-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b360fc90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b360fdc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692798571321_809406_95178" xmi:uuid="b38788f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="b379a960-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b379aa90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b386b4b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b386b5d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="357" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="560" y="329" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798674836_733129_95914" xmi:uuid="b3ba7720-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="b3a09de0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b3a09f60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692798674836_552957_95916" xmi:uuid="b3ba68e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="b3b97b70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b3b97c90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="496" y="652" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="478" y="661" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="322" y="651" width="171" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798827715_337253_96206" xmi:uuid="b40985f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692798835968_865888_96207"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_224363_372264"/>
      <target xmi:idref="_18_4_1_65b021e_1692798674836_48936_95918"/>
      <waypoint x="875" y="511"/>
      <waypoint x="875" y="452"/>
      <waypoint x="758" y="452"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798674836_434085_95915" xmi:uuid="b409f370-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="b3d32820-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b3d32950-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b3e00e70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b3e00f90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b3e0ce90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b3e0cfe0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b3e18730-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b3e18880-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692798674836_48936_95918" xmi:uuid="b4089e80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b3faab10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b3faac40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b407af30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b407b050-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="574" y="441" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="560" y="413" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798722401_183559_96054" xmi:uuid="b40a0a80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692798724987_829747_96055"/>
      <source xmi:idref="_18_4_1_65b021e_1692798690553_649480_96010"/>
      <target xmi:idref="_18_4_1_65b021e_1692798674836_552957_95916"/>
      <waypoint x="854" y="669"/>
      <waypoint x="493" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798732674_866470_96076" xmi:uuid="b40a1690-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692798734557_316922_96077"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_643583_372267"/>
      <target xmi:idref="_18_4_1_65b021e_1692798571321_13637_95176"/>
      <waypoint x="854" y="616"/>
      <waypoint x="495" y="616"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692798738227_561107_96098" xmi:uuid="b40a1f70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692798740479_520609_96099"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025963_822122_372266"/>
      <target xmi:idref="_18_4_1_65b021e_1692798571321_372449_95172"/>
      <waypoint x="854" y="560"/>
      <waypoint x="498" y="560"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1697206711800_633557_130250" xmi:uuid="958b5f40-4e2f-013c-b172-4d37e860fab5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1697206711765_823214_130246"/>
      <ownedElement xmi:id="9587fc10-4e2f-013c-b172-4d37e860fab5" xmi:uuid="9587fd30-4e2f-013c-b172-4d37e860fab5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1697206711765_823214_130246"/>
        <text>theQuantity:Numerical_item_with_unit</text>
      </ownedElement>
      <ownedElement xmi:id="958b4280-4e2f-013c-b172-4d37e860fab5" xmi:uuid="958b43a0-4e2f-013c-b172-4d37e860fab5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1697206711765_823214_130246"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="336" y="784" width="253" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1697206764991_782458_130303" xmi:uuid="95919730-4e2f-013c-b172-4d37e860fab5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="95902690-4e2f-013c-b172-4d37e860fab5" xmi:uuid="959027c0-4e2f-013c-b172-4d37e860fab5" xmi:type="umldi:UMLKeywordLabel">
        <text>ElementGroup</text>
      </ownedElement>
      <ownedElement xmi:id="95918cf0-4e2f-013c-b172-4d37e860fab5" xmi:uuid="959190a0-4e2f-013c-b172-4d37e860fab5" xmi:type="umldi:UMLLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1697206764985_384464_130301"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="637" y="728" width="155" height="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1697206770174_529445_130319" xmi:uuid="95919f00-4e2f-013c-b172-4d37e860fab5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566025963_871542_372270"/>
      <target xmi:idref="_18_4_1_65b021e_1697206764991_782458_130303"/>
      <waypoint x="854" y="773"/>
      <waypoint x="792" y="776"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1697206773624_360190_130327" xmi:uuid="9591a5b0-4e2f-013c-b172-4d37e860fab5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1697206711800_633557_130250"/>
      <target xmi:idref="_18_4_1_65b021e_1697206764991_782458_130303"/>
      <waypoint x="589" y="788"/>
      <waypoint x="637" y="785"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1150" height="999"/>
    <name>MakeFromRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564037480_513486_180751" xmi:uuid="ef3d73b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977037_997300_164264"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025964_127402_372324" xmi:uuid="ef4490f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037578_296517_180806"/>
      <ownedElement xmi:id="b410da40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b410db70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037578_296517_180806"/>
        <text>Related:ProcessPlan</text>
      </ownedElement>
      <ownedElement xmi:id="b4131c60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4131eb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037578_296517_180806"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025964_495681_372325" xmi:uuid="b4165cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035125_626656_180266"/>
        <ownedElement xmi:id="b4158890-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b41589c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035125_626656_180266"/>
          <bounds x="201" y="760" width="153" height="13"/>
          <text>processPlan : Process_plan [1]</text>
        </ownedElement>
        <bounds x="183" y="769" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="756" width="156" height="37"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025964_570958_372327" xmi:uuid="ef44ed30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037574_88897_180805"/>
      <ownedElement xmi:id="b41a1620-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b41a1740-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037574_88897_180805"/>
        <text>Relating:ProcessPlan</text>
      </ownedElement>
      <ownedElement xmi:id="b41c8f60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b41c9090-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037574_88897_180805"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025964_891288_372328" xmi:uuid="b41fe0e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035125_626656_180266"/>
        <ownedElement xmi:id="b41f1a80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b41f1e30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035125_626656_180266"/>
          <bounds x="204" y="815" width="153" height="13"/>
          <text>processPlan : Process_plan [1]</text>
        </ownedElement>
        <bounds x="186" y="824" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="812" width="159" height="37"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_724657_372379" xmi:uuid="ef4a1980-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037631_700570_180820"/>
      <ownedElement xmi:id="b42db190-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b42db2c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037631_700570_180820"/>
        <text>process_plan_relationship:Process_plan_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="b4303560-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4303700-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037631_700570_180820"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="b4313030-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4313230-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b4322ec0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4323010-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_242214_372380" xmi:uuid="b45929d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-description"/>
          <ownedElement xmi:id="b44afb60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b44afc90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-description"/>
            <text>description:text</text>
          </ownedElement>
          <ownedElement xmi:id="b45842c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4584400-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="931" y="665" width="135" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_815331_372381" xmi:uuid="b47e6ee0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-related"/>
          <ownedElement xmi:id="b4713b90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4713cc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-related"/>
            <text>related:Process_plan</text>
          </ownedElement>
          <ownedElement xmi:id="b47d8ac0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b47d8d00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-related"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="931" y="763" width="153" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_841843_372382" xmi:uuid="b4a42cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-relating"/>
          <ownedElement xmi:id="b496e290-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b496e3c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-relating"/>
            <text>relating:Process_plan</text>
          </ownedElement>
          <ownedElement xmi:id="b4a35180-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4a35470-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-relating"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="931" y="819" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_19585_372383" xmi:uuid="b4bf42e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-relation_type"/>
          <ownedElement xmi:id="b4b14440-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4b14690-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="b4be8300-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4be8430-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan_relationship-relation_type"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="931" y="714" width="144" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="910" y="630" width="320" height="224"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_788375_402535" xmi:uuid="b52fa2b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037548_76318_180788"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_724657_372379"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025965_236049_372385"/>
      <waypoint x="945" y="630"/>
      <waypoint x="945" y="249"/>
      <waypoint x="792" y="249"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_904124_372384" xmi:uuid="ef4a6d70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037640_390527_180822"/>
      <ownedElement xmi:id="b4ccb090-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4ccb1c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037640_390527_180822"/>
        <text>ia1:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b4cef520-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4cef640-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037640_390527_180822"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b4cfd490-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4cfd5b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b4d0a230-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4d0a370-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_236049_372385" xmi:uuid="b4f818b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="b4e9ef20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4e9f050-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b4f74fd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b4f75100-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="609" y="238" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_783402_372386" xmi:uuid="b5139500-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="b5059f10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b505a180-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="b512c4a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b512c5f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="609" y="210" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_411153_372387" xmi:uuid="b52ecc00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="b5208e50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b5208f80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="b52db8f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b52dba20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="607" y="266" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="182" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_298294_372388" xmi:uuid="ef4ab820-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037643_811279_180823"/>
      <ownedElement xmi:id="b5329850-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b5329970-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037643_811279_180823"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="b53514b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b53515e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037643_811279_180823"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="392" y="266" width="176" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_54037_372389" xmi:uuid="ef4b1000-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037647_164873_180824"/>
      <ownedElement xmi:id="b54355b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b5435810-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037647_164873_180824"/>
        <text>defaultType:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_317806_372390" xmi:uuid="b552a360-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="b551b510-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b551b640-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="595" y="728" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="651" y="719" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_678208_372392" xmi:uuid="b5601460-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="b55f40e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b55f4220-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="846" y="708" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="828" y="717" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="651" y="707" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_138428_402536" xmi:uuid="ef4b3350-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037537_776130_180774"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_411153_372387"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025965_298294_372388"/>
      <waypoint x="607" y="277"/>
      <waypoint x="568" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_850034_402548" xmi:uuid="ef4bd1c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037550_121888_180790"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_815331_372381"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025964_495681_372325"/>
      <waypoint x="931" y="777"/>
      <waypoint x="198" y="777"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_7109_402549" xmi:uuid="ef4bd9a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037550_271997_180791"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_841843_372382"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025964_891288_372328"/>
      <waypoint x="931" y="830"/>
      <waypoint x="201" y="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_877456_402553" xmi:uuid="ef4c2200-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037555_115409_180796"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_724657_372379"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025964_568311_372317"/>
      <waypoint x="1071" y="630"/>
      <waypoint x="1071" y="585"/>
      <waypoint x="1242" y="585"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_207990_402554" xmi:uuid="ef4c2970-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037559_455023_180800"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_19585_372383"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025965_678208_372392"/>
      <waypoint x="931" y="725"/>
      <waypoint x="843" y="725"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025964_568311_372317" xmi:uuid="ef4c4420-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037636_922322_180821"/>
      <bounds x="1242" y="577" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_295340_103598" xmi:uuid="b5610410-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="588" y="35" width="115" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807463869_963487_104171" xmi:uuid="b5af6fd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692807465353_521371_104172"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_724657_372379"/>
      <target xmi:idref="_18_4_1_65b021e_1692807297301_386177_103607"/>
      <waypoint x="945" y="630"/>
      <waypoint x="945" y="137"/>
      <waypoint x="793" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_373180_103599" xmi:uuid="b5b00380-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="b5791120-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b5791250-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b585c020-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b585c150-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b586b040-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b586b170-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b5878930-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b5878a60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_386177_103607" xmi:uuid="b5ae9c80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b5a073d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b5a07510-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b5ada9e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b5adab10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="609" y="126" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="98" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_30247_103600" xmi:uuid="b5e39920-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="b5c88530-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b5c88650-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_726367_103608" xmi:uuid="b5e34790-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="b5e22c00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b5e22d40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="519" y="207" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="501" y="216" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="378" y="203" width="138" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807505922_307537_104218" xmi:uuid="b6351510-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692807507675_615724_104219"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_724657_372379"/>
      <target xmi:idref="_18_4_1_65b021e_1692807297302_601704_103610"/>
      <waypoint x="945" y="630"/>
      <waypoint x="945" y="368"/>
      <waypoint x="792" y="368"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_793683_103601" xmi:uuid="b635b0b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="b5fd9ab0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b5fd9c10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b60b3290-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b60b3440-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b60c45f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b60c48b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b60d2510-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b60d2650-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692807297302_601704_103610" xmi:uuid="b6341190-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="b6264f30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6265470-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b6335430-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6335550-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="609" y="357" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="329" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807511592_647401_104237" xmi:uuid="b6805750-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692807513663_824214_104238"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_724657_372379"/>
      <target xmi:idref="_18_4_1_65b021e_1692807297302_514665_103611"/>
      <waypoint x="945" y="630"/>
      <waypoint x="945" y="445"/>
      <waypoint x="784" y="445"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_680090_103602" xmi:uuid="b68123d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="b64bffc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b64c00f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b657bcf0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b657be40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="b6589bd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6589d00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b6594830-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6594b00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692807297302_514665_103611" xmi:uuid="b67fac90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="b6718180-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b67182b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="b67ee230-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b67ee360-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="609" y="434" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="406" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807518015_981688_104256" xmi:uuid="b6cf9160-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692807520166_586224_104257"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_724657_372379"/>
      <target xmi:idref="_18_4_1_65b021e_1692807297302_732840_103612"/>
      <waypoint x="945" y="630"/>
      <waypoint x="945" y="529"/>
      <waypoint x="837" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_835033_103603" xmi:uuid="b6d04100-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="b6997230-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6997360-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="b6a5afc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6a5b0f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b6a68400-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6a68550-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b6a740a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6a741c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692807297302_732840_103612" xmi:uuid="b6cebd60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="b6c078d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6c079f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="b6cdc770-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6cdc9d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="609" y="518" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="490" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_684446_103604" xmi:uuid="b701d360-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="b6e7f270-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b6e7f3a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692807297302_985193_103613" xmi:uuid="b701c6f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b700c300-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b700c410-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="599" y="662" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="581" y="671" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="371" y="658" width="225" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_261469_103605" xmi:uuid="b7338d00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="b719f860-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b719f990-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692807297302_110280_103615" xmi:uuid="b7338150-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="b732ab50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b732ac80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="545" y="708" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="527" y="717" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="371" y="707" width="171" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807523902_646424_104275" xmi:uuid="b780e800-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692807525702_721644_104276"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_724657_372379"/>
      <target xmi:idref="_18_4_1_65b021e_1692807297302_270141_103617"/>
      <waypoint x="945" y="630"/>
      <waypoint x="945" y="606"/>
      <waypoint x="793" y="606"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807297301_320615_103606" xmi:uuid="b7818630-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="b74bc980-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b74bcab0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="b758d6e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b758d810-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="b759b730-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b759b8a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b75a9700-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b75a9830-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692807297302_270141_103617" xmi:uuid="b7801170-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="b7727fa0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7728140-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="b77f3b50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b77f3c70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="609" y="595" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="595" y="567" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807343952_871096_104097" xmi:uuid="b78197b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692807344883_867908_104098"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_783402_372386"/>
      <target xmi:idref="_18_4_1_65b021e_1692807297301_726367_103608"/>
      <waypoint x="609" y="224"/>
      <waypoint x="516" y="224"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807450040_582275_104127" xmi:uuid="b781a630-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692807451893_586084_104128"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_242214_372380"/>
      <target xmi:idref="_18_4_1_65b021e_1692807297302_985193_103613"/>
      <waypoint x="931" y="679"/>
      <waypoint x="596" y="679"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692807455297_201998_104149" xmi:uuid="b781b440-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692807456514_874582_104150"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_317806_372390"/>
      <target xmi:idref="_18_4_1_65b021e_1692807297302_110280_103615"/>
      <waypoint x="651" y="725"/>
      <waypoint x="542" y="725"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1245" height="869"/>
    <name>ProcessPlanRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564034781_200657_180154" xmi:uuid="ef4c6380-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977013_677082_164248"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025951_43746_371857" xmi:uuid="ef4f32d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035082_680606_180255"/>
      <ownedElement xmi:id="b7941ad0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7941e60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035082_680606_180255"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="b796a300-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b796b0c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035082_680606_180255"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025951_684953_371858" xmi:uuid="b7a65ff0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="b7a51bb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7a51d10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="240" y="83" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="222" y="92" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="84" width="195" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025951_409048_371860" xmi:uuid="ef4f8140-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035075_231139_180253"/>
      <ownedElement xmi:id="b7b43540-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7b436a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035075_231139_180253"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="b7b6c800-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7b6c950-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035075_231139_180253"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="166" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025951_634229_371861" xmi:uuid="ef4fcd40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035065_846766_180251"/>
      <ownedElement xmi:id="b7c4a700-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7c4a830-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035065_846766_180251"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="b7c6f990-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7c6fac0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035065_846766_180251"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="376" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_848642_371862" xmi:uuid="ef5018b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035071_399709_180252"/>
      <ownedElement xmi:id="b7d57ac0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7d57bf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035071_399709_180252"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="b7d7cc20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7d7cd40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035071_399709_180252"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="495" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_654085_371863" xmi:uuid="ef506410-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035086_189889_180256"/>
      <ownedElement xmi:id="b7dea140-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7dea260-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035086_189889_180256"/>
        <text>ProducedOutputs:PartVersion</text>
      </ownedElement>
      <ownedElement xmi:id="b7e0f4d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7e0f730-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035086_189889_180256"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_824163_371864" xmi:uuid="b7e70e00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1568800466835_94616_62470"/>
        <ownedElement xmi:id="b7e62600-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7e62730-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1568800466835_94616_62470"/>
          <bounds x="258" y="680" width="143" height="13"/>
          <text>partVersion : Part_version [1]</text>
        </ownedElement>
        <bounds x="240" y="689" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="686" width="213" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_862240_371866" xmi:uuid="ef50b200-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035078_687650_180254"/>
      <ownedElement xmi:id="b7f51860-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7f51990-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035078_687650_180254"/>
        <text>VersionId:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="b7f77b00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b7f77c40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035078_687650_180254"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="747" width="189" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_200985_371867" xmi:uuid="ef50fe40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035090_810082_180257"/>
      <ownedElement xmi:id="b8059710-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b8059840-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035090_810082_180257"/>
        <text>process_plan:Process_plan</text>
      </ownedElement>
      <ownedElement xmi:id="b8081360-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b8081490-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035090_810082_180257"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="b808fc80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b808fec0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="b809b880-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b809c080-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_527694_371868" xmi:uuid="b830c750-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-description"/>
          <ownedElement xmi:id="b8232360-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b82324b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-description"/>
            <text>description:text</text>
          </ownedElement>
          <ownedElement xmi:id="b82fc910-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b82fca90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1274" y="133" width="135" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_871216_371869" xmi:uuid="b85791d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-name"/>
          <ownedElement xmi:id="b8498e50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b8498f80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-name"/>
            <text>name:label</text>
          </ownedElement>
          <ownedElement xmi:id="b856ab60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b856ac90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-name"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1274" y="462" width="108" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_21105_371870" xmi:uuid="b87e3af0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-plan_id"/>
          <ownedElement xmi:id="b8704bb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b8704cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-plan_id"/>
            <text>plan_id:identifier</text>
          </ownedElement>
          <ownedElement xmi:id="b87d71d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b87d7300-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-plan_id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1274" y="364" width="128" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_99806_371871" xmi:uuid="b8a4cf70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-produced_output"/>
          <ownedElement xmi:id="b896ed80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b896ee90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-produced_output"/>
            <text>produced_output:Part_version</text>
          </ownedElement>
          <ownedElement xmi:id="b8a3d940-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b8a3da70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-produced_output"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1274" y="686" width="214" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_517119_371872" xmi:uuid="b8cab3d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-version_id"/>
          <ownedElement xmi:id="b8bcbb90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b8bcbcb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-version_id"/>
            <text>version_id:identifier</text>
          </ownedElement>
          <ownedElement xmi:id="b8c9fa80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b8c9fe80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_plan-version_id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1274" y="735" width="159" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1253" y="42" width="242" height="728"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_846459_371873" xmi:uuid="ef514b20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035095_735499_180258"/>
      <ownedElement xmi:id="b8d933b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b8d934d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035095_735499_180258"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_914982_371874" xmi:uuid="b8e8c680-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="b8e7f980-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b8e7fc90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="523" y="181" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="505" y="190" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_966597_371876" xmi:uuid="b8f637f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b8f57410-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b8f57540-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="523" y="132" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="505" y="141" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_245136_371878" xmi:uuid="b9041750-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="b9033900-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9033a30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="528" y="242" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="505" y="253" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_678467_371880" xmi:uuid="b911fcf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="b9110850-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9110970-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="247" y="162" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="301" y="171" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="133" width="219" height="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_659028_371882" xmi:uuid="ef5196d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035098_114027_180259"/>
      <ownedElement xmi:id="b91fea70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b91feb90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035098_114027_180259"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_390784_371883" xmi:uuid="b92f5220-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="b92e9df0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b92e9f20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="451" y="413" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="433" y="422" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_71541_371885" xmi:uuid="b93d28f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="b93c3470-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b93c35a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="451" y="360" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="433" y="369" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_17209_371887" xmi:uuid="b94a95a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="b9499240-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9499360-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="247" y="372" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="301" y="381" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="357" width="147" height="84"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_702219_371889" xmi:uuid="ef51e1c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035101_589690_180260"/>
      <ownedElement xmi:id="b9593b10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9593c40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035101_589690_180260"/>
        <text>selectDescription1:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_137219_371890" xmi:uuid="b968bed0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="b967d2b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b967d3e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="529" y="510" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="511" y="519" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_482874_371892" xmi:uuid="b9767360-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="b9759eb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9759fe0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="529" y="461" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="511" y="470" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_223528_371894" xmi:uuid="b98430c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="b9835a80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9835bb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="534" y="569" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="511" y="580" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_443993_371896" xmi:uuid="b99155f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="b990adf0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b990af20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="247" y="491" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="301" y="500" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="462" width="225" height="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_964623_371898" xmi:uuid="ef523060-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035105_232751_180261"/>
      <ownedElement xmi:id="b99fa3f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b99fa510-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035105_232751_180261"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="b9a20770-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9a208b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035105_232751_180261"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_597496_371899" xmi:uuid="b9b019b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="b9af42f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9af4410-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="707" y="175" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="787" y="195" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="189" width="165" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_455516_371901" xmi:uuid="ef527e80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035109_373837_180262"/>
      <ownedElement xmi:id="b9bde250-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9bde400-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035109_373837_180262"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="b9c05280-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9c053c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035109_373837_180262"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_29335_371902" xmi:uuid="b9ce0110-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="b9cd3dd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9cd4240-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="812" y="268" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="783" y="277" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="273" width="161" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025952_226988_371904" xmi:uuid="ef52c930-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035113_596855_180263"/>
      <ownedElement xmi:id="b9dbc300-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9dbc440-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035113_596855_180263"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="b9dddae0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9dddc10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035113_596855_180263"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_36718_371905" xmi:uuid="b9eb0720-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="b9ea23f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9ea2510-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="742" y="406" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="742" y="423" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="420" width="120" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_111534_371907" xmi:uuid="ef530f50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035117_690501_180264"/>
      <ownedElement xmi:id="b9f8f700-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9f8f830-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035117_690501_180264"/>
        <text>descriptors1:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="b9fb6860-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="b9fb6970-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035117_690501_180264"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_994170_371908" xmi:uuid="ba092b30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="ba085720-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba085860-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="707" y="497" width="65" height="13"/>
          <text>descAsgn [1]</text>
        </ownedElement>
        <bounds x="793" y="517" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="511" width="171" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_801778_371910" xmi:uuid="ef535ae0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035121_579525_180265"/>
      <ownedElement xmi:id="ba16f780-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba16f870-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035121_579525_180265"/>
        <text>language1:Language</text>
      </ownedElement>
      <ownedElement xmi:id="ba193670-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba1937a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035121_579525_180265"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_344614_371911" xmi:uuid="ba275590-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="ba26b170-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba26b290-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="812" y="604" width="36" height="13"/>
          <text>lang [1]</text>
        </ownedElement>
        <bounds x="789" y="613" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="609" width="167" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_827688_402364" xmi:uuid="ba608710-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035035_11313_180210"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_200985_371867"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_441425_371914"/>
      <waypoint x="1253" y="102"/>
      <waypoint x="835" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_700622_371913" xmi:uuid="ef53be50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035129_310616_180267"/>
      <ownedElement xmi:id="ba351ba0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba351d40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035129_310616_180267"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ba37c950-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba37ca70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035129_310616_180267"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ba38a340-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba38a480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ba394c80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba394d80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_441425_371914" xmi:uuid="ba5fc550-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="ba51e0b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba51e2b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ba5efb20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba5efc60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="651" y="91" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="637" y="63" width="207" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_757713_402365" xmi:uuid="ba9a34e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035038_594037_180215"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_200985_371867"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_75434_371916"/>
      <waypoint x="1253" y="200"/>
      <waypoint x="1134" y="200"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_169565_371915" xmi:uuid="ef543870-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035133_934699_180268"/>
      <ownedElement xmi:id="ba6f2f70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba6f30a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035133_934699_180268"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ba71aae0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba71ac10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035133_934699_180268"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ba72ac00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba72acf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ba734530-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba734600-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_75434_371916" xmi:uuid="ba995790-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="ba8b5630-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba8b5760-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="ba9869b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ba986ad0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="189" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="161" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_39749_402366" xmi:uuid="bb1575b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035032_497309_180207"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_492572_371921"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_64413_371918"/>
      <waypoint x="928" y="333"/>
      <waypoint x="959" y="333"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_139888_402367" xmi:uuid="bb177dd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035040_865514_180218"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_200985_371867"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_886013_371919"/>
      <waypoint x="1253" y="270"/>
      <waypoint x="1187" y="270"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_725380_371917" xmi:uuid="ef549af0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035137_479511_180269"/>
      <ownedElement xmi:id="baa908d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="baa90e30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035137_479511_180269"/>
        <text>li:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="baab6930-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="baab6a70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035137_479511_180269"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="baac60c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="baac64e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="baad1610-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="baad16f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_64413_371918" xmi:uuid="bac743c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="baba38e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="baba3a80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="bac63d30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bac63e50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="959" y="315" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_886013_371919" xmi:uuid="baee2680-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="bae00820-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bae00c80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="baed4a10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="baed4b30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="259" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_36065_371920" xmi:uuid="bb14c590-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="bb071850-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb071980-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="bb13cb00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb13ceb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="287" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="231" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_492572_371921" xmi:uuid="ef54e500-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035140_716352_180270"/>
      <ownedElement xmi:id="bb1aea50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb1aeb80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035140_716352_180270"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="bb1d5400-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb1d5530-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035140_716352_180270"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="714" y="322" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_699049_402368" xmi:uuid="bb5b77d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035044_842149_180223"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_200985_371867"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_986993_371923"/>
      <waypoint x="1253" y="431"/>
      <waypoint x="1142" y="431"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_880396_371922" xmi:uuid="ef553840-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035144_577162_180271"/>
      <ownedElement xmi:id="bb2ba5b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb2ba810-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035144_577162_180271"/>
        <text>ia:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bb2dee00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb2def30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035144_577162_180271"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="bb2ee720-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb2ee8b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bb2fa770-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb2fa910-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_986993_371923" xmi:uuid="bb5a9b10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="bb4add70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb4adf00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="bb598820-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb5989a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="420" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="385" width="249" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_654000_402369" xmi:uuid="bb984550-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035047_304525_180227"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_200985_371867"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_735568_371925"/>
      <waypoint x="1253" y="529"/>
      <waypoint x="1134" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_850800_371924" xmi:uuid="ef558060-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035147_543950_180272"/>
      <ownedElement xmi:id="bb6bf090-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb6bf300-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035147_543950_180272"/>
        <text>dta1:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bb6e5b40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb6e5cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035147_543950_180272"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="bb6f2230-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb6f2360-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bb700420-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb700580-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_735568_371925" xmi:uuid="bb979890-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="bb8963d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb896500-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="bb96ab30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bb96ac90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="518" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="490" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_31857_402370" xmi:uuid="bc10a990-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035033_5679_180208"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_725978_371930"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_673679_371927"/>
      <waypoint x="902" y="662"/>
      <waypoint x="959" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_845078_402371" xmi:uuid="bc127ae0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035048_670427_180228"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_200985_371867"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_777803_371928"/>
      <waypoint x="1253" y="599"/>
      <waypoint x="1187" y="599"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_365753_371926" xmi:uuid="ef55cad0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035151_481663_180273"/>
      <ownedElement xmi:id="bba56590-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bba56710-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035151_481663_180273"/>
        <text>li1:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="bba7ae50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bba7b110-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035151_481663_180273"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="bba87130-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bba87260-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bba92440-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bba92700-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_673679_371927" xmi:uuid="bbc29190-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="bbb58380-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bbb584b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="bbc1a350-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bbc1a480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="644" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_777803_371928" xmi:uuid="bbe934d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="bbdb3930-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bbdb3a60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="bbe84c20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bbe84d60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="588" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_527307_371929" xmi:uuid="bc0fc720-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="bc01d380-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc01d4b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="bc0ef7c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc0ef8f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="616" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="560" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_725978_371930" xmi:uuid="ef562b20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035154_534454_180274"/>
      <ownedElement xmi:id="bc160240-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc160380-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035154_534454_180274"/>
        <text>theAttribute1:String</text>
      </ownedElement>
      <ownedElement xmi:id="bc188b60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc1894d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035154_534454_180274"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="714" y="651" width="188" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_57406_371931" xmi:uuid="ef568640-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035158_283932_180275"/>
      <ownedElement xmi:id="bc26efb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc26f370-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035158_283932_180275"/>
        <text>selectId1:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_396333_371932" xmi:uuid="bc365200-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="bc357bb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc357ce0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="457" y="775" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="439" y="784" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_377100_371934" xmi:uuid="bc441520-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="bc433ad0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc433bf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="457" y="731" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="439" y="740" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_556858_371936" xmi:uuid="bc51ac20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="bc50d4d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc50d600-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="247" y="743" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="301" y="752" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="728" width="153" height="77"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_126490_371938" xmi:uuid="ef56d920-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035162_284720_180276"/>
      <ownedElement xmi:id="bc5ff830-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc5ff960-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035162_284720_180276"/>
        <text>ids1:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="bc625c10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc625f10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035162_284720_180276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025953_392539_371939" xmi:uuid="bc703b10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="bc6f5b40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc6f5c70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="742" y="763" width="49" height="13"/>
          <text>idAsgn [1]</text>
        </ownedElement>
        <bounds x="748" y="780" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="630" y="777" width="126" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_649912_402393" xmi:uuid="bca8f130-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035055_783826_180237"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_200985_371867"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025954_589793_371942"/>
      <waypoint x="1285" y="770"/>
      <waypoint x="1285" y="805"/>
      <waypoint x="1142" y="805"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025954_738109_371941" xmi:uuid="ef574c50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035166_66878_180277"/>
      <ownedElement xmi:id="bc7d7990-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc7d7ac0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035166_66878_180277"/>
        <text>ia1:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bc7ff320-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc7ff460-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035166_66878_180277"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="bc80dc20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc80dd60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bc81a740-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc81a880-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025954_589793_371942" xmi:uuid="bca83060-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="bc9a0de0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bc9a1070-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="bca76c00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bca76e70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="791" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="756" width="249" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025954_199385_371943" xmi:uuid="ef57aa30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035170_325974_180278"/>
      <ownedElement xmi:id="bcb83ea0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bcb83fd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035170_325974_180278"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025954_387929_371944" xmi:uuid="bcc7c740-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="bcc6f760-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bcc6f890-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="574" y="378" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="630" y="369" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025954_393481_371946" xmi:uuid="bcd5b760-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="bcd4d140-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bcd4d640-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="825" y="358" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="807" y="367" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="630" y="357" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_86612_402363" xmi:uuid="ef57b580-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035032_594982_180206"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_200985_371867"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025951_673809_371855"/>
      <waypoint x="1495" y="63"/>
      <waypoint x="1507" y="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_717996_402372" xmi:uuid="ef57bf50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035034_955762_180209"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_700622_371913"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025951_684953_371858"/>
      <waypoint x="637" y="98"/>
      <waypoint x="237" y="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_477009_402373" xmi:uuid="ef57c680-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035036_601897_180211"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_527694_371868"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_966597_371876"/>
      <waypoint x="1274" y="150"/>
      <waypoint x="520" y="150"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_85217_402374" xmi:uuid="ef57d2a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035036_666098_180212"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025951_409048_371860"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_678467_371880"/>
      <waypoint x="241" y="177"/>
      <waypoint x="301" y="177"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_941202_402375" xmi:uuid="ef57da20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035037_198848_180213"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_964623_371898"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_914982_371874"/>
      <waypoint x="630" y="196"/>
      <waypoint x="520" y="196"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_11075_402376" xmi:uuid="ef57e130-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035038_20658_180214"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_169565_371915"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_597496_371899"/>
      <waypoint x="945" y="203"/>
      <waypoint x="802" y="203"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_859897_402377" xmi:uuid="ef57e9a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035039_530354_180216"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_455516_371901"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_245136_371878"/>
      <waypoint x="630" y="287"/>
      <waypoint x="578" y="287"/>
      <waypoint x="578" y="259"/>
      <waypoint x="520" y="259"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_17402_402378" xmi:uuid="ef57f840-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035040_147848_180217"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_36065_371920"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_29335_371902"/>
      <waypoint x="963" y="287"/>
      <waypoint x="963" y="284"/>
      <waypoint x="798" y="284"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_183321_402379" xmi:uuid="ef57ffc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035041_440751_180219"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025954_387929_371944"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_71541_371885"/>
      <waypoint x="630" y="375"/>
      <waypoint x="448" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_443961_402380" xmi:uuid="ef5806e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035042_785941_180220"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025951_634229_371861"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_17209_371887"/>
      <waypoint x="168" y="387"/>
      <waypoint x="301" y="387"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_18276_402381" xmi:uuid="ef580fb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035043_10441_180221"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_226988_371904"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_390784_371883"/>
      <waypoint x="630" y="431"/>
      <waypoint x="448" y="431"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026826_353408_402382" xmi:uuid="ef584470-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035044_440011_180222"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_880396_371922"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_36718_371905"/>
      <waypoint x="945" y="431"/>
      <waypoint x="757" y="431"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_623209_402383" xmi:uuid="ef584c40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035045_863217_180224"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_871216_371869"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_482874_371892"/>
      <waypoint x="1274" y="475"/>
      <waypoint x="526" y="475"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_71404_402384" xmi:uuid="ef5854c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035046_82650_180225"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_111534_371907"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_137219_371890"/>
      <waypoint x="630" y="525"/>
      <waypoint x="526" y="525"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_778752_402385" xmi:uuid="ef585b40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035046_94838_180226"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_850800_371924"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_994170_371908"/>
      <waypoint x="945" y="525"/>
      <waypoint x="808" y="525"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_828731_402386" xmi:uuid="ef586440-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035049_23084_180229"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_527307_371929"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_344614_371911"/>
      <waypoint x="959" y="620"/>
      <waypoint x="804" y="620"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_238650_402387" xmi:uuid="ef5870a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035050_950834_180230"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_801778_371910"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_223528_371894"/>
      <waypoint x="630" y="623"/>
      <waypoint x="613" y="623"/>
      <waypoint x="613" y="588"/>
      <waypoint x="526" y="588"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_624992_402388" xmi:uuid="ef5877c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035050_803361_180231"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_848642_371862"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_443993_371896"/>
      <waypoint x="209" y="506"/>
      <waypoint x="301" y="506"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_407571_402389" xmi:uuid="ef587e80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035051_937686_180232"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_99806_371871"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025952_824163_371864"/>
      <waypoint x="1274" y="699"/>
      <waypoint x="255" y="699"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_157262_402390" xmi:uuid="ef5885e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035052_506000_180233"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_517119_371872"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_377100_371934"/>
      <waypoint x="1274" y="745"/>
      <waypoint x="454" y="745"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_331155_402391" xmi:uuid="ef588cc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035053_725797_180234"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_862240_371866"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_556858_371936"/>
      <waypoint x="224" y="758"/>
      <waypoint x="301" y="758"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_886542_402392" xmi:uuid="ef589700-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035053_154315_180235"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025953_126490_371938"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_396333_371932"/>
      <waypoint x="630" y="791"/>
      <waypoint x="454" y="791"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_187715_402394" xmi:uuid="ef589de0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035054_333160_180236"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025954_738109_371941"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025953_392539_371939"/>
      <waypoint x="945" y="788"/>
      <waypoint x="763" y="788"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_319965_402395" xmi:uuid="ef58a560-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035064_347453_180248"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025952_21105_371870"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025954_393481_371946"/>
      <waypoint x="1274" y="375"/>
      <waypoint x="822" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025951_673809_371855" xmi:uuid="ef58bea0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035125_626656_180266"/>
      <bounds x="1507" y="56" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1510" height="841"/>
    <name>ProcessPlan</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564035441_598001_180298" xmi:uuid="ef58db60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977020_902017_164253"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025958_100063_371972" xmi:uuid="ef5c0c60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035508_943519_180344"/>
      <ownedElement xmi:id="bce85420-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bce85560-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035508_943519_180344"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="bceae7c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bceae910-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035508_943519_180344"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025958_195461_371973" xmi:uuid="bcfa0a60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="bcf93890-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bcf939d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="240" y="48" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="222" y="57" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="49" width="195" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025958_951405_371975" xmi:uuid="ef5c8960-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035515_514140_180346"/>
      <ownedElement xmi:id="bd007390-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd0074c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035515_514140_180346"/>
        <text>ConcernedShapes:ShapeElement</text>
      </ownedElement>
      <ownedElement xmi:id="bd027f20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd028050-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035515_514140_180346"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025958_324376_371976" xmi:uuid="bd055c10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564320840_313424_218377"/>
        <ownedElement xmi:id="bd047ea0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd047fc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../ShapeAssociationAndStructure/ShapeAssociationAndStructure.xmi#_18_4_1_65b021e_1688564320840_313424_218377"/>
          <bounds x="275" y="93" width="169" height="13"/>
          <text>shapeElement : Shape_element [1]</text>
        </ownedElement>
        <bounds x="257" y="102" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="98" width="230" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025958_326432_371978" xmi:uuid="ef5ce8b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035504_51042_180343"/>
      <ownedElement xmi:id="bd134e00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd134f30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035504_51042_180343"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="bd15c980-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd15cab0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035504_51042_180343"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="161" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025958_979390_371979" xmi:uuid="ef5d4e80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035519_573277_180347"/>
      <ownedElement xmi:id="bd197fb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd1985e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035519_573277_180347"/>
        <text>Element:ProcessOperationInputOrOutputSelect</text>
      </ownedElement>
      <ownedElement xmi:id="bd1be6a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd1be7d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035519_573277_180347"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025958_690602_371980" xmi:uuid="bd1f3f40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037651_912713_180830"/>
        <ownedElement xmi:id="bd1e5ea0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd1e5fc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037651_912713_180830"/>
          <bounds x="348" y="384" width="420" height="13"/>
          <text>processOperationInputOrOutputSelect : process_operation_input_or_output_select [1]</text>
        </ownedElement>
        <bounds x="330" y="393" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="385" width="303" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_202213_371982" xmi:uuid="ef5dcc50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035523_690966_180348"/>
      <ownedElement xmi:id="bd230140-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd230270-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035523_690966_180348"/>
        <text>Operation:ProcessOperationOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="bd254600-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd254720-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035523_690966_180348"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_159620_371983" xmi:uuid="bd281760-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036755_642051_180628"/>
        <ownedElement xmi:id="bd275ad0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd275bf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036755_642051_180628"/>
          <bounds x="309" y="427" width="326" height="13"/>
          <text>processOperationOccurrence : Process_operation_occurrence [1]</text>
        </ownedElement>
        <bounds x="291" y="436" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="434" width="264" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_113762_371985" xmi:uuid="ef5e3cc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035527_664209_180349"/>
      <ownedElement xmi:id="bd2be7e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd2beb40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035527_664209_180349"/>
        <text>Placement:GeometricRepresentationRelationshipWithPlacementTransformation</text>
      </ownedElement>
      <ownedElement xmi:id="bd2e6de0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd2e6f10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035527_664209_180349"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_628499_371986" xmi:uuid="d72f1220-4103-013c-1d92-21143cc57b19" xmi:type="umldi:UMLShape">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_271a0567_1572007879181_460753_51841"/>
        <ownedElement xmi:id="d72dfec0-4103-013c-1d92-21143cc57b19" xmi:uuid="d72dffd0-4103-013c-1d92-21143cc57b19" xmi:type="umldi:UMLLabel">
          <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_271a0567_1572007879181_460753_51841"/>
          <bounds x="539" y="482" width="452" height="13"/>
          <text>geoRepRelWithPlacementTrans : Geometric_composition_with_placement_transformation [1]</text>
        </ownedElement>
        <bounds x="522" y="493" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="490" width="495" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_252032_371988" xmi:uuid="ef5e91a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035511_163399_180345"/>
      <ownedElement xmi:id="bd3f9900-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd3f9a30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035511_163399_180345"/>
        <text>Role:ClassSelect</text>
      </ownedElement>
      <ownedElement xmi:id="bd41c5c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd41c6e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035511_163399_180345"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="581" width="128" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_431692_371989" xmi:uuid="ef5ee170-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035530_835013_180350"/>
      <ownedElement xmi:id="bd4fe040-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd4fe180-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035530_835013_180350"/>
        <text>process_operation_input_or_output:Process_operation_input_or_output</text>
      </ownedElement>
      <ownedElement xmi:id="bd523900-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd523a30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035530_835013_180350"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="bd5322a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd5324e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bd53c790-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd53c870-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_796431_371990" xmi:uuid="bd79db80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-concerned_shape"/>
          <ownedElement xmi:id="bd6c1ea0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd6c1fc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-concerned_shape"/>
            <text>concerned_shape:Shape_element</text>
          </ownedElement>
          <ownedElement xmi:id="bd78f6c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd78f900-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-concerned_shape"/>
            <text>[0..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1295" y="99" width="234" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_358669_371991" xmi:uuid="bda0e640-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-description"/>
          <ownedElement xmi:id="bd927aa0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd927bc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-description"/>
            <text>description:text</text>
          </ownedElement>
          <ownedElement xmi:id="bd9ffda0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bd9fffc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1295" y="155" width="135" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_938338_371992" xmi:uuid="bdc7afb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-element"/>
          <ownedElement xmi:id="bdb93ea0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bdb93fe0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-element"/>
            <text>element:process_operation_input_or_output_select</text>
          </ownedElement>
          <ownedElement xmi:id="bdc6ef00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bdc6f030-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-element"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1295" y="386" width="324" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_560077_371993" xmi:uuid="bdef4a30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-operation"/>
          <ownedElement xmi:id="bde193f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bde19520-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-operation"/>
            <text>operation:Process_operation_occurrence</text>
          </ownedElement>
          <ownedElement xmi:id="bdee8630-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bdee8760-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-operation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1295" y="435" width="266" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_452065_371994" xmi:uuid="be0b1000-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-role"/>
          <ownedElement xmi:id="bdfca640-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bdfca790-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="be0a0770-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="be0a08a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1295" y="553" width="94" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_573040_371995" xmi:uuid="be316680-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-placement"/>
          <ownedElement xmi:id="be2367c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="be2368f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-placement"/>
            <text>placement:Geometric_relationship_with_placement_transformation</text>
          </ownedElement>
          <ownedElement xmi:id="be308970-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="be308ab0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_input_or_output-placement"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1302" y="490" width="422" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1281" y="42" width="450" height="546"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_855000_371996" xmi:uuid="ef5f3060-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035539_228761_180352"/>
      <ownedElement xmi:id="be3fbbc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="be3fbcf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035539_228761_180352"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_525134_371997" xmi:uuid="be4f3170-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="be4e4a70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="be4e4ba0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="576" y="187" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="558" y="196" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_873325_371999" xmi:uuid="be5c3520-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="be5b7060-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="be5b71a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="576" y="146" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="558" y="155" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_680035_372001" xmi:uuid="be696d60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="be68bec0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="be68bff0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="580" y="270" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="558" y="276" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_631277_372003" xmi:uuid="be772450-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="be763590-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="be7636a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="275" y="163" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="329" y="172" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="329" y="147" width="244" height="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_186058_372005" xmi:uuid="ef5f7ec0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035542_98369_180353"/>
      <ownedElement xmi:id="be85a1e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="be85a2f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035542_98369_180353"/>
        <text>selectClass:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_736967_372006" xmi:uuid="be9513e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="be944e70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="be944f90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="526" y="554" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="508" y="563" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025959_622217_372008" xmi:uuid="bea30420-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
        <ownedElement xmi:id="bea216f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bea21830-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
          <bounds x="275" y="581" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="329" y="590" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_278005_372010" xmi:uuid="beb037b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
        <ownedElement xmi:id="beaf7240-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="beaf7370-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
          <bounds x="526" y="601" width="54" height="13"/>
          <text>class [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="508" y="610" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="329" y="553" width="194" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_638004_402409" xmi:uuid="beea4650-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035492_198313_180324"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_431692_371989"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_316358_372013"/>
      <waypoint x="1281" y="74"/>
      <waypoint x="1171" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_915363_372012" xmi:uuid="ef5fcc10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035545_33885_180354"/>
      <ownedElement xmi:id="bebe5410-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bebe5660-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035545_33885_180354"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bec0b2b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bec0b3f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035545_33885_180354"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="bec1a120-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bec1a250-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bec25640-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bec25720-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_316358_372013" xmi:uuid="bee96230-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="bedafb40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bedafc60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="bee87f00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bee88040-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="987" y="63" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="973" y="35" width="265" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_603730_402410" xmi:uuid="bf24f610-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035495_824236_180329"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_431692_371989"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_394007_372015"/>
      <waypoint x="1281" y="221"/>
      <waypoint x="1162" y="221"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_184096_372014" xmi:uuid="ef601960-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035548_678445_180355"/>
      <ownedElement xmi:id="bef8aeb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bef8aff0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035548_678445_180355"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="befac3d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="befaca10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035548_678445_180355"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="befba570-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="befba6b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="befc5410-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="befc5560-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_394007_372015" xmi:uuid="bf241080-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="bf151c20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf151d50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="bf2312d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf231460-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="987" y="210" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="973" y="182" width="265" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_531639_402411" xmi:uuid="bfa14340-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035490_206985_180321"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_51847_372020"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_113567_372017"/>
      <waypoint x="956" y="347"/>
      <waypoint x="987" y="347"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_582515_402412" xmi:uuid="bfa30050-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035496_662033_180332"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_431692_371989"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_368400_372018"/>
      <waypoint x="1281" y="291"/>
      <waypoint x="1215" y="291"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_954692_372016" xmi:uuid="ef6067e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035551_264029_180356"/>
      <ownedElement xmi:id="bf33e550-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf33e9c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035551_264029_180356"/>
        <text>li:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="bf369430-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf369a30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035551_264029_180356"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="bf37b460-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf37b5a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bf38a300-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf38a430-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_113567_372017" xmi:uuid="bf528ca0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="bf452fa0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf4530d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="bf5183e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf518500-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="987" y="336" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_368400_372018" xmi:uuid="bf79c5f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="bf6b8370-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf6b84b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="bf78fcb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf78fde0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="987" y="280" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_974567_372019" xmi:uuid="bfa07470-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="bf928330-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf928450-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="bf9faa60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bf9fab90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="987" y="308" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="973" y="252" width="265" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_51847_372020" xmi:uuid="ef60b5d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035555_577218_180357"/>
      <ownedElement xmi:id="bfa62a00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bfa62b40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035555_577218_180357"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="bfa88e20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bfa88f60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035555_577218_180357"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="742" y="336" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_352268_402413" xmi:uuid="c0244b10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035501_663457_180338"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_431692_371989"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_901347_372023"/>
      <waypoint x="1502" y="588"/>
      <waypoint x="1502" y="648"/>
      <waypoint x="1171" y="648"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_910362_372021" xmi:uuid="ef610bd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035559_691607_180358"/>
      <ownedElement xmi:id="bfb6cc90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bfb6cda0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035559_691607_180358"/>
        <text>ca1:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="bfb930f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bfb934d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035559_691607_180358"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="bfb9f270-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bfb9f370-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="bfbaed50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bfbaee90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_185700_372022" xmi:uuid="bfe19100-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="bfd43e20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bfd43f40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="bfe0a280-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bfe0a480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="987" y="609" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_901347_372023" xmi:uuid="c0088220-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="bffa3a70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="bffa3ba0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c0079ad0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0079c00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="987" y="637" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_775054_372024" xmi:uuid="c0239cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="c015c4a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c015c5c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="c022be50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c022bf60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="987" y="665" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="973" y="581" width="265" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_926809_372025" xmi:uuid="ef617be0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035563_424285_180359"/>
      <ownedElement xmi:id="c0273450-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0273590-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035563_424285_180359"/>
        <text>theClassificationRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="c0299b20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0299db0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035563_424285_180359"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="742" y="665" width="222" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_880192_372026" xmi:uuid="ef6235b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035568_816339_180360"/>
      <ownedElement xmi:id="c0374600-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0374730-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035568_816339_180360"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="c039b640-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c039b770-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035568_816339_180360"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_509569_372027" xmi:uuid="c047c030-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="c046d220-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c046d350-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="735" y="175" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="829" y="195" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="665" y="189" width="172" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_113774_372029" xmi:uuid="ef629e20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035571_609680_180361"/>
      <ownedElement xmi:id="c055b310-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c055b440-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035571_609680_180361"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="c0582370-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c05824a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035571_609680_180361"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_9105_372030" xmi:uuid="c066c170-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="c065df20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c065e290-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="837" y="302" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="819" y="311" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="665" y="308" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_202164_372034" xmi:uuid="ef6308e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035575_855790_180362"/>
      <ownedElement xmi:id="c0746780-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c07468b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035575_855790_180362"/>
        <text>defaultRole:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_509040_372035" xmi:uuid="c083ee40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="c0831b90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0831ca0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="616" y="574" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="672" y="565" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_483118_372037" xmi:uuid="c091c470-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="c090b470-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c090b5a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="869" y="554" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="851" y="563" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="672" y="553" width="194" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_698577_402407" xmi:uuid="ef631ac0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035488_323759_180319"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_796431_371990"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025958_324376_371976"/>
      <waypoint x="1295" y="109"/>
      <waypoint x="272" y="109"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_776429_402408" xmi:uuid="ef6323d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035489_612758_180320"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_431692_371989"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_842761_372032"/>
      <waypoint x="1731" y="67"/>
      <waypoint x="1748" y="67"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_753148_402414" xmi:uuid="ef632cd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035490_786869_180322"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_775054_372024"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_926809_372025"/>
      <waypoint x="987" y="677"/>
      <waypoint x="964" y="677"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_504195_402415" xmi:uuid="ef6334a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035491_953531_180323"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_915363_372012"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025958_195461_371973"/>
      <waypoint x="973" y="63"/>
      <waypoint x="237" y="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_11594_402416" xmi:uuid="ef634360-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035492_546968_180325"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025958_326432_371978"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025959_631277_372003"/>
      <waypoint x="241" y="179"/>
      <waypoint x="329" y="179"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_666590_402417" xmi:uuid="ef634c10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035493_31364_180326"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_358669_371991"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025959_873325_371999"/>
      <waypoint x="1295" y="165"/>
      <waypoint x="573" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_275026_402418" xmi:uuid="ef635480-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035493_166183_180327"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_880192_372026"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025959_525134_371997"/>
      <waypoint x="665" y="203"/>
      <waypoint x="573" y="203"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_820367_402419" xmi:uuid="ef635be0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035494_286736_180328"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_184096_372014"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_509569_372027"/>
      <waypoint x="973" y="203"/>
      <waypoint x="844" y="203"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_731692_402420" xmi:uuid="ef636b30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035495_975757_180330"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_113774_372029"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025959_680035_372001"/>
      <waypoint x="665" y="319"/>
      <waypoint x="644" y="319"/>
      <waypoint x="644" y="284"/>
      <waypoint x="573" y="284"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_570697_402421" xmi:uuid="ef637490-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035496_546192_180331"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_974567_372019"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_9105_372030"/>
      <waypoint x="987" y="319"/>
      <waypoint x="834" y="319"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_441580_402422" xmi:uuid="ef637cb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035497_328524_180333"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_560077_371993"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025959_159620_371983"/>
      <waypoint x="1295" y="446"/>
      <waypoint x="306" y="446"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_563269_402423" xmi:uuid="ef638e60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035498_381417_180334"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_509040_372035"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025959_736967_372006"/>
      <waypoint x="672" y="571"/>
      <waypoint x="523" y="571"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_726276_402424" xmi:uuid="ef639600-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035498_490346_180335"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_185700_372022"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_278005_372010"/>
      <waypoint x="987" y="620"/>
      <waypoint x="523" y="620"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_808769_402425" xmi:uuid="ef639eb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035499_715216_180336"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_252032_371988"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025959_622217_372008"/>
      <waypoint x="163" y="599"/>
      <waypoint x="329" y="599"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_429764_402426" xmi:uuid="ef63a670-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035500_130944_180337"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_573040_371995"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025959_628499_371986"/>
      <waypoint x="1302" y="501"/>
      <waypoint x="537" y="501"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_284817_402427" xmi:uuid="ef63adc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035502_957050_180339"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_938338_371992"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025958_690602_371980"/>
      <waypoint x="1295" y="403"/>
      <waypoint x="345" y="403"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_587591_402428" xmi:uuid="ef63bec0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035504_522921_180341"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025959_452065_371994"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_483118_372037"/>
      <waypoint x="1295" y="571"/>
      <waypoint x="866" y="571"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_842761_372032" xmi:uuid="ef63d590-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035535_842557_180351"/>
      <bounds x="1748" y="61" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1751" height="715"/>
    <name>ProcessOperationInputOrOutput</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564036520_660277_180537" xmi:uuid="ef63fdc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977027_160504_164257"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_707608_372165" xmi:uuid="ef660c70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564034414_631087_180130"/>
      <ownedElement xmi:id="c0a409e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0a40b00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564034414_631087_180130"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="c0a66e80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0a66fc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564034414_631087_180130"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_150834_372166" xmi:uuid="c0b404e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="c0b33540-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0b338c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="245" y="51" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="227" y="60" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="49" width="200" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_900596_372168" xmi:uuid="ef667280-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036739_399581_180624"/>
      <ownedElement xmi:id="c0b7cda0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0b7ceb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036739_399581_180624"/>
        <text>DefinedIn:GeometricCoordinateSpace</text>
      </ownedElement>
      <ownedElement xmi:id="c0ba6130-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0ba6230-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036739_399581_180624"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_288490_372169" xmi:uuid="daa62980-4103-013c-1d92-21143cc57b19" xmi:type="umldi:UMLShape">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_271a0567_1572433726734_268610_49746"/>
        <ownedElement xmi:id="daa497b0-4103-013c-1d92-21143cc57b19" xmi:uuid="daa49960-4103-013c-1d92-21143cc57b19" xmi:type="umldi:UMLLabel">
          <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_271a0567_1572433726734_268610_49746"/>
          <bounds x="307" y="107" width="248" height="13"/>
          <text>geoCoordSpace : Geometric_coordinate_space [1]</text>
        </ownedElement>
        <bounds x="289" y="116" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="112" width="262" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_159556_372171" xmi:uuid="ef66f5f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036742_388749_180625"/>
      <ownedElement xmi:id="c0c13b40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0c13c60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036742_388749_180625"/>
        <text>Definition:ProcessOperationDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="c0c386c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0c387f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036742_388749_180625"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_739196_372172" xmi:uuid="c0c68d00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036253_675475_180508"/>
        <ownedElement xmi:id="c0c5d0d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0c5d210-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036253_675475_180508"/>
          <bounds x="295" y="155" width="297" height="13"/>
          <text>processOperationDefinition : Process_operation_definition [1]</text>
        </ownedElement>
        <bounds x="277" y="164" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="161" width="250" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_403545_372174" xmi:uuid="ef6746a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036735_974126_180623"/>
      <ownedElement xmi:id="c0d462d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0d463f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036735_974126_180623"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="c0d6e3b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0d6e4f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036735_974126_180623"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="369" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_569828_372175" xmi:uuid="ef6794f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036731_602394_180622"/>
      <ownedElement xmi:id="c0e4f850-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0e4f980-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036731_602394_180622"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="c0e75ce0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0e75e00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036731_602394_180622"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="518" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_970294_372176" xmi:uuid="ef67e080-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036746_63991_180626"/>
      <ownedElement xmi:id="c0eb3360-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0eb3480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036746_63991_180626"/>
        <text>Plan:ProcessPlan</text>
      </ownedElement>
      <ownedElement xmi:id="c0edabf0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0edad10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036746_63991_180626"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_269775_372177" xmi:uuid="c0f12ce0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035125_626656_180266"/>
        <ownedElement xmi:id="c0f048d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0f04a60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035125_626656_180266"/>
          <bounds x="183" y="625" width="153" height="13"/>
          <text>processPlan : Process_plan [1]</text>
        </ownedElement>
        <bounds x="165" y="634" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="630" width="138" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_309349_372179" xmi:uuid="ef682c90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036750_982795_180627"/>
      <ownedElement xmi:id="c0ff8120-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c0ff8370-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036750_982795_180627"/>
        <text>process_operation_occurrence:Process_operation_occurrence</text>
      </ownedElement>
      <ownedElement xmi:id="c1020f30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c1021050-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036750_982795_180627"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="c1030af0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c1030c20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c103bf70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c103c090-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_984_372180" xmi:uuid="c11ed160-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-id"/>
          <ownedElement xmi:id="c1111130-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c11114c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="c11dd490-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c11dd5c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1288" y="512" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_616142_372181" xmi:uuid="c14598c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-operation_definition"/>
          <ownedElement xmi:id="c137a140-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c137a260-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-operation_definition"/>
            <text>operation_definition:Process_operation_definition</text>
          </ownedElement>
          <ownedElement xmi:id="c144a350-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c144a480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-operation_definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1288" y="161" width="313" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_512754_372182" xmi:uuid="c16b7020-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-plan"/>
          <ownedElement xmi:id="c15db000-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c15db130-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-plan"/>
            <text>plan:Process_plan</text>
          </ownedElement>
          <ownedElement xmi:id="c16a97d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c16a9910-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-plan"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1288" y="631" width="137" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_714023_372183" xmi:uuid="c1928ac0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-is_defined_in"/>
          <ownedElement xmi:id="c1844400-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c1844520-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-is_defined_in"/>
            <text>is_defined_in:Geometric_coordinate_space</text>
          </ownedElement>
          <ownedElement xmi:id="c191ab70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c191adc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_occurrence-is_defined_in"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1288" y="112" width="287" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1267" y="35" width="387" height="631"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_19034_372184" xmi:uuid="ef6876e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036760_706463_180629"/>
      <ownedElement xmi:id="c1a128d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c1a129d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036760_706463_180629"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_628820_372185" xmi:uuid="c1b0b8a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="c1afd980-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c1afdb10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="538" y="418" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="520" y="427" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_225951_372187" xmi:uuid="c1bf0100-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="c1bdf900-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c1bdfa30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="538" y="356" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="520" y="365" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_431852_372189" xmi:uuid="c1cc97a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="c1cbb390-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c1cbb4c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="445" y="334" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="435" y="350" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_315184_372191" xmi:uuid="c1daa750-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="c1d9d2f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c1d9d420-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="247" y="365" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="301" y="374" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="350" width="234" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_705947_372193" xmi:uuid="ef68c3f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036763_763871_180630"/>
      <ownedElement xmi:id="c1e8b840-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c1e8b970-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036763_763871_180630"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_32019_372194" xmi:uuid="c1f7d720-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="c1f6de60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c1f6df90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="451" y="565" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="433" y="574" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_672678_372196" xmi:uuid="c205cba0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="c204d540-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c204d680-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="451" y="507" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="433" y="516" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_813466_372198" xmi:uuid="c213a6a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="c212ca00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c212cb30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="247" y="514" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="301" y="523" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="504" width="147" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_982666_372200" xmi:uuid="ef695400-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036767_276613_180631"/>
      <ownedElement xmi:id="c2218e60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2218f90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036767_276613_180631"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="c2240bf0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2240d30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036767_276613_180631"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_557186_372201" xmi:uuid="c231b880-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="c230eca0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c230edd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="707" y="406" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="801" y="426" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="637" y="420" width="172" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_707836_372203" xmi:uuid="ef69bd70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036771_338296_180632"/>
      <ownedElement xmi:id="c23f4f20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c23f5050-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036771_338296_180632"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="c241ab40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c241ac80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036771_338296_180632"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_671889_372204" xmi:uuid="c24f47c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="c24e6470-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c24e66b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="532" y="294" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="510" y="283" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="357" y="280" width="161" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_207411_372206" xmi:uuid="ef6a2420-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036774_215616_180633"/>
      <ownedElement xmi:id="c25cfcf0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c25d0170-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036774_215616_180633"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="c25f84b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c25f85e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036774_215616_180633"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_172893_372207" xmi:uuid="c26dcf70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="c26cf7d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c26cf940-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="735" y="553" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="742" y="576" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="637" y="567" width="113" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_16704_402475" xmi:uuid="c2a92d80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036722_621554_180609"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_309349_372179"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_221241_372210"/>
      <waypoint x="1267" y="74"/>
      <waypoint x="1143" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_643129_372209" xmi:uuid="ef6a84b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036778_967788_180634"/>
      <ownedElement xmi:id="c27c0150-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c27c02c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036778_967788_180634"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c27e7bb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c27e7ce0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036778_967788_180634"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c27f6720-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c27f69a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c28030c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c28031e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_221241_372210" xmi:uuid="c2a7f2e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c299c8c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c299c9f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c2a6e760-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2a6ed30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="63" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="35" width="266" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_156138_402476" xmi:uuid="c2e130c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036714_561205_180599"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_309349_372179"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_918423_372212"/>
      <waypoint x="1267" y="452"/>
      <waypoint x="1134" y="452"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_16222_372211" xmi:uuid="ef6ae8f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036781_467935_180635"/>
      <ownedElement xmi:id="c2b85960-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2b85a90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036781_467935_180635"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c2bac150-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2bac280-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036781_467935_180635"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c2bb9860-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2bb99a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c2bc5b10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2bc5e60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_918423_372212" xmi:uuid="c2e078a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="c2d3e070-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2d3e1a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="c2dfc760-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2dfc890-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="441" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="413" width="266" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_813310_402477" xmi:uuid="c35cc9b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036708_691743_180590"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_548365_372217"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_246936_372214"/>
      <waypoint x="620" y="263"/>
      <waypoint x="651" y="263"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_996077_402478" xmi:uuid="c35e16e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036716_153998_180602"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_396775_372220"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_934461_372215"/>
      <waypoint x="945" y="235"/>
      <waypoint x="879" y="235"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_902845_372213" xmi:uuid="ef6b42a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036785_34652_180636"/>
      <ownedElement xmi:id="c2ef2cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2ef35b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036785_34652_180636"/>
        <text>li:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="c2f1b920-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2f1ba50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036785_34652_180636"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="c2f29070-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2f29180-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c2f32e30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c2f32ef0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_246936_372214" xmi:uuid="c30eab00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="c300c880-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c300ca60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="c30de7a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c30de8c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="651" y="252" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_934461_372215" xmi:uuid="c3359540-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="c32772b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3277530-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="c334c460-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c334c850-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="651" y="224" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_200444_372216" xmi:uuid="c35bf070-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="c34e35a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c34e36c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="c35af600-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c35af720-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="651" y="280" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="637" y="196" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_548365_372217" xmi:uuid="ef6b9c70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036789_860233_180637"/>
      <ownedElement xmi:id="c3615b30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3615c50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036789_860233_180637"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="c363d770-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c363d890-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036789_860233_180637"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="406" y="252" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_342890_402479" xmi:uuid="c39e1d60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036720_775514_180606"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_309349_372179"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_605933_372219"/>
      <waypoint x="1267" y="598"/>
      <waypoint x="1142" y="598"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_638705_372218" xmi:uuid="ef6bf9d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036792_218389_180638"/>
      <ownedElement xmi:id="c3720250-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3720380-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036792_218389_180638"/>
        <text>ia:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c374aa20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c374ab40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036792_218389_180638"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c375ad30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c375ae60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c3766f00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3767000-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_605933_372219" xmi:uuid="c39d62b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="c38f0bc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c38f0d00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c39c7f90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c39c8140-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="588" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="553" width="266" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_396775_372220" xmi:uuid="ef6c4dd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036795_729304_180639"/>
      <ownedElement xmi:id="c3ad4620-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3ad4750-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036795_729304_180639"/>
        <text>dt:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="c3afb690-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3afb7c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036795_729304_180639"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="c3b090c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3b091d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c3b17be0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3b17d10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_718559_372221" xmi:uuid="c3cbef20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="c3be84c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3be85f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="c3cb2990-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3cb2be0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="952" y="246" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="224" width="152" height="57"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_521537_402480" xmi:uuid="c42de4d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036711_862504_180595"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_309349_372179"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_739511_372223"/>
      <waypoint x="1267" y="375"/>
      <waypoint x="1134" y="375"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_886879_372222" xmi:uuid="ef6c9e10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036798_244465_180640"/>
      <ownedElement xmi:id="c3da46a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3da47c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036798_244465_180640"/>
        <text>dta1:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c3dcaf80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3dcb0b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036798_244465_180640"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="c3ddb210-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3ddb5d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c3de8cc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3de8db0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_739511_372223" xmi:uuid="c405fc70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="c3f7b4e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c3f7b970-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="c40547d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c4054970-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="364" width="175" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_825745_372224" xmi:uuid="c42d2bf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="c41f20f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c41f2230-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="c42c5a60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c42c5b80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="329" width="192" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="301" width="266" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_344772_372225" xmi:uuid="ef6cec50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036802_17023_180641"/>
      <ownedElement xmi:id="c43cfa60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c43cfb80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036802_17023_180641"/>
        <text>ds:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_579633_372226" xmi:uuid="c44c3a70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="c44b7bb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c44b7cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="569" y="507" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="623" y="516" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_435567_372228" xmi:uuid="c45a66d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="c4597cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c4597e00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="769" y="509" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="751" y="518" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="623" y="504" width="143" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_319631_402474" xmi:uuid="ef6cf6a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036707_457328_180589"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_309349_372179"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_736827_372230"/>
      <waypoint x="1654" y="74"/>
      <waypoint x="1666" y="74"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_864464_402481" xmi:uuid="ef6cfff0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036708_430989_180591"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_825745_372224"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_396775_372220"/>
      <waypoint x="1029" y="329"/>
      <waypoint x="1029" y="281"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_599221_402482" xmi:uuid="ef6d0f50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036709_713436_180592"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_616142_372181"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_739196_372172"/>
      <waypoint x="1288" y="172"/>
      <waypoint x="292" y="172"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_350860_402483" xmi:uuid="ef6d44a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036710_201509_180593"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_403545_372174"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_315184_372191"/>
      <waypoint x="241" y="382"/>
      <waypoint x="301" y="382"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_961281_402484" xmi:uuid="ef6d4cd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036710_857705_180594"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_718559_372221"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_225951_372187"/>
      <waypoint x="952" y="256"/>
      <waypoint x="931" y="256"/>
      <waypoint x="931" y="371"/>
      <waypoint x="535" y="371"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_350605_402485" xmi:uuid="ef6d5970-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036712_112158_180596"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_569828_372175"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_813466_372198"/>
      <waypoint x="168" y="529"/>
      <waypoint x="301" y="529"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_237366_402486" xmi:uuid="ef6d6180-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036713_777522_180597"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_982666_372200"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_628820_372185"/>
      <waypoint x="637" y="434"/>
      <waypoint x="535" y="434"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_21171_402487" xmi:uuid="ef6d69b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036713_295916_180598"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_16222_372211"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_557186_372201"/>
      <waypoint x="945" y="434"/>
      <waypoint x="816" y="434"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_616708_402488" xmi:uuid="ef6d71a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036715_792443_180600"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_707836_372203"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_431852_372189"/>
      <waypoint x="441" y="305"/>
      <waypoint x="441" y="350"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_958238_402489" xmi:uuid="ef6d7d90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036715_321015_180601"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_200444_372216"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_671889_372204"/>
      <waypoint x="651" y="291"/>
      <waypoint x="525" y="291"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_353486_402490" xmi:uuid="ef6d85f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036717_958045_180603"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_579633_372226"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_672678_372196"/>
      <waypoint x="623" y="522"/>
      <waypoint x="448" y="522"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_557027_402491" xmi:uuid="ef6d8db0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036718_134358_180604"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_207411_372206"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_32019_372194"/>
      <waypoint x="637" y="581"/>
      <waypoint x="448" y="581"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_231618_402492" xmi:uuid="ef6d95d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036719_553603_180605"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_638705_372218"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_172893_372207"/>
      <waypoint x="945" y="585"/>
      <waypoint x="757" y="585"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_983970_402493" xmi:uuid="ef6da040-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036721_804737_180607"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_512754_372182"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_269775_372177"/>
      <waypoint x="1288" y="641"/>
      <waypoint x="180" y="641"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_20610_402494" xmi:uuid="ef6da860-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036721_897167_180608"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_643129_372209"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_150834_372166"/>
      <waypoint x="945" y="67"/>
      <waypoint x="242" y="67"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_524162_402495" xmi:uuid="ef6db080-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036723_227766_180610"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_714023_372183"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_288490_372169"/>
      <waypoint x="1288" y="126"/>
      <waypoint x="304" y="126"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_379112_402496" xmi:uuid="ef6db7d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036724_695056_180611"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025962_984_372180"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025962_435567_372228"/>
      <waypoint x="1288" y="525"/>
      <waypoint x="766" y="525"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025962_736827_372230" xmi:uuid="ef6dd4f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036755_642051_180628"/>
      <bounds x="1666" y="65" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1669" height="681"/>
    <name>ProcessOperationOccurrence</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564038068_233215_180904" xmi:uuid="ef6df680-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977046_532260_164273"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_664171_372400" xmi:uuid="ef76f0e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038160_241569_180969"/>
      <ownedElement xmi:id="ef734640-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ef734730-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038160_241569_180969"/>
        <text>AssignedResource:ProcessOperationResourceAssignmentSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ef74df20-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ef74e010-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038160_241569_180969"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_228262_372401" xmi:uuid="ef76e5d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037201_795697_180724"/>
        <ownedElement xmi:id="ef76ca50-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ef76cb40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037201_795697_180724"/>
          <bounds x="452" y="877" width="375" height="13"/>
          <text>processOperationResourceAssignmentSelect : resource_definition_select [1]</text>
        </ownedElement>
        <bounds x="434" y="886" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="882" width="407" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_609798_372403" xmi:uuid="ef7e1a20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036811_661036_180647"/>
      <ownedElement xmi:id="ef7a3ad0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ef7a3bd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036811_661036_180647"/>
        <text>AssignedTo:ProcessOperationOccurrence</text>
      </ownedElement>
      <ownedElement xmi:id="ef7c0550-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ef7c0640-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036811_661036_180647"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_657956_372404" xmi:uuid="ef7e0fd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036755_642051_180628"/>
        <ownedElement xmi:id="ef7dc410-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="ef7dc520-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036755_642051_180628"/>
          <bounds x="322" y="917" width="326" height="13"/>
          <text>processOperationOccurrence : Process_operation_occurrence [1]</text>
        </ownedElement>
        <bounds x="304" y="926" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="924" width="277" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_828271_372411" xmi:uuid="efb53b10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038164_360264_180970"/>
      <ownedElement xmi:id="efb20e70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efb20f60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038164_360264_180970"/>
        <text>Placement:GeometricRepresentationRelationshipWithPlacementTransformation</text>
      </ownedElement>
      <ownedElement xmi:id="efb39ae0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efb39bd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038164_360264_180970"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_917258_372412" xmi:uuid="de2fa160-4103-013c-1d92-21143cc57b19" xmi:type="umldi:UMLShape">
        <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_271a0567_1572007879181_460753_51841"/>
        <ownedElement xmi:id="de2e8320-4103-013c-1d92-21143cc57b19" xmi:uuid="de2e8440-4103-013c-1d92-21143cc57b19" xmi:type="umldi:UMLLabel">
          <modelElement href="../RepresentationAndExternalElementReference/RepresentationAndExternalElementReference.xmi#_18_4_1_271a0567_1572007879181_460753_51841"/>
          <bounds x="539" y="979" width="452" height="13"/>
          <text>geoRepRelWithPlacementTrans : Geometric_composition_with_placement_transformation [1]</text>
        </ownedElement>
        <bounds x="522" y="989" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="980" width="495" height="27"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_839520_372414" xmi:uuid="efbbfaf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038169_663785_180971"/>
      <ownedElement xmi:id="efba55c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efba56c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038169_663785_180971"/>
        <text>Reason:LocalizedString</text>
      </ownedElement>
      <ownedElement xmi:id="efbbeb40-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efbbec30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038169_663785_180971"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="1090" width="175" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_559256_372415" xmi:uuid="efbf7e80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038173_696164_180972"/>
      <ownedElement xmi:id="efbd8a20-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efbd8bf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038173_696164_180972"/>
        <text>ReferenceTool:Boolean</text>
      </ownedElement>
      <ownedElement xmi:id="efbf6640-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efbf6730-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038173_696164_180972"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="35" y="1211" width="164" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_437389_372416" xmi:uuid="f056d660-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038176_420768_180973"/>
      <ownedElement xmi:id="efcaf8c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efcaf9c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038176_420768_180973"/>
        <text>process_operation_resource_assignment:Process_operation_resource_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="efcc9fd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efcca0c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038176_420768_180973"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="efccc970-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efccca20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="efcce000-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efcce0a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_664313_372417" xmi:uuid="efeccc50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-operation"/>
          <ownedElement xmi:id="efe23c00-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efe23cf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-operation"/>
            <text>operation:Process_operation_occurrence</text>
          </ownedElement>
          <ownedElement xmi:id="efecacb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="efecadd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-operation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1351" y="932" width="266" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_239768_372418" xmi:uuid="f002a480-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-reason"/>
          <ownedElement xmi:id="eff81530-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="eff81630-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-reason"/>
            <text>reason:String</text>
          </ownedElement>
          <ownedElement xmi:id="f00281c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f00282c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-reason"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1351" y="1044" width="123" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_334721_372419" xmi:uuid="f0185700-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-reference_tool"/>
          <ownedElement xmi:id="f00d6710-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f00d6810-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-reference_tool"/>
            <text>reference_tool:Boolean</text>
          </ownedElement>
          <ownedElement xmi:id="f0183200-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f0183450-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-reference_tool"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1351" y="1212" width="165" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_342989_372420" xmi:uuid="f0376f80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-resource_definition"/>
          <ownedElement xmi:id="f02d1980-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f02d1a80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-resource_definition"/>
            <text>resource_definition:resource_definition_select</text>
          </ownedElement>
          <ownedElement xmi:id="f03751f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f03752e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-resource_definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1351" y="883" width="297" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_413013_372421" xmi:uuid="f056caf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-placement"/>
          <ownedElement xmi:id="f04c1ea0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f04c1fa0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-placement"/>
            <text>placement:Geometric_relationship_with_placement_transformation</text>
          </ownedElement>
          <ownedElement xmi:id="f056aa60-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f056ab50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_resource_assignment-placement"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1351" y="980" width="422" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1330" y="854" width="478" height="393"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_352847_402566" xmi:uuid="f248cd80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038138_639316_180943"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_437389_372416"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_752542_372459"/>
      <waypoint x="1383" y="854"/>
      <waypoint x="1383" y="480"/>
      <waypoint x="898" y="480"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_189648_372458" xmi:uuid="f2499a50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038228_116022_180985"/>
      <ownedElement xmi:id="f1fb5190-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f1fb5290-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038228_116022_180985"/>
        <text>ia1:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f1fd14a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f1fd15b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038228_116022_180985"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f1fd4030-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f1fd40e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f1fd5700-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f1fd5900-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_752542_372459" xmi:uuid="f21cc820-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="f211cc90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f211cd90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="f21ca2c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f21ca4b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="714" y="455" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_346688_372460" xmi:uuid="f2324410-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="f2277f10-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2278020-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="f23224d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f23225e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="714" y="427" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_922816_372461" xmi:uuid="f24899a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="f23d93f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f23d94e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="f2486ad0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2486bc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="717" y="483" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="700" y="399" width="265" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_719247_372462" xmi:uuid="f24d0520-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038231_192268_180986"/>
      <ownedElement xmi:id="f24b4890-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f24b4980-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038231_192268_180986"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="f24cda60-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f24cdb40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038231_192268_180986"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="504" y="483" width="176" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_748700_372463" xmi:uuid="f26f62a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038236_870779_180987"/>
      <ownedElement xmi:id="f2581e90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2581f80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038236_870779_180987"/>
        <text>dt:Description_text</text>
      </ownedElement>
      <ownedElement xmi:id="f259db70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f259dc60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038236_870779_180987"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f25a3e30-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f25a3f00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f25a4ff0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f25a5090-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_91624_372464" xmi:uuid="f26f5b00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
          <ownedElement xmi:id="f264b5e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f264b6e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>description:String</text>
          </ownedElement>
          <ownedElement xmi:id="f26f3910-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f26f3a10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="525" y="246" width="135" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="518" y="224" width="152" height="57"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_825350_402570" xmi:uuid="f2bad2d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038132_63082_180935"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_437389_372416"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_349116_372466"/>
      <waypoint x="1383" y="854"/>
      <waypoint x="1383" y="245"/>
      <waypoint x="882" y="245"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_893704_372465" xmi:uuid="f2bb8d90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038239_91014_180988"/>
      <ownedElement xmi:id="f27ad2e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f27ad400-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038239_91014_180988"/>
        <text>dta1:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="f27c7fa0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f27c80a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038239_91014_180988"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f27ca2f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f27ca3a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f27cb720-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f27cb7c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_349116_372466" xmi:uuid="f29c10f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="f290f380-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f290f480-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="f29bf440-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f29bf540-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="224" width="175" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_221044_372467" xmi:uuid="f2bab7b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
          <ownedElement xmi:id="f2b072c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2b073c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>description:Description_text</text>
          </ownedElement>
          <ownedElement xmi:id="f2ba9970-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2ba9a60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="259" width="192" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="700" y="196" width="265" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_973112_372468" xmi:uuid="f2e819e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038243_239763_180989"/>
      <ownedElement xmi:id="f2c72100-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2c72220-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038243_239763_180989"/>
        <text>selectMultiLingual:MultiLingualSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_633035_372469" xmi:uuid="f2d34fa0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501857419425_135840_25002"/>
        <ownedElement xmi:id="f2d333a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2d334a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501857419425_135840_25002"/>
          <bounds x="614" y="1130" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="596" y="1139" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_157512_372471" xmi:uuid="f2ddb9d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501857419425_525357_25004"/>
        <ownedElement xmi:id="f2dda250-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2dda350-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501857419425_525357_25004"/>
          <bounds x="289" y="1086" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="343" y="1095" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_556210_372473" xmi:uuid="f2e81200-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501857419425_752515_25006"/>
        <ownedElement xmi:id="f2e7f140-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2e7f250-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501857419425_752515_25006"/>
          <bounds x="614" y="1041" width="46" height="13"/>
          <text>text [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="596" y="1050" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="343" y="1043" width="268" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_776986_372475" xmi:uuid="f3001a70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038247_681540_180990"/>
      <ownedElement xmi:id="f2f3aac0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2f3abc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038247_681540_180990"/>
        <text>language1:Language</text>
      </ownedElement>
      <ownedElement xmi:id="f2f54c60-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2f54d60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038247_681540_180990"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_733415_372476" xmi:uuid="f3000f30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="f2fff5b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f2fff6c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="876" y="1131" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="855" y="1140" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="695" y="1134" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_555635_402584" xmi:uuid="f3600250-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038146_233908_180954"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_437389_372416"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_533084_372480"/>
      <waypoint x="1330" y="1117"/>
      <waypoint x="1257" y="1117"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_711260_372478" xmi:uuid="f360b980-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038251_863825_180991"/>
      <ownedElement xmi:id="f30b7880-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f30b7990-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038251_863825_180991"/>
        <text>li1:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="f30d10f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f30d11d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038251_863825_180991"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f30d3160-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f30d36d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f30d4b30-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f30d4bd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_634135_372479" xmi:uuid="f321ef40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="f3175df0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f3175ef0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="f321cb70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f321d270-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1029" y="1162" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_533084_372480" xmi:uuid="f3408d80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="f335de00-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f335df20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="f34071e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f34072e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1029" y="1106" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_275742_372481" xmi:uuid="f35fec00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="f3552090-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f3552190-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="f35fcd90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f35fce90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1029" y="1134" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1015" y="1078" width="265" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_256284_372482" xmi:uuid="f36407a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038257_802939_180992"/>
      <ownedElement xmi:id="f3626340-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f3626440-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038257_802939_180992"/>
        <text>theAttribute1:String</text>
      </ownedElement>
      <ownedElement xmi:id="f363f490-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f363f590-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038257_802939_180992"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="771" y="1169" width="190" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_406422_402558" xmi:uuid="f3640e30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038124_305979_180925"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_437389_372416"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_556123_372483"/>
      <waypoint x="1596" y="854"/>
      <waypoint x="1596" y="830"/>
      <waypoint x="1820" y="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_692219_402559" xmi:uuid="f36415f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038125_538538_180926"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_342989_372420"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025965_228262_372401"/>
      <waypoint x="1351" y="893"/>
      <waypoint x="449" y="893"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_830906_402560" xmi:uuid="f3641bc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038126_704029_180927"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_664313_372417"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025965_657956_372404"/>
      <waypoint x="1351" y="935"/>
      <waypoint x="319" y="935"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_157697_402567" xmi:uuid="f36423e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038128_437656_180929"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_922816_372461"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_719247_372462"/>
      <waypoint x="717" y="494"/>
      <waypoint x="680" y="494"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_313730_402571" xmi:uuid="f3644160-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038130_768721_180933"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_221044_372467"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_748700_372463"/>
      <waypoint x="707" y="270"/>
      <waypoint x="670" y="270"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_925781_402581" xmi:uuid="f3649c20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038141_43334_180948"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_334721_372419"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025965_559256_372415"/>
      <waypoint x="1351" y="1222"/>
      <waypoint x="199" y="1222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_460789_402582" xmi:uuid="f364a650-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038142_816225_180949"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_839520_372414"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_157512_372471"/>
      <waypoint x="210" y="1104"/>
      <waypoint x="343" y="1104"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_587627_402583" xmi:uuid="f364ae00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038143_702714_180950"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_239768_372418"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_556210_372473"/>
      <waypoint x="1351" y="1061"/>
      <waypoint x="611" y="1061"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_980171_402585" xmi:uuid="f364b5a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038143_18978_180951"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_634135_372479"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_256284_372482"/>
      <waypoint x="1029" y="1176"/>
      <waypoint x="961" y="1176"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_512538_402586" xmi:uuid="f364bd30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038144_552908_180952"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_275742_372481"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_733415_372476"/>
      <waypoint x="1029" y="1148"/>
      <waypoint x="870" y="1148"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_159394_402587" xmi:uuid="f364c3e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038145_273774_180953"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_776986_372475"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_633035_372469"/>
      <waypoint x="695" y="1145"/>
      <waypoint x="611" y="1145"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_47980_402588" xmi:uuid="f364cef0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038147_521307_180955"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_413013_372421"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025965_917258_372412"/>
      <waypoint x="1351" y="994"/>
      <waypoint x="537" y="994"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_556123_372483" xmi:uuid="f364e5b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038182_439848_180974"/>
      <bounds x="1820" y="816" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_802090_98248" xmi:uuid="c72a7ac0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509987065721_230294_25388"/>
      <bounds x="742" y="35" width="116" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_590280_98249" xmi:uuid="c75c8ee0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
      <ownedElement xmi:id="c74358d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c7435bf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_697203_26150"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_109361_98256" xmi:uuid="c75c8070-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="c75b8900-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c75b8a20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="596" y="418" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="578" y="427" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="455" y="413" width="138" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806206513_770518_99310" xmi:uuid="c7a9c330-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806208180_55273_99311"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_437389_372416"/>
      <target xmi:idref="_18_4_1_65b021e_1692805900207_361552_98258"/>
      <waypoint x="1383" y="854"/>
      <waypoint x="1383" y="578"/>
      <waypoint x="897" y="578"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_979820_98250" xmi:uuid="c7aa9ad0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
      <ownedElement xmi:id="c774be90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c774bfc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c7818bc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c7818ce0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987122786_798290_26152"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c7825f20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c7826050-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c78311c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c78312d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_361552_98258" xmi:uuid="c7a8ed80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="c79b17f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c79b1900-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c7a7ec50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c7a7ed60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="714" y="567" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="700" y="539" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806183783_458059_99272" xmi:uuid="c7f97e00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806186385_498817_99273"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_437389_372416"/>
      <target xmi:idref="_18_4_1_65b021e_1692805900207_78812_98259"/>
      <waypoint x="1383" y="854"/>
      <waypoint x="1383" y="151"/>
      <waypoint x="898" y="151"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_915824_98251" xmi:uuid="c7fa9a60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
      <ownedElement xmi:id="c7c3d480-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c7c3d5a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c7d0b100-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c7d0b380-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987401186_633732_27276"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c7d1ca40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c7d1cb70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c7d27a40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c7d27b40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_78812_98259" xmi:uuid="c7f8a170-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c7eab140-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c7eab610-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c7f7b2c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c7f7b400-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="714" y="140" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="700" y="112" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_757503_98252" xmi:uuid="c82c1450-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
      <ownedElement xmi:id="c8129190-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c81292a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_126023_26776"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_874447_98260" xmi:uuid="c82c05e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="c82b0df0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c82b1050-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="451" y="211" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="441" y="193" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="378" y="154" width="220" height="54"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806200177_356626_99291" xmi:uuid="c87a7490-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806202845_346741_99292"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_437389_372416"/>
      <target xmi:idref="_18_4_1_65b021e_1692805900207_781549_98262"/>
      <waypoint x="1383" y="854"/>
      <waypoint x="1383" y="354"/>
      <waypoint x="889" y="354"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_916636_98253" xmi:uuid="c87b94b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
      <ownedElement xmi:id="c844bd50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c844be90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c8516fe0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c8517110-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_961539_26774"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="c85233d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c85234d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c852ce50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c852cf10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_781549_98262" xmi:uuid="c879a330-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="c86bb840-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c86bb9f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="c878a980-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c878aab0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="714" y="343" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="700" y="315" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806211782_101_99329" xmi:uuid="c8c97750-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806213801_782188_99330"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_437389_372416"/>
      <target xmi:idref="_18_4_1_65b021e_1692805900207_245372_98263"/>
      <waypoint x="1383" y="854"/>
      <waypoint x="1383" y="662"/>
      <waypoint x="898" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_963676_98254" xmi:uuid="c8ca89b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
      <ownedElement xmi:id="c8937c30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c8937d70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>roleAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c8a06020-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c8a06150-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202213_878833_26368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="c8a14360-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c8a14480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c8a1fef0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c8a20030-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_245372_98263" xmi:uuid="c8c8b5c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c8ba8980-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c8ba8a90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c8c7ca40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c8c7cb70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="714" y="651" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="700" y="623" width="294" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_743474_98255" xmi:uuid="c8fce4f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
      <ownedElement xmi:id="c8e32b10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c8e32c50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987202198_641127_26366"/>
        <text>roleSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692805900207_523989_98264" xmi:uuid="c8fccbf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="c8fbf860-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c8fbf9a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="450" y="681" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="440" y="663" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="385" y="623" width="189" height="55"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806006929_110504_98845" xmi:uuid="c94bcf40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806008346_110696_98846"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_748700_372463"/>
      <target xmi:idref="_18_4_1_65b021e_1692805985107_746648_98751"/>
      <waypoint x="592" y="281"/>
      <waypoint x="592" y="336"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805985107_242883_98750" xmi:uuid="c94ccf00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
      <ownedElement xmi:id="c9158070-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c91582b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="c9229b20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9229c60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509987327525_678948_26772"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="c923a640-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c923a770-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c924a530-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c924a680-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805985107_746648_98751" xmi:uuid="c94ae9b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="c93d81c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c93d8300-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="c949ffe0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c94a00f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="406" y="336" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="392" y="308" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806000413_2415_98823" xmi:uuid="c94cda60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806001861_276681_98824"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_91624_372464"/>
      <target xmi:idref="_18_4_1_65b021e_1692805900207_874447_98260"/>
      <waypoint x="525" y="259"/>
      <waypoint x="448" y="259"/>
      <waypoint x="448" y="208"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806060363_878628_98870" xmi:uuid="c94ce310-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806061660_676493_98871"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_346688_372460"/>
      <target xmi:idref="_18_4_1_65b021e_1692805900207_109361_98256"/>
      <waypoint x="714" y="438"/>
      <waypoint x="593" y="438"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806217468_116786_99348" xmi:uuid="c9c8a600-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806219672_53531_99349"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_437389_372416"/>
      <target xmi:idref="_18_4_1_65b021e_1692806144164_121631_98957"/>
      <waypoint x="1383" y="854"/>
      <waypoint x="1383" y="788"/>
      <waypoint x="891" y="788"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806144164_851186_98953" xmi:uuid="c9c9cb60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141373_571661_98919"/>
      <ownedElement xmi:id="c95add10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c95ade50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141373_571661_98919"/>
        <text>roleAsgn2:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="c95d6890-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c95d7020-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141373_571661_98919"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="c95e6640-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c95e6880-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c95f41c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c95f42f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692806144164_962430_98956" xmi:uuid="c9860920-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="c977e580-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c977e6a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="c98524b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9852760-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="742" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692806144164_121631_98957" xmi:uuid="c9ad3400-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="c99ecef0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c99ed020-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="c9ac5cb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9ac5de0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="707" y="777" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692806144164_429030_98958" xmi:uuid="c9c7a700-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="c9b9afd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9b9b100-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="c9c6b940-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9c6ba60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="707" y="819" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="700" y="714" width="294" height="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806144164_984015_98954" xmi:uuid="ca12b7b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141374_300375_98920"/>
      <ownedElement xmi:id="c9d81ec0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9d82130-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141374_300375_98920"/>
        <text>role:Class</text>
      </ownedElement>
      <ownedElement xmi:id="c9daf1f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9daf330-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141374_300375_98920"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="c9dbd1d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9dbd4b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="c9dc7f30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9dc8030-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692806144164_902205_98959" xmi:uuid="c9f7d6f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
          <ownedElement xmi:id="c9e98af0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9e98c30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="c9f6e670-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="c9f6e7b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="553" y="742" width="103" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692806144164_983650_98960" xmi:uuid="ca12a580-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
          <ownedElement xmi:id="ca0490e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca049210-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="ca11cc40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca11cd70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Class-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="553" y="777" width="82" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="546" y="714" width="117" height="98"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806144164_940139_98955" xmi:uuid="ca17b990-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141376_737802_98921"/>
      <ownedElement xmi:id="ca1516e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca151810-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141376_737802_98921"/>
        <text>theRole1:String</text>
      </ownedElement>
      <ownedElement xmi:id="ca179800-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca179950-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141376_737802_98921"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="497" y="819" width="167" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806144164_825998_98961" xmi:uuid="ca17c900-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141378_295539_98929"/>
      <source xmi:idref="_18_4_1_65b021e_1692806144164_962430_98956"/>
      <target xmi:idref="_18_4_1_65b021e_1692806144164_984015_98954"/>
      <waypoint x="707" y="753"/>
      <waypoint x="663" y="753"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806144164_654179_98962" xmi:uuid="ca17d310-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806141378_597384_98934"/>
      <source xmi:idref="_18_4_1_65b021e_1692806144164_429030_98958"/>
      <target xmi:idref="_18_4_1_65b021e_1692806144164_940139_98955"/>
      <waypoint x="707" y="830"/>
      <waypoint x="664" y="830"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806172458_636287_99228" xmi:uuid="ca17dd50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806174227_582263_99229"/>
      <source xmi:idref="_18_4_1_65b021e_1692806144164_902205_98959"/>
      <target xmi:idref="_18_4_1_65b021e_1692805900207_523989_98264"/>
      <waypoint x="553" y="753"/>
      <waypoint x="448" y="753"/>
      <waypoint x="448" y="678"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692806177064_449456_99250" xmi:uuid="ca17ede0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692806178397_17928_99251"/>
      <source xmi:idref="_18_4_1_65b021e_1692806144164_983650_98960"/>
      <target xmi:idref="_18_4_1_65b021e_1692805900207_523989_98264"/>
      <waypoint x="553" y="788"/>
      <waypoint x="448" y="788"/>
      <waypoint x="448" y="678"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1823" height="1262"/>
    <name>ProcessOperationResourceAssignment</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564035912_103059_180386" xmi:uuid="f3652a40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977023_906034_164255"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_711744_372041" xmi:uuid="f368c5d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036172_160591_180486"/>
      <ownedElement xmi:id="ca2a3780-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca2a3a60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036172_160591_180486"/>
        <text>ClassifiedAs:Classification</text>
      </ownedElement>
      <ownedElement xmi:id="ca2c8980-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca2c8ab0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036172_160591_180486"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_64176_372042" xmi:uuid="ca3ad1e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
        <ownedElement xmi:id="ca39f0e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca39f220-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501865602467_748500_27046"/>
          <bounds x="245" y="53" width="202" height="13"/>
          <text>classAsgn : Classification_assignment [1]</text>
        </ownedElement>
        <bounds x="227" y="62" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="49" width="200" height="40"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_970045_372044" xmi:uuid="f3696650-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036163_761762_180484"/>
      <ownedElement xmi:id="ca48b4c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca48b9c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036163_761762_180484"/>
        <text>Description:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ca4abcc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca4abe00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036163_761762_180484"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="159" width="206" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_933961_372045" xmi:uuid="f369c510-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035183_39700_180286"/>
      <ownedElement xmi:id="ca5826d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca582840-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035183_39700_180286"/>
        <text>Id:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ca5a9c30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca5a9d50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035183_39700_180286"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="341" width="133" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_716381_372046" xmi:uuid="f36a1560-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035174_854216_180281"/>
      <ownedElement xmi:id="ca685310-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca685450-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035174_854216_180281"/>
        <text>Name:DescriptorSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ca6a9340-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca6a9940-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564035174_854216_180281"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="441" width="174" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_744603_372047" xmi:uuid="f36a6180-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036175_894541_180487"/>
      <ownedElement xmi:id="ca785b90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca785cc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036175_894541_180487"/>
        <text>ProcessType:ClassSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ca7ada10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca7adb40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036175_894541_180487"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="686" width="177" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_40040_372048" xmi:uuid="f36aaec0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036168_93961_180485"/>
      <ownedElement xmi:id="ca88f1d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca88fbf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036168_93961_180485"/>
        <text>VersionId:IdentifierSelect</text>
      </ownedElement>
      <ownedElement xmi:id="ca8b5e70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca8b6510-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036168_93961_180485"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="817" width="189" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_921075_372049" xmi:uuid="f36afd60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036179_6515_180488"/>
      <ownedElement xmi:id="ca996950-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca996a90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036179_6515_180488"/>
        <text>process_operation_definition:Process_operation_definition</text>
      </ownedElement>
      <ownedElement xmi:id="ca9be980-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca9beab0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036179_6515_180488"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="ca9cbcb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca9cbdc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ca9d80f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ca9d8230-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_347678_372050" xmi:uuid="cac3eb00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-description"/>
          <ownedElement xmi:id="cab5c830-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cab5c940-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-description"/>
            <text>description:text</text>
          </ownedElement>
          <ownedElement xmi:id="cac2f400-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cac2f530-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-description"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1281" y="106" width="135" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_771446_372051" xmi:uuid="cadf1ce0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-id"/>
          <ownedElement xmi:id="cad12600-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cad12900-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-id"/>
            <text>id:String</text>
          </ownedElement>
          <ownedElement xmi:id="cade5640-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cade5770-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-id"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1281" y="330" width="82" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_313548_372052" xmi:uuid="cb059880-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-name"/>
          <ownedElement xmi:id="caf7afb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="caf7b0e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-name"/>
            <text>name:label</text>
          </ownedElement>
          <ownedElement xmi:id="cb04c530-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb04c650-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-name"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1281" y="428" width="108" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_116200_372053" xmi:uuid="cb210840-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-process_type"/>
          <ownedElement xmi:id="cb1306d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb130d40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-process_type"/>
            <text>process_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="cb204720-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb204960-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-process_type"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1281" y="659" width="148" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_834958_372054" xmi:uuid="cb3d7240-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-version_id"/>
          <ownedElement xmi:id="cb2f3150-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb2f3280-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-version_id"/>
            <text>version_id:String</text>
          </ownedElement>
          <ownedElement xmi:id="cb3c9510-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb3c96f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition-version_id"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1281" y="806" width="142" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1260" y="49" width="365" height="792"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_723590_372055" xmi:uuid="f36b4ca0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036191_436571_180491"/>
      <ownedElement xmi:id="cb4cdb20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb4cdc70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036191_436571_180491"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_792999_372056" xmi:uuid="cb5cc130-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="cb5bd560-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb5bdfa0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="549" y="160" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="531" y="169" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_997593_372058" xmi:uuid="cb6abde0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="cb69e490-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb69e6b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="549" y="97" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="531" y="106" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_299056_372060" xmi:uuid="cb7867d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="cb777a50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb777d30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="553" y="213" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="531" y="224" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_417149_372062" xmi:uuid="cb8588c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="cb84d350-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb84d490-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="240" y="155" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="294" y="164" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="294" y="98" width="252" height="147"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_320051_372064" xmi:uuid="f36b9b30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036188_312205_180490"/>
      <ownedElement xmi:id="cb931710-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cb931830-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036188_312205_180490"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_158593_372065" xmi:uuid="cba13000-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="cba06ff0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cba07130-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="458" y="383" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="440" y="392" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_135566_372067" xmi:uuid="cbae1be0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="cbad3080-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cbad3190-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="458" y="325" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="440" y="334" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_343521_372069" xmi:uuid="cbbbdf20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="cbbb0fd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cbbb1170-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="240" y="337" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="294" y="346" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="294" y="322" width="161" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_695219_372071" xmi:uuid="f36be5a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036185_309802_180489"/>
      <ownedElement xmi:id="cbcaf820-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cbcaf950-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036185_309802_180489"/>
        <text>selectDescription1:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_739122_372072" xmi:uuid="cbda2e00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
        <ownedElement xmi:id="cbd950d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cbd951c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_822207_25455"/>
          <bounds x="537" y="481" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="519" y="490" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_80924_372074" xmi:uuid="cbe7b510-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="cbe6f6f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cbe6f830-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="537" y="426" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="519" y="435" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_420282_372076" xmi:uuid="cbf5d980-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
        <ownedElement xmi:id="cbf51410-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cbf51660-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502114501000_51937_25471"/>
          <bounds x="542" y="530" width="72" height="13"/>
          <text>language [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="519" y="541" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_628368_372078" xmi:uuid="cc03c0a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
        <ownedElement xmi:id="cc02d860-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc02d980-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_211716_25453"/>
          <bounds x="240" y="436" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="294" y="445" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="294" y="427" width="240" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_749488_372080" xmi:uuid="f36c3290-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036193_372282_180492"/>
      <ownedElement xmi:id="cc129420-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc129540-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036193_372282_180492"/>
        <text>selectId1:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_165071_372081" xmi:uuid="cc219870-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
        <ownedElement xmi:id="cc20c050-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc20c2c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253506962_882798_22878"/>
          <bounds x="457" y="845" width="67" height="13"/>
          <text>complex [0..*]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="439" y="854" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_829702_372083" xmi:uuid="cc2ff550-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="cc2f0ac0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc2f0c00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="457" y="801" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="439" y="810" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_591739_372085" xmi:uuid="cc3dd210-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
        <ownedElement xmi:id="cc3cda40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc3cdb60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_216328_22865"/>
          <bounds x="247" y="813" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="301" y="822" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="301" y="798" width="153" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_92308_372087" xmi:uuid="f36c8020-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036196_253426_180493"/>
      <ownedElement xmi:id="cc4b9be0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc4b9d00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036196_253426_180493"/>
        <text>descriptors:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="cc4e0af0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc4e0c30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036196_253426_180493"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_525521_372088" xmi:uuid="cc5c0900-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="cc5b2f50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc5b3070-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="714" y="147" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="801" y="167" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="161" width="165" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_556534_372090" xmi:uuid="f36ccd40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036200_95427_180494"/>
      <ownedElement xmi:id="cc6935c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc6937c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036200_95427_180494"/>
        <text>language:Language</text>
      </ownedElement>
      <ownedElement xmi:id="cc6b7fe0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc6b8120-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036200_95427_180494"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_726542_372091" xmi:uuid="cc795970-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="cc787a50-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc787ed0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="820" y="247" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="798" y="256" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="252" width="162" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_500070_372093" xmi:uuid="f36d18b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036204_850785_180495"/>
      <ownedElement xmi:id="cc8752b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc875800-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036204_850785_180495"/>
        <text>ids:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="cc89c0e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc89c400-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036204_850785_180495"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_706965_372094" xmi:uuid="cc975320-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="cc967960-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cc967a90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="752" y="378" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="759" y="394" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="392" width="123" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_656145_372096" xmi:uuid="f36d6240-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036208_751562_180496"/>
      <ownedElement xmi:id="cca58220-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cca58350-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036208_751562_180496"/>
        <text>descriptors1:Descriptor</text>
      </ownedElement>
      <ownedElement xmi:id="cca7e830-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cca7e950-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036208_751562_180496"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_884188_372097" xmi:uuid="ccb56a70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
        <ownedElement xmi:id="ccb49420-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ccb496b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113542010_832518_25129"/>
          <bounds x="721" y="476" width="215" height="13"/>
          <text>descAsgn : Description_text_assignment [1]</text>
        </ownedElement>
        <bounds x="807" y="496" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="490" width="171" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_723694_372099" xmi:uuid="f36dad10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036212_501928_180497"/>
      <ownedElement xmi:id="ccc332a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ccc33670-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036212_501928_180497"/>
        <text>language1:Language</text>
      </ownedElement>
      <ownedElement xmi:id="ccc5d410-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ccc5d5c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036212_501928_180497"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_241010_372100" xmi:uuid="ccd3a220-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
        <ownedElement xmi:id="ccd2c880-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ccd2c9e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501862547948_709439_25979"/>
          <bounds x="820" y="575" width="93" height="13"/>
          <text>lang : Language [1]</text>
        </ownedElement>
        <bounds x="804" y="584" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="581" width="168" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_183838_372102" xmi:uuid="f36dfa80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036216_289246_180498"/>
      <ownedElement xmi:id="cce17290-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cce173c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036216_289246_180498"/>
        <text>ids1:Identifier</text>
      </ownedElement>
      <ownedElement xmi:id="cce3ee30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cce3f0e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036216_289246_180498"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_730253_372103" xmi:uuid="ccf26180-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
        <ownedElement xmi:id="ccf16190-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ccf162c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501254473126_677112_23025"/>
          <bounds x="752" y="833" width="180" height="13"/>
          <text>idAsgn : Identification_assignment [1]</text>
        </ownedElement>
        <bounds x="765" y="850" width="15" height="15"/>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="847" width="129" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_563909_402429" xmi:uuid="cd2d30f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036135_203093_180443"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_921075_372049"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_355993_372106"/>
      <waypoint x="1260" y="67"/>
      <waypoint x="842" y="67"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_250655_372105" xmi:uuid="f36e4840-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036219_622621_180499"/>
      <ownedElement xmi:id="cd00e270-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd00e510-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036219_622621_180499"/>
        <text>ca:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cd03ad00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd03ae20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036219_622621_180499"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="cd04aea0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd04afd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="cd058610-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd058750-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_355993_372106" xmi:uuid="cd2c5990-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="cd1e7240-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd1e7370-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="cd2b64f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd2b6630-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="658" y="56" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="644" y="28" width="207" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_853774_402430" xmi:uuid="cd678d20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036139_996873_180448"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_921075_372049"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_58990_372108"/>
      <waypoint x="1260" y="165"/>
      <waypoint x="1134" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_965674_372107" xmi:uuid="f36e9730-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036223_712106_180500"/>
      <ownedElement xmi:id="cd3c32b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd3c33d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036223_712106_180500"/>
        <text>dta:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cd3eb1e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd3eb310-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036223_712106_180500"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="cd3fa0d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd3fa200-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="cd406dd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd407480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_58990_372108" xmi:uuid="cd66bfc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="cd585af0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd585c10-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="cd658f90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd659250-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="154" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="126" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_33966_402431" xmi:uuid="cde42be0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036131_443291_180438"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_71155_372113"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_147353_372110"/>
      <waypoint x="928" y="298"/>
      <waypoint x="959" y="298"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_200087_402432" xmi:uuid="cde63c90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036140_37900_180450"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_921075_372049"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_653931_372111"/>
      <waypoint x="1260" y="235"/>
      <waypoint x="1187" y="235"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_301137_372109" xmi:uuid="f36ee4c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036227_728875_180501"/>
      <ownedElement xmi:id="cd76b000-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd76b130-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036227_728875_180501"/>
        <text>li:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="cd791430-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd791620-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036227_728875_180501"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="cd79fc90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd79fdc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="cd7aaec0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd7aafe0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_147353_372110" xmi:uuid="cd9576d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="cd87f250-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd87f390-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="cd94c450-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cd94c580-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="959" y="280" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_653931_372111" xmi:uuid="cdbc5c60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="cdae4480-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cdae45b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="cdbb74e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cdbb7760-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="224" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_272625_372112" xmi:uuid="cde34a90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="cdd58720-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cdd58a70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="cde25d40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cde25f80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="252" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="196" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_71155_372113" xmi:uuid="f36f3000-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036230_989792_180502"/>
      <ownedElement xmi:id="cdea0c00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cdea0d30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036230_989792_180502"/>
        <text>theAttribute:String</text>
      </ownedElement>
      <ownedElement xmi:id="cdec62d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cdec6400-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036230_989792_180502"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="714" y="287" width="214" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_727338_402433" xmi:uuid="ce2643c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036143_222080_180454"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_921075_372049"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_385468_372115"/>
      <waypoint x="1260" y="396"/>
      <waypoint x="1142" y="396"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_240346_372114" xmi:uuid="f36f7c10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036234_174988_180503"/>
      <ownedElement xmi:id="cdfa8430-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cdfa8550-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036234_174988_180503"/>
        <text>ia:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cdfd0f90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cdfd1200-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036234_174988_180503"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="cdfdd9f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cdfddac0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="cdfeb2b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cdfeb3e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_385468_372115" xmi:uuid="ce256f00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="ce1777b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce1778e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="ce24ac00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce24ad30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="385" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="350" width="249" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026827_621165_402434" xmi:uuid="ce61c870-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036151_116496_180465"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_921075_372049"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_819717_372117"/>
      <waypoint x="1260" y="494"/>
      <waypoint x="1134" y="494"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_860969_372116" xmi:uuid="f36fc3f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036238_365976_180504"/>
      <ownedElement xmi:id="ce3575c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce357810-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036238_365976_180504"/>
        <text>dta1:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="ce37ec90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce37edc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036238_365976_180504"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ce38f420-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce38f560-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ce39c0d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce39c220-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_819717_372117" xmi:uuid="ce60eba0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="ce52be00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce52bf30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="ce5ff580-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce5ff6c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="483" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="455" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_875028_402435" xmi:uuid="cee8bfb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036132_256057_180439"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_685676_372122"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_34258_372119"/>
      <waypoint x="902" y="627"/>
      <waypoint x="959" y="627"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1721931041567_671984_128650" xmi:uuid="59c4d790-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1721931042577_190399_128651"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_921075_372049"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_494849_372120"/>
      <waypoint x="1260" y="564"/>
      <waypoint x="1187" y="564"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_844380_372118" xmi:uuid="f3701bd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036242_679584_180505"/>
      <ownedElement xmi:id="ce7678e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce767dc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036242_679584_180505"/>
        <text>li1:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="ce796cd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce796e80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036242_679584_180505"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="ce7ad270-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce7ad3b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="ce7c3f90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce7c41a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_34258_372119" xmi:uuid="ce9af220-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
          <ownedElement xmi:id="ce8bf9e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce8bfc30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>considered_attribute:String</text>
          </ownedElement>
          <ownedElement xmi:id="ce99d690-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ce99d7c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_attribute"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="609" width="188" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_494849_372120" xmi:uuid="cec38640-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="ceb424e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ceb42650-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="cec284b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cec285e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="553" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_21872_372121" xmi:uuid="cee7e780-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
          <ownedElement xmi:id="cedb0010-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cedb0150-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>used_language:Language</text>
          </ownedElement>
          <ownedElement xmi:id="cee6dc00-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cee6dd40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-used_language"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="581" width="177" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="525" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_685676_372122" xmi:uuid="f37064d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036245_163197_180506"/>
      <ownedElement xmi:id="ceec31f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ceec3370-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036245_163197_180506"/>
        <text>theAttribute1:String</text>
      </ownedElement>
      <ownedElement xmi:id="ceee64a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ceee67a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036245_163197_180506"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="714" y="616" width="188" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_504515_402436" xmi:uuid="cf2a31e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036156_708549_180472"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_921075_372049"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_143213_372124"/>
      <waypoint x="1547" y="841"/>
      <waypoint x="1547" y="872"/>
      <waypoint x="1142" y="872"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_615566_372123" xmi:uuid="f370b4e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036249_196544_180507"/>
      <ownedElement xmi:id="cefc5310-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cefc57c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036249_196544_180507"/>
        <text>ia1:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cefe95e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cefe9710-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036249_196544_180507"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="ceff7370-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="ceff74e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="cf0033c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf003620-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_143213_372124" xmi:uuid="cf295230-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="cf1aafa0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf1ab070-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="cf288340-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf288480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="861" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="826" width="249" height="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_200143_372125" xmi:uuid="f3710720-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036258_409027_180509"/>
      <ownedElement xmi:id="cf39bda0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf39bf30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036258_409027_180509"/>
        <text>selectClass:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_242226_372126" xmi:uuid="cf49e680-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="cf48f920-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf48fa50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="491" y="652" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="473" y="661" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_555824_372128" xmi:uuid="cf57e2d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
        <ownedElement xmi:id="cf56ef30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf56f070-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081201613_332687_23713"/>
          <bounds x="240" y="679" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="294" y="688" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_263561_372130" xmi:uuid="cf650c70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
        <ownedElement xmi:id="cf6419b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf641b00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501081780659_717200_23722"/>
          <bounds x="491" y="699" width="54" height="13"/>
          <text>class [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="473" y="708" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="294" y="651" width="194" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_959040_402458" xmi:uuid="cfe8c310-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036153_461379_180468"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_921075_372049"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_971491_372134"/>
      <waypoint x="1260" y="746"/>
      <waypoint x="1143" y="746"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_104210_372132" xmi:uuid="f3715d90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036261_90861_180510"/>
      <ownedElement xmi:id="cf73f270-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf73f7a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036261_90861_180510"/>
        <text>ca1:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="cf765350-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf765480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036261_90861_180510"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="cf7766f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf776840-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="cf782920-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf782ba0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_401353_372133" xmi:uuid="cfa03400-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
          <ownedElement xmi:id="cf919be0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf919d40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>assigned_class:Class</text>
          </ownedElement>
          <ownedElement xmi:id="cf9f6090-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cf9f61c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-assigned_class"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="707" width="156" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_971491_372134" xmi:uuid="cfc69970-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="cfb8ddb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cfb8def0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="cfc5bc70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cfc5bec0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="959" y="735" width="184" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_73422_372135" xmi:uuid="cfe7d590-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
          <ownedElement xmi:id="cfd88f60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cfd892b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="cfe6d3b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cfe6d4f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-role"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="959" y="763" width="106" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="945" y="679" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_51328_372136" xmi:uuid="f371a6b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036265_195085_180511"/>
      <ownedElement xmi:id="cfed1c10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cfed1f80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036265_195085_180511"/>
        <text>theClassificationRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="cfefbb90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cfefbd40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036265_195085_180511"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="658" y="763" width="273" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_33219_372137" xmi:uuid="f371f1d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036269_657037_180512"/>
      <ownedElement xmi:id="cffe8370-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="cffe85b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036269_657037_180512"/>
        <text>defaultType:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_850649_372138" xmi:uuid="d00ee870-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="d00df420-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d00df550-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="588" y="672" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="644" y="663" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_786251_372140" xmi:uuid="d01d2e60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="d01c6570-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d01c6690-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="839" y="652" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="821" y="661" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="644" y="651" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_606639_372142" xmi:uuid="f3723e70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036273_587435_180513"/>
      <ownedElement xmi:id="d02b7dc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d02b7ee0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036273_587435_180513"/>
        <text>defaultId:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_150310_372143" xmi:uuid="d03b00e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="d03a3a40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d03a3b70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="588" y="343" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="644" y="334" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025961_505696_372145" xmi:uuid="d04822b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="d0476710-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d0477570-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="839" y="323" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="821" y="332" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="644" y="322" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_154097_402437" xmi:uuid="f37247c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036133_442068_180440"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_921075_372049"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_332273_372039"/>
      <waypoint x="1625" y="63"/>
      <waypoint x="1642" y="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_813458_402438" xmi:uuid="f3725030-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036133_114884_180441"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_347678_372050"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_997593_372058"/>
      <waypoint x="1281" y="112"/>
      <waypoint x="546" y="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_624511_402439" xmi:uuid="f3725e00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036134_433254_180442"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_250655_372105"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_64176_372042"/>
      <waypoint x="644" y="70"/>
      <waypoint x="242" y="70"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_592847_402440" xmi:uuid="f3726700-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036136_462555_180444"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_970045_372044"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_417149_372062"/>
      <waypoint x="241" y="171"/>
      <waypoint x="294" y="171"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_561898_402441" xmi:uuid="f3726f10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036136_506998_180445"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_92308_372087"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_792999_372056"/>
      <waypoint x="644" y="175"/>
      <waypoint x="546" y="175"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_554741_402442" xmi:uuid="f3727700-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036137_602034_180446"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_556534_372090"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_299056_372060"/>
      <waypoint x="644" y="266"/>
      <waypoint x="630" y="266"/>
      <waypoint x="630" y="231"/>
      <waypoint x="546" y="231"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_617884_402443" xmi:uuid="f3727f10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036138_935557_180447"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_965674_372107"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_525521_372088"/>
      <waypoint x="945" y="175"/>
      <waypoint x="816" y="175"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_599994_402444" xmi:uuid="f3728d60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036139_536652_180449"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_272625_372112"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_726542_372091"/>
      <waypoint x="959" y="263"/>
      <waypoint x="813" y="263"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_890896_402445" xmi:uuid="f3729540-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036141_126451_180451"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_150310_372143"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_135566_372067"/>
      <waypoint x="644" y="340"/>
      <waypoint x="455" y="340"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_250755_402446" xmi:uuid="f3729cd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036142_365032_180452"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_500070_372093"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_158593_372065"/>
      <waypoint x="644" y="399"/>
      <waypoint x="455" y="399"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_806993_402447" xmi:uuid="f372a2e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036142_985147_180453"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_240346_372114"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_706965_372094"/>
      <waypoint x="945" y="403"/>
      <waypoint x="774" y="403"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_730358_402448" xmi:uuid="f372abf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036144_199320_180455"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_933961_372045"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_343521_372069"/>
      <waypoint x="168" y="353"/>
      <waypoint x="294" y="353"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_9557_402449" xmi:uuid="f372bc70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036145_31806_180456"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_716381_372046"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_628368_372078"/>
      <waypoint x="209" y="452"/>
      <waypoint x="294" y="452"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_156128_402450" xmi:uuid="f372c870-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036145_656478_180457"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_313548_372052"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_80924_372074"/>
      <waypoint x="1281" y="441"/>
      <waypoint x="534" y="441"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_384292_402451" xmi:uuid="f372d840-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036146_516659_180458"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_850649_372138"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_242226_372126"/>
      <waypoint x="644" y="669"/>
      <waypoint x="488" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_285588_402452" xmi:uuid="f372e590-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036147_516530_180459"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_744603_372047"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_555824_372128"/>
      <waypoint x="212" y="697"/>
      <waypoint x="294" y="697"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_625403_402453" xmi:uuid="f372ee10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036147_783785_180460"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_40040_372048"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_591739_372085"/>
      <waypoint x="224" y="829"/>
      <waypoint x="301" y="829"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_958886_402454" xmi:uuid="f372fd70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036148_171572_180461"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_723694_372099"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_420282_372076"/>
      <waypoint x="644" y="592"/>
      <waypoint x="620" y="592"/>
      <waypoint x="620" y="550"/>
      <waypoint x="534" y="550"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_431866_402455" xmi:uuid="f37304b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036148_253981_180462"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_21872_372121"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_241010_372100"/>
      <waypoint x="959" y="592"/>
      <waypoint x="819" y="592"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_744481_402456" xmi:uuid="f3730b00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036149_561313_180463"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_656145_372096"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_739122_372072"/>
      <waypoint x="644" y="501"/>
      <waypoint x="534" y="501"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_139329_402457" xmi:uuid="f37312b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036150_327959_180464"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_860969_372116"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_884188_372097"/>
      <waypoint x="945" y="504"/>
      <waypoint x="822" y="504"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_801201_402459" xmi:uuid="f3731a90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036151_137165_180466"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_73422_372135"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_51328_372136"/>
      <waypoint x="959" y="770"/>
      <waypoint x="931" y="770"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_786755_402460" xmi:uuid="f3732980-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036152_264873_180467"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_401353_372133"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_263561_372130"/>
      <waypoint x="959" y="714"/>
      <waypoint x="488" y="714"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_968287_402461" xmi:uuid="f3733160-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036154_139743_180469"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_834958_372054"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_829702_372083"/>
      <waypoint x="1281" y="816"/>
      <waypoint x="454" y="816"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_462021_402462" xmi:uuid="f3733930-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036155_955323_180470"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_183838_372102"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025960_165071_372081"/>
      <waypoint x="644" y="861"/>
      <waypoint x="454" y="861"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_543922_402463" xmi:uuid="f3734120-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036155_994073_180471"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025961_615566_372123"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_730253_372103"/>
      <waypoint x="945" y="858"/>
      <waypoint x="780" y="858"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_649561_402464" xmi:uuid="f3734b80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036161_837076_180480"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_771446_372051"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_505696_372145"/>
      <waypoint x="1281" y="340"/>
      <waypoint x="836" y="340"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026828_553532_402465" xmi:uuid="f37351d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036162_612426_180481"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025960_116200_372053"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025961_786251_372140"/>
      <waypoint x="1281" y="669"/>
      <waypoint x="836" y="669"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025960_332273_372039" xmi:uuid="f3736960-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036253_675475_180508"/>
      <bounds x="1642" y="55" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1645" height="911"/>
    <name>ProcessOperationDefinition</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564037722_109457_180852" xmi:uuid="f3738f80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977045_839711_164272"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_34194_372396" xmi:uuid="f374f2f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037760_973193_180877"/>
      <ownedElement xmi:id="d05ba550-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d05ba6a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037760_973193_180877"/>
        <text>process_state_relationship:Process_state_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d05dea90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d05debd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037760_973193_180877"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="714" y="49" width="343" height="106"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_965542_372399" xmi:uuid="f3753f30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037756_186900_180876"/>
      <ownedElement xmi:id="d06bede0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d06beef0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037756_186900_180876"/>
        <text>RelationType:ExternalOwlClass</text>
      </ownedElement>
      <ownedElement xmi:id="d06e7a30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d06e7b60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037756_186900_180876"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="21" y="84" width="598" height="60"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_485452_402555" xmi:uuid="f3754950-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037754_561722_180873"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025965_119035_372394"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025965_34194_372396"/>
      <waypoint x="1069" y="67"/>
      <waypoint x="1057" y="67"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026829_104989_402556" xmi:uuid="f37550b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566025965_34194_372396"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026953_369289_411716"/>
      <waypoint x="714" y="68"/>
      <waypoint x="655" y="57"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026953_369289_411716" xmi:uuid="f3757b50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="f3757670-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f3757710-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from PartViewRelationship</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="476" y="21" width="179" height="36"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025965_119035_372394" xmi:uuid="f3759210-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564037765_85643_180878"/>
      <bounds x="1069" y="60" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1072" height="173"/>
    <name>ProcessStateRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564039850_399129_181317" xmi:uuid="f375ad90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977072_427965_164314"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_100605_372715" xmi:uuid="f3778180-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038273_405548_181000"/>
      <ownedElement xmi:id="d07a0100-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d07a0230-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038273_405548_181000"/>
        <text>Placement:TransformationSelect</text>
      </ownedElement>
      <ownedElement xmi:id="d07c0a40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d07c0b70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038273_405548_181000"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="275" width="229" height="46"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_121206_402672" xmi:uuid="d0dc8490-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039899_976290_181343"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_627946_372732"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_508768_372718"/>
      <waypoint x="1218" y="326"/>
      <waypoint x="997" y="326"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_87685_372716" xmi:uuid="f377d170-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039920_869374_181359"/>
      <ownedElement xmi:id="d08a3aa0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d08a3be0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039920_869374_181359"/>
        <text>ct2:Cartesian_transformation_2d</text>
      </ownedElement>
      <ownedElement xmi:id="d08cb150-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d08cb5c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039920_869374_181359"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d08d9060-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d08d9270-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d08e5ca0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d08e5fc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_982029_372717" xmi:uuid="d0b4d0f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-multiplication_matrix"/>
          <ownedElement xmi:id="d0a67a40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d0a67b70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-multiplication_matrix"/>
            <text>multiplication_matrix:Direction</text>
          </ownedElement>
          <ownedElement xmi:id="d0b3ed10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d0b3ee60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-multiplication_matrix"/>
            <text>[1..2]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="812" y="286" width="215" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_508768_372718" xmi:uuid="d0db95e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-translation"/>
          <ownedElement xmi:id="d0cdd960-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d0cdda90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-translation"/>
            <text>translation:Cartesian_point</text>
          </ownedElement>
          <ownedElement xmi:id="d0dabcf0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d0dabe30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-translation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="812" y="314" width="185" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="798" y="259" width="382" height="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_416687_402673" xmi:uuid="d1193280-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039896_996383_181339"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_198772_372723"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_107653_372720"/>
      <waypoint x="1218" y="165"/>
      <waypoint x="973" y="165"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_37038_372719" xmi:uuid="f3781b80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039925_765575_181360"/>
      <ownedElement xmi:id="d0ea3540-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d0ea3680-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039925_765575_181360"/>
        <text>drr:Definitional_representation_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d0ec91d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d0ec9430-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039925_765575_181360"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d0ed8bf0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d0ed8dd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d0ee68d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d0ee6ab0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_107653_372720" xmi:uuid="d11800b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_relationship-rep_1"/>
          <ownedElement xmi:id="d106c1d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d106c360-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_relationship-rep_1"/>
            <text>rep_1:Representation</text>
          </ownedElement>
          <ownedElement xmi:id="d116d180-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d116d5e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_relationship-rep_1"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="812" y="147" width="161" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="798" y="119" width="382" height="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_205629_402674" xmi:uuid="d180d870-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039897_559413_181340"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_935572_372724"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_336032_372722"/>
      <waypoint x="1498" y="140"/>
      <waypoint x="1437" y="140"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_345261_372721" xmi:uuid="f3786720-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039929_917029_181361"/>
      <ownedElement xmi:id="d129a6b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d129a7e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039929_917029_181361"/>
        <text>pdr:Property_definition_representation</text>
      </ownedElement>
      <ownedElement xmi:id="d12ccd90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d12ccec0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039929_917029_181361"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d12dd350-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d12dd480-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d12ef1b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d12ef2e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_336032_372722" xmi:uuid="d1579e20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-definition"/>
          <ownedElement xmi:id="d147ff20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1480260-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-definition"/>
            <text>definition:represented_definition</text>
          </ownedElement>
          <ownedElement xmi:id="d1567640-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d15677c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1218" y="126" width="219" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_198772_372723" xmi:uuid="d17fd9f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-used_representation"/>
          <ownedElement xmi:id="d1711520-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1711650-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-used_representation"/>
            <text>used_representation:Representation</text>
          </ownedElement>
          <ownedElement xmi:id="d17ef430-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d17ef570-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-used_representation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1218" y="154" width="241" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1211" y="98" width="265" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_997296_402675" xmi:uuid="d1d94140-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039895_155687_181338"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_609654_372754"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_875827_372725"/>
      <waypoint x="1897" y="137"/>
      <waypoint x="1851" y="137"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_935572_372724" xmi:uuid="f378b230-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039932_591492_181362"/>
      <ownedElement xmi:id="d19094b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1909640-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039932_591492_181362"/>
        <text>asp:Assigned_shape_property</text>
      </ownedElement>
      <ownedElement xmi:id="d192f470-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d192f5b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039932_591492_181362"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d19415e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1941720-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d194e910-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d194ea30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_875827_372725" xmi:uuid="d1be5580-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_shape_property-described_element"/>
          <ownedElement xmi:id="d1af4600-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1af4740-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_shape_property-described_element"/>
            <text>described_element:assigned_shape_property_select</text>
          </ownedElement>
          <ownedElement xmi:id="d1bd5ac0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1bd5c50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_shape_property-described_element"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1519" y="126" width="332" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_53950_372726" xmi:uuid="d1d85be0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_property-name"/>
          <ownedElement xmi:id="d1caf7a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1caf8e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_property-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="d1d71090-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1d711f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_property-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1519" y="196" width="109" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1498" y="98" width="360" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_277082_402676" xmi:uuid="d26df3b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039897_431658_181341"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_211808_372731"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_273012_372728"/>
      <waypoint x="1414" y="329"/>
      <waypoint x="1519" y="329"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_970780_402677" xmi:uuid="d26fb590-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039898_676773_181342"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_87685_372716"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_562857_372729"/>
      <waypoint x="1180" y="361"/>
      <waypoint x="1519" y="361"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_649940_402678" xmi:uuid="d27137a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039899_205388_181344"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_100394_372755"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_128837_372730"/>
      <waypoint x="1918" y="299"/>
      <waypoint x="1770" y="299"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_526788_372727" xmi:uuid="f378ffe0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039937_685605_181363"/>
      <ownedElement xmi:id="d1ea3000-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1ea3210-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039937_685605_181363"/>
        <text>got:Geometric_operator_transformation</text>
      </ownedElement>
      <ownedElement xmi:id="d1ecf540-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1ecf6d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039937_685605_181363"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d1ee01b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1ee0300-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d1eef3e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d1eef510-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_273012_372728" xmi:uuid="d2195ae0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
          <ownedElement xmi:id="d209faa0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d209fbd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
            <text>source:Axis_placement</text>
          </ownedElement>
          <ownedElement xmi:id="d2186340-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d21864e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1519" y="315" width="172" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_562857_372729" xmi:uuid="d242b020-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
          <ownedElement xmi:id="d233efb0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d233f0d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
            <text>target:cartesian_transformation</text>
          </ownedElement>
          <ownedElement xmi:id="d241a660-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d241a800-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1519" y="343" width="212" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_128837_372730" xmi:uuid="d26d06c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
          <ownedElement xmi:id="d25d9bc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d25d9d60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
            <text>template_definition:Geometric_model</text>
          </ownedElement>
          <ownedElement xmi:id="d26beb10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d26bec50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1519" y="288" width="251" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1498" y="252" width="360" height="126"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_211808_372731" xmi:uuid="f3794d40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039940_200928_181364"/>
      <ownedElement xmi:id="d280d700-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d280d830-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039940_200928_181364"/>
        <text>ap:Axis_placement</text>
      </ownedElement>
      <ownedElement xmi:id="d2836490-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d28365d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039940_200928_181364"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d2848c20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2848dc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d2855d80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2855ee0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_627946_372732" xmi:uuid="d2aeee80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
          <ownedElement xmi:id="d2a02170-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2a022c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
            <text>location:Cartesian_point</text>
          </ownedElement>
          <ownedElement xmi:id="d2ae0d40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2ae0e70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1218" y="308" width="169" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1211" y="280" width="203" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_502912_372733" xmi:uuid="f37996c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039944_939150_181365"/>
      <ownedElement xmi:id="d2b60680-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2b607e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039944_939150_181365"/>
        <text>selectTrans:TransformationSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_44560_372734" xmi:uuid="d2beba20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849439_637509_73441"/>
        <ownedElement xmi:id="d2bdbdf0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2bdc020-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849439_637509_73441"/>
          <bounds x="275" y="278" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="329" y="287" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_917853_372736" xmi:uuid="d2c533b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849442_925655_73442"/>
        <ownedElement xmi:id="d2c43860-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2c43990-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849442_925655_73442"/>
          <bounds x="525" y="98" width="209" height="13"/>
          <text>geometricRepresentationRelationship [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="608" y="135" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_355683_372738" xmi:uuid="d2cc1b50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849444_410823_73443"/>
        <ownedElement xmi:id="d2cb0300-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2cb04a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849444_410823_73443"/>
          <bounds x="626" y="290" width="159" height="13"/>
          <text>cartesianTransformation2d [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="608" y="299" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_145681_372740" xmi:uuid="d2d2f460-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849445_464421_73444"/>
        <ownedElement xmi:id="d2d1eea0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2d1f020-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849445_464421_73444"/>
          <bounds x="628" y="400" width="159" height="13"/>
          <text>cartesianTransformation3d [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="608" y="413" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="329" y="119" width="294" height="350"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_860640_402682" xmi:uuid="d33c6220-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039905_869453_181349"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_9937_372746"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_148818_372744"/>
      <waypoint x="1218" y="473"/>
      <waypoint x="997" y="473"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_632281_372742" xmi:uuid="f379e2f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039953_261221_181367"/>
      <ownedElement xmi:id="d2e35880-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2e359c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039953_261221_181367"/>
        <text>ct3:Cartesian_transformation_3d</text>
      </ownedElement>
      <ownedElement xmi:id="d2e60c60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2e60da0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039953_261221_181367"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d2e74200-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2e749a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d2e81f90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d2e820c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_605917_372743" xmi:uuid="d3125580-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-multiplication_matrix"/>
          <ownedElement xmi:id="d3035fd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d3036350-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-multiplication_matrix"/>
            <text>multiplication_matrix:Direction</text>
          </ownedElement>
          <ownedElement xmi:id="d3118d60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d3118f30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-multiplication_matrix"/>
            <text>[1..3]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="812" y="434" width="215" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_148818_372744" xmi:uuid="d33b4d70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-translation"/>
          <ownedElement xmi:id="d32caa80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d32cabe0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-translation"/>
            <text>translation:Cartesian_point</text>
          </ownedElement>
          <ownedElement xmi:id="d33a5d80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d33a5eb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-translation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="812" y="461" width="185" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="798" y="406" width="382" height="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_405859_372745" xmi:uuid="f37a2e90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039957_337320_181368"/>
      <ownedElement xmi:id="d34c68a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d34c69d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039957_337320_181368"/>
        <text>ap1:Axis_placement</text>
      </ownedElement>
      <ownedElement xmi:id="d34f39e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d34f3b40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039957_337320_181368"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d3504d70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d3504f20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d35139d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d3513b30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_9937_372746" xmi:uuid="d37aa090-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
          <ownedElement xmi:id="d36b67e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d36b6920-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
            <text>location:Cartesian_point</text>
          </ownedElement>
          <ownedElement xmi:id="d379b090-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d379b1d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1218" y="455" width="169" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1211" y="427" width="203" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_246318_372747" xmi:uuid="f37a81e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039962_70177_181369"/>
      <ownedElement xmi:id="d38aae40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d38aaf70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039962_70177_181369"/>
        <text>got1:Geometric_operator_transformation</text>
      </ownedElement>
      <ownedElement xmi:id="d38d6940-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d38d6a80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039962_70177_181369"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d38e9060-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d38e9170-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d38f8780-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d38f88b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_637051_372748" xmi:uuid="d3ba2040-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
          <ownedElement xmi:id="d3aa5d70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d3aa5ec0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
            <text>source:Axis_placement</text>
          </ownedElement>
          <ownedElement xmi:id="d3b93c70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d3b93dc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1519" y="468" width="172" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_332518_372749" xmi:uuid="d3e496e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
          <ownedElement xmi:id="d3d50dd0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d3d50f00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
            <text>target:cartesian_transformation</text>
          </ownedElement>
          <ownedElement xmi:id="d3e2cd90-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d3e2cfb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1519" y="496" width="212" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_477412_372750" xmi:uuid="d40eee00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
          <ownedElement xmi:id="d3fff220-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d3fff4a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
            <text>template_definition:Geometric_model</text>
          </ownedElement>
          <ownedElement xmi:id="d40de2d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d40de400-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1519" y="441" width="251" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1498" y="413" width="360" height="118"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_297850_372751" xmi:uuid="f37accc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039966_902907_181370"/>
      <ownedElement xmi:id="d4118550-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d4118770-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039966_902907_181370"/>
        <text>propertyName:String</text>
      </ownedElement>
      <ownedElement xmi:id="d4142cf0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d4143120-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039966_902907_181370"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="1260" y="203" width="221" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_780624_402688" xmi:uuid="d4526ab0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039907_884979_181352"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_477412_372750"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_100394_372755"/>
      <waypoint x="1770" y="455"/>
      <waypoint x="1876" y="455"/>
      <waypoint x="1876" y="298"/>
      <waypoint x="1918" y="298"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_609654_372754" xmi:uuid="f37b1830-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039916_739998_181358"/>
      <ownedElement xmi:id="d4232ef0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d4233030-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039916_739998_181358"/>
        <text>tool_part_relationship:Part_definition_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d425c550-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d425c6a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039916_739998_181358"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="d426c060-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d426c190-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d427a1c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d427a2d0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_100394_372755" xmi:uuid="d4516500-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-primary_shape_representation"/>
          <ownedElement xmi:id="d441c100-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d441c230-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-primary_shape_representation"/>
            <text>primary_shape_representation:shape_model</text>
          </ownedElement>
          <ownedElement xmi:id="d45079b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d4507ae0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-primary_shape_representation"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1918" y="288" width="304" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1897" y="35" width="332" height="288"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_422278_372757" xmi:uuid="f37b6160-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039911_768379_181357"/>
      <ownedElement xmi:id="d462d460-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d462d650-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039911_768379_181357"/>
        <text>RelationType:ExternalOwlClass</text>
      </ownedElement>
      <ownedElement xmi:id="d4656860-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d46569b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039911_768379_181357"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="518" width="591" height="60"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_408713_402679" xmi:uuid="f37b6af0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039900_255993_181345"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_44560_372734"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_100605_372715"/>
      <waypoint x="329" y="298"/>
      <waypoint x="264" y="298"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_489803_402680" xmi:uuid="f37b7190-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039901_95536_181346"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_37038_372719"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_917853_372736"/>
      <waypoint x="798" y="144"/>
      <waypoint x="623" y="144"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_843212_402681" xmi:uuid="f37b7850-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039903_457874_181347"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_87685_372716"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_355683_372738"/>
      <waypoint x="798" y="305"/>
      <waypoint x="623" y="305"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_507536_402683" xmi:uuid="f37b7ec0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039904_290860_181348"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_632281_372742"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_145681_372740"/>
      <waypoint x="798" y="420"/>
      <waypoint x="623" y="420"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_439265_402684" xmi:uuid="f37b8890-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039906_444285_181350"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_332518_372749"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_632281_372742"/>
      <waypoint x="1519" y="508"/>
      <waypoint x="1180" y="508"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_682197_402685" xmi:uuid="f37b9370-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039907_558133_181351"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_637051_372748"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_405859_372745"/>
      <waypoint x="1519" y="476"/>
      <waypoint x="1414" y="476"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_850482_402686" xmi:uuid="f37bdb30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039908_804829_181353"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_607547_372752"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_609654_372754"/>
      <waypoint x="2241" y="49"/>
      <waypoint x="2229" y="49"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_383579_402687" xmi:uuid="f37be400-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039909_893010_181354"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_53950_372726"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_297850_372751"/>
      <waypoint x="1519" y="214"/>
      <waypoint x="1481" y="214"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_182899_402689" xmi:uuid="f37be900-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <source xmi:idref="_18_4_1_65b021e_1688566025969_609654_372754"/>
      <target xmi:idref="_18_4_1_65b021e_1688566026954_500435_411717"/>
      <waypoint x="1897" y="98"/>
      <waypoint x="1827" y="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026954_500435_411717" xmi:uuid="f37c1450-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <ownedElement xmi:id="f37c1010-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f37c10c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
        <text>Inherited from PartViewRelationship</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="255"/>
      </localStyle>
      <bounds x="1701" y="28" width="179" height="36"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_607547_372752" xmi:uuid="f37c2c40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039948_77737_181366"/>
      <bounds x="2241" y="41" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="2244" height="593"/>
    <name>ToolPartRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564038511_416881_181013" xmi:uuid="f37c4710-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977054_525558_164279"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_246028_372485" xmi:uuid="f3851ad0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038574_530482_181055"/>
      <ownedElement xmi:id="f3836680-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f3836780-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038574_530482_181055"/>
        <text>Placement:TransformationSelect</text>
      </ownedElement>
      <ownedElement xmi:id="f3850a50-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f3850b40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038574_530482_181055"/>
        <text>[0..1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="264" width="229" height="46"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_597411_402589" xmi:uuid="f46ed980-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038572_916750_181051"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_724139_372532"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_119660_372491"/>
      <waypoint x="1742" y="564"/>
      <waypoint x="1869" y="564"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_240912_402590" xmi:uuid="f46f68b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038573_112580_181052"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_195890_372531"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_615725_372492"/>
      <waypoint x="1742" y="665"/>
      <waypoint x="1869" y="665"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_372381_372486" xmi:uuid="f46fec50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038583_515305_181057"/>
      <ownedElement xmi:id="f3908d20-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f3908e30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038583_515305_181057"/>
        <text>same_time_machining_relationship:Same_time_machining_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="f3928370-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f3928470-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038583_515305_181057"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="f392c630-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f392c6f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f392da10-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f392da60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_339910_372490" xmi:uuid="f3fbecd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-primary_shape_representation"/>
          <ownedElement xmi:id="f3f14140-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f3f14260-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-primary_shape_representation"/>
            <text>primary_shape_representation:shape_model</text>
          </ownedElement>
          <ownedElement xmi:id="f3fbcfe0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f3fbd0e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-View_definition_relationship-primary_shape_representation"/>
            <text>[0..1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1869" y="231" width="304" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_119660_372491" xmi:uuid="f41ad100-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Part_occurrence_relationship-related_view"/>
          <ownedElement xmi:id="f41051f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4105420-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Part_occurrence_relationship-related_view"/>
            <text>related_view:Product_occurrence</text>
          </ownedElement>
          <ownedElement xmi:id="f41ab3a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f41ab4b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Part_occurrence_relationship-related_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1869" y="553" width="228" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_615725_372492" xmi:uuid="f439e090-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Part_occurrence_relationship-relating_view"/>
          <ownedElement xmi:id="f42f5890-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f42f59a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Part_occurrence_relationship-relating_view"/>
            <text>relating_view:Product_occurrence</text>
          </ownedElement>
          <ownedElement xmi:id="f439c330-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f439c430-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Part_occurrence_relationship-relating_view"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1869" y="651" width="231" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1848" y="42" width="353" height="644"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_160643_372495" xmi:uuid="f4865c30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038587_662225_181058"/>
      <ownedElement xmi:id="f474fab0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f474fc40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038587_662225_181058"/>
        <text>splitTransformation:TransformationSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_308866_372496" xmi:uuid="f47a8e90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849439_637509_73441"/>
        <ownedElement xmi:id="f47a6430-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f47a6570-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849439_637509_73441"/>
          <bounds x="268" y="267" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="322" y="276" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_733272_372498" xmi:uuid="f47e8e00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849442_925655_73442"/>
        <ownedElement xmi:id="f47e7160-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f47e7260-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849442_925655_73442"/>
          <bounds x="493" y="89" width="209" height="13"/>
          <text>geometricRepresentationRelationship [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="475" y="98" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_686225_372500" xmi:uuid="f4828170-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849444_410823_73443"/>
        <ownedElement xmi:id="f48263c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f48264c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849444_410823_73443"/>
          <bounds x="493" y="212" width="159" height="13"/>
          <text>cartesianTransformation2d [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="475" y="221" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_259278_372502" xmi:uuid="f48653d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
        <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849445_464421_73444"/>
        <ownedElement xmi:id="f4863550-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4863650-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <modelElement href="../ProductDataManagement/ProductDataManagement.xmi#_18_4_1_aec0217_1569499849445_464421_73444"/>
          <bounds x="493" y="395" width="159" height="13"/>
          <text>cartesianTransformation3d [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="475" y="404" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="322" y="91" width="168" height="385"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_324368_402593" xmi:uuid="f4f19e70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038564_812390_181040"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_88_372519"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_396912_372506"/>
      <waypoint x="1099" y="473"/>
      <waypoint x="1421" y="473"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_767893_402594" xmi:uuid="f4f22990-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038572_545597_181050"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_339910_372490"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_364427_372507"/>
      <waypoint x="1869" y="241"/>
      <waypoint x="1810" y="241"/>
      <waypoint x="1810" y="410"/>
      <waypoint x="1672" y="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_338367_372504" xmi:uuid="f4f2a180-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038595_752570_181060"/>
      <ownedElement xmi:id="f491e3a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f491e4c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038595_752570_181060"/>
        <text>got1:Geometric_operator_transformation</text>
      </ownedElement>
      <ownedElement xmi:id="f4938fe0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f49390d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038595_752570_181060"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f493b660-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f493b710-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f493c820-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f493c8f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_662375_372505" xmi:uuid="f4b25dd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
          <ownedElement xmi:id="f4a7e8c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4a7e9b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
            <text>source:Axis_placement</text>
          </ownedElement>
          <ownedElement xmi:id="f4b23ea0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4b23f90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1421" y="426" width="172" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_396912_372506" xmi:uuid="f4d20f40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
          <ownedElement xmi:id="f4c6b830-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4c6b930-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
            <text>target:cartesian_transformation</text>
          </ownedElement>
          <ownedElement xmi:id="f4d1eea0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4d1ef90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1421" y="461" width="212" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_364427_372507" xmi:uuid="f4f18630-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
          <ownedElement xmi:id="f4e6c680-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4e6c790-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
            <text>template_definition:Geometric_model</text>
          </ownedElement>
          <ownedElement xmi:id="f4f16890-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4f16990-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1421" y="399" width="251" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1407" y="371" width="360" height="125"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_646853_372508" xmi:uuid="f51f5670-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038599_811318_181061"/>
      <ownedElement xmi:id="f4fe2730-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4fe2830-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038599_811318_181061"/>
        <text>ap1:Axis_placement</text>
      </ownedElement>
      <ownedElement xmi:id="f4ffbf60-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4ffc050-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038599_811318_181061"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f4ffe140-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4ffe1e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f4fff2b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f4fff350-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_368664_372509" xmi:uuid="f51f4ea0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
          <ownedElement xmi:id="f514b2f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f514b3e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
            <text>location:Cartesian_point</text>
          </ownedElement>
          <ownedElement xmi:id="f51f3000-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f51f30f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1127" y="420" width="169" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1120" y="392" width="203" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_759397_402596" xmi:uuid="f58db100-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038561_962833_181037"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_228850_372514"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_981390_372511"/>
      <waypoint x="1323" y="277"/>
      <waypoint x="1421" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_605520_402597" xmi:uuid="f58e4640-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038565_686074_181041"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_92816_372516"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_636774_372512"/>
      <waypoint x="1092" y="315"/>
      <waypoint x="1421" y="315"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_446044_402598" xmi:uuid="f58ecb00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038567_629373_181044"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_339910_372490"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_850268_372513"/>
      <waypoint x="1869" y="241"/>
      <waypoint x="1672" y="241"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_718109_372510" xmi:uuid="f58f50b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038604_727984_181062"/>
      <ownedElement xmi:id="f52ac4f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f52ac5f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038604_727984_181062"/>
        <text>got:Geometric_operator_transformation</text>
      </ownedElement>
      <ownedElement xmi:id="f52ca2e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f52ca3d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038604_727984_181062"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f52cceb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f52ccf60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f52ce440-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f52ce4e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025966_981390_372511" xmi:uuid="f54cf540-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
          <ownedElement xmi:id="f541e140-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f541e240-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
            <text>source:Axis_placement</text>
          </ownedElement>
          <ownedElement xmi:id="f54cd4d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f54cd5e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-source"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1421" y="265" width="172" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_636774_372512" xmi:uuid="f56e13c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
          <ownedElement xmi:id="f5628af0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f5628c10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
            <text>target:cartesian_transformation</text>
          </ownedElement>
          <ownedElement xmi:id="f56df460-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f56df570-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_operator_transformation-target"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1421" y="301" width="212" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_850268_372513" xmi:uuid="f58d9560-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
          <ownedElement xmi:id="f582df20-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f582e160-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
            <text>template_definition:Geometric_model</text>
          </ownedElement>
          <ownedElement xmi:id="f58d73c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f58d79a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Geometric_placement_operation-template_definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1421" y="231" width="251" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1407" y="203" width="360" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_228850_372514" xmi:uuid="f5bc1700-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038608_811723_181063"/>
      <ownedElement xmi:id="f59acd40-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f59ace40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038608_811723_181063"/>
        <text>ap:Axis_placement</text>
      </ownedElement>
      <ownedElement xmi:id="f59c6ef0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f59c6fd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038608_811723_181063"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f59c9350-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f59c93f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f59ca6a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f59ca740-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_879174_372515" xmi:uuid="f5bc06d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
          <ownedElement xmi:id="f5b19ca0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f5b1a1c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
            <text>location:Cartesian_point</text>
          </ownedElement>
          <ownedElement xmi:id="f5bbe320-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f5bbe410-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Axis_placement-location"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1127" y="266" width="169" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1120" y="238" width="203" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_948720_402599" xmi:uuid="f60d0cf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038567_625821_181043"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_879174_372515"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_67181_372518"/>
      <waypoint x="1127" y="280"/>
      <waypoint x="913" y="280"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_92816_372516" xmi:uuid="f60d9c00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038612_400028_181064"/>
      <ownedElement xmi:id="f5c92e20-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f5c92f20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038612_400028_181064"/>
        <text>ct2:Cartesian_transformation_2d</text>
      </ownedElement>
      <ownedElement xmi:id="f5cade50-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f5cadf50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038612_400028_181064"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f5cb1330-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f5cb1420-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f5cb2f90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f5cb34a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_780972_372517" xmi:uuid="f5ec87c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-multiplication_matrix"/>
          <ownedElement xmi:id="f5e144d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f5e145d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-multiplication_matrix"/>
            <text>multiplication_matrix:Direction</text>
          </ownedElement>
          <ownedElement xmi:id="f5ec69b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f5ec6ab0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-multiplication_matrix"/>
            <text>[1..2]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="728" y="238" width="215" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_67181_372518" xmi:uuid="f60cf120-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-translation"/>
          <ownedElement xmi:id="f6021840-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6021960-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-translation"/>
            <text>translation:Cartesian_point</text>
          </ownedElement>
          <ownedElement xmi:id="f60ccd70-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f60ccfb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_2d-translation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="728" y="266" width="185" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="714" y="210" width="378" height="112"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_910278_402600" xmi:uuid="f659b110-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038566_878468_181042"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_368664_372509"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_889437_372521"/>
      <waypoint x="1127" y="434"/>
      <waypoint x="913" y="434"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_88_372519" xmi:uuid="f65a3640-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038617_304395_181065"/>
      <ownedElement xmi:id="f618ff60-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6190060-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038617_304395_181065"/>
        <text>ct3:Cartesian_transformation_3d</text>
      </ownedElement>
      <ownedElement xmi:id="f61aa820-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f61aa910-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038617_304395_181065"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f61ae710-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f61aea50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f61afbe0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f61afc80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_228069_372520" xmi:uuid="f63a62b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-multiplication_matrix"/>
          <ownedElement xmi:id="f62f9a30-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f62f9b30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-multiplication_matrix"/>
            <text>multiplication_matrix:Direction</text>
          </ownedElement>
          <ownedElement xmi:id="f63a42e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f63a43d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-multiplication_matrix"/>
            <text>[1..3]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="728" y="393" width="215" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_889437_372521" xmi:uuid="f6599520-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-translation"/>
          <ownedElement xmi:id="f64efbd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f64efdf0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-translation"/>
            <text>translation:Cartesian_point</text>
          </ownedElement>
          <ownedElement xmi:id="f6597550-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6597650-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Cartesian_transformation_3d-translation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="728" y="420" width="185" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="714" y="364" width="385" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_225212_402601" xmi:uuid="f6879890-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038569_328010_181046"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_897010_372529"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_21863_372523"/>
      <waypoint x="1134" y="119"/>
      <waypoint x="889" y="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_149443_372522" xmi:uuid="f6881770-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038622_906504_181066"/>
      <ownedElement xmi:id="f665e470-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f665e570-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038622_906504_181066"/>
        <text>drr:Definitional_representation_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="f6679cc0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6679e00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038622_906504_181066"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f6680830-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6680900-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f6681a00-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6681a90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_21863_372523" xmi:uuid="f6877d00-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_relationship-rep_1"/>
          <ownedElement xmi:id="f67cd700-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f67cd800-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_relationship-rep_1"/>
            <text>rep_1:Representation</text>
          </ownedElement>
          <ownedElement xmi:id="f6875b50-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6875c50-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Representation_relationship-rep_1"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="728" y="105" width="161" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="714" y="77" width="382" height="64"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_897781_402602" xmi:uuid="f6c92810-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038570_382305_181047"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_372381_372486"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_516220_372525"/>
      <waypoint x="1848" y="95"/>
      <waypoint x="1753" y="95"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_660619_372524" xmi:uuid="f6c9a590-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038626_324339_181067"/>
      <ownedElement xmi:id="f6938ec0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6938fd0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038626_324339_181067"/>
        <text>asp:Assigned_shape_property</text>
      </ownedElement>
      <ownedElement xmi:id="f6953e40-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6953f30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038626_324339_181067"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f69562d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6956380-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f6957910-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f69579b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_516220_372525" xmi:uuid="f6b42f10-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_shape_property-described_element"/>
          <ownedElement xmi:id="f6a99710-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6a99810-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_shape_property-described_element"/>
            <text>described_element:assigned_shape_property_select</text>
          </ownedElement>
          <ownedElement xmi:id="f6b41050-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6b41140-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_shape_property-described_element"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1421" y="84" width="332" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_61255_372526" xmi:uuid="f6c90fa0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_property-name"/>
          <ownedElement xmi:id="f6be77c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6be78b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_property-name"/>
            <text>name:String</text>
          </ownedElement>
          <ownedElement xmi:id="f6c8ed30-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6c8ef60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Assigned_property-name"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="1421" y="151" width="109" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1407" y="56" width="360" height="133"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_306164_402603" xmi:uuid="f714f590-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038563_716473_181039"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_660619_372524"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_575030_372528"/>
      <waypoint x="1407" y="91"/>
      <waypoint x="1353" y="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_751547_372527" xmi:uuid="f7158730-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038630_597568_181068"/>
      <ownedElement xmi:id="f6d4e600-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6d4e710-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038630_597568_181068"/>
        <text>pdr:Property_definition_representation</text>
      </ownedElement>
      <ownedElement xmi:id="f6d686b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6d687b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038630_597568_181068"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="f6d6ae10-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6d6aec0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="f6d6c250-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6d6c2f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_575030_372528" xmi:uuid="f6f56730-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-definition"/>
          <ownedElement xmi:id="f6eb2e90-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6eb3460-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-definition"/>
            <text>definition:represented_definition</text>
          </ownedElement>
          <ownedElement xmi:id="f6f54c40-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f6f54d40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-definition"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1134" y="77" width="219" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_897010_372529" xmi:uuid="f714d690-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-used_representation"/>
          <ownedElement xmi:id="f709f3a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f709f4b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-used_representation"/>
            <text>used_representation:Representation</text>
          </ownedElement>
          <ownedElement xmi:id="f714ad80-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f714ae90-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Property_definition_representation-used_representation"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="1134" y="105" width="241" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1120" y="49" width="265" height="91"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_314966_372530" xmi:uuid="f718c3f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038634_760356_181069"/>
      <ownedElement xmi:id="f7172a30-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f7172b20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038634_760356_181069"/>
        <text>propertyName:String</text>
      </ownedElement>
      <ownedElement xmi:id="f718b4e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f718b5d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038634_760356_181069"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="1169" y="151" width="221" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_195890_372531" xmi:uuid="f7257e30-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038638_868762_181070"/>
      <ownedElement xmi:id="f723d5c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f723d6b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038638_868762_181070"/>
        <text>relating:Product_occurrence</text>
      </ownedElement>
      <ownedElement xmi:id="f72569d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f7256ac0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038638_868762_181070"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1358" y="609" width="384" height="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_724139_372532" xmi:uuid="f7325f70-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038642_521195_181071"/>
      <ownedElement xmi:id="f730a430-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f730a530-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038642_521195_181071"/>
        <text>related:Product_occurrence</text>
      </ownedElement>
      <ownedElement xmi:id="f73248c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f73249d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038642_521195_181071"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="1358" y="518" width="384" height="88"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_882433_372533" xmi:uuid="f73597f0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038579_362762_181056"/>
      <ownedElement xmi:id="f733f5d0-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f733f6c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038579_362762_181056"/>
        <text>RelationType:ExternalOwlClass</text>
      </ownedElement>
      <ownedElement xmi:id="f7358430-0d30-013c-5e2f-5b8e392dc4e5" xmi:uuid="f7358640-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038579_362762_181056"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="564" width="595" height="60"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_184485_402591" xmi:uuid="f735a1a0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038558_748433_181034"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_246028_372485"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_308866_372496"/>
      <waypoint x="264" y="287"/>
      <waypoint x="322" y="287"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_343400_402592" xmi:uuid="f735ae40-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038559_435788_181035"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_372381_372486"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_76789_372534"/>
      <waypoint x="2201" y="63"/>
      <waypoint x="2213" y="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_965375_402595" xmi:uuid="f735b6b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038560_394670_181036"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025966_662375_372505"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_646853_372508"/>
      <waypoint x="1421" y="438"/>
      <waypoint x="1323" y="438"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_998169_402604" xmi:uuid="f735bf60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038561_145610_181038"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_61255_372526"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025967_314966_372530"/>
      <waypoint x="1421" y="161"/>
      <waypoint x="1390" y="161"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_800918_402605" xmi:uuid="f735c820-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038568_140727_181045"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_149443_372522"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_733272_372498"/>
      <waypoint x="714" y="105"/>
      <waypoint x="490" y="105"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_9342_402606" xmi:uuid="f735d5b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038570_125446_181048"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_92816_372516"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_686225_372500"/>
      <waypoint x="714" y="228"/>
      <waypoint x="490" y="228"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_814769_402607" xmi:uuid="f735ddb0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038571_525526_181049"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025967_88_372519"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025966_259278_372502"/>
      <waypoint x="714" y="410"/>
      <waypoint x="490" y="410"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025967_76789_372534" xmi:uuid="f735fec0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038591_706486_181059"/>
      <bounds x="2213" y="56" width="15" height="15"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="2216" height="712"/>
    <name>SameTimeMachiningRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1688564039499_940186_181206" xmi:uuid="f7363580-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977062_967795_164287"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_909346_372640" xmi:uuid="f739d1c0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039580_836240_181258"/>
      <ownedElement xmi:id="d8f30550-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d8f30680-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039580_836240_181258"/>
        <text>Related:ProcessOperationDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="d8f5a690-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d8f5a7c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039580_836240_181258"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_495317_372641" xmi:uuid="d8f93dd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036253_675475_180508"/>
        <ownedElement xmi:id="d8f86100-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d8f86220-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036253_675475_180508"/>
          <bounds x="284" y="745" width="297" height="13"/>
          <text>processOperationDefinition : Process_operation_definition [1]</text>
        </ownedElement>
        <bounds x="266" y="754" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="742" width="239" height="37"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_716517_372643" xmi:uuid="f73a1f60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036276_909988_180516"/>
      <ownedElement xmi:id="d8fd4200-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d8fd4370-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036276_909988_180516"/>
        <text>Relating:ProcessOperationDefinition</text>
      </ownedElement>
      <ownedElement xmi:id="d9006030-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9006530-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036276_909988_180516"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_157162_372644" xmi:uuid="d9046580-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036253_675475_180508"/>
        <ownedElement xmi:id="d9035ed0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9036030-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564036253_675475_180508"/>
          <bounds x="287" y="794" width="297" height="13"/>
          <text>processOperationDefinition : Process_operation_definition [1]</text>
        </ownedElement>
        <bounds x="269" y="803" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="255" blue="204"/>
      </localStyle>
      <bounds x="35" y="791" width="242" height="37"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_236086_372647" xmi:uuid="f73abce0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039584_82067_181259"/>
      <ownedElement xmi:id="d913f090-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d913f1b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039584_82067_181259"/>
        <text>process_operation_definition_relationship:Process_operation_definition_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="d9169470-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d91695a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039584_82067_181259"/>
        <text>[1]</text>
      </ownedElement>
      <ownedElement xmi:id="d9178f20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d91795b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d9185210-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9185620-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_967471_372648" xmi:uuid="d9437c60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-description"/>
          <ownedElement xmi:id="d933b830-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d933b970-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-description"/>
            <text>description:text</text>
          </ownedElement>
          <ownedElement xmi:id="d94210d0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9421280-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-description"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="882" y="651" width="123" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_703804_372649" xmi:uuid="d9753d20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-related"/>
          <ownedElement xmi:id="d9664aa0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9664be0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-related"/>
            <text>related:Process_operation_definition</text>
          </ownedElement>
          <ownedElement xmi:id="d9744f60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9745120-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-related"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="882" y="749" width="241" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_802847_372650" xmi:uuid="d99f9180-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-relating"/>
          <ownedElement xmi:id="d98ff8c0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d98ffa80-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-relating"/>
            <text>relating:Process_operation_definition</text>
          </ownedElement>
          <ownedElement xmi:id="d99ea170-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d99ea3e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-relating"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="882" y="798" width="244" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_476094_372651" xmi:uuid="d9be8960-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-relation_type"/>
          <ownedElement xmi:id="d9adf9e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9adfb20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-relation_type"/>
            <text>relation_type:String</text>
          </ownedElement>
          <ownedElement xmi:id="d9bd61a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9bd62f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Process_operation_definition_relationship-relation_type"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="882" y="700" width="144" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="861" y="609" width="490" height="224"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_128171_402649" xmi:uuid="da38c8a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039568_266751_181244"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_236086_372647"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_152963_372694"/>
      <waypoint x="900" y="609"/>
      <waypoint x="900" y="469"/>
      <waypoint x="645" y="469"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_230336_372693" xmi:uuid="f73e60b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039634_267088_181271"/>
      <ownedElement xmi:id="d9ce1d70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9ce1ee0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039634_267088_181271"/>
        <text>ia1:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="d9d0f440-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9d0f630-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039634_267088_181271"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="d9d21bf0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9d21da0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="d9d31170-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9d31710-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_152963_372694" xmi:uuid="d9fd1420-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="d9edd6b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9edd9f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="d9fc1900-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="d9fc1a40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="455" width="183" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_976987_372695" xmi:uuid="da1aa5e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
          <ownedElement xmi:id="da0b6fe0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da0b7110-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>identifier:String</text>
          </ownedElement>
          <ownedElement xmi:id="da19b4e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da19b850-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-identifier"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="462" y="427" width="122" height="25"/>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_871316_372696" xmi:uuid="da37bc40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
          <ownedElement xmi:id="da28a8a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da28aa30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>role:String</text>
          </ownedElement>
          <ownedElement xmi:id="da368ab0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da368bf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-role"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle fontName="Arial" fontSize="">
            <fillColor red="231" green="231" blue="231"/>
          </localStyle>
          <bounds x="465" y="483" width="94" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="448" y="399" width="249" height="119"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_568816_372697" xmi:uuid="f73eb7e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039638_526101_181272"/>
      <ownedElement xmi:id="da3ca900-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da3caa70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039638_526101_181272"/>
        <text>theRole:String</text>
      </ownedElement>
      <ownedElement xmi:id="da3f4f20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da3f5060-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039638_526101_181272"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="231" green="231" blue="231"/>
      </localStyle>
      <bounds x="252" y="483" width="176" height="25"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_620074_372705" xmi:uuid="f73ff680-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039655_231532_181276"/>
      <ownedElement xmi:id="da4eb910-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da4eba90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039655_231532_181276"/>
        <text>defaultType:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_392999_372706" xmi:uuid="da5f2710-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="da5e4460-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da5e45a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="560" y="714" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="616" y="705" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_967381_372708" xmi:uuid="da6e0e90-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="da6d3cc0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da6d3ee0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="811" y="694" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="793" y="703" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="616" y="693" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_171173_372710" xmi:uuid="f7404540-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039659_910647_181277"/>
      <ownedElement xmi:id="da7cd040-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da7cd170-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039659_910647_181277"/>
        <text>defaultDesc:DefaultString</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_905538_372711" xmi:uuid="da8d3b50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
        <ownedElement xmi:id="da8c6ae0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da8c6c30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501079956255_160965_23655"/>
          <bounds x="560" y="665" width="51" height="13"/>
          <text>input [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="616" y="656" width="15" height="15"/>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1688566025969_708490_372713" xmi:uuid="da9bd870-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
        <ownedElement xmi:id="da9abec0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="da9ac040-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080030477_871401_23660"/>
          <bounds x="811" y="645" width="29" height="13"/>
          <text>str [1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="793" y="654" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="616" y="644" width="192" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_487845_402644" xmi:uuid="f7405080-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039555_829147_181227"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_236086_372647"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_699128_372633"/>
      <waypoint x="1232" y="609"/>
      <waypoint x="1232" y="578"/>
      <waypoint x="1363" y="578"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026830_332667_402652" xmi:uuid="f7405c80-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039557_843158_181229"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_871316_372696"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_568816_372697"/>
      <waypoint x="465" y="494"/>
      <waypoint x="428" y="494"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_269127_402664" xmi:uuid="f740fb60-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039569_573986_181246"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_703804_372649"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_495317_372641"/>
      <waypoint x="882" y="760"/>
      <waypoint x="281" y="760"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_191483_402665" xmi:uuid="f74103b0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039570_707481_181247"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_802847_372650"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025968_157162_372644"/>
      <waypoint x="882" y="809"/>
      <waypoint x="284" y="809"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_453447_402670" xmi:uuid="f7412f20-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039575_632399_181254"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_476094_372651"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_967381_372708"/>
      <waypoint x="882" y="711"/>
      <waypoint x="808" y="711"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566026831_540424_402671" xmi:uuid="f74136e0-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039576_613290_181255"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_967471_372648"/>
      <target xmi:idref="_18_4_1_65b021e_1688566025969_708490_372713"/>
      <waypoint x="882" y="662"/>
      <waypoint x="808" y="662"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1688566025968_699128_372633" xmi:uuid="f7415070-0d30-013c-5e2f-5b8e392dc4e5" xmi:type="umldi:UMLShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564039590_807608_181260"/>
      <bounds x="1363" y="573" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692804781826_375141_91937" xmi:uuid="da9d5f40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
      <modelElement xmi:idref="_18_4_1_2b2015d_1509724731836_533627_29440"/>
      <bounds x="448" y="21" width="115" height="46"/>
      <isIcon>true</isIcon>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805124187_933652_93296" xmi:uuid="daf555b0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805128188_592431_93297"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_236086_372647"/>
      <target xmi:idref="_18_4_1_65b021e_1692804781827_432597_91944"/>
      <waypoint x="900" y="609"/>
      <waypoint x="900" y="116"/>
      <waypoint x="646" y="116"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_235822_91938" xmi:uuid="daf63ca0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
      <ownedElement xmi:id="dab865b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dab86740-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>classifiedAsAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="dac6c4a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dac6c730-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725614441_605665_31736"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="dac7c200-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dac7c360-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dac8c420-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dac8c950-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_432597_91944" xmi:uuid="daf47fd0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="dae4cd30-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dae4cea0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="daf37450-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="daf37590-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="105" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="448" y="77" width="288" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_690458_91939" xmi:uuid="db2fd3a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
      <ownedElement xmi:id="db12be40-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="db12bf70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_185923_30422"/>
        <text>selectDescription:DescribeSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_459389_91945" xmi:uuid="db2fb9f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
        <ownedElement xmi:id="db2ead80-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="db2eaf20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502113997832_66176_25454"/>
          <bounds x="515" y="648" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="497" y="657" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="287" y="644" width="225" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805113830_287945_93258" xmi:uuid="db855250-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805115332_664442_93259"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_236086_372647"/>
      <target xmi:idref="_18_4_1_65b021e_1692804781827_331586_91947"/>
      <waypoint x="900" y="609"/>
      <waypoint x="900" y="277"/>
      <waypoint x="690" y="277"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_88507_91940" xmi:uuid="db85f890-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
      <ownedElement xmi:id="db4a6400-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="db4a65a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>languageIndication:Language_indication</text>
      </ownedElement>
      <ownedElement xmi:id="db586b60-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="db586cb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_672189_30425"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="db598400-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="db598550-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="db5a9d20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="db5aa1f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_331586_91947" xmi:uuid="db8451e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
          <ownedElement xmi:id="db7529a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="db752ad0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>considered_instance:string_select</text>
          </ownedElement>
          <ownedElement xmi:id="db837710-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="db837850-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Language_indication-considered_instance"/>
            <text>[1]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="266" width="228" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="448" y="238" width="272" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805118365_701304_93277" xmi:uuid="dbda26f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805120935_631238_93278"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_236086_372647"/>
      <target xmi:idref="_18_4_1_65b021e_1692804781827_176922_91948"/>
      <waypoint x="900" y="609"/>
      <waypoint x="900" y="200"/>
      <waypoint x="637" y="200"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_895780_91941" xmi:uuid="dbdb0440-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
      <ownedElement xmi:id="db9ff0a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="db9ff2f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>descriptionAsgn:Description_text_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="dbada2b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dbada400-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725212907_373659_30426"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="dbaea070-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dbaea190-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dbaf6ab0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dbaf6bf0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_176922_91948" xmi:uuid="dbd92810-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
          <ownedElement xmi:id="dbca1b70-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dbca1cb0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>items:description_item</text>
          </ownedElement>
          <ownedElement xmi:id="dbd84300-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dbd845e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Description_text_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="189" width="175" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="448" y="161" width="299" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_6480_91942" xmi:uuid="dc13b6a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
      <ownedElement xmi:id="dbf6a5e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dbf6a730-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376720_531237_31516"/>
        <text>selectId:IdSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_267714_91949" xmi:uuid="dc13a740-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
        <ownedElement xmi:id="dc1223f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dc122520-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501253300424_174256_22867"/>
          <bounds x="379" y="424" width="59" height="13"/>
          <text>simple [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="361" y="433" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="238" y="420" width="138" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805108728_586160_93239" xmi:uuid="dc6cb830-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805110895_703040_93240"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_236086_372647"/>
      <target xmi:idref="_18_4_1_65b021e_1692804781827_743478_91951"/>
      <waypoint x="900" y="609"/>
      <waypoint x="900" y="354"/>
      <waypoint x="645" y="354"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_477902_91943" xmi:uuid="dc6dd410-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
      <ownedElement xmi:id="dc310f10-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dc311040-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>idAsgn:Identification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="dc3e6780-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dc3e68a0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509725376736_404843_31518"/>
        <text>[0..*]</text>
      </ownedElement>
      <ownedElement xmi:id="dc3f64b0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dc3f6650-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dc404460-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dc4048e0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692804781827_743478_91951" xmi:uuid="dc6bb040-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
          <ownedElement xmi:id="dc5b3ae0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dc5b3e50-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>items:identification_item</text>
          </ownedElement>
          <ownedElement xmi:id="dc6a9530-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dc6a9660-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Identification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="343" width="183" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="448" y="315" width="232" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692804960758_422305_92359" xmi:uuid="dc6df660-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692804961991_203824_92360"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_976987_372695"/>
      <target xmi:idref="_18_4_1_65b021e_1692804781827_267714_91949"/>
      <waypoint x="462" y="438"/>
      <waypoint x="376" y="438"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692804992059_808775_92389" xmi:uuid="dc6e0bc0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692804993359_857258_92390"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_905538_372711"/>
      <target xmi:idref="_18_4_1_65b021e_1692804781827_459389_91945"/>
      <waypoint x="616" y="665"/>
      <waypoint x="512" y="665"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805098354_635423_93214" xmi:uuid="dcce5f30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805099854_649090_93215"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025968_236086_372647"/>
      <target xmi:idref="_18_4_1_65b021e_1692805054172_523783_93061"/>
      <waypoint x="900" y="609"/>
      <waypoint x="900" y="571"/>
      <waypoint x="646" y="571"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805054172_65583_93059" xmi:uuid="dccf0e00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
      <ownedElement xmi:id="dc8ce780-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dc8cea00-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>typeAsgn:Classification_assignment</text>
      </ownedElement>
      <ownedElement xmi:id="dc9e8df0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dc9e8f30-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_200428_29597"/>
        <text>[0..1]</text>
      </ownedElement>
      <ownedElement xmi:id="dc9faa20-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dc9fac40-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartment">
        <ownedElement xmi:id="dca08470-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dca085c0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <text>structure</text>
        </ownedElement>
        <ownedElement xmi:id="_18_4_1_65b021e_1692805054172_523783_93061" xmi:uuid="dccd68f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
          <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
          <ownedElement xmi:id="dcbda790-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dcbdaa60-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>items:classification_item</text>
          </ownedElement>
          <ownedElement xmi:id="dccc72f0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dccc7430-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLMultiplicityLabel">
            <modelElement href="../../SysML_ARM/SysML_ARM.xmi#_2_attr_SYSML_ARM-Classification_assignment-items"/>
            <text>[1..*]</text>
          </ownedElement>
          <localStyle>
            <fillColor red="255" green="255" blue="204"/>
          </localStyle>
          <bounds x="462" y="560" width="184" height="25"/>
        </ownedElement>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="448" y="532" width="249" height="63"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805054172_599319_93060" xmi:uuid="dd0720f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
      <ownedElement xmi:id="dce9b2a0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dce9b3f0-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1509724799679_392418_29598"/>
        <text>typeSelect:ClassSelector</text>
      </ownedElement>
      <ownedElement xmi:id="_18_4_1_65b021e_1692805054172_549086_93062" xmi:uuid="dd070a20-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLShape">
        <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
        <ownedElement xmi:id="dd05c4e0-24a2-013c-5c01-2bb9f4d923a9" xmi:uuid="dd05c620-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLLabel">
          <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1501080985327_193333_23708"/>
          <bounds x="510" y="694" width="41" height="13"/>
          <text>str [0..1]</text>
        </ownedElement>
        <localStyle>
          <fillColor red="255" green="255" blue="255"/>
        </localStyle>
        <bounds x="492" y="703" width="15" height="15"/>
      </ownedElement>
      <localStyle>
        <fillColor red="204" green="204" blue="255"/>
      </localStyle>
      <bounds x="336" y="693" width="171" height="41"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1692805068005_526009_93164" xmi:uuid="dd072a70-24a2-013c-5c01-2bb9f4d923a9" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1692805069319_680762_93165"/>
      <source xmi:idref="_18_4_1_65b021e_1688566025969_392999_372706"/>
      <target xmi:idref="_18_4_1_65b021e_1692805054172_549086_93062"/>
      <waypoint x="616" y="711"/>
      <waypoint x="507" y="711"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="1366" height="848"/>
    <name>ProcessOperationDefinitionRelationship</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
  <umldi:UMLCompositeStructureDiagram xmi:id="_18_4_1_65b021e_1727446315427_529160_294089" xmi:uuid="fd6216b0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompositeStructureDiagram">
    <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688563977054_525558_164279"/>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315456_750087_294121" xmi:uuid="fe3bb910-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLCompartmentableShape">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038583_515305_181057"/>
      <ownedElement xmi:id="fe0fca90-6c44-013d-d608-0800270c66d6" xmi:uuid="fe0fcba0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLTypedElementLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038583_515305_181057"/>
        <text>same_time_machining_relationship:Same_time_machining_relationship</text>
      </ownedElement>
      <ownedElement xmi:id="fe27ca60-6c44-013d-d608-0800270c66d6" xmi:uuid="fe27cb90-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLMultiplicityLabel">
        <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1688564038583_515305_181057"/>
        <text>[1]</text>
      </ownedElement>
      <localStyle fontName="Arial" fontSize="">
        <fillColor red="255" green="255" blue="204"/>
      </localStyle>
      <bounds x="45" y="55" width="417" height="370"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315472_946576_294155" xmi:uuid="fe3cb550-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Activity/Activity.xmi#_18_4_1_2b2015d_1517599542122_900438_41176"/>
      <bounds x="832" y="55" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315488_670711_294170" xmi:uuid="fe4ceed0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1543576579967_376677_35155"/>
      <bounds x="832" y="75" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315502_383308_294185" xmi:uuid="fe4dda80-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1502304781281_738451_23898"/>
      <bounds x="832" y="95" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315513_553886_294200" xmi:uuid="fe629e20-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041364_520679_181996"/>
      <bounds x="832" y="115" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315581_387731_294216" xmi:uuid="fe762080-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DeltaChange/DeltaChange.xmi#_18_4_1_65b021e_1688564041515_814862_182062"/>
      <bounds x="832" y="135" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315595_103061_294231" xmi:uuid="fe911f00-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../DocumentManagement/DocumentManagement.xmi#_18_4_1_2b2015d_1525881237893_791767_43752"/>
      <bounds x="832" y="155" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315613_829275_294246" xmi:uuid="fe920de0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1513248210619_309868_41629"/>
      <bounds x="832" y="175" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315630_612585_294261" xmi:uuid="fea3e400-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604576568207_562870_63073"/>
      <bounds x="832" y="195" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315644_291495_294276" xmi:uuid="fea4d610-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_29c0149_1544535327361_189951_94691"/>
      <bounds x="832" y="215" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315660_34123_294291" xmi:uuid="feb38c90-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Message/Message.xmi#_18_4_1_2b2015d_1539780615379_38186_37469"/>
      <bounds x="832" y="235" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315677_322903_294306" xmi:uuid="fecbeeb0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625126958602_216701_72042"/>
      <bounds x="832" y="255" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315689_866218_294321" xmi:uuid="fedc9630-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625127504503_51252_72420"/>
      <bounds x="832" y="275" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315703_700813_294336" xmi:uuid="fedd8730-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../Observation/Observation.xmi#_18_4_1_8be0287_1625068381768_623976_73954"/>
      <bounds x="832" y="295" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315721_778733_294351" xmi:uuid="fede6d90-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../ManagementResources/ManagementResources.xmi#_18_4_1_2b2015d_1502449310299_727452_27972"/>
      <bounds x="832" y="315" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315739_506599_294366" xmi:uuid="ff02ba00-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_75301ad_1536231157129_972278_34109"/>
      <bounds x="832" y="335" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446315821_50674_294382" xmi:uuid="ff114740-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLShape">
      <modelElement href="../CommonResources/CommonResources.xmi#_18_4_1_2b2015d_1604585041258_339712_63540"/>
      <bounds x="832" y="355" width="15" height="15"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_481115_403832" xmi:uuid="ff115a40-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434537_735805_267904"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315472_946576_294155"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="62"/>
      <waypoint x="462" y="62"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_411483_403835" xmi:uuid="ff116180-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434621_199033_267920"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315488_670711_294170"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="82"/>
      <waypoint x="462" y="82"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_44679_403838" xmi:uuid="ff1168d0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434706_361970_267936"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315502_383308_294185"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="102"/>
      <waypoint x="462" y="102"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_354823_403841" xmi:uuid="ff117070-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434791_856440_267952"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315513_553886_294200"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="122"/>
      <waypoint x="462" y="122"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_905266_403844" xmi:uuid="ff117850-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1727446315514_401301_294212"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315581_387731_294216"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="142"/>
      <waypoint x="462" y="142"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_129049_403847" xmi:uuid="ff117f70-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434869_806632_267968"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315595_103061_294231"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="162"/>
      <waypoint x="462" y="162"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_586571_403850" xmi:uuid="ff118720-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601434953_954373_267984"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315613_829275_294246"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="182"/>
      <waypoint x="462" y="182"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_494163_403853" xmi:uuid="ff118e80-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435035_225808_268000"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315630_612585_294261"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="202"/>
      <waypoint x="462" y="202"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_299964_403856" xmi:uuid="ff119630-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435116_239489_268016"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315644_291495_294276"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="222"/>
      <waypoint x="462" y="222"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_258423_403859" xmi:uuid="ff119e30-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435198_255865_268032"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315660_34123_294291"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="242"/>
      <waypoint x="462" y="242"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_163545_403862" xmi:uuid="ff11a5e0-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435285_68187_268048"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315677_322903_294306"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="262"/>
      <waypoint x="462" y="262"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_721433_403865" xmi:uuid="ff11ad00-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435368_334809_268064"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315689_866218_294321"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="282"/>
      <waypoint x="462" y="282"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_636462_403868" xmi:uuid="ff11b390-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435447_852902_268080"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315703_700813_294336"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="302"/>
      <waypoint x="462" y="302"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_284464_403871" xmi:uuid="ff11ba30-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435531_273574_268096"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315721_778733_294351"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="322"/>
      <waypoint x="462" y="322"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_876435_403874" xmi:uuid="ff11c110-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1696601435614_758392_268112"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315739_506599_294366"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="342"/>
      <waypoint x="462" y="342"/>
    </ownedElement>
    <ownedElement xmi:id="_18_4_1_65b021e_1727446499702_254387_403877" xmi:uuid="ff11c860-6c44-013d-d608-0800270c66d6" xmi:type="umldi:UMLEdge">
      <modelElement href="ProcessPlan.xmi#_18_4_1_65b021e_1727446315740_298072_294378"/>
      <source xmi:idref="_18_4_1_65b021e_1727446315821_50674_294382"/>
      <target xmi:idref="_18_4_1_65b021e_1727446315456_750087_294121"/>
      <waypoint x="832" y="362"/>
      <waypoint x="462" y="362"/>
    </ownedElement>
    <localStyle fontSize="11"/>
    <bounds x="5" y="5" width="835" height="440"/>
    <name>SelectMapping</name>
    <resolution>60</resolution>
  </umldi:UMLCompositeStructureDiagram>
</xmi:XMI>
