import fs from 'node:fs/promises';
import path from 'node:path';
import PptxGenJS from 'pptxgenjs';
import { instance } from '@viz-js/viz';
import sharp from 'sharp';
import JSZip from 'jszip';

const ROOT = process.env.DEPO_REPO || 'D:/paritosh/PMem-codex-apach_agent';
const WORK = path.join(ROOT,'.release-test-tmp/pptx-review/enterprise');
const OUT = path.join(ROOT,'deliverables/DEPO_Enterprise_Architecture_2026-10-16');
const SOURCES = path.join(WORK,'diagram_sources');
await fs.mkdir(SOURCES,{recursive:true}); await fs.mkdir(OUT,{recursive:true});
const C={navy:'10253F',blue:'245EDB',teal:'007F78',ink:'172B42',muted:'53687C',line:'D6E0E9',paper:'F7F9FC',white:'FFFFFF',amber:'9B6410'};
const pptx = new PptxGenJS(); pptx.layout='LAYOUT_WIDE';
pptx.author='DEPO Architecture'; pptx.subject='Industrial ontology, agent orchestration, data products and customer deployment';
pptx.title='DEPO Industrial Data Platform — Enterprise Architecture'; pptx.company='DEPO';
pptx.lang='en-GB'; pptx.theme={headFontFace:'Arial',bodyFontFace:'Arial',lang:'en-GB'};
const viz=await instance();
const diagrams={}; const manifest=[];
const q=s=>JSON.stringify(s);
const wrapLines=(text,max=29)=>text.split('\n').map(line=>{const out=[];let row='';for(const word of line.split(' ')){if(row && row.length+word.length+1>max){out.push(row);row=word;}else row+=(row?' ':'')+word;}out.push(row);return out.join('\n');}).join('\n');
const node=(id,text,extra='')=>`${q(id)} [label=${q(wrapLines(text))} ${extra}];`;
const edge=(a,b,label='',extra='')=>`${q(a)} -> ${q(b)} [${label?`label=${q(wrapLines(label,22))}`:''} ${extra}];`;
const dot=(body,dir='LR')=>`digraph DEPO {
 graph [rankdir=${dir}, splines=ortho, bgcolor="transparent", pad="0.25", nodesep="0.40", ranksep="0.65", fontname="Arial", fontsize=18, compound=true];
 node [shape=box, style="rounded,filled", fillcolor="#F0F5FA", color="#91A6BC", fontcolor="#172B42", fontname="Arial", fontsize=19, margin="0.20,0.13", penwidth=1.2];
 edge [color="#466D94", arrowsize=0.8, penwidth=1.5, fontname="Arial", fontsize=14, fontcolor="#355472"];
 ${body}
}`;
async function graph(id,body,dir='LR',engine='dot'){
 const source=dot(body,dir); const svg=viz.renderString(source,{format:'svg',engine});
 await fs.writeFile(path.join(SOURCES,id+'.dot'),source);
 await fs.writeFile(path.join(SOURCES,id+'.svg'),svg);
 const png=await sharp(Buffer.from(svg)).resize({width:2400}).png().toBuffer();
 await fs.writeFile(path.join(SOURCES,id+'.png'),png);
 const vb=svg.match(/viewBox="([^"]+)"/)[1].split(/\s+/).map(Number);
 diagrams[id]={svg,png,ratio:vb[2]/vb[3]};
}

await graph('01-c4-context',`
 ${node('engineer','«person»\nEngineer / data steward')}
 ${node('consumer','«person»\nAnalyst / operator')}
 ${node('platform','«software system»\nDEPO industrial data platform\nOntology alignment and governed reuse','fillcolor="#E7F4F2" color="#007F78" penwidth=2')}
 ${node('sources','«external systems»\nPLM / CAD / QMS / documents\nSupported files and OSLC resources')}
 ${node('model','«external model endpoint»\nOllama REST / optional APIM\nConfigured inference operations')}
 ${node('consumerapp','«external consumers»\nEngineering applications / analysts\nVersioned product packages')}
 {rank=same; engineer;consumer;} {rank=same; sources;model;consumerapp;}
 ${edge('engineer','platform','HTTPS · scoped tasks')}
 ${edge('consumer','platform','HTTPS · evidence queries')}
 ${edge('sources','platform','Files / REST / OSLC')}
 ${edge('platform','model','HTTP(S) · model requests')}
 ${edge('platform','consumerapp','REST / manifests / downloads')}
`);
await graph('02-c4-containers',`
 ${node('ui','«container» Browser SPA\nReact / Siemens IX')}
 ${node('route','Optional ingress / API gateway\nPublic API routes')}
 subgraph cluster_apis {label="DEPO boundary · ten FastAPI containers · /api/v1";color="#CAD8E5";style=rounded;
  ${node('qif','Schema sets\n:8010')} ${node('onto','Ontology\n:8011')} ${node('agent','Agentic\n:8012')} ${node('g','Graph\n:8013')} ${node('ing','Ingestion\n:8014')}
  ${node('oslc','OSLC\n:8015')} ${node('cat','Catalog\n:8016')} ${node('prod','Products\n:8017')} ${node('ceim','CEIM\n:8018')} ${node('pipe','Pipeline\n:8019')}
  {rank=same;qif;onto;agent;g;ing;} {rank=same;oslc;cat;prod;ceim;pipe;}
  qif->oslc [style=invis];onto->cat [style=invis];agent->prod [style=invis];g->ceim [style=invis];ing->pipe [style=invis];
 }
 ${node('workers','«worker processes»\nPipeline · agentic workflow\nProduct catalog outbox','fillcolor="#E7F4F2"')}
 ${node('pg','«database» PostgreSQL\nControl state + XML ODS','shape=cylinder')}
 ${node('neo','«database» Neo4j\nSemantic projections + receipts','shape=cylinder')}
 ${node('art','«storage» Durable artifacts\nSources, RDF, reports, packages','shape=folder')}
 {rank=same;pg;neo;art;}
 ${edge('ui','route','HTTPS / REST')}${edge('route','qif')}${edge('route','onto')}${edge('route','agent')}${edge('route','g')}${edge('route','ing')}
 ${edge('pipe','workers','Persisted jobs')}${edge('prod','workers','Outbox')}${edge('agent','workers','Approved workflow')}
 ${edge('workers','pg','SQL / leases')}${edge('g','neo','Bolt · Cypher')}${edge('ing','art','Artifact API')}${edge('workers','art','Retained outputs')}
`,'TB');
await graph('03-c4-agent-components',`
 subgraph cluster_agent {label="Agentic Control Plane :8012";style=rounded;color="#91A6BC";
 ${node('router','«component» REST router\nArguments and operation scopes')}
 ${node('catalog','«component» Catalog\nAgents · tools · workflows')}
 ${node('prompt','«component» Prompt policy\nBounds and evidence context')}
 ${node('queue','«component» Durable workflow\nPlan, grant and run identity')}
 ${node('worker','«component» Workflow worker\nLease, checkpoint and recovery')}
 ${node('tools','«component» Tool transport\nAllowlist and service credentials')}
 }
 ${node('ui','SPA / caller')}${node('pg','PostgreSQL\nRuns, grants and telemetry','shape=cylinder')}
 ${node('domain','Domain APIs\nOntology · ingestion · graph')}${node('llm','Configured Ollama REST\nOptional recommendation / synthesis')}
 ${edge('ui','router','REST /api/v1')}${edge('router','catalog','Validated discovery')}${edge('router','queue','Authorized plan')}
 ${edge('queue','pg','SQL')}${edge('pg','worker','Leased work')}${edge('worker','tools','Permitted step')}
 ${edge('tools','domain','HTTP(S) / REST')}${edge('router','prompt','Bounded input')}${edge('prompt','llm','Configured operation')}
`);
await graph('04-uml-publication-components',`
 ${node('ceim','«component» CEIM\nAccepted semantic batch')}
 ${node('onto','«component» Ontology\nRetained RDF release')}
 ${node('bridge','«component» Agentic / Bridge\nSaved mapping preview')}
 ${node('auth','«interface» Publication contracts\nCredential + authenticated actor\nSource identity + policy evidence','fillcolor="#E7F4F2"')}
 ${node('graph','«component» Graph Service\nBatch writes and durable receipts')}
 ${node('neo','«database» Neo4j\nPublished resources and links','shape=cylinder')}
 ${node('state','«database» PostgreSQL\nJobs, approval and reconciliation','shape=cylinder')}
 {rank=same;ceim;onto;bridge;}
 ${edge('ceim','auth','Approved batch')}${edge('onto','auth','Ontology projection')}${edge('bridge','auth','Selected / policy-eligible mappings')}
 ${edge('auth','graph','REST publication APIs')}${edge('graph','neo','Bolt / bounded batches')}${edge('graph','state','Job / receipt references')}
`);
await graph('05-uml-deployment',`
 ${node('browser','«device» User workstation\nBrowser · public configuration')}
 ${node('ingress','«execution environment»\nCustomer web server / optional APIM\nFrontend dist + API routing')}
 subgraph cluster_app {label="«node» Application VM · Windows";style=rounded;color="#91A6BC";
 ${node('apis','«process group»\n10 FastAPI services · :8010–8019')}
 ${node('workers','«process group»\nPipeline · workflow · outbox workers')}
 ${node('spark','«optional execution environment»\nSpark / JVM\nApproved compute jobs')}
 }
 subgraph cluster_data {label="«node» Private data services";style=rounded;color="#91A6BC";
 ${node('pg','PostgreSQL\nApplication + analytics schemas','shape=cylinder')}
 ${node('neo','Neo4j\nNamed ontology database','shape=cylinder')}
 ${node('disk','Durable artifact directory\nAPIs and workers share access','shape=folder')}
 }
 ${node('ollama','«optional model service»\nOllama / internal REST gateway')}
 ${edge('browser','ingress','HTTPS')}${edge('ingress','apis','HTTP(S) / private REST')}${edge('apis','workers','PostgreSQL queue')}
 ${edge('workers','spark','PySpark / local runtime')}${edge('apis','pg','PostgreSQL / TLS policy')}${edge('apis','neo','Bolt / TLS policy')}
 ${edge('workers','disk','Filesystem / artifacts')}${edge('apis','disk')}${edge('apis','ollama','HTTP(S) REST')}
`);

// Graphviz implements UML sequence lifelines and labelled horizontal messages.
async function sequence(id,actors,messages){
 let b='graph [splines=line overlap=true];'; const rows=messages.length,H=rows*.9+1.2;
 const x=new Map(actors.map(([key],col)=>[key,col*3.8]));
 const wrap=(text,max)=>{const out=[];let line='';for(const word of text.split(' ')){if(line.length+word.length+1>max){out.push(line);line=word;}else line+=(line?' ':'')+word;}out.push(line);return out.join('\n');};
 actors.forEach(([key,label])=>{
   b+=node(`${key}_header`,label,`pos="${x.get(key)},${H}!" pin=true fillcolor="#E7F4F2" fontsize=19`);
   b+=node(`${key}_end`,'',`pos="${x.get(key)},0!" pin=true shape=point width=0.01 height=0.01 style=invis`);
   b+=edge(`${key}_header`,`${key}_end`,'','style=dashed arrowhead=none color="#B4C2D0"');
 });
 messages.forEach(([from,to,label,reply],idx)=>{
   const y=H-.85-idx*.9;
   b+=node(`a${idx}`,'',`pos="${x.get(from)},${y}!" pin=true shape=point width=.01 height=.01 style=invis`);
   b+=node(`b${idx}`,'',`pos="${x.get(to)},${y}!" pin=true shape=point width=.01 height=.01 style=invis`);
   b+=edge(`a${idx}`,`b${idx}`,'',reply?'style=dashed':'');
   const distance=Math.abs(x.get(from)-x.get(to));
   b+=node(`label${idx}`,wrap(`${idx+1}. ${label}`,Math.max(25,Math.floor(distance*6.5))),`pos="${(x.get(from)+x.get(to))/2},${y+.28}!" pin=true shape=plaintext style=filled fillcolor=white fontsize=18 margin=".05,.02"`);
 });
 await graph(id,b,'TB','neato');
}
await sequence('06-uml-session-sequence',[
 ['u','User / SPA'],['o','Ontology API'],['p','Credential store\nPostgreSQL'],['s','Other DEPO APIs']
],[['u','o','POST /auth/browser-session'],['o','p','Validate admin key and scopes'],['o','u','Delegated token + expiry',true],['u','s','Bearer session on scoped operations'],['s','p','Validate delegation and current credentials'],['u','o','POST /auth/browser-session/renew'],['o','u','Renew within absolute expiry',true]]);
await sequence('07-uml-ontology-sequence',[
 ['u','SPA / runner'],['i','Ingestion API'],['o','Ontology API'],['a','Artifacts / state'],['g','Graph API / Neo4j']
],[['u','i','Submit XSD schema set'],['i','a','Retain sources and conversion outputs'],['i','o','Register retained ontology'],['o','u','Ontology identity / registration result',true],['u','o','Request governed RDF publication'],['o','g','Bounded projection publication'],['g','o','Receipt or reconciliation state',true]]);
await graph('08-uml-bridge-activity',`
 ${node('start','', 'shape=circle width=.2 height=.2 fillcolor="#007F78"')}
 ${node('select','Select task\nInstance linking or ontology union')}
 ${node('scope','Resolve exact source / target identities\nRetain artifacts and snapshot')}
 ${node('preview','Governor creates preview\nSteward evaluates evidence')}
 ${node('policy','Policy satisfied?','shape=diamond fillcolor="#FFF2DD"')}
 ${node('hold','Hold ambiguous or conflicting candidates\nExpose reasons and evidence')}
 ${node('apply','Execute authorized selection\nEligible policy route or reviewed selection')}
 ${node('receipt','Retain draft / mapping result\nReconcile uncertain publication')}
 ${edge('start','select')}${edge('select','scope')}${edge('scope','preview')}${edge('preview','policy')}
 ${edge('policy','hold','No')}${edge('policy','apply','Yes')}${edge('apply','receipt')}
`);
await sequence('09-uml-merge-sequence',[
 ['u','User / SPA'],['a','Agentic API'],['w','Workflow worker'],['o','Ontology tools'],['p','PostgreSQL / artifacts']
],[['u','a','Submit ontology-union-automation'],['a','p','Persist approved plan + grant'],['w','p','Claim run / checkpoint step'],['w','o','Governor: merge.preview'],['w','o','Steward: merge.evaluate'],['w','o','Governor: merge.apply_automatic'],['o','p','Retain eligible union draft + evidence'],['a','u','Run status / changed and held items',true]]);
const cls=(id,name,fields)=>`${q(id)} [shape=plain label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="9" COLOR="#91A6BC"><TR><TD BGCOLOR="#E7F4F2"><B>${name}</B></TD></TR><TR><TD ALIGN="LEFT">${fields.join('<BR ALIGN="LEFT"/>')}<BR ALIGN="LEFT"/></TD></TR></TABLE>>];`;
await graph('10-uml-domain-classes',`
 graph [nodesep="1.2" ranksep=".85"];
 ${cls('ont','OntologyRecord',['ontology_id : string','prefix : string','lifecycle : enum','artifact_refs : list'])}
 ${cls('run','WorkflowRun',['run_id : string','status : enum','actor : string','deadline_at : timestamp'])}
 ${cls('preview','MappingPreview',['preview_id : string','source_id : string','target_id : string','snapshot_digest : string'])}
 ${cls('receipt','PublicationReceipt',['publication_id : string','digest : string','status : enum'])}
 ${cls('artifact','ArtifactRef',['artifact_id : string','sha256 : string','media_type : string'])}
 ${cls('product','DataProductVersion',['product_id : string','version : semver','manifest : object'])}
 {rank=same;run;preview;product;} {rank=same;ont;receipt;artifact;}
 ${edge('preview','ont','2')}${edge('run','preview','0..*')}${edge('run','receipt','0..*')}
 ${edge('ont','artifact','1..*')}${edge('product','artifact','1..*')}${edge('receipt','ont','1')}
`,'TB');
await graph('11-xml-ods-activity',`
 ${node('in','Retained XML + XSD closure\nExplicit target analytics profile')}
 ${node('valid','Validate supported XSD projection\nResolve fields and source identity')}
 ${node('load','Bounded relational batch load\nEntity / link rows and source document')}
 ${node('commit','PostgreSQL commit\nLoad identity and ODS outcome','fillcolor="#E7F4F2"')}
 ${node('evidence','Evidence complete?','shape=diamond fillcolor="#FFF2DD"')}
 ${node('pending','Committed / evidence pending\nReconcile analytics artifacts\nPreserve existing ODS rows')}
 ${node('views','Explicit fact / dimension views\nBusiness grain, keys and measures')}
 ${edge('in','valid')}${edge('valid','load')}${edge('load','commit')}${edge('commit','evidence')}
 ${edge('evidence','pending','No')}${edge('evidence','views','Yes')}
`);
await sequence('12-product-sequence',[
 ['u','Data Products UI'],['p','Product API'],['a','Artifacts / PostgreSQL'],['w','Outbox worker'],['c','Catalog API']
],[['u','p','Preview retained product evidence'],['p','a','Validate artifacts and semantic references'],['u','p','Publish version with authorized identity'],['p','a','Retain package, manifest and outbox'],['w','a','Claim pending registration'],['w','c','Register governed product version'],['c','u','Discover product / delivery status',true]]);
await graph('13-graph-retrieval',`
 ${node('query','Question + ontology / import scope')}
 ${node('scope','Validate read access\nResolve exact identities')}
 ${node('retrieve','Graph Service\nBounded search and traversal')}
 ${node('evidence','Retained resource references\nLabels, relationships and provenance')}
 ${node('model','Optional model synthesis\nConfigured REST contract')}
 ${node('answer','Response with evidence\nOr insufficient-evidence result')}
 ${edge('query','scope')}${edge('scope','retrieve','REST')}${edge('retrieve','evidence')}
 ${edge('evidence','model','Bounded prompt')}${edge('model','answer')}${edge('evidence','answer','Direct evidence')}
`);
await graph('14-failure-lifecycle',`
 ${node('submit','Authorized request\nStable input + operation identity')}
 ${node('execute','Worker / domain service\nBounded step and retained state')}
 ${node('result','Response received?','shape=diamond fillcolor="#FFF2DD"')}
 ${node('success','Inspect confirmed outcome\nGraph / ODS / package / catalog')}
 ${node('unknown','Outcome uncertain\nKeep run ID and original input')}
 ${node('check','Read retained state / receipt\nReconcile committed side effects')}
 ${node('retry','Retry only the permitted operation\nReuse identity where supported')}
 ${edge('submit','execute')}${edge('execute','result')}${edge('result','success','Yes')}${edge('result','unknown','No')}
 ${edge('unknown','check')}${edge('check','retry','Safe retry / recovery')}
`);
await graph('15-upgrade-activity',`
 ${node('release','Complete matching release\nPreserve .env.local and durable data')}
 ${node('pre','Configuration + runtime prerequisites\nValidate timeout budgets')}
 ${node('stop','Stop application processes\nExternal databases remain running')}
 ${node('deps','Install dependencies when requested\nBuild frontend once')}
 ${node('db','Apply pending PostgreSQL migrations\nHistory / checksum / ownership checks')}
 ${node('graph','Provision and verify Neo4j schema\nReconcile incompatible definitions')}
 ${node('start','Start APIs + workers\nReadiness and credential verification')}
 ${node('accept','Serve frontend\nCustomer acceptance and recovery checks','fillcolor="#E7F4F2"')}
 ${edge('release','pre')}${edge('pre','stop','Checks pass')}${edge('stop','deps')}${edge('deps','db')}
 ${edge('db','graph')}${edge('graph','start')}${edge('start','accept')}
`);

// Fixed orthogonal layouts keep long operational flows readable on 16:9 slides.
async function fixed(id,nodes,edges){
 let b='graph [splines=ortho overlap=true];';
 for(const [key,label,x,y,shape='box'] of nodes)b+=node(key,label,`pos="${x*1.4},${y}!" pin=true shape=${shape} width=2.75 height=.8 fontsize=18`);
 for(const [a,c,label] of edges)b+=edge(a,c,label||'');
 await graph(id,b,'LR','neato');
}
await fixed('08-uml-bridge-activity',[
 ['start','Task entry',0,3],['select','Select instance linking\nor ontology union',3.5,3],['scope','Resolve source / target\nRetain exact snapshot',7,3],['preview','Governor preview\nSteward evaluation',10.5,3],
 ['policy','Policy\nsatisfied?',10.5,0,'diamond'],['apply','Apply authorized selection\nEligible automatic policy',7,0],['receipt','Retain result and receipt\nReconcile uncertain writes',3.5,0],['hold','Hold conflicting candidates\nShow reasons and evidence',14,0]
],[['start','select'],['select','scope'],['scope','preview'],['preview','policy'],['policy','apply','Yes'],['policy','hold','No'],['apply','receipt']]);
await fixed('11-xml-ods-activity',[
 ['in','Retained XML + XSD\nExplicit analytics profile',0,3],['valid','Validate supported XSD\nResolve source and fields',3.5,3],['load','Bounded batch load\nEntity and link rows',7,3],['commit','Commit PostgreSQL ODS\nRetain load identity',10.5,3],
 ['evidence','Evidence\ncomplete?',10.5,0,'diamond'],['pending','Committed / evidence pending\nReconcile; preserve ODS rows',14,0],['views','Fact / dimension views\nExplicit grain and keys',7,0]
],[['in','valid'],['valid','load'],['load','commit'],['commit','evidence'],['evidence','pending','No'],['evidence','views','Yes']]);
await fixed('13-graph-retrieval',[
 ['query','Question + ontology scope',0,3],['scope','Read access and identity\nSelected import / ontology',3.5,3],['retrieve','Graph API search\nBounded traversal',7,3],['evidence','Resources and provenance\nRetained evidence references',7,0],['model','Optional model summary\nConfigured REST operation',3.5,0],['answer','Evidence-based response\nOr insufficient evidence',0,0]
],[['query','scope'],['scope','retrieve'],['retrieve','evidence'],['evidence','model'],['model','answer']]);
await fixed('14-failure-lifecycle',[
 ['submit','Authorized request\nStable operation identity',0,3],['execute','Worker / domain service\nBounded step and run state',3.5,3],['result','Response\nreceived?',7,3,'diamond'],['success','Inspect confirmed outcome\nGraph / ODS / product / catalog',10.5,3],['unknown','Uncertain outcome\nKeep run ID and input',7,0],['check','Read state / receipt\nReconcile completed writes',3.5,0],['retry','Permitted recovery only\nReuse stable identity',0,0]
],[['submit','execute'],['execute','result'],['result','success','Yes'],['result','unknown','No'],['unknown','check'],['check','retry']]);
await fixed('15-upgrade-activity',[
 ['release','1  Matching release\nPreserve env and durable data',0,3],['pre','2  Configuration and runtimes\nValidate timeout budgets',3.5,3],['stop','3  Stop application processes\nKeep external databases',7,3],['deps','4  Dependencies as requested\nBuild frontend once',10.5,3],
 ['db','5  Pending PG migrations\nHistory, checksums, ownership',10.5,0],['graph','6  Verify Neo4j schema\nReconcile incompatible objects',7,0],['start','7  APIs and three workers\nReadiness and credentials',3.5,0],['accept','8  Serve frontend\nCustomer acceptance checks',0,0]
],[['release','pre'],['pre','stop'],['stop','deps'],['deps','db'],['db','graph'],['graph','start'],['start','accept']]);
{
 let b='graph [splines=ortho overlap=true];';
 b+=node('browser','«container» Browser SPA\nReact / Siemens IX', 'pos="-3,2.4!" pin=true width=2.3');
 b+=node('gateway','Optional customer ingress\nDirect or gateway API routing', 'pos="-3,0!" pin=true width=2.3');
 b+='subgraph cluster_api {label="Ten independent FastAPI containers";style=rounded;color="#91A6BC";';
 b+=node('api','REST /api/v1 · scoped service contracts', 'pos="5.2,4.5!" pin=true width=7.8 height=.5 fillcolor="#E7F4F2"');
 const services=[['Schema sets',8010],['Ontology',8011],['Agentic',8012],['Graph',8013],['Ingestion',8014],['OSLC',8015],['Catalog',8016],['Products',8017],['CEIM',8018],['Pipeline',8019]];
 services.forEach(([name,port],i)=>{b+=node('svc'+i,`${name}\n:${port}`,`pos="${(i%5)*2.6},${i<5?2.6:.5}!" pin=true width=2.0 height=.65 fontsize=18`);});b+='}';
 b+=node('worker','«workers»\nPipeline · workflow · outbox','pos="14,3.7!" pin=true width=2.6');
 b+=node('pg','PostgreSQL\nSQL / TLS policy\nState and XML ODS','pos="14,1.3!" pin=true shape=cylinder width=2.6');
 b+=node('neo','Neo4j\nBolt / TLS policy\nGraph and receipts','pos="14,-1.1!" pin=true shape=cylinder width=2.6');
 b+=node('art','Durable artifacts\nFilesystem / artifact API','pos="7,-1.9!" pin=true shape=folder width=3.0');
 b+=edge('browser','gateway','HTTPS');b+=edge('gateway','api');b+=edge('api','worker');b+=edge('api','pg');b+=edge('api','neo');b+=edge('api','art');b+=edge('worker','pg');b+=edge('worker','art');
 await graph('02-c4-containers',b,'LR','neato');
}

const sources={
 context:['docs/DATA_PRODUCT_INGESTION.md','infra/deployment/services.json'],
 containers:['infra/deployment/services.json','frontend/src/config.js','infra/windows/runtime-config.ps1'],
 agent:['backend/agentic_service/catalog.json','backend/agentic_service/durable_workflows.py','backend/agentic_service/worker.py','backend/agentic_service/transport_auth.py'],
 graph:['backend/ontology_service/publication_jobs.py','backend/agentic_service/bridge_jobs.py','backend/graph_service/router.py'],
 session:['frontend/src/services/serviceAuth.js','backend/depo_platform/browser_credentials.py','frontend/src/app/RunRecoveryNotice.js'],
 data:['docs/DATA_PRODUCT_INGESTION.md','backend/data_pipeline_service/router.py','backend/depo_platform/database_setup.py'],
 install:['INSTALLATION.md','infra/windows/install-depo-windows.ps1','infra/windows/update-depo-windows.ps1','backend/postgres_migrations.py'],
};
const seq=[];
function text(slide,str,x,y,w,h,size=17,opts={}){
 slide.addText(str,{x,y,w,h,fontFace:'Arial',fontSize:size,color:C.ink,margin:0,breakLine:false,verticalAnchor:'top',...opts});
}
function base(title,kicker='APPLICATION ARCHITECTURE',subtitle=''){
 const slide=pptx.addSlide(); slide.background={color:C.white};
 const n=pptx._slides.length;
 text(slide,kicker.toUpperCase(),.6,.2,11.9,.25,10,{bold:true,color:C.teal,charSpacing:1.6});
 text(slide,title,.6,.63,12.1,.54,27,{bold:true,color:C.navy});
 if(subtitle)text(slide,subtitle,.6,1.22,12.0,.43,14,{color:C.muted});
 slide.addShape(pptx.ShapeType.line,{x:.6,y:7.03,w:12.1,h:0,line:{color:C.line,width:.6}});
 text(slide,'DEPO  /  Industrial data architecture  /  16 October 2026',.6,7.12,10,.18,9,{color:C.muted});
 text(slide,String(n).padStart(2,'0'),12.1,7.1,.55,.22,10,{color:C.muted,align:'right'});
 return slide;
}
function notes(slide,files,extra=''){
 slide.addNotes(`Architecture baseline: repository commit 0d728b9, reviewed 16 October 2026.\nSources:\n${files.map(f=>path.join(ROOT,f)).join('\n')}\n${extra}\nImplementation statements describe the repository. Live customer deployment acceptance remains separate.`);
}
function five(slide,answers){
 const labels=['WHAT','WHY','WHO','WHEN','WHERE','HOW'];
 answers.forEach((answer,i)=>{
  const col=i%3,row=Math.floor(i/3),x=.6+col*4.1,y=5.82+row*.55;
  text(slide,labels[i],x,y,.58,.18,9,{bold:true,color:C.teal});
  text(slide,answer,x+.66,y,3.29,.46,11.5,{color:C.muted});
 });
}
function diagramSlide(title,id,answers,files,subtitle='',extra=''){
 const slide=base(title,'ARCHITECTURE VIEWS',subtitle);
 const d=diagrams[id], box={x:.56,y:subtitle?1.7:1.29,w:12.18,h:subtitle?3.92:4.30};
 let w=box.w,h=w/d.ratio;if(h>box.h){h=box.h;w=h*d.ratio;}
 const x=box.x+(box.w-w)/2,y=box.y+(box.h-h)/2;
 slide.addImage({data:'image/svg+xml;base64,'+Buffer.from(d.svg).toString('base64'),x,y,w,h,altText:title});
 // PptxGenJS on Node otherwise writes a broken-image placeholder as SVG preview.
 // Supply a real high-resolution fallback while retaining the native SVG relationship.
 const preview=slide._relsMedia.find(rel=>rel.isSvgPng);
 preview.data='image/png;base64,'+d.png.toString('base64');preview.isSvgPng=false;preview.path='';
 five(slide,answers);notes(slide,files,extra);
 manifest.push({slide:pptx._slides.length,title,diagram:id,notation:extra||'Architecture view'});
 return slide;
}
function tableSlide(title,headers,rows,widths,files,subtitle='',foot=''){
 const slide=base(title,'ARCHITECTURE DECISIONS',subtitle);
 const all=[headers.map(h=>({text:h,options:{bold:true,color:C.white,fill:C.navy}})),...rows];
 slide.addTable(all,{x:.6,y:1.84,w:12.1,colW:widths,rowH:rows.length>=8?.48:.58,border:{type:'solid',pt:.5,color:C.line},fontFace:'Arial',fontSize:rows.length>=8?12.5:14.5,color:C.ink,
  fill:C.white,margin:rows.length>=8?.09:.13,autoPage:false,breakLine:false,verbose:false,paraSpaceAfterPt:0,valign:'middle'});
 if(foot)text(slide,foot,.6,6.45,12.0,.37,12.5,{color:C.muted});
 notes(slide,files);return slide;
}
function columnsSlide(title,items,files,subtitle=''){
 const slide=base(title,'OPERATING MODEL',subtitle);
 items.forEach((item,i)=>{
  const x=.65+i*4.12;
  text(slide,item.title,x,2.02,3.7,.52,21,{bold:true,color:i===2?C.teal:C.navy});
  text(slide,item.body,x,2.85,3.72,3.3,17,{paraSpaceAfterPt:13,breakLine:false});
 });notes(slide,files);return slide;
}

// 01 — editable title composition.
{
 const slide=pptx.addSlide();slide.background={color:C.navy};
 text(slide,'DEPO  /  INDUSTRIAL DATA PLATFORM',.8,.68,11.7,.3,13,{bold:true,color:'64D5C7',charSpacing:1.8});
 text(slide,'Enterprise\nsoftware architecture',.8,1.58,11.4,1.75,42,{bold:true,color:C.white,breakLine:false});
 text(slide,'Ontology alignment, governed agents and reusable data products',.84,3.75,10.8,.92,24,{color:'D6E5F2'});
 text(slide,'C4 • UML • TOGAF-aligned architecture views',.84,5.24,11.3,.4,17,{color:'93B4D1'});
 text(slide,'16 October 2026   |   Repository baseline 0d728b9',.84,6.48,11.3,.3,13,{color:'93B4D1'});
 notes(slide,['infra/deployment/services.json','docs/DATA_PRODUCT_INGESTION.md','INSTALLATION.md']);
}
tableSlide('Architecture scope and TOGAF-aligned layers',['Layer','Architecture responsibility','DEPO implementation'],[
 ['Business','Engineering meaning, stewardship and reusable evidence','Ontology review, instance linking, governed products'],
 ['Application','Service responsibilities and permitted interactions','10 APIs, 3 workers, React / Siemens IX frontend'],
 ['Data','Identity, lineage, persistence and publication outcomes','PostgreSQL, Neo4j and immutable artifact references'],
 ['Technology','Runtime, network, security and operational readiness','Windows deployment, optional gateway, Spark and Ollama'],
],[1.6,4.8,5.7],sources.context,'Four architecture domains organize the views; this is an implementation architecture, not a certification claim.','Scope: repository capabilities and customer deployment controls; untested external connectors remain deployment work.');
diagramSlide('C4 context — users, platform and external systems','01-c4-context',[
 'Industrial semantic integration and reuse.','Preserve meaning and evidence across systems.','Engineers, stewards, analysts and operators.','Import, align, query and publish tasks.','Customer application and private data services.','Scoped APIs, supported files and model REST.'
],sources.context,'Level 1 · DEPO is the system of interest; external systems remain outside its authority.','C4 System Context. External source coverage depends on supported parsers and configured adapters.');
diagramSlide('C4 containers — ten APIs and three workers','02-c4-containers',[
 'Deployable APIs, workers and persistent stores.','Separate request handling from durable execution.','Frontend, domain services and worker processes.','Interactive requests and queued background work.','Internal ports 8010–8019; public routing is configurable.','REST, PostgreSQL leases, artifacts and Bolt.'
],sources.containers,'Level 2 · Container names and ports follow the deployment manifest.','C4 Container. Gateway is optional. Storage arrows summarize ownership rather than enumerate every read connection.');
diagramSlide('C4 components — agentic execution boundary','03-c4-agent-components',[
 'Agent discovery, planning and permitted tool execution.','Keep model suggestions behind service authorization.','Agentic router, workflow worker and domain APIs.','Recommendation and approved multi-step workflows.','Agentic :8012 with PostgreSQL run state.','Validated catalog, grants, leases and bounded tools.'
],sources.agent,'Level 3 · Recommendations and durable workflows share the validated tool catalog.','C4 Component. LLM assistance is optional; agents do not self-authorize protected operations.');
diagramSlide('UML components — governed graph publication','04-uml-publication-components',[
 'Distinct publication contracts converge on graph writes.','Prevent hidden writes and ambiguous completion.','Ontology, CEIM, Agentic and Graph services.','After source and policy evidence satisfy a contract.','Private Graph API and named Neo4j database.','Scoped credentials, batched writes and receipts.'
],sources.graph,'Ontology projection, CEIM batches and Bridge links have separate contracts.','UML Component view. Product packaging and ODS commits are independent persistence outcomes.');
diagramSlide('UML deployment — customer runtime and network zones','05-uml-deployment',[
 'Browser, ingress, APIs, workers and data services.','Expose the UI while containing privileged data access.','Customer operations and service identities.','Installation, normal operation and recovery.','Application VM and private database network.','Reviewed routing, TLS policy and durable storage.'
],sources.containers.concat(sources.install),'The deployment can use direct service URLs or a configured gateway.','UML Deployment. Diagram is a deployment pattern; VM placement, firewall rules and TLS require customer acceptance.');
diagramSlide('UML sequence — delegated browser access','06-uml-session-sequence',[
 'A bounded browser session with selected scopes.','Avoid repeated raw-key entry during active use.','User, ontology session API and protected APIs.','Connect, authorized requests and active renewal.','Browser token; PostgreSQL credential validation.','Admin verification, delegation and absolute expiry.'
],sources.session,'Reconnection restores access; expiry does not undo completed writes.','UML Sequence. Renewal remains bounded by absolute expiry. Revoked or fully expired access requires reconnection.');
diagramSlide('UML sequence — source registration and RDF publication','07-uml-ontology-sequence',[
 'Create an ontology from retained engineering inputs.','Separate registration evidence from graph availability.','User, ingestion, ontology and graph services.','Schema conversion, then authorized publication.','Artifacts and PostgreSQL; RDF projection in Neo4j.','Retained identity, publication job and receipt.'
],sources.graph.concat(['backend/ingestion_service/router.py']),'A registered ontology and a published RDF projection are separate states.','UML Sequence. Logical handoffs omit internal validation calls; clients must inspect retained outcomes after response loss.');
diagramSlide('UML activity — Semantic Bridge decision flow','08-uml-bridge-activity',[
 'Instance linking or ontology-to-ontology union.','Keep task types and conflict decisions explicit.','Governor, steward, authorized user and services.','After exact source and target selection.','Ontology Junction / Semantic Bridge and workers.','Preview, policy evaluation and retained outcomes.'
],sources.agent.concat(sources.graph),'Automatic policy routes hold unsupported, stale or conflicting candidates.','UML Activity. Automatic publication remains subject to server policy and supplied authorization.');
diagramSlide('UML sequence — automated ontology union draft','09-uml-merge-sequence',[
 'A retained union draft with evaluation evidence.','Reduce repetitive review without bypassing policy.','Governor previews; steward evaluates; governor applies.','Authorized ontology-union-automation run.','Agentic worker, ontology tools and retained stores.','Checkpointed preview, evaluate and eligible apply.'
],sources.agent,'The workflow creates an eligible union draft; graph publication is a separate outcome.','UML Sequence. Tool names and workflow steps follow backend/agentic_service/catalog.json.');
diagramSlide('UML class view — retained domain identities','10-uml-domain-classes',[
 'Logical records and their evidence relationships.','Keep source, run, publication and product identities distinct.','Domain services own records; clients use references.','Across review, execution and publication.','PostgreSQL records plus referenced artifacts.','Stable keys, digests and explicit cardinalities.'
],sources.data.concat(sources.agent),'Logical domain model · records may be JSON documents rather than ORM classes.','UML Class diagram is conceptual. Field names summarize domain contracts and do not claim one SQL table or Python class per box.');
tableSlide('Data ownership — application state, ODS, RDF and artifacts',['Store','Owned data','Important boundary'],[
 ['PostgreSQL application schema','10 tables and 1 analytics view; registry namespaces, credentials and runs','Migrations 001–011; namespaces share relations'],
 ['PostgreSQL analytics schemas','One versioned schema per retained XSD closure / prefix; XML entities and links','Fact / dimension views require explicit grain and keys'],
 ['Neo4j','Published RDF resources, semantic relationships and publication evidence','Registration alone does not establish publication'],
 ['Durable artifact storage','Original bytes, RDF, reports, load receipts and product packages','Retention and access policies apply to each artifact'],
],[2.4,5.1,4.6],sources.data,'Storage responsibilities follow independent commit and publication boundaries.','A product package references selected evidence; it does not automatically export every ODS row or the entire graph.');
diagramSlide('UML activity — XML ODS and data-mart preparation','11-xml-ods-activity',[
 'Validated XML becomes structural PostgreSQL data.','Keep a committed load recoverable after evidence failure.','Pipeline worker and explicit analytics profile.','Supported XSD projection and XML instance load.','Versioned analytics schema in PostgreSQL.','Bounded batches, commit receipt and reconciliation.'
],sources.data,'Business grain and history policy remain explicit; arbitrary files do not define a data mart.','UML Activity. Current ODS path is XSD/XML. CSV/XLSX-to-ODS and SCD/conformed dimensions need separate contracts.');
diagramSlide('Sequence — product packaging and catalog delivery','12-product-sequence',[
 'A versioned package and discoverable catalog record.','Separate durable packaging from delivery retries.','Product API, outbox worker and catalog service.','After evidence and authorization validate.','Artifact packages and PostgreSQL product state.','Preview, immutable package and outbox reconciliation.'
],sources.data.concat(['backend/data_product_service/router.py']),'Catalog retries reconcile registration; they do not rerun ingestion.','UML Sequence. Package publication, graph publication and catalog registration have distinct completion evidence.');
diagramSlide('Scoped graph retrieval and Knowledge Companion','13-graph-retrieval',[
 'Bounded graph evidence and optional model summary.','Explain answers using the selected ontology context.','Knowledge Companion, Graph API and optional model.','A user submits an authorized scoped question.','Graph resources, provenance and response evidence.','Search, bounded expansion and evidence references.'
],['backend/agentic_service/companion.py','backend/agentic_service/oslc_graph_rag.py','frontend/src/Components/Chatbot.js'],'Model availability and graph evidence availability are independent checks.','Component/data-flow view. Vector ranking and retrieval quality require configured models, data and evaluation; no universal accuracy claim.');
tableSlide('Ollama REST integration — verify capabilities separately',['Capability','Contract and control','Verification meaning'],[
 ['Generation / chat','Use the configured API root or explicit operation URL','A completed response verifies that operation only'],
 ['Model discovery','GET /api/tags only when the gateway exposes it','A missing optional discovery route does not prove chat failure'],
 ['Streaming','Validate native response frames and terminal completion','HTTP 200 alone does not establish a complete stream'],
 ['Tool calling','Model / route capability check; tools retain their own authorization','Chat completion alone does not prove tool support'],
 ['Credentials','Server-side API key header and explicit gateway scope','Never compile LLM or gateway keys into browser settings'],
],[2.0,5.5,4.6],['backend/core/ollama_auth.py','backend/agentic_service/local_llm.py','infra/windows/test-depo-ollama.ps1'],'REST operation paths follow the deployed gateway contract.','Examples in configuration are guidance; test the actual customer route, model and response contract.');
diagramSlide('Failure lifecycle — uncertain response, retained outcome','14-failure-lifecycle',[
 'Recovery across side effects and response loss.','Prevent duplicate writes after a client timeout.','UI, workers, domain APIs and operators.','Timeout, interruption or downstream failure.','Persisted run state and service-owned receipts.','Inspect, reconcile and reuse stable identities.'
],sources.graph.concat(sources.session,sources.data),'Browser session expiry does not cancel an authorized background workflow.','UML Activity. Pause and cancel remain cooperative at tool boundaries; completed writes remain retained.');
tableSlide('Security and governance boundaries',['Boundary','Implemented control','Operating rule'],[
 ['Browser access','Delegated session, selected scopes, active renewal and expiry','Reconnect after full expiry / revocation; raw admin key stays out of builds'],
 ['Protected service operations','Credential profiles and authenticated actor resolution','Model recommendations never grant approval authority'],
 ['Durable workflow execution','Persisted grant, credential fingerprints, lease and checkpoints','No caller secrets in retained workflow inputs'],
 ['Network and data services','Configured gateway roots, exact origins and database identities','Customer validates TLS, firewall access and least privilege'],
 ['Operational maintenance','Separate admin authorization, scoped cleanup and audit evidence','Cleanup actions retain their own permissions and confirmations'],
],[2.2,5.0,4.9],sources.session.concat(['backend/depo_platform/authorization.py','backend/routes/admin_routes.py']),'Session lifecycle, operation authority and workflow execution are separate controls.');
tableSlide('Installation entry points and database upgrade responsibilities',['Command / script','Owned responsibility','Existing customer installation'],[
 ['Root install-depo.ps1','Delegates to complete Windows installer','Use one entry point; do not run both installers separately'],
 ['infra/windows/install-depo-windows.ps1','Dependencies, migrations, graph schema, startup and validation','Preserve environment files and durable data'],
 ['infra/windows/install-depo.ps1','Runtime prerequisites and dependency installation helper','Complete installer calls this helper automatically'],
 ['infra/postgres/\nupdate-postgres-schema.ps1','Pending PostgreSQL migrations and schema verification','Schema-only operation; no application restart'],
 ['infra/windows/update-depo-windows.ps1','Validated update sequence using the selected environment','Use -InstallDependencies when release locks change'],
],[4.1,4.0,4.0],sources.install,'Python 3.12.x · Node.js 24+ · npm 10.2+ · Spark/JDK only for enabled compute paths.');
diagramSlide('UML activity — customer update and restart sequence','15-upgrade-activity',[
 'An in-place update using the selected environment.','Fail early and preserve existing data and credentials.','Deployment operator and service-owned scripts.','After placing the complete matching release.','Customer application VM; existing databases.','Preflight, pending migrations, readiness and acceptance.'
],sources.install,'Service timeout limit: 300 seconds. Longer workflow and publication budgets have separate controls.','UML Activity. Migration failure rolls back its transaction. Failure after a successful migration requires an operator recovery plan; no automatic downgrade is implied.');
tableSlide('Service contracts and primary frontend consumers',['Service / internal port','API responsibility','Primary UI / caller'],[
 ['Schema sets :8010','Engineering schema inspection and conversion','Import / QIF'],
 ['Ontology :8011','Registration, lifecycle, modeling and publication jobs','Ontology Junction / Admin'],
 ['Agentic :8012','Agent catalog, tools, workflows and Companion','Semantic Bridge / Companion'],
 ['Graph :8013','Publication receipts, scoped queries and traversal','Graph Explorer / domain APIs'],
 ['Ingestion :8014','Sources, supported parsers and retained evidence','Import / engineering workflow'],
 ['OSLC :8015 · CEIM :8018','Linked resources / canonical mapping and validation','Configured integrations / semantic jobs'],
 ['Products :8017 · Catalog :8016','Immutable packages / governed product discovery','Data Products / Data Catalog'],
 ['Pipeline :8019','Job definitions, worker runs and analytics recovery','Data Flow / XML analytics loader'],
],[2.8,5.0,4.3],sources.containers,'OpenAPI 3.0.3 and service discovery describe operation ownership and authorization.');
columnsSlide('Operational readiness and customer acceptance',[
 {title:'Implemented controls',body:'Durable run identities and receipts\n\nScoped access and request IDs\n\nBounded writes and recovery paths\n\nConfiguration and migration checks'},
 {title:'Customer evidence',body:'Database ownership and history\n\nGateway, TLS and browser access\n\nLarge-ontology load and recovery\n\nWorker restart and backup restore'},
 {title:'Explicit product choices',body:'Fact grain and dimension policy\n\nNamed external source adapters\n\nMapping / retrieval evaluation\n\nModel capability and deployment sizing'},
],sources.install.concat(sources.data),'Repository verification supports release preparation. Customer acceptance establishes deployment readiness.');
columnsSlide('Architecture decisions and extension points',[
 {title:'Stable service boundaries',body:'Keep domain APIs as the source of operation contracts.\n\nExpose governed tools through the existing catalog and MCP adapter.'},
 {title:'Evidence before scale',body:'Measure import, mapping and retrieval outcomes on agreed engineering data.\n\nPreserve lineage and recovery identities when adding connectors.'},
 {title:'Independent outcomes',body:'Track ontology registration, RDF publication, ODS commit, product packaging and catalog delivery separately.\n\nUse explicit business contracts for new analytics.'},
],sources.context.concat(sources.agent),'A framework replacement alone does not establish correctness, interoperability or customer readiness.');

// Structural QA: every diagram has six visible explanations and source notes.
const expectedSlides=24;
if(pptx._slides.length!==expectedSlides)throw new Error(`Expected ${expectedSlides} slides, got ${pptx._slides.length}`);
await fs.writeFile(path.join(WORK,'diagram-manifest.json'),JSON.stringify(manifest,null,2));
await fs.writeFile(path.join(SOURCES,'README.md'),`# DEPO enterprise architecture diagrams\n\nBaseline: repository commit 0d728b9, 16 October 2026.\n\nThe PPTX contains editable titles, explanations and tables. Diagram assets are embedded SVG with high-resolution PNG fallbacks. Edit each Graphviz .dot file and render with Graphviz dot (dot -Tsvg input.dot -o output.svg). The UML class view describes logical records, not generated ORM classes.\n\nDiagram notation and slide mapping are listed in diagram-manifest.json. The generator uses PptxGenJS 4.x, @viz-js/viz, sharp and jszip. Set DEPO_REPO to the repository directory before running the generator.\n\nSources: INSTALLATION.md, docs/DATA_PRODUCT_INGESTION.md, infra/deployment/services.json, current service/router implementations. Runtime controls describe the repository; customer network, database and recovery acceptance remain deployment activities.\n`);
await fs.copyFile(path.join(WORK,'diagram-manifest.json'),path.join(SOURCES,'diagram-manifest.json'));
await fs.copyFile(new URL(import.meta.url),path.join(SOURCES,'build_architecture.mjs'));
const draft=path.join(WORK,'DEPO_Enterprise_Architecture_draft.pptx');
await pptx.writeFile({fileName:draft});
// Remove PptxGenJS content-type declarations for absent duplicate masters.
// All referenced masters and relationships remain intact.
const packageZip=await JSZip.loadAsync(await fs.readFile(draft));
let contentTypes=await packageZip.file('[Content_Types].xml').async('string');
contentTypes=contentTypes.replace(/<Override\b[^>]*PartName="([^"]+)"[^>]*\/>/g,(whole,part)=>packageZip.file(part.replace(/^\//,''))?whole:'');
packageZip.file('[Content_Types].xml',contentTypes);
await fs.writeFile(draft,await packageZip.generateAsync({type:'nodebuffer',compression:'DEFLATE'}));
const zip=new JSZip();for(const file of await fs.readdir(SOURCES))zip.file(file,await fs.readFile(path.join(SOURCES,file)));
await fs.writeFile(path.join(OUT,'DEPO_Architecture_Diagram_Sources.zip'),await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE'}));
console.log(JSON.stringify({draft,slides:pptx._slides.length,diagrams:manifest.length,output:OUT}));
