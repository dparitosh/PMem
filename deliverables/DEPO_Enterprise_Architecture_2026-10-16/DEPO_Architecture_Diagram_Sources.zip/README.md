# DEPO enterprise architecture diagrams

Baseline: repository commit 0d728b9, 16 October 2026.

The PPTX contains editable titles, explanations and tables. Diagram assets are embedded SVG with high-resolution PNG fallbacks. Edit each Graphviz .dot file and render with Graphviz dot (dot -Tsvg input.dot -o output.svg). The UML class view describes logical records, not generated ORM classes.

Diagram notation and slide mapping are listed in diagram-manifest.json. The generator uses PptxGenJS 4.x, @viz-js/viz, sharp and jszip. Set DEPO_REPO to the repository directory before running the generator.

Sources: INSTALLATION.md, docs/DATA_PRODUCT_INGESTION.md, infra/deployment/services.json, current service/router implementations. Runtime controls describe the repository; customer network, database and recovery acceptance remain deployment activities.
